import { Box, Button, FormControl, TextField } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../HouseholdComponentsStyles';

/**
 * Name : RentAffordabilityCalculator
 * Desc : Render RentAffordabilityCalculator
 */

const RentAffordabilityCalculator = ({
    width,
    title,
    showFaceBookLoginButton,
    onClickContinue
}) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box
                fontSize="h5.fontSize"
                lineHeight="35px"
                color="primary.light"
                mb={5.5}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                {title}
            </Box>
            <Box>
                <Box className={classes.formWidth} width="100%">
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                        Your household’s monthly gross income
                    </Box>
                    <FormControl fullWidth>
                        <TextField id="jobTitle" label="$2,123" variant="filled" />
                    </FormControl>
                    <Box
                        mt={-1.5}
                        mb={2.5}
                        color="primary.main"
                        fontSize="md.fontSize"
                        fontStyle="italic">
                        Added for you from your previous answers
                    </Box>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                        Your household’s monthly special expenses for childcare, medical, or
                        disability
                    </Box>
                    <FormControl fullWidth>
                        <TextField id="jobTitle" label="$150" variant="filled" />
                    </FormControl>
                    <Box
                        mt={-1.5}
                        mb={2.5}
                        color="primary.main"
                        fontSize="md.fontSize"
                        fontStyle="italic">
                        Added for you from your previous answers
                    </Box>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                        Other monthly expenses, including things like car payments, groceries,
                        etc..*
                    </Box>
                    <FormControl fullWidth>
                        <TextField id="jobTitle" label="Expense Amount" variant="filled" />
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                        Your monthly savings amount
                    </Box>
                    <FormControl fullWidth>
                        <TextField id="jobTitle" label="Savings Amount" variant="filled" />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(
                            width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                            showFaceBookLoginButton && 'facebooKBtn'
                        )}>
                        {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                    </Button>
                </Box>
                <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                    Your household’s monthly special expenses for childcare, medical, or disability
                </Box>
                <FormControl fullWidth>
                    <TextField id="jobTitle" label="$150" variant="filled" />
                </FormControl>
                <Box
                    mt={-1.5}
                    mb={2.5}
                    color="primary.light"
                    fontSize="md.fontSize"
                    fontStyle="italic">
                    Added for you from your previous answers
                </Box>
                <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                    Other monthly expenses, including things like car payments, groceries, etc..*
                </Box>
                <FormControl fullWidth>
                    <TextField id="jobTitle" label="Expense Amount" variant="filled" />
                </FormControl>
                <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                    Your monthly savings amount
                </Box>
                <FormControl fullWidth>
                    <TextField id="jobTitle" label="Savings Amount" variant="filled" />
                </FormControl>
            </Box>
            <Box className={classes.xsBtn}>
                <Button
                    type="submit"
                    size="large"
                    color="primary"
                    variant="contained"
                    fullWidth={width === 'xs' || width === 'sm' ? true : false}
                    className={clsx(
                        width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                        showFaceBookLoginButton && 'facebooKBtn'
                    )}
                    onClick={(!showFaceBookLoginButton && onClickContinue) || null}>
                    {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                </Button>
            </Box>
        </Box>
    );
};

RentAffordabilityCalculator.defaultProps = {
    title: '',
    showFaceBookLoginButton: false
};

RentAffordabilityCalculator.propTypes = {
    onClickContinue: PropTypes.func,
    title: PropTypes.string,
    width: PropTypes.string,
    showFaceBookLoginButton: PropTypes.bool
};

export default withWidth()(RentAffordabilityCalculator);
