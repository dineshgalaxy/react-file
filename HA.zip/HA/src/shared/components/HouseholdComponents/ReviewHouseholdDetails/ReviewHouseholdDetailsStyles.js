import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 96px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: 0,
            alignItems: 'flex-start'
        }
    },

    title: {
        borderBottom: `2px solid ${theme.common.white}`,
        '& .MuiIconButton-root':{
            padding:"0"
        }
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    },
    actionBtnWrapper: {
        '& > button': {
            fontSize: theme.typography.lg.fontSize,
            color: theme.palette.primary.main,
            position: 'relative',
            '&:not(:last-child)': {
                marginRight: `${theme.spacing(3)}px !important`,
                '&:before': {
                    content: '"|"',
                    width: '2px',
                    color: theme.palette.primary.main,
                    position: 'absolute',
                    right: '-11px'
                }
            }
        }
    }
}));

export default useStyles;
