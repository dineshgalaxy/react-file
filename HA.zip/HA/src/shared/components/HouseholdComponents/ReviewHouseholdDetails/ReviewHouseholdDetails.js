import { Box, Button, Grid, IconButton } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { Edit } from 'react-feather';
import useStyles from './ReviewHouseholdDetailsStyles';

/**
 * Name : ReviewHouseholdDetails
 * Desc : Render ReviewHouseholdDetails
 */

const ReviewHouseholdDetails = ({ onNextButtonClick, width }) => {
    const classes = useStyles();

    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%" mt={-1.5}>
                <Grid container spacing={3}>
                    <Grid item xs={12} md={6}>
                        <Box mb={4}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={2}
                                px={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Your Personal Details
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>

                            <Box
                                color="primary.light"
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.medium"
                                mb={1}>
                                Erika Alexander, 34
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Address Line 1
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Address Line 2
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Telephone
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Email Address
                            </Box>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={6.5}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={2}
                                px={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Household Details
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            <Box mb={6}>
                                <Box
                                    color="primary.light"
                                    fontSize="lg.fontSize"
                                    fontFamily="fontFamily.medium"
                                    mb={1}>
                                    First Name Last Name, 34
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    <Box component="span" mr={0.5}>
                                        Maiden:
                                    </Box>
                                    <Box component="span">Last Name</Box>
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Relationship
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Gender
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    <Box component="span" mr={0.5}>
                                        SSN:
                                    </Box>
                                    <Box component="span">XXXX-XX-XXXX</Box>
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Citizenship Status
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    <Box component="span" mr={0.5}>
                                        DOB:
                                    </Box>
                                    <Box component="span">XXXX-XX-XXXX</Box>
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Disability Status
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Student Status
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Sex Offender Status
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Race/ Ethnicity Edit Details
                                </Box>
                                <Box
                                    display="flex"
                                    alignItems="center"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    className={classes.actionBtnWrapper}>
                                    <Button size="medium" className="linkBtn">
                                        Edit
                                    </Button>
                                    <Button size="medium" className="linkBtn">
                                        Delete
                                    </Button>
                                </Box>
                            </Box>
                            <Box mb={9.5}>
                                <Box
                                    color="primary.light"
                                    fontSize="lg.fontSize"
                                    fontFamily="fontFamily.medium"
                                    mb={1}>
                                    First Name Last Name, 34
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    <Box component="span" mr={0.5}>
                                        Maiden:
                                    </Box>
                                    <Box component="span">Last Name</Box>
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Relationship
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Citizenship Status
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    <Box component="span" mr={0.5}>
                                        DOB:
                                    </Box>
                                    <Box component="span">XXXX-XX-XXXX</Box>
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Disability Status
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Student Status
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Sex Offender Status
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Race/ Ethnicity Edit Details
                                </Box>
                                <Box
                                    display="flex"
                                    alignItems="center"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    className={classes.actionBtnWrapper}>
                                    <Button size="medium" className="linkBtn">
                                        Edit
                                    </Button>
                                    <Button size="medium" className="linkBtn">
                                        Delete
                                    </Button>
                                </Box>
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        onClick={onNextButtonClick}
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Continue
                    </Button>
                </Box>
            </Box>
        </Box>
    );
};
ReviewHouseholdDetails.propTypes = {
    onNextButtonClick: PropTypes.func,
    width: PropTypes.string
};
export default withWidth()(ReviewHouseholdDetails);
