import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import useStyles from '../HouseholdComponentsStyles';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : HouseholdSpecialExpensesSelection
 * Desc : Render HouseholdSpecialExpensesSelection
 */

const HouseholdSpecialExpensesSelection = ({ title, width, onClickContinue }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={4.5}
                mt={.5}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                {title}
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box mb={.5}>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Medical expenses, such as medical insurance premiums, costs not covered by insurance, services of medical professionals or facilities, psychiatric treatment, or costs of medical equipement"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Disability expenses or costs for attendant care and auxilary apparatus for a disabled family member"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Childcare expenses, including costs paid for the care of children under 13 years of age, enabling a family member to work, attend school, or seek employment"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="None of the above"
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}
                        onClick={ onClickContinue }
                    >
                        Next
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

HouseholdSpecialExpensesSelection.propTypes = {
    onClickContinue: PropTypes.func,
    title: PropTypes.string,
    width: PropTypes.string,
};

export default withWidth()(HouseholdSpecialExpensesSelection);
