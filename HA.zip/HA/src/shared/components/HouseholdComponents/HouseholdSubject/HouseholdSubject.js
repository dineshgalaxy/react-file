import { Box, Button, FormControl, FormControlLabel, Radio, RadioGroup } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../HouseholdComponentsStyles';

/**
 * Name : HouseholdSubject
 * Desc : Render HouseholdSubject
 */

const HouseholdSubject = ({ width, title }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
        <Box
            fontSize="h5.fontSize"
            lineHeight="35px"
            color="primary.light"
            mb={6.75}
            maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
            {title}
        </Box>
        <Box className={classes.formWidth} width="100%">
            <Box pb={3}>
                <FormControl component="fieldset">
                    <RadioGroup
                        defaultValue="female"
                        aria-label="proxy"
                        name="customized-radios">
                        <Box mb={2}>
                            <FormControlLabel
                                value="true"
                                control={<Radio className="extraLightLabel" />}
                                label="Yes"
                            />
                        </Box>
                        <FormControlLabel
                            value="false"
                            control={<Radio className="extraLightLabel" />}
                            label="No"
                        />
                    </RadioGroup>
                </FormControl>
            </Box>
            <Box className={classes.xsBtn}>
                <Button
                    type="submit"
                    size="large"
                    color="primary"
                    variant="contained"
                    fullWidth={width === 'xs' || width === 'sm' ? true : false}
                    className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                    Next
                </Button>
            </Box>
        </Box>
    </Box>
    )
};

HouseholdSubject.propTypes = {
    width: PropTypes.string,
    title: PropTypes.string
};
export default withWidth()(HouseholdSubject);

