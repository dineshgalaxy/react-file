export { default } from './AssetDisposal';
