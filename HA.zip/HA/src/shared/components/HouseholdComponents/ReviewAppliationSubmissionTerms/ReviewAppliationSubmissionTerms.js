import { Box, Button, Checkbox, FormControl, FormControlLabel, TextField } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from './ReviewAppliationSubmissionTermsStyles';

/**
 * Name : ReviewAppliationSubmissionTerms
 * Desc : Render ReviewAppliationSubmissionTerms
 */

const ReviewAppliationSubmissionTerms = ({ width }) => {
    const classes = useStyles();

    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%" p={1}>
                <Box mb={2}>
                    <Box mx={-3} mb={5} px={3}>
                        <Box color="primary.light" fontSize="h6.fontSize" pb={4}>
                            I (all adults listed in the household) understand by submitting these documents, that they are true to the best of my knowledge. I further understand that statements or information provided by me are punishable under federal and state law and may constitute grounds for termination.
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize" pb={2}>
                            I acknowledge and agree that my electronic signature will be affixed in the documents required for my recertification and all signatures are attributable to the person whose name is typed in the signature line. 
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            I acknowledge and agree that in the event that any person known to me misappropriates my login or electronic signature account and HACEP could not reasonably detect it, HACEP shall have the right to treat all resulting electronic signatures and information as though they were affixed by the person whose name is typed in the signature line.
                        </Box>
                    </Box>
                </Box>
                <Box mt={4}>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    className="extraLightLabel"
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label={
                                <Box color="primary.extraLight" fontSize="h6.fontSize" mb={2}>
                                    I have read and accept the above terms and conditions
                                </Box>
                            }
                        />
                    </FormControl>
                </Box>
                <Box mt={2.5}>
                    <FormControl fullWidth>
                        <TextField
                            id="paycheckAmount"
                            label={
                                <Box display="flex" alignItems="center">
                                    Applicant Name<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="paycheckAmount"
                            label={
                                <Box display="flex" alignItems="center">
                                    Signature<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <Box mt={-1.5} color="primary.main" fontSize="md.fontSize" fontStyle="italic">
                        Type your name to sign 
                    </Box>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="secondary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Submit
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

ReviewAppliationSubmissionTerms.propTypes = {
    width: PropTypes.string
};
export default withWidth()(ReviewAppliationSubmissionTerms);