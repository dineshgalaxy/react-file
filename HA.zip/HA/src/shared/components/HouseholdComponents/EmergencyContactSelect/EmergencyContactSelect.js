import { Box, FormControl, RadioGroup, FormControlLabel, Radio, Button } from '@material-ui/core';
import useStyles from '../HouseholdComponentsStyles';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : EmergencyContactSelect
 * Desc : Render EmergencyContactSelect
 */

const EmergencyContactSelect = ({ width, title, showFaceBookLoginButton, onNextButtonClick }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={5.5}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                {title}
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box mb={8.5}>
                    <FormControl component="fieldset">
                        <RadioGroup defaultValue="female" aria-label="proxy" name="customized-radios">
                            <Box mb={2}>
                                <FormControlLabel 
                                    value="true" 
                                    control={<Radio className="extraLightLabel"/>} 
                                    label="Yes" 
                                />
                            </Box>
                            <FormControlLabel 
                                value="false" 
                                control={<Radio className="extraLightLabel"/>} 
                                label="No" 
                            />
                        </RadioGroup>
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(
                            width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                            showFaceBookLoginButton && 'facebooKBtn'
                        )}
                        onClick={onNextButtonClick}
                    >
                        {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

EmergencyContactSelect.defaultProps = {
    title: '',
    showFaceBookLoginButton: false
};

EmergencyContactSelect.propTypes = {
    onNextButtonClick: PropTypes.func,
    title: PropTypes.string,
    showFaceBookLoginButton: PropTypes.bool,
    width: PropTypes.string
};
export default withWidth()(EmergencyContactSelect);