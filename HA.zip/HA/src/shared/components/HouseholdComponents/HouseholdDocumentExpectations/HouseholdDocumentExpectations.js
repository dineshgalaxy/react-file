import { Box, Button } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from './HouseholdDocumentExpectationsStyles';

/**
 * Name : HouseholdDocumentExpectations
 * Desc : Render HouseholdDocumentExpectations
 */

const HouseholdDocumentExpectations = ({ onNextButtonClick, width }) => {
    const classes = useStyles();

    return (
        <Box className={classes.flex} width="100%">
            <Box
                fontSize="h5.fontSize"
                lineHeight="35px"
                color="primary.light"
                mb={5.5}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                We need to gather the following documents for your household’s members.
            </Box>
            <Box className={classes.textAlign} width="100%" pl={width === 'xs' || width === 'sm' ? '0' : 6}>
                <Box mb={3}>
                    <Box
                        mx={-3}
                        mb={2}
                        px={3}
                        pb={1}
                        className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.light">
                            Member First Name
                        </Box>
                    </Box>

                    <Box
                        color="primary.light"
                        fontSize="lg.fontSize"
                        fontStyle="italic"
                        mb={1}>
                        Provide all three of these::
                    </Box>
                    <Box
                        color="primary.light"
                        fontSize="lg.fontSize"
                        className={classes.list}>
                        Social Security Card
                    </Box>
                    <Box
                        color="primary.light"
                        fontSize="lg.fontSize"
                        className={classes.list}>
                        Driver’s License or other State-Issued ID
                    </Box>
                    <Box
                        color="primary.light"
                        fontSize="lg.fontSize"
                        className={classes.list}>
                        Birth Certificate
                    </Box>
                </Box>
                <Box mb={7}>
                    <Box
                        mx={-3}
                        mb={2}
                        px={3}
                        pb={1}
                        className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.light">
                            Member First Name
                        </Box>
                    </Box>

                    <Box
                        color="primary.light"
                        fontSize="lg.fontSize"
                        fontStyle="italic"
                        mb={1}>
                        Provide at least one from this list:
                    </Box>
                    <Box
                        color="primary.light"
                        fontSize="lg.fontSize"
                        className={classes.list}>
                        Social Security Card
                    </Box>
                    <Box
                        color="primary.light"
                        fontSize="lg.fontSize"
                        className={classes.list}>
                        Driver’s License
                    </Box>
                    <Box
                        color="primary.light"
                        fontSize="lg.fontSize"
                        className={classes.list}>
                        Birth Certificate
                    </Box>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        onClick={onNextButtonClick}
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Start Uploading Documents
                    </Button>
                </Box>
            </Box>
        </Box>
    );
};
HouseholdDocumentExpectations.propTypes = {
    onNextButtonClick: PropTypes.func,
    width: PropTypes.string
};
export default withWidth()(HouseholdDocumentExpectations);
