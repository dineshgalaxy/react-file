import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 80px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: 0,
            alignItems: 'flex-start'
        }
    },

    title: {
        borderBottom: `2px solid ${theme.common.gray}`
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    },
    list: {
        position: 'relative',
        paddingLeft: theme.spacing(2),
        '&:before': {
            content: '""',
            width: '4px',
            height: '4px',
            background: theme.palette.primary.light,
            position: 'absolute',
            left: '0',
            top: '9px',
            borderRadius: '50%'
        }
    }
}));

export default useStyles;
