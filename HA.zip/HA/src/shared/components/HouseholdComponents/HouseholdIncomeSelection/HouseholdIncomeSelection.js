import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import useStyles from '../HouseholdComponentsStyles';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : HouseholdIncomeSelection
 * Desc : Render HouseholdIncomeSelection
 */

const HouseholdIncomeSelection = ({ title, width, onClickContinue }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={4.5}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                {title}
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box mb={.5}>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Full or part-time employment"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Self-employment"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Overtime, bonuses, tips, or commissions"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Social Security or SSDI"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={true}
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Supplemental Security Income (SSI)"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Child support (formal or informal)"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Pension plans, retirement plans, or annuities"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Military pay"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Unemployment or Worker’s Compensation"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Other help with expenses from someone outside the household"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="PHA income"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Welfare benefits like food stamps or TANF"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Imputed welfare income (reduced amount due to welfare fraud)"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="General assistance"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Alimony or spousal support"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Foster care payments"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Student financial assistance"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Medical reimbursements (for elderly or disabled only)"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Indian Trust/per capita"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="Other"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                    />
                                }
                                label="None of the above; there are no income sources for anyone in the household"
                            />
                        </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}
                        onClick={onClickContinue}
                    >
                        Next
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

HouseholdIncomeSelection.propTypes = {
    onClickContinue: PropTypes.func,
    title: PropTypes.string,
    width: PropTypes.string,
};

export default withWidth()(HouseholdIncomeSelection);
