import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    rootUpload: {
        '& > *': {
            margin: 0
        },
        '& .MuiButton-root': {
            [theme.breakpoints.down('sm')]: {
                width:'100%'
            }
        },
    },
    input: {
        display: 'none'
    },
    '.MuiButtonBase-root': {
        padding: 0
    },
    fullWidthBtn:{
        [theme.breakpoints.down('sm')]: {
            width:'100%'
        }
    }
}));

export default useStyles;