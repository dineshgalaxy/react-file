import { Box, Button, DialogContent, DialogTitle, IconButton } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import { Camera, Info } from 'react-feather';
import PropTypes from 'prop-types';
import React from 'react';
import Image from 'next/image';
import useStyles from './BirthCertificatePopupStyles';
import Indicators from '../../Indicators';

/**
 * Name: BirthCertificatePopup
 * Desc: Render BirthCertificatePopup
 */

const BirthCertificatePopup = ({ handleClose }) => {
    const classes = useStyles();
    return (
        <>
            <DialogTitle id="simple-dialog-title">
                <IconButton aria-label="close" onClick={handleClose}>
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <Box textAlign="center" px={2}>
                    <Box position="relative" display="inline-block">
                        <Image src="/birthdefaultImg.png" width={120} height={120} />
                        <Box position="absolute" bottom="-12px" right="-4px">
                            <input accept="image/*" className={classes.input} id="icon-button-file" type="file" />
                            <label htmlFor="icon-button-file">
                                <IconButton color="primary" aria-label="upload picture" component="span">
                                    <Indicators status="success" size={37} iconName="plus" iconSize={19} borderWidth={3.5}/>
                                </IconButton>
                            </label>
                        </Box>
                    </Box>
                    <Box color="primary.light" fontSize="h3.fontSize" fontFamily="fontFamily.bold" lineHeight="32px" pt={1} pb={2}>
                        Upload Birth Certificate for Firstname
                    </Box>
                    <Box color="primary.extraLight" fontSize="lg.fontSize" lineHeight="21px" pb={3}>
                        Use the buttons below to locate your document on your device, or use your phone’s camera to take a clear, legible photo scan of the document.
                    </Box>
                    <Box className={classes.rootUpload}>
                        <input
                            accept="image/*"
                            className={classes.input}
                            id="contained-button-file"
                            multiple
                            type="file"
                        />
                        <label htmlFor="contained-button-file">
                            <Button variant="contained" size="large" color="primary" component="span">
                                Browse File
                            </Button>
                        </label>
                    </Box>
                    <Box color="primary.extraLight" fontSize="lg.fontSize" py={2}>Or, you can:</Box>
                    <Box>
                        <Button 
                            variant="contained" 
                            size="large" 
                            color="secondary" 
                            className={classes.fullWidthBtn}
                            startIcon={<Camera color="Indigo" size={24} />}>
                                Use Camera
                        </Button>
                    </Box>
                </Box>
                <Box pt={6} display="inline-block" textAlign="left" mb={7}>
                    <Box display="flex" mb={1}>
                        <Box mr={1} mt={0.5} display="flex">
                            <Info color="Indigo" size={21} />
                        </Box>
                        <Box>
                            <Box
                                color="primary.light"
                                fontSize="h5.fontSize"
                                fontFamily="fontFamily.medium"
                                lineHeight="28px">
                                Help Uploading Documents
                            </Box>
                            <Box color="primary.extraLight" fontSize="md.fontSize" pt={1}>
                                Optional helper text from HACEP
                            </Box>
                        </Box>
                    </Box>
                    
                </Box>
            </DialogContent>
        </>
    );
}
BirthCertificatePopup.propTypes = {
    handleClose: PropTypes.func
};
export default BirthCertificatePopup
