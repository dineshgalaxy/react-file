import { Box,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    TextField } from '@material-ui/core';
import useStyles from '../HouseholdComponentsStyles';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : MedicalExpenses
 * Desc : Render MedicalExpenses
 */

const MedicalExpenses = ({ width, title, showFaceBookLoginButton, onClickContinue }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={4}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                {title}
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                    To which member of the household does this expense belong?
                </Box>
                <Box pb={3}>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Person*</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label={
                                <Box display="flex" alignItems="center">
                                    Select Person<Box color="primary.main">*</Box>
                                </Box>}
                            >
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Expense Type*</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label={
                                <Box display="flex" alignItems="center">
                                    Select Expense Type<Box color="primary.main">*</Box>
                                </Box>}
                            >
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="jobTitle"
                            multiline
                            rows={4}
                            label={
                                <Box display="flex" alignItems="center">
                                    Description of expense<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="jobTitle"
                            label={
                                <Box display="flex" alignItems="center">
                                    Expense payment amount<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Payment frequency*</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label={
                                <Box display="flex" alignItems="center">
                                    Payment frequency<Box color="primary.main">*</Box>
                                </Box>}
                            >
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(
                            width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                            showFaceBookLoginButton && 'facebooKBtn'
                        )}
                        onClick={(!showFaceBookLoginButton && onClickContinue) || null}
                    >
                        {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

MedicalExpenses.defaultProps = {
    title: '',
    showFaceBookLoginButton: false
};

MedicalExpenses.propTypes = {
    title: PropTypes.string,
    width: PropTypes.string,
    showFaceBookLoginButton: PropTypes.bool,
    onClickContinue: PropTypes.func,
};
export default withWidth()(MedicalExpenses);
