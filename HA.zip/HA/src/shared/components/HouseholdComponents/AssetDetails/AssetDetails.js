import { Box,
    Button,
    RadioGroup,
    Radio,
    FormControl,
    FormControlLabel,
    InputLabel,
    MenuItem,
    Select,
    TextField } from '@material-ui/core';
import useStyles from '../HouseholdComponentsStyles';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : AssetDetails
 * Desc : Render AssetDetails
 */

const AssetDetails = ({ width, title, showFaceBookLoginButton, onClickContinue }) => {
    const classes = useStyles();
    const isFull = width === 'xs' || width === 'sm';
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={4}
                maxWidth={ isFull ? '100%' : 337}>
                {title}
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                    To which member of the household does this asset belong?*
                </Box>
                <FormControl variant="filled" fullWidth>
                    <InputLabel id="demo-simple-select-label">Select person</InputLabel>
                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        label="Select person">
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                    </Select>
                </FormControl>
                <FormControl variant="filled" fullWidth>
                    <InputLabel id="demo-simple-select-label">Type of Account*</InputLabel>
                    <Select
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        label={
                            <Box display="flex" alignItems="center">
                                Type of Account<Box color="primary.main">*</Box>
                            </Box>}
                        >
                        <MenuItem value={10}>Ten</MenuItem>
                        <MenuItem value={20}>Twenty</MenuItem>
                        <MenuItem value={30}>Thirty</MenuItem>
                    </Select>
                </FormControl>
                <FormControl fullWidth>
                    <TextField
                        id="jobTitle"
                        label={
                            <Box display="flex" alignItems="center">
                                Name of Financial Institution<Box color="primary.main">*</Box>
                            </Box>
                        }
                        variant="filled"
                    />
                </FormControl>
                <FormControl fullWidth>
                    <TextField
                        id="jobTitle"
                        label={
                            <Box display="flex" alignItems="center">
                                Value of Account <Box color="primary.main">*</Box>
                            </Box>
                        }
                        variant="filled"
                    />
                </FormControl>
                <Box mt={3} mb={1.5} color="primary.light" fontSize="h6.fontSize">
                    Does this account earn interest?*
                </Box>
                <FormControl component="fieldset">
                    <RadioGroup defaultValue="female" aria-label="proxy" name="customized-radios">
                        <Box mb={2}>
                            <FormControlLabel 
                                value="true" 
                                control={<Radio className="extraLightLabel"/>} 
                                label="Yes" 
                            />
                        </Box>
                        <FormControlLabel 
                            value="false" 
                            control={<Radio className="extraLightLabel"/>} 
                            label="No" 
                        />
                    </RadioGroup>
                </FormControl>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={ isFull ? true : false}
                        className={clsx(
                            isFull ? 'semiBorder' : '',
                            showFaceBookLoginButton && 'facebooKBtn'
                        )}
                        onClick={(!showFaceBookLoginButton && onClickContinue) || null}
                    >
                        {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}
AssetDetails.defaultProps = {
    title: '',
    showFaceBookLoginButton: false
};

AssetDetails.propTypes = {
    onClickContinue: PropTypes.func,
    title: PropTypes.string,
    width: PropTypes.string,
    showFaceBookLoginButton: PropTypes.bool,
};
export default withWidth()(AssetDetails);
