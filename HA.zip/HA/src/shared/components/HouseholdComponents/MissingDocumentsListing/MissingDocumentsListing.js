import { Box, Button, Grid } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../HouseholdComponentsStyles';

/**
 * Name : MissingDocumentsListing
 * Desc : Render MissingDocumentsListing
 */

const MissingDocumentsListing = ({ width, title, onClickContinue }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box
                fontSize="h5.fontSize"
                lineHeight="35px"
                color="primary.light"
                mb={6.75}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                {title}
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Grid container spacing={3}>
                    <Grid item xs={12} md={12}>
                        <Box mb={7}>
                            <Box
                                mx={-3}
                                mb={2}
                                px={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Identity Documents (1)
                                </Box>
                            </Box>
                            <Box color="primary.light" className={classes.list} fontSize="lg.fontSize" mb={1}>
                                Social Security Card, Driver’s License, or Birth Certificate for [Firstname]
                            </Box>
                        </Box>
                        <Box mb={7}>
                            <Box
                                mx={-3}
                                mb={2}
                                px={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Income Documents (3)
                                </Box>
                            </Box>
                            <Box color="primary.light" className={classes.list} fontSize="lg.fontSize" mb={1}>
                                3 most recent paystubs for Firstname’s employment income
                            </Box>
                        </Box>
                        <Box mb={7}>
                            <Box
                                mx={-3}
                                mb={2}
                                px={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Expense Documents (1)
                                </Box>
                            </Box>
                            <Box color="primary.light" className={classes.list} fontSize="lg.fontSize" mb={1}>
                                [document name] for [type of expense]
                            </Box>
                        </Box>
                        <Box mb={2}>
                            <Box
                                mx={-3}
                                mb={2}
                                px={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Asset Documents (1)
                                </Box>
                            </Box>
                            <Box color="primary.light" className={classes.list} fontSize="lg.fontSize" mb={1}>
                                [document name] for [type of asset]
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}
                        onClick={onClickContinue}>
                        Start Uploading Documents
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

MissingDocumentsListing.propTypes = {
    onClickContinue: PropTypes.func,
    width: PropTypes.string,
    title: PropTypes.string
};

export default withWidth()(MissingDocumentsListing);

