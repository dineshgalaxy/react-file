import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 96px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: '0 0 38px 0',
            alignItems: 'flex-start'
        }
    },
    formWidth: {
        maxWidth: '310px',
        [theme.breakpoints.down('sm')]: {
            maxWidth: '100%'
        }
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    },
    title: {
        borderBottom: '2px solid #F5F5F9'
    },
    list: {
        position: 'relative',
        paddingLeft: theme.spacing(2),
        '&:before': {
            content: '""',
            width: '4px',
            height: '4px',
            background: theme.palette.primary.light,
            position: 'absolute',
            left: '0',
            top: '8px',
            borderRadius: '50%'
        }
    }
}))

export default useStyles;