import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from './ReviewPoliciesStyles';

/**
 * Name : ReviewPolicies
 * Desc : Render ReviewPolicies
 */

const ReviewPolicies = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%">
                <Box mb={2}>
                    <Box mx={-3} px={3}>
                        <Box color="primary.light" fontSize="lg.fontSize" py={2.5}>
                            <Box fontFamily="fontFamily.medium">HUD VAWA Form 5380</Box>
                             <Box py={.75}>Short, plain language description for what this document is</Box>
                            <Box
                                display="flex"
                                alignItems="center"
                                className={classes.actionBtnWrapper}>
                                <Button size="medium" className="linkBtn">
                                    View
                                </Button>
                                <Button size="medium" className="linkBtn">
                                    Download
                                </Button>
                            </Box>
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" py={2.5}>
                            <Box fontFamily="fontFamily.medium">[Fraud Document]</Box>
                             <Box py={.75}>Short, plain language description for what this document is</Box>
                            <Box
                                display="flex"
                                alignItems="center"
                                className={classes.actionBtnWrapper}>
                                <Button size="medium" className="linkBtn">
                                    View
                                </Button>
                                <Button size="medium" className="linkBtn">
                                    Download
                                </Button>
                            </Box>
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" py={2.5}>
                            <Box fontFamily="fontFamily.medium">Section 214 Document</Box>
                             <Box py={.75}>Short, plain language description for what this document is</Box>
                            <Box
                                display="flex"
                                alignItems="center"
                                className={classes.actionBtnWrapper}>
                                <Button size="medium" className="linkBtn">
                                    View
                                </Button>
                                <Button size="medium" className="linkBtn">
                                    Download
                                </Button>
                            </Box>
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" py={2.5}>
                            <Box fontFamily="fontFamily.medium">One Strike Policy </Box>
                             <Box py={.75}>Short, plain language description for what this document is</Box>
                            <Box
                                display="flex"
                                alignItems="center"
                                className={classes.actionBtnWrapper}>
                                <Button size="medium" className="linkBtn">
                                    View
                                </Button>
                                <Button size="medium" className="linkBtn">
                                    Download
                                </Button>
                            </Box>
                        </Box>
                    </Box>
                </Box>
                <Box mt={3} mb={8}>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    className="extraLightLabel"
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label={
                                <Box color="primary.extraLight" fontSize="h6.fontSize" mb={2}>
                                    I have read and accept the above terms and conditions
                                </Box>
                            }
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Submit
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

ReviewPolicies.propTypes = {
    width: PropTypes.string
};
export default withWidth()(ReviewPolicies);

