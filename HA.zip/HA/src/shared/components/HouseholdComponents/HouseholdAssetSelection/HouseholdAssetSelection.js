import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../HouseholdComponentsStyles';

/**
 * Name : HouseholdAssetSelection
 * Desc : Render HouseholdAssetSelection
 */

const HouseholdAssetSelection = ({ width, onClickContinue }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box
                fontSize="h5.fontSize"
                lineHeight="35px"
                color="primary.light"
                mb={5.5}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                Select all the assets owned or held by anyone in the household, including yourself.*
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Checking, savings, or money market accounts"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Cetificates of deposit (CDs), mutual funds, or treasury bills"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Cash not in the bank"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Stocks, bonds, securities, or trust funds"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Real estate, land contracts, or other capital investments"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Annuities, whole or universal life insurance policies"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Personal property held as an investment"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Individual retirement account, 401(k), 403(b), or other retirement accounts"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="None of the above"
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}
                        onClick={onClickContinue}
                    >
                        Next
                    </Button>
                </Box>
            </Box>
        </Box>
    );
};
HouseholdAssetSelection.propTypes = {
    width: PropTypes.string,
    onClickContinue: PropTypes.func
};
export default withWidth()(HouseholdAssetSelection);
