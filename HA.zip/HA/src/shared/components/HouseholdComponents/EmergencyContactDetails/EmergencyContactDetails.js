import { Box,
    Button,
    Checkbox,
    FormControl,
    FormControlLabel,
    InputLabel,
    MenuItem,
    Select,
    TextField } from '@material-ui/core';
import useStyles from '../HouseholdComponentsStyles';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : EmergencyContactDetails
 * Desc : Render EmergencyContactDetails
 */

const EmergencyContactDetails = ({ width, title, showFaceBookLoginButton, onNextButtonClick }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={4}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                {title}
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label={
                                <Box display="flex" alignItems="center">
                                    Contact’s First and Last Name<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Relationship to Applicant*</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label={
                                <Box display="flex" alignItems="center">
                                    Relationship to Applicant<Box color="primary.main">*</Box>
                                </Box>
                            }>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label={
                                <Box display="flex" alignItems="center">
                                    Email Address<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="TelephoneNumber"
                            label={
                                <Box display="flex" alignItems="center">
                                    Telephone Number<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="currentAddress"
                            label="Current Address"
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="currentAddress2"
                            label="Current Address Line 2"
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="city"
                            label="City"
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">State</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="State">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="zipCode"
                            label="Zip Code"
                            variant="filled"
                        />
                    </FormControl>
                    <Box mt={4.5} mb={3} color="primary.light" fontSize="h5.fontSize" lineHeight="35px">
                        Under which circumstances may we contact this person?*
                    </Box>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="For any reason (check all)"
                        />
                    </FormControl>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Emergencies"
                        />
                    </FormControl>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Unable to contact you"
                        />
                    </FormControl>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Termination of rental assistance"
                        />
                    </FormControl>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Eviction from unit"
                        />
                    </FormControl>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Late payment of rent"
                        />
                    </FormControl>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="To assist with recertification process"
                        />
                    </FormControl>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Change in lease terms"
                        />
                    </FormControl>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Change in house rules"
                        />
                    </FormControl>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Other"
                        />
                    </FormControl>
                </Box>   
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(
                            width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                            showFaceBookLoginButton && 'facebooKBtn'
                        )}
                        onClick={onNextButtonClick}
                    >
                        {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

EmergencyContactDetails.defaultProps = {
    title: '',
    showFaceBookLoginButton: false
};

EmergencyContactDetails.propTypes = {
    onNextButtonClick: PropTypes.func,
    title: PropTypes.string,
    width: PropTypes.string,
    showFaceBookLoginButton: PropTypes.bool,
};

export default withWidth()(EmergencyContactDetails);
