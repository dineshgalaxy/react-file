import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    rootUpload: {
        '& > *': {
            margin: 0
        },
        '& .MuiButton-root': {
            fontSize:"12px",
            padding:"8px 21px"
        },
    },
    input: {
        display: 'none'
    },
    '.MuiButtonBase-root': {
        padding: 0
    },
    border:{
        borderTop:`2px solid ${theme.palette.secondary.extraLight}`,
        padding:'16px 24px'
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    },
    checkboxFontsize:{
        '& .MuiFormControlLabel-root':{
            marginRight:'0'
        },
        '& .MuiFormControlLabel-label':{
            paddingLeft:'0',
            fontSize:"15px"
        }
    }
}));

export default useStyles;