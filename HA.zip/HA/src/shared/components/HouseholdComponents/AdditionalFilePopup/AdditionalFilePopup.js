import { Box, Button, DialogContent, DialogTitle, IconButton, Link, FormControl, FormControlLabel, Checkbox } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import { Trash2 } from 'react-feather';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from './AdditionalFilePopupStyles';

/**
 * Name: AdditionalFilePopup
 * Desc: Render AdditionalFilePopup
 */

const AdditionalFilePopup = ({ handleClose }) => {
    const classes = useStyles();
    return (
        <>
            <DialogTitle id="simple-dialog-title">
                <IconButton aria-label="close" onClick={handleClose}>
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <Box textAlign="center" px={2}>
                    <Box color="primary.light" fontSize="h3.fontSize" fontFamily="fontFamily.bold" lineHeight="32px" pt={1} pb={2}>
                        Review and Save Your File
                    </Box>
                    <Box color="primary.extraLight" fontSize="lg.fontSize" lineHeight="21px" pb={3}>
                        Review the file(s) below and make sure your upload is clear and legible. Add any additional files or images needed to complete your upload.
                    </Box>
                </Box>
                <Box pb={10}>
                    <Box display="flex" alignItems="center" mx={-3} className={classes.border}>
                        <Box
                            width={48}
                            height={48}
                            bgcolor="#C4C4C4"
                            borderRadius={9}
                            overflow="hidden">
                            
                        </Box>
                        <Box
                            flexGrow={2}
                            px={1.5}
                            display="flex"
                            flexDirection="column"
                            justifyContent="center">
                            <Box color="primary.light" fontSize="md.fontSize" fontFamily="fontFamily.medium">
                                File-name.pdf
                            </Box>
                            <Box component="body1" color="button.secondaryColor" fontSize="sm.fontSize">
                                <Link href="#">
                                    View File
                                </Link>
                            </Box>
                        </Box>
                        <Box p={0.25} display="flex" justifyContent="center" alignItems="center">
                            <IconButton>
                                <Trash2 stroke-width="1.5" color="Indigo" size={16} />
                            </IconButton>
                        </Box>
                    </Box>
                    <Box display="flex" alignItems="center" mx={-3} className={classes.border}>
                        <Box
                            width={48}
                            height={48}
                            bgcolor="#C4C4C4"
                            borderRadius={9}
                            overflow="hidden">
                            
                        </Box>
                        <Box
                            flexGrow={2}
                            px={1.5}
                            display="flex"
                            flexDirection="column"
                            justifyContent="center">
                            <Box color="primary.light" fontSize="md.fontSize" fontFamily="fontFamily.medium">
                                File-name-123345.jpg
                            </Box>
                            <Box component="body1" color="button.secondaryColor" fontSize="sm.fontSize">
                                <Link href="#">
                                    View File
                                </Link>
                            </Box>
                        </Box>
                        <Box p={0.25} display="flex" justifyContent="center" alignItems="center">
                            <IconButton>
                                <Trash2 stroke-width="1.5" color="Indigo" size={16} />
                            </IconButton>
                        </Box>
                    </Box>
                    <Box className={classes.rootUpload} mt={2.5} mb={5}>
                        <input
                            accept="image/*"
                            className={classes.input}
                            id="contained-button-file"
                            multiple
                            type="file"
                        />
                        <label htmlFor="contained-button-file">
                            <Button variant="contained" size="medium" color="primary" component="span">
                                Add Another File
                            </Button>
                        </label>
                    </Box>
                    <Box className={classes.checkboxFontsize}>
                        <FormControl fullWidth className="noMargin">
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        inputProps={{ 'aria-label': 'primary checkbox' }}
                                        className="extraLightLabel"
                                    />
                                }
                                label="These files are clear and legible"
                            />
                        </FormControl>
                    </Box>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="secondary"
                        variant="contained"
                        fullWidth={true}
                        className="semiBorder">
                        Save File(s)
                    </Button>
                </Box>
            </DialogContent>
        </>
    )
}

AdditionalFilePopup.propTypes = {
    handleClose: PropTypes.func,
};

export default AdditionalFilePopup;
