import { Box, Button, Container, IconButton } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';
import { ArrowLeft, ChevronLeft } from 'react-feather';
import useStyles from './WizardHeaderStyles';
/**
 * Name : WizardHeader
 * Desc : Render WizardHeader
 */

const WizardHeader = ({ onClickBack, title, children = null }) => {
    const classes = useStyles();

    return (
        <Box bgcolor="primary.main" className={classes.WizardHeaderWrapper}>
            <Container>
                <Box
                    display="flex"
                    alignItems="center"
                    className={classes.deviceHeader}
                    position="relative"
                    zIndex={1}>
                    <IconButton className={classes.menuButton} onClick={onClickBack}>
                        <ChevronLeft color="Indigo" size={26} className={classes.visibleDesktop} />
                        <ArrowLeft
                            color="Indigo"
                            size={20}
                            strokeWidth={3}
                            className={classes.visibleXs}
                        />
                    </IconButton>
                    <Box
                        fontSize="h3.fontSize"
                        color="common.white"
                        fontFamily="fontFamily.bold"
                        ml={3}
                    >
                        {title}
                    </Box>
                </Box>
                {children ? (
                    <Box
                        display="flex"
                        alignItems="center"
                        justifyContent="center"
                        width="100%"
                        position="relative"
                        zIndex={1}
                        className={classes.xsMargin}>
                        {children}
                    </Box>
                ) : (
                    <Box
                        className={classes.WizardHeaBox}
                        display="flex"
                        alignItems="center"
                        flexWrap="wrap"
                        position="relative"
                        zIndex={1}>
                        {[
                            { text: 'Continue' },
                            { text: 'Continue' },
                            { text: 'Continue' },
                            { text: 'Continue' },
                            { text: 'Continue' },
                            { text: 'Continue' }
                        ].map((item, index) => (
                            <Button className={classes.links} key={`${item.text}_${index}`}>
                                <Box
                                    fontSize="h5.fontSize"
                                    color="common.white"
                                    fontFamily="fontFamily.regular">
                                    {item.text}
                                </Box>
                            </Button>
                        ))}
                    </Box>
                )}
            </Container>
        </Box>
    );
};
WizardHeader.propTypes = {
    onClickBack: PropTypes.func,
    children: PropTypes.any,
    title: PropTypes.string
};
export default withWidth()(WizardHeader);
