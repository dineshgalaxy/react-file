export { default } from './WizardHeader';
