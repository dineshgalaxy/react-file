import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    WizardHeaderWrapper: {
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        borderBottomLeftRadius: theme.spacing(3),
        borderBottomRightRadius: theme.spacing(3),
        padding: '24px 0',
        position: 'relative',
        backgroundImage: `url('/splashMobile.svg')`,

        [theme.breakpoints.up('sm')]: {
            '&:after': {
                position: 'absolute',
                top: '0',
                left: '0',
                right: '0',
                width: '100%',
                content: '""',
                backgroundImage: `url('/splash.svg')`,
                minHeight: '461px',
                borderBottomLeftRadius: theme.spacing(3),
                borderBottomRightRadius: theme.spacing(3),
                backgroundPosition: 'center',
                backgroundSize: 'cover'
            }
        },
        [theme.breakpoints.down('xs')]: {
            minHeight: '155px'
        }
    },
    WizardHeaBox: {
        [theme.breakpoints.down('xs')]: {
            display: 'none'
        }
    },

    links: {
        '&:hover': {
            '& > div': {
                color: theme.palette.success.light
            }
        },
        [theme.breakpoints.down('md')]: {
            margin: `0 8px`
        }
    },
    menuButton: {
        backgroundColor: theme.common.white,
        '&:hover': {
            backgroundColor: theme.common.white,
            opacity: '0.5'
        }
    },
    deviceHeader: {
        [theme.breakpoints.up('sm')]: {
            display: 'none'
        }
    },
    xsMargin:{
        [theme.breakpoints.down('xs')]: {
            padding:'0 8px 56px'
        }
    },
    visibleDesktop: {
        display: 'none',
        [theme.breakpoints.up('sm')]: {
            display: 'block'
        }
    },
    visibleXs: {
        display: 'none',
        [theme.breakpoints.down('xs')]: {
            display: 'block'
        }
    },
}));

export default useStyles;
