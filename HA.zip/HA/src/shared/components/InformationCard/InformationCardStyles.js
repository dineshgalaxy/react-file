import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 80px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: '0'
        }
    },
    imgWidth: {
        '& .MuiAvatar-root': {
            width: '337px',
            height: ' 302px',
            [theme.breakpoints.down('sm')]: {
                width: '297px',
                height: '266px'
            }
        }
    },
    xsBtnCenter: {
        [theme.breakpoints.down('sm')]: {
            textAlign: 'center'
        }
    },
    boxInfo: {
        position: 'relative',
        paddingLeft: theme.spacing(2),
        paddingBottom: theme.spacing(0.4),
        '&:before': {
            content: '""',
            width: '4px',
            height: '4px',
            background: theme.palette.primary.extraLight,
            position: 'absolute',
            left: '0',
            top: '10px',
            borderRadius: '50%'
        }
    },
    lgLeftxsCenter:{
        textAlign:'left',
        [theme.breakpoints.down('sm')]: {
            textAlign: 'center'
        }
    },
    left:{
        textAlign:'left'
    },
    center:{
        textAlign:'center'
    }
}));

export default useStyles;
