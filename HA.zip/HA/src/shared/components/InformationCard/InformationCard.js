import { Avatar, Box, Button } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from './InformationCardStyles';
/**
 * Name: MemberCard
 * Desc: Render MemberCard
 */

const InformationCard = ({
    width,
    title,
    onClickContinue,
    content,
    showImage,
    btnTitle,
    textAlign
}) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                className={classes[textAlign]}>
                {showImage && (
                    <Box display="flex" justifyContent="center" className={classes.imgWidth}>
                        <Avatar src="/household.png" variant="square" />
                    </Box>
                )}
                <Box
                    fontSize="h2.fontSize"
                    lineHeight="40px"
                    color="primary.light"
                    fontFamily="fontFamily.bold"
                    mb={2.5}>
                    {title}
                </Box>
            </Box>
            <Box
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 'unset'}
                pl={width === 'xs' || width === 'sm' ? '0' : '50px'}>
                <Box className={classes[textAlign]}>{content && content}</Box>
                <Box mt={width === 'xs' || width === 'sm' ? 5 : 4} className={classes.xsBtnCenter}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        onClick={onClickContinue}>
                        {btnTitle}
                    </Button>
                </Box>
            </Box>
        </Box>
    );
};

InformationCard.defaultProps = {
    title: '',
    content: '',
    showImage: true,
    textAlign: 'center',
    btnTitle: 'Continue'
};

InformationCard.propTypes = {
    title: PropTypes.string,
    content: PropTypes.node,
    onClickContinue: PropTypes.func,
    showImage: PropTypes.bool,
    textAlign: PropTypes.oneOf(['center', 'left', 'lgLeftxsCenter']),
    btnTitle: PropTypes.string,
    width: PropTypes.string
};

export default withWidth()(InformationCard);
