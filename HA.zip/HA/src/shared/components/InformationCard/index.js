export { default } from './InformationCard';
