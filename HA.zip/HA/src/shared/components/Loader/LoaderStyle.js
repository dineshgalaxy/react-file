import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(() => ({
    backdrop: {
        zIndex: 9999
    }
}));
export default useStyles;
