import Backdrop from '@material-ui/core/Backdrop';
import CircularProgress from '@material-ui/core/CircularProgress';
import PropTypes from 'prop-types';
import useStyles from './LoaderStyle';

/**
 * Name: Loader
 * Desc: show loader
 */
const Loader = ({ loading }) => {
    const classes = useStyles();

    return (
        <Backdrop className={classes.backdrop} open={loading}>
            <CircularProgress color="inherit" />
        </Backdrop>
    );
};
Loader.defaultProps = {
    loading: false
};
Loader.propTypes = {
    loading: PropTypes.bool
};

export default Loader;
