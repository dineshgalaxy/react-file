import { FIELDS } from './LoginFormConstants';
export const onValidate = (values) => {
    const errors = {};
    if (!values[FIELDS?.EMAIL]) {
        errors[FIELDS?.EMAIL] = 'Please enter your email.';
    } else if (values[FIELDS?.EMAIL] && !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(String(values[FIELDS?.EMAIL]).toLocaleLowerCase())) {
        errors[FIELDS?.EMAIL] = 'Please enter valid email.';
    } 
    if (!values[FIELDS?.PASSWORD]) {
        errors[FIELDS?.PASSWORD] = 'Please enter password.';
    }
    return errors;
};
