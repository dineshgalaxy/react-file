import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',

        [theme.breakpoints.up('md')]: {
            backgroundColor: theme.palette.secondary.light
        },
        [theme.breakpoints.down('sm')]: {
            padding: '30px 15px'
        },
        '& .MuiButton-endIcon':{
            marginLeft:'2px'
        },
    },
    button:{
        fontSize:'17px'
    },
    mobileButton:{
        fontSize:'13px',
        fontFamily: 'Poppins-Medium',
    },
    textAlign: {
        textAlign: 'center',
        backgroundColor: theme.common.white,
        padding: '45px 0',

        [theme.breakpoints.down('sm')]: {
            padding: '8px 0 80px'
        }
    },

    imgWidth: {
        '& .MuiAvatar-root': {
            width: '366px',
            height: ' 316px',
            [theme.breakpoints.down('sm')]: {
                width: '177px',
                height: '153px'
            }
        }
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    },
    forgetBtn: {
        "& .MuiButtonBase-root":{
            fontSize:"13px",
            fontFamily:"Poppins-Medium",
        },
        [theme.breakpoints.down('sm')]: {
            padding: '10px 0 24px'
        }
    },
    xsHidden: {
        [theme.breakpoints.down('sm')]: {
            display: 'none'
        }
    },
    xsShow: {
        [theme.breakpoints.up('md')]: {
            display: 'none'
        }
    }
}));

export default useStyles;
