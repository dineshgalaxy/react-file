import {
    Avatar,
    Box,
    Button,
    Card,
    Container,
    FormControl,
    Grid,
    TextField
} from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import FeatherIcon from 'feather-icons-react';
import Router from 'next/router';
import PropTypes from 'prop-types';
import React from 'react';
import FormErrorMessage from '~/shared/components/FormErrorMessage';
import { ROUTES } from '~/shared/constants/routesConstants';
import useForm from '~/shared/customHooks/useForm';
import { FIELDS } from './LoginFormConstants';
import useStyles from './LoginFormStyles';
import { onValidate } from './LoginFormUtils';

/**
 * Name: LoginForm
 * Desc: Render LoginForm
 */

const LoginForm = ({
    title,
    subTitle,
    forgotPasswordText,
    showLoginWithFacebook,
    onClickContinue,
    onClickSignUP,
    width
}) => {
    const classes = useStyles();
    const initialValue = {
        [FIELDS.EMAIL]: '',
        [FIELDS.PASSWORD]: ''
    };
    const { values, handleOnChange, handleBlur, handleSubmit, errors } = useForm(
        initialValue,
        onValidate
    );
    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);

        if (Object.keys(submittedError).length === 0 && submitted) {
            onClickContinue(values);
        }
    };

    const continueWithSignUP = () => {
        const { CHECK_ELIGIBILITY } = ROUTES;
        Router.push(CHECK_ELIGIBILITY?.ROUTE);
    };

    return (
        <Container>
            <Card className={classes.root}>
                <Grid container alignItems="center">
                    <Grid item xs={12} md={6}>
                        <Box display="flex" justifyContent="center" className={classes.imgWidth}>
                            <Avatar src="/Illo.svg" variant="square" />
                        </Box>
                        <Box className={classes.xsHidden}>
                            <Box
                                color="primary.extraLight"
                                fontSize="h6.fontSize"
                                textAlign="center"
                                mt={3}>
                                Don’t have an account yet?
                            </Box>
                            <Box textAlign="center">
                                <Button
                                    onClick={onClickSignUP}
                                    color="primary"
                                    className={classes.button}
                                    endIcon={
                                        <FeatherIcon
                                            strokeWidth="3"
                                            icon="chevron-right"
                                            size="15px"
                                        />
                                    }>
                                    Get Started
                                </Button>
                            </Box>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={6} className={classes.textAlign}>
                        <Box maxWidth="370px" margin="0 auto">
                            <Box
                                fontSize={
                                    width === 'xs' || width === 'sm' ? 'h2.fontSize' : 'h1.fontSize'
                                }
                                color={
                                    width === 'xs' || width === 'sm'
                                        ? 'common.black'
                                        : 'primary.light'
                                }
                                fontFamily="fontFamily.bold"
                                mb={1}>
                                {title}
                            </Box>
                            <Box fontSize="lg.fontSize" color="primary.extraLight">
                                {subTitle}
                            </Box>

                            <Box className={classes.forgetBtn}>
                                <Button
                                    color="primary"
                                    size="small"
                                    endIcon={
                                        <FeatherIcon
                                            strokeWidth="3"
                                            icon="chevron-right"
                                            size="13px"
                                        />
                                    }>
                                    {forgotPasswordText}
                                </Button>
                            </Box>
                            <form onSubmit={(e) => handleFormSubmit(e)}>
                                <Box textAlign="left" mt={1}>
                                    <form noValidate autoComplete="off">
                                        <FormControl fullWidth>
                                            <TextField
                                                name={FIELDS?.EMAIL}
                                                onChange={handleOnChange}
                                                onBlur={handleBlur}
                                                label="email address"
                                                variant="filled"
                                                error={errors[FIELDS?.EMAIL]}
                                                helperText={
                                                    errors[FIELDS?.EMAIL] ? (
                                                        <FormErrorMessage
                                                            title={errors[FIELDS?.EMAIL]}
                                                        />
                                                    ) : null
                                                }
                                            />
                                        </FormControl>

                                        <FormControl fullWidth>
                                            <TextField
                                                name={FIELDS?.PASSWORD}
                                                onChange={handleOnChange}
                                                onBlur={handleBlur}
                                                label="password"
                                                type="password"
                                                variant="filled"
                                                error={errors[FIELDS?.PASSWORD]}
                                                helperText={
                                                    errors[FIELDS?.PASSWORD] ? (
                                                        <FormErrorMessage
                                                            title={errors[FIELDS?.PASSWORD]}
                                                        />
                                                    ) : null
                                                }
                                            />
                                        </FormControl>
                                    </form>
                                </Box>

                                <Box>
                                    <Button
                                        type="submit"
                                        size="large"
                                        color="primary"
                                        variant="contained"
                                        fullWidth={true}>
                                        Log In with Password
                                    </Button>
                                </Box>
                            </form>

                            {showLoginWithFacebook && (
                                <>
                                    <Box
                                        color="primary.extraLight"
                                        fontSize="lg.fontSize"
                                        mt={width === 'xs' || width === 'sm' ? 3.75 : 2}
                                        mb={width === 'xs' || width === 'sm' ? -2 : 2}>
                                        Or, you can:
                                    </Box>
                                    <Box className={classes.xsBtn}>
                                        <Button
                                            size="large"
                                            color="primary"
                                            variant="contained"
                                            className={
                                                width === 'xs' || width === 'sm'
                                                    ? 'semiBorder facebooKBtn'
                                                    : 'facebooKBtn'
                                            }
                                            fullWidth={true}>
                                            Log In with Facebook
                                        </Button>
                                    </Box>
                                </>
                            )}
                        </Box>
                    </Grid>
                </Grid>
            </Card>

            <Box className={classes.xsShow}>
                <Box
                    color="primary.extraLight"
                    fontSize="lg.fontSize"
                    textAlign="center"
                    mt={5.25}
                    mb={2}>
                    Are you a first time user without an account? Click below to start the process.
                </Box>
                <Box textAlign="center">
                    <Button
                        onClick={() => continueWithSignUP()}
                        color="primary"
                        className={classes.mobileButton}
                        endIcon={<FeatherIcon icon="chevron-right" size="13px" strokeWidth="3" />}>
                        Get Started
                    </Button>
                </Box>
            </Box>
        </Container>
    );
};

LoginForm.defaultProps = {
    title: '',
    subTitle: '',
    forgotPasswordText: ''
};

LoginForm.propTypes = {
    title: PropTypes.string,
    subTitle: PropTypes.string,
    forgotPasswordText: PropTypes.string,
    showLoginWithFacebook: PropTypes.bool,
    onClickContinue: PropTypes.func,
    onClickSignUP: PropTypes.func,
    width: PropTypes.string
};

export default withWidth()(LoginForm);
