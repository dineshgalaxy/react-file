export const FIELDS = {
    EMAIL : 'email',
    PASSWORD : 'password'
};
