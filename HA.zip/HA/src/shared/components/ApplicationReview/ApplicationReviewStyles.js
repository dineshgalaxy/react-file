import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 96px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: '0 0 48px 0',
            alignItems: 'flex-start'
        }
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    },
    textAlign: {
        [theme.breakpoints.down('sm')]: {
            maxWidth: '100%'
        }
    },
    title: {
        borderBottom: '2px solid white'
    },
    list: {
        position: 'relative',
        paddingLeft: theme.spacing(3),
        '&:before': {
            content: '""',
            width: '6px',
            height: '6px',
            background: theme.palette.primary.light,
            position: 'absolute',
            left: '0',
            top: '7px',
            borderRadius: '50%'
        }
    }
}));

export default useStyles;
