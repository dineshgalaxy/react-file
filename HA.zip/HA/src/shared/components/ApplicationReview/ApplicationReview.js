import { Box, Button, Grid, IconButton } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { Edit } from 'react-feather';
import { noop } from '~/shared/utils/utils';
import useStyles from './ApplicationReviewStyles';

/**
 * Name : ApplicationReview
 * Desc : Render ApplicationReview
 */

const ApplicationReview = ({
    onNextButtonClick,
    width,
    applicantDetail,
    otherDetails,
    memberDetails,
    buttonText,
    onEditMember,
    onEditAccessibility,
    onEditShelter,
    onEditMilitary,
    onEditMiseDetail
}) => {
    const classes = useStyles();
    const getStatus = (value) => {
        return value ? 'Yes' : 'No';
    };
    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%">
                <Grid container spacing={3}>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                ml={-3}
                                mr={-3}
                                mb={2}
                                pl={3}
                                pr={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Personal Details
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={21} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>

                            <Box
                                color="primary.light"
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.medium"
                                mb={1}>
                                {`${applicantDetail?.fname || ''} ${applicantDetail?.lname || ''}`}
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                {`${applicantDetail?.address_1 || ''} ${
                                    applicantDetail?.address_2 || ''
                                }`}
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                {`${applicantDetail?.cellphone || ''}`}
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                {`${applicantDetail?.email || ''}`}
                            </Box>
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                ml={-3}
                                mr={-3}
                                mb={2}
                                pl={3}
                                pr={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    color="primary.light">
                                    Selected Programs
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={21} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            <Box
                                color="primary.light"
                                fontSize="lg.fontSize"
                                mb={1}
                                className={classes.list}>
                                Housing Choice
                            </Box>
                            <Box
                                color="primary.light"
                                fontSize="lg.fontSize"
                                mb={1}
                                className={classes.list}>
                                Voucher Eisenhower (1BR)
                            </Box>
                            <Box
                                color="primary.light"
                                fontSize="lg.fontSize"
                                mb={1}
                                className={classes.list}>
                                Eisenhower (2BR)
                            </Box>
                            <Box
                                color="primary.light"
                                fontSize="lg.fontSize"
                                mb={1}
                                className={classes.list}>
                                Krupp (2BR)
                            </Box>
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                ml={-3}
                                mr={-3}
                                mb={2}
                                pl={3}
                                pr={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Household
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit" onClick={() => onEditMember(1)}>
                                        <Edit size={21} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            {memberDetails?.length
                                ? memberDetails.map((item, index) => {
                                      return (
                                          <Box mb={5} key={item?.member_id}>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  fontFamily="fontFamily.medium"
                                                  mb={1}>
                                                  {`${item?.fname} ${item?.lname}`}
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  <Box component="span" mr={0.5}>
                                                      Maiden:
                                                  </Box>
                                                  <Box component="span">{item?.maiden_name}</Box>
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  {item?.relation}
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  {item?.gender}
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  <Box component="span" mr={0.5}>
                                                      SSN:
                                                  </Box>
                                                  <Box component="span">
                                                      {item?.social_security_number}
                                                  </Box>
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  {item?.citizenship}
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  <Box component="span" mr={0.5}>
                                                      DOB:
                                                  </Box>
                                                  <Box component="span">{item?.dob}</Box>
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  {getStatus(item?.is_disabled)}
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  {getStatus(item?.is_fulltime_student)}
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  {getStatus(item?.lifetime_sex_offender_reg)}
                                              </Box>
                                              <Box
                                                  color="primary.light"
                                                  fontSize="lg.fontSize"
                                                  mb={1}>
                                                  {item?.race_ethinic?.values
                                                      .map(({ type }) => type)
                                                      .join(', ')}
                                              </Box>
                                              <Box
                                                  fontSize="h5.fontSize"
                                                  fontFamily="fontFamily.semiBold">
                                                  <Button
                                                      onClick={() => onEditMember(index + 1)}
                                                      style={{
                                                          color: 'Indigo',
                                                          fontSize: '15px',
                                                          fontWeight: 700
                                                      }}
                                                      size="medium"
                                                      className="linkBtn">
                                                      Edit Details
                                                  </Button>
                                              </Box>
                                          </Box>
                                      );
                                  })
                                : null}
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                ml={-3}
                                mr={-3}
                                mb={2}
                                pl={3}
                                pr={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Household Income
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={21} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>

                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                {`$${otherDetails?.household_income || ''} per year`}
                            </Box>
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                ml={-3}
                                mr={-3}
                                mb={2}
                                pl={3}
                                pr={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    color="primary.light">
                                    Accessibility
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit" onClick={onEditAccessibility}>
                                        <Edit size={21} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            {otherDetails?.accessibility?.values?.length
                                ? otherDetails?.accessibility?.values.map(({ id, title }) => (
                                      <Box
                                          color="primary.light"
                                          fontSize="lg.fontSize"
                                          mb={1}
                                          className={classes.list}
                                          key={id}>
                                          {title}
                                      </Box>
                                  ))
                                : null}
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                ml={-3}
                                mr={-3}
                                mb={2}
                                pl={3}
                                pr={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    color="primary.light">
                                    Shelter
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit" onClick={onEditShelter}>
                                        <Edit size={21} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            {otherDetails?.shelter?.values?.length
                                ? otherDetails?.shelter?.values.map(({ title, id }) => (
                                      <Box
                                          color="primary.light"
                                          fontSize="lg.fontSize"
                                          mb={1}
                                          className={classes.list}
                                          key={id}>
                                          {title}
                                      </Box>
                                  ))
                                : null}
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                ml={-3}
                                mr={-3}
                                mb={2}
                                pl={3}
                                pr={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    color="primary.light">
                                    Military
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit" onClick={onEditMilitary}>
                                        <Edit size={21} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            {otherDetails?.military?.values?.length
                                ? otherDetails?.military?.values.map(({ title, id }) => (
                                      <Box
                                          color="primary.light"
                                          fontSize="lg.fontSize"
                                          mb={1}
                                          className={classes.list}
                                          key={id}>
                                          {title}
                                      </Box>
                                  ))
                                : null}
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                ml={-3}
                                mr={-3}
                                mb={2}
                                pl={3}
                                pr={3}
                                pb={1}
                                className={classes.title}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    color="primary.light">
                                    Other Needs
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit" onClick={onEditMiseDetail}>
                                        <Edit size={21} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            {otherDetails?.other_needs?.values?.length
                                ? otherDetails?.other_needs?.values.map(({ title, id }) => (
                                      <Box
                                          color="primary.light"
                                          fontSize="lg.fontSize"
                                          mb={1}
                                          className={classes.list}
                                          key={id}>
                                          {title}
                                      </Box>
                                  ))
                                : null}
                        </Box>
                    </Grid>
                </Grid>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        onClick={onNextButtonClick}
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        {buttonText}
                    </Button>
                </Box>
            </Box>
        </Box>
    );
};

ApplicationReview.defaultProps = {
    onNextButtonClick: noop,
    width: '',
    applicantDetail: {},
    memberDetails: [],
    buttonText: 'Confirm and Continue',
    otherDetails: {},
    onEditMember: noop,
    onEditAccessibility: noop,
    onEditShelter: noop,
    onEditMilitary: noop,
    onEditMiseDetail:noop
};

ApplicationReview.propTypes = {
    onNextButtonClick: PropTypes.func,
    width: PropTypes.string,
    applicantDetail: PropTypes.object,
    memberDetails: PropTypes.array,
    buttonText: PropTypes.string,
    otherDetails: PropTypes.object,
    onEditMember: PropTypes.func,
    onEditAccessibility: PropTypes.func,
    onEditShelter: PropTypes.func,
    onEditMilitary: PropTypes.func,
    onEditMiseDetail:PropTypes.func
};
export default withWidth()(ApplicationReview);
