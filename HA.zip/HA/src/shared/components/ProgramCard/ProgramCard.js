import { Box, Card, IconButton } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import Image from 'next/image';
import PropTypes from 'prop-types';
import React from 'react';
import { ChevronRight, Trash2 } from 'react-feather';
import useStyles from './ProgramCardsStyle';

/**
 * Name : ProgramCard
 * Desc : Render ProgramCard
 **/

const ProgramCard = (props) => {
    const {
        children,
        showLeftArrow,
        variant,
        showDeleteBox,
        showImage,
        showLeftBorder,
        imgUrl,
        width
    } = props;
    const classes = useStyles();
    return (
        <Box position="relative">
            <Card>
                <Box display="flex">
                    {showLeftBorder && (
                        <Box
                            minWidth={16}
                            minHeight={96}
                            borderRadius="50px 0 0 50px"
                            position={width === 'xs' ? 'static' : 'absolute'}
                            left="0"
                            zIndex={1}
                            className={classes[variant]}
                        />
                    )}

                    {showImage && (
                        <Box
                            className={clsx(classes.overlay, classes[variant])}
                            mr={2.5}
                            display={width === 'xs' ? 'none' : 'inherit'}>
                            <Image src={imgUrl} width={133} height={96} />
                        </Box>
                    )}

                    {children && (
                        <Box
                            flexGrow={2}
                            px={1.5}
                            py={2}
                            display="flex"
                            flexDirection="column"
                            justifyContent="center">
                            {children}
                        </Box>
                    )}

                    {showLeftArrow && (
                        <Box
                            p={0.25}
                            pr={1.25}
                            display="flex"
                            justifyContent="center"
                            alignItems="center">
                            <IconButton>
                                <ChevronRight stroke-width="3" color="Indigo" size={24} />
                            </IconButton>
                        </Box>
                    )}
                    {showDeleteBox && (
                        <Box
                            component="button"
                            p={1.5}
                            bgcolor="error.dark"
                            color="common.white"
                            minHeight={96}
                            minWidth={96}
                            display="flex"
                            justifyContent="center"
                            alignItems="center"
                            flexDirection="column"
                            border={0}>
                            <Trash2 stroke-width="1.5" color="white" size={20} />
                            <Box
                                component="body1"
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.regular"
                                pt={0.75}>
                                DELETE
                            </Box>
                        </Box>
                    )}
                </Box>
            </Card>
        </Box>
    );
};

ProgramCard.defaultProps = {
    children: '',
    showLeftArrow: false,
    showDeleteBox: false,
    showImage: false,
    showLeftBorder: true,
    imgUrl: '/view.jpg'
};

ProgramCard.propTypes = {
    variant: PropTypes.oneOf(['success', 'failed', 'waiting']),
    children: PropTypes.node,
    showLeftArrow: PropTypes.bool,
    showDeleteBox: PropTypes.bool,
    showImage: PropTypes.bool,
    showLeftBorder: PropTypes.bool,
    imgUrl: PropTypes.string,
    width: PropTypes.string
};

export default withWidth()(ProgramCard);
