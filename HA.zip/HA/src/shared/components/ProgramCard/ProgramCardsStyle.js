import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    failed: {
        backgroundColor: theme.palette.error.main,
        '&:before': {
            background: 'rgba(245, 66, 15, 0.5) !important'
        }
    },
    waiting: {
        backgroundColor: theme.palette.pending.main,
        '&:before': {
            background: 'rgba(249, 191, 2, 0.5) !important'
        }
    },
    // pending: {
    //     backgroundColor: theme.palette.pending.main
    // },
    success: {
        backgroundColor: theme.palette.success.light,
        '&:before': {
            background: 'rgba(79, 240, 188, 0.5) !important'
        }
    },
    info:{
        backgroundColor:theme.palette.info.main
    },
    overlay: {
        position: 'relative',
        '&:before': {
            content: '""',
            width: '100%',
            height: '100%',
            position: 'absolute',
            top: '0',
            bottom: '0',
            left: '0',
            right: '0',
            zIndex: '1'
        }
    }
}));

export default useStyles;