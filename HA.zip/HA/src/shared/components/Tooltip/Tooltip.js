import React from 'react';
import { Zoom, Tooltip, Box } from '@material-ui/core';
import HelpOutlineOutlinedIcon from '@material-ui/icons/HelpOutlineOutlined';

const Tooltips = () => {
    return (
        <Tooltip TransitionComponent={Zoom} title="Add">
            <Box
             display='flex'
             alignItems='center'
             fontSize='subtitle2.fontSize'
             fontFamily='Poppins-Medium'
             color='#2F0B7C'
             >
                 
                 <HelpOutlineOutlinedIcon/> <Box pl={1}> What is this ? </Box></Box>
        </Tooltip>
    )
}

export default Tooltips
