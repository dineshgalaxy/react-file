import { Box } from '@material-ui/core';
import FeatherIcon from 'feather-icons-react';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from './IndicatorsStyles';

/**
 * Name: Indicators
 * Desc: Render Indicators
 * @param { string } classNames
 */

const Indicators = ({ status, size, iconName, iconSize, borderWidth, iconColor }) => {
    const classes = useStyles();
    return (
        <Box
            width={size}
            height={size}
            borderRadius="50%"
            display="flex"
            alignItems="center"
            justifyContent="center"
            margin="0 auto"
            border={borderWidth}
            className={classes[status]}>
            <FeatherIcon icon={iconName} size={iconSize} color={iconColor} />
        </Box>
    );
};

Indicators.defaultProps = {
    size: 80,
    status: 'default',
    iconName: 'thumbs-up',
    iconSize: 36,
    borderWidth: 8
};

Indicators.propTypes = {
    status: PropTypes.oneOf(['success', 'failed', 'pending', 'default', 'complete']),
    size: PropTypes.number,
    iconSize: PropTypes.number,
    borderWidth: PropTypes.number,
    iconName: PropTypes.string,
    iconColor: PropTypes.string
};

export default Indicators;
