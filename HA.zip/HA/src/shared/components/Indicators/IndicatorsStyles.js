import { makeStyles } from '@material-ui/core';
const useStyles = makeStyles((theme) => ({
    failed: {
        backgroundColor: theme.palette.error.light,
        borderColor: `${theme.palette.error.main} !important`
    },
    pending: {
        backgroundColor: theme.palette.pending.light,
        borderColor: `${theme.palette.pending.main} !important`
    },
    success: {
        backgroundColor: theme.palette.success.light,
        borderColor: `${theme.palette.success.main} !important`
    },
    default: {
        backgroundColor: 'transparent',
        borderColor: `${theme.palette.default.main} !important`
    },
    complete: {
        backgroundColor: theme.common.white,
        border: '8px solid rgba(255, 255, 255, .5)',
        '-webkit-background-clip': 'padding-box',
        backgroundClip: 'padding-box'
    }
}));
export default useStyles;
