import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : DisclosureProvisionsAgreement
 * Desc : Render DisclosureProvisionsAgreement
 */

const DisclosureProvisionsAgreement = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box
                fontSize="h5.fontSize"
                lineHeight="35px"
                color="primary.light"
                mb={4}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                Review and confirm that you have provided the lessee with the following information.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="The lessee has received copies of the lead disclosures for this unit"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="The lessee has received the pamphlet Protect Your Family from Lead in Your Home."
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={ width === 'xs' || width === 'sm' ? 'semiBorder' : ''}
                    >
                       Confirm
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

DisclosureProvisionsAgreement.propTypes = {
    width: PropTypes.string,
};

export default withWidth()(DisclosureProvisionsAgreement)
