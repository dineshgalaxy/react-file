import { Box, Button, Grid, IconButton } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { Edit } from 'react-feather';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : LesseeAndUnitReview
 * Desc : Render LesseeAndUnitReview
 */

const LesseeAndUnitReview = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%">
                <Grid container spacing={3}>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={3}
                                px={3}
                                className={classes.title}
                                pb={1}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Your Tenant’s Details
                                </Box>
                            </Box>

                            <Box
                                color="primary.light"
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.medium"
                                mb={1}>
                                Firstname Lastname
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                for Firstname Lastname
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                T-Number: T123456
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Voucher: 123456
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                (555) 555-1234
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Address Line 1
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Address Line 2
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                City, State Zip Code
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Email Address
                            </Box>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={3}
                                px={3}
                                className={classes.title}
                                pb={1}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Unit Info and Terms
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            <Box pb={2}>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    <Box component="span" mr={0.5}>
                                        Unit Street Address
                                    </Box>
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Unit Number
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    City, State Zip Code
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    2 Bedrooms
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    $750/Month Lease
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    $250 Security Deposit
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Lease Starts 5/1/22
                                </Box>
                                <Box
                                    display="flex"
                                    alignItems="center"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    className={classes.actionBtnWrapper}>
                                    <Button size="medium" className="linkBtn">
                                        Edit
                                    </Button>
                                    <Button size="medium" className="linkBtn">
                                        Delete
                                    </Button>
                                </Box>
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Continue
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

LesseeAndUnitReview.propTypes = {
    width: PropTypes.string
};

export default withWidth()(LesseeAndUnitReview)
