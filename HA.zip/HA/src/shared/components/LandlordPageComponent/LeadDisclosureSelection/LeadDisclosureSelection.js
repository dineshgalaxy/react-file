import { Box, Button, FormControl, FormControlLabel, Radio, RadioGroup } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : LeadDisclosureSelection
 * Desc : Render LeadDisclosureSelection
 */

const LeadDisclosureSelection = ({ width }) => {
    const classes = useStyles();
    const isFull = width === 'xs' || width === 'sm';
    return (
        <Box className={classes.flex} width="100%">
            <Box
                fontSize="h5.fontSize"
                lineHeight="35px"
                color="primary.light"
                mb={4.5}
                maxWidth={isFull ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                Select which of the following statements about lead exposure is true for the unit.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box pb={1.2}>
                    <FormControl component="fieldset">
                        <RadioGroup
                            defaultValue="female"
                            aria-label="proxy"
                            name="customized-radios">
                            <Box mb={4}>
                                <FormControlLabel
                                    value="true"
                                    control={<Radio/>}
                                    label="Lead-based paint disclosure requrements do not apply because this property was built on or after January 1, 1978,"
                                />
                            </Box>
                            <Box mb={4}>
                                <FormControlLabel
                                    value="false"
                                    control={<Radio/>}
                                    label="The unit, common areas servicing the unit, and exterior painted surfaces aassociated with the unit or common areas have been found to be lead-based paint free by a lead-based paint inspector certificed under the Federal certification program or under a federally accredited State certification program."
                                />
                            </Box>
                            <FormControlLabel
                                    value="false"
                                    control={<Radio/>}
                                    label={
                                        <>
                                            <Box>
                                                The unit, common areas servicing the unit, and exterior painted surfaces aassociated with the unit or common areas have been found to be lead-based paint free by a lead-based paint inspector certificed under the Federal certification program or under a federally accredited State certification program.
                                            </Box>
                                            <Box fontSize="md.fontSize" fontStyle="italic" color="primary.main" pt={1}>If selected, we will prompt you to attach the disclosure later on.</Box>
                                        </>
                                    }
                                />
                        </RadioGroup>
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={isFull ? true : false}
                        className={clsx(isFull ? 'semiBorder' : '')}>
                        Next
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

LeadDisclosureSelection.propTypes = {
    width: PropTypes.string
};

export default withWidth()(LeadDisclosureSelection)
