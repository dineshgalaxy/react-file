import { Box,
    Button,
    RadioGroup,
    Radio,
    FormControl,
    FormControlLabel,
    InputLabel,
    MenuItem,
    Select,
    TextField } from '@material-ui/core';
import useStyles from '../LandlordPageComponentStyles';
import withWidth from '@material-ui/core/withWidth';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : UnitStructureDetails
 * Desc : Render UnitStructureDetails
 */

const UnitStructureDetails = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={3}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                Enter a few basic details about the unit.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                    In what year was the unit constructed?
                </Box>
                <Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Year</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Year">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={2.5}>
                        What is the unit’s square footage?
                    </Box>
                    <FormControl fullWidth>
                        <TextField
                            id="Employer"
                            label="Square Footage"
                            variant="filled"
                        />
                    </FormControl>
                    <Box mt={2.5} mb={3} color="primary.light" fontSize="h6.fontSize">
                       Which type of structure is the unit?
                    </Box>
                    <FormControl component="fieldset">
                        <RadioGroup defaultValue="structureUnit" aria-label="proxy" name="customized-radios">
                            <Box mb={2.5}>
                                <FormControlLabel 
                                    value="true" 
                                    control={<Radio className="size24"/>} 
                                    label={
                                        <Box>
                                            Single Family Detached
                                            <Box fontSize="md.fontSize" fontStyle="italic" color="primary.extraLight" pt={.25}>One family under one roof</Box>
                                        </Box>
                                    }
                                />
                            </Box>
                            <Box mb={2.5}>
                                <FormControlLabel 
                                    value="false" 
                                    control={<Radio className="size24"/>}
                                    label={
                                        <Box>
                                            Semi-Detached
                                            <Box fontSize="md.fontSize" fontStyle="italic" color="primary.extraLight" pt={.25}>Duplex, attached on one side</Box>
                                        </Box>
                                    }
                                />
                            </Box>
                            <Box mb={2.5}>
                                <FormControlLabel 
                                    value="false" 
                                    control={<Radio className="size24"/>}
                                    label={
                                        <Box>
                                            Rowhouse/Townhouse
                                            <Box fontSize="md.fontSize" fontStyle="italic" color="primary.extraLight" pt={.25}>Attached on two sides</Box>
                                        </Box>
                                    }
                                />
                            </Box>
                            <Box mb={2.5}>
                                <FormControlLabel 
                                    value="false" 
                                    control={<Radio className="size24"/>}
                                    label={
                                        <Box>
                                            Low-Rise Building
                                            <Box fontSize="md.fontSize" fontStyle="italic" color="primary.extraLight" pt={.25}>Four stories or fewer</Box>
                                        </Box>
                                    }
                                />
                            </Box>
                            <Box mb={2.5}>
                                <FormControlLabel 
                                    value="false" 
                                    control={<Radio className="size24"/>} 
                                    label={
                                        <Box>
                                            High-Rise Building
                                            <Box fontSize="md.fontSize" fontStyle="italic" color="primary.extraLight" pt={.25}>Five stories or more</Box>
                                        </Box>
                                    }
                                />
                            </Box>
                            <Box>
                                <FormControlLabel 
                                    value="false" 
                                    control={<Radio className="size24"/>} 
                                    label="Manufactured or Mobile Home"
                                />
                            </Box>
                        </RadioGroup>
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={ width === 'xs' || width === 'sm' ? 'semiBorder' : ''}
                    >
                       Next
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}


UnitStructureDetails.propTypes = {
    width: PropTypes.string,
};

export default withWidth()(UnitStructureDetails)
