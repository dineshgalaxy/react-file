import { Box, Button, FormControl, FormControlLabel, Radio, RadioGroup } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : MultiplePropertySelection
 * Desc : Render MultiplePropertySelection
 */

const MultiplePropertySelection = ({ width }) => {
    const classes = useStyles();
    const isFull = width === 'xs' || width === 'sm';
    return (
        <Box className={classes.flex} width="100%">
            <Box
                fontSize="h5.fontSize"
                lineHeight="35px"
                color="primary.light"
                mb={5.5}
                maxWidth={isFull ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                Does the owner of this property own more than four other units that are unassisted?
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box>
                    <FormControl component="fieldset">
                        <RadioGroup
                            defaultValue="female"
                            aria-label="proxy"
                            name="customized-radios">
                            <Box mb={2}>
                                <FormControlLabel
                                    value="true"
                                    control={<Radio className="extraLightLabel" />}
                                    label="No"
                                />
                            </Box>
                            <FormControlLabel
                                value="false"
                                control={<Radio className="extraLightLabel" />}
                                label="Yes"
                            />
                        </RadioGroup>
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={isFull ? true : false}
                        className={clsx(isFull ? 'semiBorder' : '')}>
                        Next
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

MultiplePropertySelection.propTypes = {
    width: PropTypes.string
};

export default withWidth()(MultiplePropertySelection)
