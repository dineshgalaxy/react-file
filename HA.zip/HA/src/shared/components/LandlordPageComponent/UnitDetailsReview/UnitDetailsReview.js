import { Box, Button, Grid, IconButton } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { Edit } from 'react-feather';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : UnitDetailsReview
 * Desc : Render UnitDetailsReview
 */

const UnitDetailsReview = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%">
                <Grid container spacing={3}>
                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={3}
                                px={3}
                                className={classes.title}
                                pb={1}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Structure
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>

                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Built in 1979
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                965 Square Feet
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Single Family Detached
                            </Box>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={3}
                                px={3}
                                className={classes.title}
                                pb={1}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Subsidies
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>

                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Section 202
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Tax Credit
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                [List Out Fields]
                            </Box>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={3}
                                px={3}
                                className={classes.title}
                                pb={1}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Amenities
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>

                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Stove/Refrigerator
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Washer/Dryer Hookups
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Garbage Disposal
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Dining Room
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Carpeting
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Ceiling Fan(s)
                            </Box>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={3}
                                px={3}
                                className={classes.title}
                                pb={1}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Utilities
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>

                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Heating: Natural Gas
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Cooking: Natural Gas 
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Water Heating: Natural Gas
                            </Box>
                            <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                Air Conditioning: Electric
                            </Box>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={3}
                                px={3}
                                className={classes.title}
                                pb={1}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Utility Costs
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            <Box pb={3.5}>
                                <Box
                                    color="primary.light"
                                    fontSize="lg.fontSize"
                                    fontFamily="fontFamily.medium"
                                    mb={1}>
                                    Owner WIll Pay:
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Heating Costs
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Cooking Energy Costs
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Water Heating Costs
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Water Costs
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Sewer Costs
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Trash Collection Costs
                                </Box>
                            </Box>
                            <Box
                                    color="primary.light"
                                    fontSize="lg.fontSize"
                                    fontFamily="fontFamily.medium"
                                    mb={1}>
                                    Lessee WIll Pay:
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Air Conditioning Costs
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Other Electric Costs
                                </Box>
                        </Box>
                    </Grid>

                    <Grid item xs={12} md={6}>
                        <Box mb={6}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={3}
                                px={3}
                                className={classes.title}
                                pb={1}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Appliance Provisions
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            <Box pb={3.5}>
                                <Box
                                    color="primary.light"
                                    fontSize="lg.fontSize"
                                    fontFamily="fontFamily.medium"
                                    mb={1}>
                                    Owner WIll Provide:
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Cooking Range/Stove
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Refrigerator
                                </Box>
                            </Box>
                            <Box
                                    color="primary.light"
                                    fontSize="lg.fontSize"
                                    fontFamily="fontFamily.medium"
                                    mb={1}>
                                    Lessee WIll Provide:
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Microwave
                                </Box>
                        </Box>
                    </Grid>

                </Grid>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Continue
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

UnitDetailsReview.propTypes = {
    width: PropTypes.string
};

export default withWidth()(UnitDetailsReview)
