import { Box,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    TextField } from '@material-ui/core';
import useStyles from '../LandlordPageComponentStyles';
import withWidth from '@material-ui/core/withWidth';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : ComparableUnitDetails
 * Desc : Render ComparableUnitDetails
 */

const ComparableUnitDetails = ({ width }) => {
    const classes = useStyles();
    const isFull = width === 'xs' || width === 'sm';
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={3}
                maxWidth={isFull ? '100%' : 337}
                pr={isFull ? '0' : 3}>
                To verify how this unit compares with comparable unit rental costs, we will need information about three other properties you manage.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box fontSize="h6.fontSize" color="primary.light" mb={3}>
                    Enter the details  for the first comparable unit below.
                </Box>
                <Box>
                    <FormControl fullWidth>
                        <TextField
                            id="Employer"
                            label={
                                <Box display="flex" alignItems="center">
                                    Unit Address<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="Employer"
                            label="Unit Number"
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="Employer"
                            label={
                                <Box display="flex" alignItems="center">
                                    City<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">State*</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label={
                                <Box display="flex" alignItems="center">
                                    State<Box color="primary.main">*</Box>
                                </Box>
                            }>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="Employer"
                            label={
                                <Box display="flex" alignItems="center">
                                    Zip Code<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="Employer"
                            label={
                                <Box display="flex" alignItems="center">
                                    Rental Start Date<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="Employer"
                            label={
                                <Box display="flex" alignItems="center">
                                    Monthly Rent Amount<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={isFull ? true : false}
                        className={isFull ? 'semiBorder' : ''}>
                        Next
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

ComparableUnitDetails.propTypes = {
    width: PropTypes.string
};
export default withWidth()(ComparableUnitDetails)
