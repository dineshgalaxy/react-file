import { Box,
    Button,
    FormControl,
    TextField } from '@material-ui/core';
import useStyles from '../LandlordPageComponentStyles';
import withWidth from '@material-ui/core/withWidth';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : AppointmentContactDetails
 * Desc : Render AppointmentContactDetails
 */

const AppointmentContactDetails = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={4}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                Confirm the best telephone number for our inspectors to reach you.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box pb={5.5}>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label={
                                <Box display="flex" alignItems="center">
                                    Telephone<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={width === 'xs' || width === 'sm' ? 'semiBorder' : ''}
                    >
                        Next
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

AppointmentContactDetails.propTypes = {
    width: PropTypes.string,
};


export default withWidth()(AppointmentContactDetails)
