import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : FamilyDisclosureAgreement
 * Desc : Render FamilyDisclosureAgreement
 */

const FamilyDisclosureAgreement = ({ width }) => {
    const classes = useStyles();

    return (
        <Box className={classes.flex} width="100%">
            <Box width="100%">
                <Box  mx={-3} px={3} mb={3.5} className={classes.title}>
                    <Box 
                        fontSize="h5.fontSize"
                        lineHeight="35px" 
                        color="primary.light" 
                        mb={4.5}>
                        Review and confirm the following statement about the property owner’s familial ties.
                    </Box>
                    <Box color="primary.light" fontSize="lg.fontSize" pb={4}>
                        The owner (including a principal or other interested party) is not the parent, child, grandparent, grandchild, sister or brother of any member of the family, unless the PHA has determined (and has notified the owner and the family of such determination) that approving leasing of the unit, notwithstanding such relationship, would provide reasonable accommodation for a family member who is a person with disabilities.
                    </Box>
                </Box>
                <Box>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="I have read and confirm the above statement"
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}


FamilyDisclosureAgreement.propTypes = {
    width: PropTypes.string
};

export default withWidth()(FamilyDisclosureAgreement)
