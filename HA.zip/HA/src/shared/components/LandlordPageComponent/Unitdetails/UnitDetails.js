import { Box,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    TextField } from '@material-ui/core';
import useStyles from '../LandlordPageComponentStyles';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : UnitDetails
 * Desc : Render UnitDetails
 */

const UnitDetails = ({ width, showFaceBookLoginButton }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={4}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                Enter the details for the rental unit below.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box pb={2}>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label={
                                <Box display="flex" alignItems="center">
                                    Unit Street Address<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label="Unit Number"
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label={
                                <Box display="flex" alignItems="center">
                                    City<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">State*</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label={
                                <Box display="flex" alignItems="center">
                                    State<Box color="primary.main">*</Box>
                                </Box>
                            }>
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label={
                                <Box display="flex" alignItems="center">
                                    Zip Code<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Number of Bedrooms</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Number of Bedrooms">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label={
                                <Box display="flex" alignItems="center">
                                    Monthly Rent Amount<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label={
                                <Box display="flex" alignItems="center">
                                   Security Deposit Amount<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            type="datepicker"
                            label={
                                <Box display="flex" alignItems="center">
                                   Lease Start Date<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>

                </Box>   
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(
                            width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                            showFaceBookLoginButton && 'facebooKBtn'
                        )}
                    >
                        {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

UnitDetails.defaultProps = {
    showFaceBookLoginButton: false
};

UnitDetails.propTypes = {
    width: PropTypes.string,
    showFaceBookLoginButton: PropTypes.bool,
};

export default withWidth()(UnitDetails)
