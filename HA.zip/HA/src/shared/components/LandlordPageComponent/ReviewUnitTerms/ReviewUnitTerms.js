import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : ReviewUnitTerms
 * Desc : ReviewUnitTerms
 */

const ReviewUnitTerms = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box width="100%">
                <Box pb={2}>
                    <Box mx={-3} mb={3} px={3} pb={1} className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.light"
                            pb={.5}>
                            Updated Rental Terms 
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Unit Address
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" pb={1}>
                            Address Line One 
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" pb={1}>
                            Unit Number 
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" pb={1}>
                            El Paso, Texas 77712
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Number of Bedrooms
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            2 Bedrooms
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Monthly Rent Amount (Adjusted)
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            $750
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Security Deposit Amount
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            $500
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Lease Start Date
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            May 1, 2022
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Tenant Name
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            Erika Alexander
                        </Box>
                    </Box>
                </Box>
                <Box>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label={
                                <Box color="primary.light" fontSize="h6.fontSize" mb={2}>
                                    I have read and accept the updated terms for this rental unit
                                </Box>
                            }
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                         Continue
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}
ReviewUnitTerms.propTypes = {
    width: PropTypes.string
};
export default withWidth()(ReviewUnitTerms)
