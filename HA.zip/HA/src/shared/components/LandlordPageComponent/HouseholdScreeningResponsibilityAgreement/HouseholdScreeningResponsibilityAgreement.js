import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : HouseholdScreeningResponsibilityAgreement
 * Desc : Render HouseholdScreeningResponsibilityAgreement
 */

const HouseholdScreeningResponsibilityAgreement = ({ width }) => {
    const classes = useStyles();

    return (
        <Box className={classes.flex} width="100%">
            <Box width="100%">
                <Box  mx={-3} px={3} mb={3.5} className={classes.title}>
                    <Box 
                        fontSize="h5.fontSize"
                        lineHeight="35px" 
                        color="primary.light" 
                        mb={4.5}>
                        Review and confirm the following statement about your responsibility for screening the lessee and household.
                    </Box>
                    <Box color="primary.light" fontSize="lg.fontSize" pb={4}>
                        The owner understands that the public housing authority (HACEP) has not screened the future tenant or household’s behavior or suitability for tenancy. Such screening is the responsibility accepted by the property owner.
                    </Box>
                </Box>
                <Box>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="I agree"
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

HouseholdScreeningResponsibilityAgreement.propTypes = {
    width: PropTypes.string
};


export default withWidth()(HouseholdScreeningResponsibilityAgreement)
