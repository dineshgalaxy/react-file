import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : LandlordRevieweSignatureTerms
 * Desc : Render LandlordRevieweSignatureTerms
 */

const LandlordRevieweSignatureTerms = ({ width }) => {
    const classes = useStyles();

    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%">
                <Box mb={2}>
                    <Box mx={-3} mb={3.75} px={3} pb={1} className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.light"
                            pb={.5}>
                            Esignature Waiver
                        </Box>
                    </Box>
                    <Box mx={-3} mb={5} px={3}>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            <Box fontFamily="fontFamily.medium" component="span">From time to time, donotreply@hacep.org (we, us or Company) may be required by law to provide to you certain written notices or disclosures.</Box> Described below are the terms and conditions for providing to you such notices and disclosures electronically through the airSlate, Inc. (airSlate) electronic signing system. Please read the information below carefully and thoroughly, and if you can access this information electronically to your satisfaction and agree to these terms and conditions, please confirm your agreement by clicking the I Consent button below.
                        </Box>
                    </Box>
                </Box>
                <Box mt={4}>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label={
                                <Box fontSize="h6.fontSize" mb={2}>
                                    I agree to use electronic records and signatures
                                </Box>
                            }
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Continue
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

LandlordRevieweSignatureTerms.propTypes = {
    width: PropTypes.string
};

export default withWidth()(LandlordRevieweSignatureTerms)
