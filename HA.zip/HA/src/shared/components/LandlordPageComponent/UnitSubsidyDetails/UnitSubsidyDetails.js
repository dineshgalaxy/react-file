import { Box, Button, Checkbox, FormControl, FormControlLabel, TextField } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : UnitSubsidyDetails
 * Desc : Render UnitSubsidyDetails
 */

const UnitSubsidyDetails = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box
                fontSize="h5.fontSize"
                lineHeight="35px"
                color="primary.light"
                mb={4}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                If the unit is subsidized, mark any subsidizations that are true below.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Section 202"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Section 221 (d) (3) (BMIR)"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Tax Credit"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="HOME"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label={
                                <Box>
                                    Section 236
                                    <Box fontSize="md.fontSize" fontStyle="italic" color="primary.extraLight" pt={.25}>Insured or Uninsured</Box>
                                </Box>
                            }
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label={
                                <Box>
                                    Section 515
                                    <Box fontSize="md.fontSize" fontStyle="italic" color="primary.extraLight" pt={.25}>Rural Development</Box>
                                </Box>
                            }
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label={
                                <Box>
                                    Other Subsidy
                                    <Box fontSize="md.fontSize" fontStyle="italic" color="primary.extraLight" pt={.25} mb={1.5}>Describe, Including any state or local subsidy</Box>
                                    <Box mb={-3}>
                                        <FormControl fullWidth>
                                            <TextField
                                                id="jobTitle"
                                                multiline
                                                rows={4}
                                                label="Other Subsidy"
                                                variant="filled"
                                            />
                                        </FormControl>
                                    </Box>
                                </Box>
                            }
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Or, unit is not subsidized"
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={ width === 'xs' || width === 'sm' ? 'semiBorder' : ''}
                    >
                       Next
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

UnitSubsidyDetails.propTypes = {
    width: PropTypes.string,
};
export default withWidth()(UnitSubsidyDetails)
