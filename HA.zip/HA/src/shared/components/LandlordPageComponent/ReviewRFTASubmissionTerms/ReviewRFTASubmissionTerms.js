import { Box, Button, Checkbox, FormControl, FormControlLabel, TextField } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : ReviewRFTASubmissionTerms
 * Desc : Render ReviewRFTASubmissionTerms
 */

const ReviewRFTASubmissionTerms = ({ width }) => {
    const classes = useStyles();

    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%">
                <Box mb={2}>
                    <Box mx={-3} mb={3.75} px={3} pb={1} className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.light"
                            pb={.5}>
                            Terms & Disclosures
                        </Box>
                    </Box>
                    <Box mx={-3} mb={5} px={3}>
                        <Box color="primary.light" fontSize="h6.fontSize" className={classes.scrollContent}>
                            <Box fontFamily="fontFamily.medium" pb={2}>Approved Residents of Assisted Unit</Box> 
                            I understand that the family members listed on the dwelling lease agreement as approved by the Housing Authority are the only individuals permitted to reside in the assisted unit. I also understand that I am not permitted to live in the unit while I am receiving housing assistance payments on behalf of the assisted family.
                        </Box>
                    </Box>
                </Box>
                <Box pt={3.5}>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="I have read and accept the above terms and conditions"
                        />
                    </FormControl>
                </Box>
                <Box mt={4} pb={width === 'xs' || width === 'sm' ? 1.5 : 6}>
                    <FormControl fullWidth>
                        <TextField
                            id="paycheckAmount"
                            label={
                                <Box display="flex" alignItems="center">
                                 Owner/Landlord Name<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="paycheckAmount"
                            label={
                                <Box display="flex" alignItems="center">
                                    Signature<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <Box mt={-1.5} color="primary.main" fontSize="md.fontSize" fontStyle="italic">
                        Type your name to sign 
                    </Box>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="secondary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Submit
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

ReviewRFTASubmissionTerms.propTypes = {
    width: PropTypes.string
};

export default withWidth()(ReviewRFTASubmissionTerms)
