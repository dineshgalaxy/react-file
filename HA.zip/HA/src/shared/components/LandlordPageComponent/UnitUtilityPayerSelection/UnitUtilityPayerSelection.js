import { Box,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select } from '@material-ui/core';
import useStyles from '../LandlordPageComponentStyles';
import withWidth from '@material-ui/core/withWidth';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : UnitUtilityPayerSelection
 * Desc : Render UnitUtilityPayerSelection
 */

const UnitUtilityPayerSelection = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={3}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                For each utility below, select if the landlord or tenant will be responsible for paying the associated costs.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                    Heating Costs
                </Box>
                <Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Payer</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Payer">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={1.5}>
                        Cooking Energy Costs
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Payer</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Payer">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={1.5}>
                        Water Heating Costs
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Payer</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Payer">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={1.5}>
                        Other Electric Costs
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Payer</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Payer">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={1.5}>
                        Water Costs
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Payer</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Payer">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={1.5}>
                        Sewer Costs
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Payer</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Payer">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={1.5}>
                        Trash Collection Costs
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Payer</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Payer">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={1.5}>
                        Air Conditioning Costs
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Payer</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Payer">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={ width === 'xs' || width === 'sm' ? 'semiBorder' : ''}
                    >
                       Next
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

UnitUtilityPayerSelection.propTypes = {
    width: PropTypes.string,
};

export default withWidth()(UnitUtilityPayerSelection)
