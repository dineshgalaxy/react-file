import { Box,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select } from '@material-ui/core';
import useStyles from '../LandlordPageComponentStyles';
import withWidth from '@material-ui/core/withWidth';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : UnitUtilitySelection
 * Desc : Render UnitUtilitySelection
 */

const UnitUtilitySelection = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={3}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                Enter the details for the types of utilities that are used in the unit.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box fontSize="h6.fontSize" color="primary.light" mb={1.5}>
                    What type of utility is used for the unit’s heating?
                </Box>
                <Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Type</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Type">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={2.5}>
                        What type of utility is used for cooking in the unit?
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Type</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Type">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={2.5}>
                        What type of utility is used for water heating?
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Type</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Type">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Box fontSize="h6.fontSize" color="primary.light" mb={1.5} mt={2.5}>
                        What type of utility is used for air conditioning?
                    </Box>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Type</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Type">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={ width === 'xs' || width === 'sm' ? 'semiBorder' : ''}
                    >
                       Next
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

UnitUtilitySelection.propTypes = {
    width: PropTypes.string,
};

export default withWidth()(UnitUtilitySelection)
