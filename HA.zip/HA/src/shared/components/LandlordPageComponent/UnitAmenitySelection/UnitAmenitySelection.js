import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : UnitAmenitySelection
 * Desc : Render UnitAmenitySelection
 */

const UnitAmenitySelection = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box
                fontSize="h5.fontSize"
                lineHeight="35px"
                color="primary.light"
                mb={4}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                Select any amenities that are included in the unit.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Stove/Range"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Refrigerator"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Washer"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="Dryer"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Washer/Dryer Hookups"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Laundry Facilities"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Garage"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Garbage Disposal"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Working Fireplace"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Dishwasher"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Swimming Pool"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Dining Room"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Fenced Yard"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Balcony"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Carpeting"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Ceiling Fan(s)"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <FormControlLabel
                            control={<Checkbox inputProps={{ 'aria-label': 'primary checkbox' }} />}
                            label="Handicap Accessible"
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={ width === 'xs' || width === 'sm' ? 'semiBorder' : ''}
                    >
                       Next
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

UnitAmenitySelection.propTypes = {
    width: PropTypes.string,
};

export default withWidth()(UnitAmenitySelection)
