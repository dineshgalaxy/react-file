import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 96px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: '0 0 38px 0',
            alignItems: 'flex-start'
        }
    },
    xsBtn: {
        marginTop:"24px",
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%',
            marginTop:0
        }
    },
    title: {
        borderBottom: '2px solid #fff'
    },
    scrollContent:{
        maxHeight:"383px",
        overflowY:"auto"
    },
    centerPlayIcon:{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        cursor: 'pointer'
    },
    actionBtnWrapper: {
        '& > button': {
            fontSize: theme.typography.lg.fontSize,
            color: theme.palette.primary.main,
            position: 'relative',
            '&:not(:last-child)': {
                marginRight: `${theme.spacing(3)}px !important`,
                '&:before': {
                    content: '"|"',
                    width: '2px',
                    color: theme.palette.primary.main,
                    position: 'absolute',
                    right: '-11px'
                }
            }
        }
    }
}))

export default useStyles;