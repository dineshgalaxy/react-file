import { Box, Button } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : ReviewTenantDetails
 * Desc : ReviewTenantDetails
 */

const ReviewTenantDetails = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box width="100%">
                <Box pb={2}>
                    <Box mx={-3} mb={3} px={3} pb={1} className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.light"
                            pb={.5}>
                            Your Lessee’s Details
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Name
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            Erika Alexander
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            T-Number
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            T123456
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Voucher Number
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            123456
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Telephone Number
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            (555) 555-1234
                        </Box>
                    </Box>
                    <Box mb={4}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Email Address
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize">
                            erikaa@gmail.com
                        </Box>
                    </Box>
                    <Box mb={1}>
                        <Box color="primary.light" fontSize="lg.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Current Address
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" pb={1}>
                            Address Line One 
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" pb={1}>
                            Address Line Two
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" pb={1}>
                            El Paso, Texas 77712
                        </Box>
                    </Box>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Continue
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}
ReviewTenantDetails.propTypes = {
    width: PropTypes.string
};
export default withWidth()(ReviewTenantDetails)
