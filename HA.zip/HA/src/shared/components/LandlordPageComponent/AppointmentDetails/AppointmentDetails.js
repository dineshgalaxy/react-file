import { Box,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    TextField } from '@material-ui/core';
import useStyles from '../LandlordPageComponentStyles';
import withWidth from '@material-ui/core/withWidth';
import React from 'react';
import PropTypes from 'prop-types';

/**
 * Name : AppointmentDetails
 * Desc : Render AppointmentDetails
 */

const AppointmentDetails = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={4}
                maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}
                pr={width === 'xs' || width === 'sm' ? '0' : 3}>
                Enter the first date that you’re available to meet the inspector at the unit.
            </Box>
            <Box className={classes.formWidth} width="100%">
                <Box pb={5.5}>
                    <FormControl fullWidth>
                        <TextField
                            id="fName"
                            label="February 14, 2022"
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">9am - 11am</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="9am - 11am">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <FormControl variant="filled" fullWidth>
                        <InputLabel id="demo-simple-select-label">Select Timeframe</InputLabel>
                        <Select
                            labelId="demo-simple-select-label"
                            id="demo-simple-select"
                            label="Select Timeframe">
                            <MenuItem value={10}>Ten</MenuItem>
                            <MenuItem value={20}>Twenty</MenuItem>
                            <MenuItem value={30}>Thirty</MenuItem>
                        </Select>
                    </FormControl>
                    <Button 
                        style={{
                            fontSize:"12px",
                            padding:"8px 20px"
                        }}
                        size="large" 
                        color="primary" 
                        variant="contained">
                        Add Another Timeframe
                    </Button>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={width === 'xs' || width === 'sm' ? 'semiBorder' : ''}
                    >
                        Save
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

AppointmentDetails.propTypes = {
    width: PropTypes.string,
};

export default withWidth()(AppointmentDetails)
