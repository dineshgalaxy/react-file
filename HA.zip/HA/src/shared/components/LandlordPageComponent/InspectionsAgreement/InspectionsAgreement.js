import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : InspectionsAgreement
 * Desc : Render InspectionsAgreement
 */


const InspectionsAgreement = ({ width }) => {
    const classes = useStyles();

    return (
        <Box className={classes.flex} width="100%">
            <Box width="100%">
                <Box  mx={-3} px={3} mb={3.5} className={classes.title}>
                    <Box 
                        fontSize="h5.fontSize"
                        lineHeight="35px" 
                        color="primary.light" 
                        mb={4.5}>
                        Review and confirm the following statement about inspections for the unit.
                    </Box>
                    <Box color="primary.light" fontSize="lg.fontSize" pb={4}>
                        The public housing authority (HACEP) will facilitate the inspection of the unit, and will notify the owner and the lessee if the unit is not approved.
                    </Box>
                </Box>
                <Box>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="I agree"
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

InspectionsAgreement.propTypes = {
    width: PropTypes.string
};

export default withWidth()(InspectionsAgreement)
