import { Box, Button, Grid, IconButton } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { Edit } from 'react-feather';
import useStyles from '../LandlordPageComponentStyles';

/**
 * Name : UnitCompsReview
 * Desc : Render UnitCompsReview
 */

const UnitCompsReview = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%">
                <Grid container spacing={3}>

                    <Grid item xs={12} md={6}>
                        <Box mb={2}>
                            <Box
                                display="flex"
                                alignItems="center"
                                justifyContent="space-between"
                                mx={-3}
                                mb={3}
                                px={3}
                                className={classes.title}
                                pb={1}>
                                <Box
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.semiBold"
                                    color="primary.light">
                                    Comparable Units
                                </Box>
                                <Box>
                                    <IconButton aria-label="edit">
                                        <Edit size={16} strokeWidth="2" color="Indigo" />
                                    </IconButton>
                                </Box>
                            </Box>
                            <Box pb={3.5}>
                                <Box
                                    color="primary.light"
                                    fontSize="lg.fontSize"
                                    fontFamily="fontFamily.medium"
                                    mb={1}>
                                    Unit Address Line 1
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Unit Number
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    City, State Zip Code
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Rented Since X/XX/XXXX
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    $750/month 
                                </Box>
                                <Box
                                    display="flex"
                                    alignItems="center"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    className={classes.actionBtnWrapper}>
                                    <Button size="medium" className="linkBtn">
                                        Edit
                                    </Button>
                                    <Button size="medium" className="linkBtn">
                                        Delete
                                    </Button>
                                </Box>
                            </Box>
                            <Box pb={3.5}>
                                <Box
                                    color="primary.light"
                                    fontSize="lg.fontSize"
                                    fontFamily="fontFamily.medium"
                                    mb={1}>
                                    Unit Address Line 1
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Unit Number
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    City, State Zip Code
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Rented Since X/XX/XXXX
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    $750/month 
                                </Box>
                                <Box
                                    display="flex"
                                    alignItems="center"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    className={classes.actionBtnWrapper}>
                                    <Button size="medium" className="linkBtn">
                                        Edit
                                    </Button>
                                    <Button size="medium" className="linkBtn">
                                        Delete
                                    </Button>
                                </Box>
                            </Box>
                            <Box pb={3.5}>
                                <Box
                                    color="primary.light"
                                    fontSize="lg.fontSize"
                                    fontFamily="fontFamily.medium"
                                    mb={1}>
                                    Unit Address Line 1
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Unit Number
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    City, State Zip Code
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    Rented Since X/XX/XXXX
                                </Box>
                                <Box color="primary.light" fontSize="lg.fontSize" mb={1}>
                                    $750/month 
                                </Box>
                                <Box
                                    display="flex"
                                    alignItems="center"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    className={classes.actionBtnWrapper}>
                                    <Button size="medium" className="linkBtn">
                                        Edit
                                    </Button>
                                    <Button size="medium" className="linkBtn">
                                        Delete
                                    </Button>
                                </Box>
                            </Box>
                        </Box>
                    </Grid>
                </Grid>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Continue
                    </Button>
                </Box>
            </Box>
        </Box>
    );
}

UnitCompsReview.propTypes = {
    width: PropTypes.string
};

export default withWidth()(UnitCompsReview)
