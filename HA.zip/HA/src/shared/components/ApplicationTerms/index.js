export { default } from './ApplicationTerms';
