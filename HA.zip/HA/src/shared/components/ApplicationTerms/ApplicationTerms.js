import { Box, Button, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import useStyles from './ApplicationTermsStyles';

/**
 * Name : ApplicationTerms
 * Desc : Render ApplicationTerms
 */

const ApplicationTerms = ({ onNextButtonClick, width }) => {
    const classes = useStyles();
    const [termAndCondition, setTermsAndCondition] = useState(false);

    const handleCheckBoxChange = ({ target }) => {
        setTermsAndCondition(target.checked);
    };

    return (
        <Box className={classes.flex} width="100%">
            <Box className={classes.textAlign} width="100%">
                <Box mb={2}>
                    <Box ml={-3} mr={-3} mb={2} pl={3} pr={3} pb={1} className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.light"
                            textAlign="center"
                            pb={1}>
                            Terms and Conditions
                        </Box>
                    </Box>
                    <Box ml={-3} mr={-3} mb={2} pl={3} pr={3} pb={1} className={classes.title}>
                        <Box color="primary.light" fontSize="lg.fontSize" mb={2}>
                            I (all adults listed in the household) understand by submitting these
                            documents, that they are true to the best of my knowledge. I further
                            understand that statements or information provided by me are punishable
                            under federal and state law and may constitute grounds for termination.
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" mb={3}>
                            I acknowledge and agree that my electronic signature will be affixed in
                            the documents required for my recertification and all signatures are
                            attributable to the person whose name is typed in the signature line. I
                        </Box>
                        <Box color="primary.light" fontSize="lg.fontSize" mb={2}>
                            acknowledge and agree that in the event that any person known to me
                            misappropriates my login or electronic signature account and HACEP could
                            not reasonably detect it, HACEP shall have the right to treat all
                            resulting electronic signatures and information as though they were
                            affixed by the person whose name is typed in the signature line.
                        </Box>
                    </Box>
                </Box>
                <Box mt={4}>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    className="extraLightLabel"
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label={
                                <Box color="primary.light" fontSize="h6.fontSize" mb={2}>
                                    I have read and accept the above terms and conditions
                                </Box>
                            }
                            name="termsAndCondition"
                            onChange={handleCheckBoxChange}
                        />
                    </FormControl>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="secondary"
                        variant="contained"
                        onClick={() => onNextButtonClick(termAndCondition)}
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Submit
                    </Button>
                </Box>
            </Box>
        </Box>
    );
};
ApplicationTerms.propTypes = {
    onNextButtonClick: PropTypes.func,
    width: PropTypes.string
};
export default withWidth()(ApplicationTerms);
