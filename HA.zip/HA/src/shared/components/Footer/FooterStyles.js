import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    footerWrapper: {
        [theme.breakpoints.up('lg')]: {
            padding: '72px 72px 56px'
        }
    },
    titleText: {
        borderBottom: `2px solid ${theme.palette.primary.extraLight}`
    },
    footerGrid: {
        display: 'none',
        [theme.breakpoints.up('md')]: {
            display: 'block'
        },
        '& .MuiLink-root':{
            '&:hover': {
                color: theme.palette.success.light
            }
        }
    },
    logoWrapper: {
        [theme.breakpoints.down('md')]: {
            borderBottom: `2px solid ${theme.palette.primary.extraLight}`
        },
        [theme.breakpoints.up('md')]: {
            flexDirection: 'column',
            padding: 0,
            border: 0
        }
    },
    logoText: {
        [theme.breakpoints.up('md')]: {
            fontSize: theme.typography.h4.fontSize,
            textAlign: 'center',
            maxWidth: '290px'
        }
    },
    logoImage: {
        [theme.breakpoints.up('md')]: {
            marginBottom: '24px',
            '& > div': {
                marginRight: 0,
                '& > div ': {
                    '& > img': {
                        height: '130px',
                        width: '130px'
                    }
                }
            }
        },
        [theme.breakpoints.down('sm')]: {
            '& > div': {
                '& > div ': {
                    '& > img': {
                        height: '66px',
                        width: '63px'
                    }
                }
            }
        }
    },
    companyText: {
        fontStyle: 'italic',
        [theme.breakpoints.up('md')]: {
            display: 'none'
        }
    },
    mobileLinks: {
        [theme.breakpoints.up('md')]: {
            display: 'none'
        }
    },
    companyName: {
        [theme.breakpoints.up('md')]: {
            display: 'none'
        }
    }
}));

export default useStyles;
