import { Box, Button, Grid, Link } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import Image from 'next/image';
import PropTypes from 'prop-types';
import React from 'react';
import { ChevronRight } from 'react-feather';
import useStyles from './FooterStyles';
/**
 * Name : Footer
 * Desc : Render Footer
 */

const Footer = ({ width }) => {
    const classes = useStyles();

    return (
        <Box bgcolor="primary.main" pt={7} pb={2} pr={4} pl={4} className={classes.footerWrapper}>
            <Grid container spacing={8}>
                <Grid item xs={12} md={3}>
                    <Box display="flex" alignItems="center" pb={4} className={classes.logoWrapper}>
                        <Box
                            display="flex"
                            justifyContent="center"
                            mr={2}
                            className={classes.logoImage}
                            flex={width === 'xs' || width === 'sm' ? '0 0 63px' : '0 0 163px'}>
                            <Image
                                src="/clientLogo.svg"
                                width={80}
                                height={80}
                                className={classes.image}
                            />
                        </Box>
                        <Box>
                            <Box
                                color="common.white"
                                fontSize="md.fontSize"
                                textAlign="left"
                                className={classes.companyText}>
                                HACEP
                            </Box>
                            <Box
                                color="common.white"
                                fontSize="h5.fontSize"
                                fontFamily="fontFamily.bold"
                                textAlign="left"
                                className={classes.logoText}>
                                Housing Authority of the City of El Paso
                            </Box>
                        </Box>
                    </Box>
                    <Box
                        display="flex"
                        mt={3}
                        mb={3}
                        alignItems="flex-start"
                        className={classes.companyName}>
                        <Box
                            display="flex"
                            justifyContent="center"
                            mr={2}
                            flex={width === 'xs' || width === 'sm' ? '0 0 46' : 'none'}>
                            <Image
                                src="/home.svg"
                                width={width === 'xs' || width === 'sm' ? 46 : 40}
                                height={width === 'xs' || width === 'sm' ? 43 : 37}
                            />
                        </Box>
                        <Box color="common.white" fontSize="h6.fontSize">
                            We’re a proud equal housing opportunity provider.
                        </Box>
                    </Box>
                    <Box className={classes.mobileLinks}>
                        <Box>
                            {[
                                { text: ' Privacy Policy' },
                                { text: 'Terms and Conditions' },
                                { text: 'Accessibility' },
                                { text: 'Equal Opportunity' }
                            ].map((item) => (
                                <Box mb={1.5} key={item.text}>
                                    <Link href="#" underline="none">
                                        <Box display="flex" alignItems="center">
                                            <Box fontSize="md.fontSize" color="common.white" mr={1}>
                                                {item.text}
                                            </Box>
                                            <ChevronRight strokeWidth="2" color="white" size={14} />
                                        </Box>
                                    </Link>
                                </Box>
                            ))}
                        </Box>
                    </Box>
                </Grid>
                <Grid item xs={12} md={3} className={classes.footerGrid}>
                    <Box
                        color="common.white"
                        fontSize="h5.fontSize"
                        fontFamily="fontFamily.bold"
                        pb={1}
                        mb={3}
                        className={classes.titleText}>
                        Visit HACEP
                    </Box>
                    <Box>
                        <Box mb={2} display="flex">
                            <Link href="#" underline="none">
                                <Box display="flex" alignItems="center">
                                    <Box fontSize="lg.fontSize" color="common.white" mr={1}>
                                        Main Website
                                    </Box>
                                    <ChevronRight strokeWidth="2" color="white" size={14} />
                                </Box>
                            </Link>
                        </Box>

                        <Box mb={2}>
                            <Box display="flex" alignItems="center">
                                <Box fontSize="lg.fontSize" color="common.white" mr={1}>
                                    5300 E. Paisano Drive
                                </Box>
                            </Box>
                        </Box>
                        <Box mb={2}>
                            <Box display="flex" alignItems="center">
                                <Box fontSize="lg.fontSize" color="common.white" mr={1}>
                                    El Paso, Texas 79905
                                </Box>
                            </Box>
                        </Box>
                        <Box mb={2} mt={4}>
                            <Button
                                size={
                                    width === 'xs' || width === 'sm' || width === 'md'
                                        ? 'small'
                                        : 'large'
                                }
                                color="inherit"
                                variant="contained">
                                Get Directions
                            </Button>
                        </Box>
                    </Box>
                </Grid>
                <Grid item xs={12} md={3} className={classes.footerGrid}>
                    <Box
                        color="common.white"
                        fontSize="h5.fontSize"
                        fontFamily="fontFamily.bold"
                        pb={1}
                        mb={3}
                        className={classes.titleText}>
                        Get Help & Support
                    </Box>
                    <Box>
                        {[
                            { text: 'Help Center' },
                            { text: 'Contact Us' },
                            { text: 'TDD (915) 847-3737' },
                            { text: '(915) 849-3742' }
                        ].map((item) => (
                            <Box mb={2} display="flex" key={item.text}>
                                <Link href="#" underline="none">
                                    <Box display="flex" alignItems="center">
                                        <Box fontSize="lg.fontSize" color="common.white" mr={1}>
                                            {item.text}
                                        </Box>
                                        <ChevronRight strokeWidth="2" color="white" size={14} />
                                    </Box>
                                </Link>
                            </Box>
                        ))}
                    </Box>
                </Grid>
                <Grid item xs={12} md={3} className={classes.footerGrid}>
                    <Box
                        color="common.white"
                        fontSize="h5.fontSize"
                        fontFamily="fontFamily.bold"
                        pb={1}
                        mb={3}
                        className={classes.titleText}>
                        Legal Information
                    </Box>
                    <Box>
                        {[
                            { text: 'Equal Housing Opportunity' },
                            { text: 'Accessibility' },
                            { text: 'Non-Discrimination' },
                            { text: 'Privacy & Terms of Use' }
                        ].map((item) => (
                            <Box mb={2} display="flex" key={item.text}>
                                <Link href="#" underline="none">
                                    <Box display="flex" alignItems="center">
                                        <Box fontSize="lg.fontSize" color="common.white" mr={1}>
                                            {item.text}
                                        </Box>
                                        <ChevronRight strokeWidth="2" color="white" size={14} />
                                    </Box>
                                </Link>
                            </Box>
                        ))}
                    </Box>
                </Grid>
            </Grid>
        </Box>
    );
};
Footer.propTypes = {
    width: PropTypes.string
};
export default withWidth()(Footer);
