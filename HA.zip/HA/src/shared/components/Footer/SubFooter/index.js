export { default } from './SubFooter';
