import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    companyName: {
        [theme.breakpoints.up('md')]: {
            display: 'flex',
            marginBottom: '8px'
        }
    },
    subFooterWrapper: {
        [theme.breakpoints.up('md')]: {
            padding: '20px 56px 12px 56px'
        }
    },
    poweredByText: {
        [theme.breakpoints.up('md')]: {
            flexDirection: 'row',
            alignItems: 'center',
            lineHeight: 'normal',
            marginBottom: '8px'
        }
    },
    breaker: {
        [theme.breakpoints.up('md')]: {
            display: 'flex'
        }
    }
}));

export default useStyles;
