import { Box } from '@material-ui/core';
import Image from 'next/image';
import React from 'react';
import useStyles from './SubFooterStyles';

/**
 * Name : SubFooter
 * Desc : Render SubFooter
 */

const SubFooter = () => {
    const classes = useStyles();

    return (
        <Box bgcolor="button.secondaryColor" p={3} className={classes.subFooterWrapper}>
            <Box display="flex" alignItems="center" justifyContent="space-between" flexWrap="wrap">
                <Box display="none" alignItems="center" className={classes.companyName}>
                    <Box display="flex" justifyContent="center" mr={2}>
                        <Image src="/home.svg" width={40} height={37} />
                    </Box>
                    <Box color="common.white" fontSize="h6.fontSize">
                        We’re a proud equal housing opportunity provider.
                    </Box>
                </Box>
                <Box
                    display="flex"
                    alignItems="flex-start"
                    flexDirection="column"
                    lineHeight="28px"
                    className={classes.poweredByText}>
                    <Box color="common.white" fontSize="md.fontSize">
                        ©2021 Housing Authority of the City of El Paso
                    </Box>
                    <Box
                        display="none"
                        color="common.white"
                        fontSize="md.fontSize"
                        pl={0.8}
                        pr={0.8}
                        className={classes.breaker}>
                        |
                    </Box>
                    <Box color="common.white" fontSize="md.fontSize">
                        Powered by AppName
                    </Box>
                </Box>
            </Box>
        </Box>
    );
};

export default SubFooter;
