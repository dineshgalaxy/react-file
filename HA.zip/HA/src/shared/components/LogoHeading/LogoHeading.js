import { Box } from '@material-ui/core';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from './LogoHeadingStyles';

/**
 * Name : LogoHeading
 * Desc : Render LogoHeading
 * @param  {string}  labelName
 * @param  {string}  title
 * @param  {boolean}  isLoggedIn
 * @param  {string}  breakPoint
 */

const LogoHeading = ({ title, labelName, isLoggedIn, breakPoint }) => {
    const classes = useStyles();
    const color = isLoggedIn ? 'common.white' : 'primary.light';
    const subTextColor = isLoggedIn ? 'common.white' : 'primary.light';
    return (
        <Box display="flex" flexDirection="column">
            <>
                <Box
                    fontSize="h4.fontSize"
                    fontFamily="fontFamily.extraBold"
                    color={color}
                    overflow="hidden"
                    whiteSpace="nowrap"
                    maxWidth="350px"
                    textOverflow="ellipsis"
                    className={classes.title}>
                    {!isLoggedIn || breakPoint ? title : ''}
                </Box>
                <Box
                    display="none"
                    fontSize="body5.fontSize"
                    letterSpacing="4px"
                    color={subTextColor}
                    className={classes.labelName}>
                    {labelName}
                </Box>
            </>
        </Box>
    );
};

LogoHeading.defaultProps = {};
LogoHeading.propTypes = {
    title: PropTypes.string,
    labelName: PropTypes.string,
    isLoggedIn: PropTypes.bool,
    breakPoint: PropTypes.bool
};

export default LogoHeading;
