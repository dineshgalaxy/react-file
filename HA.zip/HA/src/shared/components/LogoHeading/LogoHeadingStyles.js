import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    labelName: {
        [theme.breakpoints.up('lg')]: {
            display: 'block'
        }
    },
    title: {
        [theme.breakpoints.up('lg')]: {
            fontSize: theme.typography.h2.fontSize
        }
    }
}));

export default useStyles;
