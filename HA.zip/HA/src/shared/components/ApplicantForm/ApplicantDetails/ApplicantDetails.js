import { Box, Button, FormControl, TextField } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { useSelector } from 'react-redux';
import useStyles from './ApplicantDetailsStyle';
import FormErrorMessage from '~/shared/components/FormErrorMessage';
import { saveProfile } from '~/modules/CreateProfileModule/Utils/CreateProfileAction';
import useForm from '~/shared/customHooks/useForm';
import { FIELDS } from './ApplicantDetailsConstants';
import { onValidate } from './ApplicantDetailsUtils';

/**
 * Name : ApplicantDetails
 * Desc : Render ApplicantDetails
 */

const ApplicantDetails = ({ title, onClickContinue, showFaceBookLoginButton, width }) => {
    const classes = useStyles();
    const { user_profile_data = {} } = useSelector((state) => state.profileSteps);

    const initialValue = {
        [FIELDS.FIRST_NAME]: user_profile_data[FIELDS.FIRST_NAME] ? user_profile_data[FIELDS.FIRST_NAME] : '',
        [FIELDS.MIDDLE_NAME]: user_profile_data[FIELDS.MIDDLE_NAME] ? user_profile_data[FIELDS.MIDDLE_NAME] : '',
        [FIELDS.LAST_NAME]: user_profile_data[FIELDS.LAST_NAME] ? user_profile_data[FIELDS.LAST_NAME] : '',
        [FIELDS.EMAIL]: user_profile_data[FIELDS.EMAIL] ? user_profile_data[FIELDS.EMAIL] : '',
    };
    const { values, handleOnChange, handleSubmit, handleBlur, errors } = useForm(
        initialValue,
        onValidate
    );
    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onClickContinue(saveProfile, values);
        }
    };

    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337} mb={1}>
                <Box fontSize="h5.fontSize" lineHeight="35px" color="primary.light" mb={1.5}>
                    {title}
                </Box>
            </Box>
            <form onSubmit={(e) => handleFormSubmit(e)}>    
                <Box className={classes.textAlign} width="100%">
                    <Box mb={1}>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.FIRST_NAME}
                                value={values[FIELDS?.FIRST_NAME]}
                                inputProps={{ maxLength: 100 }}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                label={
                                    <Box display="flex" alignItems="center">
                                        First Name<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                variant="filled"
                                error={errors[FIELDS?.FIRST_NAME]}
                                helperText={errors[FIELDS?.FIRST_NAME] ?
                                    (<FormErrorMessage title={errors[FIELDS?.FIRST_NAME]}/>) : null
                                }
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                             name={FIELDS?.MIDDLE_NAME}
                             value={values[FIELDS?.MIDDLE_NAME]}
                             inputProps={{ maxLength: 100  }}
                             onChange={handleOnChange} 
                             onBlur={handleBlur}
                             onKeyUp={handleBlur}
                             label="Middle Name" 
                             variant="filled" />
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.LAST_NAME}
                                value={values[FIELDS?.LAST_NAME]}
                                inputProps={{ maxLength: 100  }}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                label={
                                    <Box display="flex" alignItems="center">
                                        Last Name<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                variant="filled"
                                error={errors[FIELDS?.LAST_NAME]}
                                helperText={errors[FIELDS?.LAST_NAME] ?
                                    (<FormErrorMessage title={errors[FIELDS?.LAST_NAME]}/>) : null
                                }
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS.EMAIL}
                                value={values[FIELDS?.EMAIL]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                label={
                                    <Box display="flex" alignItems="center">
                                        Email Address<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                variant="filled"
                                error={errors[FIELDS?.EMAIL]}
                                helperText={errors[FIELDS?.EMAIL] ?
                                    (<FormErrorMessage title={errors[FIELDS?.EMAIL]}/>) : null
                                }
                            />
                        </FormControl>
                    </Box>

                    <Box className={classes.xsBtn}>
                        <Button
                            type='submit'
                            size="large"
                            color="primary"
                            variant="contained"
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={clsx(
                                width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                                showFaceBookLoginButton && 'facebooKBtn'
                            )}>
                            {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                        </Button>
                    </Box>
                </Box>
            </form>
        </Box>
    );
};

ApplicantDetails.defaultProps = {
    title: '',
    showFaceBookLoginButton: false
};

ApplicantDetails.propTypes = {
    title: PropTypes.string,
    showFaceBookLoginButton: PropTypes.bool,
    onClickContinue: PropTypes.func,
    width: PropTypes.string
};

export default withWidth()(ApplicantDetails);
