export const FIELDS = {
    FIRST_NAME : 'fname',
    MIDDLE_NAME : 'mname',
    LAST_NAME : 'lname',
    EMAIL : 'email',
};
