export { default } from './ApplicantDetails';
