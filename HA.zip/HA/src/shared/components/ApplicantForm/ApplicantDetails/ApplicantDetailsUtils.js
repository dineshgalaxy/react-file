import { FIELDS } from './ApplicantDetailsConstants';

export const onValidate = (values) => {
    const errors = {};
    if (!values[FIELDS?.FIRST_NAME]) {
        errors[FIELDS?.FIRST_NAME] = 'Please enter your name.';
    } else if (values[FIELDS?.FIRST_NAME] && !/^[a-zA-Z]+$/.test(String(values[FIELDS?.FIRST_NAME]).toLocaleLowerCase())) {
        errors[FIELDS?.FIRST_NAME] = 'Please enter valid name.';
    }

    if (!values[FIELDS?.LAST_NAME]) {
        errors[FIELDS?.LAST_NAME] = 'Please enter your last name.';
    } else if (values[FIELDS?.LAST_NAME] && !/^[a-zA-Z]+$/.test(String(values[FIELDS?.LAST_NAME]).toLocaleLowerCase())) {
        errors[FIELDS?.LAST_NAME] = 'Please enter valid last name.';
    } 
    
    if (!values[FIELDS?.EMAIL]) {
        errors[FIELDS?.EMAIL] = 'Please enter your email.';
    } else if (values[FIELDS?.EMAIL] && !/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(String(values[FIELDS?.EMAIL]).toLocaleLowerCase())) {
        errors[FIELDS?.EMAIL] = 'Please enter valid email.';
    } 
    return errors;
};
