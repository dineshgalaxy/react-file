export { default } from './ApplicantTrustedContact';
