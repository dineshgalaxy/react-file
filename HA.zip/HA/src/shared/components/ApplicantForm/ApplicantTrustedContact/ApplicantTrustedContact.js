import { Box, FormControl, TextField } from '@material-ui/core';
import React from 'react';

/**
 * Name : ApplicantTrustedContact
 * Desc : Render ApplicantTrustedContact
 */

const ApplicantTrustedContact = () => {
    return (
        <Box>
            <FormControl fullWidth>
                <TextField
                    id="standard-basic"
                    label={
                        <Box display="flex" alignItems="center">
                            Your First Name<Box color="primary.main">*</Box>
                        </Box>
                    }
                    variant="filled"
                />
            </FormControl>
            <FormControl fullWidth>
                <TextField id="standard-basic" label="Middle Name" variant="filled" />
            </FormControl>
            <FormControl fullWidth>
                <TextField
                    id="standard-basic"
                    label={
                        <Box display="flex" alignItems="center">
                            Your Last Name<Box color="primary.main">*</Box>
                        </Box>
                    }
                    variant="filled"
                />
            </FormControl>
            <FormControl fullWidth>
                <TextField
                    id="standard-basic"
                    label={
                        <Box display="flex" alignItems="center">
                            Your Email Address<Box color="primary.main">*</Box>
                        </Box>
                    }
                    variant="filled"
                />
            </FormControl>
            <FormControl fullWidth>
                <TextField
                    id="standard-basic"
                    label={
                        <Box display="flex" alignItems="center">
                            Your Telephone Number<Box color="primary.main">*</Box>
                        </Box>
                    }
                    variant="filled"
                />
            </FormControl>
        </Box>
    );
};

export default ApplicantTrustedContact;
