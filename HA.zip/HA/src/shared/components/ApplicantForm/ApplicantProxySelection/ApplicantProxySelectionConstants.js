export const FIELDS = {
    ROLE_ID : 'role_id',
    LANGUAGE_SELECTED : 'language_selected',
    IS_PROXY: 'is_proxy',
    PROXY_FIRST_NAME: 'proxy_fname',
    PROXY_LAST_NAME: 'proxy_lname',
    PROXY_EMAIL: 'proxy_email',
    PROXY_TELEPHONE: 'proxy_telephone',
};
