import { FIELDS } from './ApplicantProxySelectionConstants';
export const onValidate = (values) => {
    const errors = {};
    if (!values[FIELDS?.IS_PROXY]) {
        errors.IS_PROXY = 'This is required field.';
    }

    return errors;
};
