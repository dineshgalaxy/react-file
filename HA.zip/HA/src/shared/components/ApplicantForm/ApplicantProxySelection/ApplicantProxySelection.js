import { 
    Box, 
    Button, 
    FormControl, 
    FormControlLabel, 
    FormHelperText, 
    Radio, 
    RadioGroup 
} from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from './ApplicantProxySelectionStyle';
import { saveProfile } from '~/modules/CreateProfileModule/Utils/CreateProfileAction';
import useForm from '~/shared/customHooks/useForm';
import { FIELDS } from './ApplicantProxySelectionConstants';
import { onValidate } from './ApplicantProxySelectionUtils';

/**
 * Name : ApplicantProxySelection
 * Desc : Render ApplicantProxySelection
 */

const ApplicantProxySelection = ({ width, title, onClickContinue, showFaceBookLoginButton }) => {
    const classes = useStyles();
    const defaultValue = "false";
    const initialValue = {
        [FIELDS.ROLE_ID]: "",
        [FIELDS.LANGUAGE_SELECTED]: "",
        [FIELDS.IS_PROXY]: defaultValue,
        [FIELDS.PROXY_FIRST_NAME]: '',
        [FIELDS.PROXY_LAST_NAME]: '',
        [FIELDS.PROXY_EMAIL]: '',
        [FIELDS.PROXY_TELEPHONE]: '',
    };
    const { values, handleOnChange, handleSubmit, errors } = useForm(
        initialValue,
        onValidate
    );
    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onClickContinue(saveProfile, values);
        }
    };

    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337} mb={1}>
                <Box fontSize="h5.fontSize" lineHeight="35px" color="primary.light" mb={1.5}>
                    {title}
                </Box>
            </Box>
            <Box className={classes.textAlign} width="100%">
                <form onSubmit={(e) => handleFormSubmit(e)}>
                    <Box mb={0.5} mt={3}>
                        <FormControl component="fieldset">
                            <RadioGroup 
                                aria-label="proxy" 
                                name={FIELDS.IS_PROXY} 
                                defaultValue={defaultValue} 
                                error={!!errors.IS_PROXY}>
                                <Box mb={2.25}>
                                    <FormControlLabel
                                        onChange={handleOnChange}
                                        value="false"
                                        control={<Radio className="extraLightLabel"/>}
                                        label="I’m applying for myself"
                                    />
                                </Box>
                                <FormControlLabel
                                    onChange={handleOnChange}
                                    value="true"
                                    control={<Radio className="extraLightLabel"/>}
                                    label="I’m a family member or other individual assisting with the application"
                                />
                            </RadioGroup>
                            {errors[FIELDS.IS_PROXY] ? (
                                <FormHelperText>{errors[FIELDS.IS_PROXY]}</FormHelperText>
                            ) : (
                                ''
                            )}
                        </FormControl>
                    </Box>
                    <Box className={classes.xsBtn}>
                        <Button
                            type="submit"
                            size="large"
                            color="primary"
                            variant="contained"
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={clsx(
                                width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                                showFaceBookLoginButton && 'facebooKBtn'
                            )}>
                            {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                        </Button>
                    </Box>
                </form>
            </Box>
        </Box>
    );
};

ApplicantProxySelection.defaultProps = {
    title: '',
    showFaceBookLoginButton: false
};

ApplicantProxySelection.propTypes = {
    title: PropTypes.string,
    showFaceBookLoginButton: PropTypes.bool,
    onClickContinue: PropTypes.func,
    width: PropTypes.string
};

export default withWidth()(ApplicantProxySelection);
