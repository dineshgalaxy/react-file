import { FIELDS } from './AccountCredentialsConstatns';
export const onValidate = (values) => {
    const errors = {};
    if (!values[FIELDS?.PASSWORD]) {
        errors[FIELDS?.PASSWORD] = 'Please enter password.';
    } else if (values[FIELDS?.PASSWORD]  && !/^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,}$/.test(values[FIELDS?.PASSWORD])) {
        errors[FIELDS?.PASSWORD] = 'Minimum eight characters, at least one uppercase letter, one lowercase letter, one number and one special character';
    } else if (!values[FIELDS?.CONFIRM_PASSWORD]) {
        errors[FIELDS?.CONFIRM_PASSWORD] = 'Please enter confirm password.';
    } else if (values[FIELDS?.PASSWORD] !== values[FIELDS?.CONFIRM_PASSWORD]) {
        errors[FIELDS?.CONFIRM_PASSWORD] = 'Password confirmation does not match.';
    }
    return errors;
};
