import { Box, Button, FormControl, TextField } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { saveProfile } from '~/modules/CreateProfileModule/Utils/CreateProfileAction';
import FormErrorMessage from '~/shared/components/FormErrorMessage';
import useForm from '~/shared/customHooks/useForm';
import { FIELDS } from './AccountCredentialsConstatns';
import useStyles from './AccountCredentialsStyle';
import { onValidate } from './AccountCredentialsUtils';

/**
 * Name : AccountCredentials
 * Desc : Render AccountCredentials
 */

const AccountCredentials = ({ title, onClickContinue, showFaceBookLoginButton, width }) => {
    const classes = useStyles();
    const initialValue = {
        [FIELDS.PASSWORD]: '',
        [FIELDS.CONFIRM_PASSWORD]: ''
    };
    const { values, handleOnChange, handleSubmit, handleBlur, errors } = useForm(
        initialValue,
        onValidate
    );
    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onClickContinue(saveProfile, values);
        }
    };

    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337} mb={1}>
                <Box fontSize="h5.fontSize" lineHeight="35px" color="primary.light" mb={1.5}>
                    {title}
                </Box>
            </Box>
            <form onSubmit={(e) => handleFormSubmit(e)}>
                <Box className={classes.textAlign} width="100%">
                    <Box>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.PASSWORD}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                type="password"
                                label={
                                    <Box display="flex" alignItems="center">
                                        Password<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                variant="filled"
                                error={errors[FIELDS?.PASSWORD]}
                                helperText={
                                    errors[FIELDS?.PASSWORD] ? (
                                        <FormErrorMessage title={errors[FIELDS?.PASSWORD]} />
                                    ) : null
                                }
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.CONFIRM_PASSWORD}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="confirm-password"
                                type="password"
                                label={
                                    <Box display="flex" alignItems="center">
                                        Confirm password<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                variant="filled"
                                error={errors[FIELDS?.CONFIRM_PASSWORD]}
                                helperText={
                                    errors[FIELDS?.CONFIRM_PASSWORD] ? (
                                        <FormErrorMessage
                                            title={errors[FIELDS?.CONFIRM_PASSWORD]}
                                        />
                                    ) : null
                                }
                            />
                        </FormControl>
                        <Box mb={2}>
                            <Button
                                type="submit"
                                size="large"
                                color="primary"
                                variant="contained"
                                fullWidth={width === 'xs' || width === 'sm' ? true : false}>
                                Save Password
                            </Button>
                        </Box>
                        <Box
                            fontSize="lg.fontSize"
                            color="primary.extraLight"
                            mb={width === 'xs' || width === 'sm' ? -2.5 : 2}
                            mt={3}
                            textAlign="center">
                            Or, you can:
                        </Box>
                    </Box>

                    <Box className={classes.xsBtn}>
                        <Button
                            size="large"
                            color="primary"
                            variant="contained"
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={clsx(
                                width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                                showFaceBookLoginButton && 'facebooKBtn'
                            )}>
                            {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                        </Button>
                    </Box>
                </Box>
            </form>
        </Box>
    );
};

AccountCredentials.defaultProps = {
    title: {},
    showFaceBookLoginButton: false
};

AccountCredentials.propTypes = {
    title: PropTypes.object,
    showFaceBookLoginButton: PropTypes.bool,
    onClickContinue: PropTypes.func,
    width: PropTypes.string
};

export default withWidth()(AccountCredentials);
