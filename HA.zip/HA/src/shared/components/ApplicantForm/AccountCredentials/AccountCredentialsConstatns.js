export const FIELDS = {
    PASSWORD : 'password',
    CONFIRM_PASSWORD : 'confirm_password'
};
