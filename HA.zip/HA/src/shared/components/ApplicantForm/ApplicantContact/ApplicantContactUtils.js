import { FIELDS } from './ApplicantContactConstants';
export const onValidate = (values) => {
    const errors = {};
    if (!values[FIELDS?.CELLPHONE]) {
        errors[FIELDS?.CELLPHONE] = 'Please enter your telephone number.';
    }else if (values[FIELDS?.CELLPHONE]  && !/(^[+]?[(]?[0-9]{3}[)]?[-\s.]?[0-9]{3}[-\s.]?[0-9]{4,4}$)/.test(values[FIELDS?.CELLPHONE])) {
        errors[FIELDS?.CELLPHONE] = 'Invalid telephone number.';
    } 
    if (!values[FIELDS?.ADDRESS_1]) {
        errors[FIELDS?.ADDRESS_1] = 'Address is required.';
    } 
    if (!values[FIELDS?.CITY]) {
        errors[FIELDS?.CITY] = 'City is required.';
    } 
    if (!values[FIELDS?.STATE]) {
        errors[FIELDS?.STATE] = 'State is required.';
    } 
    if (!values[FIELDS?.ZIP]) {
        errors[FIELDS?.ZIP] = 'Zip is required.';
    } else if (values[FIELDS?.ZIP]  && !/(^\d{5}$)|(^\d{5}-\d{4}$)/.test(values[FIELDS?.ZIP])) {
        errors[FIELDS?.ZIP] = 'Invalid zip code.';
    } 
    return errors;
};