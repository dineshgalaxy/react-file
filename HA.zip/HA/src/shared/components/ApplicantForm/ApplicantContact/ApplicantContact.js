import {
    Box,
    Button,
    Checkbox,
    FormControl,
    FormControlLabel,
    InputLabel,
    MenuItem,
    Select,
    TextField
} from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import ExpandMoreOutlinedIcon from '@material-ui/icons/ExpandMoreOutlined';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { useSelector } from 'react-redux';
import { saveProfile } from '~/modules/CreateProfileModule/Utils/CreateProfileAction';
import FormErrorMessage from '~/shared/components/FormErrorMessage';
import useForm from '~/shared/customHooks/useForm';
import { FIELDS } from './ApplicantContactConstants';
import useStyles from './ApplicantContactStyle';
import { onValidate } from './ApplicantContactUtils';

/**
 * Name : ApplicantContact
 * Desc : Render ApplicantContact
 */

const ApplicantContact = ({
    title,
    onClickContinue,
    showFaceBookLoginButton,
    stateList,
    phoneTypeList,
    contactByList,
    width
}) => {
    const classes = useStyles();
    const { user_profile_data = {} } = useSelector((state) => state.profileSteps);
    const initialValue = {
        [FIELDS.CELLPHONE]: user_profile_data[FIELDS.CELLPHONE] ? user_profile_data[FIELDS.CELLPHONE] : '',
        [FIELDS.CELLPHONE_TYPE]: user_profile_data[FIELDS.CELLPHONE_TYPE] ? user_profile_data[FIELDS.CELLPHONE_TYPE] : '',
        [FIELDS.LANDLINE]: user_profile_data[FIELDS.LANDLINE] ? user_profile_data[FIELDS.LANDLINE] : '',
        [FIELDS.LANDLINE_TYPE]: user_profile_data[FIELDS.LANDLINE_TYPE] ? user_profile_data[FIELDS.LANDLINE_TYPE] : '',
        [FIELDS.ADDRESS_1]: user_profile_data[FIELDS.ADDRESS_1] ? user_profile_data[FIELDS.ADDRESS_1] : '',
        [FIELDS.ADDRESS_2]: user_profile_data[FIELDS.ADDRESS_2] ? user_profile_data[FIELDS.ADDRESS_2] : '',
        [FIELDS.CITY]: user_profile_data[FIELDS.CITY] ? user_profile_data[FIELDS.CITY] : '',
        [FIELDS.STATE]: user_profile_data[FIELDS.STATE] ? user_profile_data[FIELDS.STATE] : '',
        [FIELDS.ZIP]: user_profile_data[FIELDS.ZIP] ? user_profile_data[FIELDS.ZIP] : ''
    };
    const { values, handleOnChange, handleSubmit, handleBlur, errors } = useForm(
        initialValue,
        onValidate
    );
    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onClickContinue(saveProfile, values);
        }
    };

    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337} mb={1}>
                <Box fontSize="h5.fontSize" lineHeight="35px" color="primary.light" mb={1.5}>
                    {title}
                </Box>
            </Box>
            <form onSubmit={(e) => handleFormSubmit(e)}>
                <Box className={classes.textAlign} width="100%">
                    <Box mb={1}>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">Type</InputLabel>
                            <Select
                                name={FIELDS?.CELLPHONE_TYPE}
                                value={values[FIELDS?.CELLPHONE_TYPE]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                IconComponent={ExpandMoreOutlinedIcon}
                                label={
                                    <Box display="flex" alignItems="center">
                                        Primary Telephone Number<Box color="primary.main">*</Box>
                                    </Box>
                                }>
                                <MenuItem value="" disabled>
                                    Select
                                </MenuItem>
                                {phoneTypeList.phone_types && phoneTypeList.phone_types.map(({ id, type }) => (
                                    <MenuItem value={id} key={id}>
                                        {type}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.CELLPHONE}
                                value={values[FIELDS?.CELLPHONE]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                inputProps={{ maxLength: 13 }}
                                label={
                                    <Box display="flex" alignItems="center">
                                        Primary Telephone Number<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                variant="filled"
                                error={errors[FIELDS?.CELLPHONE]}
                                helperText={
                                    errors[FIELDS?.CELLPHONE] ? (
                                        <FormErrorMessage title={errors[FIELDS?.CELLPHONE]} />
                                    ) : null
                                }
                            />
                        </FormControl>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">Type</InputLabel>
                            <Select
                                name={FIELDS?.LANDLINE_TYPE}
                                value={values[FIELDS?.LANDLINE_TYPE]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                IconComponent={ExpandMoreOutlinedIcon}>
                                <MenuItem value="" disabled>
                                    Select
                                </MenuItem>
                                {phoneTypeList?.phone_types ? phoneTypeList.phone_types.map(({ id, type }) => (
                                    <MenuItem value={id} key={id}>
                                        {type}
                                    </MenuItem>
                                )) : null}
                            </Select>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.LANDLINE}
                                value={values[FIELDS?.LANDLINE]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                inputProps={{ maxLength: 13 }}
                                IconComponent={ExpandMoreOutlinedIcon}
                                label={
                                    <Box component="span">
                                        Other Telephone Number (optional)
                                        <Box color="primary.main" component="span">
                                            *
                                        </Box>
                                    </Box>
                                }
                                variant="filled"
                            />
                        </FormControl>

                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.ADDRESS_1}
                                value={values[FIELDS?.ADDRESS_1]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                label="Current Address"
                                variant="filled"
                                error={errors[FIELDS?.ADDRESS_1]}
                                helperText={
                                    errors[FIELDS?.ADDRESS_1] ? (
                                        <FormErrorMessage title={errors[FIELDS?.ADDRESS_1]} />
                                    ) : null
                                }
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.ADDRESS_2}
                                value={values[FIELDS?.ADDRESS_2]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                label="Current Address Line 2"
                                variant="filled"
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.CITY}
                                value={values[FIELDS?.CITY]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                label="City"
                                variant="filled"
                                error={errors[FIELDS?.CITY]}
                                helperText={
                                    errors[FIELDS?.CITY] ? (
                                        <FormErrorMessage title={errors[FIELDS?.CITY]} />
                                    ) : null
                                }
                            />
                        </FormControl>
                        <FormControl variant="filled" fullWidth error={!!errors.STATE}>
                            <InputLabel id="demo-simple-select-label">State</InputLabel>
                            <Select
                                name={FIELDS?.STATE}
                                value={values[FIELDS?.STATE]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                IconComponent={ExpandMoreOutlinedIcon}
                                label="Current Address">
                                <MenuItem value="" disabled>
                                    Select
                                </MenuItem>
                                {stateList?.states &&
                                    stateList.states.map(({ id, state }) => (
                                        <MenuItem value={id} key={id}>
                                            {state}
                                        </MenuItem>
                                    ))}
                            </Select>
                            {errors[FIELDS.STATE] ? (
                                <FormErrorMessage title={errors[FIELDS?.STATE]} />
                            ) : (
                                ''
                            )}
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                name={FIELDS?.ZIP}
                                value={values[FIELDS?.ZIP]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                onKeyUp={handleBlur}
                                id="standard-basic"
                                label="Zipe Code"
                                variant="filled"
                                error={errors[FIELDS?.ZIP]}
                                helperText={
                                    errors[FIELDS?.ZIP] ? (
                                        <FormErrorMessage title={errors[FIELDS?.ZIP]} />
                                    ) : null
                                }
                            />
                        </FormControl>
                        <Box
                            mt={2.5}
                            mb={2}
                            color="primary.light"
                            fontSize="h5.fontSize"
                            lineHeight="35px">
                            What are the best ways for us to contact you?
                        </Box>
                        {contactByList?.contact_options && contactByList.contact_options.map(({ id, options }) => (
                            <FormControl key={id} fullWidth className="noMargin">
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            value={id}
                                            inputProps={{ 'aria-label': 'primary checkbox' }}
                                        />
                                    }
                                    label={options}
                                />
                            </FormControl>
                        ))}
                    </Box>

                    <Box className={classes.xsBtn}>
                        <Button
                            type="submit"
                            size="large"
                            color="primary"
                            variant="contained"
                            // onClick={onClickContinue}
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={clsx(
                                width === 'xs' || width === 'sm' ? 'semiBorder' : '',
                                showFaceBookLoginButton && 'facebooKBtn'
                            )}>
                            {showFaceBookLoginButton ? 'Sign Up with Facebook' : 'Next'}
                        </Button>
                    </Box>
                </Box>
            </form>
        </Box>
    );
};

ApplicantContact.defaultProps = {
    title: '',
    showFaceBookLoginButton: false,
    stateList: [],
    phoneTypeList: [],
    contactByList: []
};

ApplicantContact.propTypes = {
    title: PropTypes.string,
    showFaceBookLoginButton: PropTypes.bool,
    onClickContinue: PropTypes.func,
    stateList: PropTypes.array,
    phoneTypeList: PropTypes.array,
    contactByList: PropTypes.array,
    width: PropTypes.string
};

export default withWidth()(ApplicantContact);