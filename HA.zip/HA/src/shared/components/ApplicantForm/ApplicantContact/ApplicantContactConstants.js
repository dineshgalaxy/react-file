export const FIELDS = {
    CELLPHONE : 'cellphone',
    CELLPHONE_TYPE : 'cellphone_type',
    LANDLINE : 'landline',
    LANDLINE_TYPE : 'landline_type',
    ADDRESS_1 : 'address_1',
    ADDRESS_2 : 'address_2',
    CITY : 'city',
    STATE : 'state',
    ZIP : 'zipcode',
};
