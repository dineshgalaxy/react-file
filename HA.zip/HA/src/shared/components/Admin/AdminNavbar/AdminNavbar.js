import * as React from 'react';
import { Box, IconButton, Badge } from '@material-ui/core';
import { Button } from 'semantic-ui-react';
import propTypes from 'prop-types';
import AccountCircle from '@material-ui/icons/AccountCircle';
import NotificationsIcon from '@material-ui/icons/Notifications';
import useStyles from './AdminNavbarStyles';
import Router from 'next/router';
import { ROUTES } from '~/shared/constants/routesConstants';
import withLoader from '~/shared/components/hoc/withLoader';
import { useToasts } from 'react-toast-notifications';
import { logout } from '~/modules/Admin/Login/Utils/LoginApiUtils';

/**
 * Name: AdminNavbar
 * Desc: Render AdminNavbar
 */

const AdminNavbar = ({ setLoading }) => {
    const { addToast } = useToasts();
    const classes = useStyles();

    const handleProfileMenuOpen = () => {
        // eslint-disable-next-line no-console
        console.log('To be implemented');
    };

    const handleUserLogout = async () => {
        setLoading(true);
        try {
            const { res_data } = await logout();
            localStorage.clear();
            Router.push(ROUTES.SUPERVISOR_LOGIN.ROUTE);
            addToast(res_data.message, { appearance: 'success' });
            setLoading(false);
        } catch (e) {
            setLoading(false);
        }
    };

    return (
        <>
            <Box
                display="flex"
                alignItems="center"
                justifyContent="flex-end"
                color="text.primary"
                p="12px"
                className={classes.root}>
                <IconButton
                    size="medium"
                    style={{ marginRight: '8px' }}
                    aria-label="show 17 new notifications"
                    color="inherit">
                    <Badge badgeContent={7} color="error">
                        <NotificationsIcon />
                    </Badge>
                </IconButton>
                <IconButton
                    size="medium"
                    style={{ marginRight: '8px' }}
                    edge="end"
                    aria-label="account of current user"
                    aria-haspopup="true"
                    onClick={handleProfileMenuOpen}
                    color="inherit">
                    <AccountCircle />
                </IconButton>
                <Button
                    size="small"
                    icon="sign-out"
                    label={{ as: 'a', basic: true, content: 'Logout' }}
                    labelPosition="left"
                    onClick={handleUserLogout}
                    color="blue"
                />
            </Box>
        </>
    );
};

AdminNavbar.propTypes = {
    setLoading: propTypes.func
};

export default withLoader(AdminNavbar);
