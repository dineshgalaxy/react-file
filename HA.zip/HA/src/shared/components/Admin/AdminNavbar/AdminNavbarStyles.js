import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        borderBottom: `${theme.spacing(4)}px`,
        boxShadow: theme.shadows[1],
        backgroundColor: '#ffffff',
        position: 'fixed',
        top: '0',
        right: '0',
        left: '0',
        zIndex: '50'

    },
    logoutbtn: {
        backgroundColor: '#1579be',
        color: '#ffffff',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
    }
}));

export default useStyles;
