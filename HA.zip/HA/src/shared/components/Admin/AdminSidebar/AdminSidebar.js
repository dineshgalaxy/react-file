import React, { useState, useEffect } from 'react';
import { Grid, Drawer, List, ListItem, ListItemText } from '@material-ui/core';
import useStyles from './AdminSidebarStyles';
import { ROUTES } from '~/shared/constants/routesConstants';
import Router from 'next/router';
import { useRouter } from 'next/router';
import clsx from 'clsx';

/**
 * Name: AdminSidebar
 * Desc: Render AdminSidebar
 */

const AdminSidebar = () => {
    const classes = useStyles();
    const location = useRouter();
    const [activePath, setActivePath] = useState('');

    useEffect(() => {
        setActivePath(location.pathname);
    }, [location]);

    const menuArray = [
        {
            linkName: 'Dashboard',
            route: ROUTES.SUPERVISOR_DASHBOARD.ROUTE
        },
        {
            linkName: 'Tenants'
        },
        {
            linkName: 'Eligibility Calculator',
            route: ROUTES.ELIGIBILITY_CALCULATOR.ROUTE
        },
        {
            linkName: 'Manage SMTP',
            route: ROUTES.MANAGE_SMTP.ROUTE
        },
        {
            linkName: 'Landlords'
        },
        {
            linkName: 'Manage Programs',
            route: ROUTES.MANAGE_PROGRAMS.ROUTE
        },
        {
            linkName: 'Manage Preapplications',
            route: ROUTES.MANAGE_PREAPPLICATION.ROUTE
        },
        {
            linkName: 'Waitlist'
        },
        {
            linkName: 'Global Settings'
        },
        {
            linkName: 'Applications'
        },
        {
            linkName: 'RTFAs'
        },
        {
            linkName: 'Vouchers'
        }
    ];

    const redirectToSpecificRoute = (route) => {
        if (route) {
            Router.push(route);
        }
    };

    return (
        <Grid item md={2}>
            <Drawer
                className={classes.drawer}
                variant="permanent"
                classes={{
                    paper: classes.drawerPaper
                }}
                anchor="left">
                <div className={classes.toolbar}>
                    <img src="/logo.png" width="100" />
                </div>

                <List>
                    {menuArray.map((text) => (
                        <ListItem
                            button
                            key={text.linkName}
                            onClick={() => redirectToSpecificRoute(text.route)}
                            className={clsx(
                                classes.listname,
                                activePath === text.route && classes.listactive
                            )}>
                            <ListItemText
                                primary={text.linkName}
                            />
                        </ListItem>
                    ))}
                </List>
            </Drawer>
        </Grid>
    );
};

export default AdminSidebar;
