import { makeStyles } from '@material-ui/core/styles';

const drawerWidth = 240;

const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex'
    },
    appBar: {
        width: `calc(100% - ${drawerWidth}px)`,
        marginLeft: drawerWidth
    },
    drawer: {
        width: drawerWidth,
        flexShrink: 0
    },
    drawerPaper: {
        width: drawerWidth,
        backgroundColor: '#0e1c29',
        zIndex: 100
    },
    // necessary for content to be below app bar
    toolbar: {
        textAlign: 'center',
        padding: '25px 0',
        ...theme.mixins.toolbar
    },
    content: {
        flexGrow: 1,
        backgroundColor: theme.palette.background.default,
        padding: theme.spacing(3)
    },
    listname: {
        color: '#ffffff',
        '&:hover': {
            backgroundColor: '#fafafa66',
            color: '#ffffff'
        }
    },
    listactive: {
        backgroundColor: '#fafafa',
        color: '#0e1c29'
    }
}));

export default useStyles;
