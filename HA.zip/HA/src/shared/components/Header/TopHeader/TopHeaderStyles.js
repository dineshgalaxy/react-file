import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    link: {
        '&:not(:last-child)': {
            marginRight:theme.spacing(6),
            position: 'relative',
            '&::after': {
                content: "'|'",
                position: 'absolute',
                right: '-26px',
                top: 0,
                bottom: 0,
                color: 'inherit'
            }
        }
    }
}));

export default useStyles;
