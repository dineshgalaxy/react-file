import { Box, IconButton, Link, Dialog } from '@material-ui/core';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { ChevronLeft, X } from 'react-feather';
import useStyles from './TopHeaderStyles';
import ExitDialogBox from '~/shared/components/ExitDialogBox';

/**
 * Name: TopHeader
 * Desc: Render TopHeader
 * @param  {bool}  isWizard
 */


const TopHeader = ({ isWizard, onClickBack, onExitClick, title=''}) => {
    const classes = useStyles();
    const breakPoint = useMediaQuery('(min-width:1152px)');
    const linkNameArray = [
        {
            linkName: 'Español'
        },
        {
            linkName: 'About'
        },
        {
            linkName: 'Landlord Portal'
        }
    ];

    const [openDialog, setOpenDialog] = useState(false);
    const handleClose = () => {
        setOpenDialog(false);
    }

    return (
        <Box
            pt={1}
            pr={breakPoint ? 6 : 1}
            pb={1}
            pl={breakPoint ? 6 : 3}
            bgcolor="menus.menuBackground">
            <Box display="flex" alignItems="center" justifyContent="space-between">
                <Box display="flex" alignItems="center" maxWidth={750}>
                    {isWizard && (
                        <Box mr={0.5}>
                            <IconButton onClick={onClickBack}>
                                <ChevronLeft strokeWidth="2" color="Indigo" size={22} />
                            </IconButton>
                        </Box>
                    )}
                    <Box
                        color="primary.light"
                        fontSize={15}
                        lineHeight="21px">
                        { title ? title : 'Housing Assistance Eligiblity and PreApplication' }
                    </Box>
                </Box>
                <Box
                    color="primary.light"
                    fontSize="lg.fontSize"
                    position="relative"
                    top="-10px"
                    display={!breakPoint ? 'flex' : 'none'}>
                    <IconButton>
                        <X strokeWidth="3" color="Black" size={15} />
                    </IconButton>
                </Box>
                <Box alignItems="center" display={breakPoint ? 'flex' : 'none'}>
                    {
                        isWizard ? (
                            <>
                                <Box className={classes.link}>
                                    <Link href="/" underline="none">
                                        <Box fontSize="body5.fontSize" color="button.secondaryColor">
                                            CANCEL APPLICATION
                                        </Box>
                                    </Link>
                                </Box>
                                <Box className={classes.link}>
                                    <Link href="#" underline="none" onClick={() => {
                                        setOpenDialog(true);
                                    }}>
                                        <Box fontSize="body5.fontSize" color="button.secondaryColor">
                                            SAVE AND EXIT
                                        </Box>
                                    </Link>
                                </Box>
                                <Dialog
                                    onClose={handleClose}
                                    aria-labelledby="simple-dialog-title"
                                    open={openDialog}>
                                    <ExitDialogBox onClose={handleClose} onConfirm={onExitClick} />
                                </Dialog>
                            </>
                        ) : (
                            <>
                                {linkNameArray.map((item) => (
                                    <Box key={item.linkName}>
                                        <Link href="#" underline="none">
                                            <Box fontSize="body5.fontSize" color="button.secondaryColor">
                                                {item.linkName}
                                            </Box>
                                        </Link>
                                    </Box>
                                ))}
                            </>
                        )
                    }
                </Box>
            </Box>
        </Box>
    );
};
TopHeader.defaultProps = {
    isWizard: false,
    title: null,
    onClickBack: PropTypes.func,
};
TopHeader.propTypes = {
    isWizard: PropTypes.bool,
    onClickBack: PropTypes.func,
    onExitClick: PropTypes.func,
    title: PropTypes.string
};
export default TopHeader;
