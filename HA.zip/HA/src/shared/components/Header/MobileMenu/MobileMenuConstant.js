import { FileText, HelpCircle, Home, Send, User } from 'react-feather';
export const beforeLoginLinkArray = [
    {
        linkName: 'About HACEP'
    },
    {
        linkName: 'Landlord Portal'
    },
    {
        linkName: 'Log Out'
    }
];

export const linkArray = [
    {
        linkName: 'Español'
    },
    {
        linkName: 'Log Out'
    }
];
export const afterLoginPagesLinkArray = [
    { text: 'Your Dashboard', icon: Home },
    { text: 'Your Applications', icon: FileText },
    { text: 'Your Account', icon: User },
    { text: 'Help Center', icon: HelpCircle }
];
export const beforeLoginPagesLinkArray = [
    { text: 'Home', icon: Home },
    { text: 'Get Started', icon: Send },
    { text: 'Our Programs', icon: FileText },
    { text: 'Help Center', icon: HelpCircle }
];
