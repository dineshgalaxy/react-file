import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    loginWrapper: {
        position: 'fixed',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        width: '100%',
        height: '100vh',
        zIndex: '99999',
        backgroundColor: theme.palette.menus.menuBackground
    },
    beforeLoginWrapper: {
        backgroundColor: theme.palette.common.white
    },
    menuButton: {
        backgroundColor: theme.common.white
    },
    topImagePosition: {
        top: '40px'
    },
    bottomImagePosition: {
        bottom: '30px'
    },
    customButton: {
        fontSize: theme.typography.h6.fontSize,
        color: theme.palette.primary.main
    }
}));

export default useStyles;
