import { Box, Button, IconButton, Link } from '@material-ui/core';
import clsx from 'clsx';
import Image from 'next/image';
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { ChevronRight, X } from 'react-feather';
import {
    afterLoginPagesLinkArray,
    beforeLoginLinkArray,
    beforeLoginPagesLinkArray,
    linkArray
} from './MobileMenuConstant';
import useStyles from './MobileMenuStyles';

/**
 * Name: MobileMenu
 * Desc: Render MobileMenu
 */

const MobileMenu = ({ beforeLogin, setMenuType }) => {
    const [openMobileMenu, setOpenMobileMenu] = useState(true);
    const classes = useStyles();

    const links = beforeLogin ? beforeLoginLinkArray : linkArray;
    const actionLinks = beforeLogin ? beforeLoginPagesLinkArray : afterLoginPagesLinkArray;

    return (
        <>
            {openMobileMenu && (
                <Box
                    className={clsx(
                        classes.loginWrapper,
                        beforeLogin && classes.beforeLoginWrapper
                    )}
                    p={3}>
                    <Box display="flex" mb={11}>
                        <IconButton
                            className={classes.menuButton}
                            onClick={() => {
                                setOpenMobileMenu(false);
                                setMenuType(false);
                            }}>
                            <X strokeWidth="3" color="Indigo" size={24} />
                        </IconButton>
                    </Box>
                    <Box>
                        {actionLinks.map((item) => (
                            <Box mb={3.5} key={item.text}>
                                <Link href="#" underline="none">
                                    <Box display="flex" alignItems="center">
                                        <item.icon strokeWidth="2" color="Indigo" size={24} />
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="primary.main"
                                            fontFamily="fontFamily.bold"
                                            ml={1.5}>
                                            {item.text}
                                        </Box>
                                    </Box>
                                </Link>
                            </Box>
                        ))}
                    </Box>
                    {beforeLogin && (
                        <Box mt={1.5} mb={6}>
                            <Button size="large" color="primary" variant="contained">
                                Log In
                            </Button>
                        </Box>
                    )}
                    <Box>
                        {links.map((item, index) => (
                            <Box display="flex" key={index} mb={0.5}>
                                <Button
                                    className={clsx('linkBtn', classes.customButton)}
                                    size="medium"
                                    endIcon={<ChevronRight color="Indigo" size={17} />}>
                                    {item.linkName}
                                </Button>
                            </Box>
                        ))}
                    </Box>
                    <Box
                        position="fixed"
                        right="-10px"
                        zIndex="-1"
                        className={
                            beforeLogin ? classes.topImagePosition : classes.bottomImagePosition
                        }>
                        <Image
                            src="/clientLogo.svg"
                            width={160}
                            height={160}
                            className={classes.image}
                        />
                    </Box>
                </Box>
            )}
        </>
    );
};
MobileMenu.propTypes = {
    beforeLogin: PropTypes.bool,
    setMenuType: PropTypes.func
};
export default MobileMenu;
