import { Box, Button, IconButton, Link } from '@material-ui/core';
import Badge from '@material-ui/core/Badge';
import useMediaQuery from '@material-ui/core/useMediaQuery';
import clsx from 'clsx';
import Image from 'next/image';
import Router from 'next/router';
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { Bell, ChevronLeft, Menu } from 'react-feather';
import LogoHeading from 'shared/components/LogoHeading';
import MobileMenu from '~/shared/components/Header/MobileMenu';
import { ROUTES } from '~/shared/constants/routesConstants';
import useStyles from './MainHeaderStyles';

/**
 * Name: MainHeader
 * Desc: Render MainHeader
 * @param  {bool}  isLoggedIn
 */

const MainHeader = ({
    isLoggedIn,
    userName,
    headerSubtitle,
    showBackBtn,
    mobileTitle,
    title,
    labelName,
    showMobileMenu
}) => {
    const [menuType, setMenuType] = useState(false);
    const showMenuBar = () => {
        setMenuType(true);
    };
    const classes = useStyles();
    const breakPoint = useMediaQuery('(min-width:1152px)');
    const color = isLoggedIn ? 'common.white' : 'primary.light';
    const buttonColor = isLoggedIn ? 'secondary' : 'primary';
    const buttonTitle = isLoggedIn ? 'Help Center' : 'Log In';
    const linkNameArray = [
        {
            linkName: 'Programs'
        },
        {
            linkName: 'Help Center'
        },
        {
            linkName: 'Get Started'
        }
    ];

    const continueToLogin = () => {
        const { USER_LOGIN } = ROUTES;
        Router.push(USER_LOGIN.ROUTE);
    };

    return (
        <Box
            padding={3}
            bgcolor="common.white"
            boxShadow={2}
            className={clsx(isLoggedIn && classes.mainHeaderWrapper)}>
            <Box
                display="flex"
                alignItems="center"
                justifyContent="space-between"
                className={showBackBtn || showMobileMenu ? classes.displayNoneXs : ''}>
                <Box display="flex" alignItems="center">
                    <Box display="flex" alignItems="center" mr={breakPoint ? 2 : 0}>
                        <Box display="none" className={classes.logoImage}>
                            <Image src="/logo.svg" width={66} height={63} />
                        </Box>
                        <Box display={breakPoint ? 'none' : 'flex'}>
                            {!showBackBtn ? (
                                <IconButton className={classes.menuButton} onClick={showMenuBar}>
                                    <Menu strokeWidth="2" color="Indigo" size={30} />
                                </IconButton>
                            ) : (
                                <IconButton className={classes.menuButton} onClick={showMenuBar}>
                                    <Menu strokeWidth="2" color="Indigo" size={24} />
                                </IconButton>
                            )}
                        </Box>
                    </Box>
                    <LogoHeading
                        title={title}
                        labelName={labelName}
                        isLoggedIn={isLoggedIn}
                        breakPoint={breakPoint}
                    />
                </Box>
                <Box display="flex" alignItems="center" pl={breakPoint ? 3 : 0}>
                    <Box
                        display="none"
                        alignItems="center"
                        mr={isLoggedIn ? 5 : 9.5}
                        className={classes.linkWrapper}>
                        {linkNameArray.map((item, index) => (
                            <Box
                                key={item.linkName}
                                mr={index !== linkNameArray.length - 1 && 8}
                                flexWrap="wrap">
                                <Link href="#" underline="none">
                                    <Box
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium"
                                        color={color}
                                        className={classes.linkName}>
                                        {item.linkName}
                                    </Box>
                                </Link>
                            </Box>
                        ))}
                    </Box>

                    {!isLoggedIn || breakPoint ? (
                        <Button
                            onClick={() => continueToLogin()}
                            size={breakPoint ? 'large' : 'small'}
                            color={buttonColor}
                            variant="contained">
                            {buttonTitle}
                        </Button>
                    ) : null}
                    {isLoggedIn ? (
                        <Box ml={3}>
                            <Badge badgeContent={4} color="error">
                                <Bell strokeWidth="3" color="white" size={26} fill="white" />
                            </Badge>
                        </Box>
                    ) : null}
                </Box>
            </Box>
            {userName && (
                <Box
                    display="flex"
                    flexDirection="column"
                    textAlign="center"
                    pt={breakPoint ? 5 : 1}
                    pb={breakPoint ? 5 : 10}
                    color="common.white"
                    className={showBackBtn ? classes.displayNoneXs : ''}>
                    <Box
                        fontWeight="700"
                        fontSize={breakPoint ? 'h1.fontSize' : 'h3.fontSize'}
                        fontFamily="fontFamily.bold"
                        pb={2}>
                        {userName}
                    </Box>
                    <Box
                        fontSize={breakPoint ? 'h5.fontSize' : 'h6.fontSize'}
                        lineHeight={breakPoint ? '35px' : '26px'}
                        color="common.white"
                        maxWidth="560px"
                        margin="0 auto">
                        {headerSubtitle}
                    </Box>
                </Box>
            )}

            {(showBackBtn || showMobileMenu) && (
                <Box
                    display="flex"
                    alignItems="center"
                    className={showBackBtn || showMobileMenu ? classes.displayBlockXs : ''}>
                    <IconButton className={classes.menuButton} onClick={showMenuBar}>
                        {showBackBtn ? (
                            <ChevronLeft strokeWidth="2" color="Indigo" size={24} />
                        ) : (
                            <Menu strokeWidth="2" color="Indigo" size={24} />
                        )}
                    </IconButton>
                    <Box
                        fontSize="h4.fontSize"
                        fontFamily="fontFamily.extraBold"
                        color={color}
                        overflow="hidden"
                        whiteSpace="nowrap"
                        maxWidth="350px"
                        textOverflow="ellipsis"
                        paddingLeft={2.4}
                        className={classes.title}>
                        {mobileTitle}
                    </Box>
                </Box>
            )}
            {menuType && <MobileMenu beforeLogin={false} setMenuType={setMenuType} />}
        </Box>
    );
};

MainHeader.defaultProps = {
    showBackBtn: false,
    mobileTitle: ' ',
    title: 'AppName',
    labelName: 'EL PASO'
};
MainHeader.propTypes = {
    isLoggedIn: PropTypes.bool,
    userName: PropTypes.string,
    headerSubtitle: PropTypes.string,
    showBackBtn: PropTypes.bool,
    mobileTitle: PropTypes.string,
    title: PropTypes.string,
    labelName: PropTypes.string,
    showMobileMenu: PropTypes.bool
};

export default MainHeader;
