import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    mainHeaderWrapper: {
        backgroundImage: 'url(/headerBg.svg)',
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'center',
        backgroundSize: 'cover',
        borderBottomLeftRadius: theme.spacing(2.63),
        borderBottomRightRadius: theme.spacing(2.63)
    },
    logoImage: {
        [theme.breakpoints.up('lg')]: {
            display: 'block'
        }
    },
    linkWrapper: {
        [theme.breakpoints.up('lg')]: {
            display: 'flex'
        }
    },
    menuButton: {
        backgroundColor: theme.common.white,
        '&:hover': {
            backgroundColor: theme.common.white
        }
    },
    linkName: {
        '&:hover': {
            color: theme.palette.success.light
        }
    },
    labelName: {
        [theme.breakpoints.up('lg')]: {
            display: 'block'
        }
    },
    title: {
        [theme.breakpoints.up('lg')]: {
            fontSize: theme.typography.h2.fontSize
        }
    },
    displayBlockXs: {
        [theme.breakpoints.up('lg')]: {
            display: 'none'
        },
        display: 'flex'
    },
    displayNoneXs: {
        [theme.breakpoints.down('md')]: {
            display: 'none'
        }
    }
}));

export default useStyles;
