import { Box } from '@material-ui/core';
import PropTypes from 'prop-types';
import React from 'react';
import { AlertTriangle } from 'react-feather';

/**
 * Name : FormErrorMessage
 * Desc : Render FormErrorMessage
 * @param { srting } title
 * @param { node } children
 */

const FormErrorMessage = ({ title, children }) => {
    return (
        <Box display="flex" mx={-1.75} pt={0.5}>
            <Box
                display="flex"
                flex="0 0 16px"
                bgcolor="error.main"
                justifyContent="center"
                alignItems="center"
                width={16}
                height={16}
                borderRadius="50%"
                color="common.white"
                mr={0.5}>
                <AlertTriangle size={9} />
                {children && children}
            </Box>
            <Box fontSize="md.fontSize" lineHeight="1" color="error.dark" pt={0.25}>
                {title}
            </Box>
        </Box>
    );
};

FormErrorMessage.propTypes = {
    title: PropTypes.string,
    children: PropTypes.node
};

export default FormErrorMessage;
