import React from 'react'
import { Chip, Box } from '@material-ui/core';
import PropTypes from 'prop-types';
import useStyles from './ChipsStyles';
import CloseOutlinedIcon from '@material-ui/icons/CloseOutlined';

/**
 * Name: Chips
 * Desc: Render Chips
 * @param { string } label
 * @param { string } color
 * @param { func } onDelete
 */

const Chips = ({ label, color, onDelete }) => {
    const classes = useStyles();
    return (
        <Box>
            <Chip
                label={label}
                color={color}
                onDelete={onDelete}
                className={classes.root}
                deleteIcon={<CloseOutlinedIcon />}
            />
        </Box>
    )
}

Chips.propTypes = {
    label: PropTypes.string,
    color: PropTypes.string,
    onDelete: PropTypes.func
}

export default Chips
