import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        '&.MuiChip-root': {
            fontSize: theme.typography.fontSize.sm,
            fontFamily: theme.typography.fontFamily.extraBold,
            border: `1px solid ${theme.palette.primary.light}`,
            height: theme.spacing(4.5),
            borderRadius: 50
        }
    }
}));

export default useStyles;
