import React from 'react';
import { Box, Typography } from '@material-ui/core';
import PropTypes from 'prop-types';

/** 
 * Name : PageHeading
 * Desc : Render PageHeading
 * @param {string} title 
 **/

const PageHeading = ({ title }) => {
    return (
        <>
           <Box color='primary.main' fontFamily='fontFamily.bold' letterSpacing={8} pb={3} className='textTransform'>
                <Typography variant="h2">
                   {title}
                </Typography>
            </Box>  
        </>
    );
};
PageHeading.defaultProps = {};
PageHeading.propTypes = {
    title: PropTypes.string,
};

export default PageHeading
