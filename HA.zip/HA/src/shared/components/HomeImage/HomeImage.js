import { Avatar } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';

/**
 * Name: HomeImage
 * Desc: Render HomeImage
 */

const HomeImage = ({ width }) => {
    return (
        <Avatar
            style={{
                height: width === 'xs' || width === 'sm' ? '200px' : '530px',
                width: '100%'
            }}
            alt="view"
            src="/heroImg.jpg"
            variant="square"
        />
    );
};
HomeImage.propTypes = {
    width: PropTypes.string
};
export default withWidth()(HomeImage);
