import { Box } from '@material-ui/core';
import PropTypes from 'prop-types';
import React from 'react';

/**
 * Name : Annotations
 * Desc : Render Annotations
 * @param { string } bgColor
 * @param { string } color
 * @param { number } minHeights
 * @param { node } children
 **/

const Annotations = ({ bgColor, color, children, minHeights }) => {
    return (
        <>
            <Box bgcolor={bgColor} color={color} padding={3.5} minHeight={minHeights}>
                {children && children}
            </Box>
        </>
    );
};

Annotations.propTypes = {
    bgColor: PropTypes.string,
    color: PropTypes.string,
    children: PropTypes.node,
    minHeights: PropTypes.number
};

export default Annotations;
