import { Box, Button, Dialog } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { ChevronRight } from 'react-feather';
import ExitDialogBox from '~/shared/components/ExitDialogBox';
import { noop } from '~/shared/utils/utils';

/**
 * Name: ExitConfirmation
 * Desc: Render ExitConfirmation
 */

const ExitConfirmation = ({ exitText, onExitClick }) => {
    const [openDialog, setOpenDialog] = useState(false);
    const handleClose = () => {
        setOpenDialog(false);
    };
   
    return (
        <Box maxWidth="1008px" margin="0 auto">
            <Box display="flex" justifyContent="flex-end" pb={5} pt={8} px={3}>
                <Button
                    style={{
                        color: 'Indigo',
                        fontSize: '15px'
                    }}
                    size="medium"
                    className="linkBtn"
                    endIcon={<ChevronRight color="Indigo" size={14} />}
                    onClick={() => {
                        setOpenDialog(true);
                    }}>
                    {exitText}
                </Button>
            </Box>
            <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={openDialog}>
                <ExitDialogBox onClose={handleClose} onConfirm={onExitClick} />
            </Dialog>
        </Box>
    );
};

ExitConfirmation.defaultProps = {
    isExitText: false,
    exitText: 'EXIT',
    onConfirm: noop
};
ExitConfirmation.propTypes = {
    handleClose: PropTypes.func,
    isExitText: PropTypes.bool,
    exitText: PropTypes.string,
    onConfirm: PropTypes.func,
    onExitClick: PropTypes.func
};
export default withWidth()(ExitConfirmation);