import { Box, Button } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';

/**
 * Name: HelpCenter
 * Desc: Render HelpCenter
 */

const HelpCenter = ({ width }) => {
    return (
        <Box
            minHeight={width === 'xs' || width === 'sm' ? 277 : 355}
            width="100%"
            display="flex"
            alignItems="center"
            justifyContent="center"
            flexDirection="column"
            textAlign="center"
            bgcolor="menus.menuBackground"
            pl={3}
            pr={3}
            py={5}>
            <Box
                color="primary.light"
                fontSize={width === 'xs' || width === 'sm' ? 'h5.fontSize' : 'h3.fontSize'}
                fontFamily="fontFamily.semiBold">
                Getting housing assistance can be a tough process.
            </Box>
            <Box color="primary.light" fontSize="h6.fontSize" pt={2} pb={3.75}>
                We’re here to help you at every step
            </Box>
            <Button size="large" color="primary" variant="contained">
                Help Center
            </Button>
        </Box>
    );
};
HelpCenter.propTypes = {
    width: PropTypes.string
};
export default withWidth()(HelpCenter);
