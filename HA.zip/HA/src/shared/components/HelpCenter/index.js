export { default } from './HelpCenter';
