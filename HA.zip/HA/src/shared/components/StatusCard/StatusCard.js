import { Avatar, Box, Button, Dialog, Grid } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import FeatherIcon from 'feather-icons-react';
import Router from 'next/router';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import {
    getMethaStatus,
    getSexOffenderStatus,
    setActiveStepIndex
} from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityAction';
import { STEPS } from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityConstants';
import ExitDialogBox from '~/shared/components/ExitDialogBox';
import Indicators from '~/shared/components/Indicators';
import { ROUTES } from '~/shared/constants/routesConstants';
import { noop } from '~/shared/utils/utils';
import useStyles from './StatusCardStyles';

/**
 * Name: StatusCard
 * Desc: Render StatusCard
 */

const StatusCard = ({
    width,
    onClickContinue,
    showImage,
    iconName,
    iconStatus,
    showButton,
    showLink,
    linkText,
    buttonText,
    buttonType,
    iconColor,
    onExitClick,
    imageUrl,
    children
}) => {
    const classes = useStyles();
    const [openDialog, setOpenDialog] = useState(false);
    const dispatch = useDispatch();
    const handleClose = () => {
        setOpenDialog(false);
    };

    const { STEP3 } = STEPS;
    useEffect(() => {
        dispatch(getMethaStatus(true));
        dispatch(getSexOffenderStatus(true));
        //Self-Invoking Functions
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    return (
        <Box className={classes.root}>
            <Box display="flex" alignItems="center" flexDirection="column">
                <Grid container spacing={3} alignItems="center">
                    {iconName ? (
                        <Grid item xs={12} md={6}>
                            <Indicators
                                status={iconStatus}
                                iconName={iconName}
                                iconColor={iconColor}
                            />
                        </Grid>
                    ) : null}

                    {showImage && (
                        <Grid item xs={12} md={6}>
                            <Box
                                display="flex"
                                justifyContent="center"
                                className={classes.imgWidth}
                                mb={width === 'xs' || width === 'sm' ? 1.5 : 0}>
                                <Avatar src={imageUrl} variant="square" />
                            </Box>
                        </Grid>
                    )}

                    <Grid item xs={12} md={6}>
                        <Box className={classes.textAlign}>
                            {children}

                            {showButton ? (
                                <Box>
                                    <Button
                                        size="large"
                                        className={buttonText === 'Exit' ? classes.exitBtn : ''}
                                        color={buttonType}
                                        variant="contained"
                                        onClick={() => {
                                            buttonText === 'Exit'
                                                ? setOpenDialog(true)
                                                : onClickContinue();
                                        }}>
                                        {buttonText || 'Continue'}
                                    </Button>
                                </Box>
                            ) : null}

                            {showLink && (
                                <Box mt={5}>
                                    <Button
                                        className="link-primary"
                                        onClick={() => {
                                            iconStatus === 'success'
                                                ? setOpenDialog(true)
                                                : iconStatus === 'failed'
                                                ? dispatch(setActiveStepIndex(STEP3))
                                                : Router.push(ROUTES.CREATE_PROFILE.ROUTE);
                                        }}
                                        endIcon={<FeatherIcon icon="chevron-right" size="20" />}>
                                        {linkText}
                                    </Button>
                                </Box>
                            )}
                        </Box>
                    </Grid>
                </Grid>
                <Dialog
                    onClose={handleClose}
                    aria-labelledby="simple-dialog-title"
                    open={openDialog}>
                    <ExitDialogBox onClose={handleClose} onConfirm={onExitClick} />
                </Dialog>
            </Box>
        </Box>
    );
};

StatusCard.defaultProps = {
    showImage: false,
    iconName: '',
    iconStatus: '',
    showLink: false,
    linkText: '',
    subTitle2: '',
    buttonType: 'secondary',
    imageUrl: '/Illo.png',
    onClickContinue: noop,
    children: null
};

StatusCard.propTypes = {
    showImage: PropTypes.bool,
    iconName: PropTypes.string,
    iconStatus: PropTypes.string,
    onClickContinue: PropTypes.func,
    width: PropTypes.string,
    showButton: PropTypes.bool,
    showLink: PropTypes.bool,
    linkText: PropTypes.string,
    buttonText: PropTypes.string,
    buttonType: PropTypes.oneOf(['primary', 'secondary']),
    iconColor: PropTypes.string,
    onExitClick: PropTypes.func,
    imageUrl: PropTypes.string,
    children: PropTypes.node
};

export default withWidth()(StatusCard);