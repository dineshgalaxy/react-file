import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundPosition: 'center',
        backgroundSize: 'cover',
        position: 'relative'
    },

    textAlign: {
        [theme.breakpoints.down('sm')]: {
            textAlign: 'center'
        }
    },

    imgWidth: {
        '& .MuiAvatar-root': {
            width: '366px',
            height: ' 336px',
            [theme.breakpoints.down('md')]: {
                width: '297px',
                height: '266px'
            }
        }
    },
    primary: {
        color: theme.palette.button.secondaryColor
    },
    secondary: {
        color: theme.palette.primary.light
    },
    white: {
        color: theme.palette.common.white
    },
    exitBtn: {
        background: '#fff',
        color: theme.palette.button.secondaryColor,
        '&:hover': {
            background: theme.common.white
        }
    }
}));

export default useStyles;
