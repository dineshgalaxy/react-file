import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    loginWrapper: {
        position: 'fixed',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        width: '100%',
        height: '100vh',
        zIndex: '99999',
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    },
}));

export default useStyles;
