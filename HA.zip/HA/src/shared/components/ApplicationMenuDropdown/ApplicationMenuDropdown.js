import { Box, Button, Link } from '@material-ui/core';
import React, { useState } from 'react';
import { ChevronRight, Trash2, Check } from 'react-feather';
import useStyles from './ApplicationMenuDropdownStyles';

/**
 * Name: ApplicationMenuDropdown
 * Desc: Render ApplicationMenuDropdown
 */


const ApplicationMenuDropdown = () => {
    const [openMobileMenu, setOpenMobileMenu] = useState(true);
    const classes = useStyles();
    const applicationLinkName = [
        { text: 'Household', icon: Check },
        { text: 'Income', icon: Check },
        { text: 'Assets', icon: Check },
        { text: 'Expenses', icon: "Check" }
    ];
    return (
        <>
        {openMobileMenu && (
            <Box className={classes.loginWrapper}>
                <Box position="relative" height="100%">
                    <Box display="flex" px={3} py={3.25} bgcolor="primary.main" justifyContent="space-between">
                        <Box 
                            fontSize="h3.fontSize"
                            color="common.white"
                            fontFamily="fontFamily.bold">
                                Your Application
                        </Box>
                        <Button
                            style={{
                                color: 'white',
                                fontSize: '15px'
                            }}
                            className='linkBtn'
                            size="medium"
                            onClick={() => setOpenMobileMenu(false)}>
                            Close
                        </Button>
                    </Box>
                    <Box p={3} bgcolor="button.secondaryColor" height="calc(100% - 165px)" overflow="auto">
                        {applicationLinkName.map((item) => (
                            <Box mb={5} key={item.text}>
                                <Link href="#" underline="none">
                                    <Box display="flex" alignItems="center" justifyContent="space-between">
                                        <Box display="flex" alignItems="center">
                                            <Box width={16} height={16} borderRadius="50%" bgcolor="secondary.main" display="flex" alignItems="center" justifyContent="center" mr={1}>
                                                <item.icon strokeWidth="3" color="indigo" size={8} />
                                            </Box>
                                            <Box
                                                fontSize="h5.fontSize"
                                                color="common.white"
                                                fontFamily="fontFamily.medium"
                                            >
                                                {item.text}
                                            </Box>
                                        </Box>
                                        <Box>
                                            <ChevronRight strokeWidth="3" color="white" size={24} />
                                        </Box>
                                    </Box>
                                </Link>
                            </Box>
                        ))}
                        <Box display="flex" pb={3}>
                            <Button
                                style={{
                                    color: '#D0FFF6',
                                    fontSize: '15px',
                                    fontFamily:'Poppins-Regular'
                                }}
                                size="medium"
                                className="linkBtn"
                                startIcon={<Trash2 color="#D0FFF6" size={16} />}
                                endIcon={<ChevronRight color="#D0FFF6" size={16} />}>
                                withdraw application 
                            </Button>
                        </Box>
                        
                    </Box>
                    <Box className={classes.xsBtn}>
                        <Button
                        style={{
                           minHeight:"73px"
                        }}
                            type="submit"
                            size="large"
                            color="secondary"
                            variant="contained"
                            fullWidth={true}
                            className="semiBorder"
                            endIcon={<ChevronRight color="indigo" size={16} />}>
                            Save & Exit Application 
                        </Button>
                    </Box>
                </Box>
            </Box>
        )}
        </>
    )
}

export default ApplicationMenuDropdown
