import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 96px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: 0,
            alignItems: 'flex-start'
        }
    },

    title: {
        borderBottom: `2px solid ${theme.common.gray}`
    }
}));

export default useStyles;
