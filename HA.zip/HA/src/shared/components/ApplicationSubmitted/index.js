export { default } from './ApplicationSubmitted';
