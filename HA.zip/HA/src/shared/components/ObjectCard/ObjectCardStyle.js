import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles(() => ({
    rootUpload: {
        '& > *': {
            margin: 0
        },
        '& .MuiButton-root': {
            width: '100%',
            padding: '0'
        },
        '& .MuiCard-root': {
            width: '100%'
        }
    },
    input: {
        display: 'none'
    },
    '.MuiButtonBase-root': {
        padding: 0
    }
}));

export default useStyles;
