export { default } from './ObjectCard';
