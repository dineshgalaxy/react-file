import { Box, Button, Card, IconButton, Menu, MenuItem } from '@material-ui/core';
import FeatherIcon from 'feather-icons-react';
import PropTypes from 'prop-types';
import React from 'react';
import { noop } from '~/shared/utils/utils';
import Indicator from '../Indicators';
import useStyles from './ObjectCardStyle';

/**
 * Name : ObjectCard
 * Desc : Render ObjectCard
 **/

const ObjectCard = (props) => {
    const { children, variant, iconName, cardType, onClick, onDelete, isMember, onEditClick, showOptionMenu } =
        props;
    const classes = useStyles();
    const [anchorEl, setAnchorEl] = React.useState(null);
    const open = Boolean(anchorEl);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleEdit = () => {
        onEditClick();
        handleClose();
    };
    const handleDelete = () => {
        onDelete();
        handleClose();
    };

    return (
        <>
            {cardType === 'objectCard' ? (
                <Card onClick={onClick}>
                    <Box display="flex" alignItems="center" px={2} py={2.5} minHeight={96}>
                        <Box>
                            <Indicator
                                size={37}
                                status={variant}
                                iconName={iconName}
                                borderWidth={3.7}
                                iconSize={18}
                            />
                        </Box>
                        {children && (
                            <Box
                                flexGrow={2}
                                display="flex"
                                flexDirection="column"
                                justifyContent="center"
                                pl={1.5}>
                                {children}
                            </Box>
                        )}
                        {showOptionMenu && (
                            <Box
                                p={0.25}
                                mr={-1.5}
                                display="flex"
                                justifyContent="center"
                                alignItems="center">
                                {isMember ? (
                                    <>
                                        <IconButton color="primary" onClick={handleClick}>
                                            <FeatherIcon icon="more-vertical" size="24" />
                                        </IconButton>
                                        <Menu
                                            id="long-menu"
                                            anchorEl={anchorEl}
                                            keepMounted
                                            open={open}
                                            onClose={handleClose}>
                                            <MenuItem onClick={handleEdit}>Edit</MenuItem>
                                            <MenuItem onClick={handleDelete}>Delete</MenuItem>
                                        </Menu>
                                    </>
                                ) : (
                                    <IconButton color="primary">
                                        <FeatherIcon icon="more-vertical" size="24" />
                                    </IconButton>
                                )}
                            </Box>
                        )}

                    </Box>
                </Card>
            ) : (
                <Box className={classes.rootUpload}>
                    <input
                        accept="image/*"
                        className={classes.input}
                        id="contained-button-file"
                        multiple
                        type="file"
                    />
                    <label htmlFor="contained-button-file">
                        <Button variant="contained" component="span">
                            <Card>
                                <Box
                                    display="flex"
                                    alignItems="center"
                                    px={2}
                                    py={1.5}
                                    minHeight={96}>
                                    <Box>
                                        <Indicator
                                            size={37}
                                            status={variant}
                                            iconName={iconName}
                                            borderWidth={3.7}
                                            iconSize={18}
                                        />
                                    </Box>
                                    {children && (
                                        <Box
                                            flexGrow={2}
                                            display="flex"
                                            flexDirection="column"
                                            justifyContent="center"
                                            pl={2}>
                                            {children}
                                        </Box>
                                    )}
                                </Box>
                            </Card>
                        </Button>
                    </label>
                </Box>
            )}
        </>
    );
};

ObjectCard.defaultProps = {
    variant: 'success',
    children: '',
    iconName: 'user',
    cardType: 'objectCard',
    onClick: noop,
    isMember: false,
    onEditClick: noop,
    onDelete: noop,
    showOptionMenu : true
};

ObjectCard.propTypes = {
    variant: PropTypes.oneOf(['success', 'failed', 'pending']),
    cardType: PropTypes.oneOf(['objectCard', 'actionCard']),
    children: PropTypes.node,
    iconName: PropTypes.string,
    onClick: PropTypes.func,
    isMember: PropTypes.bool,
    onEditClick: PropTypes.func,
    onDelete: PropTypes.func,
    showOptionMenu : PropTypes.bool,
};

export default ObjectCard;
