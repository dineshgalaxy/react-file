import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    WizardHeaderWrapper: {
        borderBottomLeftRadius: theme.spacing(3),
        borderBottomRightRadius: theme.spacing(3),
        padding: '24px 0',
        position: 'relative',
        backgroundColor:theme.palette.primary.main,
        minHeight:"103px"
    },
    menuButton: {
        backgroundColor: theme.common.white,
        '&:hover': {
            backgroundColor: theme.common.white,
            opacity: '0.5'
        }
    },
}));

export default useStyles;
