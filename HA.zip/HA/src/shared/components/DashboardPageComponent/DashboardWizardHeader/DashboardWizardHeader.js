import { Box, Container, IconButton } from '@material-ui/core';
import PropTypes from 'prop-types';
import { ChevronLeft, Menu } from 'react-feather';
import useStyles from './DashboardWizardHeaderStyles';
/**
 * Name : DashboardWizardHeader
 * Desc : Render DashboardWizardHeader
 */

const DashboardWizardHeader = ({ title, isMobileMenu }) => {
    const classes = useStyles();
    const Icon = isMobileMenu ? Menu : ChevronLeft;
    return (
        <Box bgcolor="primary.main" className={classes.WizardHeaderWrapper}>
            <Container>
                <Box display="flex" alignItems="center" position="relative" zIndex={1}>
                    <IconButton className={classes.menuButton}>
                        <Icon color="Indigo" size={26} />
                    </IconButton>
                    <Box
                        fontSize="h3.fontSize"
                        color="common.white"
                        fontFamily="fontFamily.bold"
                        ml={3}>
                        {title}
                    </Box>
                </Box>
            </Container>
        </Box>
    );
};
DashboardWizardHeader.defaultProps = {
    isMobileMenu: false
};
DashboardWizardHeader.propTypes = {
    title: PropTypes.string,
    isMobileMenu: PropTypes.bool
};

export default DashboardWizardHeader;
