import { Avatar, Box, Button, Container, Grid, Link } from '@material-ui/core';
import React from 'react';

/**
 * Name : DashboardContactUs
 * Desc : DashboardContactUs
 */

const DashboardContactUs = () => {
    return (
        <Box>
            <Box bgcolor="secondary.extraLight" pt={3} pb={3}>
                <Container>
                    <Grid container spacing={3} alignItems="center">
                        <Grid item xs={12} md={6}>
                            <Box>
                                <Avatar
                                    style={{
                                        height: '292px',
                                        width: '100%'
                                    }}
                                    alt="view"
                                    src="/contactImg.jpg"
                                    variant="square"
                                />
                            </Box>
                        </Grid>
                        <Grid item xs={12} md={6}>
                            <Box
                                color="common.lightBlack"
                                fontSize="h5.fontSize"
                                fontFamily="fontFamily.semiBold"
                                mb={2}>
                                How Something Else Works
                            </Box>
                            <Box color="primary.light" fontSize="h6.fontSize">
                                5300 E. Paisano Drive
                            </Box>
                            <Box color="primary.light" fontSize="h6.fontSize">
                                El Paso, Texas 79905
                            </Box>
                            <Link href="#" underline="none">
                                <Box color="primary.main" fontSize="h6.fontSize">
                                    Get Directions
                                </Box>
                            </Link>
                            <Box mt={4} pb={3}>
                                <Button size="large" color="primary" variant="contained">
                                    (915) 849-3124
                                </Button>
                            </Box>
                        </Grid>
                    </Grid>
                </Container>
            </Box>
            <Box pt={7} pb={6}>
                <Container>
                    <Box
                        color="primary.light"
                        fontSize="h5.fontSize"
                        fontFamily="fontFamily.bold"
                        mb={1}>
                        Office Hours
                    </Box>
                    <Box color="primary.extraLight" fontSize="h6.fontSize">
                        Monday through
                    </Box>
                    <Box color="primary.extraLight" fontSize="h6.fontSize" mb={4}>
                        Friday 8 a.m. to 5 p.m.
                    </Box>
                    <Box
                        color="primary.light"
                        fontSize="h5.fontSize"
                        fontFamily="fontFamily.bold"
                        mb={1}>
                        Special Assistance
                    </Box>
                    <Box color="primary.extraLight" fontSize="h6.fontSize" mb={4}>
                        Deaf or hard of hearing clients may use the TDD telephone line
                    </Box>
                    <Button size="large" color="primary" variant="contained">
                        Log In
                    </Button>
                </Container>
            </Box>
        </Box>
    );
};

export default DashboardContactUs;
