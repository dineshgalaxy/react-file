import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    cardLinks: {
        '&:not(:last-child)': {
            borderBottom: `1px solid ${theme.common.gray}`
        }
    },
    cardLinksText: {
        width: '100%'
    },
    tabWrapper: {
        '& > div': {
            minHeight: '800px',
            paddingBottom: '8px'
        }
    },
    mobileTabs: {
        [theme.breakpoints.up('md')]: {
            display: 'none'
        }
    },
    webTabs: {
        [theme.breakpoints.up('md')]: {
            display: 'block'
        }
    },
    title: {
        borderBottom: `1px solid ${theme.common.gray}`
    }
}));

export default useStyles;
