import { Box, Link } from '@material-ui/core';
import React from 'react';
import { Plus, Archive, Edit } from 'react-feather';
import ProgramCard from '../../ProgramCard';
import ObjectCard from '../../ObjectCard';

/**
 * Name: DashboardYourApplication
 * Desc: Render DashboardYourApplication
 */

const DashboardYourApplication = () => {
    const linkArray = [
        { text: 'Apply for other programs >', icon: Plus },
        { text: 'Update your eligibility info >', icon: Edit },
        { text: 'View (6) archived applications >', icon: Archive }
    ];

    return (
        <>
        <Box pb={4.5}>
            {[
                {programName:'Housing Choice Voucher', status:"On Waitlist"},
                {programName:'Program Name (2BR)', status:"On Waitlist"},
                {programName:'Tays (1BR)', status:"On Waitlist"},
                {programName:'Siesta Gardens (2BR)', status:"Pending Review"},
            ].map((item) => (
                <Box mb={3} key={item.programName}>
                    <ProgramCard 
                        variant="waiting"
                        showImage={true}
                        showLeftBorder={true}
                        showLeftArrow={true}
                        >
                        <Box
                            color="primary.main"
                            fontSize="h6.fontSize"
                            fontFamily="fontFamily.medium">
                            {item.programName}
                        </Box>
                        <Box
                            component="body1"
                            color="primary.light"
                            fontSize="lg.fontSize"
                            fontFamily="fontFamily.regular">
                            {item.status}
                        </Box>
                    </ProgramCard>
                </Box>
            ))}
            <Box
                mb={3}
                borderColor="primary.main"
                border="1px dashed"
                borderRadius="21px">
                <ObjectCard cardType="actionCard" iconName="plus">
                    <Box
                        color="primary.main"
                        fontSize="h6.fontSize"
                        fontFamily="fontFamily.medium">
                        Start a New Pre-Application
                    </Box>
                </ObjectCard>
            </Box>
        </Box>
        <Box>
            {linkArray.map((item) => (
                <Box mb={2} key={item.text}>
                    <Link href="#" underline="none">
                        <Box display="flex" alignItems="center">
                            <item.icon
                                strokeWidth="2"
                                color="Indigo"
                                size={15}
                            />
                            <Box
                                fontSize="lg.fontSize"
                                color="primary.main"
                                fontFamily="fontFamily.medium"
                                ml={1.5}>
                                {item.text}
                            </Box>
                        </Box>
                    </Link>
                </Box>
            ))}
        </Box>
        
        </>
    )
}

export default DashboardYourApplication
