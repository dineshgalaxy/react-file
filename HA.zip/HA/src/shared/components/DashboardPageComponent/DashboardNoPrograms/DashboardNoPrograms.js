import { Box, Link, Container, Grid } from '@material-ui/core';
import React from 'react';
import useStyles from '../DashboardPageComponentStyles';
import clsx from 'clsx';
import Image from 'next/image';

/**
 * Name: DashboardNoPrograms
 * Desc: Render DashboardNoPrograms
 */

const DashboardNoPrograms = () => {
    const classes = useStyles();
    return (
        <>
            <Container>
                <Box
                    mt={5.5}
                    mb={5}
                    fontSize="h5.fontSize"
                    fontFamily="fontFamily.bold"
                    color="primary.light">
                    More Resources
                </Box>
                <Grid container spacing={4}>
                    {[
                        {
                            imageName: '/Frame1.png',
                            text: 'Rent Affordability Calculator'
                        },
                        {
                            imageName: '/Frame2.png',
                            text: 'Browse Rental Properties on GoSection8',
                            bgColor: 'success'
                        },
                        {
                            imageName: '/Frame1.png',
                            text: 'Calculate what rent you can afford',
                            bgColor: 'warning'
                        },
                        {
                            imageName: '/Frame2.png',
                            text: 'Calculate what rent you can afford'
                        }
                    ].map((item) => (
                        <Grid item xs={6} md={3} key={item.type}>
                            <Box
                                p={0}
                                borderRadius="16px"
                                mb={0}
                                className={clsx(
                                    classes.boxWrapper,
                                    item.bgColor && classes[item.bgColor]
                                )}>
                                <Box borderRadius="16px" mb={2} className={classes.imageWrapper}>
                                    <Box
                                        display="flex"
                                        justifyContent="center"
                                        position="relative"
                                        top="-16px">
                                        <Image src={item.imageName} width={207} height={186} />
                                    </Box>
                                </Box>
                                <Box>
                                    <Link href="#" underline="none">
                                        <Box display="flex" alignItems="center">
                                            <Box display="flex" justifyContent="flex-start">
                                                <Box
                                                    fontSize="lg.fontSize"
                                                    color="primary.light"
                                                    fontFamily="fontFamily.medium"
                                                    mr={1}>
                                                    {item.text}
                                                </Box>
                                            </Box>
                                        </Box>
                                    </Link>
                                </Box>
                            </Box>
                        </Grid>
                    ))}
                </Grid>
            </Container>  
        </>
    )
}

export default DashboardNoPrograms
