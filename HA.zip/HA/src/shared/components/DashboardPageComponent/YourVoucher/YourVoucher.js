import { Box, Button } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { ChevronRight, Download } from 'react-feather';
import useStyles from './YourVoucherStyles';

/**
 * Name : YourVoucher
 * Desc : YourVoucher
 */

const YourVoucher = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box width="100%">
                <Box pb={width === 'xs' || width === 'sm' ? 2 : 6}>
                    <Box mb={5} pt={2}>
                        <Box
                            color="primary.light"
                            fontSize="h6.fontSize"
                            fontFamily="fontFamily.medium"
                            pb={1}>
                            Name
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            Firstname Lastname
                        </Box>
                    </Box>
                    <Box mb={5}>
                        <Box
                            color="primary.light"
                            fontSize="h6.fontSize"
                            fontFamily="fontFamily.medium"
                            pb={1}>
                            Voucher Number
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            T123456
                        </Box>
                    </Box>
                    <Box mb={5}>
                        <Box
                            color="primary.light"
                            fontSize="h6.fontSize"
                            fontFamily="fontFamily.medium"
                            pb={1}>
                            Maximum Unit Size
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            up to [X] bedroom(s)
                        </Box>
                    </Box>
                    <Box>
                        <Box
                            color="primary.light"
                            fontSize="h6.fontSize"
                            fontFamily="fontFamily.medium"
                            pb={1}>
                            Voucher Expiration Date
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            [Date of Expiration]
                        </Box>
                        <Box pt={1}>
                            <Button
                                style={{
                                    color: 'Indigo',
                                    fontSize: '15px'
                                }}
                                size="medium"
                                className="linkBtn"
                                endIcon={<ChevronRight color="Indigo" size={14} />}>
                                Request an Extension
                            </Button>
                        </Box>
                    </Box>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="secondary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}
                        startIcon={<Download color="Indigo" size={21} strokeWidth={3} />}>
                        Download Voucher
                    </Button>
                </Box>
            </Box>
        </Box>
    );
};

YourVoucher.propTypes = {
    width: PropTypes.string
};
export default withWidth()(YourVoucher);
