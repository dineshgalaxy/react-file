import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 96px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: '0 0 38px 0',
            alignItems: 'flex-start'
        }
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    }
}));

export default useStyles;
