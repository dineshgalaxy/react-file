import { Box, Container, Link } from '@material-ui/core';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import PropTypes from 'prop-types';
import React from 'react';
import { Archive, ChevronRight, Save, Settings, User } from 'react-feather';
import CommonCard from '~/shared/components/CommonCard';
import useStyles from './DashboardAccountStyles';
/**
 * Name: DashboardAccount
 * Desc: Render DashboardAccount
 */

const DashboardAccount = () => {
    const classes = useStyles();
    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const accountLinks = [
        { text: 'Account Details', icon: User, rightIcon: ChevronRight },
        { text: 'Household Details', icon: Settings, rightIcon: ChevronRight },
        { text: 'Saved Documents', icon: Save, rightIcon: ChevronRight },
        { text: 'Archived Applications', icon: Archive, rightIcon: ChevronRight }
    ];
    const accountLinkName = [
        { label: 'Name', info: 'Erika Alexander' },
        { label: 'T-Number', info: 'T-123456' },
        { label: 'Your Voucher', info: 'Active' },
        { label: 'Email Address', info: 'email@email.com' },
        { label: '', info: 'Update Your Password' },
        { label: '', info: 'Connected Facebook Account' }
    ];
    const contactInformationLinks = [
        { label: 'Landline Phone', info: '(915) 555-1234' },
        { label: 'Cell Phone', info: '(915) 555-1234' },
        {
            label: 'Address',
            info: (
                <Box>
                    <Box mb={1}>Address Line One</Box>
                    <Box mb={1}>Address Line Two</Box>
                    <Box>City, State, Zip Code</Box>
                </Box>
            )
        },
        { label: 'Your Trusted Contact', info: 'Firstname Lastname' }
    ];

    function a11yProps(index) {
        return {
            id: `vertical-tab-${index}`,
            'aria-controls': `vertical-tabpanel-${index}`
        };
    }
    function TabPanel(props) {
        const { children, value, index, ...other } = props;

        return (
            <Box
                width="100%"
                maxWidth="640px"
                role="tabpanel"
                hidden={value !== index}
                id={`vertical-tabpanel-${index}`}
                aria-labelledby={`vertical-tab-${index}`}
                className={classes.tabWrapper}
                {...other}>
                {value === index && (
                    <CommonCard showBackBtn={false}>
                        <Box>{children}</Box>
                    </CommonCard>
                )}
            </Box>
        );
    }
    return (
        <Box>
            <Box display="none" className={classes.webTabs} mb={12}>
                <Container>
                    <Box display="flex" mt={10}>
                        <Box>
                            <Box
                                color="primary.light"
                                fontSize="h1.fontSize"
                                fontFamily="fontFamily.bold"
                                textAlign="right"
                                position="relative"
                                top="140px"
                                mr={5}>
                                <Box>Your</Box> <Box>Account</Box>
                            </Box>
                            <Tabs
                                orientation="vertical"
                                variant="scrollable"
                                value={value}
                                onChange={handleChange}
                                aria-label="Vertical tabs example"
                                className={classes.tabs}>
                                {accountLinks.map((item) => (
                                    <Tab
                                        key={item.text}
                                        label={
                                            <Box
                                                display="flex"
                                                alignItems="center"
                                                justifyContent="space-between"
                                                className={classes.cardLinks}>
                                                <Box display="flex" alignItems="center">
                                                    <Box display="flex" alignItems="center">
                                                        <Box
                                                            mr={2}
                                                            color="primary.main"
                                                            fontSize="h5.fontSize"
                                                            display="flex"
                                                            alignItems="center"
                                                            fontFamily="fontFamily.medium">
                                                            <item.icon color="Indigo" size={24} />
                                                        </Box>

                                                        <Box
                                                            mr={1}
                                                            maxWidth="400px"
                                                            color="primary.main"
                                                            fontSize="h5.fontSize"
                                                            fontFamily="fontFamily.medium"
                                                            whiteSpace="noWrap">
                                                            {item.text}
                                                        </Box>
                                                    </Box>
                                                    <Box display="flex" className="arrow">
                                                        <item.rightIcon color="Indigo" size={24} />
                                                    </Box>
                                                </Box>
                                            </Box>
                                        }
                                        {...a11yProps(0)}
                                    />
                                ))}
                            </Tabs>
                        </Box>
                        <Box width="100%">
                            <TabPanel value={value} index={0}>
                                <Box padding="16px" maxWidth="592px">
                                    <Box
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        fontFamily="fontFamily.bold">
                                        Account Information
                                    </Box>
                                    <Box>
                                        {accountLinkName.map((item) => (
                                            <Box
                                                display="flex"
                                                alignItems="center"
                                                justifyContent="space-between"
                                                pt={2}
                                                pb={2}
                                                minHeight="90px"
                                                className={classes.cardLinks}
                                                key={item}>
                                                <Link
                                                    href="#"
                                                    underline="none"
                                                    className={classes.cardLinksText}>
                                                    <Box display="flex" alignItems="center">
                                                        <Box display="flex" flexDirection="column">
                                                            <Box
                                                                color="primary.extraLight"
                                                                fontSize="mdxl.fontSize">
                                                                {item.label}
                                                            </Box>

                                                            <Box
                                                                mr={1}
                                                                color="primary.light"
                                                                fontSize="h6.fontSize">
                                                                {item.info}
                                                            </Box>
                                                        </Box>
                                                        <Box display="flex" marginLeft="auto">
                                                            <ChevronRight
                                                                color="Indigo"
                                                                size={24}
                                                            />
                                                        </Box>
                                                    </Box>
                                                </Link>
                                            </Box>
                                        ))}
                                    </Box>
                                    <Box
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        fontFamily="fontFamily.bold"
                                        mt={6}>
                                        Contact Information
                                    </Box>
                                    <Box mb={6}>
                                        {contactInformationLinks.map((item) => (
                                            <Box
                                                display="flex"
                                                alignItems="center"
                                                justifyContent="space-between"
                                                pt={2}
                                                pb={2}
                                                minHeight="90px"
                                                className={classes.cardLinks}
                                                key={item}>
                                                <Link
                                                    href="#"
                                                    underline="none"
                                                    className={classes.cardLinksText}>
                                                    <Box display="flex" alignItems="center">
                                                        <Box display="flex" flexDirection="column">
                                                            <Box
                                                                color="primary.extraLight"
                                                                fontSize="mdxl.fontSize">
                                                                {item.label}
                                                            </Box>

                                                            <Box
                                                                mr={1}
                                                                color="primary.light"
                                                                fontSize="h6.fontSize">
                                                                {item.info}
                                                            </Box>
                                                        </Box>
                                                        <Box display="flex" marginLeft="auto">
                                                            <ChevronRight
                                                                color="Indigo"
                                                                size={24}
                                                            />
                                                        </Box>
                                                    </Box>
                                                </Link>
                                            </Box>
                                        ))}
                                    </Box>
                                </Box>
                            </TabPanel>
                            <TabPanel value={value} index={1}>
                                Item Two
                            </TabPanel>
                            <TabPanel value={value} index={2}>
                                Item Three
                            </TabPanel>
                            <TabPanel value={value} index={2}>
                                Item Three
                            </TabPanel>
                        </Box>
                    </Box>
                </Container>
            </Box>
            <Box margin="0 24px 50px" className={classes.mobileTabs}>
                {accountLinks.map((item) => (
                    <Box
                        display="flex"
                        alignItems="center"
                        justifyContent="space-between"
                        pt={3}
                        pb={3}
                        className={classes.cardLinks}
                        key={item}>
                        <Link href="#" underline="none" className={classes.cardLinksText}>
                            <Box display="flex" alignItems="center">
                                <Box display="flex" alignItems="center">
                                    <Box
                                        mr={2}
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        display="flex"
                                        alignItems="center"
                                        fontFamily="fontFamily.medium">
                                        <item.icon color="Indigo" size={24} />
                                    </Box>

                                    <Box
                                        mr={1}
                                        maxWidth="400px"
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        fontFamily="fontFamily.medium">
                                        {item.text}
                                    </Box>
                                </Box>
                                <Box display="flex" marginLeft="auto">
                                    <ChevronRight color="Indigo" size={24} />
                                </Box>
                            </Box>
                        </Link>
                    </Box>
                ))}
            </Box>
        </Box>
    );
};
DashboardAccount.propTypes = {
    children: PropTypes.any,
    value: PropTypes.number,
    index: PropTypes.number
};
export default DashboardAccount;
