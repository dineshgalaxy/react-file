import { Box, Container, Link } from '@material-ui/core';
import Tab from '@material-ui/core/Tab';
import Tabs from '@material-ui/core/Tabs';
import PropTypes from 'prop-types';
import React from 'react';
import { ChevronRight, HelpCircle, Info, Phone } from 'react-feather';
import CommonCard from '~/shared/components/CommonCard';
import useStyles from './DashboardHelpCenterStyles';

/**
 * Name: DashboardHelpCenter
 * Desc: Render DashboardHelpCenter
 */

const DashboardHelpCenter = () => {
    const classes = useStyles();
    const [value, setValue] = React.useState(0);

    const handleChange = (event, newValue) => {
        setValue(newValue);
    };
    const gettingStartedText = [
        { text: 'First time users getting started with housing assistance' },
        { text: 'Helping a relative, patient, or client with an application' },
        { text: 'What to expect from the application process' }
    ];
    const eligibilityQuestionsText = [
        { text: 'Finding out if you are eligible for program assistance' },
        { text: 'Why wasn’t I eligible for HACEP’s programs?' }
    ];
    const otherTopicsText = [
        { text: 'What to do when your financial situation or household has changed' },
        { text: 'These each would get a page where HACEP can enter text' },
        { text: 'These will all be purely content that HACEP determines ' },
        { text: 'Add as many sections and topics that are needed' }
    ];

    const linkArray = [
        { text: 'Help Topics', icon: HelpCircle, rightIcon: ChevronRight },
        { text: 'Contact Us', icon: Phone, rightIcon: ChevronRight },
        { text: 'Program Information', icon: Info, rightIcon: ChevronRight }
    ];

    function a11yProps(index) {
        return {
            id: `vertical-tab-${index}`,
            'aria-controls': `vertical-tabpanel-${index}`
        };
    }
    function TabPanel(props) {
        const { children, value, index, ...other } = props;

        return (
            <Box
                width="100%"
                maxWidth="640px"
                role="tabpanel"
                hidden={value !== index}
                id={`vertical-tabpanel-${index}`}
                aria-labelledby={`vertical-tab-${index}`}
                className={classes.tabWrapper}
                {...other}>
                {value === index && (
                    <CommonCard showBackBtn={false}>
                        <Box>{children}</Box>
                    </CommonCard>
                )}
            </Box>
        );
    }
    return (
        <Box>
            <Box display="none" className={classes.webTabs} mb={12}>
                <Container>
                    <Box display="flex" mt={10}>
                        <Box>
                            <Box
                                color="primary.light"
                                fontSize="h1.fontSize"
                                fontFamily="fontFamily.bold"
                                textAlign="right"
                                position="relative"
                                top="140px"
                                mr={5}>
                                <Box>Help</Box> <Box>Center</Box>
                            </Box>
                            <Tabs
                                orientation="vertical"
                                variant="scrollable"
                                value={value}
                                onChange={handleChange}
                                aria-label="Vertical tabs example"
                                className={classes.tabs}>
                                {linkArray.map((item) => (
                                    <Tab
                                        key={item.text}
                                        label={
                                            <Box
                                                display="flex"
                                                alignItems="center"
                                                justifyContent="space-between"
                                                className={classes.cardLinks}>
                                                <Box display="flex" alignItems="center">
                                                    <Box display="flex" alignItems="center">
                                                        <Box
                                                            mr={2}
                                                            color="primary.main"
                                                            fontSize="h5.fontSize"
                                                            display="flex"
                                                            alignItems="center"
                                                            fontFamily="fontFamily.medium">
                                                            <item.icon color="Indigo" size={24} />
                                                        </Box>

                                                        <Box
                                                            mr={1}
                                                            maxWidth="400px"
                                                            color="primary.main"
                                                            fontSize="h5.fontSize"
                                                            fontFamily="fontFamily.medium"
                                                            whiteSpace="noWrap">
                                                            {item.text}
                                                        </Box>
                                                    </Box>
                                                    <Box display="flex" className="arrow">
                                                        <item.rightIcon color="Indigo" size={24} />
                                                    </Box>
                                                </Box>
                                            </Box>
                                        }
                                        {...a11yProps(0)}
                                    />
                                ))}
                            </Tabs>
                        </Box>
                        <Box width="100%">
                            <TabPanel value={value} index={0}>
                                <Box padding="16px" maxWidth="592px">
                                    <Box
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        fontFamily="fontFamily.bold">
                                        Getting Started
                                    </Box>
                                    <Box>
                                        {gettingStartedText.map((item) => (
                                            <Box
                                                display="flex"
                                                alignItems="center"
                                                justifyContent="space-between"
                                                pt={2}
                                                pb={2}
                                                minHeight="90px"
                                                className={classes.cardLinks}
                                                key={item}>
                                                <Link
                                                    href="#"
                                                    underline="none"
                                                    className={classes.cardLinksText}>
                                                    <Box display="flex" alignItems="center">
                                                        <Box
                                                            mr={1}
                                                            color="primary.main"
                                                            fontSize="h6.fontSize">
                                                            {item.text}
                                                        </Box>

                                                        <Box display="flex" marginLeft="auto">
                                                            <ChevronRight
                                                                color="Indigo"
                                                                size={24}
                                                            />
                                                        </Box>
                                                    </Box>
                                                </Link>
                                            </Box>
                                        ))}
                                    </Box>
                                    <Box
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        fontFamily="fontFamily.bold"
                                        mt={6}>
                                        Eligibility Questions
                                    </Box>
                                    <Box mb={6}>
                                        {eligibilityQuestionsText.map((item) => (
                                            <Box
                                                display="flex"
                                                alignItems="center"
                                                justifyContent="space-between"
                                                pt={2}
                                                pb={2}
                                                minHeight="90px"
                                                className={classes.cardLinks}
                                                key={item}>
                                                <Link
                                                    href="#"
                                                    underline="none"
                                                    className={classes.cardLinksText}>
                                                    <Box display="flex" alignItems="center">
                                                        <Box
                                                            mr={1}
                                                            color="primary.main"
                                                            fontSize="h6.fontSize">
                                                            {item.text}
                                                        </Box>

                                                        <Box display="flex" marginLeft="auto">
                                                            <ChevronRight
                                                                color="Indigo"
                                                                size={24}
                                                            />
                                                        </Box>
                                                    </Box>
                                                </Link>
                                            </Box>
                                        ))}
                                    </Box>
                                    <Box
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        fontFamily="fontFamily.bold"
                                        mt={6}>
                                        Other Topics
                                    </Box>
                                    <Box>
                                        {otherTopicsText.map((item) => (
                                            <Box
                                                display="flex"
                                                alignItems="center"
                                                justifyContent="space-between"
                                                pt={2}
                                                pb={2}
                                                minHeight="90px"
                                                className={classes.cardLinks}
                                                key={item}>
                                                <Link
                                                    href="#"
                                                    underline="none"
                                                    className={classes.cardLinksText}>
                                                    <Box display="flex" alignItems="center">
                                                        <Box
                                                            mr={1}
                                                            color="primary.main"
                                                            fontSize="h6.fontSize">
                                                            {item.text}
                                                        </Box>

                                                        <Box display="flex" marginLeft="auto">
                                                            <ChevronRight
                                                                color="Indigo"
                                                                size={24}
                                                            />
                                                        </Box>
                                                    </Box>
                                                </Link>
                                            </Box>
                                        ))}
                                    </Box>
                                </Box>
                            </TabPanel>
                            <TabPanel value={value} index={1}>
                                Item Two
                            </TabPanel>
                            <TabPanel value={value} index={2}>
                                Item Three
                            </TabPanel>
                        </Box>
                    </Box>
                </Container>
            </Box>
            <Box margin="0 8px 50px" className={classes.mobileTabs}>
                {linkArray.map((item) => (
                    <Box
                        display="flex"
                        alignItems="center"
                        justifyContent="space-between"
                        pt={3}
                        pb={3}
                        className={classes.cardLinks}
                        key={item}>
                        <Link href="#" underline="none" className={classes.cardLinksText}>
                            <Box display="flex" alignItems="center">
                                <Box display="flex" alignItems="center">
                                    <Box
                                        mr={2}
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        display="flex"
                                        alignItems="center"
                                        fontFamily="fontFamily.medium">
                                        <item.icon color="Indigo" size={24} />
                                    </Box>

                                    <Box
                                        mr={1}
                                        maxWidth="400px"
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        fontFamily="fontFamily.medium">
                                        {item.text}
                                    </Box>
                                </Box>
                                <Box display="flex" marginLeft="auto">
                                    <ChevronRight color="Indigo" size={24} />
                                </Box>
                            </Box>
                        </Link>
                    </Box>
                ))}
            </Box>
        </Box>
    );
};

DashboardHelpCenter.propTypes = {
    children: PropTypes.any,
    value: PropTypes.number,
    index: PropTypes.number
};
export default DashboardHelpCenter;
