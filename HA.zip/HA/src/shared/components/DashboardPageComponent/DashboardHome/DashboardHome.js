import { Box, Container, Grid, Link } from '@material-ui/core';
import clsx from 'clsx';
import Image from 'next/image';
import { default as React } from 'react';
import { Archive, ChevronRight, Edit, Plus } from 'react-feather';
import ProgramCard from '~/shared/components/ProgramCard';
import useStyles from './DashboardHomeStyles';

/**
 * Name: DashboardHome
 * Desc: Render DashboardHome
 */

const DashboardHome = () => {
    const classes = useStyles();
    const linkArray = [
        { text: 'Apply for other programs >', icon: Plus },
        { text: 'Update your eligibility info >', icon: Edit },
        { text: 'View (6) archived applications >', icon: Archive }
    ];

    return (
        <>
            <Box pb={2} bgcolor="secondary.extraLight" className={classes.dashboardUpperWrapper}>
                <Container>
                    <Box
                        pt={9}
                        pb={5}
                        fontSize="h5.fontSize"
                        fontFamily="fontFamily.bold"
                        color="primary.light"
                        display="none"
                        className={classes.linkText}>
                        Your Program Applications
                    </Box>

                    <Grid container spacing={4}>
                        <Grid item xs={12} md={8}>
                            <Box mt={-8} className={classes.linkList}>
                                <Box mb={3}>
                                    <ProgramCard
                                        variant="success"
                                        showImage={true}
                                        showLeftArrow={true}>
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            Program Title on Card (1BR)
                                        </Box>
                                        <Box
                                            component="body1"
                                            color="primary.light"
                                            fontSize="lg.fontSize"
                                            fontFamily="fontFamily.regular">
                                            Positive status
                                        </Box>
                                    </ProgramCard>
                                </Box>
                                <Box mb={3}>
                                    <ProgramCard
                                        variant="waiting"
                                        showImage={true}
                                        showLeftArrow={true}>
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            Program Title on Card (1BR)
                                        </Box>
                                        <Box
                                            component="body1"
                                            color="primary.light"
                                            fontSize="lg.fontSize"
                                            fontFamily="fontFamily.regular">
                                            Positive status
                                        </Box>
                                    </ProgramCard>
                                </Box>
                                <Box mb={3}>
                                    <ProgramCard
                                        variant="failed"
                                        showImage={true}
                                        showLeftArrow={true}>
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            Program Title on Card (1BR)
                                        </Box>
                                        <Box
                                            component="body1"
                                            color="primary.light"
                                            fontSize="lg.fontSize"
                                            fontFamily="fontFamily.regular">
                                            Positive status
                                        </Box>
                                    </ProgramCard>
                                </Box>
                                <Box mb={3}>
                                    <ProgramCard
                                        showImage={true}
                                        showLeftArrow={false}
                                        showLeftBorder={false}>
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            Program Title on Card (1BR)
                                        </Box>
                                        <Box
                                            component="body1"
                                            color="primary.light"
                                            fontSize="lg.fontSize"
                                            fontFamily="fontFamily.regular">
                                            Positive status
                                        </Box>
                                    </ProgramCard>
                                </Box>
                            </Box>
                        </Grid>
                        <Grid item xs={12} md={4}>
                            <Box>
                                {linkArray.map((item) => (
                                    <Box mb={3} key={item.text}>
                                        <Link href="#" underline="none">
                                            <Box display="flex" alignItems="center">
                                                <item.icon
                                                    strokeWidth="2"
                                                    color="Indigo"
                                                    size={15}
                                                />
                                                <Box
                                                    fontSize="lg.fontSize"
                                                    color="primary.main"
                                                    fontFamily="fontFamily.medium"
                                                    ml={1.5}>
                                                    {item.text}
                                                </Box>
                                            </Box>
                                        </Link>
                                    </Box>
                                ))}
                            </Box>
                        </Grid>
                    </Grid>
                </Container>
            </Box>

            <Container>
                <Box
                    mt={8}
                    mb={5}
                    fontSize="h5.fontSize"
                    fontFamily="fontFamily.bold"
                    color="primary.extraLight">
                    More Resources
                </Box>
                <Grid container spacing={4}>
                    {[
                        {
                            imageName: '/Frame1.png',
                            text: 'Calculate what you can afford to rent'
                        },
                        {
                            imageName: '/Frame2.png',
                            text: 'Browse El Paso housing opportunites',
                            bgColor: 'success'
                        },
                        {
                            imageName: '/Frame1.png',
                            text: 'Find out if you’re eligible',
                            bgColor: 'warning'
                        },
                        {
                            imageName: '/Frame2.png',
                            text: 'Update your family or financial info'
                        }
                    ].map((item) => (
                        <Grid item xs={6} md={3} key={item.type}>
                            <Box
                                p={0}
                                borderRadius="16px"
                                mb={8}
                                className={clsx(
                                    classes.boxWrapper,
                                    item.bgColor && classes[item.bgColor]
                                )}>
                                <Box borderRadius="16px" mb={2} className={classes.imageWrapper}>
                                    <Box
                                        display="flex"
                                        justifyContent="center"
                                        position="relative"
                                        top="-16px">
                                        <Image src={item.imageName} width={207} height={186} />
                                    </Box>
                                </Box>
                                <Box>
                                    <Link href="#" underline="none">
                                        <Box display="flex" alignItems="center">
                                            <Box display="flex" justifyContent="flex-start">
                                                <Box
                                                    fontSize="lg.fontSize"
                                                    color="primary.light"
                                                    fontFamily="fontFamily.medium"
                                                    mr={1}>
                                                    {item.text}
                                                    <Box
                                                        component="span"
                                                        position="relative"
                                                        top="3px"
                                                        left="5px"
                                                        className={classes.mobileArrow}>
                                                        <ChevronRight
                                                            strokeWidth={3}
                                                            color="indigo"
                                                            size={16}
                                                        />
                                                    </Box>
                                                </Box>
                                                <Box
                                                    fontSize="h4.fontSize"
                                                    color="primary.light"
                                                    fontFamily="fontFamily.medium"
                                                    display="none"
                                                    className={classes.webArrow}>
                                                    <ChevronRight
                                                        strokeWidth={3}
                                                        color="indigo"
                                                        size={16}
                                                    />
                                                </Box>
                                            </Box>
                                        </Box>
                                    </Link>
                                </Box>
                            </Box>
                        </Grid>
                    ))}
                </Grid>
            </Container>
        </>
    );
};

export default DashboardHome;
