import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    cardLinks: {
        borderBottom: `1px solid ${theme.common.gray}`
    },
    cardLinksText: {
        width: '100%'
    }
}));

export default useStyles;
