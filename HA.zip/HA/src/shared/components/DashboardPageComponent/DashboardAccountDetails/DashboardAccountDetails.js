import { Box, Link } from '@material-ui/core';
import React from 'react';
import { ChevronRight } from 'react-feather';
import useStyles from './DashboardAccountDetailsStyles';
/**
 * Name: DashboardAccountDetails
 * Desc: Render DashboardAccountDetails
 */

const DashboardAccountDetails = () => {
    const classes = useStyles();
    const accountLinks = [
        { label: 'Name', info: 'Erika Alexander' },
        { label: 'T-Number', info: 'T-123456' },
        { label: 'Your Voucher', info: 'Active' },
        { label: 'Email Address', info: 'email@email.com' },
        { label: '', info: 'Update Your Password' },
        { label: '', info: 'Connected Facebook Account' }
    ];
    const contactInformationLinks = [
        { label: 'Landline Phone', info: '(915) 555-1234' },
        { label: 'Cell Phone', info: '(915) 555-1234' },
        {
            label: 'Address',
            info: (
                <Box>
                    <Box mb={1}>Address Line One</Box>
                    <Box mb={1}>Address Line Two</Box>
                    <Box>City, State, Zip Code</Box>
                </Box>
            )
        },
        { label: 'Your Trusted Contact', info: 'Firstname Lastname' }
    ];
    return (
        <Box>
            <Box padding="24px 8px">
                <Box color="primary.light" fontSize="h5.fontSize" fontFamily="fontFamily.bold">
                    Account Information
                </Box>
                <Box>
                    {accountLinks.map((item) => (
                        <Box
                            display="flex"
                            alignItems="center"
                            justifyContent="space-between"
                            pt={2}
                            pb={2}
                            minHeight="90px"
                            className={classes.cardLinks}
                            key={item}>
                            <Link href="#" underline="none" className={classes.cardLinksText}>
                                <Box display="flex" alignItems="center">
                                    <Box display="flex" flexDirection="column">
                                        <Box color="primary.extraLight" fontSize="mdxl.fontSize">
                                            {item.label}
                                        </Box>

                                        <Box mr={1} color="primary.light" fontSize="h6.fontSize">
                                            {item.info}
                                        </Box>
                                    </Box>
                                    <Box display="flex" marginLeft="auto">
                                        <ChevronRight color="Indigo" size={24} />
                                    </Box>
                                </Box>
                            </Link>
                        </Box>
                    ))}
                </Box>
                <Box
                    color="primary.light"
                    fontSize="h5.fontSize"
                    fontFamily="fontFamily.bold"
                    mt={6}>
                    Contact Information
                </Box>
                <Box mb={6}>
                    {contactInformationLinks.map((item) => (
                        <Box
                            display="flex"
                            alignItems="center"
                            justifyContent="space-between"
                            pt={2}
                            pb={2}
                            minHeight="90px"
                            className={classes.cardLinks}
                            key={item}>
                            <Link href="#" underline="none" className={classes.cardLinksText}>
                                <Box display="flex" alignItems="center">
                                    <Box display="flex" flexDirection="column">
                                        <Box color="primary.extraLight" fontSize="mdxl.fontSize">
                                            {item.label}
                                        </Box>

                                        <Box mr={1} color="primary.light" fontSize="h6.fontSize">
                                            {item.info}
                                        </Box>
                                    </Box>
                                    <Box display="flex" marginLeft="auto">
                                        <ChevronRight color="Indigo" size={24} />
                                    </Box>
                                </Box>
                            </Link>
                        </Box>
                    ))}
                </Box>
            </Box>
        </Box>
    );
};

export default DashboardAccountDetails;
