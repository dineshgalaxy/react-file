export { default } from './HouseholdMemberDetails';
