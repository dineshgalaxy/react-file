import {useMemo} from 'react'
import { useSelector } from 'react-redux';
import { getFirstFormInItValues, onValidateAdditionalMemberFirstForm } from '~/modules/HouseHoldModule/Utils/HouseHoldUtils';
import useForm from '~/shared/customHooks/useForm';

const useHouseholdMemberDetailsForm = () => {
    const {
        additionalFormInfo = {},
        activeMember,
    } = useSelector((state) => state.houseHoldDetails);

    const initialValue = useMemo(
        () => getFirstFormInItValues(additionalFormInfo, activeMember),
        // eslint-disable-next-line react-hooks/exhaustive-deps
        [activeMember]
    );


    const {
        values,
        handleOnChange,
        setInitValue,
        handleSubmit,
        errors,
        touched,
        handleBlur,
        setCustomValue,
        isFormSubmit
    } = useForm(initialValue, onValidateAdditionalMemberFirstForm)

    return {
        handleOnChange,
        values,
        handleSubmit,
        errors,
        handleBlur,
        touched,
        isFormSubmit,
        setCustomValue,
        setInitValue,
        initialValue,
        activeMember
    };
}

export default useHouseholdMemberDetailsForm
