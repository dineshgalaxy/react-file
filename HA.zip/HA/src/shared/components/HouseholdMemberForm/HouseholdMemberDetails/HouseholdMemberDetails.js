import {
    Box,
    Button,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    TextField,
    InputAdornment
} from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import ExpandMoreOutlinedIcon from '@material-ui/icons/ExpandMoreOutlined';
import { DatePicker } from '@material-ui/pickers';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React, {useEffect, useState} from 'react';
import { MEMBER_FORM_FILED } from '~/modules/HouseHoldModule/Utils/HouseHoldConstants';
import FormErrorMessage from '~/shared/components/FormErrorMessage';
import useStyles from '~/modules/HouseHoldModule/HouseholdMembers/HouseholdStyle';
import useHouseholdMemberDetailsForm from './useHouseholdMemberDetailsForm';
import InputMask from 'react-input-mask';

/**
 * Name : HouseholdMemberDetails
 * Desc : Render HouseholdMemberDetails
 */

const HouseholdMemberDetails = ({
    title,
    onNextButtonClick,
    width,
    gender,
    relationShip,
    citizenShip,
    payFrequency
}) => {

    const classes = useStyles();

    const {
        handleOnChange,
        values,
        handleSubmit,
        errors,
        handleBlur,
        touched,
        isFormSubmit,
        setCustomValue,
        setInitValue,
        initialValue,
        activeMember
    } = useHouseholdMemberDetailsForm();

    useEffect(() => {
        setInitValue(initialValue);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [activeMember, initialValue]);

    const [selectedDate, setSelectedDate] = useState(new Date(values.dob) || new Date());


    const handleDateChange = (date) => {
        setSelectedDate(date);
        let myDate = date.getUTCFullYear() + '/' + (date.getMonth() + 1) + '/' + date.getUTCDate();
        setCustomValue('dob', myDate);
    };

    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onNextButtonClick(values);
        }
    };

    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337} mb={1}>
                <Box fontSize="h5.fontSize" lineHeight="35px" color="primary.light" mb={1.5}>
                    {title}
                </Box>
            </Box>
            <form onSubmit={(e) => handleFormSubmit(e)}>
                <Box className={classes.textAlign} width="100%">
                    <Box>
                        <FormControl fullWidth>
                            <TextField
                                id="standard-basic"
                                label={
                                    <Box display="flex" alignItems="center">
                                        First Name<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                inputProps={{ maxLength: 100}}
                                variant="filled"
                                name={MEMBER_FORM_FILED['firstName']}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                value={values[MEMBER_FORM_FILED.firstName]}
                                error={!!errors[MEMBER_FORM_FILED.firstName]}
                                helperText={
                                    isFormSubmit && errors[MEMBER_FORM_FILED.firstName] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.firstName]}
                                        />
                                    ) : touched[MEMBER_FORM_FILED.firstName] &&
                                        errors[MEMBER_FORM_FILED.firstName] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.firstName]}
                                        />
                                    ) : (
                                        ''
                                    )
                                }
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                id="standard-basic"
                                label="Middle Name"
                                variant="filled"
                                name={MEMBER_FORM_FILED['middleName']}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                inputProps={{ maxLength: 100}}
                                value={values[MEMBER_FORM_FILED.middleName]}
                                error={!!errors[MEMBER_FORM_FILED.middleName]}
                                helperText={
                                    isFormSubmit && errors[MEMBER_FORM_FILED.middleName] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.middleName]}
                                        />
                                    ) : touched[MEMBER_FORM_FILED.middleName] &&
                                        errors[MEMBER_FORM_FILED.middleName] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.middleName]}
                                        />
                                    ) : (
                                        ''
                                    )
                                }
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                id="standard-basic"
                                label={
                                    <Box display="flex" alignItems="center">
                                        Last Name<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                variant="filled"
                                name={MEMBER_FORM_FILED['lastName']}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                inputProps={{ maxLength: 100}}
                                value={values[MEMBER_FORM_FILED.lastName]}
                                error={!!errors[MEMBER_FORM_FILED.lastName]}
                                helperText={
                                    isFormSubmit && errors[MEMBER_FORM_FILED.lastName] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.lastName]}
                                        />
                                    ) : touched[MEMBER_FORM_FILED.lastName] &&
                                        errors[MEMBER_FORM_FILED.lastName] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.lastName]}
                                        />
                                    ) : (
                                        ''
                                    )
                                }
                            />
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                id="standard-basic"
                                label="Maiden Name, if applicable"
                                variant="filled"
                                name={MEMBER_FORM_FILED['maidenName']}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                value={values[MEMBER_FORM_FILED.maidenName]}
                                error={!!errors[MEMBER_FORM_FILED.maidenName]}
                                helperText={
                                    isFormSubmit && errors[MEMBER_FORM_FILED.maidenName] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.maidenName]}
                                        />
                                    ) : touched[MEMBER_FORM_FILED.maidenName] &&
                                        errors[MEMBER_FORM_FILED.maidenName] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.maidenName]}
                                        />
                                    ) : (
                                        ''
                                    )
                                }
                            />
                        </FormControl>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">
                                <Box display="flex" alignItems="center">
                                    Relationship<Box color="primary.main">*</Box>
                                </Box>
                            </InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                name={MEMBER_FORM_FILED['relationShipId']}
                                IconComponent={ExpandMoreOutlinedIcon}
                                displayEmpty
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                value={values[MEMBER_FORM_FILED.relationShipId]}
                                error={!!errors[MEMBER_FORM_FILED.relationShipId]}>
                                {relationShip &&
                                    relationShip.map(({ id, type }) => (
                                        <MenuItem value={id} key={id}>
                                            {type}
                                        </MenuItem>
                                    ))}
                            </Select>
                            {isFormSubmit && errors[MEMBER_FORM_FILED.relationShipId] ? (
                                <Box pl={2} pr={2} pt={0.25} color="error.main">
                                    <FormErrorMessage
                                        title={errors[MEMBER_FORM_FILED.relationShipId]}
                                    />
                                </Box>
                            ) : touched[MEMBER_FORM_FILED.relationShipId] &&
                                errors[MEMBER_FORM_FILED.relationShipId] ? (
                                <Box pl={2} pr={2} pt={0.25} color="error.main">
                                    <FormErrorMessage
                                        title={errors[MEMBER_FORM_FILED.relationShipId]}
                                    />
                                </Box>
                            ) : (
                                ''
                            )}
                        </FormControl>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">
                                <Box display="flex" alignItems="center">
                                    Citizenship Status<Box color="primary.main">*</Box>
                                </Box>
                            </InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                name={MEMBER_FORM_FILED['citizenShipId']}
                                IconComponent={ExpandMoreOutlinedIcon}
                                displayEmpty
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                value={values[MEMBER_FORM_FILED.citizenShipId]}
                                error={!!errors[MEMBER_FORM_FILED.citizenShipId]}>
                                {citizenShip &&
                                    citizenShip.map(({ id, citizenship }) => (
                                        <MenuItem value={id} key={id}>
                                            {citizenship}
                                        </MenuItem>
                                    ))}
                            </Select>
                            {isFormSubmit && errors[MEMBER_FORM_FILED.citizenShipId] ? (
                                <Box pl={2} pr={2} pt={0.25} color="error.main">
                                    <FormErrorMessage
                                        title={errors[MEMBER_FORM_FILED.citizenShipId]}
                                    />
                                </Box>
                            ) : touched[MEMBER_FORM_FILED.citizenShipId] &&
                                errors[MEMBER_FORM_FILED.citizenShipId] ? (
                                <Box pl={2} pr={2} pt={0.25} color="error.main">
                                    <FormErrorMessage
                                        title={errors[MEMBER_FORM_FILED.citizenShipId]}
                                    />
                                </Box>
                            ) : (
                                ''
                            )}
                        </FormControl>
                        <FormControl fullWidth className={classes.datePicker}>
                            <DatePicker
                                autoOk
                                variant="inline"
                                disableFuture
                                minDate={new Date(1970 - 1 - 1)}
                                format="dd/MM/yyyy"
                                label={
                                    <Box display="flex" alignItems="center">
                                        Date of Birth<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                name={MEMBER_FORM_FILED['dateOfBirth']}
                                views={['year', 'month', 'date']}
                                value={selectedDate}
                                onChange={handleDateChange}
                                error={!!errors[MEMBER_FORM_FILED.dateOfBirth]}
                                helperText={
                                    isFormSubmit && errors[MEMBER_FORM_FILED.dateOfBirth] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.dateOfBirth]}
                                        />
                                    ) : touched[MEMBER_FORM_FILED.dateOfBirth] &&
                                        errors[MEMBER_FORM_FILED.dateOfBirth] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.dateOfBirth]}
                                        />
                                    ) : (
                                        ''
                                    )
                                }
                            />
                        </FormControl>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">
                                <Box display="flex" alignItems="center">
                                    Gender<Box color="primary.main">*</Box>
                                </Box>
                            </InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                name={MEMBER_FORM_FILED['gender']}
                                IconComponent={ExpandMoreOutlinedIcon}
                                displayEmpty
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                value={values[MEMBER_FORM_FILED.gender]}
                                error={!!errors[MEMBER_FORM_FILED.gender]}>
                                {gender &&
                                    gender.map(({ id, gender }) => (
                                        <MenuItem value={id} key={id}>
                                            {gender}
                                        </MenuItem>
                                    ))}
                            </Select>
                            {isFormSubmit && errors[MEMBER_FORM_FILED.gender] ? (
                                <Box pl={2} pr={2} pt={0.25} color="error.main">
                                    <FormErrorMessage title={errors[MEMBER_FORM_FILED.gender]} />
                                </Box>
                            ) : touched[MEMBER_FORM_FILED.gender] &&
                                errors[MEMBER_FORM_FILED.gender] ? (
                                <Box pl={2} pr={2} pt={0.25} color="error.main">
                                    <FormErrorMessage title={errors[MEMBER_FORM_FILED.gender]} />
                                </Box>
                            ) : (
                                ''
                            )}
                        </FormControl>
                        <FormControl fullWidth>
                            <InputMask mask="999-99-9999"
                                maskChar={null}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                value={values[MEMBER_FORM_FILED.socialSecurityNumber]}
                            >
                                {() => <TextField
                                    id="standard-basic"
                                    label={
                                        <Box display="flex" alignItems="center">
                                            Social Security Number<Box color="primary.main">*</Box>
                                        </Box>
                                    }
                                    onBlur={handleBlur}
                                    value={values[MEMBER_FORM_FILED.socialSecurityNumber]}
                                    name={MEMBER_FORM_FILED['socialSecurityNumber']}
                                    variant="filled"
                                    error={!!errors[MEMBER_FORM_FILED.socialSecurityNumber]}
                                    helperText={
                                        isFormSubmit &&
                                            errors[MEMBER_FORM_FILED.socialSecurityNumber] ? (
                                            <FormErrorMessage
                                                title={errors[MEMBER_FORM_FILED.socialSecurityNumber]}
                                            />
                                        ) : touched[MEMBER_FORM_FILED.socialSecurityNumber] &&
                                            errors[MEMBER_FORM_FILED.socialSecurityNumber] ? (
                                            <FormErrorMessage
                                                title={errors[MEMBER_FORM_FILED.socialSecurityNumber]}
                                            />
                                        ) : (
                                            ''
                                        )
                                    }
                                />}
                            </InputMask>
                            <Box
                                mt={1}
                                mb={1}
                                fontSize="md.fontSize"
                                fontStyle="italic"
                                color="primary.main">
                                If the individual does not have a Social Security Number, enter all
                                nines into the field instead (e.g. 999-99-9999)
                            </Box>
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                id="standard-basic"
                                label={
                                    <Box display="flex" alignItems="center">
                                        Yearly Income<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                variant="filled"
                                name={MEMBER_FORM_FILED['yearlyIncome']}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                InputProps={{
                                    startAdornment:
                                        <Box mt={2}>
                                            <InputAdornment position="start">
                                                $
                                            </InputAdornment>
                                        </Box>,
                                }}
                                value={values[MEMBER_FORM_FILED.yearlyIncome]}
                                error={!!errors[MEMBER_FORM_FILED.yearlyIncome]}
                                helperText={
                                    isFormSubmit && errors[MEMBER_FORM_FILED.yearlyIncome] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.yearlyIncome]}
                                        />
                                    ) : touched[MEMBER_FORM_FILED.yearlyIncome] &&
                                        errors[MEMBER_FORM_FILED.yearlyIncome] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.yearlyIncome]}
                                        />
                                    ) : (
                                        ''
                                    )
                                }
                            />
                        </FormControl>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">
                                <Box display="flex" alignItems="center">
                                    Pay Frequency<Box color="primary.main">*</Box>
                                </Box>
                            </InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                IconComponent={ExpandMoreOutlinedIcon}
                                name={MEMBER_FORM_FILED['payFrequencyId']}
                                displayEmpty
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                value={values[MEMBER_FORM_FILED.payFrequencyId]}
                                error={!!errors[MEMBER_FORM_FILED.payFrequencyId]}>
                                {payFrequency &&
                                    payFrequency.map(({ id, frequency }) => (
                                        <MenuItem value={id} key={id}>
                                            {frequency}
                                        </MenuItem>
                                    ))}
                            </Select>
                            {isFormSubmit && errors[MEMBER_FORM_FILED.payFrequencyId] ? (
                                <Box pl={2} pr={2} pt={0.25} color="error.main">
                                    <FormErrorMessage
                                        title={errors[MEMBER_FORM_FILED.payFrequencyId]}
                                    />
                                </Box>
                            ) : touched[MEMBER_FORM_FILED.payFrequencyId] &&
                                errors[MEMBER_FORM_FILED.payFrequencyId] ? (
                                <Box pl={2} pr={2} pt={0.25} color="error.main">
                                    {' '}
                                    <FormErrorMessage
                                        title={errors[MEMBER_FORM_FILED.payFrequencyId]}
                                    />
                                </Box>
                            ) : (
                                ''
                            )}
                        </FormControl>
                        <FormControl fullWidth>
                            <TextField
                                id="standard-basic"
                                label={
                                    <Box display="flex" alignItems="center">
                                        Paycheck Amount<Box color="primary.main">*</Box>
                                    </Box>
                                }
                                variant="filled"
                                name={MEMBER_FORM_FILED['paycheckAmount']}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                InputProps={{
                                    startAdornment:
                                        <Box mt={2}>
                                            <InputAdornment position="start">
                                                $
                                            </InputAdornment>
                                        </Box>,
                                }}
                                value={values[MEMBER_FORM_FILED.paycheckAmount]}
                                error={!!errors[MEMBER_FORM_FILED.paycheckAmount]}
                                helperText={
                                    isFormSubmit && errors[MEMBER_FORM_FILED.paycheckAmount] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.paycheckAmount]}
                                        />
                                    ) : touched[MEMBER_FORM_FILED.paycheckAmount] &&
                                        errors[MEMBER_FORM_FILED.paycheckAmount] ? (
                                        <FormErrorMessage
                                            title={errors[MEMBER_FORM_FILED.paycheckAmount]}
                                        />
                                    ) : (
                                        ''
                                    )
                                }
                            />
                        </FormControl>
                    </Box>
                    <Box className={classes.xsBtn}>
                        <Button
                            size="large"
                            color="primary"
                            variant="contained"
                            type="submit"
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                            Next
                        </Button>
                    </Box>
                </Box>
            </form>
        </Box>
    );
};
HouseholdMemberDetails.propTypes = {
    title: PropTypes.string,
    onNextButtonClick: PropTypes.func,
    width: PropTypes.string,
    gender: PropTypes.array,
    citizenShip: PropTypes.array,
    relationShip: PropTypes.array,
    payFrequency: PropTypes.array
};
export default withWidth()(HouseholdMemberDetails);
