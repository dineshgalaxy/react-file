import {
    Box,
    Button,
    Checkbox,
    FormControl,
    FormControlLabel,
    InputLabel,
    MenuItem,
    Select
} from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import ExpandMoreOutlinedIcon from '@material-ui/icons/ExpandMoreOutlined';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { MEMBER_FORM_FILED } from '~/modules/HouseHoldModule/Utils/HouseHoldConstants';
import FormErrorMessage from '~/shared/components/FormErrorMessage';
import useStyles from '~/modules/HouseHoldModule/HouseholdMembers/HouseholdStyle';
import useHouseholdMemberMoreDetailsForm from './useHouseholdMoreDetailsForm';

/**
 * Name : HouseholdMemberMoreDetails
 * Desc : Render HouseholdMemberMoreDetails
 */

const HouseholdMemberMoreDetails = ({
    title,
    firstName,
    onNextButtonClick,
    width,
    raceEthnics,
}) => {
    const classes = useStyles();
    const {
        values,
        handleOnChange,
        handleSubmit,
        errors,
        touched,
        handleBlur,
        setCustomValue,
        isFormSubmit
    } = useHouseholdMemberMoreDetailsForm();

    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onNextButtonClick(values);
        }
    };

    const handleCheckBoxSelect = (event) => {
        const { value } = event.target;
        let allCheckBoxData = [...values.raceEthnics];
        if (allCheckBoxData.length) {
            const index = allCheckBoxData.indexOf(value);
            if (index > -1) {
                allCheckBoxData.splice(index, 1);
            } else {
                allCheckBoxData = [...allCheckBoxData, value];
            }
        } else {
            allCheckBoxData = [value];
        }
        setCustomValue('raceEthnics', allCheckBoxData);
    };

    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337} mb={1}>
                <Box fontSize="h5.fontSize" lineHeight="35px" color="primary.light" mb={1.5}>
                    {title}
                </Box>
            </Box>
            <form onSubmit={(e) => handleFormSubmit(e)}>
                <Box className={classes.textAlign} width="100%">
                    <Box mb={2} mt={0.75}>
                        <Box mb={1} fontSize="h6.fontSize" color="primary.light">
                            Is {firstName} disabled?
                            <Box component="span" color="primary.main">
                                *
                            </Box>
                        </Box>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">Select</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                name={MEMBER_FORM_FILED['isDisabled']}
                                IconComponent={ExpandMoreOutlinedIcon}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                error={!!errors[MEMBER_FORM_FILED.isDisabled]}
                                value={values[MEMBER_FORM_FILED.isDisabled]}>
                                <MenuItem value="true">Yes</MenuItem>
                                <MenuItem value="false">No</MenuItem>
                            </Select>
                            {isFormSubmit && errors[MEMBER_FORM_FILED.isDisabled] ? (
                                <FormErrorMessage title={errors[MEMBER_FORM_FILED.isDisabled]} />
                            ) : touched[MEMBER_FORM_FILED.isDisabled] &&
                              errors[MEMBER_FORM_FILED.isDisabled] ? (
                                <FormErrorMessage title={errors[MEMBER_FORM_FILED.isDisabled]} />
                            ) : (
                                ''
                            )}
                        </FormControl>
                        <Box mb={1} fontSize="h6.fontSize" color="primary.light">
                            Is {firstName} a full-time student?
                            <Box component="span" color="primary.main">
                                *
                            </Box>
                        </Box>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">Select</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                name={MEMBER_FORM_FILED['isFulltimeStudent']}
                                IconComponent={ExpandMoreOutlinedIcon}
                                displayEmpty
                                error={!!errors[MEMBER_FORM_FILED.isFulltimeStudent]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                value={values[MEMBER_FORM_FILED.isFulltimeStudent]}>
                                <MenuItem value="true">Yes</MenuItem>
                                <MenuItem value="false">No</MenuItem>
                            </Select>
                            {isFormSubmit && errors[MEMBER_FORM_FILED.isFulltimeStudent] ? (
                                <FormErrorMessage
                                    title={errors[MEMBER_FORM_FILED.isFulltimeStudent]}
                                />
                            ) : touched[MEMBER_FORM_FILED.isFulltimeStudent] &&
                              errors[MEMBER_FORM_FILED.isFulltimeStudent] ? (
                                <FormErrorMessage
                                    title={errors[MEMBER_FORM_FILED.isFulltimeStudent]}
                                />
                            ) : (
                                ''
                            )}
                        </FormControl>
                        <Box mb={1} fontSize="h6.fontSize" color="primary.light">
                            Will {firstName} become a full-time student within the next year?
                            <Box component="span" color="primary.main">
                                *
                            </Box>
                        </Box>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">Select</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                name={MEMBER_FORM_FILED['isStudentNextYear']}
                                IconComponent={ExpandMoreOutlinedIcon}
                                displayEmpty
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                error={!!errors[MEMBER_FORM_FILED.isStudentNextYear]}
                                value={values[MEMBER_FORM_FILED.isStudentNextYear]}>
                                <MenuItem value="true">Yes</MenuItem>
                                <MenuItem value="false">No</MenuItem>
                            </Select>
                            {isFormSubmit && errors[MEMBER_FORM_FILED.isStudentNextYear] ? (
                                <FormErrorMessage
                                    title={errors[MEMBER_FORM_FILED.isStudentNextYear]}
                                />
                            ) : touched[MEMBER_FORM_FILED.isStudentNextYear] &&
                              errors[MEMBER_FORM_FILED.isStudentNextYear] ? (
                                <FormErrorMessage
                                    title={errors[MEMBER_FORM_FILED.isStudentNextYear]}
                                />
                            ) : (
                                ''
                            )}
                        </FormControl>
                        <Box mb={1} fontSize="h6.fontSize" color="primary.light">
                            Is {firstName} subject to a lifetime sex offender registration?
                            <Box component="span" color="primary.main">
                                *
                            </Box>
                        </Box>
                        <FormControl variant="filled" fullWidth>
                            <InputLabel id="demo-simple-select-label">Select</InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                name={MEMBER_FORM_FILED['lifetimeSexOffenderReg']}
                                IconComponent={ExpandMoreOutlinedIcon}
                                displayEmpty
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                error={!!errors[MEMBER_FORM_FILED.lifetimeSexOffenderReg]}
                                value={values[MEMBER_FORM_FILED.lifetimeSexOffenderReg]}>
                                <MenuItem value="true">Yes</MenuItem>
                                <MenuItem value="false">No</MenuItem>
                            </Select>
                            {isFormSubmit && errors[MEMBER_FORM_FILED.lifetimeSexOffenderReg] ? (
                                <FormErrorMessage
                                    title={errors[MEMBER_FORM_FILED.lifetimeSexOffenderReg]}
                                />
                            ) : touched[MEMBER_FORM_FILED.lifetimeSexOffenderReg] &&
                              errors[MEMBER_FORM_FILED.lifetimeSexOffenderReg] ? (
                                <FormErrorMessage
                                    title={errors[MEMBER_FORM_FILED.lifetimeSexOffenderReg]}
                                />
                            ) : (
                                ''
                            )}
                        </FormControl>
                        <Box mb={2} fontSize="h6.fontSize" color="primary.light">
                            Check any races or ethnicities that apply for {firstName}.
                        </Box>
                        {raceEthnics &&
                            raceEthnics.map(({ id, type }) => {
                                return values[MEMBER_FORM_FILED.raceEthnics]?.includes(id) ? (
                                    <FormControl fullWidth className="noMargin" key={id}>
                                        <FormControlLabel
                                            control={
                                                <Checkbox
                                                    checked={true}
                                                    inputProps={{
                                                        'aria-label': 'primary checkbox'
                                                    }}
                                                />
                                            }
                                            onChange={handleCheckBoxSelect}
                                            value={id}
                                            label={type}
                                            name={MEMBER_FORM_FILED['raceEthnics']}
                                        />
                                    </FormControl>
                                ) : (
                                    <FormControl fullWidth className="noMargin" key={id}>
                                        <FormControlLabel
                                            control={
                                                <Checkbox
                                                    inputProps={{
                                                        'aria-label': 'primary checkbox'
                                                    }}
                                                />
                                            }
                                            onChange={handleCheckBoxSelect}
                                            value={id}
                                            label={type}
                                            name={MEMBER_FORM_FILED['raceEthnics']}
                                        />
                                    </FormControl>
                                );
                            })}
                    </Box>

                    <Box className={classes.xsBtn}>
                        <Button
                            size="large"
                            color="primary"
                            variant="contained"
                            type="submit"
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                            Next
                        </Button>
                    </Box>
                </Box>
            </form>
        </Box>
    );
};
HouseholdMemberMoreDetails.propTypes = {
    title: PropTypes.string,
    onNextButtonClick: PropTypes.func,
    width: PropTypes.string,
    raceEthnics: PropTypes.array,
    firstName: PropTypes.string
};
export default withWidth()(HouseholdMemberMoreDetails);
