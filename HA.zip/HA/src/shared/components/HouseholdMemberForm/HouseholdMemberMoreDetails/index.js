export { default } from './HouseholdMemberMoreDetails';
