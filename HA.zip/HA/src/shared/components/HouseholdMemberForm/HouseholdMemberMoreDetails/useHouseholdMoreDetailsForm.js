import { useSelector } from 'react-redux';
import { onValidateAdditionalMemberSecondForm } from '~/modules/HouseHoldModule/Utils/HouseHoldUtils';
import useForm from '~/shared/customHooks/useForm';

const useHouseholdMemberMoreDetailsForm = () => {
    const {
        additionalFormInfo = {},
        activeMember,
    } = useSelector((state) => state.houseHoldDetails);

    const initialValue = {
        is_disabled: additionalFormInfo[activeMember]?.is_disabled || '',
        is_fulltime_student: additionalFormInfo[activeMember]?.is_fulltime_student || '',
        is_student_next_year: additionalFormInfo[activeMember]?.is_student_next_year || '',
        lifetime_sex_offender_reg:
            additionalFormInfo[activeMember]?.lifetime_sex_offender_reg || '',
        raceEthnics: additionalFormInfo[activeMember]?.raceEthnics || []
    };


    const {
        values,
        handleOnChange,
        handleSubmit,
        errors,
        touched,
        handleBlur,
        setCustomValue,
        isFormSubmit
    } = useForm(initialValue, onValidateAdditionalMemberSecondForm)

    return {
        handleOnChange,
        values,
        handleSubmit,
        errors,
        handleBlur,
        touched,
        isFormSubmit,
        setCustomValue,
        initialValue,
        activeMember
    };
}

export default useHouseholdMemberMoreDetailsForm
