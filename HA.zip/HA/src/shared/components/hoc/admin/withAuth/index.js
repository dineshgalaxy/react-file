import React from 'react';
import Router from 'next/router';
import { Box, Grid } from '@material-ui/core';
import Loader from '~/shared/components/Loader';
import AdminNavbar from '~/shared/components/Admin/AdminNavbar';
import AdminSidebar from '~/shared/components/Admin/AdminSidebar';
import { ROUTES } from '~/shared/constants/routesConstants';
import { getAccessToken } from '~/shared/utils/utils';

const withAuth = (Component = null, Layout = false) => {
    class withAuth extends React.Component {
        state = {
            loading: true
        };

        componentDidMount() {
            if (getAccessToken()) {
                this.setState({ loading: false });
            } else {
                Router.push(ROUTES.SUPERVISOR_LOGIN.ROUTE);
            }
        }

        renderLayoutBasedComponent = () => {
            if (Layout) {
                return (
                    <Box>
                        <AdminNavbar />
                        <Box>
                            <div style={{ paddingTop: "80px" }}>
                                <Grid container spacing={1}>
                                    <AdminSidebar />
                                    <Component {...this.props} />
                                </Grid>
                            </div>
                        </Box>
                    </Box>
                );
            }

            return <Component {...this.props} />;
        };

        render() {
            const { loading } = this.state;

            if (loading) {
                return <Loader />;
            }

            return <>{this.renderLayoutBasedComponent()}</>;
        }
    }

    return withAuth;
};

export default withAuth;
