import { useToasts } from 'react-toast-notifications';

const withToast = (Components) =>
    function WrappedComponent(props) {
        const toastFuncs = useToasts();
        return <Components {...props} {...toastFuncs} />;
    };

    export default withToast