import PropTypes from 'prop-types'; // ES6
import React from 'react';
import Footer from '../Footer/Footer';
import SubFooter from '../Footer/SubFooter';
import Header from '../Header/MainHeader';

const Layout = ({ children, showHeader, showFooter }) => {
    return (
        <>
            {showHeader ? <Header /> : null}
            {children}
            {showFooter ? <Footer /> : null}
            {showFooter ? <SubFooter /> : null}
        </>
    );
};

Layout.defaultProps = {
    showHeader: true,
    showFooter: true
};

Layout.propTypes = {
    children: PropTypes.node.isRequired,
    showHeader: PropTypes.bool,
    showFooter: PropTypes.bool
};

export { Layout };
