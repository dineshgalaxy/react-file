import { makeStyles } from '@material-ui/core';
const useStyles = makeStyles((theme) => ({
    primaryAlert:{
        backgroundColor:theme.palette.primary.main,
        color:theme.common.white,
        boxShadow:"none",
        borderRadius:"0"
    },
    secondaryAlert:{
        backgroundColor:theme.palette.menus.menuBackground,
        color:theme.palette.primary.light,
        boxShadow:"none",
        borderRadius:"0"
    }
}));
export default useStyles;