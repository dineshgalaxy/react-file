import { Card, IconButton } from '@material-ui/core';
import { Alert } from '@material-ui/lab';
import { X } from 'react-feather';
import React from 'react';
import useStyles from './AlertsStyles';
import PropTypes from 'prop-types';

/**
 * Name: Alerts
 * Desc: Render Alerts
 */

const Alerts = ({ variant, iconColor, children, showCloseBtn }) => {
    const classes = useStyles();
    return (
        <>
            <Card className={classes[variant]}>
                <Alert
                    action={
                        showCloseBtn && (
                            <IconButton>
                                <X strokeWidth="3" color={iconColor}/>
                            </IconButton>
                        )}
                    >
                { children && children }
                </Alert>
            </Card>
        </>
    )
}

Alerts.defaultProps ={
    showCloseBtn: false
};

Alerts.propTypes = {
    variant: PropTypes.oneOf(["primaryAlert", "secondaryAlert"]),
    iconColor: PropTypes.oneOf(["white", "indigo"]),
    children: PropTypes.node,
    showCloseBtn: PropTypes.bool
};
export default Alerts
