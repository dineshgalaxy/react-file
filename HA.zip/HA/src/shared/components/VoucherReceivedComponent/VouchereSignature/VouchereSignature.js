import { Box, Button, Checkbox, FormControl, FormControlLabel, TextField } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../VoucherReceivedStyles';

/**
 * Name : VouchereSignature
 * Desc : VouchereSignature
 */
const VouchereSignature = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box width="100%">
                <Box pb={2}>
                    <Box mx={-3} mb={3} px={3} pb={1} className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.extraLight"
                            pb={.5}>
                            Your Voucher Details
                        </Box>
                    </Box>
                    <Box mb={5}>
                        <Box color="primary.light" fontSize="h6.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Name
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            Firstname Lastname
                        </Box>
                    </Box>
                    <Box mb={5}>
                        <Box color="primary.light" fontSize="h6.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Voucher Number
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            T123456
                        </Box>
                    </Box>
                    <Box mb={5}>
                        <Box color="primary.light" fontSize="h6.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Maximum Unit Size
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            up to [X] bedroom(s)
                        </Box>
                    </Box>
                    <Box mb={5}>
                        <Box color="primary.light" fontSize="h6.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Voucher Issue Date
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            [Date of Issue]
                        </Box>
                    </Box>
                    <Box mb={5}>
                        <Box color="primary.light" fontSize="h6.fontSize" fontFamily="fontFamily.medium" pb={1}>
                            Voucher Expiration Date
                        </Box>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            [Date of Expiration]
                        </Box>
                    </Box>
                </Box>
                <Box pb={8}>
                    <Box mx={-3} mb={3} px={3} pb={1} className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.extraLight"
                            pb={.5}>
                            Terms & Disclosures
                        </Box>
                    </Box>
                    <Box fontSize="sm.fontSize" color="primary.light" lineHeight="23px" pb={1} className={classes.scrollContent}>
                        <Box fontSize="md.fontSize" fontFamily="fontFamily.medium" pb={1}>Sections if Needed</Box>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ipsum sed tristique praesent nibh adipiscing nulla facilisi eu, placerat. Elementum quam pulvinar at orci platea commodo mattis. In consequat praesent tempus, nec orci. Facilisis quisque aliquam nunc non condimentum volutpat. In consequat praesent tempus, nec orci. Facilisis quisque aliquam nunc non condimentum volutpat. In consequat praesent tempus, nec orci. Facilisis quisque aliquam nunc non condimentum volutpat. In consequat praesent tempus, nec orci.
                    </Box>
                </Box>
                <Box>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="I have read and accept the above terms and conditions of my voucher"
                        />
                    </FormControl>
                </Box>
                <Box mt={4} pb={width === 'xs' || width === 'sm' ? 1.5 : 6}>
                    <FormControl fullWidth>
                        <TextField
                            id="paycheckAmount"
                            label={
                                <Box display="flex" alignItems="center">
                                 Your Name<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <FormControl fullWidth>
                        <TextField
                            id="paycheckAmount"
                            label={
                                <Box display="flex" alignItems="center">
                                    Signature<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <Box mt={-1.5} color="primary.main" fontSize="md.fontSize" fontStyle="italic">
                        Type your name to sign 
                    </Box>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="secondary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Submit
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

VouchereSignature.propTypes = {
    width: PropTypes.string
};
export default withWidth()(VouchereSignature);
