import { Box, Button, Checkbox, FormControl, FormControlLabel, TextField } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import useStyles from '../VoucherReceivedStyles';

/**
 * Name : AcknowledgementtoSelectDwelling
 * Desc : AcknowledgementtoSelectDwelling
 */

const AcknowledgementtoSelectDwelling = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box width="100%">
                <Box pb={2}>
                    <Box mx={-3} mb={3} px={3} pb={1} className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.extraLight"
                            pb={.5}>
                            Acknowledgement to Select Dwelling Unit
                        </Box>
                    </Box>
                    <Box mb={5.5}>
                        <Box color="primary.light" fontSize="h6.fontSize">
                            I have been informed and understand that I have the right to select any eligbile unit, including units owned by the Housing Authority of the City of El Paso, without pressure or steering.
                        </Box>
                    </Box>
                </Box>
                <Box>
                    <FormControl fullWidth className="noMargin">
                        <FormControlLabel
                            control={
                                <Checkbox
                                    checked={true}
                                    inputProps={{ 'aria-label': 'primary checkbox' }}
                                />
                            }
                            label="I have read and accept the above terms and conditions of my voucher"
                        />
                    </FormControl>
                </Box>
                <Box mt={4} pb={width === 'xs' || width === 'sm' ? 3.5 : 6}>
                    <FormControl fullWidth>
                        <TextField
                            id="paycheckAmount"
                            label={
                                <Box display="flex" alignItems="center">
                                    Signature<Box color="primary.main">*</Box>
                                </Box>
                            }
                            variant="filled"
                        />
                    </FormControl>
                    <Box mt={-1.5} color="primary.main" fontSize="md.fontSize" fontStyle="italic">
                        Type your name to sign 
                    </Box>
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        size="large"
                        color="secondary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Confirm and Submit
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}


AcknowledgementtoSelectDwelling.propTypes = {
    width: PropTypes.string
};
export default withWidth()(AcknowledgementtoSelectDwelling);
