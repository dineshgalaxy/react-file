import { Avatar, Box, Button } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';
/**
 * Name: VoucherDeliveryContent
 * Desc: Render VoucherDeliveryContent
 */

const VoucherDeliveryContent = ({ width }) => {
    return (
        <Box
            maxWidth={958}
            width="100%"
            display={width === 'xs' || width === 'sm' ? 'block' : 'flex'}
            alignItems="center"
            justifyContent="center"
            flexDirection={width === 'xs' || width === 'sm' ? 'column' : 'row'}
            margin=" 0 auto">
            <Box>
                <Avatar
                    style={{
                        height: width === 'xs' ? '100%': 364,
                        width: width === 'xs' ? '100%' : 456
                    }}
                    alt="view"
                    src="/view.jpg"
                    variant="square"
                />
            </Box>
            <Box
                padding={width === 'xs' || width === 'sm' ? 0 : ''}
                pl={width === 'xs' || width === 'sm' ? 0 : 6.5}
                pr={width === 'xs' || width === 'sm' ? 0 : 0}
                pt={width === 'xs' || width === 'sm' ? 3.5 : 0}
                pb={width === 'xs' || width === 'sm' ? 5 : 0}
                textAlign="center"
                >
                <Box
                    color="primary.light"
                    fontFamily="fontFamily.semiBold"
                    fontSize={width === 'xs' || width === 'sm' ? 'h5.fontSize' : 'h3.fontSize'}
                    lineHeight={width === 'xs' || width === 'sm' ? 'normal' : '43px'}>
                    Find a rental unit using the GoSection8.com website.
                </Box>
                <Box color="primary.light" fontSize="h6.fontSize" pt={1.5} pb={width === 'xs' || width === 'sm' ? 5 : 4.5} lineHeight="26px">
                    Use GoSection8.com to browse participating rental properties. Once you’ve selected a unit you intend to rent, provide the landlord with the voucher number below for their paperwork.
                </Box>
                <Button size="large" color="primary" variant="contained">
                    Visit GoSection8
                </Button>
            </Box>
        </Box>
    );
}

VoucherDeliveryContent.propTypes = {
    width: PropTypes.string
};
export default withWidth()(VoucherDeliveryContent);

