import { Box, Button } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import { ChevronRight, FileText } from 'react-feather';
import React from 'react'
import useStyles from '../VoucherReceivedStyles';
import PropTypes from 'prop-types';
import Image from 'next/image';
import clsx from 'clsx';
import Indicators from '../../Indicators';

/**
 * Name : VoucherVideo
 * Desc : Render VoucherVideo
 */

const VoucherVideo = ({ width }) => {
    const classes = useStyles();
    return (
        <Box className={classes.flex} width="100%">
            <Box 
                fontSize="h5.fontSize"
                lineHeight="35px" 
                color="primary.light" 
                mb={1.5}
                mx={width === 'xs' ? -3 : 0}
                mt={width === 'xs' ? -3 : 0}
                maxWidth={width === 'xs' || width === 'sm' ? 'calc(100% + 48px)' : 437}
                position="relative">
                    <Image
                        src="/videobg.jpg"
                        width={375}
                        height={179}
                    />
                    <Box className={classes.centerPlayIcon}>
                        <Indicators
                            status="success"
                            iconColor="indigo"
                            iconName="play"
                        />
                    </Box>
            </Box>
            <Box width="100%" pl={width === 'xs' || width === 'sm' ? 0 : 6}>
                <Box fontSize="h5.fontSize" fontFamily="fontFamily.medium" color="primary.extraLight" pb={.5}>
                    Title of the Video
                </Box>
                <Box>
                    <Button
                        style={{
                            color: 'Indigo',
                            fontSize: '15px'
                        }}
                        size="medium"
                        className="linkBtn"
                        endIcon={<ChevronRight color="Indigo" size={14} />}
                        startIcon={<FileText color="Indigo" size={16} />}
                        >
                            View Transcript 
                    </Button>
                </Box>
                <Box>
                    <Button
                        style={{
                            color: 'Indigo',
                            fontSize: '15px'
                        }}
                        size="medium"
                        className="linkBtn"
                        endIcon={<ChevronRight color="Indigo" size={14} />}
                        startIcon={<FileText color="Indigo" size={16} />}
                        >
                           Ver transcripción en español
                    </Button>
                </Box>
                <Box fontSize="md.fontSize" color="primary.light" pt={3} pb={width === 'xs' || width === 'sm' ? 1.2 : 6}>
                    HACEP requires all tenants to watch and review this video. By selecting “Continue” below, you are verifying that you have seen and understand the video’s contents.
                </Box>
                <Box className={classes.xsBtn}>
                    <Button
                        type="submit"
                        size="large"
                        color="primary"
                        variant="contained"
                        fullWidth={width === 'xs' || width === 'sm' ? true : false}
                        className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                        Continue
                    </Button>
                </Box>
            </Box>
        </Box>
    )
}

VoucherVideo.propTypes = {
    width: PropTypes.string,
};

export default withWidth()(VoucherVideo);

