export { default } from './CommonCard';
