import { Box, Card, IconButton } from '@material-ui/core';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { ArrowLeft, ChevronLeft } from 'react-feather';
import useStyles from './CommonCardStyle';

/**
 * Name: CommonCard
 * Desc: Render CommonCard
 */

const CommonCard = ({
    bgColor,
    isStatusCard,
    onClickBack,
    showBackBtn,
    showHeader,
    noMargin,
    children,
    bgScreen,
    backBtnColor,
    space,
    pageView,
    landingPageIcon
}) => {
    const classes = useStyles();
    const cardClass = clsx(
        classes.root,
        classes[bgColor],
        classes[bgScreen],
        classes[space],
        classes[pageView],
        {
            [classes.noMargin]: noMargin,
            [classes.welcomePage]: isStatusCard,
            [classes.header]: showHeader
        }
    );

    return (
        <Card className={cardClass}>
            <Box className={classes.subRoot}>
                {landingPageIcon && (
                    <Box mb={4}>
                        <IconButton className={classes.mobileBackBtn} onClick={onClickBack}>
                            <ArrowLeft color="Indigo" strokeWidth={3} size={20} />
                        </IconButton>
                    </Box>
                )}

                {showBackBtn && (
                    <Box display="flex" alignItems="center" className={classes.iconRoot}>
                        <IconButton
                            className={clsx(
                                classes[backBtnColor],
                                isStatusCard ? classes.goBackBtn1 : classes.goBackBtn2
                            )}
                            onClick={onClickBack}>
                            <ArrowLeft color="Indigo" size={20} className={classes.visibleXs} />
                            <ChevronLeft
                                color="Indigo"
                                size={30}
                                className={classes.visibleDesktop}
                            />
                        </IconButton>
                        <Box
                            color={
                                backBtnColor !== 'backBtnPrimary'
                                    ? 'common.white'
                                    : 'button.secondaryColor'
                            }
                            ml={2}
                            className={classes.visibleDesktop}>
                            Go Back
                        </Box>
                    </Box>
                )}
                {children}
            </Box>
        </Card>
    );
};

CommonCard.defaultProps = {
    bgColor: 'white',
    showHeader: false,
    children: '',
    showFaceBookLoginButton: false,
    isProfileSetup: false,
    isStatusCard: false,
    noMargin: false,
    showBackBtn: true,
    bgScreen: 'none',
    backBtnColor: 'backBtnPrimary',
    space: 'lg',
    pageView: 'half',
    landingPageIcon: false
};

CommonCard.propTypes = {
    bgColor: PropTypes.oneOf(['white', 'primary', 'gray', 'transparent']),
    onClickBack: PropTypes.func,
    onClickContinue: PropTypes.func,
    showHeader: PropTypes.bool,
    children: PropTypes.node,
    showFaceBookLoginButton: PropTypes.bool,
    isProfileSetup: PropTypes.bool,
    isStatusCard: PropTypes.bool,
    noMargin: PropTypes.bool,
    showBackBtn: PropTypes.bool,
    bgScreen: PropTypes.oneOf(['welcome', 'success', 'none']),
    backBtnColor: PropTypes.oneOf(['backBtnWhite', 'backBtnPrimary']),
    space: PropTypes.oneOf(['lg', 'xs']),
    pageView: PropTypes.oneOf(['full', 'half']),
    landingPageIcon: PropTypes.bool
};

export default CommonCard;
