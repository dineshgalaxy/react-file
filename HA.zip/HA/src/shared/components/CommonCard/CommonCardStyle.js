import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        padding: '24px 24px 52px',
        maxWidth: '960px',
        position: 'relative',
        zIndex: '1',
        [theme.breakpoints.down('xs')]: {
            padding: '24px 24px 52px'
        }
    },
    lg: {
        margin: '0 auto',
        [theme.breakpoints.down('xs')]: {
            margin: '-66px 24px 0'
        }
    },
    xs: {
        margin: 0
    },

    primary: {
        background: theme.palette.menus.menuBackground
    },

    white: {
        background: theme.palette.common.white
    },
    gray: {
        background: theme.common.gray
    },

    transparent: {
        background: 'transparent',
        boxShadow: 'none',
        [theme.breakpoints.down('xs')]: {
            margin: '-68px 0px 0'
        }
    },

    welcome: {
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundImage: `url('/splash.svg')`,
        [theme.breakpoints.down('sm')]: {
            backgroundImage: `url('/splashMobile.svg')`
        }
    },

    success: {
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundImage: `url('/successBg.svg')`,
        [theme.breakpoints.down('sm')]: {
            backgroundImage: `url('/successBgMobile.svg')`
        }
    },
    none: {
        backgroundImage: 'none'
    },

    subRoot: {
        maxWidth: '960px',
        margin: '0 auto',
        width: '100%',
        minHeight: '160px',
        [theme.breakpoints.down('sm')]: {
            minHeight: 'auto',
        }
    },
    full: {
        minHeight: '100vh',
        width: '100%',
        maxWidth: 'unset',
        display: 'flex',
        alignItems: 'center',
        borderRadius: '0',
        [theme.breakpoints.down('xs')]: {
            margin: '0 auto'
        }
    },

    half: {
        minHeight: 'auto'
    },

    header: {
        minHeight: 'calc(100vh - 78px)'
    },

    backBtnPrimary: {
        backgroundColor: 'rgba(151, 151, 191, 0.2)',
        '&:hover': {
            backgroundColor: theme.common.white,
            opacity: '0.5'
        },
        [theme.breakpoints.down('xs')]: {
            display: 'none'
        }
    },
    backBtnWhite: {
        backgroundColor: theme.common.white,
        '&:hover': {
            backgroundColor: theme.common.white,
            opacity: '0.5'
        }
    },

    visibleDesktop: {
        display: 'none',
        [theme.breakpoints.up('md')]: {
            display: 'block'
        }
    },
    visibleXs: {
        display: 'none',
        [theme.breakpoints.down('sm')]: {
            display: 'block'
        }
    },
    iconRoot: {
        paddingBottom: '30px',
        [theme.breakpoints.down('sm')]: {
            paddingBottom: '10px'
        },
        [theme.breakpoints.down('xs')]: {
            display: 'none'
        }
    },
    mobileBackBtn:{
        display:'none',
        [theme.breakpoints.down('xs')]: {
            backgroundColor: theme.common.white,
            display:'block',
            '&:hover': {
                backgroundColor: theme.common.white,
                opacity: '0.5'
            }
        }
        
    }
}));

export default useStyles;
