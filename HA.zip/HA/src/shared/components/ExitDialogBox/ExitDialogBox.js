import { Box, Button, DialogContent, DialogTitle, IconButton } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import PropTypes from 'prop-types';
import React from 'react';

/**
 * Name: ExitDialogBox
 * Desc: Render ExitDialogBox
 */

const ExitDialogBox = ({ onConfirm, onClose }) => {
    return (
        <>
            <DialogTitle id="simple-dialog-title">
                <IconButton aria-label="close" onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            </DialogTitle>
            <DialogContent>
                <Box textAlign="center" pt={2.5}>
                    <Box
                        fontSize="h3.fontSize"
                        fontFamily="fontFamily.bold"
                        color="primary.light"
                        pb={1}>
                        Are you sure you want to exit before finishing?
                    </Box>
                    <Box fontSize="lg.fontSize" color="primary.extraLight" mb={3}>
                        Any progress you’ve made won’t be saved yet.
                    </Box>
                </Box>
            </DialogContent>
            <Box>
                <Button
                    fullWidth
                    size="large"
                    color="secondary"
                    className="semiBorder"
                    variant="contained"
                    style={{
                        borderRadius: 0
                    }}
                    onClick={onConfirm}>
                    Yes, Exit Now
                </Button>
                <Button
                    fullWidth
                    size="large"
                    color="primary"
                    className="semiBorder"
                    variant="contained"
                    onClick={onClose}>
                    No, Keep Going
                </Button>
            </Box>
        </>
    );
};
ExitDialogBox.propTypes = {
    onConfirm: PropTypes.func,
    onClose: PropTypes.func
};
export default ExitDialogBox;
