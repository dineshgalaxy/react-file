export const APIS = {
    LOGIN_URL: 'api/v1/users/login',
    LOGOUT_URL: 'api/v1/users/logout',
    ELIGIBILITY_CALCULATOR: 'api/v1/mini-candidacy',
    SMTP_LIST: 'api/v1/admin-configuration/smtp',
    UPDATE_SMTP: 'api/v1/admin-configuration',
    PROGRAM_LIST: 'api/v1/programs',
    FETCH_WAIT_LIST: 'api/v1/programs/wait-list-type',
    CREATE_PROGRAM: 'api/v1/programs/create',
    FETCH_PREAPPLICATION_LIST: 'api/v1/programs/applicant/list',
    FETCH_SPECIFIC_APPLICANT: 'api/v1/users/review-pre-application',
    FETCH_APPLICANT_STATUS_LIST: 'api/v1/programs/status/list',
    UPDATE_APPLICANT_STATUS: 'api/v1/programs/update/status'
};
