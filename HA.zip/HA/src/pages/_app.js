import DateFnsUtils from '@date-io/date-fns';
import CssBaseline from '@material-ui/core/CssBaseline';
import { ThemeProvider } from '@material-ui/core/styles';
import { MuiPickersUtilsProvider } from '@material-ui/pickers';
import Head from 'next/head';
import PropTypes from 'prop-types';
import React from 'react';
import { Provider } from 'react-redux';
import { ToastProvider } from 'react-toast-notifications';
import { persistStore } from 'redux-persist';
import { PersistGate } from 'redux-persist/integration/react';
import { useStore } from 'shared/redux/store';
import 'shared/styles/globals.scss';
import theme from 'shared/utils/theme';
import GlobalStyles from '~/shared/utils/globalStyles';

/**
 * Name : App
 * Desc : Render App
 **/

export default function MyApp(props) {
    const { Component, pageProps } = props;
    const store = useStore(pageProps.initialReduxState);
    const persistor = persistStore(store, {}, function () {
        persistor.persist();
    });
    // var hideWidget = (window.location.href.indexOf("Home") > -1) ? true : false;

    // Remove the server-side injected CSS.

    return (
        <React.Fragment>
            <Head>
                <title>Hacep</title>
                <link rel="icon" type="image/png" sizes="32x32" href="/Client_Logo.png" />
                <meta
                    name="viewport"
                    content="minimum-scale=1, initial-scale=1, width=device-width"
                />
                {/* LocalizeJs starts*/}
                <script async src="https://global.localizecdn.com/localize.js"></script>
                <script>
                    {`!function(a){if(!a.Localize){a.Localize={};
                    for(var e=["translate","untranslate","phrase","initialize","translatePage","setLanguage","getLanguage","getSourceLanguage","detectLanguage","getAvailableLanguages","untranslatePage","bootstrap","prefetch","on","off","hideWidget","showWidget"],
                    t=0;t<e.length;t++)a.Localize[e[t]]=function(){}}}(window);`}
                </script>
                <script>
                    {`Localize.initialize({ key: '6744e827e2252', rememberLanguage: true, });`}
                </script>
                {/* LocalizeJs end*/}
            </Head>
            <ToastProvider autoDismiss>
                <ThemeProvider theme={theme}>
                    {/* CssBaseline kickstart an elegant, consistent, and simple baseline to build upon. */}
                    <GlobalStyles />
                    <CssBaseline />
                    <Provider store={store}>
                        <PersistGate loading={<div>loading</div>} persistor={persistor}>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <Component {...pageProps} />
                            </MuiPickersUtilsProvider>
                        </PersistGate>
                    </Provider>
                </ThemeProvider>
            </ToastProvider>
        </React.Fragment>
    );
}

MyApp.propTypes = {
    Component: PropTypes.elementType.isRequired,
    pageProps: PropTypes.object.isRequired
};
