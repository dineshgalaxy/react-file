import React from 'react';
import StyledFullPageFlowModule from '~/modules/StyledFullFlowPageModule';

/**
 * Name : CommonFullPageFlowStyle
 * desc : Render CommonFullPageFlowStyle
 **/
function CommonFullPageFlowStyle() {
    return (
            <StyledFullPageFlowModule />
    );
}

export default CommonFullPageFlowStyle;
