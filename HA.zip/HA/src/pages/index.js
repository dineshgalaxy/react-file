import React from 'react';
import 'semantic-ui-css/semantic.min.css';
import HomeModule from '~/modules/Home';

export default function Home() {
    return <HomeModule />;
}
