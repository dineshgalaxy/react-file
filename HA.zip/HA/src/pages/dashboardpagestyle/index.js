import React from 'react';
import DashboardPageStyleModule from '~/modules/DashboardPageStyleModule';

/**
 * Name : DashboardPageStyle
 * desc : Render DashboardPageStyle
 **/
function DashboardPageStyle() {
    return (
        <>
            <DashboardPageStyleModule/>
        </>
    );
}

export default DashboardPageStyle;