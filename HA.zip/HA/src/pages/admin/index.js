import React, {useEffect} from 'react';
import Router from 'next/router'
import 'semantic-ui-css/semantic.min.css';
import { ROUTES } from '~/shared/constants/routesConstants';

const AdminLogin = () => {
    useEffect(() => {
    Router.push(ROUTES.SUPERVISOR_LOGIN.ROUTE)
    }, [])

    return(<> </>)
}

export default AdminLogin