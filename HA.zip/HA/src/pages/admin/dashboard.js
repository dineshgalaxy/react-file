import React from 'react';
import DashboardModule from '~/modules/Admin/DashboardModule';
import "semantic-ui-css/semantic.min.css"
import withAuth from '~/shared/components/hoc/admin/withAuth';

const Dashboard = () => {
    return (
        <>
            <DashboardModule/>
        </>
    );
}

export default withAuth(Dashboard, true);