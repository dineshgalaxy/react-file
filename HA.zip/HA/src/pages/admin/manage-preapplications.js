import React from 'react';
import 'semantic-ui-css/semantic.min.css';
import ManagePreapplications from '~/modules/Admin/ManagePreapplications';
import withAuth from '~/shared/components/hoc/admin/withAuth';

const ManagePreapplication = () => {
    return (
        <>
            <ManagePreapplications />
        </>
    );
};

export default withAuth(ManagePreapplication, true);
