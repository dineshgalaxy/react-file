import React, {useEffect} from 'react';
import 'semantic-ui-css/semantic.min.css';
import LoginForm from '~/modules/Admin/Login';
import Router from 'next/router';
import Head from 'next/head';
import { ROUTES } from '~/shared/constants/routesConstants';
import { getAccessToken } from '~/shared/utils/utils';

const AdminLogin = () => {

    useEffect(() => {
        // If there is access token then not now allow user to access login page
        if(getAccessToken()) {
            Router.push(ROUTES.SUPERVISOR_DASHBOARD.ROUTE)
        }
    },[])

    return (
        <>
         <Head>
                <title>Admin Login</title>
                <link rel="icon" href="/Client_Logo.png" />
            </Head>
            {getAccessToken() ? '' : <LoginForm />}
        </>
    );
};

export default AdminLogin;
