import React from 'react';
import 'semantic-ui-css/semantic.min.css';
import ManagePrograms from '~/modules/Admin/ManagePrograms';
import withAuth from '~/shared/components/hoc/admin/withAuth';

const ManageProgram = () => {
    return (
        <>
            <ManagePrograms />
        </>
    );
};

export default withAuth(ManageProgram, true);
