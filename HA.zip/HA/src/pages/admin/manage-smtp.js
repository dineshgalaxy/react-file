import React from 'react'
import 'semantic-ui-css/semantic.min.css';
import ManagePrograms from '~/modules/Admin/ManageSmtp';
import withAuth from '~/shared/components/hoc/admin/withAuth';

const ManageSmtp = () => {
    return (
        <div>
            <ManagePrograms/>
        </div>
    )
}

export default withAuth(ManageSmtp, true)
