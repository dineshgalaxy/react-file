import React from 'react';
import 'semantic-ui-css/semantic.min.css';
import EligibilityCalculator from '~/modules/Admin/EligibilityCalculator';
import withAuth from '~/shared/components/hoc/admin/withAuth';

const Calculator = () => {
    return (
        <>
            <EligibilityCalculator />
        </>
    );
};

export default withAuth(Calculator, true);
