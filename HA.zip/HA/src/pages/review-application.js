import Head from 'next/head';
import React from 'react';
import styles from 'shared/styles/Home.module.scss';
import ReviewApplication from '~/modules/ReviewApplication';

export default function index() {
    return (
        <div className={styles.main}>
            <Head>
                <title>Check your eligibility</title>
                <link rel="icon" href="/favicon.ico" />
            </Head>

            <main className={styles.main}>
                <ReviewApplication />
            </main>
        </div>
    );
}
