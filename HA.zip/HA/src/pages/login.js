import Head from 'next/head';
import React from 'react';
import styles from 'shared/styles/Home.module.scss';
import LoinModule from '~/modules/LoginModule';

export default function index() {
    return (
        <div className={styles.main}>
            <Head>
                <title>Login</title>
                <link rel="icon" href="/Client_Logo.png" />
            </Head>

            <main className={styles.main}>
                <LoinModule />
            </main>
        </div>
    );
}
