import Head from 'next/head';
import React from 'react';
import styles from 'shared/styles/Home.module.scss';
import CreateProfileModule from '~/modules/CreateProfileModule';

export default function index() {
    return (
        <div className={styles.main}>
            <Head>
                <title>Create Profile</title>
                <link rel="icon" href="/Client_Logo.png" />
            </Head>

            <main className={styles.main}>
                <CreateProfileModule />
            </main>
        </div>
    );
}
