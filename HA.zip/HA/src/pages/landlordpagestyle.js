import React from 'react';
import LandlordPageStyleModule from '~/modules/LandlordPageStyleModule';

/**
 * Name : LandlordPageStyle
 * desc : Render LandlordPageStyle
 **/

const LandlordPageStyle = () => {
    return (
        <div>
            <LandlordPageStyleModule/>
        </div>
    )
}

export default LandlordPageStyle
