import Box from '@material-ui/core/Box';
import Button from '@material-ui/core/Button';
import Container from '@material-ui/core/Container';
import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { decrementCount, incrementCount } from '../shared/redux/actions';
import { getCounter } from '../shared/selectors/common';
import httpRequest, { METHODS } from '../shared/utils/axios';
function Examples() {
    const [apiData, setApiData] = useState({});
    const counter = useSelector((state) => getCounter(state));
    const dispatch = useDispatch();
    const handleReduxAction = (isInc) => {
        if (isInc) {
            dispatch(incrementCount());
        } else {
            dispatch(decrementCount());
        }
    };

    const handleApiCall = async () => {
        const [response, error] = await httpRequest({
            method: METHODS.POST,
            body: {
                name: 'morpheus',
                job: 'leader'
            },
            url: 'https://reqres.in/api/users?page=2'
        });

        if (!error) {
            setApiData(response);
        }
    };

    return (
        <Container maxWidth="sm">
            <Box my={12}>
                <h4> Env Variable</h4>
                {process.env.NEXT_PUBLIC_DEVELOPMENT_ENV_VARIABLE}
            </Box>
            <Box my={12}>
                <h4>Redux Example</h4>
                <Button role="button" variant="contained" color="primary" onClick={() => handleReduxAction(true)}>
                    Increment Count: {counter}
                </Button>
                <Button role="button"
                    variant="contained"
                    color="primary"
                    onClick={() => handleReduxAction(false)}>
                    Decrement Count: {counter}
                </Button>
            </Box>
            <Box my={12}>
                <h4>API call Example</h4>
                <Button role="button" variant="contained" color="primary" onClick={() => handleApiCall()}>
                    api call
                </Button>
                <br />
                <code>{JSON.stringify(apiData)}</code>
            </Box>
        </Container>
    );
}
export default Examples;
