import React from 'react';
import VoucherReceivedPageModule from '~/modules/VoucherReceivedPageModule';

/**
 * Name : voucherreceivedfullpagestyle
 * desc : Render voucherreceivedfullpagestyle
 **/
function voucherreceivedfullpagestyle() {
    return (
        <>
            <VoucherReceivedPageModule/>
        </>
    );
}

export default voucherreceivedfullpagestyle;