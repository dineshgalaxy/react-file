import Head from 'next/head';
import React from 'react';
import styles from 'shared/styles/Home.module.scss';
import HouseHoldModule from '~/modules/HouseHoldModule';

export default function index() {
    return (
        <div className={styles.main}>
            <Head>
                <title>House Hold Detail</title>
                <link rel="icon" href="/Client_Logo.png" />
            </Head>

            <main className={styles.main}>
                <HouseHoldModule />
            </main>
        </div>
    );
}
