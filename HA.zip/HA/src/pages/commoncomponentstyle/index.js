import React from 'react';
import StyledComponentModule from '~/modules/StyledComponentModule';


/** 
 * Name : CommonComponentStyle 
 * desc : Render CommonComponentStyle
**/
function CommonComponentStyle() {
    return (
        <>
            <StyledComponentModule/>
        </>
    );
}

export default CommonComponentStyle;