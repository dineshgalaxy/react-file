import { Box, Container, Grid, Link } from '@material-ui/core';
import { default as React } from 'react';
import { Archive, HelpCircle } from 'react-feather';
import MainHeader from 'shared/components/Header/MainHeader';
import TopHeader from 'shared/components/Header/TopHeader';
import Alert from '~/shared/components/Alert';
import CommonCard from '~/shared/components/CommonCard';
import DashboardAccount from '~/shared/components/DashboardPageComponent/DashboardAccount';
import DashboardAccountDetails from '~/shared/components/DashboardPageComponent/DashboardAccountDetails';
import DashboardContactUs from '~/shared/components/DashboardPageComponent/DashboardContactUs';
import DashboardHelpCenter from '~/shared/components/DashboardPageComponent/DashboardHelpCenter';
import DashboardHelpTopics from '~/shared/components/DashboardPageComponent/DashboardHelpTopics';
import DashboardHome from '~/shared/components/DashboardPageComponent/DashboardHome';
import DashboardNoPrograms from '~/shared/components/DashboardPageComponent/DashboardNoPrograms';
import DashboardYourApplication from '~/shared/components/DashboardPageComponent/DashboardYourApplication';
import YourVoucher from '~/shared/components/DashboardPageComponent/YourVoucher';
import Footer from '~/shared/components/Footer';
import SubFooter from '~/shared/components/Footer/SubFooter';
import HelpCenter from '~/shared/components/HelpCenter';
import ObjectCard from '~/shared/components/ObjectCard';
import PageHeading from '~/shared/components/PageHeading';
import ProgramCard from '~/shared/components/ProgramCard';
import WizardHeader from '~/shared/components/WizardHeader';

/**
 * Name: DashboardPageStyleModule
 * Desc: Render DashboardPageStyleModule
 */

const DashboardPageStyleModule = () => {
    const linkArrays = [
        { text: 'See if you’re eligible >', icon: HelpCircle },
        { text: 'View (6) archived applications >', icon: Archive }
    ];

    return (
        <>
            <Grid container>
                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="Dashboard Home" />
                    </Box>
                    <TopHeader />
                    <MainHeader
                        isLoggedIn={true}
                        userName="Hello, Erika"
                        headerSubtitle="View your active housing applications below on your dashboard below."
                    />
                    <DashboardHome />
                    <HelpCenter />
                    <Footer />
                    <SubFooter />
                </Grid>

                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="Dashboard Account" />
                    </Box>
                    <MainHeader
                        isLoggedIn={true}
                        showMobileMenu={true}
                        mobileTitle="Your Account"
                        showBell={false}
                    />
                    <DashboardAccount />
                    <HelpCenter />
                    <Footer />
                    <SubFooter />
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="Dashboard Account Details" />
                    </Box>
                    <MainHeader
                        isLoggedIn={true}
                        showBackBtn={true}
                        mobileTitle="Account Details"
                        showBell={false}
                    />
                    <Container>
                        <DashboardAccountDetails />
                    </Container>
                    <HelpCenter />
                    <Footer />
                    <SubFooter />
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="Dashboard - Voucher" />
                    </Box>
                    <WizardHeader title="Your Voucher" />

                    <CommonCard>
                        <YourVoucher />
                    </CommonCard>
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="Dashboard Help Center" />
                    </Box>
                    <MainHeader
                        isLoggedIn={true}
                        mobileTitle="Help Center"
                        showBell={false}
                        showMobileMenu={true}
                    />
                    <Container>
                        <DashboardHelpCenter />
                    </Container>
                    <HelpCenter />
                    <Footer />
                    <SubFooter />
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="Dashboard - Help Topics" />
                    </Box>

                    <MainHeader
                        isLoggedIn={true}
                        showBackBtn={true}
                        mobileTitle="Help Topics"
                        showBell={false}
                    />
                    <Container>
                        <DashboardHelpTopics />
                    </Container>
                    <HelpCenter />
                    <Footer />
                    <SubFooter />
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="Dashboard - Contact Us" />
                    </Box>
                    <MainHeader
                        isLoggedIn={true}
                        showBackBtn={true}
                        mobileTitle="Contact Us"
                        showBell={false}
                    />

                    <DashboardContactUs />

                    <HelpCenter />
                    <Footer />
                    <SubFooter />
                </Grid>
                <Grid item xs={12} md={12} width="100%">
                    <Box mt={5}>
                        <PageHeading title="Dashboard Alerts" />
                    </Box>
                    <Box bgcolor="secondary.extraLight">
                        <MainHeader
                            isLoggedIn={true}
                            showBackBtn={true}
                            mobileTitle="Your Alerts"
                            showBell={false}
                        />

                        <Container>
                            <Box pb={3} pl={1} pr={1} mt={1}>
                                {[
                                    {
                                        title: 'Program Name for the Alert',
                                        subtitle:
                                            'Your name has been reached and you may complete a full application now.',
                                        time: '1d'
                                    },
                                    {
                                        title: 'Housing Choice Voucher',
                                        subtitle:
                                            'Your application is incomplete. Finish it now to keep your spot.',
                                        time: '3d'
                                    },
                                    {
                                        title: 'Tays (1BR)',
                                        subtitle:
                                            'There is an update on your application for this program.',
                                        time: '24w'
                                    },
                                    {
                                        title: 'Siesta Gardens (2BR)',
                                        subtitle:
                                            'Your application has been approved! Click here to find your next steps.',
                                        time: '52w'
                                    },
                                    {
                                        title: 'Siesta Gardens (2BR)',
                                        subtitle:
                                            'Your application has been approved! Click here to find your next steps.',
                                        time: '52w'
                                    },
                                    {
                                        title: 'Housing Choice Voucher',
                                        subtitle:
                                            'Your application has been approved! Click here to find your next steps.',
                                        time: '52w'
                                    }
                                ].map((item) => (
                                    <Box pt={3} key={item.title}>
                                        <Alert>
                                            <Box
                                                display="flex"
                                                alignItems="center"
                                                justifyContent="space-between">
                                                <Box>
                                                    <Box
                                                        fontSize="lg.fontSize"
                                                        fontFamily="fontFamily.bold"
                                                        color="primary.extraLight">
                                                        {item.title}
                                                    </Box>
                                                    <Box
                                                        fontSize="md.fontSize"
                                                        color="primary.extraLight"
                                                        pt={0.5}>
                                                        {item.subtitle}
                                                    </Box>
                                                </Box>
                                                <Box
                                                    display="flex"
                                                    minWidth="50px"
                                                    height="100%"
                                                    alignItems="center"
                                                    justifyContent="flex-end"
                                                    fontSize="xs.fontSize"
                                                    fontFamily="fontFamily.bold"
                                                    color="common.grayText"
                                                    mr={-2}>
                                                    <Box
                                                        display="inline-block"
                                                        width={9}
                                                        height={9}
                                                        bgcolor="error.main"
                                                        borderRadius="50%"
                                                        mr={0.75}></Box>
                                                    {item.time}
                                                </Box>
                                            </Box>
                                        </Alert>
                                    </Box>
                                ))}
                            </Box>
                            <Box
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.medium"
                                display="flex"
                                justifyContent="center"
                                pt={1}
                                pb={6}>
                                <Link href="#">Load Older Messages +</Link>
                            </Box>
                        </Container>
                    </Box>
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="No Programs" />
                    </Box>
                    <Box bgcolor="secondary.extraLight">
                        <MainHeader
                            isLoggedIn="true"
                            padding="0 0 24px"
                            userName="Hello, Erika"
                            headerSubtitle="You don’t have any active program applications right now."
                        />
                        <CommonCard bgColor="transparent" showBackBtn={false}>
                            <Box
                                mb={3}
                                borderColor="primary.main"
                                border="1px dashed"
                                borderRadius="21px">
                                <ObjectCard cardType="actionCard" iconName="plus">
                                    <Box
                                        color="primary.main"
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium">
                                        Start a New Pre-Application
                                    </Box>
                                </ObjectCard>
                            </Box>
                            <Box pt={2.5}>
                                {linkArrays.map((item) => (
                                    <Box mb={2} key={item.text}>
                                        <Link href="#" underline="none">
                                            <Box display="flex" alignItems="center">
                                                <item.icon
                                                    strokeWidth="2"
                                                    color="Indigo"
                                                    size={15}
                                                />
                                                <Box
                                                    fontSize="lg.fontSize"
                                                    color="primary.main"
                                                    fontFamily="fontFamily.medium"
                                                    ml={1.5}>
                                                    {item.text}
                                                </Box>
                                            </Box>
                                        </Link>
                                    </Box>
                                ))}
                            </Box>
                        </CommonCard>
                    </Box>
                    <Box mb={7}>
                        <DashboardNoPrograms />
                    </Box>
                    <HelpCenter />
                    <Footer />
                    <SubFooter />
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="Your Applications" />
                    </Box>
                    <MainHeader
                        isLoggedIn="true"
                        padding="0 0 24px"
                        userName="Your Applications"
                        headerSubtitle="View your active housing applications  or start a new application below."
                    />
                    <CommonCard bgColor="transparent" showBackBtn={false}>
                        <DashboardYourApplication />
                    </CommonCard>
                    <HelpCenter />
                    <Footer />
                    <SubFooter />
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box mt={5}>
                        <PageHeading title="Archived Application" />
                    </Box>
                    <Box bgcolor="secondary.extraLight">
                        <MainHeader
                            isLoggedIn={true}
                            showBackBtn={true}
                            mobileTitle="Archive"
                            showBell={false}
                        />
                        <Container>
                            <Box pb={3}>
                                {[
                                    {
                                        title: 'Housing Choice Voucher',
                                        subtitle: 'Archived 5/16/22'
                                    },
                                    {
                                        title: 'Siesta Gardens (2BR)',
                                        subtitle: 'Application Not Approved'
                                    },
                                    { title: 'DeWetter (2BR)', subtitle: 'Archived 5/16/22' },
                                    { title: 'Kathy White (2BR)', subtitle: 'Archived 5/16/22' },
                                    { title: 'Eisenhower (2BR)', subtitle: 'Archived 5/16/22' },
                                    { title: 'Krupp (2BR)', subtitle: 'Archived 5/16/22' }
                                ].map((item) => (
                                    <Box pt={3} key={item.title}>
                                        <ProgramCard
                                            variant="info"
                                            showImage={true}
                                            showLeftBorder={true}>
                                            <Box
                                                color="primary.main"
                                                fontSize="h6.fontSize"
                                                fontFamily="fontFamily.medium">
                                                {item.title}
                                            </Box>
                                            <Box
                                                component="body1"
                                                color="primary.light"
                                                fontSize="lg.fontSize"
                                                fontFamily="fontFamily.regular">
                                                {item.subtitle}
                                            </Box>
                                        </ProgramCard>
                                    </Box>
                                ))}
                            </Box>
                        </Container>
                        <Footer />
                        <SubFooter />
                    </Box>
                </Grid>
            </Grid>
        </>
    );
};

export default DashboardPageStyleModule;
