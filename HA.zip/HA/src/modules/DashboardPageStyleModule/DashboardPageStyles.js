import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    linkText: {
        [theme.breakpoints.up('sm')]: {
            display: 'block'
        }
    },
    success: {
        [theme.breakpoints.up('sm')]: {
            backgroundColor: `${theme.palette.secondary.light} !important`
        },
        '& > div:first-child': {
            [theme.breakpoints.down('sm')]: {
                backgroundColor: `${theme.palette.secondary.light} !important`
            }
        }
    },
    warning: {
        [theme.breakpoints.up('sm')]: {
            backgroundColor: `${theme.palette.pending.extraLight} !important`
        },
        '& > div:first-child': {
            [theme.breakpoints.down('sm')]: {
                backgroundColor: `${theme.palette.pending.extraLight} !important`
            }
        }
    },
    boxWrapper: {
        [theme.breakpoints.up('sm')]: {
            marginBottom: '100px',
            backgroundColor: theme.common.secondaryBgColor,
            padding: '0px 24px 24px'
        }
    },
    imageWrapper: {
        backgroundColor: theme.common.secondaryBgColor,
        [theme.breakpoints.up('sm')]: {
            backgroundColor: 'transparent',
            marginBottom: 0
        }
    },
    linkList: {
        [theme.breakpoints.up('sm')]: {
            marginTop: 0
        }
    }
}));

export default useStyles;
