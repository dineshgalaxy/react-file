/* eslint-disable react-hooks/exhaustive-deps */
import _ from 'lodash';
import React, { useEffect, useState, useRef } from 'react';
import { Segment, Table, Button, Input, Icon, Confirm } from 'semantic-ui-react';
import { Menu, MenuItem, Box } from '@material-ui/core';
import { MoreVert } from '@material-ui/icons';
import withLoader from '~/shared/components/hoc/withLoader';
import styles from '~/shared/styles/ManageProgram.module.scss';
import { noResults, useSortableData } from '~/shared/utils/admin/adminUtils';
import CustomPagination from '~/shared/utils/admin/CustomPagination';
import AddProgramForm from './AddProgramForm';
import { useToasts } from 'react-toast-notifications';
import propTypes from 'prop-types';
import { fetchList, deleteProgramService } from './Utils/ManageProgramsApiUtils';
import { DELETE_CONFIRMATION } from '~/shared/utils/admin/messages';

const ManagePrograms = ({ setLoading, isLoading }) => {
    const [searchInput, setSearchInput] = useState('');
    const [limit, setLimit] = useState(10);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [tableData, setTableData] = useState([]);
    const [allProgramsList, setAllProgramsList] = useState([]);
    const [showAddProgramModal, setShowAddProgramModal] = useState(false);
    const [filteredPrograms, setFilteredPrograms] = useState([]);
    const [programIdToUpdate, setProgramIdToUpdate] = useState(null);
    const [programIdToDelete, setProgramIdToDelete] = useState(null);
    const [showConfirmationBox, setShowConfirmationBox] = useState(false);
    const [anchorEl, setAnchorEl] = useState(null);
    const [selectedId, setSelectedId] = useState(0);
    const open = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
        setAnchorEl(null);
    };
    const { addToast } = useToasts();

    const { programsList, requestSort, sortConfig } = useSortableData(tableData);

    const fetchManageProgramData = async () => {
        setLoading(true);
        try {
            const response = await fetchList()
            const { data } = response.res_data;
            setAllProgramsList(data);
            setFilteredPrograms(data);
            setLoading(false);
        } catch (e) {
            setLoading(false);
        }
    };

    const deleteProgram = async () => {
        setLoading(true);
        try {
            const { res_data } = await deleteProgramService(programIdToDelete);
            addToast(res_data?.message, { appearance: 'success' });
            setCurrentPage(1);
            setProgramIdToDelete(null);
            setShowConfirmationBox(false);
            fetchManageProgramData();
        } catch {
            setLoading(false);
        }
    };

    const renderConfirmationBox = () => {
        return (
            <Confirm
                open={showConfirmationBox}
                cancelButton="No"
                confirmButton="Yes"
                content={DELETE_CONFIRMATION}
                onCancel={() => setShowConfirmationBox(false)}
                onConfirm={deleteProgram}
            />
        );
    };

    // it'll call API once and save all data(pagination, searching, sorting to be handled on client side)
    useEffect(() => {
        fetchManageProgramData();
    }, []);

    const searchData = useRef(
        _.throttle((val, programs) => {
            const query = val.toLowerCase();
            setCurrentPage(1);
            const filteredData = programs.filter((item) => {
                const { program, description, waitlist_title, is_active, created_at } = item;
                let createdAt = new Date(created_at);
                return (
                    program.toLowerCase().indexOf(query) > -1 ||
                    description.toLowerCase().indexOf(query) > -1 ||
                    waitlist_title.toLowerCase().indexOf(query) > -1 ||
                    (is_active ? 'Active' : 'Inactive').toLowerCase().indexOf(query) > -1 ||
                    createdAt.toDateString().toLowerCase().indexOf(query) > -1
                );
            });
            setFilteredPrograms(filteredData);
        }, 400)
    );

    const handlePagesAndTableData = () => {
        const lastProgramIndex = currentPage * limit;
        const firstProgramIndex = lastProgramIndex - limit;
        const slicedProgramsList = filteredPrograms.slice(firstProgramIndex, lastProgramIndex);
        setTableData(slicedProgramsList);
        setTotalPages(Math.ceil(filteredPrograms.length / limit));
    };

    useEffect(() => {
        if (!searchInput) {
            setFilteredPrograms(allProgramsList);
        } else {
            searchData.current(searchInput, allProgramsList);
        }
    }, [searchInput]);

    useEffect(() => {
        handlePagesAndTableData();
    }, [limit, currentPage, filteredPrograms]);

    const handlePagination = (page, recordLimit = 10) => {
        setCurrentPage(page);
        setLimit(recordLimit);
    };

    const getClassNamesFor = (name) => {
        if (!sortConfig) {
            return;
        }
        return sortConfig.key === name ? sortConfig.direction : undefined;
    };

    const handleAddProgramForm = () => {
        setShowAddProgramModal(!showAddProgramModal);
    };

    const handleUpdateProgram = (id) => {
        setProgramIdToUpdate(id);
    };

    const handleDeleteProgram = (id) => {
        setProgramIdToDelete(id);
        setShowConfirmationBox(true);
    };

    const renderTableBody = () => {
        return (
            <Table.Body>
                {programsList?.map((result, index) => {
                    const { program, waitlist_title, description, is_active, created_at, id } =
                        result;
                    let createdAt = new Date(created_at);
                    return (
                        <Table.Row key={index}>
                            <Table.Cell>{program}</Table.Cell>
                            <Table.Cell>{waitlist_title}</Table.Cell>
                            <Table.Cell>{description}</Table.Cell>
                            <Table.Cell>{is_active === true ? 'Active' : 'Inactive'}</Table.Cell>
                            <Table.Cell>
                                <Box display="flex" alignItems="center" justifyContent="space-between">
                                    <div>{createdAt.toDateString()}</div>
                                    <div onClick={() => { setSelectedId(id) }}>
                                        <div
                                            id="basic-button"
                                            aria-controls="basic-button"
                                            aria-haspopup="true"
                                            aria-expanded={open ? 'true' : undefined}
                                            onClick={handleClick}
                                            className={styles.iconcursor}
                                        >
                                            <MoreVert />
                                        </div>
                                    </div>
                                </Box>
                                {id === selectedId && (
                                    <Menu
                                        id="basic-button"
                                        anchorEl={anchorEl}
                                        open={open}
                                        onClose={handleClose}
                                        MenuListProps={{
                                            'aria-labelledby': 'basic-button',
                                        }}
                                    >
                                        <MenuItem onClick={handleClose}>
                                            <Box display="flex" alignItems="center" onClick={() => { handleUpdateProgram(id) }}>
                                                <Icon
                                                    className={styles.iconcursor}
                                                    name="edit"

                                                />
                                                <div>Edit</div>
                                            </Box>
                                        </MenuItem>
                                        <MenuItem onClick={handleClose}>
                                            <Box display="flex" alignItems="center" onClick={() => handleDeleteProgram(id)}>
                                                <Icon
                                                    className={styles.iconcursor}
                                                    name="trash alternate"

                                                />
                                                <div>Remove</div>
                                            </Box>
                                        </MenuItem>
                                    </Menu>
                                )}
                            </Table.Cell>
                        </Table.Row>
                    );
                })}
            </Table.Body>
        );
    };

    const renderTable = () => {
        return (
            <>
                <Table celled sortable>
                    <Table.Header>
                        <Table.Row>
                            <Table.HeaderCell
                                sorted={getClassNamesFor('program')}
                                onClick={() => requestSort('program')}>
                                Program
                            </Table.HeaderCell>
                            <Table.HeaderCell
                                sorted={getClassNamesFor('waitlist_title')}
                                onClick={() => requestSort('waitlist_title')}>
                                Waitlist Type
                            </Table.HeaderCell>
                            <Table.HeaderCell
                                sorted={getClassNamesFor('description')}
                                onClick={() => requestSort('description')}>
                                Description
                            </Table.HeaderCell>
                            <Table.HeaderCell
                                sorted={getClassNamesFor('is_active')}
                                onClick={() => requestSort('is_active')}>
                                Status
                            </Table.HeaderCell>
                            <Table.HeaderCell
                                sorted={getClassNamesFor('created_at')}
                                onClick={() => requestSort('created_at')}>
                                Created At
                            </Table.HeaderCell>
                        </Table.Row>
                    </Table.Header>
                    {renderTableBody()}
                </Table>
                <CustomPagination
                    handlePagination={handlePagination}
                    currentPage={currentPage}
                    limit={limit}
                    totalPages={totalPages}
                />
            </>
        );
    };

    return (
        <div className={styles.programs}>
            <Segment>
                <div className={styles.wrapper}>
                    <Input
                        value={searchInput}
                        icon="search"
                        onChange={(e) => setSearchInput(e.target.value)}
                    />
                    <Button onClick={handleAddProgramForm}>Add</Button>
                    <AddProgramForm
                        showAddProgramModal={showAddProgramModal}
                        handleAddProgramForm={handleAddProgramForm}
                        fetchManageProgramData={fetchManageProgramData}
                        programIdToUpdate={programIdToUpdate}
                        setProgramIdToUpdate={setProgramIdToUpdate}
                    />
                </div>
                {tableData?.length ? renderTable() : !isLoading ? noResults() : ''}
                {renderConfirmationBox()}
            </Segment>
        </div>
    );
};

ManagePrograms.propTypes = {
    setLoading: propTypes.func,
    isLoading: propTypes.bool
};

export default withLoader(ManagePrograms);
