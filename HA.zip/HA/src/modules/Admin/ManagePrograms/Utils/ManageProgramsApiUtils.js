import { APIS } from '~/shared/constants/adminApiConstants';
import httpRequest, { METHODS } from '~/shared/utils/axios';
import { getUserId } from '~/shared/utils/utils';

export const fetchList = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.PROGRAM_LIST,
        method: METHODS.GET,
    });
    if (!error) {
        return response;
    }
};

export const fetchSpecificProgram = async (programId) => {
    const [response = {}, error] = await httpRequest({
        url: `${APIS.PROGRAM_LIST}/${programId}`,
        method: METHODS.GET,
    });
    if (!error) {
        return response;
    }
};

export const fetchAllWaitList = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_WAIT_LIST,
        method: METHODS.GET,
    });
    if (!error) {
        return response;
    }
};

export const createProgramService = async (body) => {
    const user_id = getUserId()
    const [response = {}, error] = await httpRequest({
        url: APIS.CREATE_PROGRAM,
        method: METHODS.POST,
        headers: { user_id },
        body
    });
    if (!error) {
        return response;
    }
        return error
};

export const updateProgramService = async (body, programId) => {
    const [response = {}, error] = await httpRequest({
        url: APIS.PROGRAM_LIST,
        method: METHODS.PUT,
        headers: { program_id:  programId},
        body
    });
    if (!error) {
        return response;
    }
};

export const deleteProgramService = async (programId) => {
    const [response = {}, error] = await httpRequest({
        url: `${APIS.PROGRAM_LIST}/${programId}`,
        method: METHODS.DELETE,
    });
    if (!error) {
        return response;
    }
        return error
};

