/* eslint-disable react-hooks/exhaustive-deps */
import React, { useState, useEffect } from 'react';
import { Modal, Grid, Form, Input, Button, TextArea, Dropdown } from 'semantic-ui-react';
import withLoader from '~/shared/components/hoc/withLoader';
import { useToasts } from 'react-toast-notifications';
import propTypes from 'prop-types';
import { createProgramService, fetchAllWaitList, fetchSpecificProgram, updateProgramService } from './Utils/ManageProgramsApiUtils';

const AddProgramForm = ({
    showAddProgramModal,
    handleAddProgramForm,
    setLoading,
    fetchManageProgramData,
    programIdToUpdate,
    setProgramIdToUpdate
}) => {
    const [programName, setProgramName] = useState('');
    const [description, setDescription] = useState('');
    const [waitlistOptions, setWaitlistOptions] = useState([]);
    const [waitlistType, setWaitlistType] = useState(0);
    const [programId, setProgramId] = useState('');
    const [editForm, setEditForm] = useState(false);
    const { addToast } = useToasts();

    const areRequiredFilled = () => {
        const requiredFields = ['description', 'programName', 'waitlistType'];
        return requiredFields.find((i) => !eval(i)) === undefined;
    };

    const clearStates = () => {
        setDescription('');
        setProgramName('');
        setWaitlistType(0);
        setEditForm(false);
        setProgramIdToUpdate(null);
    };

    const handleAddProgramFormClose = () => {
        clearStates();
        handleAddProgramForm();
    };

    const fetchAllWaitListData = async () => {
        try {
            const response = await fetchAllWaitList();
            const { data } = response.res_data;
            let waitlistArray = data?.map((waitlist) => ({
                key: waitlist.id,
                text: waitlist.waitlist_type,
                value: waitlist.id
            }));
            setWaitlistOptions(waitlistArray);
        } catch (e) {
            setLoading(false);
        }
    };
    const fetchSpecificProgramData = async (programId) => {
        setLoading(true);
        try {
            const response = await fetchSpecificProgram(programId);
            const { data } = response.res_data;
            setDescription(data[0].description);
            setWaitlistType(data[0].waitlist_type);
            setProgramName(data[0].program);
            setProgramId(data[0].id);
            setLoading(false);
            handleAddProgramForm();
        } catch {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchAllWaitListData();
        if (programIdToUpdate !== null) {
            fetchSpecificProgramData(programIdToUpdate);
            setEditForm(true);
        }
    }, [programIdToUpdate]);

    const sendCreateProgramData = async (data) => {
        setLoading(true);
        try {
            const { res_data } = await createProgramService(data);
            addToast(res_data?.message, { appearance: 'success' });
            setLoading(false);
            handleAddProgramFormClose();
            fetchManageProgramData();
        } catch {
            handleAddProgramFormClose();
            setLoading(false);
        }
    };

    const sendUpdateProgramData = async (data) => {
        setLoading(true);
        try {
            const { res_data } = await updateProgramService(data, programId);
            addToast(res_data?.message, { appearance: 'success' });
            handleAddProgramFormClose();
            fetchManageProgramData();
            setLoading(false);
        } catch {
            setLoading(false);
        }
    };

    const handleAddProgramData = () => {
        let programData = {
            program: programName,
            description,
            waitlist_type: waitlistType
        };
        editForm ? sendUpdateProgramData(programData) : sendCreateProgramData(programData);
    };

    const renderAddProgramForm = () => {
        return (
            <Form>
                <Grid columns="2">
                    <Grid.Column>
                        <Form.Field required>
                            <label>Program name</label>
                            <Input
                                name="programName"
                                placeholder="Enter program Name"
                                onChange={(e, { value }) => setProgramName(value)}
                                value={programName}
                            />
                        </Form.Field>
                    </Grid.Column>
                    <Grid.Column>
                        <Form.Field required>
                            <label>Waitlist type</label>
                            <Dropdown
                                name="waitlistType"
                                placeholder="Select Waitlist"
                                selection
                                options={waitlistOptions || []}
                                value={waitlistType}
                                onChange={(e, { value }) => setWaitlistType(value)}
                            />
                        </Form.Field>
                    </Grid.Column>
                    <Grid.Column>
                        <Form.Field required>
                            <label>Description</label>
                            <TextArea
                                name="description"
                                placeholder="Enter description"
                                onChange={(e, { value }) => setDescription(value)}
                                value={description}
                            />
                        </Form.Field>
                    </Grid.Column>
                </Grid>
                <Grid>
                    <Grid.Column>
                        <Button
                            onClick={handleAddProgramData}
                            positive
                            disabled={!areRequiredFilled()}>
                            Save
                        </Button>
                        <Button color="black" onClick={handleAddProgramFormClose}>
                            Close
                        </Button>
                    </Grid.Column>
                </Grid>
            </Form>
        );
    };

    return (
        <>
            <Modal
                closeIcon
                onClose={handleAddProgramFormClose}
                dimmer={true}
                open={showAddProgramModal}>
                <Modal.Header>{editForm ? 'Update Program' : 'Add Program'}</Modal.Header>
                <Modal.Content>
                    <Modal.Description>{renderAddProgramForm()}</Modal.Description>
                </Modal.Content>
            </Modal>
        </>
    );
};

AddProgramForm.propTypes = {
    setLoading: propTypes.func,
    showAddProgramModal: propTypes.bool,
    handleAddProgramForm: propTypes.func,
    fetchManageProgramData: propTypes.func,
    fetchSpecificProductId: propTypes.number,
    programIdToUpdate: propTypes.string,
    setProgramIdToUpdate: propTypes.func
};

export default withLoader(AddProgramForm);
