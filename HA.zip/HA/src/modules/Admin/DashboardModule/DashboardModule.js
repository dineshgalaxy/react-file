import React from 'react';
import AdminContent from '~/modules/Admin/DashboardModule/AdminContent';

/** 
 * TODO(DashboardModule): Render DashboardModule
**/

const DashboardModule = () => {
    return (
        <AdminContent />
    );
}

export default DashboardModule;