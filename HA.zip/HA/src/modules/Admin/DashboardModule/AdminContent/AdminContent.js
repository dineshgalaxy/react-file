import React from 'react';
import { Box, Grid, Card } from '@material-ui/core';
import useStyles from './CardStyle';

/**
 * Name : AdminContent
 * desc : Render AdminContent
 **/

const AdminContent = () => {
    const classes = useStyles();

    return (
        <>
            <Grid item md={10}>
                <Box display="flex" maxWidth="85%" style={{ margin: '30px auto' }}>
                    <Grid container spacing={2} columns={16}>
                        <Grid item md={5}>
                            <Card className={classes.erererer}>
                                <Box minHeight={200}>
                                    <h2>Satisfaction</h2>
                                </Box>
                            </Card>
                        </Grid>

                        <Grid item md={7}>
                            <Card className={classes.erererer}>
                                <Box minHeight={200}>
                                    <h2>Sales</h2>
                                </Box>
                            </Card>
                        </Grid>
                    </Grid>
                </Box>
            </Grid>
        </>
    );
};

export default AdminContent;
