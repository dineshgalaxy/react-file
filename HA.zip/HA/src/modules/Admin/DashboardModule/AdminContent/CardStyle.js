import { makeStyles } from "@material-ui/core";
const useStyles = makeStyles((theme) => ({
    erererer:{
        padding:theme.spacing(2),
        borderRadius:`${theme.spacing(2.625)}px`,
        boxShadow:theme.shadows[1]
    }

}))

export default useStyles