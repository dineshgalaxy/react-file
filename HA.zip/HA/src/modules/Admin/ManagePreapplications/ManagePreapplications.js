/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import withLoader from '~/shared/components/hoc/withLoader';
import {
    fetchApplicantStatusList,
    fetchList,
    updateStatusService
} from './Utils/ManagePreapplicationApiUtils';
import styles from '~/shared/styles/ManagePreapplication.module.scss';
import propTypes from 'prop-types';
import { Dropdown, Icon, Segment, Table } from 'semantic-ui-react';
import ViewPreapplication from './ViewPreapplication/ViewPreapplication';
import { useToasts } from 'react-toast-notifications';
import {
    confirmationBoxTitle,
    statusArray,
    renderConfirmationBox
} from './Utils/ManagePreapplicationUtils';
import CustomPagination from '~/shared/utils/admin/CustomPagination';
import { pendingStatusId } from './Utils/ManagePreapplicationConstants';

const ManagePreapplications = ({ setLoading }) => {
    const { addToast } = useToasts();
    const [preapplicationData, setPreapplicationData] = useState([]);
    const [showViewPreApplicationDetails, setShowViewPreApplicationDetails] = useState(false);
    const [showConfirmationBox, setShowConfirmationBox] = useState(false);
    const [applicationStatus, setApplicationStatus] = useState('');
    const [limit, setLimit] = useState(10);
    const [currentPage, setCurrentPage] = useState(1);
    //TODO: work in progress
    // eslint-disable-next-line no-unused-vars  
    const [totalPages, setTotalPages] = useState(1);
    const [userId, setUserId] = useState(null);
    const [applicantId, setApplicantId] = useState(null);
    const [dropdownList, setDropdownList] = useState([]);
    const [apiData, setApiData] = useState({});
    const [showRejectModal, setShowRejectModal] = useState(true);
    const [remark, setRemark] = useState('');
    const [userAccountId, setUserAccountId] = useState(null);

    const fetchPreapplicationsList = async () => {
        setLoading(true);
        try {
            const response = await fetchList();
            const { data } = response.res_data;
            setPreapplicationData(data);
            setLoading(false);
        } catch (e) {
            setLoading(false);
        }
    };

    const fetchStatusListData = async () => {
        try {
            const { res_data } = await fetchApplicantStatusList();
            const filteredStatusArray = statusArray(res_data.data);
            setDropdownList(filteredStatusArray);
        } catch {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (remark) {
            setApiData(Object.assign(apiData, { remark }));
        } 
    }, [remark]);

    useEffect(() => {
        fetchPreapplicationsList();
        fetchStatusListData();
    }, []);

    const handleViewPreapplicationModal = (userId) => {
        setUserId(userId);
        setShowViewPreApplicationDetails(!showViewPreApplicationDetails);
    };

    const handleViewPreapplicationModalClose = () => {
        setShowViewPreApplicationDetails(false);
        setUserId(null);
    };

    const handleOnChange = (value, id, userId) => {
        setApplicantId(id);
        dropdownList.forEach((data) => {
            if (data.value === value) {
                setApplicationStatus(data.text);
            }
        });
        setUserAccountId(userId);
        const updateStatus = {
            application_status: value,
            remark: ''
        };
        setShowRejectModal(true)
        setApiData(updateStatus);
        setShowConfirmationBox(true);
    };

    const updateStatus = async () => {
        setLoading(true);
        try {
            const response = await updateStatusService(apiData, applicantId, userAccountId);
            if(response?.res_data) {
                addToast(response?.res_data?.message, { appearance: 'success' });
            }
            setShowRejectModal(false)
            setShowConfirmationBox(false)
            setRemark('')
            fetchPreapplicationsList()
            setLoading(false);
        } catch (error) {
            setLoading(false);
        }
    };

    const handleRejectModalClose = () => {
        setShowRejectModal(!showRejectModal);
    };

    const renderTableBody = () => {
        return (
            <Table.Body>
                {preapplicationData?.map((result, index) => {
                    const { program, fname, lname, email, application_status, user_account_id, id } =
                        result;
                    return (
                        <Table.Row key={index}>
                            <Table.Cell>{program}</Table.Cell>
                            <Table.Cell>{`${fname || ''} ${lname || ''}`}</Table.Cell>
                            <Table.Cell>{email}</Table.Cell>
                            <Table.Cell>
                                <Dropdown
                                    placeholder="Select"
                                    fluid
                                    selection
                                    value={application_status}
                                    options={dropdownList}
                                    disabled={application_status !== pendingStatusId}
                                    onChange={(e, { value }) =>
                                        handleOnChange(value, id, user_account_id)
                                    }
                                />
                            </Table.Cell>
                            <Table.Cell textAlign="center">
                                <Icon
                                    name="eye"
                                    className={styles.iconcursor}
                                    onClick={() => handleViewPreapplicationModal(user_account_id)}
                                />
                            </Table.Cell>
                        </Table.Row>
                    );
                })}
            </Table.Body>
        );
    };

    const handlePagination = (page, recordLimit = 10) => {
        setCurrentPage(page);
        setLimit(recordLimit);
    };

    const renderTable = () => {
        return (
            <>
                <Table celled sortable>
                    <Table.Header>
                        <Table.Row>
                            <Table.HeaderCell>Program Name</Table.HeaderCell>
                            <Table.HeaderCell>Username</Table.HeaderCell>
                            <Table.HeaderCell>Email</Table.HeaderCell>
                            <Table.HeaderCell>Status</Table.HeaderCell>
                            <Table.HeaderCell textAlign="center">Actions</Table.HeaderCell>
                        </Table.Row>
                    </Table.Header>
                    {renderTableBody()}
                    {renderConfirmationBox(
                        showConfirmationBox,
                        setShowConfirmationBox,
                        confirmationBoxTitle(applicationStatus),
                        updateStatus,
                        applicationStatus,
                        showRejectModal,
                        handleRejectModalClose,
                        setRemark,
                        remark
                    )}
                </Table>
                <CustomPagination
                    handlePagination={handlePagination}
                    currentPage={currentPage}
                    limit={limit}
                    totalPages={totalPages}
                />
            </>
        );
    };
    return (
        <div className={styles.programs}>
            <Segment>
                <div>
                    {renderTable()}
                    {userId && (
                        <ViewPreapplication
                            showViewPreApplicationDetails={showViewPreApplicationDetails}
                            handleViewPreapplicationModalClose={handleViewPreapplicationModalClose}
                            userId={userId}
                        />
                    )}
                </div>
            </Segment>
        </div>
    );
};

ManagePreapplications.propTypes = {
    setLoading: propTypes.func,
    isLoading: propTypes.bool
};

export default withLoader(ManagePreapplications);
