/* eslint-disable react-hooks/exhaustive-deps */
import React, { useEffect, useState } from 'react';
import { Grid, Modal, Header, Segment } from 'semantic-ui-react';
import propTypes from 'prop-types';
import withLoader from '~/shared/components/hoc/withLoader';
import { fetchSpecificApplicant } from '../Utils/ManagePreapplicationApiUtils';
import { Box } from '@material-ui/core';
import { noResults } from '~/shared/utils/admin/adminUtils';

const ViewPreapplication = ({
    showViewPreApplicationDetails,
    handleViewPreapplicationModalClose,
    setLoading,
    userId
}) => {
    const [applicantDetail, setApplicantDetail] = useState([]);
    const [membersDetail, setMembersDetail] = useState([]);
    const [othersDetail, setOthersDetail] = useState([]);
    const [programsDetail, setProgramsDetail] = useState([]);

    const fetchSpecificApplicantData = async (userId) => {
        setLoading(true);
        try {
            const { res_data } = await fetchSpecificApplicant(userId);
            const { applicantDetail, membersDetail, othersDetail, programsDetail } = res_data.data;
            setApplicantDetail(applicantDetail);
            setMembersDetail(membersDetail);
            setOthersDetail(othersDetail);
            setProgramsDetail(programsDetail);
            setLoading(false);
        } catch (e) {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchSpecificApplicantData(userId);
    }, [userId]);

    const getStatus = (value) => {
        return value ? 'Yes' : 'No';
    };

    const renderPersonalDetails = () => (
        <>
            <Header as="h5" attached="top">
                Personal Details
            </Header>
            <Segment attached>
                <Box fontSize="md.fontSize" mb={1}>
                    {`${applicantDetail?.fname || ''} ${applicantDetail?.lname || ''}`}
                </Box>
                <Box fontSize="md.fontSize" mb={1}>
                    {`${applicantDetail?.address_1 || ''} ${applicantDetail?.address_2 || ''}`}
                </Box>
                <Box fontSize="md.fontSize" mb={1}>
                    {`${applicantDetail?.cellphone || ''}`}
                </Box>
                <Box fontSize="md.fontSize" mb={1}>
                    {`${applicantDetail?.email || ''}`}
                </Box>
            </Segment>
        </>
    );

    const renderProgramDetails = () => (
        <>
            <Header as="h5" attached="top">
                Selected Programs
            </Header>
            <Segment attached>
                {programsDetail?.map(({ id, program }) => {
                    return (
                        <Box key={id} fontSize="md.fontSize" mb={1}>
                            {program}
                        </Box>
                    );
                })}
            </Segment>
        </>
    );

    const renderHouseholdDetails = () => (
        <>
            <Header as="h5" attached="top">
                Household
            </Header>
            <Segment attached>
                {membersDetail?.length
                    ? membersDetail.map((item) => {
                          return (
                              <Box mb={5} key={item?.member_id}>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      {`${item?.fname} ${item?.lname}`}
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      <Box component="span" mr={0.5}>
                                          Maiden:
                                      </Box>
                                      <Box component="span">{item?.maiden_name}</Box>
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      {item?.relation}
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      {item?.gender}
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      <Box component="span" mr={0.5}>
                                          SSN:
                                      </Box>
                                      <Box component="span">{item?.social_security_number}</Box>
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      {item?.citizenship}
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      <Box component="span" mr={0.5}>
                                          DOB:
                                      </Box>
                                      <Box component="span">{item?.dob}</Box>
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      {getStatus(item?.is_disabled)}
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      {getStatus(item?.is_fulltime_student)}
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      {getStatus(item?.lifetime_sex_offender_reg)}
                                  </Box>
                                  <Box fontSize="md.fontSize" mb={1}>
                                      {item?.race_ethinic?.values
                                          .map(({ type }) => type)
                                          .join(', ')}
                                  </Box>
                              </Box>
                          );
                      })
                    : noResults()}
            </Segment>
        </>
    );

    const renderHouseholdIncome = () => (
        <>
            <Header as="h5" attached="top">
                Household Income
            </Header>
            <Segment attached>
                <Box fontSize="md.fontSize" mb={1}>
                    {`$${othersDetail?.household_income || 0} per year`}
                </Box>
            </Segment>
        </>
    );

    const renderAccessibilityDetails = () => (
        <>
            <Header as="h5" attached="top">
                Accessibility
            </Header>
            <Segment attached>
                {othersDetail?.accessibility?.values?.length
                    ? othersDetail?.accessibility?.values.map(({ id, title }) => (
                          <Box fontSize="md.fontSize" mb={1} key={id}>
                              {title}
                          </Box>
                      ))
                    : noResults()}
            </Segment>
        </>
    );

    const renderShelterDetails = () => (
        <>
            <Header as="h5" attached="top">
                Shelter
            </Header>
            <Segment attached>
                {othersDetail?.shelter?.values?.length
                    ? othersDetail?.shelter?.values.map(({ title, id }) => (
                          <Box fontSize="md.fontSize" mb={1} key={id}>
                              {title}
                          </Box>
                      ))
                    : noResults()}
            </Segment>
        </>
    );

    const renderMilitaryDetails = () => (
        <>
            <Header as="h5" attached="top">
                Military
            </Header>
            <Segment attached>
                {othersDetail?.military?.values?.length
                    ? othersDetail?.military?.values.map(({ title, id }) => (
                          <Box fontSize="md.fontSize" mb={1} key={id}>
                              {title}
                          </Box>
                      ))
                    : noResults()}
            </Segment>
        </>
    );

    const renderOtherNeedsDetails = () => (
        <>
            <Header as="h5" attached="top">
                Other Needs
            </Header>
            <Segment attached>
                {othersDetail?.other_needs?.values?.length
                    ? othersDetail?.other_needs?.values.map(({ title, id }) => (
                          <Box fontSize="md.fontSize" mb={1} key={id}>
                              {title}
                          </Box>
                      ))
                    : noResults()}
            </Segment>
        </>
    );

    const renderApplicantDetails = () => {
        return (
            <>
                <Grid columns="2">
                    <Grid.Column>{renderPersonalDetails()}</Grid.Column>
                    <Grid.Column>{renderProgramDetails()}</Grid.Column>
                    <Grid.Column>{renderHouseholdDetails()}</Grid.Column>
                    <Grid.Column>{renderHouseholdIncome()}</Grid.Column>
                    <Grid.Column>{renderAccessibilityDetails()}</Grid.Column>
                    <Grid.Column>{renderShelterDetails()}</Grid.Column>
                    <Grid.Column>{renderMilitaryDetails()}</Grid.Column>
                    <Grid.Column>{renderOtherNeedsDetails()}</Grid.Column>
                </Grid>
            </>
        );
    };

    return (
        <>
            <Modal
                closeIcon
                onClose={handleViewPreapplicationModalClose}
                dimmer={true}
                open={showViewPreApplicationDetails}>
                <Modal.Header>View Preapplications</Modal.Header>
                <Modal.Content scrolling>
                    <Modal.Description>{renderApplicantDetails()}</Modal.Description>
                </Modal.Content>
            </Modal>
        </>
    );
};

ViewPreapplication.propTypes = {
    showViewPreApplicationDetails: propTypes.bool,
    handleViewPreapplicationModalClose: propTypes.func,
    userId: propTypes.string,
    setLoading: propTypes.func
};

export default withLoader(ViewPreapplication);
