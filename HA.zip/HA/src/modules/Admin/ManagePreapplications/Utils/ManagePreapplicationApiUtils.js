import { APIS } from '~/shared/constants/adminApiConstants';
import httpRequest, { METHODS } from '~/shared/utils/axios';

export const fetchList = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_PREAPPLICATION_LIST,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
    return error
};

export const fetchSpecificApplicant = async (userId) => {
    const [response = {}, error] = await httpRequest({
        url: `${APIS.FETCH_SPECIFIC_APPLICANT}/${userId}`,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
    return error
};

export const fetchApplicantStatusList = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_APPLICANT_STATUS_LIST,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
    return error
};

export const updateStatusService = async (body, application_id, user_id) => {
    const [response = {}, error] = await httpRequest({
        url: APIS.UPDATE_APPLICANT_STATUS,
        method: METHODS.PUT,
        headers: { application_id, user_id },
        body
    });
    if (!error) {
        return response;
    }
    return error
};