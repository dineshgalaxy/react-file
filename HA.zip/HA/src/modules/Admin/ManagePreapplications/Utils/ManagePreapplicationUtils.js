import React from 'react';
import { Button, Confirm, Form, Modal, TextArea } from 'semantic-ui-react';

export const confirmationBoxTitle = (status = '') => {
    const title = `Are you sure you want to ${status} this application ?`;
    return title;
};

export const statusArray = (statusListArray) => {
    const pendingReviewApplication = 'Pending Review Pre-Application';
    const rejectReviewApplication = 'Reject Pre-Application';
    const readyForApplication = 'Ready for Full Application';
    const filteredStatusArray = [];

    statusListArray.forEach((data) => {
        if (
            data.status === pendingReviewApplication ||
            data.status === rejectReviewApplication ||
            data.status === readyForApplication
        ) {
            filteredStatusArray.push({
                key: data.id,
                text: data.status,
                value: data.id
            });
        }
    });
    return filteredStatusArray;
};

export const renderConfirmationBox = (
    showConfirmationBox,
    setShowConfirmationBox,
    title,
    onConfirm,
    applicationStatus,
    showRejectModal,
    handleRejectModalClose,
    setRemark,
    remark
) => {
    return (
        <>
            {applicationStatus === 'Reject Pre-Application' ? (
                <Modal closeIcon onClose={handleRejectModalClose} open={showRejectModal}>
                    <Modal.Content>
                        <Modal.Description>{title}</Modal.Description>
                        <br />
                        <Form>
                            <TextArea
                                placeholder="Remarks"
                                onChange={(e, data) => setRemark(data.value)}
                            />
                        </Form>
                    </Modal.Content>
                    <Modal.Actions>
                        <Button onClick={handleRejectModalClose}>No</Button>
                        <Button disabled={!remark} color="primary" onClick={onConfirm}>
                            Yes
                        </Button>
                    </Modal.Actions>
                </Modal>
            ) : (
                <Confirm
                    open={showConfirmationBox}
                    cancelButton="No"
                    confirmButton="Yes"
                    content={title}
                    onCancel={() => setShowConfirmationBox(false)}
                    onConfirm={onConfirm}
                />
            )}
        </>
    );
};