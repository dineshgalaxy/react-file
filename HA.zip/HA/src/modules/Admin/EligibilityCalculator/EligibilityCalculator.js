import _ from 'lodash';
import propTypes from 'prop-types';
import React, { Component } from 'react';
import { Button, Form, Input, Label } from 'semantic-ui-react';
import {
    Table,
    TableBody,
    TableHead,
    TableCell,
    TableContainer,
    TableRow,
    Paper
} from '@material-ui/core';
import Loader from '~/shared/components/Loader';
import { DECIMAL_REGEX, MAX_AMOUNT } from '~/shared/constants/constants';
import styles from '~/shared/styles/Calculator.module.scss';
import {
    ALLOWED_UPTO_TWO_DECIMALS,
    AMOUNT_INCREASED_ERROR,
    INVALID_AMOUNT,
    INVALID_MAXIMUM_AMOUNT,
    INVALID_THRESHOLD_AMOUNT
} from '~/shared/utils/admin/messages';
import { renderFieldError } from '~/shared/utils/admin/adminUtils';
import { fetchList, updateEligibilityCalculator } from './Utils/EligibilityCalculatorUtils';
import withToast from '~/shared/components/hoc/withToast';

class EligibilityCalculator extends Component {
    constructor(props) {
        super(props);

        this.state = {
            loading: false,
            threshold1: 0,
            maximum1: 0,
            id1: 0,
            threshold2: 0,
            maximum2: 0,
            id2: 0,
            threshold3: 0,
            maximum3: 0,
            id3: 0,
            threshold4: 0,
            maximum4: 0,
            id4: 0,
            threshold5: 0,
            maximum5: 0,
            id5: 0,
            threshold6: 0,
            maximum6: 0,
            id6: 0,
            threshold7: 0,
            maximum7: 0,
            id7: 0,
            threshold8: 0,
            maximum8: 0,
            id8: 0,
            threshold9: 0,
            maximum9: 0,
            id9: 0,
            threshold10: 0,
            maximum10: 0,
            id10: 0,
            threshold11: 0,
            maximum11: 0,
            id11: 0,
            threshold12: 0,
            maximum12: 0,
            id12: 0,
            threshold13: 0,
            maximum13: 0,
            id13: 0,
            threshold14: 0,
            maximum14: 0,
            id14: 0,
            updatedFieldIndex: [],
            errors: {}
        };
    }

    isFormValid = () => !Object.keys(this.state.errors).length;

    /**
     * Description:To fetch eligibility calculator form data from API
     */
    fetchCalculatorData = async () => {
        this.setState({ loading: true });
        try {
            const { res_data } = await fetchList();
            const { data } = res_data;
            data.forEach((candidacyData) => {
                switch (candidacyData.no_of_members) {
                    case 1:
                        this.setState({
                            threshold1: candidacyData.threshold_amount,
                            maximum1: candidacyData.max_amount,
                            id1: candidacyData.family_members_id
                        });
                        break;

                    case 2:
                        this.setState({
                            threshold2: candidacyData.threshold_amount,
                            maximum2: candidacyData.max_amount,
                            id2: candidacyData.family_members_id
                        });
                        break;

                    case 3:
                        this.setState({
                            threshold3: candidacyData.threshold_amount,
                            maximum3: candidacyData.max_amount,
                            id3: candidacyData.family_members_id
                        });
                        break;

                    case 4:
                        this.setState({
                            threshold4: candidacyData.threshold_amount,
                            maximum4: candidacyData.max_amount,
                            id4: candidacyData.family_members_id
                        });
                        break;

                    case 5:
                        this.setState({
                            threshold5: candidacyData.threshold_amount,
                            maximum5: candidacyData.max_amount,
                            id5: candidacyData.family_members_id
                        });
                        break;

                    case 6:
                        this.setState({
                            threshold6: candidacyData.threshold_amount,
                            maximum6: candidacyData.max_amount,
                            id6: candidacyData.family_members_id
                        });
                        break;

                    case 7:
                        this.setState({
                            threshold7: candidacyData.threshold_amount,
                            maximum7: candidacyData.max_amount,
                            id7: candidacyData.family_members_id
                        });
                        break;

                    case 8:
                        this.setState({
                            threshold8: candidacyData.threshold_amount,
                            maximum8: candidacyData.max_amount,
                            id8: candidacyData.family_members_id
                        });
                        break;

                    case 9:
                        this.setState({
                            threshold9: candidacyData.threshold_amount,
                            maximum9: candidacyData.max_amount,
                            id9: candidacyData.family_members_id
                        });
                        break;

                    case 10:
                        this.setState({
                            threshold10: candidacyData.threshold_amount,
                            maximum10: candidacyData.max_amount,
                            id10: candidacyData.family_members_id
                        });
                        break;

                    case 11:
                        this.setState({
                            threshold11: candidacyData.threshold_amount,
                            maximum11: candidacyData.max_amount,
                            id11: candidacyData.family_members_id
                        });
                        break;

                    case 12:
                        this.setState({
                            threshold12: candidacyData.threshold_amount,
                            maximum12: candidacyData.max_amount,
                            id12: candidacyData.family_members_id
                        });
                        break;

                    case 13:
                        this.setState({
                            threshold13: candidacyData.threshold_amount,
                            maximum13: candidacyData.max_amount,
                            id13: candidacyData.family_members_id
                        });
                        break;

                    case 14:
                        this.setState({
                            threshold14: candidacyData.threshold_amount,
                            maximum14: candidacyData.max_amount,
                            id14: candidacyData.family_members_id
                        });
                        break;

                    default:
                        break;
                }
            });
            this.setState({ loading: false });
        } catch (e) {
            this.setState({ loading: false });
            return false;
        }
    };

    componentDidMount() {
        this.fetchCalculatorData();
    }

    validateField = (name, value, i) => {
        const { errors } = this.state;
        let error = errors;
        if (error[name]) {
            error = _.omit(error, name);
        }

        if (name.includes('threshold')) {
            if (+value < 0 || !value) {
                error[name] = [INVALID_AMOUNT];
            } else if (+value > +MAX_AMOUNT) {
                error[name] = [AMOUNT_INCREASED_ERROR];
            } else if (!DECIMAL_REGEX.test(value)) {
                error[name] = [ALLOWED_UPTO_TWO_DECIMALS];
            } else if (+value > +this.state[`maximum${i}`]) {
                error[name] = [INVALID_THRESHOLD_AMOUNT];
            } else if (this.state[`maximum${i}`] > 0) {
                delete error[`maximum${i}`];
            }
        }

        if (name.includes('maximum')) {
            if (+value < 0 || !value) {
                error[name] = [INVALID_AMOUNT];
            } else if (+value > +MAX_AMOUNT) {
                error[name] = [AMOUNT_INCREASED_ERROR];
            } else if (!DECIMAL_REGEX.test(value)) {
                error[name] = [ALLOWED_UPTO_TWO_DECIMALS];
            } else if (+value < +this.state[`threshold${i}`]) {
                error[name] = [INVALID_MAXIMUM_AMOUNT];
            } else if (this.state[`threshold${i}`] > 0) {
                delete error[`threshold${i}`];
            }
        }

        this.setState({ errors: error });
    };

    handleChange = (name, value, index) => {
        const { updatedFieldIndex } = this.state;
        if (!updatedFieldIndex.includes(index)) {
            this.setState((state) => ({
                updatedFieldIndex: [index, ...state.updatedFieldIndex]
            }));
        }

        this.setState({
            [name]: value
        });

        this.validateField(name, value, index);
    };

    sendCalculatorFormData = async (data) => {
        const { addToast } = this.props;
        this.setState({ loading: true });
        try {
            const { res_data } = await updateEligibilityCalculator(data)
            this.fetchCalculatorData();
            addToast(res_data?.message, { appearance: 'success' });
            this.setState({ loading: false });
        } catch (e) {
            this.setState({ loading: false });
        }
    };

    handleCalculatorSubmit = () => {
        const { updatedFieldIndex } = this.state;
        let tempArr = updatedFieldIndex.map((index) => {
            let result = {
                family_members_id: this.state[`id${index}`],
                no_of_members: index
            };
            if (this.state[`threshold${index}`]) {
                Object.assign(result, { threshold_amount: this.state[`threshold${index}`] });
            }
            if (this.state[`maximum${index}`]) {
                Object.assign(result, { max_amount: this.state[`maximum${index}`] });
            }
            return result;
        });
        // eslint-disable-next-line no-console
        let updatedFormData = {
            updateInfo: tempArr
        };
        this.sendCalculatorFormData(updatedFormData);
    };

    renderFormFields = () => {
        const {
            threshold1,
            maximum1,
            threshold2,
            maximum2,
            threshold3,
            maximum3,
            threshold4,
            maximum4,
            threshold5,
            maximum5,
            threshold6,
            maximum6,
            threshold7,
            maximum7,
            threshold8,
            maximum8,
            threshold9,
            maximum9,
            threshold10,
            maximum10,
            threshold11,
            maximum11,
            threshold12,
            maximum12,
            threshold13,
            maximum13,
            threshold14,
            maximum14,
            errors
        } = this.state;
        return (
            <>
                <TableRow>
                    <TableCell align="center">
                        <b>1</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold1"
                                value={threshold1}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 1)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold1 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum1"
                                value={maximum1}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 1)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum1 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>2</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold2"
                                value={threshold2}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 2)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold2 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum2"
                                value={maximum2}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 2)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum2 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>3</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold3"
                                value={threshold3}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 3)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold3 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum3"
                                value={maximum3}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 3)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum3 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>4</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold4"
                                value={threshold4}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 4)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold4 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum4"
                                value={maximum4}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 4)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum4 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>5</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold5"
                                value={threshold5}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 5)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold5 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum5"
                                value={maximum5}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 5)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum5 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>6</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold6"
                                value={threshold6}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 6)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold6 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum6"
                                value={maximum6}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 6)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum6 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>7</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold7"
                                value={threshold7}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 7)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold7 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum7"
                                value={maximum7}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 7)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum7 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>8</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold8"
                                value={threshold8}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 8)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold8 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum8"
                                value={maximum8}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 8)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum8 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>9</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold9"
                                value={threshold9}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 9)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold9 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum9"
                                value={maximum9}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 9)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum9 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>10</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold10"
                                value={threshold10}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 10)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold10 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum10"
                                value={maximum10}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 10)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum10 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>11</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold11"
                                value={threshold11}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 11)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold11 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum11"
                                value={maximum11}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 11)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum11 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>12</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold12"
                                value={threshold12}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 12)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold12 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum12"
                                value={maximum12}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 12)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum12 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>13</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold13"
                                value={threshold13}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 13)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold13 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum13"
                                value={maximum13}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 13)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum13 || [])])}
                    </TableCell>
                </TableRow>
                <TableRow>
                    <TableCell align="center">
                        <b>14</b>
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="threshold14"
                                value={threshold14}
                                placeholder="Enter threshold amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 14)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.threshold14 || [])])}
                    </TableCell>

                    <TableCell>
                        <Form.Field>
                            <Input
                                name="maximum14"
                                value={maximum14}
                                placeholder="Enter maximum amount"
                                labelPosition="left"
                                onChange={(e, { name, value }) =>
                                    this.handleChange(name, value, 14)
                                }>
                                <Label basic>$</Label>
                                <input type="number" />
                            </Input>
                        </Form.Field>
                        {renderFieldError([...(errors.maximum14 || [])])}
                    </TableCell>
                </TableRow>
            </>
        );
    };

    renderCalculatorForm = () => {
        return (
            <Form error={!this.isFormValid()}>
                <TableContainer component={Paper}>
                    <Table sx={{ minWidth: 650 }} aria-label="simple table">
                        <TableHead>
                            <TableRow>
                                <TableCell align="center">
                                    <strong>Number of Person</strong>
                                </TableCell>
                                <TableCell align="center">
                                    <strong>Threshold Amount</strong>
                                </TableCell>
                                <TableCell align="center">
                                    <strong>Maximum Amount</strong>
                                </TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody>{this.renderFormFields()}</TableBody>
                    </Table>
                </TableContainer>
                <div className={styles.btnbox}>
                    <Button
                        content="Submit"
                        disabled={!this.isFormValid()}
                        onClick={this.handleCalculatorSubmit}
                        primary
                    />
                </div>
            </Form>
        );
    };

    render() {
        const { loading } = this.state;
        return (
            <div className={styles.calculator}>
                <Loader loading={loading} />
                <div className={styles.calcbody}>
                    <div className={styles.calcheader}>
                        <h3>Eligibility Calculator</h3>
                    </div>
                    <div style={{ padding: '1em' }}>
                        {this.renderCalculatorForm()}
                    </div>
                </div>
            </div>
        );
    }
}

EligibilityCalculator.propTypes = {
    userData: propTypes.object,
    addToast: propTypes.func
};

export default withToast((EligibilityCalculator));
