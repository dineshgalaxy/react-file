import { APIS } from '~/shared/constants/adminApiConstants';
import httpRequest, { METHODS } from '~/shared/utils/axios';
import { getUserId } from '~/shared/utils/utils';

export const fetchList = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.ELIGIBILITY_CALCULATOR,
        method: METHODS.GET,
    });
    if (!error) {
        return response;
    }
        return error
};

export const updateEligibilityCalculator = async (body) => {
    const user_id = getUserId()
    const [response = {}, error] = await httpRequest({
        url: APIS.ELIGIBILITY_CALCULATOR,
        method: METHODS.PUT,
        headers: { user_id },
        body
    });
    if (!error) {
        return response;
    } 
        return error
};

