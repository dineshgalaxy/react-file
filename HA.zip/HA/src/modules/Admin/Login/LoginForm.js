import _ from 'lodash';
import Router from 'next/router';
import propTypes from 'prop-types';
import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useToasts } from 'react-toast-notifications';
import { Button, Form, Grid, Header, Segment } from 'semantic-ui-react';
import styles from 'shared/styles/Login.module.scss';
import Loader from '~/shared/components/Loader';
import { ROUTES } from '~/shared/constants/routesConstants';
import { setLocalStorage } from '~/shared/utils/storeManager';
import { loginFail, loginInit, loginSuccess } from './Utils/LoginAction';
import { login } from './Utils/LoginApiUtils';

const LoginForm = () => {
    const {
        userData
    } = useSelector(({loginDetails}) => loginDetails)
    const dispatch = useDispatch()
    const { loading } = userData;
    const { addToast } = useToasts();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState({});

    const validateField = (name) => {
        let error = errors;
        if (error[name]) {
            error = _.omit(error, name);
        }
        setErrors(error);
    };

    const handleLoginFormOnChange = (e, { name, value }) => {
        if (name === 'email') {
            setEmail(value);
        }
        if (name === 'password') {
            setPassword(value);
        }
        validateField(name, value);
    };

    const userLogin = async (data) => {
        try {
            dispatch(loginInit());
            const { res_data } = await login(data);
            if (res_data.data && !Object.keys(res_data.data).length) {
                dispatch(loginFail());
                addToast(res_data.message, { appearance: 'error' });
            } else {
                addToast(res_data.message, { appearance: 'success' });
                dispatch(loginSuccess(res_data.data.userDetails));
                Router.push(ROUTES.SUPERVISOR_DASHBOARD.ROUTE)
                setLocalStorage('user_details',res_data.data.userDetails)
            }
        } catch (e) {
            dispatch(loginFail());
            addToast('Error in Login', { appearance: 'error' });
        }
    };

    const handleLoginForm = () => {
        let loginDetails = {
            email,
            password
        };
        userLogin(loginDetails)
    };

    const renderLoginForm = () => (
        <Grid textAlign="center" style={{ height: '100vh' }} verticalAlign="middle">
            <Grid.Column style={{ maxWidth: 450 }}>
                <Header as="h2" textAlign="center">
                    Log-in to your account
                </Header>
                <Form size="large">
                    <Segment stacked>
                        <Form.Input
                            name="email"
                            fluid
                            value={email}
                            onChange={handleLoginFormOnChange}
                            icon="user"
                            iconPosition="left"
                            placeholder="E-mail address"
                        />
                        <Form.Input
                            name="password"
                            fluid
                            icon="lock"
                            value={password}
                            onChange={handleLoginFormOnChange}
                            iconPosition="left"
                            placeholder="Password"
                            type="password"
                        />

                        <Button fluid size="large" loading={loading} onClick={handleLoginForm}>
                            Login
                        </Button>
                    </Segment>
                </Form>
            </Grid.Column>
        </Grid>
    );

    return (
        <div className={styles.login}>
            <Loader loading={loading} />
            {renderLoginForm()}
        </div>
    );
};

LoginForm.propTypes = {
    userData: propTypes.object
};


export default LoginForm;
