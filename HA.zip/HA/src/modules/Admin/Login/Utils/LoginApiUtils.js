import { APIS } from '~/shared/constants/adminApiConstants';
import httpRequest, { METHODS } from '~/shared/utils/axios';
import { getUserId } from '~/shared/utils/utils';

export const login = async (body) => {
    const [response = {}, error] = await httpRequest({
        url: APIS.LOGIN_URL,
        method: METHODS.POST,
        body
    });
    if (!error) {
        return response;
    }
};

export const logout = async () => {
    const user_id = getUserId()
    const [response = {}, error] = await httpRequest({
        url: APIS.LOGOUT_URL,
        method: METHODS.GET,
        headers: { user_id }
    });
    if (!error) {
        return response;
    }
};

