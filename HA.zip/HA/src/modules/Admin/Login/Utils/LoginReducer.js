import { initialState, loginConstants } from "./LoginConstants";

const {
    LOGIN_SUCCESS,
    LOGIN_FAIL,
    LOGIN_INIT
} = loginConstants

export const loginReducer = (state = initialState, { type, payload }) => {
  switch (type) {
    case LOGIN_INIT:
      return { ...state, userData: { ...state.userData, loading: true } };
    case LOGIN_SUCCESS:
      return { ...state, userData: { ...state.userData, loading: false, data: payload } };
    case LOGIN_FAIL:
      return { ...state,  userData: { ...state.userData, loading: false } };
    default:
      return state;
  }
};
