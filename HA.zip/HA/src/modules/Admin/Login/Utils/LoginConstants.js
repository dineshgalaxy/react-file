
export const loginConstants = {
    LOGIN_SUCCESS: 'LOGIN_SUCCESS',
    LOGIN_FAIL: 'LOGIN_FAIL',
    LOGIN_INIT: 'LOGIN_INIT'
}

export const initialState = {
    userData: {
        loading: false,
        data: []
    },
  };