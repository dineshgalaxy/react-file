import { loginConstants } from "./LoginConstants";

const {
    LOGIN_SUCCESS,
    LOGIN_FAIL,
    LOGIN_INIT
} = loginConstants

export const loginInit = () => ({
    type: LOGIN_INIT
});

export const loginSuccess = (data) => ({
    type: LOGIN_SUCCESS,
    payload: data
});

export const loginFail = () => ({
    type: LOGIN_FAIL
});

