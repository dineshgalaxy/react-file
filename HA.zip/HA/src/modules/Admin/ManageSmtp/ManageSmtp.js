import React, { useState } from 'react';
import { useEffect } from 'react';
import { Button, Form, FormField, Grid, Input } from 'semantic-ui-react';
import withLoader from '~/shared/components/hoc/withLoader';
import styles from '~/shared/styles/ManageSmtp.module.scss';
import PropTypes from 'prop-types';
import { useToasts } from 'react-toast-notifications';
import { fetchList, updateSmtpService } from './Utils/ManageSmtpUtils';

const ManageSmtp = ({ setLoading }) => {
    const [host, setHost] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [port, setPort] = useState('');
    const { addToast } = useToasts();



    const areRequiredFilled = () => {
        const requiredFields = ['host', 'username', 'password', 'port'];
        return requiredFields.find((i) => !eval(i)) === undefined;
    };

    const fetchManageSmtpData = async () => {
        setLoading(true);
        try {
            const { res_data } = await fetchList();
            const { data } = res_data;
            setHost(data.SMTP_HOST)
            setUsername(data.SMTP_USER)
            setPassword(data.SMTP_PASSWORD)
            setPort(data.SMTP_PORT)
            setLoading(false);
        } catch (e) {
            setLoading(false);
        }
    };

    const sendUpdateSmtpData = async (data) => {
        setLoading(true); 
        try {
            const { res_data } = await updateSmtpService(data);
            addToast(res_data?.message, { appearance: 'success' });
            fetchManageSmtpData();
            setLoading(false);
        } catch {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchManageSmtpData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleManageSmtpSubmit = () => {
        let smtpData = {
           SMTP_HOST: host,
           SMTP_USER: username,
           SMTP_PASSWORD: password,
           SMTP_PORT: port
        };
        sendUpdateSmtpData(smtpData)
    };

    const renderManageSmtpForm = () => {
        return (
            <Form>
                <Grid columns="2">
                    <Grid.Column>
                        <FormField>Host</FormField>
                    </Grid.Column>
                    <Grid.Column>
                        <FormField>
                            <Input
                                type="text"
                                name="host"
                                value={host}
                                onChange={(e, { value }) => setHost(value)}
                            />
                        </FormField>
                    </Grid.Column>
                    <Grid.Column>
                        <FormField>Username</FormField>
                    </Grid.Column>
                    <Grid.Column>
                        <FormField>
                            <Input
                                type="text"
                                name="username"
                                value={username}
                                onChange={(e, { value }) => setUsername(value)}
                            />
                        </FormField>
                    </Grid.Column>
                    <Grid.Column>
                        <FormField>Password</FormField>
                    </Grid.Column>
                    <Grid.Column>
                        <FormField>
                            <Input
                                name="password"
                                value={password}
                                onChange={(e, { value }) => setPassword(value)}
                            />
                        </FormField>
                    </Grid.Column>
                    <Grid.Column>
                        <FormField>Port</FormField>
                    </Grid.Column>
                    <Grid.Column>
                        <FormField>
                            <Input
                                type="text"
                                name="port"
                                value={port}
                                onChange={(e, { value }) => setPort(value)}
                            />
                        </FormField>
                    </Grid.Column>
                </Grid>
                <div className={styles.btnbox}>
                    <Button
                        content="Submit"
                        disabled={!areRequiredFilled()}
                        onClick={handleManageSmtpSubmit}
                        primary
                    />
                </div>
            </Form>
        );
    };

    return (
        <div className={styles.smtpsidebar}>
        <div className={styles.smtp}>
            <div className={styles.smtpbody}>
                <div className={styles.smtpheader}>
                    <h3>Manage SMTP</h3>
                </div>
                <div style={{ padding: '1em' }}>{renderManageSmtpForm()}</div>
            </div>
        </div>
        </div>
    );
};

ManageSmtp.propTypes = {
    setLoading: PropTypes.func
};

export default withLoader(ManageSmtp);
