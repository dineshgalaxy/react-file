import { yourDocumentsConstants, initialState } from './YourDocumentsConstants';

const {
    YOUR_DOCUMENTS_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    YOUR_DOCUMENTS_CHECK,
    RESET_FORM,
    YOUR_DOCUMENTS_STATUS
} = yourDocumentsConstants;

export const YourDocuments = (state = initialState, action) => {
    switch (action.type) {
        case CONTINUE_WELCOME: {
            return {
                ...state,
                welcomeContinue: action.payload.welcomeContinue
            };
        }
        case YOUR_DOCUMENTS_CHECK: {
            return {
                ...state,
                yourDocumentsCheck: action.payload.yourDocumentsCheck
            };
        }
        case YOUR_DOCUMENTS_ACTIVE_INDEX: {
            return {
                ...state,
                activeStepIndex: action.payload
            };
        }
        case RESET_FORM: {
            return {
                ...initialState
            };
        }
        case YOUR_DOCUMENTS_STATUS: {
            return {
                ...state,
                activeStepIndex: 5,
                yourDocumentsStatus: action.payload
            };
        }
        default:
            return state;
    }
};
