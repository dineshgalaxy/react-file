import { noop } from '~/shared/utils/utils';
import { yourDocumentsStatusConstant, yourDocumentsStatusData } from './YourDocumentsConstants';

export const getProgressValue = (activeIndex) => {
    return 50 * activeIndex;
};
export const getYourDocumentsStatusData = (yourDocumentsStatus, onExitClickFun, onSuccessClick) => {
    const yourDocumentsStatusRes = {
        Success: 1,
        Failed: 2,
        Questioned: 3
    }[yourDocumentsStatus];

    let onPrimaryClick = noop;
    if (yourDocumentsStatusRes === yourDocumentsStatusConstant.SUCCESS) {
        onPrimaryClick = onSuccessClick;
    } else if (yourDocumentsStatusRes === yourDocumentsStatusConstant.FAILED) {
        onPrimaryClick = onExitClickFun;
    } else {
        onPrimaryClick = onExitClickFun;
    }

    const data = yourDocumentsStatusData[yourDocumentsStatusRes];
    return {
        ...data,
        onPrimaryClick: onPrimaryClick
    };
};
