import { yourDocumentsConstants } from './YourDocumentsConstants';
const {
    YOUR_DOCUMENTS_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    YOUR_DOCUMENTS_CHECK,
    RESET_FORM,
} = yourDocumentsConstants;

export const setActiveStepIndex = (payload) => {
    return {
        type: YOUR_DOCUMENTS_ACTIVE_INDEX,
        payload
    };
};

export const continueWelcome = (payload) => {
    return {
        type: CONTINUE_WELCOME,
        payload
    };
};
export const continueYourDocuments= (payload) => {
    return {
        type: YOUR_DOCUMENTS_CHECK,
        payload
    };
};
export const resetForm = (payload) => {
    return {
        type: RESET_FORM,
        payload
    };
};

