export const initialState = {
    activeStepIndex: 1,
    welcomeContinue: false,
    yourDocumentsCheck: false,
    reviewStatus: 0
};
export const yourDocumentsConstants = {
    YOUR_DOCUMENTS_ACTIVE_INDEX: 'YOUR_DOCUMENTS_ACTIVE_INDEX',
    SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
    CONTINUE_WELCOME: 'CONTINUE_WELCOME',
    YOUR_DOCUMENTS_CHECK: 'YOUR_DOCUMENTS_CHECK',
    SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
    RESET_FORM: 'RESET_FORM',
    YOUR_DOCUMENTS_STATUS: 'YOUR_DOCUMENTS_STATUS'
};

export const STEPS = {
    STEP1: 1,
    STEP2: 2,
};

export const yourDocumentsStatusConstant = {
    SUCCESS: 1,
    FAILED: 2,
    PENDING: 3
};

export const yourDocumentsStatusData = {
};
