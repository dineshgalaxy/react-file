export { default } from './YourDocuments';
