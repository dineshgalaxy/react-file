import { Box, LinearProgress } from '@material-ui/core';
import Router from 'next/router';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    continueYourDocuments,
    setActiveStepIndex
} from '~/modules/YourDocuments/Utils/YourDocumentsAction';
import { STEPS } from '~/modules/YourDocuments/Utils/YourDocumentsConstants';
import {
    getProgressValue
} from '~/modules/YourDocuments/Utils/YourDocumentsUtils';
import CommonCard from '~/shared/components/CommonCard';
import TopHeader from '~/shared/components/Header/TopHeader';
import withLoader from '~/shared/components/hoc/withLoader';
import InformationCard from '~/shared/components/InformationCard';
import WizardHeader from '~/shared/components/WizardHeader';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import { ROUTES } from '~/shared/constants/routesConstants';
import MissingDocumentsListing from '~/shared/components/HouseholdComponents/MissingDocumentsListing';

/**
 * Render YourDocuments
 */
const pageTitle = 'Your Documents';

const YourDocuments = () => {
    const { HOME, REVIEW_AND_SIGN } = ROUTES;
    const { STEP1, STEP2 } = STEPS;
    const dispatch = useDispatch();
    const [width, setWidth] = useState(window.innerWidth);
    const { activeStepIndex } = useSelector(
        (state) => state.yourDocuments
    );

    const handleExitClick = () => {
        Router.push(HOME.ROUTE);
    };

    const handleClickContinue = async (fn, { ...data }) => {
        dispatch(fn({ ...data }));
        if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        } else {
            Router.push(REVIEW_AND_SIGN.ROUTE);
        }
    };

    const handleClickBack = () => {
        if (activeStepIndex !== STEP1) {
            dispatch(setActiveStepIndex(activeStepIndex - 1));
        } else {
            Router.push(HOME.ROUTE);
        }
    };

    function handleWindowSizeChange() {
        setWidth(window.innerWidth);
    }
    useEffect(() => {
        window.addEventListener('resize', handleWindowSizeChange); //todo : add custom hook for this
        return () => {
            window.removeEventListener('resize', handleWindowSizeChange);
        };
    }, []);

    let isMobile = width <= 1024;

    return (

        <Box>
            {activeStepIndex <= Object.keys(STEPS).length ? (
                <>
                    {!isMobile && (
                        <TopHeader
                            title={pageTitle}
                            isWizard={true}
                            onExitClick={handleExitClick}
                            onClickBack={handleClickBack}
                        />
                    )}
                    <LinearProgress
                        variant="determinate"
                        value={getProgressValue(activeStepIndex)}
                    />
                </>
            ) : null}

            { activeStepIndex === STEP1 ? (
                <>
                    <CommonCard pageView="full" bgColor="primary" onClickBack={handleClickBack} >
                        <InformationCard
                            title="Your Required Documents"
                            subTitle="Based on the information you’ve provided, we still need up to 4 documents in order to process your application. You may enter them on the following screens, or save your application and return later to upload them if you need more time."
                            onClickContinue={() =>
                                handleClickContinue(continueYourDocuments, {
                                    welcomeContinue: true
                                })
                            }                            
                        />
                    </CommonCard>
                </>
            ) : null}
            {activeStepIndex === STEP2 ? (
                <>
                    <WizardHeader title="Documents" />
                    <CommonCard onClickBack={handleClickBack}>
                        <MissingDocumentsListing
                            title="We still need the following documents to complete your application. Gather the documents and start uploading them below."
                            onClickContinue={() =>
                                handleClickContinue(continueYourDocuments, {
                                    welcomeContinue: true
                                })
                            } 
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
        </Box>
    );
};

YourDocuments.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(YourDocuments);
