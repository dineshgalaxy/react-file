import { Box, Button, Grid } from '@material-ui/core';
import { ChevronRight } from 'react-feather';
import CommonCard from 'shared/components/CommonCard';
import StatusCard from 'shared/components/StatusCard';
import PageHeading from '~/shared/components/PageHeading';
import WizardHeader from '~/shared/components/WizardHeader';
import React from 'react';
import VoucherVideo from '~/shared/components/VoucherReceivedComponent/VoucherVideo';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import VouchereSignature from '~/shared/components/VoucherReceivedComponent/VouchereSignature';
import AcknowledgementtoSelectDwelling from '~/shared/components/VoucherReceivedComponent/AcknowledgementtoSelectDwelling/AcknowledgementtoSelectDwelling';
import VoucherDelivery from '~/shared/components/VoucherReceivedComponent/VoucherDelivery';
import VoucherDeliveryContent from '~/shared/components/VoucherReceivedComponent/VoucherDeliveryContent';


/**
 * Name: VoucherReceivedPageModule
 * Desc: Render VoucherReceivedPageModule
 */

const VoucherReceivedPageModule = () => {
    return (
        <Box bgcolor="secondary.extraLight" py={2} px={2}>
            <Grid container spacing={3}>
                <Grid item xs={12} md={12} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Approval Welcome" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            backBtnColor="backBtnWhite"
                            landingPageIcon={true}
                            pageView="full"
                            >
                            <StatusCard
                                showButton={true}
                                buttonText="Get Your Voucher"
                                statusImage="/Illo.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                        Your application is approved and your voucher is ready!
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box pt={1}>
                                            We’ll walk you through signing your voucher and finding a rental unit with a participating landlord.
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                             <Box display="flex" justifyContent="center" pt={6}>
                                <Button
                                    style={{
                                        color: 'white',
                                        fontSize: '15px'
                                    }}
                                    size="medium"
                                    className="linkBtn"
                                    endIcon={<ChevronRight color="Indigo" size={14} />}>
                                    Or Cancel Your Voucher
                                </Button>
                            </Box>
                        </CommonCard>
                    </Box>
                </Grid>
                <Grid item xs={12} md={12} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Voucher Video" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1} pb={3}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            First, take a few minutes to watch the video below.
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            It’s required that you view it to move forward, and will help you learn more about next steps. 
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard>
                                    <VoucherVideo/>
                                </CommonCard>
                                <ExitConfirmation isExitText={true} exitText="EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>
                <Grid item xs={12} md={12} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Sign Voucher Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Sign Your Voucher
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.light"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            The voucher is a document that authorizes you to look for an eligible rental unit. First, you’ll sign it, and then you’ll provide your saved or printed copy to the landlord of your future rental. 
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>
                <Grid item xs={12} md={12} width="100%">
                    <Box>
                        <PageHeading title="Voucher eSignature" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review and Sign Your Voucher Terms
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                The information below shows the terms of the voucher and rental unit details you’ve been approved for. Once you add your eSignature below, we’ll send you a PDF of your voucher.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <VouchereSignature/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="EXIT" />
                </Grid>

                <Grid item xs={12} md={12} width="100%">
                    <Box>
                        <PageHeading title="Acknowledgement to Select Dwelling" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={4}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review and Sign the Terms for Finding Your Unit
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                The terms below explain that you’ll be able to select any eligible rental unit, without any input or recommendation from HACEP.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <AcknowledgementtoSelectDwelling/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="EXIT" />
                </Grid>

                <Grid item xs={12} md={12} width="100%">
                    <Box>
                        <PageHeading title="Voucher Delivery" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={4}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Here’s Your Digital Voucher
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Scroll down for more information about how to use your voucher and find your rental unit. 
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard>
                        <VoucherDelivery/>
                    </CommonCard>
                    <Box color="primary.light" bgcolor="#D9EEFF" px={5} py={7.5} textAlign="center" my={6}>
                        <Box fontSize="h5.fontSize" fontFamily="fontFamily.semiBold" pb={2}>
                            What can you afford?
                        </Box>
                        <Box fontSize="h6.fontSize">
                            Based on your previous information, we estimate that you can afford <Box fontFamily="fontFamily.bold" component="span">up to about $450 per month. </Box>You can discuss rent with landlords and ask if they will negotiate based on your affordability estimate.
                        </Box>
                    </Box>
                    <VoucherDeliveryContent/>
                </Grid>

                <Grid item xs={12} md={12} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Loading Voucher" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            pageView="full"
                            showBackBtn={false}>
                            <StatusCard
                                iconName="more-horizontal"
                                iconStatus="success"
                                iconColor="indigo"
                                showButton={false}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                        Hold on while we generate your voucher document.
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                        
                    </Box>
                </Grid>

            </Grid>
        </Box>
    );
};

export default VoucherReceivedPageModule;