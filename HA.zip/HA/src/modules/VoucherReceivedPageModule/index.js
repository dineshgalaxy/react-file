export { default } from './VoucherReceivedPageModule';
