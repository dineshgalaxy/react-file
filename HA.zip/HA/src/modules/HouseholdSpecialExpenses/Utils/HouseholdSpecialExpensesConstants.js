export const initialState = {
    activeStepIndex: 1,
    welcomeContinue: false,
    householdSpecialExpensesCheck: false,
    reviewStatus: 0
};
export const householdSpecialExpensesConstants = {
    HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX: 'HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX',
    SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
    CONTINUE_WELCOME: 'CONTINUE_WELCOME',
    HOUSEHOLD_SPECIAL_EXPENSES_CHECK: 'HOUSEHOLD_SPECIAL_EXPENSES_CHECK',
    SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
    RESET_FORM: 'RESET_FORM',
    HOUSEHOLD_SPECIAL_EXPENSES_STATUS: 'HOUSEHOLD_SPECIAL_EXPENSES_STATUS'
};

export const STEPS = {
    STEP1: 1,
    STEP2: 2,
    STEP3: 3,
    STEP4: 4,
    STEP5: 5
};

export const householdSpecialExpensesStatusConstant = {
    SUCCESS: 1,
    FAILED: 2,
    PENDING: 3
};

export const householdSpecialExpensesStatusData = {
};
