import { householdSpecialExpensesConstants } from './HouseholdSpecialExpensesConstants';
const {
    HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    HOUSEHOLD_SPECIAL_EXPENSES_CHECK,
    RESET_FORM,
} = householdSpecialExpensesConstants;

export const setActiveStepIndex = (payload) => {
    return {
        type: HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX,
        payload
    };
};

export const continueWelcome = (payload) => {
    return {
        type: CONTINUE_WELCOME,
        payload
    };
};
export const continueHouseholdSpecialExpenses = (payload) => {
    return {
        type: HOUSEHOLD_SPECIAL_EXPENSES_CHECK,
        payload
    };
};
export const resetForm = (payload) => {
    return {
        type: RESET_FORM,
        payload
    };
};

