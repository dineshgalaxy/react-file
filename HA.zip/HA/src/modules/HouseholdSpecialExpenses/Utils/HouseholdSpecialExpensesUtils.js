import { noop } from '~/shared/utils/utils';
import { householdSpecialExpensesStatusConstant, householdSpecialExpensesStatusData } from './HouseholdSpecialExpensesConstants';

export const getProgressValue = (activeIndex) => {
    return 20 * activeIndex;
};
export const getHouseholdSpecialExpensesStatusData = (householdSpecialExpensesStatus, onExitClickFun, onSuccessClick) => {
    const householdSpecialExpensesStatusRes = {
        Success: 1,
        Failed: 2,
        Questioned: 3
    }[householdSpecialExpensesStatus];

    let onPrimaryClick = noop;
    if (householdSpecialExpensesStatusRes === householdSpecialExpensesStatusConstant.SUCCESS) {
        onPrimaryClick = onSuccessClick;
    } else if (householdSpecialExpensesStatusRes === householdSpecialExpensesStatusConstant.FAILED) {
        onPrimaryClick = onExitClickFun;
    } else {
        onPrimaryClick = onExitClickFun;
    }

    const data = householdSpecialExpensesStatusData[householdSpecialExpensesStatusRes];
    return {
        ...data,
        onPrimaryClick: onPrimaryClick
    };
};
