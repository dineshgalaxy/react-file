import { householdSpecialExpensesConstants, initialState } from './HouseholdSpecialExpensesConstants';

const {
    HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    HOUSEHOLD_SPECIAL_EXPENSES_CHECK,
    RESET_FORM,
    HOUSEHOLD_SPECIAL_EXPENSES_STATUS
} = householdSpecialExpensesConstants;

export const HouseholdSpecialExpenses = (state = initialState, action) => {
    switch (action.type) {
        case CONTINUE_WELCOME: {
            return {
                ...state,
                welcomeContinue: action.payload.welcomeContinue
            };
        }
        case HOUSEHOLD_SPECIAL_EXPENSES_CHECK: {
            return {
                ...state,
                householdSpecialExpensesCheck: action.payload.householdSpecialExpensesCheck
            };
        }
        case HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX: {
            return {
                ...state,
                activeStepIndex: action.payload
            };
        }
        case RESET_FORM: {
            return {
                ...initialState
            };
        }
        case HOUSEHOLD_SPECIAL_EXPENSES_STATUS: {
            return {
                ...state,
                activeStepIndex: 5,
                householdSpecialExpensesStatus: action.payload
            };
        }
        default:
            return state;
    }
};
