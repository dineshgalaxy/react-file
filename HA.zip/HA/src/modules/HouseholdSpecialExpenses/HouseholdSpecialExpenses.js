import { Box, LinearProgress, Button } from '@material-ui/core';
import Router from 'next/router';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    continueHouseholdSpecialExpenses,
    setActiveStepIndex
} from '~/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesAction';
import { STEPS } from '~/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesConstants';
import {
    getProgressValue
} from '~/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesUtils';
import CommonCard from '~/shared/components/CommonCard';
import TopHeader from '~/shared/components/Header/TopHeader';
import withLoader from '~/shared/components/hoc/withLoader';
import InformationCard from '~/shared/components/InformationCard';
import WizardHeader from '~/shared/components/WizardHeader';
import { ROUTES } from '~/shared/constants/routesConstants';
import ObjectCard from '~/shared/components/ObjectCard';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import HouseholdSpecialExpensesSelection from '~/shared/components/HouseholdComponents/HouseholdSpecialExpensesSelection';
import MedicalExpenses from '~/shared/components/HouseholdComponents/MedicalExpenses';

/**
 * Render HouseholdSpecialExpenses
 */
const pageTitle = 'Household Special Expenses';

const HouseholdSpecialExpenses = () => {
    const { HOME, RENT_AFFORDABILITY } = ROUTES;
    const { STEP1, STEP2, STEP3, STEP4, STEP5 } = STEPS;
    const dispatch = useDispatch();
    const [width, setWidth] = useState(window.innerWidth);
    const { activeStepIndex } = useSelector(
        (state) => state.householdSpecialExpenses
    );

    const handleExitClick = () => {
        Router.push(HOME.ROUTE);
    };

    const handleClickContinue = async (fn, { ...data }) => {
        dispatch(fn({ ...data }));
        if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        } else {
            Router.push(RENT_AFFORDABILITY.ROUTE);
        }
    };

    const handleClickBack = () => {
        if (activeStepIndex !== STEP1) {
            dispatch(setActiveStepIndex(activeStepIndex - 1));
        } else {
            Router.push(HOME.ROUTE);
        }
    };

    function handleWindowSizeChange() {
        setWidth(window.innerWidth);
    }
    useEffect(() => {
        window.addEventListener('resize', handleWindowSizeChange); //todo : add custom hook for this
        return () => {
            window.removeEventListener('resize', handleWindowSizeChange);
        };
    }, []);

    let isMobile = width <= 1024;

    return (

        <Box>
            {activeStepIndex <= Object.keys(STEPS).length ? (
                <>
                    {!isMobile && (
                        <TopHeader
                            title={pageTitle}
                            isWizard={true}
                            onExitClick={handleExitClick}
                            onClickBack={handleClickBack}
                        />
                    )}
                    <LinearProgress
                        variant="determinate"
                        value={getProgressValue(activeStepIndex)}
                    />
                </>
            ) : null}

            { activeStepIndex === STEP1 ? (
                <>
                    <CommonCard pageView="full" bgColor="primary" onClickBack={handleClickBack}>
                        <InformationCard
                            title="Your Household’s Special Expenses"
                            subTitle="Finally, we’ll ask you about expsenses for medical care, disability, or child care that don’t include your regular living expenses."
                            onClickContinue={() =>
                                handleClickContinue(continueHouseholdSpecialExpenses, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                </>
            ) : null}
            {activeStepIndex === STEP2 ? (
                <>
                    <WizardHeader title="Expenses" />
                    <CommonCard onClickBack={handleClickBack}>
                        <HouseholdSpecialExpensesSelection
                            title="Select all special expenses that are true for anyone in the household, including yourself.*"
                            onClickContinue={() =>
                                handleClickContinue(continueHouseholdSpecialExpenses, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
            {activeStepIndex === STEP3 ? (
                <>
                    <WizardHeader>
                        <Box textAlign="center">
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Add All Medical Expenses
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Add all medical expenses for all members of the household, including yourself, until all are shown below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="transparent" backBtnColor="backBtnWhite" onClickBack={handleClickBack}>
                        <Box>
                            {[
                                {documentName:'Add Medical Expense'}
                            ].map((item) => (
                                <Box
                                    borderColor="primary.main"
                                    border="1px dashed"
                                    borderRadius="21px"
                                    key={item.documentName}>
                                    <ObjectCard iconName="plus" showOptionMenu={false}
                                        onClick={() =>
                                            handleClickContinue(continueHouseholdSpecialExpenses, {
                                                welcomeContinue: true
                                            })
                                        }
                                    >
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium"
                                            lineHeight="1.4">
                                            {item.documentName}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                        </Box>
                    </CommonCard>
                    <Box mt={-5}>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                    </Box>
                </>
            ) : null}
            {activeStepIndex === STEP4 ? (
                <>
                    <WizardHeader title="Expenses" />
                    <CommonCard onClickBack={handleClickBack}>
                        <MedicalExpenses
                            title="Enter all the information available for this medical expense."
                            onClickContinue={() =>
                                    handleClickContinue(continueHouseholdSpecialExpenses, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
            {activeStepIndex === STEP5 ? (
                <>
                    <WizardHeader>
                        <Box textAlign="center">
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Continue Adding Any Medical Expenses
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Add all medical expenses for all members of the household, including yourself, until all are shown below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="transparent" backBtnColor="backBtnWhite"  onClickBack={handleClickBack}>
                        <Box>
                            <Box mb={3}>
                                <ObjectCard iconName="dollar-sign">
                                    <Box
                                        color="primary.main"
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium">
                                        [Type of Expense]
                                    </Box>
                                    <Box color="primary.light" fontSize="lg.fontSize">
                                        $100/mo.
                                    </Box>
                                </ObjectCard>
                            </Box>
                            {[{ documentName: 'Add Medical Expense' }].map((item) => (
                                <Box
                                    key={item.documentName}
                                    mb={3}
                                    borderColor="primary.main"
                                    border="1px dashed"
                                    borderRadius="21px">
                                    <ObjectCard cardType="actionCard" iconName="box">
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium"
                                            lineHeight="24px">
                                            {item.documentName}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                        </Box>
                    </CommonCard>
                    <Box display="flex" justifyContent="center">
                        <Button 
                            size="large"
                            color="primary"
                            variant="contained"
                            onClick={() =>
                                    handleClickContinue(continueHouseholdSpecialExpenses, {
                                    welcomeContinue: true
                                })
                            }
                        >
                            Finished Adding
                        </Button>
                    </Box>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
        </Box>
    );
};

HouseholdSpecialExpenses.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(HouseholdSpecialExpenses);
