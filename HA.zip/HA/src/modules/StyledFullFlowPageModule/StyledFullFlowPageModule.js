import { Box, Button, Checkbox, FormControl, FormControlLabel, Grid, Card, Dialog } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
// import MobileMenu from '~/shared/components/Header/MobileMenu';
import React, { useState } from 'react';
import { ChevronRight, Info } from 'react-feather';
import CommonCard from 'shared/components/CommonCard';
import HouseholdDocumentExpectations from 'shared/components/HouseholdComponents/HouseholdDocumentExpectations';
import ReviewHouseholdDetails from 'shared/components/HouseholdComponents/ReviewHouseholdDetails';
import StatusCard from 'shared/components/StatusCard';
import ApplicationMenuDropdown from '~/shared/components/ApplicationMenuDropdown/ApplicationMenuDropdown';
import ApplicationReview from '~/shared/components/ApplicationReview';
import ApplicationSubmitted from '~/shared/components/ApplicationSubmitted';
import ApplicationTerms from '~/shared/components/ApplicationTerms';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import AdditionalFilePopup from '~/shared/components/HouseholdComponents/AdditionalFilePopup';
import AssetDetails from '~/shared/components/HouseholdComponents/AssetDetails';
import AssetDisposal from '~/shared/components/HouseholdComponents/AssetDisposal';
import BirthCertificatePopup from '~/shared/components/HouseholdComponents/BirthCertificatePopup';
import EmergencyContactDetails from '~/shared/components/HouseholdComponents/EmergencyContactDetails';
import EmergencyContactSelect from '~/shared/components/HouseholdComponents/EmergencyContactSelect/EmergencyContactSelect';
import EmploymentDetails from '~/shared/components/HouseholdComponents/EmploymentDetails';
import HouseholdAssetSelection from '~/shared/components/HouseholdComponents/HouseholdAssetSelection';
import HouseholdIncomeSelection from '~/shared/components/HouseholdComponents/HouseholdIncomeSelection';
import HouseholdSpecialExpensesSelection from '~/shared/components/HouseholdComponents/HouseholdSpecialExpensesSelection';
import HouseholdSubject from '~/shared/components/HouseholdComponents/HouseholdSubject/HouseholdSubject';
import MedicalExpenses from '~/shared/components/HouseholdComponents/MedicalExpenses';
import MissingDocumentsListing from '~/shared/components/HouseholdComponents/MissingDocumentsListing';
import RentAffordabilityCalculator from '~/shared/components/HouseholdComponents/RentAffordabilityCalculator/RentAffordabilityCalculator';
import ReviewAppliationSubmissionTerms from '~/shared/components/HouseholdComponents/ReviewAppliationSubmissionTerms';
import RevieweSignatureTerms from '~/shared/components/HouseholdComponents/RevieweSignatureTerms';
import ReviewHouseholdAssetDetails from '~/shared/components/HouseholdComponents/ReviewHouseholdAssetDetails';
import ReviewHouseholdExpenseDetails from '~/shared/components/HouseholdComponents/ReviewHouseholdExpenseDetails';
import ReviewHouseholdIncomeDetails from '~/shared/components/HouseholdComponents/ReviewHouseholdIncomeDetails';
import ReviewHouseholdMemberDetails from '~/shared/components/HouseholdComponents/ReviewHouseholdMemberDetails/ReviewHouseholdMemberDetails';
import ReviewPolicies from '~/shared/components/HouseholdComponents/ReviewPolicies/ReviewPolicies';
import InformationCard from '~/shared/components/InformationCard';
import LoginForm from '~/shared/components/LoginForm';
import ObjectCard from '~/shared/components/ObjectCard';
import PageHeading from '~/shared/components/PageHeading';
import WizardHeader from '~/shared/components/WizardHeader';

/**
 * Name: StyledComponent
 * Desc: Render StyledComponent
 */

const useStyles = makeStyles((theme) => ({
    boxInfo: {
        position: 'relative',
        paddingLeft: theme.spacing(2),
        paddingBottom: theme.spacing(0.4),
        '&:before': {
            content: '""',
            width: '4px',
            height: '4px',
            background: theme.palette.primary.extraLight,
            position: 'absolute',
            left: '0',
            top: '10px',
            borderRadius: '50%'
        }
    }
}));

const StyledComponentModule = () => {
    const [openDialog, setOpenDialog] = useState(false);
    const handleClose = () => {
        setOpenDialog(false);
    };
    const [openDialog1, setOpenDialog1] = useState(false);
    const handleClose1 = () => {
        setOpenDialog1(false);
    };
    const classes = useStyles();

    return (
        <Box bgcolor="secondary.light" py={2} px={2}>
            <Grid container spacing={3}>
                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Appication Welcome" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            backBtnColor="backBtnWhite"
                            landingPageIcon={true}
                            pageView="full">
                            <StatusCard
                                showButton={true}
                                imageUrl="/Illo.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                        Let’s begin your application.
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box pt={1}>
                                            You have been selected to apply for the Krupp (1BR) program.
                                            Your application will be due no later than{' '}
                                            <Box
                                                color="error.main"
                                                component="span"
                                                fontFamily="fontFamily.extraBold">
                                                January 15, 2022
                                            </Box>
                                            . Continue below to see more and start your application.
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Appication Expectation" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <InformationCard
                                showImage={false}
                                textAlign="left"
                                title="For this application, you’ll need some information and documents."
                                content={
                                    <>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={3}>
                                            You’ll need to provide information about the identity,
                                            employment, and finances of all household members and
                                            minor children. To complete the application, you’ll also
                                            need to provide original scans of any corresponding
                                            documents, like:
                                        </Box>
                                        <Card>
                                            <Box
                                                px={3}
                                                py={3.5}
                                                color="primary.extraLight"
                                                fontSize="h6.fontSize">
                                                {[
                                                    'Social security cards',
                                                    'Drivers’ license',
                                                    'Bank statements',
                                                    'Other financial information'
                                                ].map((item, index) => (
                                                    <Box
                                                        key={`${item}_${index}`}
                                                        className={classes.boxInfo}>
                                                        {item}
                                                    </Box>
                                                ))}
                                                <Box
                                                    fontSize="md.fontSize"
                                                    color="primary.main"
                                                    pt={1.5}>
                                                    {'Takes about: 25 minutes'}
                                                </Box>
                                            </Box>
                                        </Card>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mt="30px"
                                            mb={3}>
                                            {
                                                'If you need to return later to finish your application, you can save your progress and exit at any point.'
                                            }
                                        </Box>
                                    </>
                                }
                                btnTitle="Start Application"
                            />
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="You and Your HouseHold Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        You and Your Household
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            In this section, we’ll ask some questions about you and your
                                            household members. Be sure to update any information that’s
                                            changed since your previous visits (e.g. births, divorces)
                                            that may change your eligibility for assistance
                                        </Box>
                                    </Box>
                                  
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Review Previous Household" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Review Your Household
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            Review the details we have on file for your household.
                                            If any members have changed, you may edit, remove, or
                                            add new ones below.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box mb={-3}>
                                        {[
                                            { userName: 'Erika Alexander', type: 'Applicant' },
                                            { userName: 'Carlos Alexander', type: 'Spouse' },
                                            { userName: 'Lara Alexander', type: 'Child' }
                                        ].map((item) => (
                                            <Box mb={3} key={item.type}>
                                                <ObjectCard>
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium">
                                                        {item.userName}
                                                    </Box>
                                                    <Box
                                                        color="primary.light"
                                                        fontSize="lg.fontSize">
                                                        {item.type}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                        <Box
                                            mb={3}
                                            borderColor="primary.main"
                                            border="1px dashed"
                                            borderRadius="21px">
                                            <ObjectCard cardType="actionCard" iconName="plus">
                                                <Box
                                                    color="primary.main"
                                                    fontSize="h6.fontSize"
                                                    fontFamily="fontFamily.medium">
                                                    Add Another Person
                                                </Box>
                                            </ObjectCard>
                                        </Box>
                                    </Box>
                                </CommonCard>
                                <Box display="flex" justifyContent="center">
                                    <Button size="large" color="primary" variant="contained">
                                        Continue
                                    </Button>
                                </Box>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review Household Details" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review Your Household’s Details
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Review the details listed below for each member of your household
                                and edit any details that are incorrect or out of date.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewHouseholdDetails />
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <Box display="flex" justifyContent="flex-end" pb={5} pt={8} px={3}>
                            <Button
                                style={{
                                    color: 'Indigo',
                                    fontSize: '15px'
                                }}
                                size="medium"
                                className="linkBtn"
                                endIcon={<ChevronRight color="Indigo" size={14} />}>
                                SAVE AND EXIT
                            </Button>
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Household Document Expectations" />
                    </Box>
                    <Box bgcolor="secondary.extraLight">
                        <WizardHeader title="Household" />
                        <CommonCard>
                            <HouseholdDocumentExpectations />
                        </CommonCard>
                        <Box display="flex" justifyContent="center" pt={6} px={3}>
                            <Button
                                style={{
                                    color: 'Indigo',
                                    fontSize: '15px'
                                }}
                                size="medium"
                                className="linkBtn"
                                endIcon={<ChevronRight color="Indigo" size={14} />}>
                                Or Skip for Now
                            </Button>
                        </Box>
                        <Box maxWidth="1008px" margin="0 auto">
                            <Box mt={6.5} px={3} display="inline-block" pb={6}>
                                <Box display="flex" mb={1}>
                                    <Box mr={1} mt={0.5} display="flex">
                                        <Info color="Indigo" size={21} />
                                    </Box>
                                    <Box
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        fontFamily="fontFamily.medium"
                                        lineHeight="21px">
                                        Why do we need these documents?
                                    </Box>
                                </Box>
                                <Box color="primary.extraLight" fontSize="md.fontSize" mb={2}>
                                    Optional helper text from HACEP
                                </Box>
                            </Box>
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Skip Documents" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            backBtnColor="backBtnWhite"
                            landingPage={true}
                            pageView="full">
                            <StatusCard
                                iconName="alert-triangle"
                                iconStatus="pending"
                                buttonType="secondary"
                                iconColor="indigo"
                                showButton={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                        You’ve chosen to skip uploading documents for now.
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                            <Box
                                            pb={2}
                                            fontFamily="fontFamily.regular"
                                            fontSize="h6.fontSize">
                                            You can continue entering information and come back later to
                                            upload your documents. Please note that in order to submit
                                            your application, you will need to locate the required
                                            documents.
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Add Required Member Documents" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Add Firstname’s Documents
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            At least one document from the list below is required
                                            for Firstname. Click on the document you’d like to
                                            upload below and follow the instructions.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box mb={-3}>
                                        <Box mb={3}>
                                            <ObjectCard iconName="file-text">
                                                <Box
                                                    color="primary.main"
                                                    fontSize="h6.fontSize"
                                                    fontFamily="fontFamily.medium">
                                                    Birth Certificate
                                                </Box>
                                                <Box color="primary.light" fontSize="lg.fontSize">
                                                    for Firstname Lastname
                                                </Box>
                                            </ObjectCard>
                                        </Box>
                                        {[
                                            { documentName: 'Add License or State I.D.' },
                                            { documentName: 'Add Social Security Card' }
                                        ].map((item) => (
                                            <Box
                                                key={item.documentName}
                                                mb={3}
                                                borderColor="primary.main"
                                                border="1px dashed"
                                                borderRadius="21px">
                                                <ObjectCard cardType="actionCard" iconName="plus">
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium">
                                                        {item.documentName}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                        <Box pt={2} pb={1.5}>
                                            <FormControl fullWidth className="noMargin">
                                                <FormControlLabel
                                                    control={
                                                        <Checkbox
                                                            inputProps={{
                                                                'aria-label': 'primary checkbox'
                                                            }}
                                                        />
                                                    }
                                                    label="Check this box if Firstname does not have any of these documents       available."
                                                />
                                            </FormControl>
                                        </Box>
                                    </Box>
                                </CommonCard>
                                <Box display="flex" justifyContent="center">
                                    <Button size="large" color="primary" variant="contained">
                                        Finished Uploading
                                    </Button>
                                </Box>
                                <Box display="flex" justifyContent="center">
                                    <ExitConfirmation
                                        isExitText={true}
                                        exitText="Or Skip for Now"
                                    />
                                </Box>
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box mb={3}>
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={() => {
                                setOpenDialog(true);
                            }}>
                            Birth Certificate Popup
                        </Button>
                        <Dialog
                            onClose={handleClose}
                            aria-labelledby="simple-dialog-title"
                            open={openDialog}>
                            <BirthCertificatePopup handleClose={handleClose} />
                        </Dialog>
                    </Box>
                    <Box>
                        <Button
                            variant="contained"
                            color="secondary"
                            onClick={() => {
                                setOpenDialog1(true);
                            }}>
                            Additional File Popup
                        </Button>
                        <Dialog
                            onClose={handleClose1}
                            aria-labelledby="simple-dialog-title"
                            open={openDialog1}>
                            <AdditionalFilePopup handleClose={handleClose1} />
                        </Dialog>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="No Documents" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            backBtnColor="backBtnWhite"
                            landingPage={true}
                            pageView="full">
                            <StatusCard
                                iconName="alert-triangle"
                                iconStatus="pending"
                                buttonText="Continue Anyway"
                                buttonType="secondary"
                                iconColor="indigo"
                                showButton={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                        This member of your household may not be eligible.
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                            <Box
                                            pb={1}
                                            fontFamily="fontFamily.regular"
                                            fontSize="h6.fontSize">
                                            Federal regulations require that all household members
                                            provide citizenship documentation for housing assistance
                                            programs. If you do not have documentation available for a
                                            member of your household, your application may not be
                                            approved. Would you like to continue with the application?
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                            <Box textAlign="center" pt={5}>
                                <Button
                                    style={{
                                        color: 'white',
                                        fontSize: '15px',
                                        fontWeight: 'Poppins-Regular'
                                    }}
                                    size="medium"
                                    className="linkBtn"
                                    endIcon={<ChevronRight color="Indigo" size={14} />}>
                                    Or Cancel Application
                                </Button>
                            </Box>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Emergency Contact Select" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader title="Household" />
                                <CommonCard>
                                    <EmergencyContactSelect title="Would you like to add an emergency contact person?" />
                                </CommonCard>
                                <Box maxWidth="1008px" margin="0 auto">
                                    <Box mt={6.5} px={3}>
                                        <Box display="flex" mb={1}>
                                            <Box mr={1} display="flex" mt={0.5}>
                                                <Info color="Indigo" size={21} />
                                            </Box>
                                            <Box
                                                color="primary.light"
                                                fontSize="h5.fontSize"
                                                fontFamily="fontFamily.medium"
                                                lineHeight="28px">
                                                About Emergency Contacts
                                            </Box>
                                        </Box>
                                        <Box color="primary.extraLight" fontSize="md.fontSize">
                                            As part of your application for housing, you have the
                                            right by law to include the name, address, telephone
                                            number, and other relevant information for a family
                                            member, a friend, or an organization that offers social,
                                            health, advocacy, or other support services. This
                                            contact information is for the purpose of identifying a
                                            person or organization that may be able to help in
                                            resolving issues that may arise during your tenancy or
                                            to assist in providing needed special care or services.
                                            You may update, remove, or change the information that
                                            you provide on this form at any time. You are not
                                            required to provide this contact information.
                                        </Box>
                                    </Box>
                                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                                </Box>
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Emergency Contact Details" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader title="Household" />
                                <CommonCard>
                                    <EmergencyContactDetails title="Enter your emergency contact person’s information below. They should be someone who does not live in the household." />
                                </CommonCard>
                                <Box maxWidth="1008px" margin="0 auto">
                                    <Box mt={6.5} px={3} pb={4}>
                                        <Box display="flex" mb={1}>
                                            <Box mr={1} mt={0.5} display="flex">
                                                <Info color="Indigo" size={21} />
                                            </Box>
                                            <Box
                                                color="primary.light"
                                                fontSize="h5.fontSize"
                                                fontFamily="fontFamily.medium"
                                                lineHeight="28px">
                                                About Emergency Contacts
                                            </Box>
                                        </Box>
                                        <Box color="primary.extraLight" fontSize="md.fontSize">
                                            As part of your application for housing, you have the
                                            right by law to include the name, address, telephone
                                            number, and other relevant information for a family
                                            member, a friend, or an organization that offers social,
                                            health, advocacy, or other support services. This
                                            contact information is for the purpose of identifying a
                                            person or organization that may be able to help in
                                            resolving issues that may arise during your tenancy or
                                            to assist in providing needed special care or services.
                                            You may update, remove, or change the information that
                                            you provide on this form at any time. You are not
                                            required to provide this contact information.
                                        </Box>
                                    </Box>
                                </Box>
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Income Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Your Household Income
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            Next, we’ll ask you about all the sources of income for the
                                            whole household.
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Income Selection" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader title="Income" />
                                <CommonCard>
                                    <HouseholdIncomeSelection title="Select all the sources of income that are true for yourself or for anyone in the household.*" />
                                </CommonCard>
                                <Box maxWidth="1008px" margin="0 auto">
                                    <Box mt={6.5} px={3} display="inline-block">
                                        <Box display="flex" mb={1}>
                                            <Box mr={1} mt={0.5} display="flex">
                                                <Info color="Indigo" size={21} />
                                            </Box>
                                            <Box
                                                color="primary.light"
                                                fontSize="h5.fontSize"
                                                fontFamily="fontFamily.medium"
                                                lineHeight="28px">
                                                Reporting Income
                                            </Box>
                                        </Box>
                                        <Box color="primary.extraLight" fontSize="md.fontSize">
                                            You must report all income regardless of source,
                                            including any income you expect to recieve within the
                                            next 90 days.
                                        </Box>
                                    </Box>
                                </Box>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Employment Income" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Add Household Employment Income
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            Add an employment source for every full or part-time job
                                            held by all members of the household until all jobs are
                                            shown below.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box>
                                        {[{ documentName: 'Add Job or Employment' }].map((item) => (
                                            <Box
                                                key={item.documentName}
                                                borderColor="primary.main"
                                                border="1px dashed"
                                                borderRadius="21px">
                                                <ObjectCard cardType="actionCard" iconName="plus">
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium"
                                                        lineHeight="17px">
                                                        {item.documentName}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                    </Box>
                                </CommonCard>
                                <Box display="flex" justifyContent="center">
                                    <Button size="large" color="primary" variant="contained">
                                        Continue
                                    </Button>
                                </Box>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Employment Details" />
                        </Box>
                        <>
                            <WizardHeader title="Household" />
                            <CommonCard>
                                <EmploymentDetails title="First, enter all the information available for this job or employment income." />
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Add Required Documents" />
                        </Box>
                        <>
                            <WizardHeader>
                                <Box textAlign="center" mt={1}>
                                    <Box
                                        fontSize="h3.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.bold"
                                        mb={2}
                                        lineHeight="32px">
                                        Add Paystubs for this Job or Employment
                                    </Box>
                                    <Box fontSize="h6.fontSize" color="common.white">
                                        Provide the three most recent paystubs for [Firstname]’s
                                        employment with [Employer Name]. If you don’t have them
                                        available right now, you can skip for now and upload them
                                        later.
                                    </Box>
                                </Box>
                            </WizardHeader>

                            <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                <Box mb={-3}>
                                    {[
                                        { documentName: 'Add Recent Paystub 1' },
                                        { documentName: 'Add Recent Paystub 2' },
                                        { documentName: 'Add Recent Paystub 3' }
                                    ].map((item) => (
                                        <Box
                                            key={item.documentName}
                                            borderColor="primary.main"
                                            border="1px dashed"
                                            borderRadius="21px"
                                            mb={3}>
                                            <ObjectCard cardType="actionCard" iconName="plus">
                                                <Box
                                                    color="primary.main"
                                                    fontSize="h6.fontSize"
                                                    fontFamily="fontFamily.medium"
                                                    lineHeight="17px">
                                                    {item.documentName}
                                                </Box>
                                            </ObjectCard>
                                        </Box>
                                    ))}
                                </Box>
                            </CommonCard>
                            <Box display="flex" justifyContent="center">
                                <Button size="large" color="primary" variant="contained">
                                    Finished Uploading
                                </Button>
                            </Box>
                            <Box display="flex" justifyContent="center" mt={-2}>
                                <ExitConfirmation isExitText={true} exitText="Or Skip for Now" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Employment Income Overview" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Continue Adding Employment Income
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            Add an employment source for every full or part-time job
                                            held by all members of the household until all jobs are
                                            shown below.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box>
                                        <Box mb={3}>
                                            <ObjectCard iconName="dollar-sign">
                                                <Box
                                                    color="primary.main"
                                                    fontSize="h6.fontSize"
                                                    fontFamily="fontFamily.medium">
                                                    Company Name
                                                </Box>
                                                <Box color="primary.light" fontSize="lg.fontSize">
                                                    $1,341/mo. for Firstname
                                                </Box>
                                            </ObjectCard>
                                        </Box>
                                        {[{ documentName: 'Add Job or Employment' }].map((item) => (
                                            <Box
                                                key={item.documentName}
                                                borderColor="primary.main"
                                                border="1px dashed"
                                                borderRadius="21px">
                                                <ObjectCard cardType="actionCard" iconName="plus">
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium">
                                                        {item.documentName}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                    </Box>
                                </CommonCard>
                                <Box display="flex" justifyContent="center">
                                    <Button size="large" color="primary" variant="contained">
                                        Finished Adding
                                    </Button>
                                </Box>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Household Assets Starter" />
                        </Box>
                        <CommonCard
                            bgColor="primary"
                            landingPageIcon={true}
                            pageView="full">
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Your Household Assets
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                            <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            Next, we’ll ask you about other assets like bank accounts,
                                            real estate, and other income-producing assets.
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Asset Selection" />
                        </Box>
                        <Box bgcolor="secondary.extraLight">
                            <WizardHeader title="Assets" />
                            <CommonCard>
                                <HouseholdAssetSelection />
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Asset Disposal" />
                        </Box>
                        <Box bgcolor="secondary.extraLight">
                            <WizardHeader title="Assets" />
                            <CommonCard>
                                <AssetDisposal />
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Asset Overview" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Add All Checking, Savings, or Money Market Accounts
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            Add details for every checking, savings, or money market
                                            account for all members of the household, including
                                            yourself, until all are shown below.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box>
                                        {[
                                            {
                                                userName:
                                                    'Add Checking, Savings, or Money Market Account'
                                            }
                                        ].map((item) => (
                                            <Box
                                                borderColor="primary.main"
                                                border="1px dashed"
                                                borderRadius="21px"
                                                key={item.type}>
                                                <ObjectCard cardType="actionCard" iconName="plus">
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium"
                                                        lineHeight="1.4">
                                                        {item.userName}
                                                    </Box>
                                                    <Box
                                                        color="primary.light"
                                                        fontSize="lg.fontSize">
                                                        {item.type}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                    </Box>
                                </CommonCard>
                                <Box mt={-5}>
                                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                                </Box>
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Asset Details" />
                        </Box>
                        <>
                            <WizardHeader title="Assets" />
                            <CommonCard>
                                <AssetDetails title="Enter all the information available for the account." />
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Asset Overview" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Continue Adding Checking, Savings, or Money Market
                                            Accounts
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            Add an employment source for every full or part-time job
                                            held by all members of the household until all jobs are
                                            shown below.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box>
                                        <Box mb={3}>
                                            <ObjectCard iconName="dollar-sign">
                                                <Box
                                                    color="primary.main"
                                                    fontSize="h6.fontSize"
                                                    fontFamily="fontFamily.medium">
                                                    [Type of Account]
                                                </Box>
                                                <Box color="primary.light" fontSize="lg.fontSize">
                                                    $500 at Chase Bank
                                                </Box>
                                            </ObjectCard>
                                        </Box>
                                        {[
                                            {
                                                documentName:
                                                    'Add Checking, Savings, or Money Market Account'
                                            }
                                        ].map((item) => (
                                            <Box
                                                key={item.documentName}
                                                borderColor="primary.main"
                                                border="1px dashed"
                                                borderRadius="21px">
                                                <ObjectCard cardType="actionCard" iconName="box">
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium"
                                                        lineHeight="24px">
                                                        {item.documentName}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                    </Box>
                                </CommonCard>
                                <Box display="flex" justifyContent="center">
                                    <Button size="large" color="primary" variant="contained">
                                        Finished Adding
                                    </Button>
                                </Box>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Household Special Expenses Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Your Household’s Special Expenses
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                            <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            Finally, we’ll ask you about expsenses for medical care,
                                            disability, or child care that don’t include your regular
                                            living expenses.
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Special Expenses Selection" />
                        </Box>
                        <>
                            <WizardHeader title="Expenses" />
                            <CommonCard>
                                <HouseholdSpecialExpensesSelection title="Select all special expenses that are true for anyone in the household, including yourself.*" />
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Add All Medical Expenses" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Add All Medical Expenses
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            Add all medical expenses for all members of the
                                            household, including yourself, until all are shown
                                            below.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box>
                                        {[{ documentName: 'Add Medical Expense' }].map((item) => (
                                            <Box
                                                borderColor="primary.main"
                                                border="1px dashed"
                                                borderRadius="21px"
                                                key={item.documentName}>
                                                <ObjectCard cardType="actionCard" iconName="plus">
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium"
                                                        lineHeight="1.4">
                                                        {item.documentName}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                    </Box>
                                </CommonCard>
                                <Box mt={-5}>
                                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                                </Box>
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Medical Expenses" />
                        </Box>
                        <>
                            <WizardHeader title="Expenses" />
                            <CommonCard>
                                <MedicalExpenses title="Enter all the information available for this medical expense." />
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Expense Overview" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Continue Adding Any Medical Expenses
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            Add all medical expenses for all members of the
                                            household, including yourself, until all are shown
                                            below.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box>
                                        <Box mb={3}>
                                            <ObjectCard iconName="dollar-sign">
                                                <Box
                                                    color="primary.main"
                                                    fontSize="h6.fontSize"
                                                    fontFamily="fontFamily.medium">
                                                    [Type of Expense]
                                                </Box>
                                                <Box color="primary.light" fontSize="lg.fontSize">
                                                    $100/mo.
                                                </Box>
                                            </ObjectCard>
                                        </Box>
                                        {[{ documentName: 'Add Medical Expense' }].map((item) => (
                                            <Box
                                                key={item.documentName}
                                                mb={3}
                                                borderColor="primary.main"
                                                border="1px dashed"
                                                borderRadius="21px">
                                                <ObjectCard cardType="actionCard" iconName="box">
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium"
                                                        lineHeight="24px">
                                                        {item.documentName}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                    </Box>
                                </CommonCard>
                                <Box display="flex" justifyContent="center">
                                    <Button size="large" color="primary" variant="contained">
                                        Finished Adding
                                    </Button>
                                </Box>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Rent Affordability Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Your Rent Affordability
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            In order to determine what rent you can afford, we’ll
                                            calculate an estimated based on some of your information.
                                        </Box>
                                    </Box>
                            
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Rent Affordability Calculator" />
                        </Box>
                        <>
                            <WizardHeader title="Affordability" />
                            <CommonCard>
                                <RentAffordabilityCalculator title="Complete the information below to calculate your rent affordability estimate." />
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Rent Affordability Estimate" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            backBtnColor="backBtnWhite"
                            pageView="full">
                            <StatusCard
                                iconName="dollar-sign"
                                iconStatus="success"
                                iconColor="indigo"
                                showButton={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                        Here’s your rent affordability estimate.
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            pt={1}
                                            pb={1}
                                            fontFamily="fontFamily.regular"
                                            lineHeight="26px">
                                            Based on your information, we estimate that you can afford{' '}
                                            <Box component="span" fontFamily="fontFamily.bold">
                                                {' '}
                                                up to $550 per month{' '}
                                            </Box>{' '}
                                            in rent. You can use that range as a guide when you explore
                                            available units and discuss what you can afford with
                                            potential landlords.
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Your Documents Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Your Required Documents
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            Based on the information you’ve provided, we still need up
                                            to 4 documents in order to process your application. You may
                                            enter them on the following screens, or save your
                                            application and return later to upload them if you need more
                                            time.
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Missing Documents Listing" />
                        </Box>

                        <WizardHeader title="Documents" />
                        <CommonCard>
                            <MissingDocumentsListing title="We still need the following documents to complete your application. Gather the documents and start uploading them below." />
                        </CommonCard>
                        <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Review and Sign Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Review and Sign Your Application
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                         <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            You’re almost done! The last thing you’ll need to do is
                                            review your application for accuracy, add your esignature,
                                            and submit your application to HACEP for processing.
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review Household Member Details" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review Your Household Member Details
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Use the edit links below to modify any of your application
                                information that is not correct. When you’re done, click “Confirm
                                and Continue” below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewHouseholdMemberDetails />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review Household Income Details" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review Your Household Income Details
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Use the edit links below to modify any of your application
                                information that is not correct. When you’re done, click “Confirm
                                and Continue” below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewHouseholdIncomeDetails />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review Household Asset Details" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review Your Household Asset Details
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Use the edit links below to modify any of your application
                                information that is not correct. When you’re done, click “Confirm
                                and Continue” below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewHouseholdAssetDetails />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review Household Expense Details" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review Your Household Special Expense Details
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Use the edit links below to modify any of your application
                                information that is not correct. When you’re done, click “Confirm
                                and Continue” below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewHouseholdExpenseDetails />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review Policies" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review Legal Notices and Policies
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                The documents below provide important information from the federal
                                government about your application.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewPolicies />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={12} width="100%">
                    <Box>
                        <PageHeading title="Review eSignature Terms" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Get Ready to Sign Your Application
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                The waiver below enables HACEP to use your esignature to sign your
                                application.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <RevieweSignatureTerms />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review Appliation Submission Terms" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Sign and Submit Your Application
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Read the terms and conditions below. Once you’ve read and understand
                                them, enter your eSignature and submit your application.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewAppliationSubmissionTerms />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Application Submitted" />
                        </Box>
                        <CommonCard bgScreen={'success'}>
                            <StatusCard
                                buttonText="Exit to Dashboard"
                                buttonType="primary"
                                iconName="check-circle"
                                iconStatus="complete"
                                iconColor="indigo"
                                showButton={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.main">
                                        We’ve received your application!
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box mt={4}>
                                            <ApplicationSubmitted apllicationTitle="What’s Next?">
                                                <Box color="primary.light" fontSize="h6.fontSize">
                                                    An administrator will review your submission, verify
                                                    the information and documents you’ve provided. If
                                                    any corrections are needed, you will be contacted
                                                    through the email and telephone number associated
                                                    with your account. If your application is approved,
                                                    HACEP will provide you with the documents and next
                                                    steps you’ll need to secure your housing.
                                                </Box>
                                            </ApplicationSubmitted>
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Subject" />
                        </Box>

                        <WizardHeader title="History" />
                        <CommonCard>
                            <HouseholdSubject title="Is any member of your household subject to a lifetime sex offender registration?" />
                        </CommonCard>
                        <ExitConfirmation isExitText={true} exitText="EXIT" />
                    </Box>
                </Grid>
                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Household Assisted" />
                        </Box>

                        <WizardHeader title="History" />
                        <CommonCard>
                            <HouseholdSubject title="Has any member of your household been convicted of manufacturing methamphetamine on the premises of federally assisted housing?" />
                        </CommonCard>
                        <ExitConfirmation isExitText={true} exitText="EXIT" />
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Pre-Application Review " />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" pl={3} pr={3} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}>
                                Review Your Pre-Application
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Review, edit, and confirm all of the information you’ve provided
                                below. If everything looks correct, click “confirm”.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ApplicationReview />
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <Box display="flex" justifyContent="flex-end" pb={5} pt={8} px={3}>
                            <Button
                                style={{
                                    color: 'Indigo',
                                    fontSize: '15px'
                                }}
                                size="medium"
                                className="linkBtn"
                                endIcon={<ChevronRight color="Indigo" size={14} />}>
                                OR CANCEL
                            </Button>
                        </Box>
                    </Box>
                </Grid>
                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Pre-Application Terms " />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}>
                                Review Your Terms and Conditions
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Before you submit your PreApplication, please confirm that you’ve
                                read and understand the folllowing terms and conditions.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ApplicationTerms />
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <Box display="flex" justifyContent="flex-end" pb={5} pt={8} px={3}>
                            <Button
                                style={{
                                    color: 'Indigo',
                                    fontSize: '15px'
                                }}
                                size="medium"
                                className="linkBtn"
                                endIcon={<ChevronRight color="Indigo" size={14} />}>
                                OR CANCEL
                            </Button>
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <WizardHeader>
                        <Box textAlign="center">
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}>
                                Review Your Household
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Okay, we’ve added all of your household members below. You may add
                                anyone we missed, or continue if everything looks correct.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <Box maxWidth="936px" margin="0 auto" position="relative">
                        <Box margin="-54px 24px 0 24px">
                            {[
                                { userName: 'Erika Alexander', type: 'Applicant' },
                                { userName: 'Carlos Alexander', type: 'Spouse' },
                                { userName: 'Lara Alexander', type: 'Child' }
                            ].map((item) => (
                                <Box mb={3} key={item.type}>
                                    <ObjectCard>
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            {item.userName}
                                        </Box>
                                        <Box color="primary.light" fontSize="lg.fontSize">
                                            {item.type}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                            <Box
                                mb={6}
                                borderColor="primary.main"
                                border="1px dashed"
                                borderRadius="21px">
                                <ObjectCard cardType="actionCard" iconName="plus">
                                    <Box
                                        color="primary.main"
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium">
                                        Add Another Person
                                    </Box>
                                </ObjectCard>
                            </Box>
                            <Box display="flex" justifyContent="center">
                                <Button size="large" color="primary" variant="contained">
                                    Continue
                                </Button>
                            </Box>
                        </Box>
                    </Box>
                    <ExitConfirmation isExitText={true} />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box bgcolor="#F5F5F9" pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Login Form" />
                        </Box>

                        <LoginForm />
                    </Box>
                </Grid>

                {/* TO Do  */}
                {/* <Grid item xs={12}>
                    <MobileMenu beforeLogin={false} />
                </Grid> */}

                <ApplicationMenuDropdown />
            </Grid>
        </Box>
    );
};
export default StyledComponentModule;
