export { default } from './LetsGetStarted';
