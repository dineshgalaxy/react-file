import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    root: {
        width: '100%',
        height: '100vh',
        background: theme.palette.primary.main,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundPosition: 'center',
        backgroundSize: 'cover',
        '& .MuiAvatar-root': {
            width: '100px',
            height: '100px'
        }
    },
    menuButton: {
        backgroundColor: theme.common.white,
        '&:hover': {
            backgroundColor: theme.common.white,
            opacity: '0.5'
        }
    }
}));

export default useStyles;
