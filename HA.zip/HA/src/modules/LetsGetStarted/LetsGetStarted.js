import { Box, Button, Container, Grid, IconButton } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import Image from 'next/image';
import PropTypes from 'prop-types';
import React from 'react';
import { ArrowLeft, ChevronLeft } from 'react-feather';
import useStyles from './LetsGetStartedStyles';

/**
 * Name: LetsGetStarted
 * Desc: Render LetsGetStarted
 */

const LetsGetStarted = ({ width }) => {
    const classes = useStyles();
    return (
        <Box
            className={classes.root}
            style={{ backgroundImage: `url('/splash.svg')` }}
            backgroundSize="cover"
            backgroundPosition="center">
            <Container>
                <Box display="flex" alignItems="center" flexDirection="column">
                    <Box
                        display="flex"
                        alignItems="center"
                        width="100%"
                        ml={width === 'xs' || width === 'sm' ? 0 : 22}
                        mb={5}>
                        <IconButton className={classes.menuButton}>
                            {width === 'xs' || width === 'sm' ? (
                                <ArrowLeft strokeWidth="3" color="Indigo" size={30} />
                            ) : (
                                <ChevronLeft strokeWidth="3" color="Indigo" size={30} />
                            )}
                        </IconButton>
                        <Box color="common.white" ml={2}>
                            {width === 'xs' || width === 'sm' ? '' : 'Go Back'}
                        </Box>
                    </Box>
                    <Grid container spacing={3} alignItems="center">
                        <Grid item xs={12} md={6}>
                            <Box display="flex" justifyContent="center" mb={width === 'xs' || width === 'sm' ? 1.5 : 0}>
                                <Image src="/Illo.svg" width={366} height={316} />
                            </Box>
                        </Grid>
                        <Grid item xs={12} md={6}>
                            <Box textAlign={width === 'xs' || width === 'sm' ? 'center' : ''}>
                                <Box
                                    fontSize="h2.fontSize"
                                    color="common.white"
                                    fontFamily="fontFamily.bold"
                                    mb={2}>
                                    Let’s Get Started
                                </Box>
                                <Box
                                    fontSize="h6.fontSize"
                                    color="common.white"
                                    fontFamily="fontFamily.medium"
                                    mb={5}>
                                    Thanks for taking the first step in accessing more affordable
                                    housing through HACEP’s assistance programs. Let’s get you
                                    started.
                                </Box>
                                
                                <Box>
                                    <Button size="large" color="secondary" variant="contained">
                                        Continue
                                    </Button>
                                </Box>
                            </Box>
                        </Grid>
                    </Grid>
                </Box>
            </Container>
        </Box>
    );
};
LetsGetStarted.propTypes = {
    width: PropTypes.string
};

export default withWidth()(LetsGetStarted);
