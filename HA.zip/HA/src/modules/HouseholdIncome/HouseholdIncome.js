import { Box, LinearProgress, Button } from '@material-ui/core';
import Router from 'next/router';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Info } from 'react-feather';
import {
    continueHousehold,
    setActiveStepIndex
} from '~/modules/HouseholdIncome/Utils/HouseholdIncomeAction';
import { STEPS } from '~/modules/HouseholdIncome/Utils/HouseholdIncomeConstants';
import {
    getProgressValue
} from '~/modules/HouseholdIncome/Utils/HouseholdIncomeUtils';
import CommonCard from '~/shared/components/CommonCard';
import TopHeader from '~/shared/components/Header/TopHeader';
import withLoader from '~/shared/components/hoc/withLoader';
import InformationCard from '~/shared/components/InformationCard';
import WizardHeader from '~/shared/components/WizardHeader';
import { ROUTES } from '~/shared/constants/routesConstants';
import ObjectCard from '~/shared/components/ObjectCard';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import HouseholdIncomeSelection from '~/shared/components/HouseholdComponents/HouseholdIncomeSelection';
import EmploymentDetails from '~/shared/components/HouseholdComponents/EmploymentDetails';
/**
 * Render HouseholdIncome
 */
const pageTitle = 'Household Income';

const HouseholdIncome = () => {
    const { HOME, HOUSEHOLD_ASSETS } = ROUTES;
    const { STEP1, STEP2, STEP3, STEP4, STEP5 , STEP6 } = STEPS;
    const dispatch = useDispatch();
    const [width, setWidth] = useState(window.innerWidth);
    const { activeStepIndex } = useSelector(
        (state) => state.householdIncome
    );

    const handleExitClick = () => {
        Router.push(HOME.ROUTE);
    };

    const handleClickContinue = async (fn, { ...data }) => {
        dispatch(fn({ ...data }));
        if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        } else {
            Router.push(HOUSEHOLD_ASSETS.ROUTE);
        }
    };

    const handleClickBack = () => {
        if (activeStepIndex !== STEP1) {
            dispatch(setActiveStepIndex(activeStepIndex - 1));
        } else {
            Router.push(HOME.ROUTE);
        }
    };

    function handleWindowSizeChange() {
        setWidth(window.innerWidth);
    }
    useEffect(() => {
        window.addEventListener('resize', handleWindowSizeChange); //todo : add custom hook for this
        return () => {
            window.removeEventListener('resize', handleWindowSizeChange);
        };
    }, []);

    let isMobile = width <= 1024;

    return (

        <Box>
            {activeStepIndex <= Object.keys(STEPS).length ? (
                <>
                    {!isMobile && (
                        <TopHeader
                            title={pageTitle}
                            isWizard={true}
                            onExitClick={handleExitClick}
                            onClickBack={handleClickBack}
                        />
                    )}
                    <LinearProgress
                        variant="determinate"
                        value={getProgressValue(activeStepIndex)}
                    />
                </>
            ) : null}

            { activeStepIndex === STEP1 ? (
                <>
                    <CommonCard pageView="full" bgColor="primary" onClickBack={handleClickBack}>
                        <InformationCard
                            title="Your Household Income"
                            subTitle="Next, we’ll ask you about all the sources of income for the whole household."
                            onClickContinue={() =>
                                handleClickContinue(continueHousehold, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                </>
            ) : null}
            {activeStepIndex === STEP2 ? (
                <>
                    <WizardHeader title="Income"  onClickBack={handleClickBack}/>
                    <CommonCard onClickBack={handleClickBack}>
                        <HouseholdIncomeSelection
                            title="Select all the sources of income that are true for yourself or for anyone in the household.*"
                            onClickContinue={() =>
                                handleClickContinue(continueHousehold, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <Box mt={6.5} px={3} display="inline-block">
                            <Box display="flex" mb={1}>
                                <Box mr={1} mt={0.5} display="flex">
                                    <Info color="Indigo" size={21} />
                                </Box>
                                <Box
                                    color="primary.light"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium">
                                    Reporting Income
                                </Box>
                            </Box>
                            <Box color="primary.extraLight" fontSize="md.fontSize">
                                You must report all income regardless of source, including
                                any income you expect to recieve within the next 90 days.
                            </Box>
                        </Box>
                    </Box>
                    <ExitConfirmation isExitText={true}  onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
            {activeStepIndex === STEP3 ? (
                <>
                    <WizardHeader>
                        <Box textAlign="center" mt={1.5}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Add Household Employment Income
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Add an employment source for every full or part-time job
                                held by all members of the household until all jobs are
                                shown below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="transparent" backBtnColor="backBtnWhite" onClickBack={handleClickBack}>
                        <Box>
                            {[{ documentName: 'Add Job or Employment' }].map((item) => (
                                <Box
                                    key={item.documentName}
                                    borderColor="primary.main"
                                    border="1px dashed"
                                    borderRadius="21px">
                                    <ObjectCard cardType="actionCard" iconName="plus">
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium"
                                            lineHeight="17px">
                                            {item.documentName}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                        </Box>
                    </CommonCard>
                    <Box display="flex" justifyContent="center">
                        <Button 
                            size="large" 
                            color="primary" 
                            variant="contained"
                            onClick={() =>
                                handleClickContinue(continueHousehold, {
                                    welcomeContinue: true
                                })
                            }
                        >
                            Continue
                        </Button>
                    </Box>
                    <ExitConfirmation isExitText={true}  onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
            {activeStepIndex === STEP4 ? (
                <>
                    <WizardHeader title="Household" />
                    <CommonCard onClickBack={handleClickBack}>
                        <EmploymentDetails 
                            title="First, enter all the information available for this job or employment income."
                            onClickContinue={() =>
                                handleClickContinue(continueHousehold, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} onContinueClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
            {activeStepIndex === STEP5 ? (
                <>
                    <WizardHeader>
                        <Box textAlign="center">
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Add Paystubs for this Job or Employment
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Provide the three most recent paystubs for [Firstname]’s
                                employment with [Employer Name]. If you don’t have them
                                available right now, you can skip for now and upload them
                                later.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="transparent" backBtnColor="backBtnWhite" onClickBack={handleClickBack}>
                        <Box mb={-3}>
                            {[
                                { documentName: 'Add Recent Paystub 1' },
                                { documentName: 'Add Recent Paystub 2' },
                                { documentName: 'Add Recent Paystub 3' }
                            ].map((item) => (
                                <Box
                                    key={item.documentName}
                                    borderColor="primary.main"
                                    border="1px dashed"
                                    borderRadius="21px"
                                    mb={3}>
                                    <ObjectCard cardType="actionCard" iconName="plus">
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium"
                                            lineHeight="17px">
                                            {item.documentName}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                        </Box>
                    </CommonCard>
                    <Box display="flex" justifyContent="center">
                        <Button 
                            size="large" 
                            color="primary"
                            variant="contained"
                            onClick={() =>
                                handleClickContinue(continueHousehold, {
                                    welcomeContinue: true
                                })
                            }
                        >
                            Finished Uploading
                        </Button>
                    </Box>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="Or Skip for Now" />
                </>
            ) : null}
            {activeStepIndex === STEP6 ? (
                <>
                    <WizardHeader>
                        <Box textAlign="center">
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Continue Adding Employment Income
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Add an employment source for every full or part-time job
                                held by all members of the household until all jobs are
                                shown below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="transparent" backBtnColor="backBtnWhite" onClickBack={handleClickBack}>
                        <Box>
                            <Box mb={3}>
                                <ObjectCard iconName="dollar-sign">
                                    <Box
                                        color="primary.main"
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium">
                                        Company Name
                                    </Box>
                                    <Box color="primary.light" fontSize="lg.fontSize">
                                        $1,341/mo. for Firstname
                                    </Box>
                                </ObjectCard>
                            </Box>
                            {[{ documentName: 'Add Job or Employment' }].map((item) => (
                                <Box
                                    key={item.documentName}
                                    mb={3}
                                    borderColor="primary.main"
                                    border="1px dashed"
                                    borderRadius="21px">
                                    <ObjectCard cardType="actionCard" iconName="plus">
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            {item.documentName}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                        </Box>
                    </CommonCard>
                    <Box display="flex" justifyContent="center">
                        <Button 
                            size="large"
                            color="primary" variant="contained"
                            onClick={() =>
                                handleClickContinue(continueHousehold, {
                                    welcomeContinue: true
                                })
                            }
                        >
                            Finished Adding
                        </Button>
                    </Box>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
        </Box>
    );
};

HouseholdIncome.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(HouseholdIncome);
