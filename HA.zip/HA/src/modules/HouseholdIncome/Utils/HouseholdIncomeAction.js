import { householdIncomeConstants } from './HouseholdIncomeConstants';
const {
    HOUSEHOLD_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    HOUSEHOLD_CHECK,
    RESET_FORM,
} = householdIncomeConstants;

export const setActiveStepIndex = (payload) => {
    return {
        type: HOUSEHOLD_ACTIVE_INDEX,
        payload
    };
};

export const continueWelcome = (payload) => {
    return {
        type: CONTINUE_WELCOME,
        payload
    };
};
export const continueHousehold= (payload) => {
    return {
        type: HOUSEHOLD_CHECK,
        payload
    };
};
export const resetForm = (payload) => {
    return {
        type: RESET_FORM,
        payload
    };
};

