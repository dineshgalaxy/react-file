import { householdIncomeConstants, initialState } from './HouseholdIncomeConstants';

const {
    HOUSEHOLD_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    HOUSEHOLD_CHECK,
    RESET_FORM,
    HOUSEHOLD_STATUS
} = householdIncomeConstants;

export const HouseholdIncome = (state = initialState, action) => {
    switch (action.type) {
        case CONTINUE_WELCOME: {
            return {
                ...state,
                welcomeContinue: action.payload.welcomeContinue
            };
        }
        case HOUSEHOLD_CHECK: {
            return {
                ...state,
                householdIncomeCheck: action.payload.householdIncomeCheck
            };
        }
        case HOUSEHOLD_ACTIVE_INDEX: {
            return {
                ...state,
                activeStepIndex: action.payload
            };
        }
        case RESET_FORM: {
            return {
                ...initialState
            };
        }
        case HOUSEHOLD_STATUS: {
            return {
                ...state,
                activeStepIndex: 5,
                householdIncomeStatus: action.payload
            };
        }
        default:
            return state;
    }
};
