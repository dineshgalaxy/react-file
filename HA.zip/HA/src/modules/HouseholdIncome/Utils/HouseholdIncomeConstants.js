export const initialState = {
    activeStepIndex: 1,
    welcomeContinue: false,
    householdIncomeCheck: false,
    familyMember: '',
    monthlyIncome: '',
    reviewStatus: 0
};
export const householdIncomeConstants = {
    HOUSEHOLD_ACTIVE_INDEX: 'HOUSEHOLD_ACTIVE_INDEX',
    SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
    CONTINUE_WELCOME: 'CONTINUE_WELCOME',
    HOUSEHOLD_CHECK: 'HOUSEHOLD_CHECK',
    SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
    RESET_FORM: 'RESET_FORM',
    HOUSEHOLD_STATUS: 'HOUSEHOLD_STATUS'
};

export const STEPS = {
    STEP1: 1,
    STEP2: 2,
    STEP3: 3,
    STEP4: 4,
    STEP5: 5,
    STEP6: 6
};

export const householdIncomeStatusConstant = {
    SUCCESS: 1,
    FAILED: 2,
    PENDING: 3
};

export const householdIncomeStatusData = {
};
