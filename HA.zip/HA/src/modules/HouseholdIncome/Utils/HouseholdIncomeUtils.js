import { noop } from '~/shared/utils/utils';
import { householdIncomeStatusConstant, householdIncomeStatusData } from './HouseholdIncomeConstants';

export const getProgressValue = (activeIndex) => {
    return 16.666666667 * activeIndex;
};
export const getHouseholdIncomeStatusData = (householdIncomeStatus, onExitClickFun, onSuccessClick) => {
    const householdIncomeStatusRes = {
        Success: 1,
        Failed: 2,
        Questioned: 3
    }[householdIncomeStatus];

    let onPrimaryClick = noop;
    if (householdIncomeStatusRes === householdIncomeStatusConstant.SUCCESS) {
        onPrimaryClick = onSuccessClick;
    } else if (householdIncomeStatusRes === householdIncomeStatusConstant.FAILED) {
        onPrimaryClick = onExitClickFun;
    } else {
        onPrimaryClick = onExitClickFun;
    }

    const data = householdIncomeStatusData[householdIncomeStatusRes];
    return {
        ...data,
        onPrimaryClick: onPrimaryClick
    };
};
