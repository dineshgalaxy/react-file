import { Box, Card } from '@material-ui/core';
import React from 'react';
import useStyles from './ApplicationSubmittedStyles';
import PropTypes from 'prop-types';

/**
 * Name : ApplicationSubmitted
 * Desc : Render ApplicationSubmitted
 */

const ApplicationSubmitted = ({ apllicationTitle, children }) => {
    const classes = useStyles();

    return (
        <Box className={classes.flex} width="100%">
            <Card>
                <Box px={2.5} pt={2.5} pb={3.5}>
                    <Box mx={-3} mb={2} px={3} pb={1} className={classes.title}>
                        <Box
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.semiBold"
                            color="primary.light"
                            textAlign="center"
                            pb={1}>
                           {apllicationTitle}
                        </Box>
                    </Box>
                    <Box ml={-3} mr={-3} pl={3} pr={3} pb={3}>
                        {children && children}
                    </Box>
                </Box>
            </Card>
        </Box>
    );
};

ApplicationSubmitted.propTypes = {
    apllicationTitle: PropTypes.string,
    children:PropTypes.node
};

export default ApplicationSubmitted;
