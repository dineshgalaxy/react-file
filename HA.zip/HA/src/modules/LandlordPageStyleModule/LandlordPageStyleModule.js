import { Box, FormControl, TextField, Grid, Card, Button } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import React from 'react'
import { Info } from 'react-feather';
import CommonCard from 'shared/components/CommonCard';
import StatusCard from 'shared/components/StatusCard';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import WizardHeader from '~/shared/components/WizardHeader';
import PageHeading from '~/shared/components/PageHeading';
import InformationCard from '~/shared/components/InformationCard';
import ObjectCard from '~/shared/components/ObjectCard';
import ReviewTenantDetails from '~/shared/components/LandlordPageComponent/ReviewTenantDetails';
import UnitDetails from '~/shared/components/LandlordPageComponent/Unitdetails/UnitDetails';
import ReviewUnitTerms from '~/shared/components/LandlordPageComponent/ReviewUnitTerms';
import UnitStructureDetails from '~/shared/components/LandlordPageComponent/UnitStructureDetails';
import UnitSubsidyDetails from '~/shared/components/LandlordPageComponent/UnitSubsidyDetails';
import UnitAmenitySelection from '~/shared/components/LandlordPageComponent/UnitAmenitySelection/UnitAmenitySelection';
import UnitUtilitySelection from '~/shared/components/LandlordPageComponent/UnitUtilitySelection';
import UnitUtilityPayerSelection from '~/shared/components/LandlordPageComponent/UnitUtilityPayerSelection';
import UnitAppliancePayerSelection from '~/shared/components/LandlordPageComponent/UnitAppliancePayerSelection';
import MultiplePropertySelection from '~/shared/components/LandlordPageComponent/MultiplePropertySelection';
import ComparableUnitDetails from '~/shared/components/LandlordPageComponent/ComparableUnitDetails';
import LeadDisclosureSelection from '~/shared/components/LandlordPageComponent/LeadDisclosureSelection/LeadDisclosureSelection';
import FamilyDisclosureAgreement from '~/shared/components/LandlordPageComponent/FamilialDisclosureAgreement';
import HouseholdScreeningResponsibilityAgreement from '~/shared/components/LandlordPageComponent/HouseholdScreeningResponsibilityAgreement/HouseholdScreeningResponsibilityAgreement';
import ScreeningResponsibilityAgreement from '~/shared/components/LandlordPageComponent/ScreeningResponsibilityAgreement';
import InspectionsAgreement from '~/shared/components/LandlordPageComponent/InspectionsAgreement';
import DisclosureProvisionsAgreement from '~/shared/components/LandlordPageComponent/DisclosureProvisionsAgreement';
import AppointmentDetails from '~/shared/components/LandlordPageComponent/AppointmentDetails';
import AppointmentContactDetails from '~/shared/components/LandlordPageComponent/AppointmentContactDetails/AppointmentContactDetails';
import LesseeAndUnitReview from '~/shared/components/LandlordPageComponent/LesseeAndUnitReview';
import UnitDetailsReview from '~/shared/components/LandlordPageComponent/UnitDetailsReview/UnitDetailsReview';
import UnitCompsReview from '~/shared/components/LandlordPageComponent/UnitCompsReview';
import DocumentsReview from '~/shared/components/LandlordPageComponent/DocumentsReview';
import LandlordRevieweSignatureTerms from '~/shared/components/LandlordPageComponent/LandlordRevieweSignatureTerms';
import ReviewRFTASubmissionTerms from '~/shared/components/LandlordPageComponent/ReviewRFTASubmissionTerms';
import ApplicationSubmitted from '~/shared/components/ApplicationSubmitted';


/**
 * Name: LandlordPageStyleModule
 * Desc: Render LandlordPageStyleModule
 */
 const useStyles = makeStyles((theme) => ({
    boxInfo: {
        position: 'relative',
        paddingLeft: theme.spacing(2),
        paddingBottom: theme.spacing(0.4),
        '&:before': {
            content: '""',
            width: '4px',
            height: '4px',
            background: theme.palette.primary.extraLight,
            position: 'absolute',
            left: '0',
            top: '10px',
            borderRadius: '50%'
        }
    }
}));

const LandlordPageStyleModule = () => {
    const classes = useStyles();
    return (
        <Box bgcolor="secondary.light" py={2} px={2}>
            <Grid container spacing={3}>
                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="RFTA Welcome"/>
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            backBtnColor="backBtnWhite"
                            landingPageIcon={true}
                            pageView="full">
                            <StatusCard
                                showButton={true}
                                imageUrl="/Illo.svg"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                        Ready to start an RFTA for a new lessee?
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                            We’ll help you fill out your new Request for Tenancy Approval (RFTA) that is required to initiate housing assistance for your future tenant.
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="RFTA Expectations" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <InformationCard
                                showImage={false}
                                textAlign="left"
                                btnTitle="Start Your RFTA"
                                title="You’ll need some information and documents ready."
                                content={
                                    <>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={3}>
                                            We’ll collect information about the tenant, the rental unit itself, and the lease agreements you’ve made with the lessee. You’ll need the following items to complete the RFTA:
                                        </Box>
                                        <Card>
                                            <Box
                                                px={3}
                                                py={3.5}
                                                color="primary.extraLight"
                                                fontSize="h6.fontSize">
                                                {[
                                                    'The lessee’s voucher number',
                                                    'Unit details and property information',
                                                    'A copy of the lease agreement',
                                                    'A voided check (for deposits from HACEP)',
                                                    'Details for 3 comparative rental units (if unsubsidized)'
                                                ].map((item, index) => (
                                                    <Box
                                                        key={`${item}_${index}`}
                                                        className={classes.boxInfo}>
                                                        {item}
                                                    </Box>
                                                ))}
                                                <Box
                                                    fontSize="md.fontSize"
                                                    color="primary.main"
                                                    pt={3}>
                                                    {'Takes about: 60 minutes'}
                                                </Box>
                                            </Box>
                                        </Card>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mt="30px"
                                            mb={3}>
                                            If you need to return later to finish your application, you can save your progress and exit at any point.
                                        </Box>
                                    </>
                                }
                            />
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Tenant Entry" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/Illo.svg"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={4}
                                        mt={1}
                                        color="primary.light">
                                        First, enter the lessee’s T-Number below.
                                    </Box>
                                    <Box mb={3} textAlign="left">
                                       <FormControl fullWidth>
                                            <TextField id="jobTitle" label="E.g. T123456" variant="filled" />
                                        </FormControl>
                                    </Box>
                                  
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Loading Tenant" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            pageView="full"
                            showBackBtn={false}>
                            <StatusCard
                                iconName="more-horizontal"
                                iconStatus="success"
                                iconColor="indigo"
                                showButton={false}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                        Hold on while we locate your lessee.
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review Tenant Details" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={3.5}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                We’ve found the individual below.
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Review the details listed below to confirm that the information matches your tenant.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewTenantDetails/>
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <Box mt={5} px={3} display="inline-block">
                            <Box display="flex" mb={1}>
                                <Box mr={1} mt={0.5} display="flex">
                                    <Info color="Indigo" size={21} />
                                </Box>
                                <Box
                                    color="primary.light"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    lineHeight="28px">
                                    Not Your Lessee?
                                </Box>
                            </Box>
                            <Box color="primary.extraLight" fontSize="md.fontSize">
                                If the information above does not match your tenant, use the arrow to go back to the previous screen and re-enter your tenant’s T-Number, making sure your entry is free of errors or typos.
                            </Box>
                        </Box>
                    </Box>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="T-Number Not Found" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/Illo.svg"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        We didn’t find anyone with that T-Number.
                                    </Box>
                                    <Box 
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium"
                                        color="primary.light"
                                        mb={3}>
                                        Check your lessee’s voucher and re-enter their T-Number.
                                    </Box>
                                    <Box textAlign="left">
                                       <FormControl fullWidth>
                                            <TextField id="jobTitle" label="E.g. T123456" variant="filled" />
                                        </FormControl>
                                    </Box>
                                  
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Info Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Your Rental Unit Info and Terms
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            First we’ll collect some details about your rental unit, and verify that the unit is likely to be affordable for this tenant. 
                                        </Box>
                                    </Box>
                                  
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Details" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader title="Unit Terms" />
                                <CommonCard>
                                    <UnitDetails/>
                                </CommonCard>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Loading Affordability" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            pageView="full"
                            showBackBtn={false}>
                            <StatusCard
                                iconName="more-horizontal"
                                iconStatus="success"
                                iconColor="indigo"
                                showButton={false}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                        Hold on while we calculate the affordability of this unit for the lessee.
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Affordability Success" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            backBtnColor="backBtnWhite"
                            landingPage={true}
                            pageView="full"
                            landingPageIcon={true}>
                            <StatusCard
                                iconName="thumbs-up"
                                iconStatus="success"
                                buttonType="secondary"
                                iconColor="indigo"
                                showButton={true}
                                showLink={true}
                                linkText="Or Save and Exit"
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={6}
                                        mt={1}
                                        color="common.white">
                                       Great, it looks like this unit meets the affordability requirements for this lessee.
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={12} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Affordability Questioned" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            backBtnColor="backBtnWhite"
                            landingPage={true}
                            pageView="full"
                            landingPageIcon={true}>
                            <StatusCard
                                iconName="alert-triangle"
                                iconStatus="pending"
                                buttonType="secondary"
                                iconColor="indigo"
                                showButton={true}
                                showLink={true}
                                linkText="Or Save and Exit"
                                buttonText="Yes, Adjust Rent"
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                       The proposed monthly rent falls outside of our affordability calculations for this lessee.
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        mb={6}
                                        mt={1}
                                        color="common.white">
                                       We’ve found that the monthly rent for this unit would need to be a maximum of $750 per month to continue. <Box fontFamily="fontFamily.bold">Would you like to reduce the rent amount to $750 per month and continue with the RFTA?</Box>
                                    </Box>
                                    <Box mb={3}>
                                        <Button
                                            size="large"
                                            color="inherit"
                                            variant="contained"
                                            className="w-269">
                                            No
                                        </Button>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review Unit Terms" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={1.5}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review the Updated Rental Terms
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                We updated the rent to meet the lessee’s affordability. Review the terms below and confirm to continue with the RFTA.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewUnitTerms/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Info Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Unit Details
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            Next, we’ll collect details about the unit itself including the structure, amenities, and more. You can save and exit at any point if you need more time to complete your RFTA.
                                        </Box>
                                    </Box>
                                  
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>


                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Structure Details" />
                        </Box>
                        <>
                            <WizardHeader title="Unit Details" />
                            <CommonCard>
                                <UnitStructureDetails/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Subsidy Details" />
                        </Box>
                        <Box bgcolor="secondary.extraLight">
                            <WizardHeader title="Unit Details" />
                            <CommonCard>
                               <UnitSubsidyDetails/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Amenity Selection" />
                        </Box>
                        <Box bgcolor="secondary.extraLight">
                            <WizardHeader title="Unit Details" />
                            <CommonCard>
                               <UnitAmenitySelection/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Utility Selection" />
                        </Box>
                        <>
                            <WizardHeader title="Unit Details" />
                            <CommonCard>
                                <UnitUtilitySelection/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Utility Payer Selection" />
                        </Box>
                        <>
                            <WizardHeader title="Unit Details" />
                            <CommonCard>
                                <UnitUtilityPayerSelection/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Appliance Payer Selection" />
                        </Box>
                        <>
                            <WizardHeader title="Unit Details" />
                            <CommonCard>
                                <UnitAppliancePayerSelection/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Multiple Property Selection"/>
                        </Box>
                        <Box bgcolor="secondary.extraLight">
                            <WizardHeader title="Unit Details"/>
                            <CommonCard>
                                <MultiplePropertySelection/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT"/>
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Comparable Unit Details" />
                        </Box>
                        <>
                            <WizardHeader title="Unit Details" />
                            <CommonCard>
                                <ComparableUnitDetails/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={12} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Comparable Unit Review"/>
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Review Your Comparable Units
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            The three units you’ve entered for comparison are shown below. If everything looks correct, click “Continue” to proceed.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box mb={-3}>
                                        {[
                                            { title: 'Address Line 1', subtitle: '$750/month' },
                                            { title: 'Address Line 1', subtitle: '$785/month' },
                                            { title: 'Address Line 1', subtitle: '$1200/month' }
                                         ].map((item) => (
                                            <Box mb={3} key={item.title}>
                                                <ObjectCard iconName="map-pin">
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium">
                                                        {item.title}
                                                    </Box>
                                                    <Box color="primary.light" fontSize="lg.fontSize">
                                                        {item.subtitle}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                        
                                    </Box>
                                </CommonCard>
                                <Box display="flex" justifyContent="center">
                                    <Button size="large" color="primary" variant="contained">
                                        Continue
                                    </Button>
                                </Box>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Disclosures Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Unit Disclosures
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            Next, we need you to provide some legal and safety disclosures that helps us verify the safety of the unit for the tenant and meet federal compliance guidelines.
                                        </Box>
                                    </Box>
                                  
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Multiple Property Selection"/>
                        </Box>
                        <Box bgcolor="secondary.extraLight">
                            <WizardHeader title="Disclosures"/>
                            <CommonCard>
                                <LeadDisclosureSelection/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT"/>
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Familial Disclosure Agreement" />
                    </Box>
                    <WizardHeader title="Disclosures"/>
                    <CommonCard bgColor="gray">
                       <FamilyDisclosureAgreement/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Screening Responsibility Agreement" />
                    </Box>
                    <WizardHeader title="Disclosures"/>
                    <CommonCard bgColor="gray">
                       <HouseholdScreeningResponsibilityAgreement/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Screening Responsibility Agreement" />
                    </Box>
                    <WizardHeader title="Disclosures"/>
                    <CommonCard bgColor="gray">
                       <ScreeningResponsibilityAgreement/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Inspections Agreement" />
                    </Box>
                    <WizardHeader title="Disclosures"/>
                    <CommonCard bgColor="gray">
                       <InspectionsAgreement/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Disclosure Provisions Agreement" />
                        </Box>
                        <>
                            <WizardHeader title="Unit Details" />
                            <CommonCard>
                                <DisclosureProvisionsAgreement/>
                            </CommonCard>
                            <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Landlord Documents Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Uploading Your Documents
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            We need a few items to complete your RFTA, including a copy of the lease, a voided check, and lead hazard documentation if applicable. We’ll walk you through uploading them on the following screens, or you can save and return later to finish if needed.
                                        </Box>
                                    </Box>
                                  
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Comparable Unit Review"/>
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader>
                                    <Box textAlign="center" mt={1}>
                                        <Box
                                            fontSize="h3.fontSize"
                                            color="common.white"
                                            fontFamily="fontFamily.bold"
                                            mb={2}
                                            lineHeight="32px">
                                            Review Your Comparable Units
                                        </Box>
                                        <Box fontSize="h6.fontSize" color="common.white">
                                            The three units you’ve entered for comparison are shown below. If everything looks correct, click “Continue” to proceed.
                                        </Box>
                                    </Box>
                                </WizardHeader>

                                <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                    <Box mb={-3}>
                                        {[
                                            { documentName: 'Add Copy of the Lease'},
                                            { documentName: 'Add a Voided Check'},
                                            { documentName: 'Add Lead Disclosure(s)'}
                                         ].map((item) => (
                                            <Box 
                                                mb={3} 
                                                key={item.documentName} 
                                                borderColor="primary.main"
                                                border="1px dashed"
                                                borderRadius="21px">
                                                <ObjectCard cardType="actionCard" iconName="plus">
                                                    <Box
                                                        color="primary.main"
                                                        fontSize="h6.fontSize"
                                                        fontFamily="fontFamily.medium">
                                                        {item.documentName}
                                                    </Box>
                                                </ObjectCard>
                                            </Box>
                                        ))}
                                        
                                    </Box>
                                </CommonCard>
                                <Box display="flex" justifyContent="center" mt={2} mb={-2}>
                                    <Button size="large" color="primary" variant="contained">
                                        Finished Uploading
                                    </Button>
                                </Box>
                                <Box display="flex" justifyContent="center">
                                    <ExitConfirmation
                                        isExitText={true}
                                        exitText="Or Skip for Now"
                                    />
                                </Box>
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box mb={5}>
                            <PageHeading title="Skip Documents" />
                        </Box>
                        <CommonCard
                            bgScreen={'welcome'}
                            backBtnColor="backBtnWhite"
                            landingPage={true}
                            pageView="full"
                            landingPageIcon={true}>
                            <StatusCard
                                iconName="alert-triangle"
                                iconStatus="pending"
                                buttonType="secondary"
                                iconColor="indigo"
                                showButton={true}
                                buttonText="Continue"
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="common.white">
                                       You’ve chosen to skip uploading documents for now.
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        mb={6}
                                        mt={1}
                                        color="common.white">
                                       You can continue entering information and come back later to upload your documents. Please note that in order to submit your RFTA, you will need to locate the required documents.
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>
                
                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Unit Inspection Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Scheduling Your Inspection
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            HACEP will facilitate the inspection of the rental unit to ensure that it meets all the standards needed for the housing assistance program. We’ll help you schedule a time for the inspection visit.
                                        </Box>
                                    </Box>
                                  
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Add Appointment Times" />
                        </Box>
                        <>
                            <WizardHeader>
                                <Box textAlign="center" mt={1}>
                                    <Box
                                        fontSize="h3.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.bold"
                                        mb={2}
                                        lineHeight="32px">
                                        Select Your Preferred Appointment Times
                                    </Box>
                                    <Box fontSize="h6.fontSize" color="common.white">
                                        Let us know of a few times that you’ll be available to meet the inspector at the property. An inspector will confirm your appointment window  within the next few days.
                                    </Box>
                                </Box>
                            </WizardHeader>

                            <CommonCard bgColor="transparent" backBtnColor="backBtnWhite">
                                <Box mb={-3}>
                                    <Box mb={3}>
                                        <ObjectCard iconName="Calendar">
                                            <Box
                                                color="primary.main"
                                                fontSize="h6.fontSize"
                                                fontFamily="fontFamily.medium"
                                                lineHeight="17px">
                                                February 14, 2022
                                            </Box>
                                            <Box color="primary.light" fontSize="lg.fontSize">
                                                9am-11am + 1 more 
                                            </Box>
                                        </ObjectCard>
                                    </Box>

                                    {[
                                        { documentName: 'Select Date and Time 2' },
                                        { documentName: 'Select Date and Time 3' }
                                    ].map((item) => (
                                        <Box
                                            key={item.documentName}
                                            borderColor="primary.main"
                                            border="1px dashed"
                                            borderRadius="21px"
                                            mb={3}>
                                            <ObjectCard cardType="actionCard" iconName="plus">
                                                <Box
                                                    color="primary.main"
                                                    fontSize="h6.fontSize"
                                                    fontFamily="fontFamily.medium"
                                                    lineHeight="17px">
                                                    {item.documentName}
                                                </Box>
                                            </ObjectCard>
                                        </Box>
                                    ))}
                                </Box>
                            </CommonCard>
                            <Box display="flex" justifyContent="center">
                                <Button size="large" color="primary" variant="contained">
                                    Continue
                                </Button>
                            </Box>
                            <ExitConfirmation isExitText={true} exitText="Or Skip for Now" />
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Appointment Details" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader title="Inspection" />
                                <CommonCard>
                                    <AppointmentDetails/>
                                </CommonCard>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Appointment Contact Details" />
                        </Box>
                        <>
                            <Box bgcolor="secondary.extraLight">
                                <WizardHeader title="Inspection" />
                                <CommonCard>
                                    <AppointmentContactDetails/>
                                </CommonCard>
                                <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                            </Box>
                        </>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="Review and Sign Starter" />
                        </Box>
                        <CommonCard pageView="full" bgColor="primary" landingPageIcon={true}>
                            <StatusCard
                                showButton={true}
                                buttonType="primary"
                                imageUrl="/household.png"
                                showImage={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.light">
                                        Review and Sign Your RFTA
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box
                                            fontSize="h6.fontSize"
                                            color="primary.extraLight"
                                            lineHeight="26px"
                                            mb={2.5}>
                                            You’re almost done! The last thing you’ll need to do is review your application for accuracy, add your esignature, and submit your RFTA to HACEP for processing.
                                        </Box>
                                    </Box>
                                  
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Lessee and Unit Review" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review Your Lessee, Unit Info and Terms
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Use the edit links below to modify any of your application information that is not correct. When you’re done, click “Confirm and Continue” below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <LesseeAndUnitReview/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Unit Details Review" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review The Details Provided for the Unit
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Use the edit links below to modify any of your application information that is not correct. When you’re done, click “Confirm and Continue” below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <UnitDetailsReview/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Unit Comps Review" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review Your Comparable Units
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Use the edit links below to modify any of your application information that is not correct. When you’re done, click “Confirm and Continue” below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <UnitCompsReview/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Documents Review" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Review Your  Documents
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Use the edit links below to modify any of your application information that is not correct. When you’re done, click “Confirm and Continue” below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <DocumentsReview/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={12} width="100%">
                    <Box>
                        <PageHeading title="Review eSignature Terms" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Get Ready to Sign Your RFTA 
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                The waiver below enables HACEP to use your esignature to sign your Request for Tenancy Approval.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <LandlordRevieweSignatureTerms/>
                    </CommonCard>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box>
                        <PageHeading title="Review RFTA Submission Terms" />
                    </Box>
                    <WizardHeader>
                        <Box textAlign="center" mt={1} pb={2}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Sign and Submit Your RFTA
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Read the terms and conditions below. Once you’ve read and understand them, enter your eSignature and submit your RFTA.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray">
                        <ReviewRFTASubmissionTerms/>
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <Box mt={5} px={3} display="inline-block">
                            <Box display="flex" mb={1}>
                                <Box mr={1} mt={0.5} display="flex">
                                    <Info color="Indigo" size={21} />
                                </Box>
                                <Box
                                    color="primary.light"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium"
                                    lineHeight="28px">
                                    Warning
                                </Box>
                            </Box>
                            <Box color="primary.extraLight" fontSize="md.fontSize">
                                Title 18 US Code Section 1001 states that a person is guilty of a felony for knowingly and willingly making a false or fraudulent statement to any Department or Agency of the United States. State law may also provide penalties for false or fraudulent statements.
                            </Box>
                        </Box>
                    </Box>
                    <ExitConfirmation isExitText={true} exitText="SAVE AND EXIT" />
                </Grid>

                <Grid item xs={12} md={6} width="100%">
                    <Box pt={3} pb={3}>
                        <Box>
                            <PageHeading title="RFTA Submitted" />
                        </Box>
                        <CommonCard bgScreen={'success'} space="xs">
                            <StatusCard
                                buttonText="Exit to Dashboard"
                                buttonType="primary"
                                iconName="check-circle"
                                iconStatus="complete"
                                iconColor="indigo"
                                showButton={true}
                            >
                                <>
                                    <Box
                                        fontSize="h2.fontSize"
                                        fontFamily="fontFamily.bold"
                                        lineHeight="40px"
                                        mb={2}
                                        mt={1}
                                        color="primary.main">
                                        We’ve received your RFTA.
                                    </Box>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="common.white"
                                        fontFamily="fontFamily.medium"
                                        mb={5}>
                                        <Box mt={4}>
                                            <ApplicationSubmitted title="What’s Next?">
                                                <Box color="primary.light" fontSize="h6.fontSize" pb={1.5}>
                                                    An administrator will review your submission, verify the information and documents you’ve provided. 
                                                </Box>
                                                <Box color="primary.light" fontSize="h6.fontSize" pb={1.5}>
                                                    You will be contacted at the number you’ve provided to confirm the final time for your inspection of the unit. 
                                                </Box>
                                                <Box color="primary.light" fontSize="h6.fontSize">
                                                    If your RFTA and inspection are approved, we will deliver the housing contract for your signature and finalization. 
                                                </Box>
                                            </ApplicationSubmitted>
                                        </Box>
                                    </Box>
                                </>
                            </StatusCard>
                        </CommonCard>
                    </Box>
                </Grid>



            </Grid>
        </Box>
    )
}


export default LandlordPageStyleModule
