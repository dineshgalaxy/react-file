export const FIELDS = {
    MONTHLY_INCOME: 'monthlyIncome'
};
