import { Box, Button, FormControl, TextField } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';
import { useSelector } from 'react-redux';
import { saveMonthlyIncome } from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityAction';
import useForm from '~/shared/customHooks/useForm';
import { FIELDS } from './BudgetCardInfoConstants';
import useStyles from './BudgetCardInfoStyles';
import { onValidate } from './BudgetCardInfoUtils';
import { InputAdornment } from '@material-ui/core';

/**
 * Name: BudgetCardInfo
 * Desc: Render BudgetCardInfo
 */

const BudgetCardInfo = ({ title, onClickContinue, width }) => {
    const classes = useStyles();
    const { monthlyIncome: defaultValue } = useSelector((state) => state.checkEligibility);
    const initialValue = {
        monthlyIncome: defaultValue
    };
    const { values, handleOnChange, handleSubmit, errors, handleBlur } = useForm(
        initialValue,
        onValidate
    );

    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onClickContinue(saveMonthlyIncome, values);
        }
    };
    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? "100%" : 337}>
                <Box fontSize={width === 'xs' || width === 'sm' ? "h5.fontSize" : "h3.fontSize"} color="primary.light" mt={width === 'xs' || width === 'sm' ? 0 : 3} mb={width === 'xs' || width === 'sm' ? 3.5 : 2} lineHeight={width === 'xs' || width === 'sm' ? "35px" : "41px"}>
                    {title}
                </Box>
            </Box>
            <Box className={classes.textAlign} width="100%">
                <form onSubmit={handleFormSubmit}>
                    <Box mb={3.5}>
                        <FormControl fullWidth>
                            <TextField
                                required
                                autoComplete='off'
                                error={!!errors[FIELDS.MONTHLY_INCOME]}
                                id="standard-basic"
                                label="Enter monthly income"
                                variant="filled"
                                name={FIELDS.MONTHLY_INCOME}
                                value={values[FIELDS.MONTHLY_INCOME]}
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                InputProps={{
                                    startAdornment:
                                        <Box pt={2}>
                                            <InputAdornment position="start">
                                                $
                                            </InputAdornment>
                                        </Box>,
                                }}
                                helperText={
                                    errors[FIELDS.MONTHLY_INCOME]
                                        ? errors[FIELDS.MONTHLY_INCOME]
                                        : ''
                                }
                            />
                        </FormControl>
                    </Box>

                    <Box className={classes.xsBtn}>
                        <Button
                            size="large"
                            color="primary"
                            variant="contained"
                            type="submit"
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={width === 'xs' || width === 'sm' ? 'semiBorder' : ''}>
                            Next
                        </Button>
                    </Box>
                </form>
            </Box>
        </Box>
    );
};
BudgetCardInfo.defaultProps = {
    title: ''
};
BudgetCardInfo.propTypes = {
    title: PropTypes.string,
    onClickContinue: PropTypes.func,
    width: PropTypes.string
};

export default withWidth()(BudgetCardInfo);
