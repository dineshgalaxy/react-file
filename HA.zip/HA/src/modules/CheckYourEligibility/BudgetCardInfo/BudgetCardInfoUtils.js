export const onValidate = (values) => {
    const errors = {};
    if (!values.monthlyIncome) {
        errors.monthlyIncome = 'This is required field.';
    }
    
    if (Number(values.monthlyIncome)) {
        if (!/^\d*(\.)?(\d{0,2})?$/.test(values.monthlyIncome)) {
            errors.monthlyIncome = 'Please enter income upto two decimal numbers.';
        }
        if (values.monthlyIncome > 99999.99) {
            errors.monthlyIncome = "Income can't be greater than $99,999.99";
        }
    }

    else {
        errors.monthlyIncome = 'Please enter valid income.';
    }

    return errors;
};




// /^(0|[1-9]\d*)(\.\d+)?$/