import { Box, Button, FormControl, FormHelperText, MenuItem, Select } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import ExpandMoreOutlinedIcon from '@material-ui/icons/ExpandMoreOutlined';
import PropTypes from 'prop-types';
import React from 'react';
import { useSelector } from 'react-redux';
import { saveFamilyInfo } from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityAction';
import useForm from '~/shared/customHooks/useForm';
import { FIELDS } from './FamilyInfoCardConstants';
import useStyles from './FamilyInfoCardStyles';
import { onValidate, getMemberText } from './FamilyInfoCardUtils';
/**
 * Name: FamilyInfoCard
 * Desc: Render FamilyInfoCard
 */

const FamilyInfoCard = ({ title, onClickContinue, width, familyMemberList }) => {
    const classes = useStyles();
    const { familyMember: defaultValue } = useSelector((state) => state.checkEligibility);
    const initialValue = {
        familyMember: defaultValue
    };
    const { values, handleOnChange, handleSubmit, errors, handleBlur } = useForm(
        initialValue,
        onValidate
    );

    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onClickContinue(saveFamilyInfo, values);
        }
    };

    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
                <Box
                    fontSize={width === 'xs' || width === 'sm' ? 'h5.fontSize' : 'h3.fontSize'}
                    color="primary.light"
                    mt={width === 'xs' || width === 'sm' ? 0 : 3}
                    mb={width === 'xs' || width === 'sm' ? 3.5 : 2}
                    lineHeight={width === 'xs' || width === 'sm' ? '35px' : '41px'}>
                    {title}
                </Box>
            </Box>

            <Box className={classes.textAlign} width="100%">
                <form onSubmit={(e) => handleFormSubmit(e)}>
                    <Box mb={3.5} className="withoutLabel">
                        <FormControl variant="filled" fullWidth error={!!errors.familyMember}>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                displayEmpty
                                iconcomponent={ExpandMoreOutlinedIcon}
                                onChange={handleOnChange}
                                placeholder="Select Members"
                                name={FIELDS.FAMILY_MEMBER}
                                value={values[FIELDS.FAMILY_MEMBER]}
                                onBlur={handleBlur}>
                                <MenuItem value="" disabled>
                                    Select
                                </MenuItem>
                                {familyMemberList.map(({ id, no_of_members }) => (
                                    <MenuItem value={id} key={id}>
                                        {getMemberText(no_of_members)}
                                    </MenuItem>
                                ))}
                            </Select>
                            {errors[FIELDS.FAMILY_MEMBER] ? (
                                <FormHelperText>{errors[FIELDS.FAMILY_MEMBER]}</FormHelperText>
                            ) : (
                                ''
                            )}
                        </FormControl>
                    </Box>

                    <Box className={classes.xsBtn}>
                        <Button
                            size="large"
                            color="primary"
                            variant="contained"
                            type="submit"
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={width === 'xs' || width === 'sm' ? 'semiBorder' : ''}>
                            Next
                        </Button>
                    </Box>
                </form>
            </Box>
        </Box>
    );
};

FamilyInfoCard.defaultProps = {
    title: '',
    subtitle: ''
};

FamilyInfoCard.propTypes = {
    title: PropTypes.string,
    subtitle: PropTypes.string,
    onClickContinue: PropTypes.func,
    width: PropTypes.string,
    familyMemberList: PropTypes.array
};

export default withWidth()(FamilyInfoCard);
