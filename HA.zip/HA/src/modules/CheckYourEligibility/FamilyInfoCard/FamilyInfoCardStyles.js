import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    imgWidth: {
        '& .MuiAvatar-root': {
            width: '337px',
            height: ' 302px',
            [theme.breakpoints.down('sm')]: {
                width: '297px',
                height: '266px'
            }
        }
    },
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 96px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: '0 0 30px 0'
        }
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    },
    textAlign: {
        maxWidth: '283px',
        [theme.breakpoints.down('sm')]: {
            maxWidth: '100%'
        }
    }
}));

export default useStyles;
