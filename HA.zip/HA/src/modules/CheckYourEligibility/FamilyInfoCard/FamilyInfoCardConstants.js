export const FIELDS = {
    FAMILY_MEMBER: 'familyMember'
};
