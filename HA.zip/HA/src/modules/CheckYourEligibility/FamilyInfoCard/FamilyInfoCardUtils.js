export const onValidate = (values) => {
    const errors = {};
    if (!values.familyMember) {
        errors.familyMember = 'This is a required field.';
    }

    return errors;
};


export const getMemberText = (no_of_members) => {
    return no_of_members > 1 ? no_of_members + " members " : no_of_members + " member ";
};
