export { default } from './FamilyInfoCard';
