import { eligibilityConstants, initialState } from './CheckYourEligibilityConstants';

const {
    ELIGIBILITY_ACTIVE_INDEX,
    SAVE_MONTHLY_INCOME,
    SAVE_FAMILY_INFO,
    CONTINUE_WELCOME,
    ELIGIBILITY_CHECK,
    RESET_FORM,
    ELIGIBILITY_STATUS,
    METHA_STATUS,
    SEX_OFFENDER_STATUS
} = eligibilityConstants;

export const CheckYourEligibility = (state = initialState, action) => {
    switch (action.type) {
        case CONTINUE_WELCOME: {
            return {
                ...state,
                welcomeContinue: action.payload.welcomeContinue
            };
        }
        case ELIGIBILITY_CHECK: {
            return {
                ...state,
                eligibilityCheck: action.payload.eligibilityCheck
            };
        }
        case SAVE_FAMILY_INFO: {
            return {
                ...state,
                familyMember: action.payload.familyMember
            };
        }
        case SAVE_MONTHLY_INCOME: {
            return {
                ...state,
                monthlyIncome: action.payload.monthlyIncome
            };
        }
        case ELIGIBILITY_ACTIVE_INDEX: {
            return {
                ...state,
                activeStepIndex: action.payload
            };
        }
        case RESET_FORM: {
            return {
                ...initialState
            };
        }
        case METHA_STATUS: {
            return {
                ...state,
                methaStatus: action.payload
            };
        }
        case SEX_OFFENDER_STATUS: {
            return {
                ...state,
                sexOffenderStatus: action.payload
            };
        }
        case ELIGIBILITY_STATUS: {
            return {
                ...state,
                activeStepIndex: 7,
                eligibilityStatus: action.payload
            };
        }
        default:
            return state;
    }
};
