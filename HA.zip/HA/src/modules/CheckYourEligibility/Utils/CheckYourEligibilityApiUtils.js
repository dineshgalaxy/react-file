import { APIS } from '~/shared/constants/apisConstants';
import httpRequest, { METHODS } from '~/shared/utils/axios';

export const handleCheckEligibilityStatus = async (eligibility) => {
    const { familyMember, monthlyIncome } = eligibility;
    const reqParam = {
        family_members_id: familyMember,
        amount: monthlyIncome
    };
    const [response = {}, error] = await httpRequest({
        url: APIS.CHECK_ELIGIBILITY,
        method: METHODS.POST,
        body: reqParam
    });
    if (!error) {
        localStorage.setItem('family_members_id', familyMember)
        localStorage.setItem('amount', monthlyIncome)
        return response;
    }
};

export const fetchFamilyMemberList = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_FAMILY_MEMBER,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};
