import { noop } from '~/shared/utils/utils';
import { eligibilityStatusConstant, eligibilityStatusData } from './CheckYourEligibilityConstants';

export const getProgressValue = (activeIndex) => {
    return Math.ceil(16.6 * activeIndex);
};
export const getEligibilityStatusData = (eligibilityStatus, onExitClickFun, onSuccessClick) => {
    const eligibilityStatusRes = {
        Success: 1,
        Failed: 2,
        Questioned: 3
    }[eligibilityStatus];

    let onPrimaryClick = noop;
    if (eligibilityStatusRes === eligibilityStatusConstant.SUCCESS) {
        onPrimaryClick = onSuccessClick;
    } else if (eligibilityStatusRes === eligibilityStatusConstant.FAILED) {
        onPrimaryClick = onExitClickFun;
    } else {
        onPrimaryClick = onExitClickFun;
    }

    const data = eligibilityStatusData[eligibilityStatusRes];
    return {
        ...data,
        onPrimaryClick: onPrimaryClick
    };
};
