import { eligibilityConstants } from './CheckYourEligibilityConstants';
const {
    ELIGIBILITY_ACTIVE_INDEX,
    SAVE_FAMILY_INFO,
    SAVE_MONTHLY_INCOME,
    CONTINUE_WELCOME,
    ELIGIBILITY_CHECK,
    RESET_FORM,
    ELIGIBILITY_STATUS,
    SEX_OFFENDER_STATUS,
    METHA_STATUS
} = eligibilityConstants;

export const setActiveStepIndex = (payload) => {
    return {
        type: ELIGIBILITY_ACTIVE_INDEX,
        payload
    };
};
export const saveFamilyInfo = (payload) => {
    return {
        type: SAVE_FAMILY_INFO,
        payload
    };
};
export const continueWelcome = (payload) => {
    return {
        type: CONTINUE_WELCOME,
        payload
    };
};
export const continueEligibilityCheck = (payload) => {
    return {
        type: ELIGIBILITY_CHECK,
        payload
    };
};
export const saveMonthlyIncome = (payload) => {
    return {
        type: SAVE_MONTHLY_INCOME,
        payload
    };
};
export const resetForm = (payload) => {
    return {
        type: RESET_FORM,
        payload
    };
};
export const getEligibilityStatus = (payload) => {
    return {
        type: ELIGIBILITY_STATUS,
        payload
    };
};
export const getSexOffenderStatus = (payload) => {
    return {
        type: SEX_OFFENDER_STATUS,
        payload
    };
};
export const getMethaStatus = (payload) => {
    return {
        type: METHA_STATUS,
        payload
    };
};
