export const initialState = {
    activeStepIndex: 1,
    welcomeContinue: false,
    eligibilityCheck: false,
    familyMember: '',
    monthlyIncome: '',
    eligibilityStatus: 0,
    sexOffenderStatus: true,
    methaStatus: true
};
export const eligibilityConstants = {
    ELIGIBILITY_ACTIVE_INDEX: 'ELIGIBILITY_ACTIVE_INDEX',
    SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
    CONTINUE_WELCOME: 'CONTINUE_WELCOME',
    ELIGIBILITY_CHECK: 'ELIGIBILITY_CHECK',
    SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
    RESET_FORM: 'RESET_FORM',
    ELIGIBILITY_STATUS: 'ELIGIBILITY_STATUS',
    METHA_STATUS: 'METHA_STATUS',
    SEX_OFFENDER_STATUS: 'SEX_OFFENDER_STATUS'
};

export const STEPS = {
    STEP1: 1,
    STEP2: 2,
    STEP3: 3,
    STEP4: 4,
    STEP5: 5,
    STEP6: 6
};

export const eligibilityStatusConstant = {
    SUCCESS: 1,
    FAILED: 2,
    PENDING: 3
};

export const eligibilityStatusData = {
    [eligibilityStatusConstant.SUCCESS]: {
        iconName: 'thumbs-up',
        status: 'success',
        title: 'Good news! it looks like you may be a candidate for housing assistance.',
        subTitle:
            "Some copy about how if you'd like to continue, we'll need more information from you, including such and such, and will take about 30 minutes. Would you like to continue?",
        subTitle2: '',
        buttonText: 'Continue',
        linkText: 'Or Not Right now'
    },
    [eligibilityStatusConstant.FAILED]: {
        iconName: 'thumbs-down',
        status: 'failed',
        title: "It doesn't look like you're a candidate for assistance at this time.",
        subTitle:
            "Based on the information you entered, your household doesn't meet the criteria for our housing assistance program. if you'd like to read more about eligibility requirement, you can visit our help Section, or contact us for more information.",
        subTitle2: '',
        buttonText: 'Exit',
        linkText: 'Or Try Again'
    },
    [eligibilityStatusConstant.PENDING]: {
        iconName: 'alert-triangle',
        status: 'pending',
        title: 'You may or may not be a candidate based on your income.',
        subTitle:
            'Your monthly income looks like it might be too high to be eligible for assistance, but only by a small amount.',
        subTitle2:
            "In some situations, individuals may still be able to quality. if you'd like to find out for sure, you may continue anyway, or contact our office to speak with a representative about your eligibility.",
        buttonText: 'Exit',
        linkText: 'Or Continue Anyway'
    }
};
