import { Box, Button, Container, Dialog } from '@material-ui/core';
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { ChevronRight, Info } from 'react-feather';
import ExitDialogBox from '~/shared/components/ExitDialogBox';

/**
 * Name: HouseholdDetails
 * Desc: Render HouseholdDetails
 */

const HouseholdDetails = ({ onExitClick }) => {
    const [openDialog, setOpenDialog] = useState(false);
    const handleClose = () => {
        setOpenDialog(false);
    };

    return (
        <Container>
            <Box margin="20px auto" maxWidth="960px">
                <Box mb={6}>
                    <Box display="flex" alignItems="center" mb={1}>
                        <Box mr={1} display="flex">
                            <Info color="Indigo" size={21} />
                        </Box>
                        <Box
                            color="primary.light"
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.medium">
                            Counting Members
                        </Box>
                    </Box>
                    <Box color="primary.extraLight" fontSize="md.fontSize">
                        Household Members refers to anyone living in the household including
                        yourself, spouses, minor or adult children, foster children, and live-in
                        aids.
                    </Box>
                </Box>
                <Box display="flex" justifyContent="flex-end" pb={18}>
                    <Button
                        style={{
                            color: 'Indigo',
                            fontSize: '15px'
                        }}
                        size="medium"
                        className="linkBtn"
                        endIcon={<ChevronRight color="Indigo" size={14} />}
                        onClick={() => {
                            setOpenDialog(true);
                        }}>
                        EXIT
                    </Button>
                </Box>
                <Dialog
                    onClose={handleClose}
                    aria-labelledby="simple-dialog-title"
                    open={openDialog}>
                    <ExitDialogBox onClose={handleClose} onConfirm={onExitClick} />
                </Dialog>
            </Box>
        </Container>
    );
};
HouseholdDetails.propTypes = {
    width: PropTypes.string,
    onExitClick: PropTypes.func
};

export default HouseholdDetails;
