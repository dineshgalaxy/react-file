import { Box, Button, Container, Dialog } from '@material-ui/core';
import PropTypes from 'prop-types';
import React, { useState } from 'react';
import { ChevronRight, Info } from 'react-feather';
import ExitDialogBox from '~/shared/components/ExitDialogBox';

/**
 * Name: HouseholdIncome
 * Desc: Render HouseholdIncome
 */

const HouseholdIncome = ({ onExitClick }) => {
    const [openDialog, setOpenDialog] = useState(false);
    const handleClose = () => {
        setOpenDialog(false);
    };
    return (
        <Container>
            <Box margin="24px auto" maxWidth="960px">
                <Box mb={6}>
                    <Box display="flex" alignItems="center" mb={1}>
                        <Box mr={1} display="flex">
                            <Info color="Indigo" size={21} />
                        </Box>
                        <Box
                            color="primary.light"
                            fontSize="h5.fontSize"
                            fontFamily="fontFamily.medium">
                            Calculating Income
                        </Box>
                    </Box>
                    <Box color="primary.extraLight" fontSize="md.fontSize" mb={1.5}>
                        Annual Income includes all amounts, monetary or not, that :
                    </Box>
                    <Box color="primary.extraLight" fontSize="md.fontSize" mb={1}>
                        (1) Belong to family members
                    </Box>
                    <Box color="primary.extraLight" fontSize="md.fontSize" mb={1}>
                        (2) Are anticipated to be received by the family
                    </Box>
                    <Box color="primary.extraLight" fontSize="md.fontSize" mb={1}>
                        (3) Are derived from assets to which any member of the family has access
                    </Box>
                    <Box color="primary.extraLight" fontSize="md.fontSize" mb={1}>
                        (4) Are received for children in the household
                    </Box>
                    <Box color="primary.extraLight" fontSize="md.fontSize" mb={1}>
                        (5) Including Social Security benefits
                    </Box>
                </Box>
                <Box display="flex" justifyContent="flex-end" pb={2}>
                    <Button
                        style={{
                            color: 'Indigo',
                            fontSize: '15px'
                        }}
                        size="medium"
                        className="linkBtn"
                        endIcon={<ChevronRight color="Indigo" size={14} />}
                        onClick={() => {
                            setOpenDialog(true);
                        }}>
                        EXIT
                    </Button>
                </Box>
                <Dialog
                    onClose={handleClose}
                    aria-labelledby="simple-dialog-title"
                    open={openDialog}>
                    <ExitDialogBox onClose={handleClose} onConfirm={onExitClick} />
                </Dialog>
            </Box>
        </Container>
    );
};
HouseholdIncome.propTypes = {
    width: PropTypes.string,
    onExitClick: PropTypes.func
};

export default HouseholdIncome;
