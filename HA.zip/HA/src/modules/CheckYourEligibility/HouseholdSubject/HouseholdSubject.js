import { Box, Button, FormControl, FormControlLabel, Radio, RadioGroup } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React  from 'react';
import { useDispatch, useSelector } from 'react-redux';
import useStyles from './HouseholdComponentsStyles';
import { getMethaStatus,getSexOffenderStatus } from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityAction';

/**
 * Name : HouseholdSubject
 * Desc : Render HouseholdSubject
 */

const HouseholdSubject = ({ width, title ,onClickContinue, step}) => {
    const dispatch = useDispatch();
    const classes = useStyles();
    const { methaStatus , sexOffenderStatus} = useSelector(
        (state) => state.checkEligibility
    );

    const renderMetaRadio = ()=>{
        return(
            <RadioGroup
            defaultValue={methaStatus}
            aria-label="proxy"
            name="customized-radios">
            <Box mb={2}>
                <FormControlLabel
                    value={true}
                    checked={methaStatus}
                    onChange={()=>{dispatch(getMethaStatus(true))}}
                    control={<Radio className="extraLightLabel" />}
                    label="Yes"
                />
            </Box>
            <FormControlLabel
                value={false}
                checked={!methaStatus}
                onChange={()=>{dispatch(getMethaStatus(false))}}
                control={<Radio className="extraLightLabel" />}
                label="No"
            />
        </RadioGroup>
        )
    }

    const renderSexOffenderRadio = ()=>{
        return(
            <RadioGroup
            defaultValue={sexOffenderStatus}
            aria-label="proxy"
            name="customized-radios">
            <Box mb={2}>
                <FormControlLabel
                    value={true}
                    checked={sexOffenderStatus}
                    onChange={()=>{dispatch(getSexOffenderStatus(true))}}
                    control={<Radio className="extraLightLabel" />}
                    label="Yes"
                />
            </Box>
            <FormControlLabel
                value={false}
                checked={!sexOffenderStatus}
                onChange={()=>{dispatch(getSexOffenderStatus(false))}}
                control={<Radio className="extraLightLabel" />}
                label="No"
            />
        </RadioGroup>
        )
    }


    return (
        <Box className={classes.flex} width="100%">
        <Box
            fontSize="h5.fontSize"
            lineHeight="35px"
            color="primary.light"
            mb={6.75}
            maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337}>
            {title}
        </Box>
        <Box className={classes.formWidth} width="100%">
            <Box pb={3}>
                <FormControl component="fieldset">
                  {step === 3 ? renderSexOffenderRadio() : renderMetaRadio()} 
                </FormControl>
            </Box>
            <Box className={classes.xsBtn}>
                <Button
                    type="submit"
                    size="large"
                    color="primary"
                    variant="contained"
                    fullWidth={width === 'xs' || width === 'sm' ? true : false}
                    onClick={onClickContinue}
                    className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                    Next
                </Button>
            </Box>
        </Box>
    </Box>
    )
};

HouseholdSubject.propTypes = {
    width: PropTypes.string,
    title: PropTypes.string,
    onClickContinue: PropTypes.func,
    step: PropTypes.number
};
export default withWidth()(HouseholdSubject);

