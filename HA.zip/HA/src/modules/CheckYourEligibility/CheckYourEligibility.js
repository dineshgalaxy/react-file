import { Box, LinearProgress, Card } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Router from 'next/router';
import PropTypes from 'prop-types';
import { useEffect, useMemo, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import BudgetCardInfo from '~/modules/CheckYourEligibility/BudgetCardInfo';
import FamilyInfoCard from '~/modules/CheckYourEligibility/FamilyInfoCard';
import {
    continueEligibilityCheck,
    continueWelcome,
    getEligibilityStatus,
    setActiveStepIndex
} from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityAction';
import {
    fetchFamilyMemberList,
    handleCheckEligibilityStatus
} from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityApiUtils';
import { STEPS } from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityConstants';
import {
    getEligibilityStatusData,
    getProgressValue
} from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityUtils';
import CommonCard from '~/shared/components/CommonCard';
import TopHeader from '~/shared/components/Header/TopHeader';
import withLoader from '~/shared/components/hoc/withLoader';
import InformationCard from '~/shared/components/InformationCard';
import StatusCard from '~/shared/components/StatusCard';
import WizardHeader from '~/shared/components/WizardHeader';
import { ROUTES } from '~/shared/constants/routesConstants';
import HouseholdDetails from './HouseholdDetails';
import HouseholdIncome from './HouseholdIncome';
import HouseholdSubject from './HouseholdSubject';
import ExitConfirmation from '~/shared/components/ExitConfirmation';

/**
 * Render CheckYourEligibility
 */

const useStyles = makeStyles((theme) => ({
    boxInfo: {
        position: 'relative',
        paddingLeft: theme.spacing(2),
        paddingBottom: theme.spacing(0.4),
        '&:before': {
            content: '""',
            width: '4px',
            height: '4px',
            background: theme.palette.primary.extraLight,
            position: 'absolute',
            left: '0',
            top: '10px',
            borderRadius: '50%'
        }
    }
}));

const CheckYourEligibility = ({ setLoading }) => {
    const { HOME, CREATE_PROFILE } = ROUTES;
    const { STEP1, STEP2, STEP3, STEP4, STEP5, STEP6 } = STEPS;
    const dispatch = useDispatch();
    const [familyMemberList, setFamilyMemberList] = useState([]);
    const [width, setWidth] = useState(window.innerWidth);
    const classes = useStyles();
    const { activeStepIndex, eligibilityStatus, methaStatus, sexOffenderStatus, ...restValue } =
        useSelector((state) => state.checkEligibility);

    useEffect(() => {
        (async () => {
            const { res_data: { data = [] } = {} } = await fetchFamilyMemberList();
            setFamilyMemberList(data);
        })(); //Self-Invoking Functions
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleExitClick = () => {
        Router.push(HOME.ROUTE);
    };

    const handleSuccessClick = () => {
        Router.push(CREATE_PROFILE.ROUTE);
    };

    const { buttonText, iconName, linkText, status, subTitle, subTitle2, title, onPrimaryClick } =
        useMemo(
            () => getEligibilityStatusData(eligibilityStatus, handleExitClick, handleSuccessClick),
            // eslint-disable-next-line react-hooks/exhaustive-deps
            [eligibilityStatus]
        );

    const handleNext = async ({ ...data }) => {
        setLoading(true);
        const { res_data: { status_code: statusCode = '', message = '' } = {} } =
            await handleCheckEligibilityStatus({
                ...restValue,
                ...data
            });
        if (statusCode === 200) {
            dispatch(getEligibilityStatus(message));
            setLoading(false);
            return true;
        }
    };

    const handleClickContinue = async (fn, { ...data }) => {
        dispatch(fn({ ...data }));
        if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        } else {
            handleNext(data);
        }
    };

    const stepOne = activeStepIndex === STEP1;
    const stepTwo = activeStepIndex === STEP2;
    const stepThree = activeStepIndex === STEP3;
    const stepFour = activeStepIndex === STEP4;
    const stepFive = activeStepIndex === STEP5;
    const stepSix = activeStepIndex === STEP6;

    const handleClickBack = () => {
        if (activeStepIndex !== STEP1) {
            if (sexOffenderStatus && activeStepIndex === 7) {
                dispatch(setActiveStepIndex(activeStepIndex - STEP4));
            } else if (methaStatus && activeStepIndex === 7) {
                dispatch(setActiveStepIndex(activeStepIndex - STEP3));
            } else {
                dispatch(setActiveStepIndex(activeStepIndex - STEP1));
            }
        } else {
            Router.push(HOME.ROUTE);
        }
    };

    const handleRadioBtnContinue = () => {
        if (methaStatus && stepFour) {
            dispatch(getEligibilityStatus('Failed'));
        } else if (sexOffenderStatus && stepThree) {
            dispatch(getEligibilityStatus('Failed'));
        } else if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
            getEligibilityStatusData(2, handleExitClick, handleSuccessClick);
        }
    };

    function handleWindowSizeChange() {
        setWidth(window.innerWidth);
    }

    useEffect(() => {
        window.addEventListener('resize', handleWindowSizeChange); //todo : add custom hook for this
        return () => {
            window.removeEventListener('resize', handleWindowSizeChange);
        };
    }, []);

    let isMobile = width <= 1024;

    return (
        <Box>
            {activeStepIndex <= Object.keys(STEPS).length ? (
                <>
                    {!isMobile && (
                        <TopHeader
                            isWizard={true}
                            onExitClick={handleExitClick}
                            onClickBack={handleClickBack}
                        />
                    )}
                    <LinearProgress
                        variant="determinate"
                        value={getProgressValue(activeStepIndex)}
                    />
                </>
            ) : null}

            {stepOne ? (
                <CommonCard
                    onClickBack={handleClickBack}
                    bgScreen="welcome"
                    backBtnColor="backBtnWhite"
                    pageView="full">
                    <StatusCard
                        title="Let’s Get Started"
                        subTitle="Thanks for taking the first step in accessing more affordable housing through HACEP’s assistance programs. Let’s get you started."
                        showImage
                        showButton
                        onClickContinue={() =>
                            handleClickContinue(continueWelcome, {
                                welcomeContinue: true
                            })
                        }
                    />
                </CommonCard>
            ) : null}
            {stepTwo ? (
                <>
                    <WizardHeader onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack} bgColor="primary">
                        <InformationCard
                            title="First, we’ll find out if you may be a candidate."
                            onClickContinue={() => {
                                handleClickContinue(continueEligibilityCheck, {
                                    eligibilityCheck: true
                                });
                            }}
                            content={
                                <>
                                    <Box
                                        fontSize="h6.fontSize"
                                        color="primary.extraLight"
                                        lineHeight="26px"
                                        mb={2.5}>
                                        In order to determine for which programs you’re eligible to
                                        apply, we’ll guide you through entering some basic
                                        information, including:
                                    </Box>
                                    <Card>
                                        <Box
                                            px={3}
                                            py={3.5}
                                            color="primary.extraLight"
                                            fontSize="h6.fontSize">
                                            {[
                                                'Sex offender Details',
                                                'Meth Amphetamine Details',
                                                'Your household size',
                                                'Your household income'
                                            ].map((item, index) => (
                                                <Box
                                                    key={`${item}_${index}`}
                                                    className={classes.boxInfo}>
                                                    {item}
                                                </Box>
                                            ))}
                                        </Box>
                                    </Card>
                                    ]
                                </>
                            }
                        />
                    </CommonCard>
                </>
            ) : null}
            {stepThree ? (
                <>
                    <WizardHeader title="History" onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack}>
                        <HouseholdSubject
                            title="Is any member of your household subject to a lifetime sex offender registration?"
                            step={3}
                            onClickContinue={handleRadioBtnContinue}
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick}/>
                    {/* <ExitConfirmation isExitText={true} exitText="EXIT" /> */}
                </>
            ) : null}

            {stepFour ? (
                <>
                    <WizardHeader title="History" onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack}>
                        <HouseholdSubject
                            title="Has any member of your household been convicted of manufacturing methamphetamine on the premises of federally assisted housing?"
                            step={4}
                            onClickContinue={handleRadioBtnContinue}
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick}/>
                </>
            ) : null}
            {stepFive ? (
                <>
                    <WizardHeader onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack}>
                        <FamilyInfoCard
                            familyMemberList={familyMemberList}
                            title="How many total members are in the household, including any children?"
                            onClickContinue={handleClickContinue}
                        />
                    </CommonCard>
                    <HouseholdDetails onExitClick={handleExitClick} />
                </>
            ) : null}
            {stepSix ? (
                <>
                    <WizardHeader onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack}>
                        <BudgetCardInfo
                            title="What is the combined monthly income of all household members?"
                            onClickContinue={handleClickContinue}
                        />
                    </CommonCard>
                    <HouseholdIncome onExitClick={handleExitClick} />
                </>
            ) : null}
            {activeStepIndex > Object.keys(STEPS).length ? (
                <CommonCard
                    onClickBack={handleClickBack}
                    bgScreen="welcome"
                    backBtnColor="backBtnWhite"
                    pageView="full">
                    <StatusCard
                        iconName={iconName}
                        iconStatus={status}
                        title={title}
                        subTitle={subTitle}
                        showHeader={false}
                        showLink={true}
                        showButton
                        buttonText={buttonText}
                        linkText={linkText}
                        subTitle2={subTitle2}
                        onExitClick={handleExitClick}
                        onClickContinue={onPrimaryClick}
                    />
                </CommonCard>
            ) : null}
        </Box>
    );
};

CheckYourEligibility.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(CheckYourEligibility);