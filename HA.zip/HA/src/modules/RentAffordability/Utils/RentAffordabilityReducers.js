import { rentAffordabilityConstants, initialState } from './RentAffordabilityConstants';

const {
    RENT_AFFORDABILITY_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    RENT_AFFORDABILITY_CHECK,
    RESET_FORM,
    RENT_AFFORDABILITY_STATUS
} = rentAffordabilityConstants;

export const RentAffordability = (state = initialState, action) => {
    switch (action.type) {
        case CONTINUE_WELCOME: {
            return {
                ...state,
                welcomeContinue: action.payload.welcomeContinue
            };
        }
        case RENT_AFFORDABILITY_CHECK: {
            return {
                ...state,
                rentAffordabilityCheck: action.payload.rentAffordabilityCheck
            };
        }
        case RENT_AFFORDABILITY_ACTIVE_INDEX: {
            return {
                ...state,
                activeStepIndex: action.payload
            };
        }
        case RESET_FORM: {
            return {
                ...initialState
            };
        }
        case RENT_AFFORDABILITY_STATUS: {
            return {
                ...state,
                activeStepIndex: 5,
                rentAffordabilityStatus: action.payload
            };
        }
        default:
            return state;
    }
};
