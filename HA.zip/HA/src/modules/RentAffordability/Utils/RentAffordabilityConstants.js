export const initialState = {
    activeStepIndex: 1,
    welcomeContinue: false,
    rentAffordabilityCheck: false,
    reviewStatus: 0
};
export const rentAffordabilityConstants = {
    RENT_AFFORDABILITY_ACTIVE_INDEX: 'RENT_AFFORDABILITY_ACTIVE_INDEX',
    SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
    CONTINUE_WELCOME: 'CONTINUE_WELCOME',
    RENT_AFFORDABILITY_CHECK: 'RENT_AFFORDABILITY_CHECK',
    SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
    RESET_FORM: 'RESET_FORM',
    RENT_AFFORDABILITY_STATUS: 'RENT_AFFORDABILITY_STATUS'
};

export const STEPS = {
    STEP1: 1,
    STEP2: 2
};

export const rentAffordabilityStatusConstant = {
    SUCCESS: 1,
    FAILED: 2,
    PENDING: 3
};

export const rentAffordabilityStatusData = {
};
