import { noop } from '~/shared/utils/utils';
import { rentAffordabilityStatusConstant, rentAffordabilityStatusData } from './RentAffordabilityConstants';

export const getProgressValue = (activeIndex) => {
    return 33.333333333 * activeIndex;
};
export const getRentAffordabilityStatusData = (rentAffordabilityStatus, onExitClickFun, onSuccessClick) => {
    const rentAffordabilityStatusRes = {
        Success: 1,
        Failed: 2,
        Questioned: 3
    }[rentAffordabilityStatus];

    let onPrimaryClick = noop;
    if (rentAffordabilityStatusRes === rentAffordabilityStatusConstant.SUCCESS) {
        onPrimaryClick = onSuccessClick;
    } else if (rentAffordabilityStatusRes === rentAffordabilityStatusConstant.FAILED) {
        onPrimaryClick = onExitClickFun;
    } else {
        onPrimaryClick = onExitClickFun;
    }

    const data = rentAffordabilityStatusData[rentAffordabilityStatusRes];
    return {
        ...data,
        onPrimaryClick: onPrimaryClick
    };
};
