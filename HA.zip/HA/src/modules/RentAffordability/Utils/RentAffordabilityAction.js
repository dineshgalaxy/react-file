import { rentAffordabilityConstants } from './RentAffordabilityConstants';
const {
    RENT_AFFORDABILITY_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    RENT_AFFORDABILITY_CHECK,
    RESET_FORM,
} = rentAffordabilityConstants;

export const setActiveStepIndex = (payload) => {
    return {
        type: RENT_AFFORDABILITY_ACTIVE_INDEX,
        payload
    };
};

export const continueWelcome = (payload) => {
    return {
        type: CONTINUE_WELCOME,
        payload
    };
};
export const continueRentAffordability= (payload) => {
    return {
        type: RENT_AFFORDABILITY_CHECK,
        payload
    };
};
export const resetForm = (payload) => {
    return {
        type: RESET_FORM,
        payload
    };
};

