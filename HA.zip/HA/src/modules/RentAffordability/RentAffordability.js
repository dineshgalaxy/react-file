import { Box, LinearProgress } from '@material-ui/core';
import Router from 'next/router';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    continueRentAffordability,
    setActiveStepIndex
} from '~/modules/RentAffordability/Utils/RentAffordabilityAction';
import { STEPS } from '~/modules/RentAffordability/Utils/RentAffordabilityConstants';
import {
    getProgressValue
} from '~/modules/RentAffordability/Utils/RentAffordabilityUtils';
import CommonCard from '~/shared/components/CommonCard';
import StatusCard from 'shared/components/StatusCard';
import TopHeader from '~/shared/components/Header/TopHeader';
import withLoader from '~/shared/components/hoc/withLoader';
import InformationCard from '~/shared/components/InformationCard';
import WizardHeader from '~/shared/components/WizardHeader';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import { ROUTES } from '~/shared/constants/routesConstants';
import RentAffordabilityCalculator from '~/shared/components/HouseholdComponents/RentAffordabilityCalculator/RentAffordabilityCalculator';

/**
 * Render RentAffordability
 */
const pageTitle = 'Rent Affordability';

const RentAffordability = () => {
    const { HOME, YOUR_DOCUMENTS } = ROUTES;
    const { STEP1, STEP2, STEP3 } = STEPS;
    const dispatch = useDispatch();
    const [width, setWidth] = useState(window.innerWidth);
    const { activeStepIndex } = useSelector(
        (state) => state.rentAffordability
    );

    const handleExitClick = () => {
        Router.push(HOME.ROUTE);
    };

    const handleClickContinue = async (fn, { ...data }) => {
        dispatch(fn({ ...data }));
        if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        } else {
            Router.push(YOUR_DOCUMENTS.ROUTE);
        }
    };

    const handleClickBack = () => {
        if (activeStepIndex !== STEP1) {
            dispatch(setActiveStepIndex(activeStepIndex - 1));
        } else {
            Router.push(HOME.ROUTE);
        }
    };

    function handleWindowSizeChange() {
        setWidth(window.innerWidth);
    }
    useEffect(() => {
        window.addEventListener('resize', handleWindowSizeChange); //todo : add custom hook for this
        return () => {
            window.removeEventListener('resize', handleWindowSizeChange);
        };
    }, []);

    let isMobile = width <= 1024;

    return (

        <Box>
            {activeStepIndex <= Object.keys(STEPS).length ? (
                <>
                    {!isMobile && (
                        <TopHeader
                            title={pageTitle}
                            isWizard={true}
                            onExitClick={handleExitClick}
                            onClickBack={handleClickBack}
                        />
                    )}
                    <LinearProgress
                        variant="determinate"
                        value={getProgressValue(activeStepIndex)}
                    />
                </>
            ) : null}

            { activeStepIndex === STEP1 ? (
                <>
                    <CommonCard pageView="full" bgColor="primary" onClickBack={handleClickBack} >
                        <InformationCard
                            title="Your Rent Affordability"
                            subTitle="In order to determine what rent you can afford, we’ll calculate an estimated based on some of your information."
                            onClickContinue={() =>
                                handleClickContinue(continueRentAffordability, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                </>
            ) : null}
            {activeStepIndex === STEP2 ? (
                <>
                    <WizardHeader title="Affordability" />
                    <CommonCard onClickBack={handleClickBack}>
                        <RentAffordabilityCalculator
                            title="Complete the information below to calculate your rent affordability estimate."
                            onClickContinue={() =>
                                handleClickContinue(continueRentAffordability, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                    <Box mt={-5}>
                        <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                    </Box>
                </>
            ) : null}
            {activeStepIndex === STEP3 ? (
                <>
                    <CommonCard
                        bgScreen={'welcome'}
                        backBtnColor="backBtnWhite"
                        pageView="full"
                        onClickBack={handleClickBack}>
                        <StatusCard
                            title="Here’s your rent affordability estimate."
                            iconName="dollar-sign"
                            iconStatus="success"
                            iconColor="indigo"
                            subTitle={
                                <Box pt={1} pb={1} fontFamily="fontFamily.regular" lineHeight="26px"> 
                                   Based on your information, we estimate that you can afford <Box component="span" fontFamily="fontFamily.bold"> up to $550 per month </Box> in rent. You can use that range as a guide when you explore available units and discuss what you can afford with potential landlords. 
                                </Box>
                            }
                            onClickContinue={() =>
                                handleClickContinue(continueRentAffordability, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                </>
            ) : null}
        </Box>
    );
};

RentAffordability.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(RentAffordability);
