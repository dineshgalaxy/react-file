import PropTypes from 'prop-types';
import Router from 'next/router';
import withLoader from '~/shared/components/hoc/withLoader';
import LoginForm from '~/shared/components/LoginForm';
import { ROUTES } from '~/shared/constants/routesConstants';

import { useDispatch } from 'react-redux';

import {
    getLoginStatus
} from '~/modules/LoginModule/Utils/LoginAction';
import {
    handleLoggedIn
} from '~/modules/LoginModule/Utils/LoginApiUtils';

/**
 * Render CreateProfileModule
 * @param {func} setLoading
 * @returns Component
 */

const LoginModule = ({ setLoading }) => {
    const { CREATE_PROFILE } = ROUTES;
    const dispatch = useDispatch();

    const handleClickContinue = async ({ ...data }) => {
        setLoading(true);
        const { res_data: { status_code: statusCode = '', message = '' } = {} } =
            await handleLoggedIn ({ ...data });

        if (statusCode === 200) {
            dispatch(getLoginStatus(message));
            setLoading(false);
            return true;
        }
    };

    const handleSignUP = async () => {
        Router.push(CREATE_PROFILE?.ROUTE);
    }

    return (
        <>
            <LoginForm 
                title="Log in"
                subTitle="Enter your saved email and password used to create your account."
                forgotPasswordText="Forgot your password?"
                onClickContinue={handleClickContinue}
                onClickSignUP={handleSignUP}
                showLoginWithFacebook={false}
            />
        </>
    );
};

LoginModule.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(LoginModule);
