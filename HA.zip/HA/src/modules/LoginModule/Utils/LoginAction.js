import { loginConstants } from './LoginConstants';
const { LOGIN_STATUS } = loginConstants;

export const getLoginStatus = (payload) => {
    return {
        type: LOGIN_STATUS,
        payload
    };
};