import { initialState, loginConstants } from './LoginConstants';
const { RESET_FORM } = loginConstants;

export const Login = (state = initialState, action) => {
    switch (action.type) {
        case RESET_FORM: {
            return {
                ...initialState
            };
        }
        default:
            return state;
    }
};
