export const loginConstants = {
    RESET_FORM: 'RESET_FORM',
    LOGIN_STATUS: 'LOGIN_STATUS',
};
