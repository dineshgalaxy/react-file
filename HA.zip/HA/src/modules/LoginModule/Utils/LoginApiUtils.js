import { APIS } from '~/shared/constants/apisConstants';
import httpRequest, { METHODS } from '~/shared/utils/axios';

export const handleLoggedIn = async (requestBody = {}) => {
    const [response = {}, error] = await httpRequest({
        url: APIS.LOGIN_URL,
        method: METHODS.POST,
        body: requestBody
    });
    if (!error) {
        return response;
    }
};
