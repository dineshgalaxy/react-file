export const initialState = {
    activeStepIndex: 1,
    welcomeContinue: false,
    reviewCheck: false,
    familyMember: '',
    monthlyIncome: '',
    reviewStatus: 0
};
export const reviewConstants = {
    REVIEW_ACTIVE_INDEX: 'REVIEW_ACTIVE_INDEX',
    SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
    CONTINUE_WELCOME: 'CONTINUE_WELCOME',
    REVIEW_CHECK: 'REVIEW_CHECK',
    SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
    RESET_FORM: 'RESET_FORM',
    REVIEW_STATUS: 'REVIEW_STATUS'
};

export const STEPS = {
    STEP1: 1,
    STEP2: 2,
    STEP3: 3,
    STEP4: 4,
    STEP5: 5,
    STEP6: 6,
    STEP7: 7,
    STEP8: 8,
    STEP9: 9
};

export const reviewStatusConstant = {
    SUCCESS: 1,
    FAILED: 2,
    PENDING: 3
};

export const reviewStatusData = {
};
