import { reviewConstants } from './ReviewApplicationConstants';
const {
    REVIEW_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    REVIEW_CHECK,
    RESET_FORM,
} = reviewConstants;

export const setActiveStepIndex = (payload) => {
    return {
        type: REVIEW_ACTIVE_INDEX,
        payload
    };
};

export const continueWelcome = (payload) => {
    return {
        type: CONTINUE_WELCOME,
        payload
    };
};
export const continueReview= (payload) => {
    return {
        type: REVIEW_CHECK,
        payload
    };
};
export const resetForm = (payload) => {
    return {
        type: RESET_FORM,
        payload
    };
};

