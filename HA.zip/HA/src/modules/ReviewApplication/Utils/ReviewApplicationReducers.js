import { reviewConstants, initialState } from './ReviewApplicationConstants';

const {
    REVIEW_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    REVIEW_CHECK,
    RESET_FORM,
    REVIEW_STATUS
} = reviewConstants;

export const ReviewApplication = (state = initialState, action) => {
    switch (action.type) {
        case CONTINUE_WELCOME: {
            return {
                ...state,
                welcomeContinue: action.payload.welcomeContinue
            };
        }
        case REVIEW_CHECK: {
            return {
                ...state,
                reviewCheck: action.payload.reviewCheck
            };
        }
        case REVIEW_ACTIVE_INDEX: {
            return {
                ...state,
                activeStepIndex: action.payload
            };
        }
        case RESET_FORM: {
            return {
                ...initialState
            };
        }
        case REVIEW_STATUS: {
            return {
                ...state,
                activeStepIndex: 5,
                reviewStatus: action.payload
            };
        }
        default:
            return state;
    }
};
