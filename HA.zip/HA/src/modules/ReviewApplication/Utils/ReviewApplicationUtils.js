import { noop } from '~/shared/utils/utils';
import { reviewStatusConstant, reviewStatusData } from './ReviewApplicationConstants';

export const getProgressValue = (activeIndex) => {
    return 11.111111111 * activeIndex;
};
export const getReviewStatusData = (reviewStatus, onExitClickFun, onSuccessClick) => {
    const reviewStatusRes = {
        Success: 1,
        Failed: 2,
        Questioned: 3
    }[reviewStatus];

    let onPrimaryClick = noop;
    if (reviewStatusRes === reviewStatusConstant.SUCCESS) {
        onPrimaryClick = onSuccessClick;
    } else if (reviewStatusRes === reviewStatusConstant.FAILED) {
        onPrimaryClick = onExitClickFun;
    } else {
        onPrimaryClick = onExitClickFun;
    }

    const data = reviewStatusData[reviewStatusRes];
    return {
        ...data,
        onPrimaryClick: onPrimaryClick
    };
};
