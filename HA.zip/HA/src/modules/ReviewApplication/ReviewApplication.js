import { Box, LinearProgress, Button, FormControl, FormControlLabel, Checkbox } from '@material-ui/core';
import Router from 'next/router';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ChevronRight, Info } from 'react-feather';
import {
    continueReview,
    setActiveStepIndex
} from '~/modules/ReviewApplication/Utils/ReviewApplicationAction';
import { STEPS } from '~/modules/ReviewApplication/Utils/ReviewApplicationConstants';
import {
    getProgressValue
} from '~/modules/ReviewApplication/Utils/ReviewApplicationUtils';
import CommonCard from '~/shared/components/CommonCard';
import TopHeader from '~/shared/components/Header/TopHeader';
import withLoader from '~/shared/components/hoc/withLoader';
import InformationCard from '~/shared/components/InformationCard';
import StatusCard from '~/shared/components/StatusCard';
import WizardHeader from '~/shared/components/WizardHeader';
import { ROUTES } from '~/shared/constants/routesConstants';
import ObjectCard from '~/shared/components/ObjectCard';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import ApplicationReview from '~/shared/components/ApplicationReview';
import HouseholdDocumentExpectations from '~/shared/components/HouseholdComponents/HouseholdDocumentExpectations';
import EmergencyContactSelect from '~/shared/components/HouseholdComponents/EmergencyContactSelect/EmergencyContactSelect';
import EmergencyContactDetails from '~/shared/components/HouseholdComponents/EmergencyContactDetails';
/**
 * Render ReviewApplication
 */
const pageTitle = 'Application Review';

const ReviewApplication = () => {
    const { HOME, HOUSEHOLD_INCOME } = ROUTES;
    const { STEP1, STEP2, STEP3, STEP4, STEP5 , STEP6, STEP7, STEP8, STEP9 } = STEPS;
    const dispatch = useDispatch();
    const [width, setWidth] = useState(window.innerWidth);
    const { activeStepIndex } = useSelector(
        (state) => state.reviewApplication
    );

    const handleExitClick = () => {
        Router.push(HOME.ROUTE);
    };

    const handleClickContinue = async (fn, { ...data }) => {
        dispatch(fn({ ...data }));
        if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        } else {
            Router.push(HOUSEHOLD_INCOME.ROUTE);
        }
    };

    const handleClickBack = () => {
        if (activeStepIndex !== STEP1) {
            dispatch(setActiveStepIndex(activeStepIndex - 1));
        } else {
            Router.push(HOME.ROUTE);
        }
    };

    function handleWindowSizeChange() {
        setWidth(window.innerWidth); 
    }
    useEffect(() => {
        window.addEventListener('resize', handleWindowSizeChange); //todo : add custom hook for this
        return () => {
            window.removeEventListener('resize', handleWindowSizeChange);
        };
    }, []);

    let isMobile = width <= 1024;

    return (

        <Box>
            {activeStepIndex <= Object.keys(STEPS).length ? (
                <>
                    {!isMobile && (
                        <TopHeader
                            title={pageTitle}
                            isWizard={true}
                            onExitClick={handleExitClick}
                            onClickBack={handleClickBack}
                        />
                    )}
                    <LinearProgress
                        variant="determinate"
                        value={getProgressValue(activeStepIndex)}
                    />
                </>
            ) : null}

            { activeStepIndex === STEP1 ? (
                    <CommonCard bgScreen={'welcome'} backBtnColor="backBtnWhite" isFullPage={true} onClickBack={handleClickBack} isStatusCard={true}>
                        <StatusCard
                            showButton={true}
                            title="Let’s begin your application."
                            subTitle={
                                <>
                                    You have been selected to apply for the Krupp (1BR) program.
                                    Your application will be due no later than{' '}
                                    <Box
                                        color="error.main"
                                        component="span"
                                        fontFamily="fontFamily.extraBold">
                                        January 15, 2022
                                    </Box>
                                    . Continue below to see more and start your application.
                                </>
                            }
                            showImage={true}
                            onClickContinue={() =>
                                handleClickContinue(continueReview, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
            ) : null}
            {activeStepIndex === STEP2 ? (
                <>
                    <CommonCard pageView="full" bgColor="primary" onClickBack={handleClickBack}>
                        <InformationCard
                            showImage={false}
                                textAlign="left"
                                title="For this application, you’ll need some information and documents."
                                subTitle="You’ll need to provide information about the identity, employment, and finances of all household members and minor children. To complete the application, you’ll also need to provide original scans of any corresponding documents, like:"
                                infoList={[
                                    'Social security cards',
                                    'Drivers’ license',
                                    'Bank statements',
                                    'Other financial information'
                                ]}
                                content="Takes about: 25 minutes"
                                subTitle2="If you need to return later to finish your application, you can save your progress and exit at any point."
                                btnTitle="Start Application"
                                onClickContinue={() => {
                                handleClickContinue(continueReview, {
                                    reviewCheck: true
                                });
                            }}
                        />
                    </CommonCard>
                </>
            ) : null}
            {activeStepIndex === STEP3 ? (
                <>
                    <CommonCard pageView="full" bgColor="primary" onClickBack={handleClickBack}>
                        <InformationCard
                            title="You and Your Household"
                            subTitle="In this section, we’ll ask some questions about you and your household members. Be sure to update any information that’s changed since your previous visits (e.g. births, divorces) that may change your eligibility for assistance."
                            onClickContinue={() => {
                                handleClickContinue(continueReview, {
                                    reviewCheck: true
                                });
                            }}
                        />
                    </CommonCard>
                </>
            ) : null}
            {activeStepIndex === STEP4 ? (
                <>
                    <WizardHeader  onClickBack={handleClickBack} >
                        <Box textAlign="center" mt={1.5}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}>
                                Review Your Household
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Review the details we have on file for your household. If
                                any members have changed, you may edit, remove, or add new
                                ones below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="transparent" backBtnColor="backBtnWhite" onClickBack={handleClickBack}>
                        <Box>
                            {[
                                { userName: 'Erika Alexander', type: 'Applicant' },
                                { userName: 'Carlos Alexander', type: 'Spouse' },
                                { userName: 'Lara Alexander', type: 'Child' }
                            ].map((item) => (
                                <Box mb={3} key={item.type}>
                                    <ObjectCard isMember = {true} >
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            {item.userName}
                                        </Box>
                                        <Box color="primary.light" fontSize="lg.fontSize">
                                            {item.type}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                            <Box
                                mb={6}
                                borderColor="primary.main"
                                border="1px dashed"
                                borderRadius="21px">
                                <ObjectCard cardType="actionCard" iconName="plus">
                                    <Box
                                        color="primary.main"
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium">
                                        Add Another Person
                                    </Box>
                                </ObjectCard>
                            </Box>
                            <Box display="flex" justifyContent="center">
                                <Button size="large" color="primary" variant="contained" onClick={() => {
                                handleClickContinue(continueReview, {
                                    reviewCheck: true
                                });
                            }}>
                                    Continue
                                </Button>
                            </Box>
                        </Box>
                        <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                    </CommonCard>
                </>
            ) : null}
            {activeStepIndex === STEP5 ? (
                <>
                    <WizardHeader  onClickBack={handleClickBack}>
                        <Box textAlign="center" pl={3} pr={3} pb={2} mt={-3}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}>
                                Review Your Pre-Application
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Review, edit, and confirm all of the information you’ve provided
                                below. If everything looks correct, click “confirm”.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="gray" onClickBack={handleClickBack}>
                        <ApplicationReview 
                            onNextButtonClick={() => {
                                handleClickContinue(continueReview, {
                                    reviewCheck: true
                                });
                            }}
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
            {activeStepIndex === STEP6 ? (
                <>
                    <WizardHeader title="Household" onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack}>
                        <HouseholdDocumentExpectations 
                            onNextButtonClick={() => {
                                handleClickContinue(continueReview, {
                                    reviewCheck: true
                                });
                            }}
                        />
                    </CommonCard>
                    <Box display="flex" justifyContent="center" pt={6} px={3}>
                        <Button
                            style={{
                                color: 'Indigo',
                                fontSize: '15px'
                            }}
                            size="medium"
                            className="linkBtn"
                            endIcon={<ChevronRight color="Indigo" size={14} />}>
                            Or Skip for Now
                        </Button>
                    </Box>
                    <Box maxWidth="1008px" margin="0 auto">
                        <Box mt={6.5} px={3} display="inline-block">
                            <Box display="flex" mb={1}>
                                <Box mr={1} mt={0.5} display="flex">
                                    <Info color="Indigo" size={21} />
                                </Box>
                                <Box
                                    color="primary.light"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium">
                                    Why do we need these documents?
                                </Box>
                            </Box>
                            <Box color="primary.extraLight" fontSize="md.fontSize" mb={2}>
                                Optional helper text from HACEP
                            </Box>
                        </Box>
                    </Box>
                </>
            ) : null}
            {activeStepIndex === STEP7 ? (
                <>
                    <WizardHeader titl="Add Firstname’s Documents" onClickBack={handleClickBack} >
                        <Box textAlign="center" mt={1.5}>
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Add Firstname’s Documents
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                At least one document from the list below is required for
                                Firstname. Click on the document you’d like to upload below
                                and follow the instructions.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="transparent" backBtnColor="backBtnWhite"  onClickBack={handleClickBack}>
                        <Box mb={-3}>
                            <Box mb={3}>
                                <ObjectCard isMember = {true}>
                                    <Box
                                        color="primary.main"
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium">
                                        Birth Certificate
                                    </Box>
                                    <Box color="primary.light" fontSize="lg.fontSize">
                                        for Firstname Lastname
                                    </Box>
                                </ObjectCard>
                            </Box>
                            {[
                                { documentName: 'Add License or State I.D.' },
                                { documentName: 'Add Social Security Card' }
                            ].map((item) => (
                                <Box
                                    key={item.documentName}
                                    mb={3}
                                    borderColor="primary.main"
                                    border="1px dashed"
                                    borderRadius="21px">
                                    <ObjectCard cardType="actionCard" iconName="plus">
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            {item.documentName}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                            <Box pt={2} pb={1.5}>
                                <FormControl fullWidth className="noMargin">
                                    <FormControlLabel
                                        control={
                                            <Checkbox
                                                inputProps={{
                                                    'aria-label': 'primary checkbox'
                                                }}
                                            />
                                        }
                                        label="Check this box if Firstname does not have any of these documents available."
                                    />
                                </FormControl>
                            </Box>
                        </Box>
                    </CommonCard>
                    <Box display="flex" justifyContent="center">
                        <Button 
                            size="large"
                            color="primary"
                            variant="contained"  
                            onClick={() => {
                                handleClickContinue(continueReview, {
                                    reviewCheck: true
                                });
                            }}
                        >
                            Finished Uploading
                        </Button>
                    </Box>
                    <Box display="flex" justifyContent="center">
                        <ExitConfirmation isExitText={true} exitText="Or Skip for Now" onExitClick={handleExitClick}/>
                    </Box>
                </>
            ) : null}
            {activeStepIndex === STEP8 ? (
                <>
                    <WizardHeader title="Household"  onClickBack={handleClickBack}/>
                    <CommonCard  onClickBack={handleClickBack}>
                        <EmergencyContactSelect 
                            title="Would you like to add an emergency contact person?"
                            onNextButtonClick={() => {
                                handleClickContinue(continueReview, {
                                    reviewCheck: true
                                });
                            }}
                        />
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <Box mt={6.5} px={3}>
                            <Box display="flex" mb={1}>
                                <Box mr={1} display="flex">
                                    <Info color="Indigo" size={21} />
                                </Box>
                                <Box
                                    color="primary.light"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium">
                                    About Emergency Contacts
                                </Box>
                            </Box>
                            <Box color="primary.extraLight" fontSize="md.fontSize">
                                As part of your application for housing, you have the right
                                by law to include the name, address, telephone number, and
                                other relevant information for a family member, a friend, or
                                an organization that offers social, health, advocacy, or
                                other support services. This contact information is for the
                                purpose of identifying a person or organization that may be
                                able to help in resolving issues that may arise during your
                                tenancy or to assist in providing needed special care or
                                services. You may update, remove, or change the information
                                that you provide on this form at any time. You are not
                                required to provide this contact information.
                            </Box>
                        </Box>
                        <ExitConfirmation isExitText={true}  onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                    </Box>
                </>
            ) : null}
            {activeStepIndex === STEP9 ? (
                <>
                    <WizardHeader title="Household" />
                    <CommonCard onClickBack={handleClickBack}>
                        <EmergencyContactDetails 
                            title="Enter your emergency contact person’s information below. They should be someone who does not live in the household." 
                            onNextButtonClick={() => {
                                handleClickContinue(continueReview, {
                                    reviewCheck: true
                                });
                            }}
                        />
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <Box mt={6.5} px={3}>
                            <Box display="flex" mb={1}>
                                <Box mr={1} mt={0.5} display="flex">
                                    <Info color="Indigo" size={21} />
                                </Box>
                                <Box
                                    color="primary.light"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium">
                                    About Emergency Contacts
                                </Box>
                            </Box>
                            <Box color="primary.extraLight" fontSize="md.fontSize">
                                As part of your application for housing, you have the right
                                by law to include the name, address, telephone number, and
                                other relevant information for a family member, a friend, or
                                an organization that offers social, health, advocacy, or
                                other support services. This contact information is for the
                                purpose of identifying a person or organization that may be
                                able to help in resolving issues that may arise during your
                                tenancy or to assist in providing needed special care or
                                services. You may update, remove, or change the information
                                that you provide on this form at any time. You are not
                                required to provide this contact information.
                            </Box>
                        </Box>
                    </Box>
                </>
            ) : null}
        </Box>
    );
};

ReviewApplication.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(ReviewApplication);