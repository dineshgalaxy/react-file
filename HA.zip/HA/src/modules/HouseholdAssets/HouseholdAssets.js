import { Box, LinearProgress, Button } from '@material-ui/core';
import Router from 'next/router';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
    continueHouseholdAssets,
    setActiveStepIndex
} from '~/modules/HouseholdAssets/Utils/HouseholdAssetsAction';
import { STEPS } from '~/modules/HouseholdAssets/Utils/HouseholdAssetsConstants';
import {
    getProgressValue
} from '~/modules/HouseholdAssets/Utils/HouseholdAssetsUtils';
import CommonCard from '~/shared/components/CommonCard';
import TopHeader from '~/shared/components/Header/TopHeader';
import withLoader from '~/shared/components/hoc/withLoader';
import InformationCard from '~/shared/components/InformationCard';
import WizardHeader from '~/shared/components/WizardHeader';
import { ROUTES } from '~/shared/constants/routesConstants';
import ObjectCard from '~/shared/components/ObjectCard';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import HouseholdAssetSelection from '~/shared/components/HouseholdComponents/HouseholdAssetSelection';
import AssetDisposal from '~/shared/components/HouseholdComponents/AssetDisposal';
import AssetDetails from '~/shared/components/HouseholdComponents/AssetDetails';
/**
 * Render HouseholdAssets
 */
const pageTitle = 'Household Assets';

const HouseholdAssets = () => {
    const { HOME, HOUSEHOLD_SPECIAL_EXPENSES } = ROUTES;
    const { STEP1, STEP2, STEP3, STEP4, STEP5 , STEP6 } = STEPS;
    const dispatch = useDispatch();
    const [width, setWidth] = useState(window.innerWidth);
    const { activeStepIndex } = useSelector(
        (state) => state.householdAssets
    );

    const handleExitClick = () => {
        Router.push(HOME.ROUTE);
    };

    const handleClickContinue = async (fn, { ...data }) => {
        dispatch(fn({ ...data }));
        if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        } else {
            Router.push(HOUSEHOLD_SPECIAL_EXPENSES.ROUTE);
        }
    };

    const handleClickBack = () => {
        if (activeStepIndex !== STEP1) {
            dispatch(setActiveStepIndex(activeStepIndex - 1));
        } else {
            Router.push(HOME.ROUTE);
        }
    };

    function handleWindowSizeChange() {
        setWidth(window.innerWidth);
    }
    useEffect(() => {
        window.addEventListener('resize', handleWindowSizeChange); //todo : add custom hook for this
        return () => {
            window.removeEventListener('resize', handleWindowSizeChange);
        };
    }, []);

    let isMobile = width <= 1024;

    return (

        <Box>
            {activeStepIndex <= Object.keys(STEPS).length ? (
                <>
                    {!isMobile && (
                        <TopHeader
                            title={pageTitle}
                            isWizard={true}
                            onExitClick={handleExitClick}
                            onClickBack={handleClickBack}
                        />
                    )}
                    <LinearProgress
                        variant="determinate"
                        value={getProgressValue(activeStepIndex)}
                    />
                </>
            ) : null}

            { activeStepIndex === STEP1 ? (
                <>
                    <CommonCard pageView="full" bgColor="primary" onClickBack={handleClickBack}>
                        <InformationCard
                            title="Your Household Assets"
                            subTitle="Next, we’ll ask you about other assets like bank accounts, real estate, and other income-producing assets."
                            onClickContinue={() =>
                                handleClickContinue(continueHouseholdAssets, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                </>
            ) : null}
            {activeStepIndex === STEP2 ? (
                <>
                    <WizardHeader title="Assets" />
                    <CommonCard onClickBack={handleClickBack} >
                        <HouseholdAssetSelection
                            onClickContinue={() =>
                                handleClickContinue(continueHouseholdAssets, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                    </Box>
                </>
            ) : null}
            {activeStepIndex === STEP3 ? (
                <>
                    <WizardHeader title="Assets" />
                    <CommonCard onClickBack={handleClickBack} >
                        <AssetDisposal 
                            onClickContinue={() =>
                                handleClickContinue(continueHouseholdAssets, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                    <Box maxWidth="1008px" margin="0 auto">
                        <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                    </Box>
                </>
            ) : null}
            {activeStepIndex === STEP4 ? (
                <>
                    <WizardHeader>
                        <Box textAlign="center">
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Add All Checking, Savings, or Money Market Accounts
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Add details for every checking, savings, or money market
                                account for all members of the household, including
                                yourself, until all are shown below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="transparent" backBtnColor="backBtnWhite"  onClickBack={handleClickBack}>
                        <Box>
                            {[
                                {
                                    userName:
                                        'Add Checking, Savings, or Money Market Account'
                                }
                            ].map((item) => (
                                <Box
                                    borderColor="primary.main"
                                    border="1px dashed"
                                    borderRadius="21px"
                                    key={item.type}>
                                    <ObjectCard cardType="objectCard" iconName="plus" showOptionMenu={false}
                                        onClick={() =>
                                            handleClickContinue(continueHouseholdAssets, {
                                                welcomeContinue: true
                                            })
                                        }
                                    >
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium"
                                            lineHeight="1.4">
                                            {item.userName}
                                        </Box>
                                        <Box color="primary.light" fontSize="lg.fontSize">
                                            {item.type}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                        </Box>
                    </CommonCard>
                    <Box mt={-5}>
                        <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                    </Box>
                    
                </>
            ) : null}
            {activeStepIndex === STEP5 ? (
                <>
                    <WizardHeader title="Assets" />
                    <CommonCard onClickBack={handleClickBack}>
                        <AssetDetails 
                            title="Enter all the information available for the account."
                            onClickContinue={() =>
                                handleClickContinue(continueHouseholdAssets, {
                                    welcomeContinue: true
                                })
                            }
                        />
                    </CommonCard>
                     <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
            {activeStepIndex === STEP6 ? (
                <>
                    <WizardHeader>
                        <Box textAlign="center">
                            <Box
                                fontSize="h3.fontSize"
                                color="common.white"
                                fontFamily="fontFamily.bold"
                                mb={2}
                                lineHeight="32px">
                                Continue Adding Checking, Savings, or Money Market Accounts
                            </Box>
                            <Box fontSize="h6.fontSize" color="common.white">
                                Add an employment source for every full or part-time job held by all members of the household until all jobs are shown below.
                            </Box>
                        </Box>
                    </WizardHeader>
                    <CommonCard bgColor="transparent" onClickBack={handleClickBack}>
                        <Box>
                            <Box mb={3}>
                                <ObjectCard iconName="dollar-sign">
                                    <Box
                                        color="primary.main"
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium">
                                        [Type of Account]
                                    </Box>
                                    <Box color="primary.light" fontSize="lg.fontSize">
                                        $500 at Chase Bank
                                    </Box>
                                </ObjectCard>
                            </Box>
                            {[{ documentName: 'Add Checking, Savings, or Money Market Account' }].map((item) => (
                                <Box
                                    key={item.documentName}
                                    mb={3}
                                    borderColor="primary.main"
                                    border="1px dashed"
                                    borderRadius="21px">
                                    <ObjectCard cardType="actionCard" iconName="box">
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium"
                                            lineHeight="24px">
                                            {item.documentName}
                                        </Box>
                                    </ObjectCard>
                                </Box>
                            ))}
                        </Box>
                    </CommonCard>
                    <Box display="flex" justifyContent="center">
                        <Button 
                            size="large"
                            color="primary"
                            variant="contained"
                            onClick={() =>
                                handleClickContinue(continueHouseholdAssets, {
                                    welcomeContinue: true
                                })
                            }
                        >
                            Finished Adding
                        </Button>
                    </Box>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} exitText="SAVE AND EXIT" />
                </>
            ) : null}
        </Box>
    );
};

HouseholdAssets.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(HouseholdAssets);
