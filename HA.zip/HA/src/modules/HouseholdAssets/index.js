export { default } from './HouseholdAssets';
