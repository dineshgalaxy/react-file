export const initialState = {
    activeStepIndex: 1,
    welcomeContinue: false,
    householdAssetsCheck: false,
    reviewStatus: 0
};
export const householdAssetsConstants = {
    HOUSEHOLD_ASSETS_ACTIVE_INDEX: 'HOUSEHOLD_ASSETS_ACTIVE_INDEX',
    SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
    CONTINUE_WELCOME: 'CONTINUE_WELCOME',
    HOUSEHOLD_ASSETS_CHECK: 'HOUSEHOLD_ASSETS_CHECK',
    SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
    RESET_FORM: 'RESET_FORM',
    HOUSEHOLD_ASSETS_STATUS: 'HOUSEHOLD_ASSETS_STATUS'
};

export const STEPS = {
    STEP1: 1,
    STEP2: 2,
    STEP3: 3,
    STEP4: 4,
    STEP5: 5,
    STEP6: 6
};

export const householdAssetsStatusConstant = {
    SUCCESS: 1,
    FAILED: 2,
    PENDING: 3
};

export const householdAssetsStatusData = {
};
