import { householdAssetsConstants } from './HouseholdAssetsConstants';
const {
    HOUSEHOLD_ASSETS_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    HOUSEHOLD_ASSETS_CHECK,
    RESET_FORM,
} = householdAssetsConstants;

export const setActiveStepIndex = (payload) => {
    return {
        type: HOUSEHOLD_ASSETS_ACTIVE_INDEX,
        payload
    };
};

export const continueWelcome = (payload) => {
    return {
        type: CONTINUE_WELCOME,
        payload
    };
};
export const continueHouseholdAssets= (payload) => {
    return {
        type: HOUSEHOLD_ASSETS_CHECK,
        payload
    };
};
export const resetForm = (payload) => {
    return {
        type: RESET_FORM,
        payload
    };
};

