import { householdAssetsConstants, initialState } from './HouseholdAssetsConstants';

const {
    HOUSEHOLD_ASSETS_ACTIVE_INDEX,
    CONTINUE_WELCOME,
    HOUSEHOLD_ASSETS_CHECK,
    RESET_FORM,
    HOUSEHOLD_ASSETS_STATUS
} = householdAssetsConstants;

export const HouseholdAssets = (state = initialState, action) => {
    switch (action.type) {
        case CONTINUE_WELCOME: {
            return {
                ...state,
                welcomeContinue: action.payload.welcomeContinue
            };
        }
        case HOUSEHOLD_ASSETS_CHECK: {
            return {
                ...state,
                householdAssetsCheck: action.payload.householdAssetsCheck
            };
        }
        case HOUSEHOLD_ASSETS_ACTIVE_INDEX: {
            return {
                ...state,
                activeStepIndex: action.payload
            };
        }
        case RESET_FORM: {
            return {
                ...initialState
            };
        }
        case HOUSEHOLD_ASSETS_STATUS: {
            return {
                ...state,
                activeStepIndex: 5,
                householdAssetsStatus: action.payload
            };
        }
        default:
            return state;
    }
};
