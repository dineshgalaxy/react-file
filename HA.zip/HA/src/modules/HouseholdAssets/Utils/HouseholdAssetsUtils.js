import { noop } from '~/shared/utils/utils';
import { householdAssetsStatusConstant, householdAssetsStatusData } from './HouseholdAssetsConstants';

export const getProgressValue = (activeIndex) => {
    return 16.666666667 * activeIndex;
};
export const getHouseholdAssetsStatusData = (householdAssetsStatus, onExitClickFun, onSuccessClick) => {
    const householdAssetsStatusRes = {
        Success: 1,
        Failed: 2,
        Questioned: 3
    }[householdAssetsStatus];

    let onPrimaryClick = noop;
    if (householdAssetsStatusRes === householdAssetsStatusConstant.SUCCESS) {
        onPrimaryClick = onSuccessClick;
    } else if (householdAssetsStatusRes === householdAssetsStatusConstant.FAILED) {
        onPrimaryClick = onExitClickFun;
    } else {
        onPrimaryClick = onExitClickFun;
    }

    const data = householdAssetsStatusData[householdAssetsStatusRes];
    return {
        ...data,
        onPrimaryClick: onPrimaryClick
    };
};
