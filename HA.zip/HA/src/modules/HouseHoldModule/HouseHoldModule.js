import { Box, Button } from '@material-ui/core';
import Router from 'next/router';
import PropTypes from 'prop-types';
import React, { useCallback, useEffect, useState } from 'react';
import { Info } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import { useToasts } from 'react-toast-notifications';
import { fetchFamilyMemberList } from '~/modules/CheckYourEligibility/Utils/CheckYourEligibilityApiUtils';
import HouseholdAccessibilityNeeds from '~/modules/HouseHoldModule/HouseholdMembers/HouseholdAccessibilityNeeds';
import HouseholdAdditionalMembers from '~/modules/HouseHoldModule/HouseholdMembers/HouseholdAdditionalMembers';
import HouseholdMilitaryHistory from '~/modules/HouseHoldModule/HouseholdMembers/HouseholdMilitaryHistory';
import HouseholdMiscDetails from '~/modules/HouseHoldModule/HouseholdMembers/HouseholdMiscDetails';
import HouseholdShelterNeeds from '~/modules/HouseHoldModule/HouseholdMembers/HouseholdShelterNeeds';
import {
    deleteMember,
    fetchAdditionalMemberCount,
    fetchAllFormData,
    fetchMember,
    fetchMemberDetail,
    fetchReviewPreApplication,
    getEligiblePrograms,
    saveHouseHoldDetails,
    saveHouseHoldMember,
    saveProgramsWithTerms
} from '~/modules/HouseHoldModule/Utils/HouseHoldApiUtils';
import ApplicationReview from '~/shared/components/ApplicationReview';
import ApplicationSubmitted from '~/shared/components/ApplicationSubmitted';
import ApplicationTerms from '~/shared/components/ApplicationTerms';
import CommonCard from '~/shared/components/CommonCard';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import withLoader from '~/shared/components/hoc/withLoader';
import HouseholdMemberDetails from '~/shared/components/HouseholdMemberForm/HouseholdMemberDetails';
import HouseholdMemberMoreDetails from '~/shared/components/HouseholdMemberForm/HouseholdMemberMoreDetails';
import InformationCard from '~/shared/components/InformationCard';
import ObjectCard from '~/shared/components/ObjectCard';
import StatusCard from '~/shared/components/StatusCard';
import WizardHeader from '~/shared/components/WizardHeader';
import { ROUTES } from '~/shared/constants/routesConstants';
import EligiblePrograms from './HouseholdMembers/EligiblePrograms';
import {
    addMoreMember,
    backAdditionalFormStep1,
    backAdditionalFormStep2,
    confirmReviewDetail,
    handleEditMember,
    infoContinue,
    removeMember,
    renderEditForms,
    resetAdditionalMember,
    resetAllForm,
    saveAccommodation,
    saveAdditionalFirstForm,
    saveAdditionalForm,
    saveAdditionalMember,
    saveMilitaryInfo,
    saveOtherInfo,
    savePrograms,
    saveShelterInfo,
    setActiveStepIndex,
    setAdditionalFormStep
} from './Utils/HouseHoldAction';
import {
    HOUSE_HOLD_FORMS_COUNTS,
    OTHER_FORMS,
    statusCardData,
    STEPS
} from './Utils/HouseHoldConstants';
import {
    getFormNumber,
    getHouseHoldPayload,
    saveDefaultCheckBoxValues
} from './Utils/HouseHoldUtils';
/*
 * Render CreateProfileModule
 * @param {func} setLoading
 * @returns Component
 */

const HouseHoldModule = ({ setLoading }) => {
    const { CREATE_PROFILE } = ROUTES;
    const { addToast } = useToasts();
    const dispatch = useDispatch();
    const {
        activeStepIndex,
        memberFormSteps,
        additionalFormInfo = {},
        activeMember,
        houseHoldFormCount,
        programs
    } = useSelector((state) => state.houseHoldDetails);

    const firstName = additionalFormInfo[activeMember]?.fname;
    const [selectedMember, setSelectedMember] = useState(0);
    const [memberList, setMemberList] = useState([]);

    const [statusCard, setStatusCard] = useState({
        title: 'Hold on while we determine for which programs you may be a candidate.',
        iconName: 'more-horizontal',
        iconStatus: 'success'
    });

    const [applicationDetail, setApplicantDetail] = useState();
    const [eligibleProgramDetails, setEligibleProgramDetails] = useState([]);
    const [preApplicationData, setPreApplicationData] = useState({});
    const [formData, setFormData] = useState({
        accessibility: [],
        military: [],
        shelter: [],
        miseDetail: [],
        gender: [],
        citizenShip: [],
        relationShip: [],
        payFrequency: [],
        raceEthnics: []
    });

    useEffect(() => {
        (async () => {
            setLoading(true);
            const [memberCountList, memberCount] = await Promise.all([
                fetchFamilyMemberList(),
                fetchAdditionalMemberCount()
            ]);
            setSelectedMember(memberCount?.res_data?.data?.no_of_members || 0);
            setMemberList(memberCountList?.res_data?.data);
            setLoading(false);
        })(); //Self-Invoking Functions
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const getAllMemberInfo = async (memberDetails) => {
        const members = Promise.all(
            memberDetails?.map(async (item) => {
                const { res_data: { data = {} } = {} } = await fetchMember(item.member_id);
                return data;
            })
        );
        const result = await members;
        dispatch(renderEditForms(result));
    };

    const fetchMemberDetails = async () => {
        setLoading(true);
        const { res_data: { data = {} } = {} } = await fetchMemberDetail();
        setApplicantDetail(data?.applicantDetail);
        if (data?.memberDetails?.length) {
            dispatch(setActiveStepIndex(activeStepIndex));
            await getAllMemberInfo(data?.memberDetails);
        }
        setLoading(false);
    };

    useEffect(() => {
        (async () => {
            await fetchMemberDetails();
        })(); //Self-Invoking Functions
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        (async () => {
            setLoading(true);
            const {
                accessibility,
                military,
                shelter,
                miseDetail,
                gender,
                citizenShip,
                relationShip,
                payFrequency,
                raceEthnics
            } = await fetchAllFormData();
            const { data: accessibilityData, selectedData: accessibilitySelectedData } =
                accessibility;
            const { data: militaryData, selectedData: militarySelectedData } = military;
            const { data: shelterData, selectedData: shelterSelectedData } = shelter;
            const { data: miseDetailData, selectedData: miseDetailSelectedData } = miseDetail;
            setFormData({
                ...formData,
                accessibility: accessibilityData,
                military: militaryData,
                gender,
                citizenShip,
                shelter: shelterData,
                miseDetail: miseDetailData,
                relationShip,
                payFrequency,
                raceEthnics
            });
            dispatch(saveAccommodation(saveDefaultCheckBoxValues(accessibilitySelectedData)));
            dispatch(saveMilitaryInfo(saveDefaultCheckBoxValues(militarySelectedData)));
            dispatch(saveShelterInfo(saveDefaultCheckBoxValues(shelterSelectedData)));
            dispatch(saveOtherInfo(saveDefaultCheckBoxValues(miseDetailSelectedData)));
            setLoading(false);
        })(); //Self-Invoking Functions
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const handleClickContinue = async (fn, { ...data }) => {
        dispatch(fn({ ...data }));
        if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        }
    };

    const handleClickBack = () => {
        if (activeStepIndex !== STEPS.STEP1) {
            dispatch(setActiveStepIndex(activeStepIndex - 1));
        } else {
            Router.push(CREATE_PROFILE.ROUTE);
        }
    };

    const handleReviewPageBack = () => {
        if (activeStepIndex !== STEPS.STEP1) {
            dispatch(setActiveStepIndex(activeStepIndex - 1));
        }
        const backForm =
            Object.keys(additionalFormInfo).length === 1
                ? Object.keys(additionalFormInfo).length
                : Object.keys(additionalFormInfo).length - 1;
        dispatch(setAdditionalFormStep(backForm));
    };

    const handleSaveAdditionalMember = async (fn, { ...data }) => {
        dispatch(fn({ ...data, activeMember }));
    };

    const handleContinueMembers = async () => {
        setLoading(true);
        await fetchMemberDetails();
        setLoading(false);
        dispatch(setActiveStepIndex(activeStepIndex + 1));
    };

    const handleSaveHouseHold = async (data) => {
        setLoading(true);
        const payload = await getHouseHoldPayload(data, formData);
        const { res_data: { status = false } = {} } = await saveHouseHoldDetails({
            ...payload
        });
        setLoading(false);
        return { status };
    };

    const getAllEligibleDetails = async () => {
        const { res_data: { data = {}, status = false } = {} } = await getEligiblePrograms();
        if (status) {
            setEligibleProgramDetails(data?.programs);
            if (!data?.programs?.length) {
                setStatusCard(statusCardData);
            }
        }
    };

    useEffect(() => {
        (async () => {
            if (activeStepIndex === STEPS.STEP8) {
                await getAllEligibleDetails();
            }
        })(); //Self-Invoking Functions
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [activeStepIndex]);

    const handleClickHouseHold = async (fn, { ...data }) => {
        dispatch(fn({ ...data }));
        const { status } = await handleSaveHouseHold(data);
        if (status && activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        }
    };

    const handleSaveAdditionalForm = async (fn, { ...data }) => {
        dispatch(fn({ ...data, activeMember }));
        setLoading(true);
        const { res_data: { status = false } = {} } = await saveHouseHoldMember({
            ...additionalFormInfo[activeMember],
            ...data
        });
        if (status) {
            if (activeMember < memberFormSteps.length) {
                dispatch(setAdditionalFormStep(activeMember + 1));
            } else {
                dispatch(setActiveStepIndex(activeStepIndex + 1));
            }
        }
        setLoading(false);
    };

    const handleAdditionalFormBack = async (fn) => {
        dispatch(fn());
        if (activeMember !== HOUSE_HOLD_FORMS_COUNTS.FORM1) {
            dispatch(setAdditionalFormStep(activeMember - 1));
        } else {
            dispatch(resetAdditionalMember());
        }
    };

    const handleAddNewMember = () => {
        dispatch(addMoreMember());
    };

    const handleEditAdditionalMember = async (memberIndex) => {
        dispatch(handleEditMember({ activeMember: Number(memberIndex) }));
    };

    const getRelationName = useCallback(
        (relationShipId) => {
            if (relationShipId) {
                const [relation] = formData?.relationShip.filter(({ id }) => id === relationShipId);
                return relation?.type;
            }
        },
        [formData?.relationShip]
    );
    const handleDelete = async (memberId, memberIndex) => {
        if (memberId) {
            const { res_data } = await deleteMember(memberId);
            if (res_data?.status) {
                await fetchMemberDetails();
                addToast(res_data?.message, { appearance: 'success' });
            }
        } else {
            dispatch(removeMember(memberIndex));
        }
    };

    const handleExitClick = async () => {
        dispatch(resetAllForm());
        await fetchMemberDetails();
    };

    useEffect(() => {
        (async () => {
            if (activeStepIndex === STEPS.STEP9) {
                const {
                    res_data: {
                        data: { applicantDetail = {}, membersDetail = [], othersDetail = {} } = {}
                    }
                } = await fetchReviewPreApplication();
                setPreApplicationData({ applicantDetail, membersDetail, othersDetail });
            }
        })(); //Self-Invoking Functions
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [activeStepIndex]);

    const handleAcceptTermCondition = async (term) => {
        setLoading(true);
        if (term) {
            const { res_data: { status = false } = {} } = await saveProgramsWithTerms({
                terms_acknowledged: term,
                programIds: programs
            });
            if (status) {
                dispatch(setActiveStepIndex(activeStepIndex + 1));
            }
        } else {
            addToast('Terms and conditions are required.', { appearance: 'error' });
        }
        setLoading(false);
    };

    const handleSubmitPrograms = (programsData) => {
        if (programsData?.length) {
            dispatch(savePrograms(programsData));
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        } else {
            addToast('Please select at least a program.', { appearance: 'error' });
        }
    };

    return (
        <>
            <Box bgcolor="secondary.extraLight">
                {activeStepIndex === STEPS.STEP1 ? (
                    <CommonCard onClickBack={handleClickBack} bgColor="primary" pageView="full">
                        <InformationCard
                            title="Next, we’ll ask about your household."
                            subTitle="You’ll enter information for each member of your household, including personal details required to complete your applications."
                            onClickContinue={() =>
                                handleClickContinue(infoContinue, { infoContinue: true })
                            }
                            content={
                                <Box
                                    fontSize="h6.fontSize"
                                    color="primary.extraLight"
                                    lineHeight="26px"
                                    mb={2.5}>
                                    You’ll enter information for each member of your household,
                                    including personal details required to complete your
                                    applications.
                                </Box>
                            }
                        />
                    </CommonCard>
                ) : null}
                {activeStepIndex === STEPS.STEP2 ? (
                    <>
                        <WizardHeader onClickBack={handleClickBack} />
                        {!memberFormSteps.length ? (
                            <>
                                <CommonCard onClickBack={handleClickBack}>
                                    <HouseholdAdditionalMembers
                                        memberList={memberList}
                                        selectedMember={selectedMember}
                                        onClickContinue={(data) =>
                                            handleSaveAdditionalMember(saveAdditionalMember, data)
                                        }
                                        title="Not counting yourself, enter how many other additional members are or
 will be in your household."
                                    />
                                </CommonCard>
                                <ExitConfirmation isExitText={true} onConfirm={handleExitClick} />
                            </>
                        ) : null}
                        {memberFormSteps.includes(activeMember) ? (
                            <>
                                {houseHoldFormCount === HOUSE_HOLD_FORMS_COUNTS.FORM1 ? (
                                    <>
                                        <CommonCard
                                            onClickBack={() =>
                                                handleAdditionalFormBack(backAdditionalFormStep1)
                                            }>
                                            <HouseholdMemberDetails
                                                gender={formData?.gender}
                                                citizenShip={formData?.citizenShip}
                                                relationShip={formData?.relationShip}
                                                payFrequency={formData?.payFrequency}
                                                onNextButtonClick={(data) =>
                                                    handleSaveAdditionalMember(
                                                        saveAdditionalFirstForm,
                                                        data
                                                    )
                                                }
                                                title={`Let’s enter the ${getFormNumber(
                                                    activeMember
                                                )} additional member of your household.`}
                                            />
                                        </CommonCard>
                                        <Box maxWidth="1008px" margin="0 auto">
                                            <Box mt={4} mx={3} mb={-6.5}>
                                                <Box display="flex" alignItems="center" mb={1}>
                                                    <Box mr={1} display="flex">
                                                        <Info color="Indigo" size={21} />
                                                    </Box>
                                                    <Box
                                                        color="primary.light"
                                                        fontSize="h5.fontSize"
                                                        fontFamily="fontFamily.medium">
                                                        Pay Frequency Help
                                                    </Box>
                                                </Box>
                                                <Box
                                                    color="primary.extraLight"
                                                    fontSize="md.fontSize"
                                                    mb={1}>
                                                    Understanding paycheck frequency can be
                                                    confusing. Use the definitions below for help
                                                    understanding paycheck frequency:
                                                </Box>
                                                <Box
                                                    color="primary.extraLight"
                                                    fontSize="md.fontSize"
                                                    mb={1}>
                                                    <Box
                                                        component="span"
                                                        fontFamily="fontFamily.medium"
                                                        mr={0.4}>
                                                        Weekly:
                                                    </Box>
                                                    The individual is paid once per week. Enter
                                                    “Every Week” above.
                                                </Box>
                                                <Box
                                                    color="primary.extraLight"
                                                    fontSize="md.fontSize"
                                                    mb={1}>
                                                    <Box
                                                        component="span"
                                                        fontFamily="fontFamily.medium"
                                                        mr={0.4}>
                                                        BiWeekly:
                                                    </Box>
                                                    The individual is paid every other week. Enter
                                                    “Every other week ” above.
                                                </Box>
                                                <Box
                                                    color="primary.extraLight"
                                                    fontSize="md.fontSize"
                                                    mb={1}>
                                                    <Box
                                                        component="span"
                                                        fontFamily="fontFamily.medium"
                                                        mr={0.4}>
                                                        Semimonthly:
                                                    </Box>
                                                    The individual is usually paid twice per month,
                                                    like on the 15th and 30th. Enter “Twice Per
                                                    Month” above.
                                                </Box>
                                                <Box
                                                    color="primary.extraLight"
                                                    fontSize="md.fontSize"
                                                    mb={1}>
                                                    <Box
                                                        component="span"
                                                        fontFamily="fontFamily.medium"
                                                        mr={0.4}>
                                                        Monthly:
                                                    </Box>
                                                    The individual is paid once per month. Enter
                                                    “Once Per Month” above.
                                                </Box>
                                            </Box>
                                        </Box>
                                        <ExitConfirmation
                                            onConfirm={handleExitClick}
                                            isExitText={true}
                                        />
                                    </>
                                ) : null}
                                {houseHoldFormCount === HOUSE_HOLD_FORMS_COUNTS.FORM2 ? (
                                    <>
                                        <CommonCard
                                            onClickBack={() => {
                                                dispatch(backAdditionalFormStep2());
                                            }}>
                                            <HouseholdMemberMoreDetails
                                                firstName={firstName}
                                                raceEthnics={formData?.raceEthnics}
                                                onNextButtonClick={(data) =>
                                                    handleSaveAdditionalForm(
                                                        saveAdditionalForm,
                                                        data
                                                    )
                                                }
                                                title={`Enter a few more details for ${firstName}.`}
                                            />
                                        </CommonCard>
                                        <ExitConfirmation
                                            onConfirm={handleExitClick}
                                            isExitText={true}
                                        />
                                    </>
                                ) : null}
                            </>
                        ) : null}
                    </>
                ) : null}
                {activeStepIndex === STEPS.STEP3 ? (
                    <>
                        <WizardHeader onClickBack={handleReviewPageBack}>
                            <Box textAlign="center">
                                <Box
                                    fontSize="h3.fontSize"
                                    color="common.white"
                                    fontFamily="fontFamily.bold"
                                    lineHeight="32px"
                                    mb={2}
                                    px={2}>
                                    Review Your Household
                                </Box>
                                <Box fontSize="h6.fontSize" color="common.white">
                                    Okay, we’ve added all of your household members below. You may
                                    add anyone we missed, or continue if everything looks correct.
                                </Box>
                            </Box>
                        </WizardHeader>

                        <CommonCard
                            backBtnColor="backBtnWhite"
                            onClickBack={handleReviewPageBack}
                            bgColor="transparent">
                            <Box>
                                <Box mb={3} key={applicationDetail?.user_id}>
                                    <ObjectCard>
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            {`${applicationDetail?.fname || ''} ${
                                                applicationDetail?.lname || ''
                                            }`}
                                        </Box>
                                        <Box color="primary.light" fontSize="lg.fontSize">
                                            {applicationDetail?.role || ''}
                                        </Box>
                                    </ObjectCard>
                                </Box>

                                {Object.keys(additionalFormInfo).length
                                    ? Object.keys(additionalFormInfo).map(function (key) {
                                          return (
                                              <Box mb={3} key={key}>
                                                  <ObjectCard
                                                      isMember={true}
                                                      onEditClick={() =>
                                                          handleEditAdditionalMember(key)
                                                      }
                                                      onDelete={() =>
                                                          handleDelete(
                                                              additionalFormInfo[key]?.id,
                                                              key
                                                          )
                                                      }>
                                                      <Box
                                                          color="primary.main"
                                                          fontSize="h6.fontSize"
                                                          fontFamily="fontFamily.medium">
                                                          {`${additionalFormInfo[key]?.fname} ${additionalFormInfo[key]?.lname}`}
                                                      </Box>
                                                      <Box
                                                          color="primary.light"
                                                          fontSize="lg.fontSize">
                                                          {getRelationName(
                                                              additionalFormInfo[key]
                                                                  ?.relationship_id
                                                          )}
                                                      </Box>
                                                  </ObjectCard>
                                              </Box>
                                          );
                                      })
                                    : null}

                                <Box
                                    mb={6}
                                    borderColor="primary.main"
                                    border="1px dashed"
                                    borderRadius="21px">
                                    <ObjectCard iconName="plus" onClick={handleAddNewMember}>
                                        <Box
                                            color="primary.main"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            Add Another Person
                                        </Box>
                                    </ObjectCard>
                                </Box>
                                <Box display="flex" justifyContent="center">
                                    <Button
                                        size="large"
                                        color="primary"
                                        variant="contained"
                                        onClick={handleContinueMembers}>
                                        Continue
                                    </Button>
                                </Box>
                            </Box>
                        </CommonCard>
                        <ExitConfirmation isExitText={true} onConfirm={handleExitClick} />
                    </>
                ) : null}
                {activeStepIndex === STEPS.STEP4 ? (
                    <>
                        <WizardHeader onClickBack={handleClickBack} />
                        <CommonCard onClickBack={handleClickBack}>
                            <HouseholdAccessibilityNeeds
                                accessibility={formData?.accessibility}
                                onClickContinue={(data) =>
                                    handleClickHouseHold(saveAccommodation, {
                                        ...data,
                                        form: OTHER_FORMS.SAVE_ACCOMMODATION_FORM_INFO
                                    })
                                }
                                title="Do you or any member of your household require special accomodations?"
                            />
                        </CommonCard>
                        <ExitConfirmation isExitText={true} onConfirm={handleExitClick} />
                    </>
                ) : null}
                {activeStepIndex === STEPS.STEP5 ? (
                    <>
                        <WizardHeader onClickBack={handleClickBack} />
                        <CommonCard onClickBack={handleClickBack}>
                            <HouseholdShelterNeeds
                                shelter={formData?.shelter}
                                onClickContinue={(data) =>
                                    handleClickHouseHold(saveShelterInfo, {
                                        ...data,
                                        form: OTHER_FORMS.SAVE_SHELTER_FORM_INFO
                                    })
                                }
                                title="Are you or any members of the household currently displaced or homeless?"
                            />
                        </CommonCard>
                        <ExitConfirmation isExitText={true} onConfirm={handleExitClick} />
                    </>
                ) : null}
                {activeStepIndex === STEPS.STEP6 ? (
                    <>
                        <WizardHeader onClickBack={handleClickBack} />
                        <CommonCard onClickBack={handleClickBack}>
                            <HouseholdMilitaryHistory
                                military={formData?.military}
                                title="Are you or any household members currently serving or veterans?"
                                onClickContinue={(data) =>
                                    handleClickHouseHold(saveMilitaryInfo, {
                                        ...data,
                                        form: OTHER_FORMS.SAVE_MILITARY_FORM_INFO
                                    })
                                }
                            />
                        </CommonCard>
                        <ExitConfirmation isExitText={true} onConfirm={handleExitClick} />
                    </>
                ) : null}
                {activeStepIndex === STEPS.STEP7 ? (
                    <>
                        <WizardHeader />
                        <CommonCard onClickBack={handleClickBack}>
                            <HouseholdMiscDetails
                                miseDetails={formData?.miseDetail}
                                onClickBack={handleClickBack}
                                onClickContinue={(data) =>
                                    handleClickHouseHold(saveOtherInfo, {
                                        ...data,
                                        form: OTHER_FORMS.SAVE_OTHER_FORM_INFO
                                    })
                                }
                                title="Mark any of the following that apply to one or more household members."
                            />
                        </CommonCard>
                        <Box maxWidth="1008px" margin="0 auto">
                            <Box mt={4} mx={3} mb={-6.5}>
                                <Box display="flex" alignItems="center" mb={1}>
                                    <Box mr={1} display="flex">
                                        <Info color="Indigo" size={21} />
                                    </Box>
                                    <Box
                                        color="primary.light"
                                        fontSize="h5.fontSize"
                                        fontFamily="fontFamily.medium">
                                        More Information
                                    </Box>
                                </Box>
                                <Box color="primary.extraLight" fontSize="md.fontSize">
                                    An elderly or disabled family is any family in which the head or
                                    spouse (or the sole member) is at least 62 years of age or a
                                    person with disabilities.
                                </Box>
                            </Box>
                            <ExitConfirmation isExitText={true} onConfirm={handleExitClick} />
                        </Box>
                    </>
                ) : null}

                {activeStepIndex === STEPS.STEP8 ? (
                    <>
                        {eligibleProgramDetails.length ? (
                            <EligiblePrograms
                                onSubmit={(data) => handleSubmitPrograms(data)}
                                programs={eligibleProgramDetails}
                            />
                        ) : (
                            <CommonCard
                                onClickBack={handleClickBack}
                                isStatusCard={true}
                                isFullPage={true}
                                showBackBtn={false}>
                                <StatusCard
                                    title={statusCard?.title}
                                    subTitle={statusCard?.subTitle}
                                    subTitle2={statusCard?.subTitle2}
                                    iconName={statusCard?.iconName}
                                    buttonType={statusCard?.buttonType}
                                    buttonText={statusCard?.buttonText}
                                    iconStatus={statusCard?.iconStatus}
                                    showButton={statusCard?.showButton}
                                    onClickContinue={() => Router.push(ROUTES.HOME.ROUTE)}
                                />
                            </CommonCard>
                        )}
                    </>
                ) : null}
                {activeStepIndex === STEPS.STEP9 ? (
                    <>
                        <WizardHeader onClickBack={handleClickBack}>
                            <Box textAlign="center" pl={3} pr={3} pb={2} mt={-3}>
                                <Box
                                    fontSize="h3.fontSize"
                                    color="common.white"
                                    fontFamily="fontFamily.bold"
                                    mb={2}>
                                    Review Your Pre-Application
                                </Box>
                                <Box fontSize="h6.fontSize" color="common.white">
                                    Review, edit, and confirm all of the information you’ve provided
                                    below. If everything looks correct, click “confirm”.
                                </Box>
                            </Box>
                        </WizardHeader>
                        <CommonCard bgColor="gray" onClickBack={handleClickBack}>
                            <ApplicationReview
                                onNextButtonClick={() =>
                                    handleClickContinue(confirmReviewDetail, {
                                        reviewDetailConfirm: true
                                    })
                                }
                                applicantDetail={preApplicationData?.applicantDetail}
                                memberDetails={preApplicationData?.membersDetail}
                                otherDetails={preApplicationData?.othersDetail}
                                buttonText="Confirm"
                                onEditMember={handleEditAdditionalMember}
                                onEditAccessibility={() => dispatch(setActiveStepIndex(4))}
                                onEditShelter={() => dispatch(setActiveStepIndex(5))}
                                onEditMilitary={() => dispatch(setActiveStepIndex(6))}
                                onEditMiseDetail={() => dispatch(setActiveStepIndex(7))}
                            />
                        </CommonCard>
                        <ExitConfirmation
                            isExitText={true}
                            onContinueClick={handleExitClick}
                            exitText="OR CANCEL"
                        />
                    </>
                ) : null}
                {activeStepIndex === STEPS.STEP10 ? (
                    <>
                        <WizardHeader onClickBack={handleClickBack}>
                            <Box textAlign="center" pl={3} pr={3} pb={2} mt={-3}>
                                <Box
                                    fontSize="h3.fontSize"
                                    color="common.white"
                                    fontFamily="fontFamily.bold"
                                    mb={2}>
                                    Review Your Pre-Application
                                </Box>
                                <Box fontSize="h6.fontSize" color="common.white">
                                    Before you submit your PreApplication, please confirm that
                                    you’ve read and understand the following terms and conditions.
                                </Box>
                            </Box>
                        </WizardHeader>
                        <CommonCard bgColor="gray" onClickBack={handleClickBack}>
                            <ApplicationTerms
                                onNextButtonClick={(data) => handleAcceptTermCondition(data)}
                            />
                        </CommonCard>
                        <ExitConfirmation
                            isExitText={true}
                            onContinueClick={handleExitClick}
                            exitText="OR CANCEL"
                        />
                    </>
                ) : null}
                {activeStepIndex > Object.keys(STEPS).length ? (
                    <CommonCard bgScreen="success" space="xs" showBackBtn={false}>
                        <StatusCard
                            title="We’ve received your Pre-Application."
                            buttonText="Exit to Dashboard"
                            titleColor="primary"
                            buttonType="primary"
                            iconName="check-circle"
                            iconStatus="complete"
                            iconColor="indigo"
                            showButton
                            onClickContinue={() => Router.push('/')}
                            subTitle={
                                <Box mt={4}>
                                    <ApplicationSubmitted title="What’s Next?">
                                        <Box color="primary.light" fontSize="h6.fontSize" pb={2}>
                                            We’ll review your pre-application information to
                                            determine if you are a candidate for any open programs
                                            or waitlists. You will likely be updated within 14 days
                                            of your status, but be advised that waitlists may last
                                            for up to 2-4 years.
                                        </Box>
                                        <Box color="primary.light" fontSize="h6.fontSize">
                                            We’ll send updates to the email address provided in your
                                            application, or you can view up-to-date status
                                            information on your dashboard.
                                        </Box>
                                    </ApplicationSubmitted>
                                </Box>
                            }
                        />
                    </CommonCard>
                ) : null}
            </Box>
        </>
    );
};

HouseHoldModule.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(HouseHoldModule);
