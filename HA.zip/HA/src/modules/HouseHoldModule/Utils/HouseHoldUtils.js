import { CHAR_VALIDATION_REGEX, DIGIT_REGEX } from '~/shared/constants/constants';
import { OTHER_FORMS } from './HouseHoldConstants';

export const onValidateAdditionalMemberField = (values) => {
    let errors = {};
    if (!values.additionalMember) {
        errors.additionalMember = 'This field is required.';
    }
    return errors;
};

export const onValidateAdditionalMemberFirstForm = (values) => {
    let errors = {};
    const unmask_social_security_number = values.social_security_number.replace(DIGIT_REGEX, '');
    //first name
    if (!values.fname.trim()) {
        errors.fname = 'This field is required.';
    } else if (!CHAR_VALIDATION_REGEX.test(values.fname)) {
        errors.fname = 'Please enter valid first name.';
    }
    //middle name
    if (!CHAR_VALIDATION_REGEX.test(values.mname)) {
        errors.mname = 'Please enter valid middle name.';
    }
    //last name
    if (!values.lname.trim()) {
        errors.lname = 'This field is required.';
    } else if (!CHAR_VALIDATION_REGEX.test(values.lname)) {
        errors.lname = 'Please enter valid last name.';
    }
    //maiden_name
    if (!CHAR_VALIDATION_REGEX.test(values.maiden_name)) {
        errors.maiden_name = 'Please enter valid maiden name.';
    }
    //relationship_id
    if (!values.relationship_id) {
        errors.relationship_id = 'This field is required.';
    }
    //citizenship_id
    if (!values.citizenship_id) {
        errors.citizenship_id = 'This field is required.';
    }
    //dob
    if (!values.dob) {
        errors.dob = 'This field is required.';
    }
    //gender_id
    if (!values.gender_id) {
        errors.gender_id = 'This field is required.';
    }
    if (!unmask_social_security_number.trim()) {
        errors.social_security_number = 'This field is required.';
    } else if (isNaN(unmask_social_security_number)) {
        errors.social_security_number = 'Please enter valid social security number.';
    }
    //yearly_income
    if (!values.yearly_income) {
        errors.yearly_income = 'This field is required.';
    } else if (isNaN(values.yearly_income)) {
        errors.yearly_income = 'Please enter valid yearly income.';
    }
    //pay_frequency_id
    if (!values.pay_frequency_id) {
        errors.pay_frequency_id = 'This field is required.';
    }
    //paycheck_amount
    if (!values.paycheck_amount) {
        errors.paycheck_amount = 'This field is required.';
    } else if (isNaN(values.paycheck_amount)) {
        errors.yearly_income = 'Please enter valid pay check amount.';
    }
    return errors;
};

export const onValidateAdditionalMemberSecondForm = (values) => {
    let errors = {};
    //is_disabled
    if (!values.is_disabled) {
        errors.is_disabled = 'This field is required.';
    }
    //is_fulltime_student
    if (!values.is_fulltime_student) {
        errors.is_fulltime_student = 'This field is required.';
    }
    //is_student_next_year
    if (!values.is_student_next_year) {
        errors.is_student_next_year = 'This field is required.';
    }
    //lifetime_sex_offender_reg
    if (!values.lifetime_sex_offender_reg) {
        errors.lifetime_sex_offender_reg = 'This field is required.';
    }

    return errors;
};

export const getFirstFormInItValues = (additionalFormInfo, activeMember) => {
    let date = new Date();
    let myDate = date.getUTCFullYear() + '/' + (date.getMonth() + 1) + '/' + date.getUTCDate();
    return {
        fname: additionalFormInfo[activeMember]?.fname || '',
        mname: additionalFormInfo[activeMember]?.mname || '',
        lname: additionalFormInfo[activeMember]?.lname || '',
        maiden_name: additionalFormInfo[activeMember]?.maiden_name || '',
        relationship_id: additionalFormInfo[activeMember]?.relationship_id || '',
        citizenship_id: additionalFormInfo[activeMember]?.citizenship_id || '',
        dob: additionalFormInfo[activeMember]?.dob || myDate,
        gender_id: additionalFormInfo[activeMember]?.gender_id || '',
        social_security_number:
            additionalFormInfo[activeMember]?.social_security_number.replace(DIGIT_REGEX, '') || '',
        yearly_income: additionalFormInfo[activeMember]?.yearly_income || '',
        pay_frequency_id: additionalFormInfo[activeMember]?.pay_frequency_id || '',
        paycheck_amount: additionalFormInfo[activeMember]?.paycheck_amount || ''
    };
};

export const getFormNumber = (activeMember) => {
    const number = {
        1: 'first',
        2: 'second',
        3: 'third',
        4: 'fourth',
        5: 'fifth',
        6: 'sixth',
        7: 'seventh',
        8: 'eight',
        9: 'nine',
        10: 'ten',
        11: 'eleven',
        12: 'twelve',
        13: 'thirteen',
        14: 'fourteen'
    }[activeMember];

    return number;
};

export const filterOtherFormData = (detail, data, key) => {
    const payload = {};
    data = detail.filter((e) => data[e.id] && Object.keys(data).includes(e.id));
    const selectedDetails = [];
    for (const item of data) {
        selectedDetails.push({ id: item?.id, title: item?.type });
    }
    payload[key] = {
        values: selectedDetails
    };
    return payload;
};

export const saveDefaultCheckBoxValues = (data) => {
    let defaultSelectedData = {};
    if (data?.length) {
        data.forEach(({ id }) => {
            defaultSelectedData = { ...defaultSelectedData, [id]: true };
        });
    }
    return defaultSelectedData;
};

export const getHouseHoldPayload = async (data, formData) => {
    let payload = {};
    switch (data.form) {
        case OTHER_FORMS.SAVE_ACCOMMODATION_FORM_INFO: {
            payload = filterOtherFormData(formData?.accessibility, data, 'accessibility');
            break;
        }
        case OTHER_FORMS.SAVE_SHELTER_FORM_INFO: {
            payload = filterOtherFormData(formData?.shelter, data, 'shelter');
            break;
        }
        case OTHER_FORMS.SAVE_MILITARY_FORM_INFO: {
            payload = filterOtherFormData(formData?.military, data, 'military');
            break;
        }
        case OTHER_FORMS.SAVE_OTHER_FORM_INFO: {
            payload = filterOtherFormData(formData?.miseDetail, data, 'misc_household_other');
            break;
        }
    }
    return payload;
};
