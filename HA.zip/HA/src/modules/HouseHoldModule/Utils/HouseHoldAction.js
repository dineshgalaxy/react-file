import { houseHoldConstants } from './HouseHoldConstants';

const {
    HOUSE_HOLD_ACTIVE_INDEX,
    HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM,
    HOUSE_HOLD_INFO_CONTINUE,
    HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER,
    HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM,
    SET_ADDITIONAL_FORM_STEP,
    BACK_ADDITIONAL_FORM_STEP2,
    BACK_ADDITIONAL_FORM_STEP1,
    RESET_ADDITIONAL_MEMBER,
    ADDITIONAL_REVIEW_CONTINUE,
    SAVE_ACCOMMODATIONS,
    SAVE_SHELTER_INFO,
    SAVE_MILITARY_IFO,
    SAVE_OTHER_INFO,
    ADD_MORE_MEMBER,
    REMOVE_MEMBER,
    EDIT_MEMBER,
    RENDER_EDIT_FORMS,
    RESET_FORM,
    CONFIRM_REVIEW_DETAIL,
    SAVE_PROGRAMS
} = houseHoldConstants;

export const setActiveStepIndex = (payload) => {
    return {
        type: HOUSE_HOLD_ACTIVE_INDEX,
        payload
    };
};

export const infoContinue = (payload) => {
    return {
        type: HOUSE_HOLD_INFO_CONTINUE,
        payload
    };
};

export const saveAdditionalMember = (payload) => {
    return {
        type: HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER,
        payload
    };
};

export const saveAdditionalFirstForm = (payload) => {
    return {
        type: HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM,
        payload
    };
};

export const saveAdditionalForm = (payload) => {
    return {
        type: HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM,
        payload
    };
};

export const setAdditionalFormStep = (payload) => {
    return {
        type: SET_ADDITIONAL_FORM_STEP,
        payload
    };
};

export const backAdditionalFormStep2 = (payload) => {
    return {
        type: BACK_ADDITIONAL_FORM_STEP2,
        payload
    };
};

export const backAdditionalFormStep1 = (payload) => {
    return {
        type: BACK_ADDITIONAL_FORM_STEP1,
        payload
    };
};

export const resetAdditionalMember = (payload) => {
    return {
        type: RESET_ADDITIONAL_MEMBER,
        payload
    };
};

export const additionalReviewContinue = (payload) => {
    return {
        type: ADDITIONAL_REVIEW_CONTINUE,
        payload
    };
};

export const saveAccommodation = (payload) => {
    return {
        type: SAVE_ACCOMMODATIONS,
        payload
    };
};

export const saveShelterInfo = (payload) => {
    return {
        type: SAVE_SHELTER_INFO,
        payload
    };
};

export const saveMilitaryInfo = (payload) => {
    return {
        type: SAVE_MILITARY_IFO,
        payload
    };
};

export const saveOtherInfo = (payload) => {
    return {
        type: SAVE_OTHER_INFO,
        payload
    };
};

export const addMoreMember = (payload) => {
    return {
        type: ADD_MORE_MEMBER,
        payload
    };
};

export const removeMember = (payload) => {
    return {
        type: REMOVE_MEMBER,
        payload
    };
};

export const handleEditMember = (payload) => {
    return {
        type: EDIT_MEMBER,
        payload
    };
};

export const renderEditForms = (payload) => {
    return {
        type: RENDER_EDIT_FORMS,
        payload
    };
};

export const resetAllForm = (payload) => {
    return {
        type: RESET_FORM,
        payload
    };
};
export const confirmReviewDetail = (payload) => {
    return {
        type: CONFIRM_REVIEW_DETAIL,
        payload
    };
};
export const savePrograms = (payload) => {
    return {
        type: SAVE_PROGRAMS,
        payload
    };
};
