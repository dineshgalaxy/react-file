import _ from 'lodash';
import { houseHoldConstants, initialState } from './HouseHoldConstants';
const {
    RESET_FORM,
    HOUSE_HOLD_ACTIVE_INDEX,
    HOUSE_HOLD_INFO_CONTINUE,
    HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER,
    HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM,
    HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM,
    SET_ADDITIONAL_FORM_STEP,
    BACK_ADDITIONAL_FORM_STEP2,
    BACK_ADDITIONAL_FORM_STEP1,
    RESET_ADDITIONAL_MEMBER,
    ADDITIONAL_REVIEW_CONTINUE,
    SAVE_ACCOMMODATIONS,
    SAVE_SHELTER_INFO,
    SAVE_MILITARY_IFO,
    SAVE_OTHER_INFO,
    ADD_MORE_MEMBER,
    REMOVE_MEMBER,
    EDIT_MEMBER,
    RENDER_EDIT_FORMS,
    CONFIRM_REVIEW_DETAIL,
    SAVE_PROGRAMS
} = houseHoldConstants;

const convertBooleanToString = (value) => {
    return value ? 'true' : 'false';
};
const getRaceEthnicData = (raceEthnics) => {
    let raceEthnicsArr = [];
    raceEthnics?.values.forEach((value) => {
        raceEthnicsArr = [...raceEthnicsArr, value?.id];
    });
    return raceEthnicsArr;
};
export const HouseHoldReducer = (state = initialState, action) => {
    const { additionalFormInfo } = state;
    switch (action.type) {
        case HOUSE_HOLD_ACTIVE_INDEX: {
            return {
                ...state,
                activeStepIndex: action.payload
            };
        }
        case HOUSE_HOLD_INFO_CONTINUE: {
            return {
                ...state,
                infoContinue: action.payload.infoContinue
            };
        }
        case HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER: {
            let stepsArr = new Array(action.payload.additionalMember).fill(1);
            stepsArr.forEach((item, index) => {
                stepsArr[index] = index + 1;
            });

            return {
                ...state,
                additionalMember: action.payload.additionalMember,
                memberFormSteps: stepsArr,
                houseHoldFormCount: 1,
                activeMember: 1
            };
        }
        case HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM: {
            return {
                ...state,
                additionalFormInfo: {
                    ...additionalFormInfo,
                    [action.payload.activeMember]: {
                        ...additionalFormInfo[action.payload.activeMember],
                        ...action.payload
                    }
                },
                houseHoldFormCount: 2
            };
        }
        case HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM: {
            return {
                ...state,
                additionalFormInfo: {
                    ...additionalFormInfo,
                    [action.payload.activeMember]: {
                        ...additionalFormInfo[action.payload.activeMember],
                        ...action.payload
                    }
                },
                houseHoldFormCount: 1
            };
        }
        case SET_ADDITIONAL_FORM_STEP: {
            return {
                ...state,
                activeMember: action.payload
            };
        }
        case BACK_ADDITIONAL_FORM_STEP2: {
            return {
                ...state,
                houseHoldFormCount: 1
            };
        }
        case BACK_ADDITIONAL_FORM_STEP1: {
            return {
                ...state,
                houseHoldFormCount: 2
            };
        }
        case RESET_ADDITIONAL_MEMBER: {
            return {
                ...state,
                memberFormSteps: [],
                activeMember: 0
            };
        }
        case ADDITIONAL_REVIEW_CONTINUE: {
            return {
                ...state,
                reviewContinue: action.payload.reviewContinue
            };
        }
        case SAVE_ACCOMMODATIONS: {
            return {
                ...state,
                accommodations: action.payload
            };
        }
        case SAVE_SHELTER_INFO: {
            return {
                ...state,
                shelterInfo: action.payload
            };
        }
        case SAVE_MILITARY_IFO: {
            return {
                ...state,
                militaryInfo: action.payload
            };
        }
        case SAVE_OTHER_INFO: {
            return {
                ...state,
                otherInfo: action.payload
            };
        }
        case RESET_FORM: {
            return {
                ...initialState
            };
        }
        case ADD_MORE_MEMBER: {
            let stepsArr = new Array(Object.keys(additionalFormInfo).length + 1).fill(1);
            stepsArr.forEach((item, index) => {
                stepsArr[index] = index + 1;
            });

            return {
                ...state,
                additionalMember: stepsArr.length || 1,
                memberFormSteps: stepsArr,
                houseHoldFormCount: 1,
                activeMember: stepsArr.length || 1,
                activeStepIndex: 2
            };
        }
        case REMOVE_MEMBER: {
            const additionalFormInfoData = { ...additionalFormInfo };
            const removedMember = _.omit(additionalFormInfoData, action.payload);
            return {
                ...state,
                additionalFormInfo: { ...removedMember }
            };
        }
        case EDIT_MEMBER: {
            return {
                ...state,
                houseHoldFormCount: 1,
                activeStepIndex: 2,
                activeMember: action.payload.activeMember
            };
        }
        case RENDER_EDIT_FORMS: {
            const existMember = [...action.payload];
            let stepsArr = new Array(action.payload.length).fill(1);
            stepsArr.forEach((item, index) => {
                stepsArr[index] = index + 1;
            });
            let memberInfo = {};
            existMember.forEach((item, index) => {
                memberInfo = {
                    ...memberInfo,
                    [index + 1]: {
                        ...item,
                        is_disabled: convertBooleanToString(item.is_disabled),
                        is_fulltime_student: convertBooleanToString(item.is_fulltime_student),
                        is_student_next_year: convertBooleanToString(item.is_student_next_year),
                        lifetime_sex_offender_reg: convertBooleanToString(
                            item.lifetime_sex_offender_reg
                        ),
                        raceEthnics: getRaceEthnicData(item.race_ethinic)
                    }
                };
            });
            return {
                ...state,
                additionalMember: action.payload.length,
                memberFormSteps: stepsArr,
                additionalFormInfo: { ...memberInfo }
            };
        }
        case CONFIRM_REVIEW_DETAIL: {
            return {
                ...state,
                reviewDetailConfirm: action.payload.reviewDetailConfirm
            };
        }
        case SAVE_PROGRAMS: {
            return {
                ...state,
                programs: action.payload
            };
        }
        default:
            return state;
    }
};
