import { APIS } from '~/shared/constants/apisConstants';
import httpRequest, { METHODS } from '~/shared/utils/axios';
import { getUserId } from '~/shared/utils/utils';

export const fetchAccessibility = async () => {
    const userId = getUserId();
    let API_URL = APIS.FETCH_ACCESSIBILITY;
    if (userId) {
        API_URL = `${APIS.FETCH_ACCESSIBILITY}?user_id=${userId}`;
    }
    const [response = {}, error] = await httpRequest({
        url: API_URL,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};
export const fetchMilitary = async () => {
    const userId = getUserId();
    let API_URL = APIS.FETCH_MILITARY;
    if (userId) {
        API_URL = `${APIS.FETCH_MILITARY}?user_id=${userId}`;
    }
    const [response = {}, error] = await httpRequest({
        url: API_URL,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};
export const fetchShelter = async () => {
    const userId = getUserId();
    let API_URL = APIS.FETCH_SHELTER;
    if (userId) {
        API_URL = `${APIS.FETCH_SHELTER}?user_id=${userId}`;
    }
    const [response = {}, error] = await httpRequest({
        url: API_URL,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};
export const fetchMiseDetails = async () => {
    const userId = getUserId();
    let API_URL = APIS.FETCH_MISE_DETAILS;
    if (userId) {
        API_URL = `${APIS.FETCH_MISE_DETAILS}?user_id=${userId}`;
    }
    const [response = {}, error] = await httpRequest({
        url: API_URL,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};

export const fetchGender = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_GENDER,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};
export const fetchCitizenSip = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_CITIZENSHIP,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};
export const fetchRelationShip = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_RELATIONSHIP,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};
export const fetchPayFrequency = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_PAY_FREQUENCY,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};
export const fetchRaceEthnic = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_RACE_ETHNIC,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};

export const fetchAllFormData = async () => {
    const [
        accessibility,
        military,
        shelter,
        miseDetail,
        gender,
        citizenShip,
        relationShip,
        payFrequency,
        raceEthnics
    ] = await Promise.all([
        fetchAccessibility(),
        fetchMilitary(),
        fetchShelter(),
        fetchMiseDetails(),
        fetchGender(),
        fetchCitizenSip(),
        fetchRelationShip(),
        fetchPayFrequency(),
        fetchRaceEthnic()
    ]);

    return {
        accessibility: {
            data: accessibility?.res_data?.data?.accessibility || [],
            selectedData: accessibility?.res_data?.data?.selected_values || []
        },
        military: {
            data: military?.res_data?.data?.military || [],
            selectedData: military?.res_data?.data?.selected_values || []
        },
        shelter: {
            data: shelter?.res_data?.data?.shelter || [],
            selectedData: shelter?.res_data?.data?.selected_values || []
        },
        miseDetail: {
            data: miseDetail?.res_data?.data?.misc_household_other || [],
            selectedData: miseDetail?.res_data?.data?.selected_values || []
        },
        gender: gender?.res_data?.data?.gender || [],
        citizenShip: citizenShip?.res_data?.data?.citizenship || [],
        relationShip: relationShip?.res_data?.data?.relationship || [],
        payFrequency: payFrequency?.res_data?.data?.payFrequency || [],
        raceEthnics: raceEthnics?.res_data?.data?.race_ethinic || []
    };
};

const saveEachMember = async (reqParam) => {
    const [response = {}, error] = await httpRequest({
        url: APIS.SAVE_MEMBER_DETAILS,
        method: METHODS.POST,
        body: reqParam
    });
    if (!error) {
        return response;
    }
    return error;
};

const updateEachMember = async (reqParam) => {
    const [response = {}, error] = await httpRequest({
        url: `${APIS.HOUSE_HOLD_MEMBER}/${reqParam?.id}`,
        method: METHODS.PUT,
        body: reqParam
    });
    if (!error) {
        return response;
    }
    return error;
};

export const saveHouseHoldMember = async (data) => {
    const userId = getUserId();
    const { res_data: { data: { race_ethinic: raceEthnicsData = [] } = {} } = {} } =
        await fetchRaceEthnic();

    // eslint-disable-next-line no-unused-vars
    const { activeMember, raceEthnics, ...requestData } = data;

    let requestParam = {
        ...requestData,
        user_account_id: userId,
        is_disabled: JSON.parse(requestData?.is_disabled),
        is_fulltime_student: JSON.parse(requestData?.is_fulltime_student),
        is_student_next_year: JSON.parse(requestData?.is_student_next_year),
        lifetime_sex_offender_reg: JSON.parse(requestData?.lifetime_sex_offender_reg),
        race_ethinic: {
            values: raceEthnicsData.filter((item) => raceEthnics.includes(item.id))
        },
        social_security_card_url: '',
        any_document: true,
        is_file_clear_legible: true,
        dob_certificate_url: '',
        license_url: ''
    };

    if (requestParam?.id) {
        return updateEachMember(requestParam);
    }
    return saveEachMember(requestParam);
};

export const fetchMemberDetail = async () => {
    const userId = getUserId();
    const [response = {}, error] = await httpRequest({
        url: `${APIS.FETCH_MEMBER_DETAIL}/${userId}`,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};

export const fetchAdditionalMemberCount = async () => {
    const userId = getUserId();
    const [response = {}, error] = await httpRequest({
        url: `${APIS.FETCH_MEMBER_NUMBER}/${userId}`,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};

export const getEligiblePrograms = async () => {
    const user_id = getUserId();
    const [response = {}, error] = await httpRequest({
        url: `${APIS.ELIGIBLE_PROGRAMS}`,
        method: METHODS.GET,
        headers: { user_id }
    });
    if (!error) {
        return response;
    }
};

export const saveHouseHoldDetails = async (body) => {
    const user_id = getUserId();
    const [response = {}, error] = await httpRequest({
        url: `${APIS.SAVE_HOUSE_HOLD_DETAILS}`,
        method: METHODS.PUT,
        headers: { user_id },
        body
    });
    if (!error) {
        return response;
    }
};

export const deleteMember = async (memberId) => {
    const [response = {}, error] = await httpRequest({
        url: `${APIS.HOUSE_HOLD_MEMBER}/${memberId}`,
        method: METHODS.DELETE
    });
    if (!error) {
        return response;
    }
};

export const fetchMember = async (memberId) => {
    const [response = {}, error] = await httpRequest({
        url: `${APIS.HOUSE_HOLD_MEMBER}/${memberId}`,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};

export const fetchReviewPreApplication = async () => {
    const user_id = getUserId();
    const [response = {}, error] = await httpRequest({
        url: `${APIS.FETCH_REVIEW_PRE_APPLICATION}/${user_id}`,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};

export const saveProgramsWithTerms = async (data) => {
    const user_id = getUserId();
    const reqParam = {
        user_account_id: user_id,
        ...data
    };

    const [response = {}, error] = await httpRequest({
        url: `${APIS.SAVE_PROGRAM_WITH_TERMS}`,
        method: METHODS.POST,
        body: reqParam
    });

    if (!error) {
        return response;
    }
    return error;
};
