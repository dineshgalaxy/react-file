export const initialState = {
    activeStepIndex: 1,
    infoContinue: false,
    additionalMember: 0,
    memberFormSteps: [],
    activeMember: 1,
    houseHoldFormCount: 1,
    additionalFormInfo: {},
    reviewContinue: false,
    accommodations: {},
    shelterInfo: {},
    militaryInfo: {},
    otherInfo: {},
    reviewDetailConfirm: false,
    programs: []
};

export const STEPS = {
    STEP1: 1,
    STEP2: 2,
    STEP3: 3,
    STEP4: 4,
    STEP5: 5,
    STEP6: 6,
    STEP7: 7,
    STEP8: 8,
    STEP9: 9,
    STEP10: 10
};
export const houseHoldConstants = {
    RESET_FORM: 'RESET_FORM',
    HOUSE_HOLD_ACTIVE_INDEX: 'HOUSE_HOLD_ACTIVE_INDEX',
    HOUSE_HOLD_INFO_CONTINUE: 'HOUSE_HOLD_INFO_CONTINUE',
    HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER: 'HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER',
    HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM: 'HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM',
    HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM: 'HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM',
    SET_ADDITIONAL_FORM_STEP: 'SET_ADDITIONAL_FORM_STEP',
    BACK_ADDITIONAL_FORM_STEP2: 'BACK_ADDITIONAL_FORM_STEP2',
    BACK_ADDITIONAL_FORM_STEP1: 'BACK_ADDITIONAL_FORM_STEP1',
    RESET_ADDITIONAL_MEMBER: 'RESET_ADDITIONAL_MEMBER',
    ADDITIONAL_REVIEW_CONTINUE: 'ADDITIONAL_REVIEW_CONTINUE',
    SAVE_ACCOMMODATIONS: 'SAVE_ACCOMMODATIONS',
    SAVE_SHELTER_INFO: 'SAVE_SHELTER_INFO',
    SAVE_MILITARY_IFO: 'SAVE_MILITARY_IFO',
    SAVE_OTHER_INFO: 'SAVE_OTHER_INFO',
    ADD_MORE_MEMBER: 'ADD_MORE_MEMBER',
    REMOVE_MEMBER: 'REMOVE_MEMBER',
    EDIT_MEMBER: 'EDIT_MEMBER',
    RENDER_EDIT_FORMS: 'RENDER_EDIT_FORMS',
    CONFIRM_REVIEW_DETAIL: 'CONFIRM_REVIEW_DETAIL',
    SAVE_PROGRAMS: 'SAVE_PROGRAMS'
};

export const MEMBER_FORM_FILED = {
    firstName: 'fname',
    middleName: 'mname',
    lastName: 'lname',
    maidenName: 'maiden_name',
    relationShipId: 'relationship_id',
    citizenShipId: 'citizenship_id',
    dateOfBirth: 'dob',
    gender: 'gender_id',
    socialSecurityNumber: 'social_security_number',
    yearlyIncome: 'yearly_income',
    payFrequencyId: 'pay_frequency_id',
    paycheckAmount: 'paycheck_amount',
    isDisabled: 'is_disabled',
    isFulltimeStudent: 'is_fulltime_student',
    isStudentNextYear: 'is_student_next_year',
    lifetimeSexOffenderReg: 'lifetime_sex_offender_reg',
    raceEthnics: 'raceEthnics'
};

export const HOUSE_HOLD_FORMS_COUNTS = {
    FORM1: 1,
    FORM2: 2
};

export const OTHER_FORMS = {
    SAVE_ACCOMMODATION_FORM_INFO: 'saveAccommodation',
    SAVE_SHELTER_FORM_INFO: 'saveShelterInfo',
    SAVE_MILITARY_FORM_INFO: 'saveMilitaryInfo',
    SAVE_OTHER_FORM_INFO: 'saveOtherInfo'
};

export const statusCardData = {
    title: "It doesn't look like you're a candidate for any programs.",
    subTitle:
        "We're sorry. based on the information you've provided you don't meet the criteria for any of our programs.",
    subTitle2:
        'You can review the eligibility criteria and learn more about the programs here. If you think there is a mistake on eligibility. You can contact us for help.',
    showButton: true,
    buttonText: 'Exit to Dashboard',
    buttonType: 'white',
    iconName: 'thumbs-down',
    iconStatus: 'failed'
};
