import {
    Box,
    Button,
    Checkbox,
    FormControl,
    FormControlLabel,
    FormHelperText
} from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { useSelector } from 'react-redux';
import useForm from '~/shared/customHooks/useForm';
import useStyles from '../HouseholdStyle';
import { onValidate } from './HouseholdAccessibilityNeedsUtils';

/**
 * Name : HouseholdAccessibilityNeeds
 * Desc : Render HouseholdAccessibilityNeeds
 */

const HouseholdAccessibilityNeeds = ({ title, onClickContinue, width, accessibility }) => {
    const classes = useStyles();
    const { accommodations: defaultValue } = useSelector((state) => state.houseHoldDetails);
    const initialValue = {
        ...defaultValue
    };

    const {
        values,
        handleOnSelect,
        handleBlur,
        handleSubmit,
        errors: { error }
    } = useForm(initialValue, onValidate);

    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onClickContinue(values);
        }
    };

    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337} mb={2}>
                <Box fontSize="h5.fontSize" lineHeight="35px" color="primary.light" mb={1.5}>
                    {title}
                </Box>
            </Box>

            {error ? <FormHelperText>{error}</FormHelperText> : null}
            <form onSubmit={(e) => handleFormSubmit(e)}>
                <Box className={classes.textAlign} width="100%">
                    <Box mb={1}>
                        {accessibility.map(({ type, id }) => (
                            <FormControl fullWidth className="noMargin" key={id}>
                                <FormControlLabel
                                    control={
                                        <Checkbox
                                            inputProps={{ 'aria-label': 'primary checkbox' }}
                                        />
                                    }
                                    checked={!!values[id]}
                                    name={id}
                                    value={id}
                                    label={type}
                                    onChange={handleOnSelect}
                                    onBlur={handleBlur}
                                />
                            </FormControl>
                        ))}
                    </Box>

                    <Box className={classes.xsBtn}>
                        <Button
                            type="submit"
                            size="large"
                            color="primary"
                            variant="contained"
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                            Next
                        </Button>
                    </Box>
                </Box>
            </form>
        </Box>
    );
};
HouseholdAccessibilityNeeds.propTypes = {
    title: PropTypes.string,
    onClickContinue: PropTypes.func,
    width: PropTypes.string,
    accessibility: PropTypes.array
};
export default withWidth()(HouseholdAccessibilityNeeds);
