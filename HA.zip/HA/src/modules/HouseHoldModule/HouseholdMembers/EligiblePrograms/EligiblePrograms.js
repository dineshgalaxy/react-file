/* eslint-disable react-hooks/exhaustive-deps */
import { Box, Button, Card, Checkbox, Link } from '@material-ui/core';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import CommonCard from '~/shared/components/CommonCard';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import Indicators from '~/shared/components/Indicators';
import WizardHeader from '~/shared/components/WizardHeader';

const EligiblePrograms = ({ programs, onSubmit }) => {
    const { programs: selectedProgram } = useSelector((state) => state.houseHoldDetails);
    const [selectedPrograms, setSelectedPrograms] = useState([]);
    const [showDetailProgramId, setShowDetailProgramId] = useState('');

    useEffect(() => {
        const allProgramsIds = programs.map((data) => data.id);
        if (selectedProgram?.length > 0) {
            setSelectedPrograms(selectedProgram);
        } else {
            setSelectedPrograms(allProgramsIds);
        }
    }, []);

    const handleChange = (e, id) => {
        if (e.target.checked && !selectedPrograms.includes(id)) {
            setSelectedPrograms([id, ...selectedPrograms]);
        } else if (!e.target.checked) {
            let checkedPrograms = selectedPrograms.filter((program) => id !== program);
            setSelectedPrograms(checkedPrograms);
        }
    };

    const handleShowDetails = (id) => {
        if (id === showDetailProgramId) {
            setShowDetailProgramId('');
        } else {
            setShowDetailProgramId(id);
        }
    };

    return (
        <>
            <WizardHeader>
                <Box textAlign="center" mt={1} pb={2}>
                    <Box mb={6}>
                        <Indicators status="success" iconColor="indigo" />
                    </Box>
                    <Box
                        fontSize="h3.fontSize"
                        color="common.white"
                        fontFamily="fontFamily.bold"
                        mb={3}
                        lineHeight="32px">
                        {`We’ve found that you may be a good a candidate for ${programs.length} programs.`}
                    </Box>
                    <Box fontSize="h6.fontSize" color="common.white">
                        Based on the criteria you entered, you’re eligible for the selected programs
                        below. Continue below to preapply for all programs, or uncheck any programs
                        you do not wish to preapply for.
                    </Box>
                </Box>
            </WizardHeader>
            <CommonCard bgColor="transparent" showBackBtn={false}>
                {programs?.map((data) => {
                    const { id, program, description, waitlist_type } = data;
                    return (
                        <Box mb={3} key={id}>
                            <Card>
                                <Box display="flex" alignItems="flex-start" p={2.5} minHeight={96}>
                                    <Box
                                        display="flex"
                                        justifyContent="flex-end"
                                        minWidth={38}
                                        flex="0 0 38px"
                                        mt={1.25}>
                                        <Checkbox
                                            checked={selectedPrograms.includes(id)}
                                            onChange={(e) => handleChange(e, id)}
                                        />
                                    </Box>
                                    <Box
                                        ml={0.5}
                                        flexGrow={2}
                                        display="flex"
                                        flexDirection="column"
                                        justifyContent="center">
                                        <Box
                                            color="primary.dark"
                                            fontSize="h6.fontSize"
                                            fontFamily="fontFamily.medium">
                                            {program}
                                        </Box>
                                        <Box
                                            color="primary.light"
                                            fontSize="md.fontSize"
                                            fontFamily="fontFamily.regular">
                                            {waitlist_type}
                                        </Box>

                                        {id === showDetailProgramId && (
                                            <Box
                                                color="primary.extraLight"
                                                fontSize="md.fontSize"
                                                fontFamily="fontFamily.regular"
                                                mb={1}
                                                mt={1}>
                                                {description}
                                            </Box>
                                        )}

                                        <Box
                                            color="primary.mian"
                                            fontSize="md.fontSize"
                                            fontFamily="fontFamily.regular">
                                            <Link
                                                component="button"
                                                color="primary"
                                                underline="none"
                                                onClick={() => handleShowDetails(id)}>
                                                {id !== showDetailProgramId
                                                    ? 'Show Details'
                                                    : 'Hide Details'}
                                            </Link>
                                        </Box>
                                    </Box>
                                </Box>
                            </Card>
                        </Box>
                    );
                })}
            </CommonCard>
            <Box display="flex" justifyContent="center">
                <Button
                    size="large"
                    color="primary"
                    variant="contained"
                    onClick={() => onSubmit(selectedPrograms)}>
                    Submit Preapplications
                </Button>
            </Box>
            <ExitConfirmation isExitText={true} exitText="OR CANCEL" />
        </>
    );
};

EligiblePrograms.propTypes = {
    programs: PropTypes.array,
    onSubmit: PropTypes.func
};

export default EligiblePrograms;
