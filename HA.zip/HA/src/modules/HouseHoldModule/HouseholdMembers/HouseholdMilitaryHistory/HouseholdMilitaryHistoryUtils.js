export const onValidate = (values) => {
    const selectedValue = Object.values(values).includes(true);
    const errors = {};
    if (!selectedValue) {
        errors.error = 'Please select military info.'
    }
    return errors;
};
