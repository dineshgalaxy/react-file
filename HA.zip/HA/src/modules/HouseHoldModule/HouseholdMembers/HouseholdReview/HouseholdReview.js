import { Box, Checkbox, FormControl, FormControlLabel } from '@material-ui/core';
import React from 'react';

/**
 * Name : HouseholdReview
 * Desc : Render HouseholdReview
 */

const HouseholdReview = () => {
    return (
        <Box mb={2}>
            <Box mb={2}>
                <FormControl fullWidth className="noMargin">
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={true}
                                inputProps={{ 'aria-label': 'primary checkbox' }}
                            />
                        }
                        label="One or more family members is elderly (over the age of 62)"
                    />
                </FormControl>
            </Box>
            <Box mb={2}>
                <FormControl fullWidth className="noMargin">
                    <FormControlLabel
                        control={
                            <Checkbox
                                className="extraLightLabel"
                                checked={true}
                                inputProps={{ 'aria-label': 'primary checkbox' }}
                            />
                        }
                        label="One or more family members is currently enrolled in K-12 school"
                    />
                </FormControl>
            </Box>
            <Box mb={2}>
                <FormControl fullWidth className="noMargin">
                    <FormControlLabel
                        control={
                            <Checkbox
                                className="extraLightLabel"
                                checked={true}
                                inputProps={{ 'aria-label': 'primary checkbox' }}
                            />
                        }
                        label="One or more family members is currently enrolled in a college or university"
                    />
                </FormControl>
            </Box>
            <Box mb={2}>
                <FormControl fullWidth className="noMargin">
                    <FormControlLabel
                        control={
                            <Checkbox
                                className="extraLightLabel"
                                checked={true}
                                inputProps={{ 'aria-label': 'primary checkbox' }}
                            />
                        }
                        label="One or more family members is a victim of domestic violence"
                    />
                </FormControl>
            </Box>
            <Box mb={2}>
                <FormControl fullWidth className="noMargin">
                    <FormControlLabel
                        control={
                            <Checkbox
                                className="extraLightLabel"
                                checked={true}
                                inputProps={{ 'aria-label': 'primary checkbox' }}
                            />
                        }
                        label="None of the above"
                    />
                </FormControl>
            </Box>
        </Box>
    );
};

export default HouseholdReview;
