export { default } from './HouseholdMiscDetails';
