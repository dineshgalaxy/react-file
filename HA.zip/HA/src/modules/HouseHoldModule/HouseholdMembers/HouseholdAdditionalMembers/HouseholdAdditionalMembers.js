import {
    Box,
    Button,
    FormControl,
    FormHelperText,
    InputLabel,
    MenuItem,
    Select
} from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import ExpandMoreOutlinedIcon from '@material-ui/icons/ExpandMoreOutlined';
import clsx from 'clsx';
import PropTypes from 'prop-types';
import React from 'react';
import { onValidateAdditionalMemberField } from '~/modules/HouseHoldModule/Utils/HouseHoldUtils';
import useForm from '~/shared/customHooks/useForm';
import useStyles from '../HouseholdStyle';

/**
 * Name : HouseholdAdditionalMembers
 * Desc : Render HouseholdAdditionalMembers
 */
const FIELDS = {
    ADDITIONAL_MEMBER: 'additionalMember'
};
const HouseholdAdditionalMembers = ({
    title,
    selectedMember,
    onClickContinue,
    width,
    memberList
}) => {
    const classes = useStyles();
    const initialValue = {
        additionalMember: selectedMember
    };
    const { values, handleOnChange, handleSubmit, errors, handleBlur } = useForm(
        initialValue,
        onValidateAdditionalMemberField
    );

    const handleFormSubmit = async (event) => {
        const { submittedError, submitted } = await handleSubmit(event);
        if (Object.keys(submittedError).length === 0 && submitted) {
            onClickContinue(values);
        }
    };
    return (
        <Box className={classes.flex} width="100%">
            <Box maxWidth={width === 'xs' || width === 'sm' ? '100%' : 337} mb={1}>
                <Box fontSize="h5.fontSize" lineHeight="35px" color="primary.light" mb={1.5}>
                    {title}
                </Box>
            </Box>
            <Box className={classes.textAlign} width="100%">
                <form onSubmit={(e) => handleFormSubmit(e)}>
                    <Box mb={2} mt={2.5}>
                        <FormControl
                            variant="filled"
                            fullWidth
                            error={!!errors[FIELDS.ADDITIONAL_MEMBER]}>
                            <InputLabel id="demo-simple-select-label">
                                Select additional member
                            </InputLabel>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                IconComponent={ExpandMoreOutlinedIcon}
                                displayEmpty
                                onChange={handleOnChange}
                                onBlur={handleBlur}
                                name={FIELDS.ADDITIONAL_MEMBER}
                                value={values[FIELDS.ADDITIONAL_MEMBER]}>
                                <MenuItem value="" disabled>
                                    Select
                                </MenuItem>
                                {memberList &&
                                    memberList.map(({ id, no_of_members }) => (
                                        <MenuItem value={no_of_members} key={id}>
                                            {`${no_of_members} additional member`}
                                        </MenuItem>
                                    ))}
                            </Select>
                            {errors[FIELDS.ADDITIONAL_MEMBER] ? (
                                <FormHelperText>{errors[FIELDS.ADDITIONAL_MEMBER]}</FormHelperText>
                            ) : (
                                ''
                            )}
                        </FormControl>
                    </Box>

                    <Box className={classes.xsBtn}>
                        <Button
                            size="large"
                            color="primary"
                            variant="contained"
                            type="submit"
                            fullWidth={width === 'xs' || width === 'sm' ? true : false}
                            className={clsx(width === 'xs' || width === 'sm' ? 'semiBorder' : '')}>
                            Next
                        </Button>
                    </Box>
                </form>
            </Box>
        </Box>
    );
};
HouseholdAdditionalMembers.propTypes = {
    title: PropTypes.string,
    onClickContinue: PropTypes.func,
    width: PropTypes.string,
    memberList: PropTypes.array,
    selectedMember: PropTypes.number
};
export default withWidth()(HouseholdAdditionalMembers);
