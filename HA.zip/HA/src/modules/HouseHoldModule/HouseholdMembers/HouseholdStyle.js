import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    flex: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0 96px',
        [theme.breakpoints.down('sm')]: {
            flexDirection: 'column',
            padding: '0 0 48px 0',
            alignItems: 'flex-start'
        }
    },
    xsBtn: {
        [theme.breakpoints.down('sm')]: {
            position: 'absolute',
            bottom: '0',
            left: '0',
            right: '0',
            width: '100%'
        }
    },
    textAlign: {
        maxWidth: '310px',
        [theme.breakpoints.down('sm')]: {
            maxWidth: '100%'
        }
    },
    datePicker:{
            border: `1px solid ${theme.palette.primary.extraLight}`,
            borderRadius: '16px',
            backgroundColor: theme.common.white,
            height: '52px',
            padding:"0 16px",
            '&:hover': {
                backgroundColor: theme.common.white
            },
            "& .MuiInput-underline": {
                '&:before, &:after': {
                    border: 'none'
                },
                '&:hover': {
                    '&:before, &:after': {
                        border: 'none'
                    }
                }
            },
            "& .MuiInputBase-input":{
                color: theme.palette.primary.light,
                fontSize: "17px",
                paddingBottom:"0",
                paddingTop:"9px",
            },
            "& .MuiInputLabel-formControl":{
                top:'7px'
            }
    }
}));

export default useStyles;
