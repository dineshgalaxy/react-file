import {
    Box,
    Button,
    Container,
    Dialog,
    DialogContent,
    DialogTitle,
    FormControl,
    IconButton,
    MenuItem,
    Select
} from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import ExpandMoreOutlinedIcon from '@material-ui/icons/ExpandMoreOutlined';
import FeatherIcon from 'feather-icons-react';
import PropTypes from 'prop-types';
import React, { useEffect, useState } from 'react';
import GetStarted from '~/modules/Home/GetStarted';
import SplashScreen from '~/modules/Home/SplashScreen';
import HelpCenter from '~/shared/components/HelpCenter';
import withLoader from '~/shared/components/hoc/withLoader';
import HomeImage from '~/shared/components/HomeImage';
import { Layout } from '~/shared/components/Layout';
import ViewPrograms from '~/shared/components/ViewPrograms';
import { getLocalStorage, setLocalStorage } from '~/shared/utils/storeManager';
/**
 * Name : Home
 * Desc: Render Home
 **/

function Home({ width }) {
    const [showSplash, setShowSplash] = useState(getLocalStorage('languageModal') ? false : true);
    const [openDialog, setOpenDialog] = useState(false);
    const [select, setSelect] = useState('');
    const languageSelect = [
        {
            label: "English",
            value: "en"
        },

        {
            label: "Español",
            value: "es"
        }
    ]

    const handleClose = () => {
        setOpenDialog(false);
    };

    const handleChangeSelectBox = (event) => {
        setSelect(event.target.value);
        window.Localize.setLanguage(event.target.value);
    };

    useEffect(() => {
        if (!showSplash && !getLocalStorage('languageModal')) {
            setOpenDialog(true);
            setLocalStorage('languageModal', true);
        }
    }, [showSplash]);

    useEffect(() => {
        const splashScreen = setTimeout(() => {
            setShowSplash(false);
            setSelect(localStorage.getItem("ljs-lang"));
        }, 2000);
        return () => clearTimeout(splashScreen);
    });

    return (
        <>
            {showSplash ? (
                <SplashScreen />
            ) : (
                <Layout>
                    <HomeImage />
                    <Container>
                        <GetStarted />
                        <Box
                            pt={width === 'xs' || width === 'sm' ? 6 : 12}
                            pb={width === 'xs' || width === 'sm' ? 4 : 12}>
                            <ViewPrograms />
                        </Box>
                    </Container>
                    <HelpCenter />
                </Layout>
            )}
            <Dialog onClose={handleClose} aria-labelledby="simple-dialog-title" open={openDialog}>
                <DialogTitle id="simple-dialog-title">
                    <IconButton aria-label="close" onClick={handleClose}>
                        <FeatherIcon icon="x" strokeWidth={3} color="#2F0B7C" size="22" />
                    </IconButton>
                </DialogTitle>
                <DialogContent>
                    <Box textAlign="center" pt={2.5}>
                        <Box
                            fontSize="h3.fontSize"
                            fontFamily="fontFamily.bold"
                            color="primary.light"
                            pb={1}>
                            Select Your Language
                        </Box>
                        <Box fontSize="lg.fontSize" fontStyle="italic" color="primary.extraLight">
                            Choose Your Language
                        </Box>
                    </Box>
                    <Box>
                        <Box maxWidth={256} mx="auto" py={3} className="withoutLabel">
                            <FormControl variant="filled" fullWidth>
                                <Select
                                    labelId="demo-simple-select-label"
                                    id="demo-simple-select"
                                    IconComponent={ExpandMoreOutlinedIcon}
                                    value={select}
                                    onChange={handleChangeSelectBox}>
                                    {languageSelect.map((option) => (
                                        <MenuItem
                                            value={option.value}
                                            key={option.label}>{option.label}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Box>
                    </Box>
                </DialogContent>
                <Box>
                    <Button
                        fullWidth
                        size="large"
                        color="secondary"
                        className="semiBorder"
                        variant="contained"
                        onClick={handleClose}>
                        Continue
                    </Button>
                </Box>
            </Dialog>
        </>
    );
}
Home.propTypes = {
    width: PropTypes.string
};
export default withWidth()(withLoader(Home));
