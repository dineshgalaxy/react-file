export { default } from './SplashScreen';
