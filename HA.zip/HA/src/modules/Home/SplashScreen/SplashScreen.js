import { Avatar, Box } from '@material-ui/core';
import React from 'react';
import useStyles from './SplashScreenStyles';

/**
 * Name: SplashScreen
 * Desc: Render SplashScreen
 */

const SplashScreen = () => {
    const classes = useStyles();

    return (
        <Box className={classes.root} style={{ backgroundImage: `url('/splash.svg')` }}>
            <Box display="flex" alignItems="center" flexDirection="column">
                <Avatar alt="logo" src="/clientLogo.svg" />
                <Box
                    fontSize={31}
                    color="common.white"
                    fontFamily="fontFamily.extraBold"
                    mt={3.5}>
                    AppName
                </Box>
                <Box mt={.75} mb={.75} fontSize="h6.fontSize" color="common.white" fontFamily="fontFamily.medium">
                    Tenant Portal
                </Box>
                {/* <Box fontSize="h6.fontSize" color="common.white" fontStyle="italic">
                    Portal de Inquilinos
                </Box> */}
            </Box>
        </Box>
    );
};

export default SplashScreen;
