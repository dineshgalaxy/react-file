import { Box, Button, Card, Grid, Link } from '@material-ui/core';
import withWidth from '@material-ui/core/withWidth';
import PropTypes from 'prop-types';
import React from 'react';
import { ChevronRight } from 'react-feather';
import { ROUTES } from '~/shared/constants/routesConstants';
import useStyles from './GetStartedStyles';

/**
 * Name: GetStarted
 * Desc: Render GetStarted
 */

const GetStarted = ({ width }) => {
    const { CHECK_ELIGIBILITY } = ROUTES;
    const classes = useStyles();

    return (
        <Card
            className={classes.customCard}
            style={{
                marginTop: width === 'xs' || width === 'sm' ? '-50px' : '-220px'
            }}>
            <Box
                pt={width === 'xs' || width === 'sm' ? 0 : 5}
                pb={width === 'xs' || width === 'sm' ? 10.5 : 5}
                pl={width === 'xs' || width === 'sm' ? 3 : 15}
                pr={width === 'xs' || width === 'sm' ? 3 : 15}
                position="relative">
                <Grid container spacing={3} alignItems="center">
                    <Grid item xs={12} md={6}>
                        <Box pb={width === 'xs' || width === 'sm' ? 0 : 5}>
                            <Box
                                fontSize={
                                    width === 'xs' || width === 'sm' ? 'h3.fontSize' : 'h1.fontSize'
                                }
                                lineHeight={width === 'xs' || width === 'sm' ? 'normal' : '54px'}
                                color="primary.light"
                                fontFamily="fontFamily.extraBold"
                                maxWidth="410px"
                                mb={width === 'xs' || width === 'sm' ? 0 : 0}
                                mt={width === 'xs' || width === 'sm' ? 5 : 0}>
                                Take the next step toward more affordable housing.
                            </Box>
                        </Box>
                        <Box
                            mt={width === 'xs' || width === 'sm' ? 1 : 0}
                            ml={width === 'xs' || width === 'sm' ? -3 : 0}
                            mr={width === 'xs' || width === 'sm' ? -3 : 0}
                            className={classes.mobileBtn}>
                            <Link href={CHECK_ELIGIBILITY.ROUTE} underline="none">
                                <Button
                                    size="large"
                                    color="secondary"
                                    variant="contained"
                                    fullWidth={width === 'xs' || width === 'sm' ? true : false}
                                    className={
                                        width === 'xs' || width === 'sm' ? 'semiBorder' : ''
                                    }>
                                    Get Started
                                </Button>
                            </Link>
                        </Box>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        {[
                            'Apply for housing assistance',
                            'Find out if you’re eligibile for assistance',
                            'Check on or update your application',
                            'Learn more about our assistance programs'
                        ].map((item) => {
                            return (
                                <Box
                                    display="flex"
                                    alignItems="center"
                                    justifyContent="space-between"
                                    py={width === 'xs' || width === 'sm' ? 2.5 : 4}
                                    className={classes.cardLinks}
                                    key={item}>
                                    <Link
                                        href="#"
                                        underline="none"
                                        className={classes.cardLinksText}>
                                        <Box
                                            display="flex"
                                            alignItems="center"
                                            justifyContent="space-between">
                                            <Box
                                                mr={1}
                                                maxWidth="400px"
                                                color="primary.main"
                                                fontSize={
                                                    width === 'xs' || width === 'sm'
                                                        ? 'h6.fontSize'
                                                        : 'h5.fontSize'
                                                }
                                                fontFamily="fontFamily.medium">
                                                {item}
                                            </Box>

                                            <Box display="flex">
                                                <ChevronRight
                                                    color="Indigo"
                                                    size={
                                                        width === 'xs' || width === 'sm' ? 17 : 24
                                                    }
                                                />
                                            </Box>
                                        </Box>
                                    </Link>
                                </Box>
                            );
                        })}
                    </Grid>
                </Grid>
            </Box>
        </Card>
    );
};
GetStarted.propTypes = {
    width: PropTypes.string
};
export default withWidth()(GetStarted);
