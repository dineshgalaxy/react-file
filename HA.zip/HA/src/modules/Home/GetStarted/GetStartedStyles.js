import { makeStyles } from '@material-ui/core/styles';

const useStyles = makeStyles((theme) => ({
    cardLinks: {
        '&:not(:last-child)': {
            borderBottom: `1px solid ${theme.common.gray}`
        }
    },
    customCard: {
        padding: 0,
        position: 'relative',
        zIndex: '1'
    },
    cardLinksText: {
        width: '100%'
    },
    mobileBtn:{
        [theme.breakpoints.down('sm')]: {
            position:'absolute',
            bottom:'0',
            left:'0',
            right:'0'
        },
    }
}));

export default useStyles;
