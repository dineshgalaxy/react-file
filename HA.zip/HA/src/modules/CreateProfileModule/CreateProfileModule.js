import { Box, Card, LinearProgress } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Router from 'next/router';
import PropTypes from 'prop-types';
import { useEffect, useState } from 'react';
import { Info } from 'react-feather';
import { useDispatch, useSelector } from 'react-redux';
import {
    fetchContactByList,
    fetchPhoneTypeList,
    fetchStateList,
    handleSignUP
} from '~/modules/CreateProfileModule/Utils/CreateProfileApiUtils';
import AccountCredentials from '~/shared/components/ApplicantForm/AccountCredentials';
import ApplicantContact from '~/shared/components/ApplicantForm/ApplicantContact';
import ApplicantDetails from '~/shared/components/ApplicantForm/ApplicantDetails';
import ApplicantProxySelection from '~/shared/components/ApplicantForm/ApplicantProxySelection';
import CommonCard from '~/shared/components/CommonCard';
import ExitConfirmation from '~/shared/components/ExitConfirmation';
import withLoader from '~/shared/components/hoc/withLoader';
import InformationCard from '~/shared/components/InformationCard';
import StatusCard from '~/shared/components/StatusCard';
import WizardHeader from '~/shared/components/WizardHeader';
import { ROUTES } from '~/shared/constants/routesConstants';
import { setActiveStepIndex } from './Utils/CreateProfileAction';
import { STEPS } from './Utils/CreateProfileConstants';
import { getProgressValue } from './Utils/CreateProfileUtils';

/**
 * Render CreateProfileModule
 * @param {func} setLoading
 * @returns Component
 */

const useStyles = makeStyles((theme) => ({
    boxInfo: {
        position: 'relative',
        paddingLeft: theme.spacing(2),
        paddingBottom: theme.spacing(0.4),
        '&:before': {
            content: '""',
            width: '4px',
            height: '4px',
            background: theme.palette.primary.extraLight,
            position: 'absolute',
            left: '0',
            top: '10px',
            borderRadius: '50%'
        }
    }
}));

const CreateProfileModule = ({ setLoading }) => {
    const { HOME, CHECK_ELIGIBILITY, HOUSE_HOLD_DETAIL } = ROUTES;
    const dispatch = useDispatch();
    const [createFormDetails, setCreateFormDetails] = useState({
        stateList: [],
        phoneTypeList: [],
        contactByList: []
    });

    useEffect(() => {
        (async () => {
            setLoading(true);
            const [states, phone_types, contact_options] = await Promise.all([
                fetchStateList(),
                fetchPhoneTypeList(),
                fetchContactByList()
            ]);
            setCreateFormDetails({
                ...createFormDetails,
                stateList: states?.res_data?.data,
                phoneTypeList: phone_types?.res_data?.data,
                contactByList: contact_options?.res_data?.data
            });
            setLoading(false);
        })(); //Self-Invoking Functions
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const { activeStepIndex, ...restValue } = useSelector((state) => state.profileSteps);

    const handleNext = async ({ ...data }) => {
        setLoading(true);
        const { res_data: { status_code: statusCode, data: { userDetails = {} } = {} } = {} } =
            await handleSignUP({ ...restValue, ...data });
        if (statusCode === 200) {
            setLoading(false);
            if (userDetails?.access_token) {
                localStorage.setItem('user_details', JSON.stringify(userDetails));
                dispatch(setActiveStepIndex(activeStepIndex + 1));
            }
            return true;
        }
    };

    const handleClickContinue = async (fn, { ...data }) => {
        if (typeof fn === 'function') {
            dispatch(fn({ ...data }));
        }
        if (activeStepIndex < Object.keys(STEPS).length) {
            dispatch(setActiveStepIndex(activeStepIndex + 1));
        } else {
            handleNext(data);
        }
    };
    const handleClickBack = () => {
        if (activeStepIndex !== STEPS.STEP1) {
            dispatch(setActiveStepIndex(activeStepIndex - 1));
        } else {
            Router.push(CHECK_ELIGIBILITY.ROUTE);
        }
    };

    const handleExitClick = () => {
        Router.push(HOME.ROUTE);
    };

    const handleNextClick = () => {
        Router.push(HOUSE_HOLD_DETAIL.ROUTE);
    };

    return (
        <>
            <LinearProgress variant="determinate" value={getProgressValue(activeStepIndex)} />
            {activeStepIndex === STEPS.STEP1 ? (
                <CommonCard
                    onClickBack={handleClickBack}
                    bgColor="primary"
                    isFullPage={true}
                    showImage={true}>
                    <InformationCard
                        title="Okay, we'll need to gather some more information from you."
                        onClickContinue={handleClickContinue}
                        textAlign="left"
                        content={
                            <>
                                <Box
                                    fontSize="h6.fontSize"
                                    color="primary.extraLight"
                                    lineHeight="26px"
                                    mb={2.5}>
                                    In order to find out exactly which program you may qualify for,
                                    we'll ask some more question about your household, including:
                                </Box>
                                <Card>
                                    <Box
                                        px={3}
                                        py={3.5}
                                        color="primary.extraLight"
                                        fontSize="h6.fontSize">
                                        {[
                                            'Your personal details',
                                            'Your contact information',
                                            'Household member details'
                                        ].map((item, index) => (
                                            <Box
                                                key={`${item}_${index}`}
                                                className={classes.boxInfo}>
                                                {item}
                                            </Box>
                                        ))}
                                        <Box fontSize="md.fontSize" color="primary.main" pt={1.5}>
                                            {'Takes about: 25 minutes'}
                                        </Box>
                                    </Box>
                                </Card>
                                <Box
                                    fontSize="h6.fontSize"
                                    color="primary.extraLight"
                                    lineHeight="26px"
                                    mt="30px"
                                    mb={3}>
                                    Then, you'll be able to submit a PreApplication to those
                                    programs-the first step toward getting housing assistance.
                                </Box>
                            </>
                        }
                    />
                </CommonCard>
            ) : null}
            {activeStepIndex === STEPS.STEP2 ? (
                <>
                    <WizardHeader onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack}>
                        <ApplicantProxySelection
                            title="Are you applying for yourself or assisting someone else?"
                            onClickContinue={handleClickContinue}
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} onExitClick={handleExitClick} />
                </>
            ) : null}
            {activeStepIndex === STEPS.STEP3 ? (
                <>
                    <WizardHeader onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack}>
                        <ApplicantDetails
                            title="Enter your personal details below."
                            onClickContinue={handleClickContinue}
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} />
                </>
            ) : null}
            {activeStepIndex === STEPS.STEP4 ? (
                <>
                    <WizardHeader onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack}>
                        <ApplicantContact
                            title="Enter your contact information below."
                            onClickContinue={handleClickContinue}
                            showFaceBookLoginButton={false}
                            stateList={createFormDetails?.stateList}
                            phoneTypeList={createFormDetails?.phoneTypeList}
                            contactByList={createFormDetails?.contactByList}
                        />
                    </CommonCard>
                    <ExitConfirmation isExitText={true} />
                </>
            ) : null}
            {activeStepIndex === STEPS.STEP5 ? (
                <>
                    <WizardHeader onClickBack={handleClickBack} />
                    <CommonCard onClickBack={handleClickBack}>
                        <AccountCredentials
                            showFaceBookLoginButton={true}
                            onClickContinue={handleClickContinue}
                            title={
                                <>
                                    <Box mb={2}>
                                        Create a password that will be used to access your account.
                                    </Box>
                                    <Box fontSize="h6.fontSize" lineHeight="26px" mb={3}>
                                        Use 8 or more characters with a mix of letters, numbers, and
                                        symbols.
                                    </Box>
                                </>
                            }
                        />
                    </CommonCard>

                    <Box maxWidth="1008px" margin="0 auto">
                        <Box mt={5} margin="24px">
                            <Box display="flex" alignItems="center" mb={1}>
                                <Box mr={1} display="flex">
                                    <Info color="Indigo" size={21} />
                                </Box>
                                <Box
                                    color="primary.light"
                                    fontSize="h5.fontSize"
                                    fontFamily="fontFamily.medium">
                                    Your Information
                                </Box>
                            </Box>
                            <Box color="primary.extraLight" fontSize="md.fontSize">
                                HACEP will not keep or store your password. Keep your password safe
                                so you may access your account alter.
                            </Box>
                        </Box>
                    </Box>
                    <ExitConfirmation isExitText={true} />
                </>
            ) : null}
            {activeStepIndex > Object.keys(STEPS).length ? (
                <CommonCard onClickBack={handleClickBack} isStatusCard={true} isFullPage={true}>
                    <StatusCard
                        iconStatus="success"
                        iconColor="indigo"
                        iconName="user"
                        showButton
                        title="We've created your account and you may proceed with your pre-application."
                        subTitle2="Take a moment to note the email and password you used for this account. These credentials will be needed to access the application later on."
                        buttonText="Continue"
                        onClickContinue={handleNextClick}
                        onExitClick={handleExitClick}
                    />
                </CommonCard>
            ) : null}
        </>
    );
};

CreateProfileModule.propTypes = {
    setLoading: PropTypes.func
};
export default withLoader(CreateProfileModule);
