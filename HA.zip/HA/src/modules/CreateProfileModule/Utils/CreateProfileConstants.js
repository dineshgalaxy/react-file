export const initialState = {
    activeStepIndex: 1
};

export const STEPS = {
    STEP1: 1,
    STEP2: 2,
    STEP3: 3,
    STEP4: 4,
    STEP5: 5
};

export const profileConstants = {
    RESET_FORM: 'RESET_FORM',
    PROFILE_ACTIVE_INDEX: 'PROFILE_ACTIVE_INDEX',
    SAVE_PROFILE: 'SAVE_PROFILE',
    SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME'
};
