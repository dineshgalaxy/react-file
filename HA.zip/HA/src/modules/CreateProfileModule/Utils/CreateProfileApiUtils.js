import { APIS } from '~/shared/constants/apisConstants';
import httpRequest, { METHODS } from '~/shared/utils/axios';

export const handleSignUP = async (profile = {}) => {
    const { user_profile_data = {}, password } = profile;
    const no_of_members = localStorage.getItem('family_members_id')
    const family_income = parseFloat(localStorage.getItem('amount'))
    
    const requestBody = {
        password, 
        no_of_members, 
        family_income, 
        ...user_profile_data
    }
    requestBody.is_proxy = (requestBody.is_proxy === "true" ? true : false)

    const [response = {}, error] = await httpRequest({
        url: APIS.SIGN_UP_URL,
        method: METHODS.POST,
        body: requestBody
    });
    if (!error) {
        return response;
    }
};

export const fetchStateList = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_STATE_URL,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};

export const fetchPhoneTypeList = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_PHONE_TYPE_URL,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};

export const fetchContactByList = async () => {
    const [response = {}, error] = await httpRequest({
        url: APIS.FETCH_CONTACT_BY_URL,
        method: METHODS.GET
    });
    if (!error) {
        return response;
    }
};
