import { profileConstants } from './CreateProfileConstants';

const { PROFILE_ACTIVE_INDEX, SAVE_PROFILE } = profileConstants;

export const setActiveStepIndex = (payload) => {
    return {
        type: PROFILE_ACTIVE_INDEX,
        payload
    };
};

export const saveProfile = (payload) => {
    return {
        type: SAVE_PROFILE,
        payload
    };
};