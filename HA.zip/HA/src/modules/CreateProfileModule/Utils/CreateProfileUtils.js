export const getProgressValue = (activeIndex) => {
    return Math.ceil(16.66 * activeIndex);
};