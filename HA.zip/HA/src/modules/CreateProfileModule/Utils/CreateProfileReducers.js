import { initialState, profileConstants } from './CreateProfileConstants';

const { RESET_FORM, PROFILE_ACTIVE_INDEX, SAVE_PROFILE } = profileConstants;

export const CreateProfile = (state = initialState, action) => {
    switch (action.type) {
        case PROFILE_ACTIVE_INDEX: {
            return {
                ...state,
                activeStepIndex: action.payload
            };
        }
        case SAVE_PROFILE: {
            return {
                ...state,
                user_profile_data: {...state?.user_profile_data, ...action.payload}
            };
        }
        case RESET_FORM: {
            return {
                ...initialState
            };
        }

        default:
            return state;
    }
};
