import {
    Avatar,
    Box,
    Button,
    Card,
    Checkbox,
    Dialog,
    DialogContent,
    DialogTitle,
    FormControl,
    FormControlLabel,
    FormLabel,
    Grid,
    IconButton,
    InputAdornment,
    Link,
    MenuItem,
    Radio,
    RadioGroup,
    Select,
    Switch,
    TextField,
    Typography
} from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';
import ExpandMoreOutlinedIcon from '@material-ui/icons/ExpandMoreOutlined';
import React, { useState } from 'react';
import { AlertTriangle } from 'react-feather';
import MainHeader from 'shared/components/Header/MainHeader';
import Alerts from '~/shared/components/Alert/Alerts';
import Annotations from '~/shared/components/Annotations';
import Chips from '~/shared/components/Chips';
import FormErrorMessage from '~/shared/components/FormErrorMessage';
// import MobileMenu from 'shared/components/Header/MobileMenu';
import TopHeader from '~/shared/components/Header/TopHeader';
import Indicators from '~/shared/components/Indicators';
import LogoHeading from '~/shared/components/LogoHeading';
import ObjectCard from '~/shared/components/ObjectCard';
import PageHeading from '~/shared/components/PageHeading';
import ProgramCard from '~/shared/components/ProgramCard';
import Tooltip from '~/shared/components/Tooltip';
// import EligiblePrograms from '../HouseHoldModule/HouseholdMembers/EligiblePrograms';

/**
 * Name: StyledComponent
 * Desc: Render StyledComponent
 */

const handleDelete = () => {
    // eslint-disable-next-line no-console
    console.info('You clicked the delete icon.');
};

const StyledComponentModule = () => {
    const [value, setValue] = useState('female');
    const [checked, setChecked] = useState(true);

    const [showDetails, setShowDetails] = useState(false);

    const [state, setState] = useState({
        checkedA: true,
        checkedB: true
    });

    const [select, setselect] = React.useState('');

    const handleChangeSelectBox = (event) => {
        setselect(event.target.value);
    };

    const [openDialog, setOpenDialog] = useState(false);

    const handleClickOpenDialog = () => {
        setOpenDialog(true);
    };

    const handleClose = () => {
        setOpenDialog(false);
    };

    const handleChange = (event) => {
        setValue(event.target.value);
    };

    const handleChangeCheckBox = (event) => {
        setChecked(event.target.checked);
    };

    const handleChangeSwitchBox = (event) => {
        setState({ ...state, [event.target.name]: event.target.checked });
    };

    return (
        <Box bgcolor="secondary.light" py={2} px={2}>
            <Grid container spacing={3}>
                <Grid item xs={12} md={12}>
                    {/* <EligiblePrograms /> */}
                </Grid>
                <Grid item xs={12} md={12}>
                    <PageHeading title="App name" />
                    <LogoHeading title="AppName" />
                </Grid>
                <Grid item xs={12} md={12}>
                    <PageHeading title="Client Logo" />
                    <Box>
                        <Avatar alt="logo" src="/logo.svg" />
                    </Box>
                </Grid>

                <Grid item xs={12} md={12}>
                    <PageHeading title="Buttons" />
                    <Box display="flex" flexWrap="wrap">
                        <Box pb={8}>
                            <Box
                                display="flex"
                                justifyContent="space-between"
                                alignItems="flex-start"
                                mb={3}>
                                <Button size="large" color="primary" variant="contained">
                                    smaller
                                </Button>
                                <Button color="primary" variant="contained">
                                    Smallest
                                </Button>
                                <Button size="small" color="primary" variant="contained">
                                    I’m tiny
                                </Button>
                            </Box>
                            <Box
                                display="flex"
                                justifyContent="space-between"
                                alignItems="flex-start"
                                mb={3}>
                                <Button size="large" color="secondary" variant="contained">
                                    smaller
                                </Button>
                                <Button size="medium" color="secondary" variant="contained">
                                    Smallest
                                </Button>
                                <Button size="small" color="secondary" variant="contained">
                                    I’m tiny
                                </Button>
                            </Box>
                            <Box
                                display="flex"
                                justifyContent="space-between"
                                alignItems="flex-start"
                                mb={3}>
                                <Button size="large" color="inherit" variant="contained">
                                    smaller
                                </Button>
                                <Button size="medium" color="inherit" variant="contained">
                                    Smallest
                                </Button>
                                <Button size="small" color="inherit" variant="contained">
                                    I’m tiny
                                </Button>
                            </Box>
                        </Box>
                        <Box mb={8}>
                            <Box mb={3}>
                                <Button
                                    fullWidth
                                    size="large"
                                    color="primary"
                                    className="semiBorder"
                                    variant="contained">
                                    Get Started
                                </Button>
                            </Box>
                            <Box mb={3}>
                                <Button
                                    fullWidth
                                    size="large"
                                    color="secondary"
                                    className="semiBorder"
                                    variant="contained">
                                    Get Started
                                </Button>
                            </Box>
                            <Box mb={3}>
                                <Button size="large" className="semiBorder" variant="contained">
                                    Get Started
                                </Button>
                            </Box>
                        </Box>
                    </Box>
                </Grid>

                <Grid item xs={12} md={12}>
                    <PageHeading title="INDICATORS" />
                    <Box display="flex" justifyContent="space-between">
                        {['pending', 'success', 'failed', 'default', 'complete'].map(
                            (item, index) => {
                                return <Indicators status={item} key={index} />;
                            }
                        )}
                    </Box>
                </Grid>
                <Grid item xs={12} md={12}>
                    <PageHeading title="Controls" />
                    {/* <Box display="flex" justifyContent="space-between" mb={5}>
                                    <MenuOutlinedIcon fontSize="25px" />
                                </Box> */}

                    <PageHeading title="Tooltip" />
                    <Box>
                        <Tooltip />
                    </Box>
                </Grid>

                <Grid item xs={12} md={12}>
                    <Box color="info.main" fontFamily="fontFamily.bold" pb={2}>
                        <Typography variant="h3">Input Box</Typography>
                    </Box>
                    <Box mb={2.5}>
                        <FormControl>
                            <TextField
                                id="standard-basic"
                                label="Standard"
                                variant="filled"
                                error
                                helperText={
                                    <FormErrorMessage title="Please enter your telephone number">
                                        <AlertTriangle size={9} />
                                    </FormErrorMessage>
                                }
                            />
                        </FormControl>
                    </Box>
                    <Box mb={2.5}>
                        <FormControl fullWidth>
                            <TextField
                                variant="filled"
                                label="Field Input Label"
                                value="text"
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment>
                                            <IconButton className="icon-search"></IconButton>
                                        </InputAdornment>
                                    )
                                }}
                            />
                        </FormControl>
                    </Box>
                    <Box mb={2.5}>
                        <FormControl variant="filled" fullWidth>
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                value={select}
                                onChange={handleChangeSelectBox}>
                                <MenuItem value={10}>Ten</MenuItem>
                                <MenuItem value={20}>Twenty</MenuItem>
                                <MenuItem value={30}>Thirty</MenuItem>
                            </Select>
                        </FormControl>
                    </Box>
                </Grid>

                <Grid item xs={12} md={12}>
                    <PageHeading title="Annotations" />
                    <Box mb={6.25}>
                        <Annotations bgColor="primary.main" color="common.white" minHeights={147}>
                            <Box fontSize="h6.fontSize" fontFamily="fontFamily.medium">
                                Design To Do: Design error messages for screens.
                            </Box>
                        </Annotations>
                    </Box>
                    <Box mb={6.25}>
                        <Annotations bgColor="error.dark" color="common.white" minHeights={147}>
                            <Box fontSize="h6.fontSize" fontFamily="fontFamily.medium">
                                Here’s a discussion note for this screen.
                            </Box>
                        </Annotations>
                    </Box>
                    <Box mb={6.25}>
                        <Annotations
                            bgColor="pending.main"
                            color="common.darkBlack"
                            minHeights={147}>
                            <Box fontSize="h6.fontSize" fontFamily="fontFamily.medium">
                                Here’s a note for this screen.
                            </Box>
                        </Annotations>
                    </Box>
                </Grid>
                <Grid item xs={12} md={12}>
                    <PageHeading title="Program Card" />
                    <Box mb={6.25}>
                        <ProgramCard variant="waiting" showDeleteBox={true}>
                            <Box
                                color="primary.main"
                                fontSize="h6.fontSize"
                                fontFamily="fontFamily.medium">
                                Program Title on Card (1BR)
                            </Box>
                            <Box
                                component="body1"
                                color="primary.light"
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.regular">
                                Waitlist or on-track status
                            </Box>
                        </ProgramCard>
                    </Box>

                    <Box mb={6.25}>
                        <ProgramCard variant="success" showLeftArrow={true}>
                            <Box
                                color="primary.main"
                                fontSize="h6.fontSize"
                                fontFamily="fontFamily.medium">
                                Small Card Title
                            </Box>
                            <Box
                                component="body1"
                                color="primary.light"
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.regular">
                                Small card status indicator line
                            </Box>
                        </ProgramCard>
                    </Box>

                    <Box mb={6.25}>
                        <ProgramCard variant="failed" showImage={true} showLeftArrow={true}>
                            <Box
                                color="primary.main"
                                fontSize="h6.fontSize"
                                fontFamily="fontFamily.medium">
                                Small Card Title
                            </Box>
                            <Box
                                component="body1"
                                color="primary.light"
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.regular">
                                Waitlist or on-track status
                            </Box>
                        </ProgramCard>
                    </Box>

                    <Box mb={6.25}>
                        <ProgramCard variant="success" showImage={true} showLeftBorder={false}>
                            <Box
                                color="primary.main"
                                fontSize="h6.fontSize"
                                fontFamily="fontFamily.medium">
                                Program Title on Card (1BR)
                            </Box>
                            <Box
                                component="body1"
                                color="primary.light"
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.regular">
                                Waitlist or on-track status
                            </Box>
                        </ProgramCard>
                    </Box>
                </Grid>

                <Grid item xs={12} md={12}>
                    <PageHeading title="Object Card" />

                    <Box mb={6.25}>
                        <ObjectCard>
                            <Box
                                color="primary.dark"
                                fontSize="h6.fontSize"
                                fontFamily="fontFamily.medium">
                                Erika Alexander
                            </Box>
                            <Box
                                color="primary.light"
                                fontSize="lg.fontSize"
                                fontFamily="fontFamily.regular">
                                Applicant
                            </Box>
                        </ObjectCard>
                    </Box>

                    {/* <Box mb={6.25}>
                        <UploadCard>
                            <Box color="primary.dark" fontSize="h6.fontSize">
                                Add Another Person
                            </Box>
                        </UploadCard>
                    </Box> */}

                    <Box mb={6.25}>
                        <ObjectCard cardType="actionCard" iconName="plus">
                            <Box
                                color="primary.dark"
                                fontSize="h6.fontSize"
                                fontFamily="fontFamily.medium">
                                Add Another Person
                            </Box>
                        </ObjectCard>
                    </Box>

                    <Box mb={6.25}>
                        <Card>
                            <Box display="flex" alignItems="flex-start" p={2.5} minHeight={96}>
                                <Box
                                    display="flex"
                                    justifyContent="flex-end"
                                    minWidth={38}
                                    flex="0 0 38px"
                                    mt={1.25}>
                                    <Checkbox checked={checked} onChange={handleChange} />
                                </Box>
                                <Box
                                    ml={0.5}
                                    flexGrow={2}
                                    display="flex"
                                    flexDirection="column"
                                    justifyContent="center">
                                    <Box
                                        color="primary.dark"
                                        fontSize="h6.fontSize"
                                        fontFamily="fontFamily.medium">
                                        Housing Choice Voucher
                                    </Box>
                                    <Box
                                        color="primary.light"
                                        fontSize="md.fontSize"
                                        fontFamily="fontFamily.regular">
                                        Find your own unit
                                    </Box>

                                    {showDetails && (
                                        <Box
                                            color="common.lightBlue"
                                            fontSize="md.fontSize"
                                            fontFamily="fontFamily.regular"
                                            mb={1}
                                            mt={1}>
                                            The Eisenhower is a waitlisted multi-unit housing option
                                            in Northeast El Paso with 2, 3, and 4 bedroom units made
                                            available through HACEP’s Program-Based Voucher system.
                                        </Box>
                                    )}

                                    <Box
                                        color="primary.mian"
                                        fontSize="md.fontSize"
                                        fontFamily="fontFamily.regular">
                                        <Link
                                            component="button"
                                            color="primary"
                                            underline="none"
                                            onClick={() => setShowDetails(!showDetails)}>
                                            {!showDetails ? ' Show Details' : 'Hide Details'}
                                        </Link>
                                    </Box>
                                </Box>
                            </Box>
                        </Card>
                    </Box>
                </Grid>
                <Grid item xs={12} md={12}>
                    <PageHeading title="Alerts" />
                    <Alerts />
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box color="primary.light" fontFamily="fontFamily.bold" pb={2}>
                        <Typography variant="h3">Radio Button</Typography>
                    </Box>
                    <Box mb={2.5}>
                        {/* <Radio /> */}
                        <FormControl component="fieldset">
                            <FormLabel component="legend">Gender</FormLabel>
                            <RadioGroup
                                aria-label="gender"
                                name="gender1"
                                value={value}
                                onChange={handleChange}>
                                <FormControlLabel
                                    value="female"
                                    control={<Radio />}
                                    label="Female"
                                />
                                <FormControlLabel value="male" control={<Radio />} label="Male" />
                                <FormControlLabel value="other" control={<Radio />} label="Other" />
                                <FormControlLabel
                                    value="disabled"
                                    disabled
                                    control={<Radio />}
                                    label="(Disabled option)"
                                />
                            </RadioGroup>
                        </FormControl>
                    </Box>
                    <Box color="primary.light" fontFamily="fontFamily.bold" pb={2}>
                        <Typography variant="h3">Check Box</Typography>
                    </Box>
                    <Box mb={2.5}>
                        <Checkbox
                            checked={checked}
                            onChange={handleChangeCheckBox}
                            inputProps={{ 'aria-label': 'primary checkbox' }}
                        />
                    </Box>
                    <Box color="primary.light" fontFamily="fontFamily.bold" pb={2}>
                        <Typography variant="h3">Toggle Switch</Typography>
                    </Box>
                    <Box mb={2.5}>
                        <Switch
                            checked={state.checkedB}
                            onChange={handleChangeSwitchBox}
                            name="checkedB"
                            inputProps={{ 'aria-label': 'primary checkbox' }}
                        />
                    </Box>
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box color="info.main" fontFamily="fontFamily.bold" pb={2}>
                        <Typography variant="h3">Tags</Typography>
                    </Box>
                    <Box mb={2}>
                        <Chips label="Tag Name" color="primary" />
                    </Box>
                    <Box mb={2}>
                        <Chips label="Active Tag" color="secondary" onDelete={handleDelete} />
                    </Box>
                </Grid>

                <Grid item xs={12} md={12}>
                    <PageHeading title="Cards" />
                    <Box mb={4}>
                        <Card>
                            <Box minHeight={96} width="100%"></Box>
                        </Card>
                    </Box>
                    <Box>
                        <Card>
                            <Box minHeight={604} width="100%"></Box>
                        </Card>
                    </Box>
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box
                        fontSize="xlg.fontSize"
                        fontFamily="fontFamily.bold"
                        bgcolor="primary.main"
                        color="white">
                        change font Size and Family using box
                    </Box>
                </Grid>
                <Grid item xs={12} md={12}>
                    <Box mb={3}>
                        <MainHeader />
                    </Box>
                    <TopHeader isWizard={true} />
                    <MainHeader isLoggedIn={true} />
                </Grid>

                <Grid item xs={12} md={12}>
                    <PageHeading title="DialogBox" />
                    <Box>
                        <Button variant="outlined" color="primary" onClick={handleClickOpenDialog}>
                            Open simple dialog
                        </Button>

                        <Dialog
                            onClose={handleClose}
                            aria-labelledby="simple-dialog-title"
                            open={openDialog}>
                            <DialogTitle id="simple-dialog-title">
                                <IconButton aria-label="close" onClick={handleClose}>
                                    <CloseIcon />
                                </IconButton>
                            </DialogTitle>
                            <DialogContent>
                                <Box textAlign="center" pt={2.5}>
                                    <Box
                                        fontSize="h3.fontSize"
                                        fontFamily="fontFamily.bold"
                                        color="primary.light"
                                        pb={1}>
                                        Select your language
                                    </Box>
                                    <Box
                                        fontSize="lg.fontSize"
                                        fontStyle="italic"
                                        color="primary.extraLight">
                                        Elige tu idioma
                                    </Box>
                                </Box>
                                <Box>
                                    <Box maxWidth={256} mx="auto" py={3}>
                                        <FormControl variant="filled" fullWidth>
                                            <Select
                                                labelId="demo-simple-select-label"
                                                id="demo-simple-select"
                                                iconcomponent={ExpandMoreOutlinedIcon}
                                                value={select}
                                                onChange={handleChangeSelectBox}>
                                                <MenuItem value={1}>English</MenuItem>
                                                <MenuItem value={2}>German</MenuItem>
                                            </Select>
                                        </FormControl>
                                    </Box>
                                </Box>
                            </DialogContent>
                            <Box>
                                <Button
                                    fullWidth
                                    size="large"
                                    color="secondary"
                                    className="semiBorder"
                                    variant="contained">
                                    Continue
                                </Button>
                            </Box>
                        </Dialog>
                    </Box>
                </Grid>
            </Grid>
        </Box>
    );
};
export default StyledComponentModule;
