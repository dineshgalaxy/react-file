module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/pages/dashboardpagestyle/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/head":
/*!****************************************************!*\
  !*** external "next/dist/next-server/lib/head.js" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/head.js");

/***/ }),

/***/ "../next-server/lib/to-base-64":
/*!**********************************************************!*\
  !*** external "next/dist/next-server/lib/to-base-64.js" ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/to-base-64.js");

/***/ }),

/***/ "../next-server/server/image-config":
/*!***************************************************************!*\
  !*** external "next/dist/next-server/server/image-config.js" ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/image-config.js");

/***/ }),

/***/ "./node_modules/next/dist/client/image.js":
/*!************************************************!*\
  !*** ./node_modules/next/dist/client/image.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = Image;

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/objectWithoutPropertiesLoose */ "./node_modules/next/node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js"));

var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/next/node_modules/@babel/runtime/helpers/extends.js"));

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _head = _interopRequireDefault(__webpack_require__(/*! ../next-server/lib/head */ "../next-server/lib/head"));

var _toBase = __webpack_require__(/*! ../next-server/lib/to-base-64 */ "../next-server/lib/to-base-64");

var _imageConfig = __webpack_require__(/*! ../next-server/server/image-config */ "../next-server/server/image-config");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

if (true) {
  ;
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['default', defaultLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];
const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","domains":[]} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout) {
  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout);
  const last = widths.length - 1;
  return {
    src: loader({
      src,
      quality,
      width: widths[last]
    }),
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', ')
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load((0, _extends2.default)({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
}

function Image(_ref) {
  let {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    loader = defaultImageLoader
  } = _ref,
      all = (0, _objectWithoutPropertiesLoose2.default)(_ref, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "objectFit", "objectPosition", "loader"]);
  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';
  let unsized = false;

  if ('unsized' in rest) {
    unsized = Boolean(rest.unsized); // Remove property so it's not spread into image:

    delete rest['unsized'];
  } else if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  if (true) {
    if (!src) {
      throw new Error(`Image is missing required "src" property. Make sure you pass "src" in props to the \`next/image\` component. Received: ${JSON.stringify({
        width,
        height,
        quality
      })}`);
    }

    if (!VALID_LAYOUT_VALUES.includes(layout)) {
      throw new Error(`Image with src "${src}" has invalid "layout" property. Provided "${layout}" should be one of ${VALID_LAYOUT_VALUES.map(String).join(',')}.`);
    }

    if (!VALID_LOADING_VALUES.includes(loading)) {
      throw new Error(`Image with src "${src}" has invalid "loading" property. Provided "${loading}" should be one of ${VALID_LOADING_VALUES.map(String).join(',')}.`);
    }

    if (priority && loading === 'lazy') {
      throw new Error(`Image with src "${src}" has both "priority" and "loading='lazy'" properties. Only one should be used.`);
    }

    if (unsized) {
      throw new Error(`Image with src "${src}" has deprecated "unsized" property, which was removed in favor of the "layout='fill'" property`);
    }
  }

  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src && src.startsWith('data:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  const [setRef, isIntersected] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px',
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = {
    visibility: isVisible ? 'inherit' : 'hidden',
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  };

  if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined' && layout !== 'fill') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else if (typeof widthInt === 'undefined' && typeof heightInt === 'undefined' && layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else {
    // <Image src="i.png" />
    if (true) {
      throw new Error(`Image with src "${src}" must use "width" and "height" properties or "layout='fill'" property.`);
    }
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  if (unsized) {
    wrapperStyle = undefined;
    sizerStyle = undefined;
    imgStyle = undefined;
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    role: "presentation",
    src: `data:image/svg+xml;base64,${(0, _toBase.toBase64)(sizerSvg)}`
  }) : null) : null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    className: className,
    ref: setRef,
    style: imgStyle
  })), priority ?
  /*#__PURE__*/
  // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src // @ts-ignore: imagesrcset is not yet in the link element type
    ,
    imagesrcset: imgAttributes.srcSet // @ts-ignore: imagesizes is not yet in the link element type
    ,
    imagesizes: imgAttributes.sizes
  })) : null);
} //BUILT IN LOADERS


function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?format=auto&fit=max&w=300
  const params = ['auto=format', 'fit=max', 'w=' + width];
  let paramsString = '';

  if (quality) {
    params.push('q=' + quality);
  }

  if (params.length) {
    paramsString = '?' + params.join('&');
  }

  return `${root}${normalizeSrc(src)}${paramsString}`;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (true) {
    const missingValues = []; // these should always be provided but make sure they are

    if (!src) missingValues.push('src');
    if (!width) missingValues.push('width');

    if (missingValues.length > 0) {
      throw new Error(`Next Image Optimization requires ${missingValues.join(', ')} to be provided. Make sure you pass them as props to the \`next/image\` component. Received: ${JSON.stringify({
        src,
        width,
        quality
      })}`);
    }

    if (src.startsWith('//')) {
      throw new Error(`Failed to parse src "${src}" on \`next/image\`, protocol-relative URL (//) must be changed to an absolute URL (http:// or https://)`);
    }

    if (!src.startsWith('/') && configDomains) {
      let parsedSrc;

      try {
        parsedSrc = new URL(src);
      } catch (err) {
        console.error(err);
        throw new Error(`Failed to parse src "${src}" on \`next/image\`, if using relative image it must start with a leading slash "/" or be an absolute URL (http:// or https://)`);
      }

      if (!configDomains.includes(parsedSrc.hostname)) {
        throw new Error(`Invalid src prop (${src}) on \`next/image\`, hostname "${parsedSrc.hostname}" is not configured under images in your \`next.config.js\`\n` + `See more info: https://err.sh/next.js/next-image-unconfigured-host`);
      }
    }
  }

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/image.js":
/*!************************************!*\
  !*** ./node_modules/next/image.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/image */ "./node_modules/next/dist/client/image.js")


/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/extends.js":
/*!**************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/extends.js ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ "./src/modules/DashboardPageStyleModule/DashboardPageStyleModule.js":
/*!**************************************************************************!*\
  !*** ./src/modules/DashboardPageStyleModule/DashboardPageStyleModule.js ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! shared/components/Header/MainHeader */ "./src/shared/components/Header/MainHeader/index.js");
/* harmony import */ var shared_components_Header_TopHeader__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! shared/components/Header/TopHeader */ "./src/shared/components/Header/TopHeader/index.js");
/* harmony import */ var _shared_components_Alert__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/shared/components/Alert */ "./src/shared/components/Alert/index.js");
/* harmony import */ var _shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/shared/components/CommonCard */ "./src/shared/components/CommonCard/index.js");
/* harmony import */ var _shared_components_DashboardPageComponent_DashboardAccount__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/shared/components/DashboardPageComponent/DashboardAccount */ "./src/shared/components/DashboardPageComponent/DashboardAccount/index.js");
/* harmony import */ var _shared_components_DashboardPageComponent_DashboardAccountDetails__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/shared/components/DashboardPageComponent/DashboardAccountDetails */ "./src/shared/components/DashboardPageComponent/DashboardAccountDetails/index.js");
/* harmony import */ var _shared_components_DashboardPageComponent_DashboardContactUs__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/shared/components/DashboardPageComponent/DashboardContactUs */ "./src/shared/components/DashboardPageComponent/DashboardContactUs/index.js");
/* harmony import */ var _shared_components_DashboardPageComponent_DashboardHelpCenter__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/shared/components/DashboardPageComponent/DashboardHelpCenter */ "./src/shared/components/DashboardPageComponent/DashboardHelpCenter/index.js");
/* harmony import */ var _shared_components_DashboardPageComponent_DashboardHelpTopics__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~/shared/components/DashboardPageComponent/DashboardHelpTopics */ "./src/shared/components/DashboardPageComponent/DashboardHelpTopics/index.js");
/* harmony import */ var _shared_components_DashboardPageComponent_DashboardHome__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~/shared/components/DashboardPageComponent/DashboardHome */ "./src/shared/components/DashboardPageComponent/DashboardHome/index.js");
/* harmony import */ var _shared_components_DashboardPageComponent_DashboardNoPrograms__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~/shared/components/DashboardPageComponent/DashboardNoPrograms */ "./src/shared/components/DashboardPageComponent/DashboardNoPrograms/index.js");
/* harmony import */ var _shared_components_DashboardPageComponent_DashboardYourApplication__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ~/shared/components/DashboardPageComponent/DashboardYourApplication */ "./src/shared/components/DashboardPageComponent/DashboardYourApplication/index.js");
/* harmony import */ var _shared_components_DashboardPageComponent_YourVoucher__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ~/shared/components/DashboardPageComponent/YourVoucher */ "./src/shared/components/DashboardPageComponent/YourVoucher/index.js");
/* harmony import */ var _shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ~/shared/components/Footer */ "./src/shared/components/Footer/index.js");
/* harmony import */ var _shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ~/shared/components/Footer/SubFooter */ "./src/shared/components/Footer/SubFooter/index.js");
/* harmony import */ var _shared_components_HelpCenter__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ~/shared/components/HelpCenter */ "./src/shared/components/HelpCenter/index.js");
/* harmony import */ var _shared_components_ObjectCard__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ~/shared/components/ObjectCard */ "./src/shared/components/ObjectCard/index.js");
/* harmony import */ var _shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ~/shared/components/PageHeading */ "./src/shared/components/PageHeading/index.js");
/* harmony import */ var _shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ~/shared/components/ProgramCard */ "./src/shared/components/ProgramCard/index.js");
/* harmony import */ var _shared_components_WizardHeader__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(/*! ~/shared/components/WizardHeader */ "./src/shared/components/WizardHeader/index.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\modules\\DashboardPageStyleModule\\DashboardPageStyleModule.js";























/**
 * Name: DashboardPageStyleModule
 * Desc: Render DashboardPageStyleModule
 */

const DashboardPageStyleModule = () => {
  const linkArrays = [{
    text: 'See if you’re eligible >',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_3__["HelpCircle"]
  }, {
    text: 'View (6) archived applications >',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_3__["Archive"]
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
      container: true,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Dashboard Home"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_TopHeader__WEBPACK_IMPORTED_MODULE_5__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
          isLoggedIn: true,
          userName: "Hello, Erika",
          headerSubtitle: "View your active housing applications below on your dashboard below."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_DashboardPageComponent_DashboardHome__WEBPACK_IMPORTED_MODULE_13__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 49,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_HelpCenter__WEBPACK_IMPORTED_MODULE_19__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 50,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 51,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Dashboard Account"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
          isLoggedIn: true,
          showMobileMenu: true,
          mobileTitle: "Your Account",
          showBell: false
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_DashboardPageComponent_DashboardAccount__WEBPACK_IMPORTED_MODULE_8__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_HelpCenter__WEBPACK_IMPORTED_MODULE_19__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 55,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Dashboard Account Details"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 72,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 71,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
          isLoggedIn: true,
          showBackBtn: true,
          mobileTitle: "Account Details",
          showBell: false
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 74,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_DashboardPageComponent_DashboardAccountDetails__WEBPACK_IMPORTED_MODULE_9__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 81,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_HelpCenter__WEBPACK_IMPORTED_MODULE_19__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 83,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 84,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 85,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 70,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Dashboard - Voucher"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 88,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_WizardHeader__WEBPACK_IMPORTED_MODULE_23__["default"], {
          title: "Your Voucher"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 91,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__["default"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_DashboardPageComponent_YourVoucher__WEBPACK_IMPORTED_MODULE_16__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 94,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 93,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Dashboard Help Center"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 98,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
          isLoggedIn: true,
          mobileTitle: "Help Center",
          showBell: false,
          showMobileMenu: true
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 101,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_DashboardPageComponent_DashboardHelpCenter__WEBPACK_IMPORTED_MODULE_11__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 108,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 107,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_HelpCenter__WEBPACK_IMPORTED_MODULE_19__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 110,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 111,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 112,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 97,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Dashboard - Help Topics"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 116,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 115,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
          isLoggedIn: true,
          showBackBtn: true,
          mobileTitle: "Help Topics",
          showBell: false
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 119,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_DashboardPageComponent_DashboardHelpTopics__WEBPACK_IMPORTED_MODULE_12__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 126,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 125,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_HelpCenter__WEBPACK_IMPORTED_MODULE_19__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 128,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 129,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 130,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 114,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Dashboard - Contact Us"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 134,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 133,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
          isLoggedIn: true,
          showBackBtn: true,
          mobileTitle: "Contact Us",
          showBell: false
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 136,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_DashboardPageComponent_DashboardContactUs__WEBPACK_IMPORTED_MODULE_10__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 143,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_HelpCenter__WEBPACK_IMPORTED_MODULE_19__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 145,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 146,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 147,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 132,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        width: "100%",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Dashboard Alerts"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 151,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 150,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          bgcolor: "secondary.extraLight",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
            isLoggedIn: true,
            showBackBtn: true,
            mobileTitle: "Your Alerts",
            showBell: false
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 154,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              pb: 3,
              pl: 1,
              pr: 1,
              mt: 1,
              children: [{
                title: 'Program Name for the Alert',
                subtitle: 'Your name has been reached and you may complete a full application now.',
                time: '1d'
              }, {
                title: 'Housing Choice Voucher',
                subtitle: 'Your application is incomplete. Finish it now to keep your spot.',
                time: '3d'
              }, {
                title: 'Tays (1BR)',
                subtitle: 'There is an update on your application for this program.',
                time: '24w'
              }, {
                title: 'Siesta Gardens (2BR)',
                subtitle: 'Your application has been approved! Click here to find your next steps.',
                time: '52w'
              }, {
                title: 'Siesta Gardens (2BR)',
                subtitle: 'Your application has been approved! Click here to find your next steps.',
                time: '52w'
              }, {
                title: 'Housing Choice Voucher',
                subtitle: 'Your application has been approved! Click here to find your next steps.',
                time: '52w'
              }].map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                pt: 3,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Alert__WEBPACK_IMPORTED_MODULE_6__["default"], {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        fontSize: "lg.fontSize",
                        fontFamily: "fontFamily.bold",
                        color: "primary.extraLight",
                        children: item.title
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 208,
                        columnNumber: 53
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        fontSize: "md.fontSize",
                        color: "primary.extraLight",
                        pt: 0.5,
                        children: item.subtitle
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 214,
                        columnNumber: 53
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 207,
                      columnNumber: 49
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      display: "flex",
                      minWidth: "50px",
                      height: "100%",
                      alignItems: "center",
                      justifyContent: "flex-end",
                      fontSize: "xs.fontSize",
                      fontFamily: "fontFamily.bold",
                      color: "common.grayText",
                      mr: -2,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        display: "inline-block",
                        width: 9,
                        height: 9,
                        bgcolor: "error.main",
                        borderRadius: "50%",
                        mr: 0.75
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 231,
                        columnNumber: 53
                      }, undefined), item.time]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 221,
                      columnNumber: 49
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 203,
                    columnNumber: 45
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 202,
                  columnNumber: 41
                }, undefined)
              }, item.title, false, {
                fileName: _jsxFileName,
                lineNumber: 201,
                columnNumber: 37
              }, undefined))
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 162,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              fontSize: "lg.fontSize",
              fontFamily: "fontFamily.medium",
              display: "flex",
              justifyContent: "center",
              pt: 1,
              pb: 6,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                href: "#",
                children: "Load Older Messages +"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 252,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 245,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 161,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 153,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 149,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "No Programs"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 259,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 258,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          bgcolor: "secondary.extraLight",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
            isLoggedIn: "true",
            padding: "0 0 24px",
            userName: "Hello, Erika",
            headerSubtitle: "You don\u2019t have any active program applications right now."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 262,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__["default"], {
            bgColor: "transparent",
            showBackBtn: false,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              mb: 3,
              borderColor: "primary.main",
              border: "1px dashed",
              borderRadius: "21px",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ObjectCard__WEBPACK_IMPORTED_MODULE_20__["default"], {
                cardType: "actionCard",
                iconName: "plus",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.main",
                  fontSize: "h6.fontSize",
                  fontFamily: "fontFamily.medium",
                  children: "Start a New Pre-Application"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 275,
                  columnNumber: 37
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 274,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 269,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              pt: 2.5,
              children: linkArrays.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mb: 2,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                  href: "#",
                  underline: "none",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
                      strokeWidth: "2",
                      color: "Indigo",
                      size: 15
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 288,
                      columnNumber: 49
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      fontSize: "lg.fontSize",
                      color: "primary.main",
                      fontFamily: "fontFamily.medium",
                      ml: 1.5,
                      children: item.text
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 293,
                      columnNumber: 49
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 287,
                    columnNumber: 45
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 286,
                  columnNumber: 41
                }, undefined)
              }, item.text, false, {
                fileName: _jsxFileName,
                lineNumber: 285,
                columnNumber: 37
              }, undefined))
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 283,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 268,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 261,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 7,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_DashboardPageComponent_DashboardNoPrograms__WEBPACK_IMPORTED_MODULE_14__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 308,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 307,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_HelpCenter__WEBPACK_IMPORTED_MODULE_19__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 310,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 311,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 312,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 257,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Your Applications"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 316,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 315,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
          isLoggedIn: "true",
          padding: "0 0 24px",
          userName: "Your Applications",
          headerSubtitle: "View your active housing applications  or start a new application below."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 318,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__["default"], {
          bgColor: "transparent",
          showBackBtn: false,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_DashboardPageComponent_DashboardYourApplication__WEBPACK_IMPORTED_MODULE_15__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 325,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 324,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_HelpCenter__WEBPACK_IMPORTED_MODULE_19__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 327,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 328,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 329,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 314,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mt: 5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_21__["default"], {
            title: "Archived Application"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 333,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 332,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          bgcolor: "secondary.extraLight",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_4__["default"], {
            isLoggedIn: true,
            showBackBtn: true,
            mobileTitle: "Archive",
            showBell: false
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 336,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              pb: 3,
              children: [{
                title: 'Housing Choice Voucher',
                subtitle: 'Archived 5/16/22'
              }, {
                title: 'Siesta Gardens (2BR)',
                subtitle: 'Application Not Approved'
              }, {
                title: 'DeWetter (2BR)',
                subtitle: 'Archived 5/16/22'
              }, {
                title: 'Kathy White (2BR)',
                subtitle: 'Archived 5/16/22'
              }, {
                title: 'Eisenhower (2BR)',
                subtitle: 'Archived 5/16/22'
              }, {
                title: 'Krupp (2BR)',
                subtitle: 'Archived 5/16/22'
              }].map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                pt: 3,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_22__["default"], {
                  variant: "info",
                  showImage: true,
                  showLeftBorder: true,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    color: "primary.main",
                    fontSize: "h6.fontSize",
                    fontFamily: "fontFamily.medium",
                    children: item.title
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 363,
                    columnNumber: 45
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    component: "body1",
                    color: "primary.light",
                    fontSize: "lg.fontSize",
                    fontFamily: "fontFamily.regular",
                    children: item.subtitle
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 369,
                    columnNumber: 45
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 359,
                  columnNumber: 41
                }, undefined)
              }, item.title, false, {
                fileName: _jsxFileName,
                lineNumber: 358,
                columnNumber: 37
              }, undefined))
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 343,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 342,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 381,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Footer_SubFooter__WEBPACK_IMPORTED_MODULE_18__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 382,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 335,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 331,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 38,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ __webpack_exports__["default"] = (DashboardPageStyleModule);

/***/ }),

/***/ "./src/modules/DashboardPageStyleModule/index.js":
/*!*******************************************************!*\
  !*** ./src/modules/DashboardPageStyleModule/index.js ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardPageStyleModule__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardPageStyleModule */ "./src/modules/DashboardPageStyleModule/DashboardPageStyleModule.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _DashboardPageStyleModule__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/pages/dashboardpagestyle/index.js":
/*!***********************************************!*\
  !*** ./src/pages/dashboardpagestyle/index.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modules_DashboardPageStyleModule__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/modules/DashboardPageStyleModule */ "./src/modules/DashboardPageStyleModule/index.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\pages\\dashboardpagestyle\\index.js";


/**
 * Name : DashboardPageStyle
 * desc : Render DashboardPageStyle
 **/

function DashboardPageStyle() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_modules_DashboardPageStyleModule__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 13
    }, this)
  }, void 0, false);
}

/* harmony default export */ __webpack_exports__["default"] = (DashboardPageStyle);

/***/ }),

/***/ "./src/shared/components/Alert/Alerts.js":
/*!***********************************************!*\
  !*** ./src/shared/components/Alert/Alerts.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_lab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/lab */ "@material-ui/lab");
/* harmony import */ var _material_ui_lab__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_lab__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _AlertsStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./AlertsStyles */ "./src/shared/components/Alert/AlertsStyles.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Alert\\Alerts.js";






/**
 * Name: Alerts
 * Desc: Render Alerts
 */

const Alerts = ({
  variant,
  iconColor,
  children,
  showCloseBtn
}) => {
  const classes = Object(_AlertsStyles__WEBPACK_IMPORTED_MODULE_5__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
      className: classes[variant],
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_lab__WEBPACK_IMPORTED_MODULE_2__["Alert"], {
        action: showCloseBtn && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_3__["X"], {
            strokeWidth: "3",
            color: iconColor
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 33
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 29
        }, undefined),
        children: children && children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

Alerts.defaultProps = {
  showCloseBtn: false
};
Alerts.propTypes = {
  variant: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.oneOf(["primaryAlert", "secondaryAlert"]),
  iconColor: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.oneOf(["white", "indigo"]),
  children: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.node,
  showCloseBtn: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (Alerts);

/***/ }),

/***/ "./src/shared/components/Alert/AlertsStyles.js":
/*!*****************************************************!*\
  !*** ./src/shared/components/Alert/AlertsStyles.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  primaryAlert: {
    backgroundColor: theme.palette.primary.main,
    color: theme.common.white,
    boxShadow: "none",
    borderRadius: "0"
  },
  secondaryAlert: {
    backgroundColor: theme.palette.menus.menuBackground,
    color: theme.palette.primary.light,
    boxShadow: "none",
    borderRadius: "0"
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Alert/index.js":
/*!**********************************************!*\
  !*** ./src/shared/components/Alert/index.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Alerts__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Alerts */ "./src/shared/components/Alert/Alerts.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Alerts__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/CommonCard/CommonCard.js":
/*!********************************************************!*\
  !*** ./src/shared/components/CommonCard/CommonCard.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _CommonCardStyle__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./CommonCardStyle */ "./src/shared/components/CommonCard/CommonCardStyle.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\CommonCard\\CommonCard.js";






/**
 * Name: CommonCard
 * Desc: Render CommonCard
 */

const CommonCard = ({
  bgColor,
  isStatusCard,
  onClickBack,
  showBackBtn,
  showHeader,
  noMargin,
  children,
  bgScreen,
  backBtnColor,
  space,
  pageView,
  landingPageIcon
}) => {
  const classes = Object(_CommonCardStyle__WEBPACK_IMPORTED_MODULE_6__["default"])();
  const cardClass = clsx__WEBPACK_IMPORTED_MODULE_2___default()(classes.root, classes[bgColor], classes[bgScreen], classes[space], classes[pageView], {
    [classes.noMargin]: noMargin,
    [classes.welcomePage]: isStatusCard,
    [classes.header]: showHeader
  });
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
    className: cardClass,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      className: classes.subRoot,
      children: [landingPageIcon && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 4,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
          className: classes.mobileBackBtn,
          onClick: onClickBack,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["ArrowLeft"], {
            color: "Indigo",
            strokeWidth: 3,
            size: 20
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 25
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 21
      }, undefined), showBackBtn && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        className: classes.iconRoot,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
          className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(classes[backBtnColor], isStatusCard ? classes.goBackBtn1 : classes.goBackBtn2),
          onClick: onClickBack,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["ArrowLeft"], {
            color: "Indigo",
            size: 20,
            className: classes.visibleXs
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 60,
            columnNumber: 29
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["ChevronLeft"], {
            color: "Indigo",
            size: 30,
            className: classes.visibleDesktop
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 61,
            columnNumber: 29
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 25
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: backBtnColor !== 'backBtnPrimary' ? 'common.white' : 'button.secondaryColor',
          ml: 2,
          className: classes.visibleDesktop,
          children: "Go Back"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 25
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 53,
        columnNumber: 21
      }, undefined), children]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 42,
    columnNumber: 9
  }, undefined);
};

CommonCard.defaultProps = {
  bgColor: 'white',
  showHeader: false,
  children: '',
  showFaceBookLoginButton: false,
  isProfileSetup: false,
  isStatusCard: false,
  noMargin: false,
  showBackBtn: true,
  bgScreen: 'none',
  backBtnColor: 'backBtnPrimary',
  space: 'lg',
  pageView: 'half',
  landingPageIcon: false
};
CommonCard.propTypes = {
  bgColor: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['white', 'primary', 'gray', 'transparent']),
  onClickBack: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  onClickContinue: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  showHeader: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  children: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.node,
  showFaceBookLoginButton: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  isProfileSetup: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  isStatusCard: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  noMargin: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  showBackBtn: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  bgScreen: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['welcome', 'success', 'none']),
  backBtnColor: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['backBtnWhite', 'backBtnPrimary']),
  space: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['lg', 'xs']),
  pageView: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['full', 'half']),
  landingPageIcon: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (CommonCard);

/***/ }),

/***/ "./src/shared/components/CommonCard/CommonCardStyle.js":
/*!*************************************************************!*\
  !*** ./src/shared/components/CommonCard/CommonCardStyle.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  root: {
    padding: '24px 24px 52px',
    maxWidth: '960px',
    position: 'relative',
    zIndex: '1',
    [theme.breakpoints.down('xs')]: {
      padding: '24px 24px 52px'
    }
  },
  lg: {
    margin: '0 auto',
    [theme.breakpoints.down('xs')]: {
      margin: '-66px 24px 0'
    }
  },
  xs: {
    margin: 0
  },
  primary: {
    background: theme.palette.menus.menuBackground
  },
  white: {
    background: theme.palette.common.white
  },
  gray: {
    background: theme.common.gray
  },
  transparent: {
    background: 'transparent',
    boxShadow: 'none',
    [theme.breakpoints.down('xs')]: {
      margin: '-68px 0px 0'
    }
  },
  welcome: {
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundImage: `url('/splash.svg')`,
    [theme.breakpoints.down('sm')]: {
      backgroundImage: `url('/splashMobile.svg')`
    }
  },
  success: {
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    backgroundImage: `url('/successBg.svg')`,
    [theme.breakpoints.down('sm')]: {
      backgroundImage: `url('/successBgMobile.svg')`
    }
  },
  none: {
    backgroundImage: 'none'
  },
  subRoot: {
    maxWidth: '960px',
    margin: '0 auto',
    width: '100%',
    minHeight: '160px',
    [theme.breakpoints.down('sm')]: {
      minHeight: 'auto'
    }
  },
  full: {
    minHeight: '100vh',
    width: '100%',
    maxWidth: 'unset',
    display: 'flex',
    alignItems: 'center',
    borderRadius: '0',
    [theme.breakpoints.down('xs')]: {
      margin: '0 auto'
    }
  },
  half: {
    minHeight: 'auto'
  },
  header: {
    minHeight: 'calc(100vh - 78px)'
  },
  backBtnPrimary: {
    backgroundColor: 'rgba(151, 151, 191, 0.2)',
    '&:hover': {
      backgroundColor: theme.common.white,
      opacity: '0.5'
    },
    [theme.breakpoints.down('xs')]: {
      display: 'none'
    }
  },
  backBtnWhite: {
    backgroundColor: theme.common.white,
    '&:hover': {
      backgroundColor: theme.common.white,
      opacity: '0.5'
    }
  },
  visibleDesktop: {
    display: 'none',
    [theme.breakpoints.up('md')]: {
      display: 'block'
    }
  },
  visibleXs: {
    display: 'none',
    [theme.breakpoints.down('sm')]: {
      display: 'block'
    }
  },
  iconRoot: {
    paddingBottom: '30px',
    [theme.breakpoints.down('sm')]: {
      paddingBottom: '10px'
    },
    [theme.breakpoints.down('xs')]: {
      display: 'none'
    }
  },
  mobileBackBtn: {
    display: 'none',
    [theme.breakpoints.down('xs')]: {
      backgroundColor: theme.common.white,
      display: 'block',
      '&:hover': {
        backgroundColor: theme.common.white,
        opacity: '0.5'
      }
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/CommonCard/index.js":
/*!***************************************************!*\
  !*** ./src/shared/components/CommonCard/index.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _CommonCard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CommonCard */ "./src/shared/components/CommonCard/CommonCard.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _CommonCard__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardAccount/DashboardAccount.js":
/*!*******************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardAccount/DashboardAccount.js ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Tab */ "@material-ui/core/Tab");
/* harmony import */ var _material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Tabs */ "@material-ui/core/Tabs");
/* harmony import */ var _material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/shared/components/CommonCard */ "./src/shared/components/CommonCard/index.js");
/* harmony import */ var _DashboardAccountStyles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./DashboardAccountStyles */ "./src/shared/components/DashboardPageComponent/DashboardAccount/DashboardAccountStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\DashboardPageComponent\\DashboardAccount\\DashboardAccount.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









/**
 * Name: DashboardAccount
 * Desc: Render DashboardAccount
 */

const DashboardAccount = () => {
  const classes = Object(_DashboardAccountStyles__WEBPACK_IMPORTED_MODULE_8__["default"])();
  const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_5___default.a.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const accountLinks = [{
    text: 'Account Details',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["User"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }, {
    text: 'Household Details',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["Settings"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }, {
    text: 'Saved Documents',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["Save"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }, {
    text: 'Archived Applications',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["Archive"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }];
  const accountLinkName = [{
    label: 'Name',
    info: 'Erika Alexander'
  }, {
    label: 'T-Number',
    info: 'T-123456'
  }, {
    label: 'Your Voucher',
    info: 'Active'
  }, {
    label: 'Email Address',
    info: 'email@email.com'
  }, {
    label: '',
    info: 'Update Your Password'
  }, {
    label: '',
    info: 'Connected Facebook Account'
  }];
  const contactInformationLinks = [{
    label: 'Landline Phone',
    info: '(915) 555-1234'
  }, {
    label: 'Cell Phone',
    info: '(915) 555-1234'
  }, {
    label: 'Address',
    info: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 1,
        children: "Address Line One"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 1,
        children: "Address Line Two"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        children: "City, State, Zip Code"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 17
    }, undefined)
  }, {
    label: 'Your Trusted Contact',
    info: 'Firstname Lastname'
  }];

  function a11yProps(index) {
    return {
      id: `vertical-tab-${index}`,
      'aria-controls': `vertical-tabpanel-${index}`
    };
  }

  function TabPanel(props) {
    const {
      children,
      value,
      index
    } = props,
          other = _objectWithoutProperties(props, ["children", "value", "index"]);

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], _objectSpread(_objectSpread({
      width: "100%",
      maxWidth: "640px",
      role: "tabpanel",
      hidden: value !== index,
      id: `vertical-tabpanel-${index}`,
      "aria-labelledby": `vertical-tab-${index}`,
      className: classes.tabWrapper
    }, other), {}, {
      children: value === index && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__["default"], {
        showBackBtn: false,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 21
      }, this)
    }), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 61,
      columnNumber: 13
    }, this);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "none",
      className: classes.webTabs,
      mb: 12,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          mt: 10,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.light",
              fontSize: "h1.fontSize",
              fontFamily: "fontFamily.bold",
              textAlign: "right",
              position: "relative",
              top: "140px",
              mr: 5,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                children: "Your"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 92,
                columnNumber: 33
              }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                children: "Account"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 92,
                columnNumber: 49
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 84,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3___default.a, {
              orientation: "vertical",
              variant: "scrollable",
              value: value,
              onChange: handleChange,
              "aria-label": "Vertical tabs example",
              className: classes.tabs,
              children: accountLinks.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread({
                label: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  className: classes.cardLinks,
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      display: "flex",
                      alignItems: "center",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        mr: 2,
                        color: "primary.main",
                        fontSize: "h5.fontSize",
                        display: "flex",
                        alignItems: "center",
                        fontFamily: "fontFamily.medium",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
                          color: "Indigo",
                          size: 24
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 119,
                          columnNumber: 61
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 112,
                        columnNumber: 57
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        mr: 1,
                        maxWidth: "400px",
                        color: "primary.main",
                        fontSize: "h5.fontSize",
                        fontFamily: "fontFamily.medium",
                        whiteSpace: "noWrap",
                        children: item.text
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 122,
                        columnNumber: 57
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 111,
                      columnNumber: 53
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      display: "flex",
                      className: "arrow",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.rightIcon, {
                        color: "Indigo",
                        size: 24
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 133,
                        columnNumber: 57
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 132,
                      columnNumber: 53
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 110,
                    columnNumber: 49
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 105,
                  columnNumber: 45
                }, undefined)
              }, a11yProps(0)), item.text, false, {
                fileName: _jsxFileName,
                lineNumber: 102,
                columnNumber: 37
              }, undefined))
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 94,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 83,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            width: "100%",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 0,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                padding: "16px",
                maxWidth: "592px",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h5.fontSize",
                  fontFamily: "fontFamily.bold",
                  children: "Account Information"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 146,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  children: accountLinkName.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    pt: 2,
                    pb: 2,
                    minHeight: "90px",
                    className: classes.cardLinks,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                      href: "#",
                      underline: "none",
                      className: classes.cardLinksText,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        display: "flex",
                        alignItems: "center",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          display: "flex",
                          flexDirection: "column",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                            color: "primary.extraLight",
                            fontSize: "mdxl.fontSize",
                            children: item.label
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 169,
                            columnNumber: 61
                          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                            mr: 1,
                            color: "primary.light",
                            fontSize: "h6.fontSize",
                            children: item.info
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 175,
                            columnNumber: 61
                          }, undefined)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 168,
                          columnNumber: 57
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          display: "flex",
                          marginLeft: "auto",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                            color: "Indigo",
                            size: 24
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 183,
                            columnNumber: 61
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 182,
                          columnNumber: 57
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 167,
                        columnNumber: 53
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 163,
                      columnNumber: 49
                    }, undefined)
                  }, item, false, {
                    fileName: _jsxFileName,
                    lineNumber: 154,
                    columnNumber: 45
                  }, undefined))
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 152,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h5.fontSize",
                  fontFamily: "fontFamily.bold",
                  mt: 6,
                  children: "Contact Information"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 193,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  mb: 6,
                  children: contactInformationLinks.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    pt: 2,
                    pb: 2,
                    minHeight: "90px",
                    className: classes.cardLinks,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                      href: "#",
                      underline: "none",
                      className: classes.cardLinksText,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        display: "flex",
                        alignItems: "center",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          display: "flex",
                          flexDirection: "column",
                          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                            color: "primary.extraLight",
                            fontSize: "mdxl.fontSize",
                            children: item.label
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 217,
                            columnNumber: 61
                          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                            mr: 1,
                            color: "primary.light",
                            fontSize: "h6.fontSize",
                            children: item.info
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 223,
                            columnNumber: 61
                          }, undefined)]
                        }, void 0, true, {
                          fileName: _jsxFileName,
                          lineNumber: 216,
                          columnNumber: 57
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          display: "flex",
                          marginLeft: "auto",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                            color: "Indigo",
                            size: 24
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 231,
                            columnNumber: 61
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 230,
                          columnNumber: 57
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 215,
                        columnNumber: 53
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 211,
                      columnNumber: 49
                    }, undefined)
                  }, item, false, {
                    fileName: _jsxFileName,
                    lineNumber: 202,
                    columnNumber: 45
                  }, undefined))
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 200,
                  columnNumber: 37
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 145,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 144,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 1,
              children: "Item Two"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 243,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 2,
              children: "Item Three"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 246,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 2,
              children: "Item Three"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 249,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 143,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 80,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      margin: "0 24px 50px",
      className: classes.mobileTabs,
      children: accountLinks.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        pt: 3,
        pb: 3,
        className: classes.cardLinks,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
          href: "#",
          underline: "none",
          className: classes.cardLinksText,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            display: "flex",
            alignItems: "center",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mr: 2,
                color: "primary.light",
                fontSize: "h5.fontSize",
                display: "flex",
                alignItems: "center",
                fontFamily: "fontFamily.medium",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
                  color: "Indigo",
                  size: 24
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 276,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 269,
                columnNumber: 37
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mr: 1,
                maxWidth: "400px",
                color: "primary.light",
                fontSize: "h5.fontSize",
                fontFamily: "fontFamily.medium",
                children: item.text
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 279,
                columnNumber: 37
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 268,
              columnNumber: 33
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              marginLeft: "auto",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                color: "Indigo",
                size: 24
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 289,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 288,
              columnNumber: 33
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 267,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 266,
          columnNumber: 25
        }, undefined)
      }, item, false, {
        fileName: _jsxFileName,
        lineNumber: 258,
        columnNumber: 21
      }, undefined))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 256,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 79,
    columnNumber: 9
  }, undefined);
};

DashboardAccount.propTypes = {
  children: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.any,
  value: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number,
  index: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number
};
/* harmony default export */ __webpack_exports__["default"] = (DashboardAccount);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardAccount/DashboardAccountStyles.js":
/*!*************************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardAccount/DashboardAccountStyles.js ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  cardLinks: {
    '&:not(:last-child)': {
      borderBottom: `1px solid ${theme.common.gray}`
    }
  },
  customCard: {
    padding: 0,
    position: 'relative',
    zIndex: '1'
  },
  cardLinksText: {
    width: '100%'
  },
  mobileBtn: {
    [theme.breakpoints.down('sm')]: {
      position: 'absolute',
      bottom: '0',
      left: '0',
      right: '0'
    }
  },
  tabWrapper: {
    '& > div': {
      minHeight: '800px',
      paddingBottom: '8px'
    }
  },
  mobileTabs: {
    [theme.breakpoints.up('md')]: {
      display: 'none'
    }
  },
  webTabs: {
    [theme.breakpoints.up('md')]: {
      display: 'block'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardAccount/index.js":
/*!********************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardAccount/index.js ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardAccount__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardAccount */ "./src/shared/components/DashboardPageComponent/DashboardAccount/DashboardAccount.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _DashboardAccount__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardAccountDetails/DashboardAccountDetails.js":
/*!*********************************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardAccountDetails/DashboardAccountDetails.js ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _DashboardAccountDetailsStyles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./DashboardAccountDetailsStyles */ "./src/shared/components/DashboardPageComponent/DashboardAccountDetails/DashboardAccountDetailsStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\DashboardPageComponent\\DashboardAccountDetails\\DashboardAccountDetails.js";




/**
 * Name: DashboardAccountDetails
 * Desc: Render DashboardAccountDetails
 */

const DashboardAccountDetails = () => {
  const classes = Object(_DashboardAccountDetailsStyles__WEBPACK_IMPORTED_MODULE_4__["default"])();
  const accountLinks = [{
    label: 'Name',
    info: 'Erika Alexander'
  }, {
    label: 'T-Number',
    info: 'T-123456'
  }, {
    label: 'Your Voucher',
    info: 'Active'
  }, {
    label: 'Email Address',
    info: 'email@email.com'
  }, {
    label: '',
    info: 'Update Your Password'
  }, {
    label: '',
    info: 'Connected Facebook Account'
  }];
  const contactInformationLinks = [{
    label: 'Landline Phone',
    info: '(915) 555-1234'
  }, {
    label: 'Cell Phone',
    info: '(915) 555-1234'
  }, {
    label: 'Address',
    info: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 1,
        children: "Address Line One"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 1,
        children: "Address Line Two"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        children: "City, State, Zip Code"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 17
    }, undefined)
  }, {
    label: 'Your Trusted Contact',
    info: 'Firstname Lastname'
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      padding: "24px 8px",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        color: "primary.light",
        fontSize: "h5.fontSize",
        fontFamily: "fontFamily.bold",
        children: "Account Information"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        children: accountLinks.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2,
          pb: 2,
          minHeight: "90px",
          className: classes.cardLinks,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
            href: "#",
            underline: "none",
            className: classes.cardLinksText,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                flexDirection: "column",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.extraLight",
                  fontSize: "mdxl.fontSize",
                  children: item.label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 55,
                  columnNumber: 41
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  mr: 1,
                  color: "primary.light",
                  fontSize: "h6.fontSize",
                  children: item.info
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 59,
                  columnNumber: 41
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 54,
                columnNumber: 37
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                marginLeft: "auto",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_3__["ChevronRight"], {
                  color: "Indigo",
                  size: 24
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 64,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 63,
                columnNumber: 37
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 53,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 29
          }, undefined)
        }, item, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 25
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        color: "primary.light",
        fontSize: "h5.fontSize",
        fontFamily: "fontFamily.bold",
        mt: 6,
        children: "Contact Information"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 6,
        children: contactInformationLinks.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2,
          pb: 2,
          minHeight: "90px",
          className: classes.cardLinks,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
            href: "#",
            underline: "none",
            className: classes.cardLinksText,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                flexDirection: "column",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.extraLight",
                  fontSize: "mdxl.fontSize",
                  children: item.label
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 92,
                  columnNumber: 41
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  mr: 1,
                  color: "primary.light",
                  fontSize: "h6.fontSize",
                  children: item.info
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 96,
                  columnNumber: 41
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 91,
                columnNumber: 37
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                marginLeft: "auto",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_3__["ChevronRight"], {
                  color: "Indigo",
                  size: 24
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 101,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 100,
                columnNumber: 37
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 90,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 29
          }, undefined)
        }, item, false, {
          fileName: _jsxFileName,
          lineNumber: 80,
          columnNumber: 25
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 78,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 37,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 36,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (DashboardAccountDetails);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardAccountDetails/DashboardAccountDetailsStyles.js":
/*!***************************************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardAccountDetails/DashboardAccountDetailsStyles.js ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  cardLinks: {
    borderBottom: `1px solid ${theme.common.gray}`
  },
  cardLinksText: {
    width: '100%'
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardAccountDetails/index.js":
/*!***************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardAccountDetails/index.js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardAccountDetails__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardAccountDetails */ "./src/shared/components/DashboardPageComponent/DashboardAccountDetails/DashboardAccountDetails.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _DashboardAccountDetails__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardContactUs/DashboardContactUs.js":
/*!***********************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardContactUs/DashboardContactUs.js ***!
  \***********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\DashboardPageComponent\\DashboardContactUs\\DashboardContactUs.js";


/**
 * Name : DashboardContactUs
 * Desc : DashboardContactUs
 */

const DashboardContactUs = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      bgcolor: "secondary.extraLight",
      pt: 3,
      pb: 3,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
          container: true,
          spacing: 3,
          alignItems: "center",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
            item: true,
            xs: 12,
            md: 6,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Avatar"], {
                style: {
                  height: '292px',
                  width: '100%'
                },
                alt: "view",
                src: "/contactImg.jpg",
                variant: "square"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 17,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 16,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
            item: true,
            xs: 12,
            md: 6,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "common.lightBlack",
              fontSize: "h5.fontSize",
              fontFamily: "fontFamily.semiBold",
              mb: 2,
              children: "How Something Else Works"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 29,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.light",
              fontSize: "h6.fontSize",
              children: "5300 E. Paisano Drive"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.light",
              fontSize: "h6.fontSize",
              children: "El Paso, Texas 79905"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 39,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                color: "primary.main",
                fontSize: "h6.fontSize",
                children: "Get Directions"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 43,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 42,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              mt: 4,
              pb: 3,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "large",
                color: "primary",
                variant: "contained",
                children: "(915) 849-3124"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 48,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      pt: 7,
      pb: 6,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.light",
          fontSize: "h5.fontSize",
          fontFamily: "fontFamily.bold",
          mb: 1,
          children: "Office Hours"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.extraLight",
          fontSize: "h6.fontSize",
          children: "Monday through"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.extraLight",
          fontSize: "h6.fontSize",
          mb: 4,
          children: "Friday 8 a.m. to 5 p.m."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.light",
          fontSize: "h5.fontSize",
          fontFamily: "fontFamily.bold",
          mb: 1,
          children: "Special Assistance"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 71,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.extraLight",
          fontSize: "h6.fontSize",
          mb: 4,
          children: "Deaf or hard of hearing clients may use the TDD telephone line"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          size: "large",
          color: "primary",
          variant: "contained",
          children: "Log In"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 81,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (DashboardContactUs);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardContactUs/index.js":
/*!**********************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardContactUs/index.js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardContactUs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardContactUs */ "./src/shared/components/DashboardPageComponent/DashboardContactUs/DashboardContactUs.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _DashboardContactUs__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardHelpCenter/DashboardHelpCenter.js":
/*!*************************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardHelpCenter/DashboardHelpCenter.js ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Tab */ "@material-ui/core/Tab");
/* harmony import */ var _material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Tabs */ "@material-ui/core/Tabs");
/* harmony import */ var _material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/shared/components/CommonCard */ "./src/shared/components/CommonCard/index.js");
/* harmony import */ var _DashboardHelpCenterStyles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./DashboardHelpCenterStyles */ "./src/shared/components/DashboardPageComponent/DashboardHelpCenter/DashboardHelpCenterStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\DashboardPageComponent\\DashboardHelpCenter\\DashboardHelpCenter.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









/**
 * Name: DashboardHelpCenter
 * Desc: Render DashboardHelpCenter
 */

const DashboardHelpCenter = () => {
  const classes = Object(_DashboardHelpCenterStyles__WEBPACK_IMPORTED_MODULE_8__["default"])();
  const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_5___default.a.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  const gettingStartedText = [{
    text: 'First time users getting started with housing assistance'
  }, {
    text: 'Helping a relative, patient, or client with an application'
  }, {
    text: 'What to expect from the application process'
  }];
  const eligibilityQuestionsText = [{
    text: 'Finding out if you are eligible for program assistance'
  }, {
    text: 'Why wasn’t I eligible for HACEP’s programs?'
  }];
  const otherTopicsText = [{
    text: 'What to do when your financial situation or household has changed'
  }, {
    text: 'These each would get a page where HACEP can enter text'
  }, {
    text: 'These will all be purely content that HACEP determines '
  }, {
    text: 'Add as many sections and topics that are needed'
  }];
  const linkArray = [{
    text: 'Help Topics',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["HelpCircle"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }, {
    text: 'Contact Us',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["Phone"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }, {
    text: 'Program Information',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["Info"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }];

  function a11yProps(index) {
    return {
      id: `vertical-tab-${index}`,
      'aria-controls': `vertical-tabpanel-${index}`
    };
  }

  function TabPanel(props) {
    const {
      children,
      value,
      index
    } = props,
          other = _objectWithoutProperties(props, ["children", "value", "index"]);

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], _objectSpread(_objectSpread({
      width: "100%",
      maxWidth: "640px",
      role: "tabpanel",
      hidden: value !== index,
      id: `vertical-tabpanel-${index}`,
      "aria-labelledby": `vertical-tab-${index}`,
      className: classes.tabWrapper
    }, other), {}, {
      children: value === index && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__["default"], {
        showBackBtn: false,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 21
      }, this)
    }), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 54,
      columnNumber: 13
    }, this);
  }

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "none",
      className: classes.webTabs,
      mb: 12,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          mt: 10,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.light",
              fontSize: "h1.fontSize",
              fontFamily: "fontFamily.bold",
              textAlign: "right",
              position: "relative",
              top: "140px",
              mr: 5,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                children: "Help"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 85,
                columnNumber: 33
              }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                children: "Center"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 85,
                columnNumber: 49
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 77,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3___default.a, {
              orientation: "vertical",
              variant: "scrollable",
              value: value,
              onChange: handleChange,
              "aria-label": "Vertical tabs example",
              className: classes.tabs,
              children: linkArray.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread({
                label: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  className: classes.cardLinks,
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      display: "flex",
                      alignItems: "center",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        mr: 2,
                        color: "primary.main",
                        fontSize: "h5.fontSize",
                        display: "flex",
                        alignItems: "center",
                        fontFamily: "fontFamily.medium",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
                          color: "Indigo",
                          size: 24
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 112,
                          columnNumber: 61
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 105,
                        columnNumber: 57
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        mr: 1,
                        maxWidth: "400px",
                        color: "primary.main",
                        fontSize: "h5.fontSize",
                        fontFamily: "fontFamily.medium",
                        whiteSpace: "noWrap",
                        children: item.text
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 115,
                        columnNumber: 57
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 104,
                      columnNumber: 53
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      display: "flex",
                      className: "arrow",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.rightIcon, {
                        color: "Indigo",
                        size: 24
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 126,
                        columnNumber: 57
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 125,
                      columnNumber: 53
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 103,
                    columnNumber: 49
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 98,
                  columnNumber: 45
                }, undefined)
              }, a11yProps(0)), item.text, false, {
                fileName: _jsxFileName,
                lineNumber: 95,
                columnNumber: 37
              }, undefined))
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 87,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            width: "100%",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 0,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                padding: "16px",
                maxWidth: "592px",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h5.fontSize",
                  fontFamily: "fontFamily.bold",
                  children: "Getting Started"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 139,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  children: gettingStartedText.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    pt: 2,
                    pb: 2,
                    minHeight: "90px",
                    className: classes.cardLinks,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                      href: "#",
                      underline: "none",
                      className: classes.cardLinksText,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        display: "flex",
                        alignItems: "center",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          mr: 1,
                          color: "primary.main",
                          fontSize: "h6.fontSize",
                          children: item.text
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 161,
                          columnNumber: 57
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          display: "flex",
                          marginLeft: "auto",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                            color: "Indigo",
                            size: 24
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 169,
                            columnNumber: 61
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 168,
                          columnNumber: 57
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 160,
                        columnNumber: 53
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 156,
                      columnNumber: 49
                    }, undefined)
                  }, item, false, {
                    fileName: _jsxFileName,
                    lineNumber: 147,
                    columnNumber: 45
                  }, undefined))
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 145,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h5.fontSize",
                  fontFamily: "fontFamily.bold",
                  mt: 6,
                  children: "Eligibility Questions"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 179,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  mb: 6,
                  children: eligibilityQuestionsText.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    pt: 2,
                    pb: 2,
                    minHeight: "90px",
                    className: classes.cardLinks,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                      href: "#",
                      underline: "none",
                      className: classes.cardLinksText,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        display: "flex",
                        alignItems: "center",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          mr: 1,
                          color: "primary.main",
                          fontSize: "h6.fontSize",
                          children: item.text
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 202,
                          columnNumber: 57
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          display: "flex",
                          marginLeft: "auto",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                            color: "Indigo",
                            size: 24
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 210,
                            columnNumber: 61
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 209,
                          columnNumber: 57
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 201,
                        columnNumber: 53
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 197,
                      columnNumber: 49
                    }, undefined)
                  }, item, false, {
                    fileName: _jsxFileName,
                    lineNumber: 188,
                    columnNumber: 45
                  }, undefined))
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 186,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h5.fontSize",
                  fontFamily: "fontFamily.bold",
                  mt: 6,
                  children: "Other Topics"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 220,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  children: otherTopicsText.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "space-between",
                    pt: 2,
                    pb: 2,
                    minHeight: "90px",
                    className: classes.cardLinks,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                      href: "#",
                      underline: "none",
                      className: classes.cardLinksText,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        display: "flex",
                        alignItems: "center",
                        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          mr: 1,
                          color: "primary.main",
                          fontSize: "h6.fontSize",
                          children: item.text
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 243,
                          columnNumber: 57
                        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                          display: "flex",
                          marginLeft: "auto",
                          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                            color: "Indigo",
                            size: 24
                          }, void 0, false, {
                            fileName: _jsxFileName,
                            lineNumber: 251,
                            columnNumber: 61
                          }, undefined)
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 250,
                          columnNumber: 57
                        }, undefined)]
                      }, void 0, true, {
                        fileName: _jsxFileName,
                        lineNumber: 242,
                        columnNumber: 53
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 238,
                      columnNumber: 49
                    }, undefined)
                  }, item, false, {
                    fileName: _jsxFileName,
                    lineNumber: 229,
                    columnNumber: 45
                  }, undefined))
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 227,
                  columnNumber: 37
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 138,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 137,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 1,
              children: "Item Two"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 263,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 2,
              children: "Item Three"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 266,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 136,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 75,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 74,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 73,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      margin: "0 8px 50px",
      className: classes.mobileTabs,
      children: linkArray.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        pt: 3,
        pb: 3,
        className: classes.cardLinks,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
          href: "#",
          underline: "none",
          className: classes.cardLinksText,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            display: "flex",
            alignItems: "center",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mr: 2,
                color: "primary.light",
                fontSize: "h5.fontSize",
                display: "flex",
                alignItems: "center",
                fontFamily: "fontFamily.medium",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
                  color: "Indigo",
                  size: 24
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 293,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 286,
                columnNumber: 37
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mr: 1,
                maxWidth: "400px",
                color: "primary.light",
                fontSize: "h5.fontSize",
                fontFamily: "fontFamily.medium",
                children: item.text
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 296,
                columnNumber: 37
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 285,
              columnNumber: 33
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              marginLeft: "auto",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                color: "Indigo",
                size: 24
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 306,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 305,
              columnNumber: 33
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 284,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 283,
          columnNumber: 25
        }, undefined)
      }, item, false, {
        fileName: _jsxFileName,
        lineNumber: 275,
        columnNumber: 21
      }, undefined))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 273,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 72,
    columnNumber: 9
  }, undefined);
};

DashboardHelpCenter.propTypes = {
  children: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.any,
  value: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number,
  index: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number
};
/* harmony default export */ __webpack_exports__["default"] = (DashboardHelpCenter);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardHelpCenter/DashboardHelpCenterStyles.js":
/*!*******************************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardHelpCenter/DashboardHelpCenterStyles.js ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  cardLinks: {
    '&:not(:last-child)': {
      borderBottom: `1px solid ${theme.common.gray}`
    }
  },
  customCard: {
    padding: 0,
    position: 'relative',
    zIndex: '1'
  },
  cardLinksText: {
    width: '100%'
  },
  mobileBtn: {
    [theme.breakpoints.down('sm')]: {
      position: 'absolute',
      bottom: '0',
      left: '0',
      right: '0'
    }
  },
  tabWrapper: {
    '& > div': {
      minHeight: '800px',
      paddingBottom: '8px'
    }
  },
  mobileTabs: {
    [theme.breakpoints.up('sm')]: {
      display: 'none'
    }
  },
  webTabs: {
    [theme.breakpoints.up('sm')]: {
      display: 'block'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardHelpCenter/index.js":
/*!***********************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardHelpCenter/index.js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardHelpCenter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardHelpCenter */ "./src/shared/components/DashboardPageComponent/DashboardHelpCenter/DashboardHelpCenter.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _DashboardHelpCenter__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardHelpTopics/DashboardHelpTopics.js":
/*!*************************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardHelpTopics/DashboardHelpTopics.js ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Tab */ "@material-ui/core/Tab");
/* harmony import */ var _material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Tabs */ "@material-ui/core/Tabs");
/* harmony import */ var _material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/shared/components/CommonCard */ "./src/shared/components/CommonCard/index.js");
/* harmony import */ var _DashboardHelpTopicsStyles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./DashboardHelpTopicsStyles */ "./src/shared/components/DashboardPageComponent/DashboardHelpTopics/DashboardHelpTopicsStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\DashboardPageComponent\\DashboardHelpTopics\\DashboardHelpTopics.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }









/**
 * Name: DashboardHelpTopics
 * Desc: Render DashboardHelpTopics
 */

const DashboardHelpTopics = () => {
  const classes = Object(_DashboardHelpTopicsStyles__WEBPACK_IMPORTED_MODULE_8__["default"])();
  const [value, setValue] = react__WEBPACK_IMPORTED_MODULE_5___default.a.useState(0);

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  function a11yProps(index) {
    return {
      id: `vertical-tab-${index}`,
      'aria-controls': `vertical-tabpanel-${index}`
    };
  }

  function TabPanel(props) {
    const {
      children,
      value,
      index
    } = props,
          other = _objectWithoutProperties(props, ["children", "value", "index"]);

    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], _objectSpread(_objectSpread({
      width: "100%",
      maxWidth: "640px",
      role: "tabpanel",
      hidden: value !== index,
      id: `vertical-tabpanel-${index}`,
      "aria-labelledby": `vertical-tab-${index}`,
      className: classes.tabWrapper
    }, other), {}, {
      children: value === index && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_CommonCard__WEBPACK_IMPORTED_MODULE_7__["default"], {
        showBackBtn: false,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 42,
          columnNumber: 25
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 21
      }, this)
    }), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 13
    }, this);
  }

  const accountLinks = [{
    text: 'Help Topics',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["User"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }, {
    text: 'Contact Us',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["Settings"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }, {
    text: 'Program Information',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_6__["Save"],
    rightIcon: react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"]
  }];
  const gettingStartedText = [{
    text: 'First time users getting started with housing assistance'
  }, {
    text: 'Helping a relative, patient, or client with an application'
  }, {
    text: 'What to expect from the application process'
  }];
  const eligibilityQuestionsText = [{
    text: 'Finding out if you are eligible for program assistance'
  }, {
    text: 'Why wasn’t I eligible for HACEP’s programs?'
  }];
  const otherTopicsText = [{
    text: 'What to do when your financial situation or household has changed'
  }, {
    text: 'These each would get a page where HACEP can enter text'
  }, {
    text: 'These will all be purely content that HACEP determines '
  }, {
    text: 'Add as many sections and topics that are needed'
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "none",
      className: classes.webTabs,
      mb: 12,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          mt: 10,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.light",
              fontSize: "h1.fontSize",
              fontFamily: "fontFamily.bold",
              textAlign: "right",
              position: "relative",
              top: "140px",
              mr: 5,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                children: "Help"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 82,
                columnNumber: 33
              }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                children: "Center"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 82,
                columnNumber: 49
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Tabs__WEBPACK_IMPORTED_MODULE_3___default.a, {
              orientation: "vertical",
              variant: "scrollable",
              value: value,
              onChange: handleChange,
              "aria-label": "Vertical tabs example",
              className: classes.tabs,
              children: accountLinks.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Tab__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread({
                label: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "space-between",
                  className: classes.cardLinks,
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      display: "flex",
                      alignItems: "center",
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        mr: 2,
                        color: "primary.main",
                        fontSize: "h5.fontSize",
                        display: "flex",
                        alignItems: "center",
                        fontFamily: "fontFamily.medium",
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
                          color: "Indigo",
                          size: 24
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 109,
                          columnNumber: 61
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 102,
                        columnNumber: 57
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        mr: 1,
                        maxWidth: "400px",
                        color: "primary.main",
                        fontSize: "h5.fontSize",
                        fontFamily: "fontFamily.medium",
                        whiteSpace: "noWrap",
                        children: item.text
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 112,
                        columnNumber: 57
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 101,
                      columnNumber: 53
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      display: "flex",
                      className: "arrow",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.rightIcon, {
                        color: "Indigo",
                        size: 24
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 123,
                        columnNumber: 57
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 122,
                      columnNumber: 53
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 100,
                    columnNumber: 49
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 95,
                  columnNumber: 45
                }, undefined)
              }, a11yProps(0)), item.text, false, {
                fileName: _jsxFileName,
                lineNumber: 92,
                columnNumber: 37
              }, undefined))
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 84,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            width: "100%",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 0,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                padding: "16px",
                maxWidth: "592px",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h5.fontSize",
                  fontFamily: "fontFamily.bold",
                  pb: 3,
                  mb: 4,
                  className: classes.title,
                  children: "Creating Your Account with HACEP\u2019s AppName"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 136,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h6.fontSize",
                  fontFamily: "fontFamily.bold",
                  mb: 2,
                  children: "How Something Works"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 145,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h6.fontSize",
                  mb: 5,
                  children: "ipsum dolor sit amet, consectetur adipiscing elit. Arcu pretium ultrices vitae pretium volutpat nibh. Dolor ullamcorper id et commodo. At vel mauris vulputate malesuada auctor dis eu sed. Ac ornare diam viverra laoreet."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 152,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h6.fontSize",
                  mb: 3,
                  children: "Elementum pretium nulla neque, convallis tortor nisl nullam tincidunt commodo. Leo vitae gravida dui bibendum nulla. Proin sed id mattis sed venenatis malesuada risus semper etiam. Diam id viverra urna cum tortor sed arcu sem sed."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 158,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  mb: 7,
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                    size: "medium",
                    color: "primary",
                    variant: "contained",
                    children: "Button Link"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 165,
                    columnNumber: 41
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 164,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  borderRadius: "5px",
                  overflow: "hidden",
                  mb: 3,
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Avatar"], {
                    style: {
                      height: '292px',
                      width: '100%'
                    },
                    alt: "view",
                    src: "/view.jpg",
                    variant: "square"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 170,
                    columnNumber: 41
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 169,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h6.fontSize",
                  fontFamily: "fontFamily.bold",
                  mb: 2,
                  children: "How Something Else Works"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 180,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "h6.fontSize",
                  mb: 3,
                  children: "ipsum dolor sit amet, consectetur adipiscing elit. Arcu pretium ultrices vitae pretium volutpat nibh. Dolor ullamcorper id et commodo. At vel mauris vulputate malesuada auctor dis eu sed. Ac ornare diam viverra laoreet."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 187,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  mb: 7,
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                    size: "medium",
                    color: "primary",
                    variant: "contained",
                    children: "Button Link"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 194,
                    columnNumber: 41
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 193,
                  columnNumber: 37
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 135,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 134,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 1,
              children: "Item Two"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 200,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(TabPanel, {
              value: value,
              index: 2,
              children: "Item Three"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 203,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 133,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 70,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      margin: "30px 8px 50px",
      className: classes.mobileTabs,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        color: "primary.light",
        fontSize: "h5.fontSize",
        fontFamily: "fontFamily.bold",
        children: "Getting Started"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 211,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        children: gettingStartedText.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2,
          pb: 2,
          minHeight: "90px",
          className: classes.cardLinks,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
            href: "#",
            underline: "none",
            className: classes.cardLinksText,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mr: 1,
                color: "primary.main",
                fontSize: "h6.fontSize",
                children: item.text
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 227,
                columnNumber: 37
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                marginLeft: "auto",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                  color: "Indigo",
                  size: 24
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 232,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 231,
                columnNumber: 37
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 226,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 225,
            columnNumber: 29
          }, undefined)
        }, item, false, {
          fileName: _jsxFileName,
          lineNumber: 216,
          columnNumber: 25
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 214,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        color: "primary.light",
        fontSize: "h5.fontSize",
        fontFamily: "fontFamily.bold",
        mt: 6,
        children: "Eligibility Questions"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 239,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 6,
        children: eligibilityQuestionsText.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2,
          pb: 2,
          minHeight: "90px",
          className: classes.cardLinks,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
            href: "#",
            underline: "none",
            className: classes.cardLinksText,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mr: 1,
                color: "primary.main",
                fontSize: "h6.fontSize",
                children: item.text
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 259,
                columnNumber: 37
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                marginLeft: "auto",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                  color: "Indigo",
                  size: 24
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 264,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 263,
                columnNumber: 37
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 258,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 257,
            columnNumber: 29
          }, undefined)
        }, item, false, {
          fileName: _jsxFileName,
          lineNumber: 248,
          columnNumber: 25
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 246,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        color: "primary.light",
        fontSize: "h5.fontSize",
        fontFamily: "fontFamily.bold",
        mt: 6,
        children: "Other Topics"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 271,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 6,
        children: otherTopicsText.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          pt: 2,
          pb: 2,
          minHeight: "90px",
          className: classes.cardLinks,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
            href: "#",
            underline: "none",
            className: classes.cardLinksText,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mr: 1,
                color: "primary.main",
                fontSize: "h6.fontSize",
                children: item.text
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 291,
                columnNumber: 37
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                marginLeft: "auto",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                  color: "Indigo",
                  size: 24
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 296,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 295,
                columnNumber: 37
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 290,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 289,
            columnNumber: 29
          }, undefined)
        }, item, false, {
          fileName: _jsxFileName,
          lineNumber: 280,
          columnNumber: 25
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 278,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 210,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 69,
    columnNumber: 9
  }, undefined);
};

DashboardHelpTopics.propTypes = {
  children: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.any,
  value: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number,
  index: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.number
};
/* harmony default export */ __webpack_exports__["default"] = (DashboardHelpTopics);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardHelpTopics/DashboardHelpTopicsStyles.js":
/*!*******************************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardHelpTopics/DashboardHelpTopicsStyles.js ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  cardLinks: {
    '&:not(:last-child)': {
      borderBottom: `1px solid ${theme.common.gray}`
    }
  },
  cardLinksText: {
    width: '100%'
  },
  tabWrapper: {
    '& > div': {
      minHeight: '800px',
      paddingBottom: '8px'
    }
  },
  mobileTabs: {
    [theme.breakpoints.up('md')]: {
      display: 'none'
    }
  },
  webTabs: {
    [theme.breakpoints.up('md')]: {
      display: 'block'
    }
  },
  title: {
    borderBottom: `1px solid ${theme.common.gray}`
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardHelpTopics/index.js":
/*!***********************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardHelpTopics/index.js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardHelpTopics__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardHelpTopics */ "./src/shared/components/DashboardPageComponent/DashboardHelpTopics/DashboardHelpTopics.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _DashboardHelpTopics__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardHome/DashboardHome.js":
/*!*************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardHome/DashboardHome.js ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/shared/components/ProgramCard */ "./src/shared/components/ProgramCard/index.js");
/* harmony import */ var _DashboardHomeStyles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./DashboardHomeStyles */ "./src/shared/components/DashboardPageComponent/DashboardHome/DashboardHomeStyles.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\DashboardPageComponent\\DashboardHome\\DashboardHome.js";







/**
 * Name: DashboardHome
 * Desc: Render DashboardHome
 */

const DashboardHome = () => {
  const classes = Object(_DashboardHomeStyles__WEBPACK_IMPORTED_MODULE_7__["default"])();
  const linkArray = [{
    text: 'Apply for other programs >',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_5__["Plus"]
  }, {
    text: 'Update your eligibility info >',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_5__["Edit"]
  }, {
    text: 'View (6) archived applications >',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_5__["Archive"]
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      pb: 2,
      bgcolor: "secondary.extraLight",
      className: classes.dashboardUpperWrapper,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          pt: 9,
          pb: 5,
          fontSize: "h5.fontSize",
          fontFamily: "fontFamily.bold",
          color: "primary.light",
          display: "none",
          className: classes.linkText,
          children: "Your Program Applications"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 26,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
          container: true,
          spacing: 4,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
            item: true,
            xs: 12,
            md: 8,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              mt: -8,
              className: classes.linkList,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mb: 3,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_6__["default"], {
                  variant: "success",
                  showImage: true,
                  showLeftArrow: true,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    color: "primary.main",
                    fontSize: "h6.fontSize",
                    fontFamily: "fontFamily.medium",
                    children: "Program Title on Card (1BR)"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 45,
                    columnNumber: 41
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    component: "body1",
                    color: "primary.light",
                    fontSize: "lg.fontSize",
                    fontFamily: "fontFamily.regular",
                    children: "Positive status"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 51,
                    columnNumber: 41
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 41,
                  columnNumber: 37
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 40,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mb: 3,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_6__["default"], {
                  variant: "waiting",
                  showImage: true,
                  showLeftArrow: true,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    color: "primary.main",
                    fontSize: "h6.fontSize",
                    fontFamily: "fontFamily.medium",
                    children: "Program Title on Card (1BR)"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 65,
                    columnNumber: 41
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    component: "body1",
                    color: "primary.light",
                    fontSize: "lg.fontSize",
                    fontFamily: "fontFamily.regular",
                    children: "Positive status"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 71,
                    columnNumber: 41
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 61,
                  columnNumber: 37
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 60,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mb: 3,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_6__["default"], {
                  variant: "failed",
                  showImage: true,
                  showLeftArrow: true,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    color: "primary.main",
                    fontSize: "h6.fontSize",
                    fontFamily: "fontFamily.medium",
                    children: "Program Title on Card (1BR)"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 85,
                    columnNumber: 41
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    component: "body1",
                    color: "primary.light",
                    fontSize: "lg.fontSize",
                    fontFamily: "fontFamily.regular",
                    children: "Positive status"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 91,
                    columnNumber: 41
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 81,
                  columnNumber: 37
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mb: 3,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_6__["default"], {
                  showImage: true,
                  showLeftArrow: false,
                  showLeftBorder: false,
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    color: "primary.main",
                    fontSize: "h6.fontSize",
                    fontFamily: "fontFamily.medium",
                    children: "Program Title on Card (1BR)"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 105,
                    columnNumber: 41
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    component: "body1",
                    color: "primary.light",
                    fontSize: "lg.fontSize",
                    fontFamily: "fontFamily.regular",
                    children: "Positive status"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 111,
                    columnNumber: 41
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 101,
                  columnNumber: 37
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 100,
                columnNumber: 33
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 39,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 38,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
            item: true,
            xs: 12,
            md: 4,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              children: linkArray.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                mb: 3,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                  href: "#",
                  underline: "none",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    alignItems: "center",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
                      strokeWidth: "2",
                      color: "Indigo",
                      size: 15
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 128,
                      columnNumber: 49
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      fontSize: "lg.fontSize",
                      color: "primary.main",
                      fontFamily: "fontFamily.medium",
                      ml: 1.5,
                      children: item.text
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 133,
                      columnNumber: 49
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 127,
                    columnNumber: 45
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 126,
                  columnNumber: 41
                }, undefined)
              }, item.text, false, {
                fileName: _jsxFileName,
                lineNumber: 125,
                columnNumber: 37
              }, undefined))
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 123,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 122,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 24,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mt: 8,
        mb: 5,
        fontSize: "h5.fontSize",
        fontFamily: "fontFamily.bold",
        color: "primary.extraLight",
        children: "More Resources"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 151,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        container: true,
        spacing: 4,
        children: [{
          imageName: '/Frame1.png',
          text: 'Calculate what you can afford to rent'
        }, {
          imageName: '/Frame2.png',
          text: 'Browse El Paso housing opportunites',
          bgColor: 'success'
        }, {
          imageName: '/Frame1.png',
          text: 'Find out if you’re eligible',
          bgColor: 'warning'
        }, {
          imageName: '/Frame2.png',
          text: 'Update your family or financial info'
        }].map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
          item: true,
          xs: 6,
          md: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            p: 0,
            borderRadius: "16px",
            mb: 8,
            className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(classes.boxWrapper, item.bgColor && classes[item.bgColor]),
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              borderRadius: "16px",
              mb: 2,
              className: classes.imageWrapper,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                justifyContent: "center",
                position: "relative",
                top: "-16px",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_3___default.a, {
                  src: item.imageName,
                  width: 207,
                  height: 186
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 195,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 190,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 189,
              columnNumber: 33
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                href: "#",
                underline: "none",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  display: "flex",
                  alignItems: "center",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    justifyContent: "flex-start",
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      fontSize: "lg.fontSize",
                      color: "primary.light",
                      fontFamily: "fontFamily.medium",
                      mr: 1,
                      children: [item.text, /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                        component: "span",
                        position: "relative",
                        top: "3px",
                        left: "5px",
                        className: classes.mobileArrow,
                        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["ChevronRight"], {
                          strokeWidth: 3,
                          color: "indigo",
                          size: 16
                        }, void 0, false, {
                          fileName: _jsxFileName,
                          lineNumber: 214,
                          columnNumber: 57
                        }, undefined)
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 208,
                        columnNumber: 53
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 202,
                      columnNumber: 49
                    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      fontSize: "h4.fontSize",
                      color: "primary.light",
                      fontFamily: "fontFamily.medium",
                      display: "none",
                      className: classes.webArrow,
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["ChevronRight"], {
                        strokeWidth: 3,
                        color: "indigo",
                        size: 16
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 227,
                        columnNumber: 53
                      }, undefined)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 221,
                      columnNumber: 49
                    }, undefined)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 201,
                    columnNumber: 45
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 200,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 199,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 198,
              columnNumber: 33
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 181,
            columnNumber: 29
          }, undefined)
        }, item.type, false, {
          fileName: _jsxFileName,
          lineNumber: 180,
          columnNumber: 25
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 159,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 150,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ __webpack_exports__["default"] = (DashboardHome);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardHome/DashboardHomeStyles.js":
/*!*******************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardHome/DashboardHomeStyles.js ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  linkText: {
    [theme.breakpoints.up('sm')]: {
      display: 'block'
    }
  },
  success: {
    [theme.breakpoints.up('sm')]: {
      backgroundColor: `${theme.palette.secondary.light} !important`
    },
    '& > div:first-child': {
      [theme.breakpoints.down('sm')]: {
        backgroundColor: `${theme.palette.secondary.light} !important`
      }
    }
  },
  warning: {
    [theme.breakpoints.up('sm')]: {
      backgroundColor: `${theme.palette.pending.extraLight} !important`
    },
    '& > div:first-child': {
      [theme.breakpoints.down('sm')]: {
        backgroundColor: `${theme.palette.pending.extraLight} !important`
      }
    }
  },
  boxWrapper: {
    [theme.breakpoints.up('sm')]: {
      marginBottom: '100px',
      backgroundColor: theme.common.secondaryBgColor,
      padding: '0px 24px 24px'
    }
  },
  imageWrapper: {
    backgroundColor: theme.common.secondaryBgColor,
    [theme.breakpoints.up('sm')]: {
      backgroundColor: 'transparent',
      marginBottom: 0
    }
  },
  linkList: {
    [theme.breakpoints.up('sm')]: {
      marginTop: 0
    }
  },
  dashboardUpperWrapper: {
    [theme.breakpoints.up('sm')]: {
      paddingBottom: '64px'
    }
  },
  mobileArrow: {
    [theme.breakpoints.up('sm')]: {
      display: 'none'
    }
  },
  webArrow: {
    [theme.breakpoints.up('sm')]: {
      display: 'block'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardHome/index.js":
/*!*****************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardHome/index.js ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardHome__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardHome */ "./src/shared/components/DashboardPageComponent/DashboardHome/DashboardHome.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _DashboardHome__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardNoPrograms/DashboardNoPrograms.js":
/*!*************************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardNoPrograms/DashboardNoPrograms.js ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _DashboardPageComponentStyles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../DashboardPageComponentStyles */ "./src/shared/components/DashboardPageComponent/DashboardPageComponentStyles.js");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\DashboardPageComponent\\DashboardNoPrograms\\DashboardNoPrograms.js";





/**
 * Name: DashboardNoPrograms
 * Desc: Render DashboardNoPrograms
 */

const DashboardNoPrograms = () => {
  const classes = Object(_DashboardPageComponentStyles__WEBPACK_IMPORTED_MODULE_3__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mt: 5.5,
        mb: 5,
        fontSize: "h5.fontSize",
        fontFamily: "fontFamily.bold",
        color: "primary.light",
        children: "More Resources"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        container: true,
        spacing: 4,
        children: [{
          imageName: '/Frame1.png',
          text: 'Rent Affordability Calculator'
        }, {
          imageName: '/Frame2.png',
          text: 'Browse Rental Properties on GoSection8',
          bgColor: 'success'
        }, {
          imageName: '/Frame1.png',
          text: 'Calculate what rent you can afford',
          bgColor: 'warning'
        }, {
          imageName: '/Frame2.png',
          text: 'Calculate what rent you can afford'
        }].map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
          item: true,
          xs: 6,
          md: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            p: 0,
            borderRadius: "16px",
            mb: 0,
            className: clsx__WEBPACK_IMPORTED_MODULE_4___default()(classes.boxWrapper, item.bgColor && classes[item.bgColor]),
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              borderRadius: "16px",
              mb: 2,
              className: classes.imageWrapper,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                justifyContent: "center",
                position: "relative",
                top: "-16px",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_5___default.a, {
                  src: item.imageName,
                  width: 207,
                  height: 186
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 61,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 56,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 55,
              columnNumber: 33
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                href: "#",
                underline: "none",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  display: "flex",
                  alignItems: "center",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    display: "flex",
                    justifyContent: "flex-start",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                      fontSize: "lg.fontSize",
                      color: "primary.light",
                      fontFamily: "fontFamily.medium",
                      mr: 1,
                      children: item.text
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 68,
                      columnNumber: 49
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 67,
                    columnNumber: 45
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 66,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 65,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 64,
              columnNumber: 33
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 29
          }, undefined)
        }, item.type, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 25
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

/* harmony default export */ __webpack_exports__["default"] = (DashboardNoPrograms);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardNoPrograms/index.js":
/*!***********************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardNoPrograms/index.js ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardNoPrograms__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardNoPrograms */ "./src/shared/components/DashboardPageComponent/DashboardNoPrograms/DashboardNoPrograms.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _DashboardNoPrograms__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardPageComponentStyles.js":
/*!**************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardPageComponentStyles.js ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  linkText: {
    [theme.breakpoints.up('sm')]: {
      display: 'block'
    }
  },
  success: {
    [theme.breakpoints.up('sm')]: {
      backgroundColor: `${theme.palette.secondary.light} !important`
    },
    '& > div:first-child': {
      [theme.breakpoints.down('sm')]: {
        backgroundColor: `${theme.palette.secondary.light} !important`
      }
    }
  },
  warning: {
    [theme.breakpoints.up('sm')]: {
      backgroundColor: `${theme.palette.pending.extraLight} !important`
    },
    '& > div:first-child': {
      [theme.breakpoints.down('sm')]: {
        backgroundColor: `${theme.palette.pending.extraLight} !important`
      }
    }
  },
  boxWrapper: {
    [theme.breakpoints.up('sm')]: {
      marginBottom: '100px',
      backgroundColor: theme.common.secondaryBgColor,
      padding: '0px 24px 24px'
    }
  },
  imageWrapper: {
    backgroundColor: theme.common.secondaryBgColor,
    [theme.breakpoints.up('sm')]: {
      backgroundColor: 'transparent',
      marginBottom: 0
    }
  },
  linkList: {
    [theme.breakpoints.up('sm')]: {
      marginTop: 0
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardYourApplication/DashboardYourApplication.js":
/*!***********************************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardYourApplication/DashboardYourApplication.js ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ProgramCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../ProgramCard */ "./src/shared/components/ProgramCard/index.js");
/* harmony import */ var _ObjectCard__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../ObjectCard */ "./src/shared/components/ObjectCard/index.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\DashboardPageComponent\\DashboardYourApplication\\DashboardYourApplication.js";





/**
 * Name: DashboardYourApplication
 * Desc: Render DashboardYourApplication
 */

const DashboardYourApplication = () => {
  const linkArray = [{
    text: 'Apply for other programs >',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_3__["Plus"]
  }, {
    text: 'Update your eligibility info >',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_3__["Edit"]
  }, {
    text: 'View (6) archived applications >',
    icon: react_feather__WEBPACK_IMPORTED_MODULE_3__["Archive"]
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      pb: 4.5,
      children: [[{
        programName: 'Housing Choice Voucher',
        status: "On Waitlist"
      }, {
        programName: 'Program Name (2BR)',
        status: "On Waitlist"
      }, {
        programName: 'Tays (1BR)',
        status: "On Waitlist"
      }, {
        programName: 'Siesta Gardens (2BR)',
        status: "Pending Review"
      }].map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 3,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ProgramCard__WEBPACK_IMPORTED_MODULE_4__["default"], {
          variant: "waiting",
          showImage: true,
          showLeftBorder: true,
          showLeftArrow: true,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.main",
            fontSize: "h6.fontSize",
            fontFamily: "fontFamily.medium",
            children: item.programName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 35,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            component: "body1",
            color: "primary.light",
            fontSize: "lg.fontSize",
            fontFamily: "fontFamily.regular",
            children: item.status
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 21
        }, undefined)
      }, item.programName, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 17
      }, undefined)), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 3,
        borderColor: "primary.main",
        border: "1px dashed",
        borderRadius: "21px",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ObjectCard__WEBPACK_IMPORTED_MODULE_5__["default"], {
          cardType: "actionCard",
          iconName: "plus",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.main",
            fontSize: "h6.fontSize",
            fontFamily: "fontFamily.medium",
            children: "Start a New Pre-Application"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 21
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 17
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 51,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 21,
      columnNumber: 9
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      children: linkArray.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mb: 2,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
          href: "#",
          underline: "none",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            display: "flex",
            alignItems: "center",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
              strokeWidth: "2",
              color: "Indigo",
              size: 15
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              fontSize: "lg.fontSize",
              color: "primary.main",
              fontFamily: "fontFamily.medium",
              ml: 1.5,
              children: item.text
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 76,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 21
        }, undefined)
      }, item.text, false, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 17
      }, undefined))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 66,
      columnNumber: 9
    }, undefined)]
  }, void 0, true);
};

/* harmony default export */ __webpack_exports__["default"] = (DashboardYourApplication);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/DashboardYourApplication/index.js":
/*!****************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/DashboardYourApplication/index.js ***!
  \****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DashboardYourApplication__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DashboardYourApplication */ "./src/shared/components/DashboardPageComponent/DashboardYourApplication/DashboardYourApplication.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _DashboardYourApplication__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/YourVoucher/YourVoucher.js":
/*!*********************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/YourVoucher/YourVoucher.js ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/withWidth */ "@material-ui/core/withWidth");
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _YourVoucherStyles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./YourVoucherStyles */ "./src/shared/components/DashboardPageComponent/YourVoucher/YourVoucherStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\DashboardPageComponent\\YourVoucher\\YourVoucher.js";







/**
 * Name : YourVoucher
 * Desc : YourVoucher
 */

const YourVoucher = ({
  width
}) => {
  const classes = Object(_YourVoucherStyles__WEBPACK_IMPORTED_MODULE_7__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    className: classes.flex,
    width: "100%",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      width: "100%",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        pb: width === 'xs' || width === 'sm' ? 2 : 6,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 5,
          pt: 2,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.light",
            fontSize: "h6.fontSize",
            fontFamily: "fontFamily.medium",
            pb: 1,
            children: "Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.light",
            fontSize: "h6.fontSize",
            children: "Firstname Lastname"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 28,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 5,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.light",
            fontSize: "h6.fontSize",
            fontFamily: "fontFamily.medium",
            pb: 1,
            children: "Voucher Number"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 33,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.light",
            fontSize: "h6.fontSize",
            children: "T123456"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 40,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 5,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.light",
            fontSize: "h6.fontSize",
            fontFamily: "fontFamily.medium",
            pb: 1,
            children: "Maximum Unit Size"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.light",
            fontSize: "h6.fontSize",
            children: "up to [X] bedroom(s)"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.light",
            fontSize: "h6.fontSize",
            fontFamily: "fontFamily.medium",
            pb: 1,
            children: "Voucher Expiration Date"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 57,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "primary.light",
            fontSize: "h6.fontSize",
            children: "[Date of Expiration]"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            pt: 1,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              style: {
                color: 'Indigo',
                fontSize: '15px'
              },
              size: "medium",
              className: "linkBtn",
              endIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                color: "Indigo",
                size: 14
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 75,
                columnNumber: 42
              }, undefined),
              children: "Request an Extension"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 68,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 67,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        className: classes.xsBtn,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          size: "large",
          color: "secondary",
          variant: "contained",
          fullWidth: width === 'xs' || width === 'sm' ? true : false,
          className: clsx__WEBPACK_IMPORTED_MODULE_3___default()(width === 'xs' || width === 'sm' ? 'semiBorder' : ''),
          startIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["Download"], {
            color: "Indigo",
            size: 21,
            strokeWidth: 3
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 88,
            columnNumber: 36
          }, undefined),
          children: "Download Voucher"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 82,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 81,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 9
  }, undefined);
};

YourVoucher.propTypes = {
  width: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default()()(YourVoucher));

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/YourVoucher/YourVoucherStyles.js":
/*!***************************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/YourVoucher/YourVoucherStyles.js ***!
  \***************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  flex: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0 96px',
    [theme.breakpoints.down('sm')]: {
      flexDirection: 'column',
      padding: '0 0 38px 0',
      alignItems: 'flex-start'
    }
  },
  xsBtn: {
    [theme.breakpoints.down('sm')]: {
      position: 'absolute',
      bottom: '0',
      left: '0',
      right: '0',
      width: '100%'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/DashboardPageComponent/YourVoucher/index.js":
/*!***************************************************************************!*\
  !*** ./src/shared/components/DashboardPageComponent/YourVoucher/index.js ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _YourVoucher__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./YourVoucher */ "./src/shared/components/DashboardPageComponent/YourVoucher/YourVoucher.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _YourVoucher__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/ExitDialogBox/ExitDialogBox.js":
/*!**************************************************************!*\
  !*** ./src/shared/components/ExitDialogBox/ExitDialogBox.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/icons/Close */ "@material-ui/icons/Close");
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\ExitDialogBox\\ExitDialogBox.js";




/**
 * Name: ExitDialogBox
 * Desc: Render ExitDialogBox
 */

const ExitDialogBox = ({
  onConfirm,
  onClose
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["DialogTitle"], {
      id: "simple-dialog-title",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
        "aria-label": "close",
        onClick: onClose,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2___default.a, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["DialogContent"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        textAlign: "center",
        pt: 2.5,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          fontSize: "h3.fontSize",
          fontFamily: "fontFamily.bold",
          color: "primary.light",
          pb: 1,
          children: "Are you sure you want to exit before finishing?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          fontSize: "lg.fontSize",
          color: "primary.extraLight",
          mb: 3,
          children: "Any progress you\u2019ve made won\u2019t be saved yet."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
        fullWidth: true,
        size: "large",
        color: "secondary",
        className: "semiBorder",
        variant: "contained",
        style: {
          borderRadius: 0
        },
        onClick: onConfirm,
        children: "Yes, Exit Now"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
        fullWidth: true,
        size: "large",
        color: "primary",
        className: "semiBorder",
        variant: "contained",
        onClick: onClose,
        children: "No, Keep Going"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

ExitDialogBox.propTypes = {
  onConfirm: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  onClose: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func
};
/* harmony default export */ __webpack_exports__["default"] = (ExitDialogBox);

/***/ }),

/***/ "./src/shared/components/ExitDialogBox/index.js":
/*!******************************************************!*\
  !*** ./src/shared/components/ExitDialogBox/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ExitDialogBox__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ExitDialogBox */ "./src/shared/components/ExitDialogBox/ExitDialogBox.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _ExitDialogBox__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Footer/Footer.js":
/*!************************************************!*\
  !*** ./src/shared/components/Footer/Footer.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/withWidth */ "@material-ui/core/withWidth");
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _FooterStyles__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./FooterStyles */ "./src/shared/components/Footer/FooterStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Footer\\Footer.js";







/**
 * Name : Footer
 * Desc : Render Footer
 */

const Footer = ({
  width
}) => {
  const classes = Object(_FooterStyles__WEBPACK_IMPORTED_MODULE_7__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    bgcolor: "primary.main",
    pt: 7,
    pb: 2,
    pr: 4,
    pl: 4,
    className: classes.footerWrapper,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
      container: true,
      spacing: 8,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 3,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          alignItems: "center",
          pb: 4,
          className: classes.logoWrapper,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            display: "flex",
            justifyContent: "center",
            mr: 2,
            className: classes.logoImage,
            flex: width === 'xs' || width === 'sm' ? '0 0 63px' : '0 0 163px',
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_3___default.a, {
              src: "/clientLogo.svg",
              width: 80,
              height: 80,
              className: classes.image
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 27,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "common.white",
              fontSize: "md.fontSize",
              textAlign: "left",
              className: classes.companyText,
              children: "HACEP"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 35,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "common.white",
              fontSize: "h5.fontSize",
              fontFamily: "fontFamily.bold",
              textAlign: "left",
              className: classes.logoText,
              children: "Housing Authority of the City of El Paso"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 42,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          mt: 3,
          mb: 3,
          alignItems: "flex-start",
          className: classes.companyName,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            display: "flex",
            justifyContent: "center",
            mr: 2,
            flex: width === 'xs' || width === 'sm' ? '0 0 46' : 'none',
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_3___default.a, {
              src: "/home.svg",
              width: width === 'xs' || width === 'sm' ? 46 : 40,
              height: width === 'xs' || width === 'sm' ? 43 : 37
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 63,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 58,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            color: "common.white",
            fontSize: "h6.fontSize",
            children: "We\u2019re a proud equal housing opportunity provider."
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          className: classes.mobileLinks,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            children: [{
              text: ' Privacy Policy'
            }, {
              text: 'Terms and Conditions'
            }, {
              text: 'Accessibility'
            }, {
              text: 'Equal Opportunity'
            }].map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              mb: 1.5,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                href: "#",
                underline: "none",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  display: "flex",
                  alignItems: "center",
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                    fontSize: "md.fontSize",
                    color: "common.white",
                    mr: 1,
                    children: item.text
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 84,
                    columnNumber: 45
                  }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                    strokeWidth: "2",
                    color: "white",
                    size: 14
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 87,
                    columnNumber: 45
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 83,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 82,
                columnNumber: 37
              }, undefined)
            }, item.text, false, {
              fileName: _jsxFileName,
              lineNumber: 81,
              columnNumber: 33
            }, undefined))
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 74,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 3,
        className: classes.footerGrid,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "common.white",
          fontSize: "h5.fontSize",
          fontFamily: "fontFamily.bold",
          pb: 1,
          mb: 3,
          className: classes.titleText,
          children: "Visit HACEP"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 96,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            mb: 2,
            display: "flex",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                alignItems: "center",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  fontSize: "lg.fontSize",
                  color: "common.white",
                  mr: 1,
                  children: "Main Website"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 109,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                  strokeWidth: "2",
                  color: "white",
                  size: 14
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 112,
                  columnNumber: 37
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 108,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 107,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 106,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            mb: 2,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "lg.fontSize",
                color: "common.white",
                mr: 1,
                children: "5300 E. Paisano Drive"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 119,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 118,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 117,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            mb: 2,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "lg.fontSize",
                color: "common.white",
                mr: 1,
                children: "El Paso, Texas 79905"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 126,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 125,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 124,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            mb: 2,
            mt: 4,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
              size: width === 'xs' || width === 'sm' || width === 'md' ? 'small' : 'large',
              color: "inherit",
              variant: "contained",
              children: "Get Directions"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 132,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 131,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 105,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 95,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 3,
        className: classes.footerGrid,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "common.white",
          fontSize: "h5.fontSize",
          fontFamily: "fontFamily.bold",
          pb: 1,
          mb: 3,
          className: classes.titleText,
          children: "Get Help & Support"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 146,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: [{
            text: 'Help Center'
          }, {
            text: 'Contact Us'
          }, {
            text: 'TDD (915) 847-3737'
          }, {
            text: '(915) 849-3742'
          }].map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            mb: 2,
            display: "flex",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                alignItems: "center",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  fontSize: "lg.fontSize",
                  color: "common.white",
                  mr: 1,
                  children: item.text
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 165,
                  columnNumber: 41
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                  strokeWidth: "2",
                  color: "white",
                  size: 14
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 168,
                  columnNumber: 41
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 164,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 163,
              columnNumber: 33
            }, undefined)
          }, item.text, false, {
            fileName: _jsxFileName,
            lineNumber: 162,
            columnNumber: 29
          }, undefined))
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 155,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 145,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 3,
        className: classes.footerGrid,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "common.white",
          fontSize: "h5.fontSize",
          fontFamily: "fontFamily.bold",
          pb: 1,
          mb: 3,
          className: classes.titleText,
          children: "Legal Information"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 176,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: [{
            text: 'Equal Housing Opportunity'
          }, {
            text: 'Accessibility'
          }, {
            text: 'Non-Discrimination'
          }, {
            text: 'Privacy & Terms of Use'
          }].map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            mb: 2,
            display: "flex",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                alignItems: "center",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  fontSize: "lg.fontSize",
                  color: "common.white",
                  mr: 1,
                  children: item.text
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 195,
                  columnNumber: 41
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
                  strokeWidth: "2",
                  color: "white",
                  size: 14
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 198,
                  columnNumber: 41
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 194,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 193,
              columnNumber: 33
            }, undefined)
          }, item.text, false, {
            fileName: _jsxFileName,
            lineNumber: 192,
            columnNumber: 29
          }, undefined))
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 185,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 175,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 17,
    columnNumber: 9
  }, undefined);
};

Footer.propTypes = {
  width: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default()()(Footer));

/***/ }),

/***/ "./src/shared/components/Footer/FooterStyles.js":
/*!******************************************************!*\
  !*** ./src/shared/components/Footer/FooterStyles.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  footerWrapper: {
    [theme.breakpoints.up('lg')]: {
      padding: '72px 72px 56px'
    }
  },
  titleText: {
    borderBottom: `2px solid ${theme.palette.primary.extraLight}`
  },
  footerGrid: {
    display: 'none',
    [theme.breakpoints.up('md')]: {
      display: 'block'
    },
    '& .MuiLink-root': {
      '&:hover': {
        color: theme.palette.success.light
      }
    }
  },
  logoWrapper: {
    [theme.breakpoints.down('md')]: {
      borderBottom: `2px solid ${theme.palette.primary.extraLight}`
    },
    [theme.breakpoints.up('md')]: {
      flexDirection: 'column',
      padding: 0,
      border: 0
    }
  },
  logoText: {
    [theme.breakpoints.up('md')]: {
      fontSize: theme.typography.h4.fontSize,
      textAlign: 'center',
      maxWidth: '290px'
    }
  },
  logoImage: {
    [theme.breakpoints.up('md')]: {
      marginBottom: '24px',
      '& > div': {
        marginRight: 0,
        '& > div ': {
          '& > img': {
            height: '130px',
            width: '130px'
          }
        }
      }
    },
    [theme.breakpoints.down('sm')]: {
      '& > div': {
        '& > div ': {
          '& > img': {
            height: '66px',
            width: '63px'
          }
        }
      }
    }
  },
  companyText: {
    fontStyle: 'italic',
    [theme.breakpoints.up('md')]: {
      display: 'none'
    }
  },
  mobileLinks: {
    [theme.breakpoints.up('md')]: {
      display: 'none'
    }
  },
  companyName: {
    [theme.breakpoints.up('md')]: {
      display: 'none'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Footer/SubFooter/SubFooter.js":
/*!*************************************************************!*\
  !*** ./src/shared/components/Footer/SubFooter/SubFooter.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _SubFooterStyles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./SubFooterStyles */ "./src/shared/components/Footer/SubFooter/SubFooterStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Footer\\SubFooter\\SubFooter.js";




/**
 * Name : SubFooter
 * Desc : Render SubFooter
 */

const SubFooter = () => {
  const classes = Object(_SubFooterStyles__WEBPACK_IMPORTED_MODULE_4__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    bgcolor: "button.secondaryColor",
    p: 3,
    className: classes.subFooterWrapper,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      flexWrap: "wrap",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "none",
        alignItems: "center",
        className: classes.companyName,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          justifyContent: "center",
          mr: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_2___default.a, {
            src: "/home.svg",
            width: 40,
            height: 37
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 19,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 18,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "common.white",
          fontSize: "h6.fontSize",
          children: "We\u2019re a proud equal housing opportunity provider."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "flex-start",
        flexDirection: "column",
        lineHeight: "28px",
        className: classes.poweredByText,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "common.white",
          fontSize: "md.fontSize",
          children: "\xA92021 Housing Authority of the City of El Paso"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "none",
          color: "common.white",
          fontSize: "md.fontSize",
          pl: 0.8,
          pr: 0.8,
          className: classes.breaker,
          children: "|"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "common.white",
          fontSize: "md.fontSize",
          children: "Powered by AppName"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 25,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (SubFooter);

/***/ }),

/***/ "./src/shared/components/Footer/SubFooter/SubFooterStyles.js":
/*!*******************************************************************!*\
  !*** ./src/shared/components/Footer/SubFooter/SubFooterStyles.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  companyName: {
    [theme.breakpoints.up('md')]: {
      display: 'flex',
      marginBottom: '8px'
    }
  },
  subFooterWrapper: {
    [theme.breakpoints.up('md')]: {
      padding: '20px 56px 12px 56px'
    }
  },
  poweredByText: {
    [theme.breakpoints.up('md')]: {
      flexDirection: 'row',
      alignItems: 'center',
      lineHeight: 'normal',
      marginBottom: '8px'
    }
  },
  breaker: {
    [theme.breakpoints.up('md')]: {
      display: 'flex'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Footer/SubFooter/index.js":
/*!*********************************************************!*\
  !*** ./src/shared/components/Footer/SubFooter/index.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _SubFooter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./SubFooter */ "./src/shared/components/Footer/SubFooter/SubFooter.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _SubFooter__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Footer/index.js":
/*!***********************************************!*\
  !*** ./src/shared/components/Footer/index.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Footer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Footer */ "./src/shared/components/Footer/Footer.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Footer__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Header/MainHeader/MainHeader.js":
/*!***************************************************************!*\
  !*** ./src/shared/components/Header/MainHeader/MainHeader.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Badge */ "@material-ui/core/Badge");
/* harmony import */ var _material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/useMediaQuery */ "@material-ui/core/useMediaQuery");
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var shared_components_LogoHeading__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! shared/components/LogoHeading */ "./src/shared/components/LogoHeading/index.js");
/* harmony import */ var _shared_components_Header_MobileMenu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/shared/components/Header/MobileMenu */ "./src/shared/components/Header/MobileMenu/index.js");
/* harmony import */ var _shared_constants_routesConstants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~/shared/constants/routesConstants */ "./src/shared/constants/routesConstants.js");
/* harmony import */ var _MainHeaderStyles__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./MainHeaderStyles */ "./src/shared/components/Header/MainHeader/MainHeaderStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Header\\MainHeader\\MainHeader.js";













/**
 * Name: MainHeader
 * Desc: Render MainHeader
 * @param  {bool}  isLoggedIn
 */

const MainHeader = ({
  isLoggedIn,
  userName,
  headerSubtitle,
  showBackBtn,
  mobileTitle,
  title,
  labelName,
  showMobileMenu
}) => {
  const {
    0: menuType,
    1: setMenuType
  } = Object(react__WEBPACK_IMPORTED_MODULE_8__["useState"])(false);

  const showMenuBar = () => {
    setMenuType(true);
  };

  const classes = Object(_MainHeaderStyles__WEBPACK_IMPORTED_MODULE_13__["default"])();
  const breakPoint = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3___default()('(min-width:1152px)');
  const color = isLoggedIn ? 'common.white' : 'primary.light';
  const buttonColor = isLoggedIn ? 'secondary' : 'primary';
  const buttonTitle = isLoggedIn ? 'Help Center' : 'Log In';
  const linkNameArray = [{
    linkName: 'Programs'
  }, {
    linkName: 'Help Center'
  }, {
    linkName: 'Get Started'
  }];

  const continueToLogin = () => {
    const {
      USER_LOGIN
    } = _shared_constants_routesConstants__WEBPACK_IMPORTED_MODULE_12__["ROUTES"];
    next_router__WEBPACK_IMPORTED_MODULE_6___default.a.push(USER_LOGIN.ROUTE);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    padding: 3,
    bgcolor: "common.white",
    boxShadow: 2,
    className: clsx__WEBPACK_IMPORTED_MODULE_4___default()(isLoggedIn && classes.mainHeaderWrapper),
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      className: showBackBtn || showMobileMenu ? classes.displayNoneXs : '',
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          alignItems: "center",
          mr: breakPoint ? 2 : 0,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            display: "none",
            className: classes.logoImage,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_5___default.a, {
              src: "/logo.svg",
              width: 66,
              height: 63
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            display: breakPoint ? 'none' : 'flex',
            children: !showBackBtn ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
              className: classes.menuButton,
              onClick: showMenuBar,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["Menu"], {
                strokeWidth: "2",
                color: "Indigo",
                size: 30
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 76,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 75,
              columnNumber: 33
            }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
              className: classes.menuButton,
              onClick: showMenuBar,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["Menu"], {
                strokeWidth: "2",
                color: "Indigo",
                size: 24
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_LogoHeading__WEBPACK_IMPORTED_MODULE_10__["default"], {
          title: title,
          labelName: labelName,
          isLoggedIn: isLoggedIn,
          breakPoint: breakPoint
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 85,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        pl: breakPoint ? 3 : 0,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "none",
          alignItems: "center",
          mr: isLoggedIn ? 5 : 9.5,
          className: classes.linkWrapper,
          children: linkNameArray.map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            mr: index !== linkNameArray.length - 1 && 8,
            flexWrap: "wrap",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "h6.fontSize",
                fontFamily: "fontFamily.medium",
                color: color,
                className: classes.linkName,
                children: item.linkName
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 104,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 103,
              columnNumber: 33
            }, undefined)
          }, item.linkName, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 29
          }, undefined))
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 93,
          columnNumber: 21
        }, undefined), !isLoggedIn || breakPoint ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          onClick: () => continueToLogin(),
          size: breakPoint ? 'large' : 'small',
          color: buttonColor,
          variant: "contained",
          children: buttonTitle
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 117,
          columnNumber: 25
        }, undefined) : null, isLoggedIn ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          ml: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_2___default.a, {
            badgeContent: 4,
            color: "error",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["Bell"], {
              strokeWidth: "3",
              color: "white",
              size: 26,
              fill: "white"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 128,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 127,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 126,
          columnNumber: 25
        }, undefined) : null]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 13
    }, undefined), userName && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      flexDirection: "column",
      textAlign: "center",
      pt: breakPoint ? 5 : 1,
      pb: breakPoint ? 5 : 10,
      color: "common.white",
      className: showBackBtn ? classes.displayNoneXs : '',
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        fontWeight: "700",
        fontSize: breakPoint ? 'h1.fontSize' : 'h3.fontSize',
        fontFamily: "fontFamily.bold",
        pb: 2,
        children: userName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 143,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        fontSize: breakPoint ? 'h5.fontSize' : 'h6.fontSize',
        lineHeight: breakPoint ? '35px' : '26px',
        color: "common.white",
        maxWidth: "560px",
        margin: "0 auto",
        children: headerSubtitle
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 150,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 135,
      columnNumber: 17
    }, undefined), (showBackBtn || showMobileMenu) && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      alignItems: "center",
      className: showBackBtn || showMobileMenu ? classes.displayBlockXs : '',
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
        className: classes.menuButton,
        onClick: showMenuBar,
        children: showBackBtn ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["ChevronLeft"], {
          strokeWidth: "2",
          color: "Indigo",
          size: 24
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 168,
          columnNumber: 29
        }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["Menu"], {
          strokeWidth: "2",
          color: "Indigo",
          size: 24
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 170,
          columnNumber: 29
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 166,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        fontSize: "h4.fontSize",
        fontFamily: "fontFamily.extraBold",
        color: color,
        overflow: "hidden",
        whiteSpace: "nowrap",
        maxWidth: "350px",
        textOverflow: "ellipsis",
        paddingLeft: 2.4,
        className: classes.title,
        children: mobileTitle
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 173,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 162,
      columnNumber: 17
    }, undefined), menuType && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Header_MobileMenu__WEBPACK_IMPORTED_MODULE_11__["default"], {
      beforeLogin: false,
      setMenuType: setMenuType
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 187,
      columnNumber: 26
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 58,
    columnNumber: 9
  }, undefined);
};

MainHeader.defaultProps = {
  showBackBtn: false,
  mobileTitle: ' ',
  title: 'AppName',
  labelName: 'EL PASO'
};
MainHeader.propTypes = {
  isLoggedIn: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool,
  userName: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  headerSubtitle: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  showBackBtn: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool,
  mobileTitle: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  title: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  labelName: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  showMobileMenu: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (MainHeader);

/***/ }),

/***/ "./src/shared/components/Header/MainHeader/MainHeaderStyles.js":
/*!*********************************************************************!*\
  !*** ./src/shared/components/Header/MainHeader/MainHeaderStyles.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  mainHeaderWrapper: {
    backgroundImage: 'url(/headerBg.svg)',
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'center',
    backgroundSize: 'cover',
    borderBottomLeftRadius: theme.spacing(2.63),
    borderBottomRightRadius: theme.spacing(2.63)
  },
  logoImage: {
    [theme.breakpoints.up('lg')]: {
      display: 'block'
    }
  },
  linkWrapper: {
    [theme.breakpoints.up('lg')]: {
      display: 'flex'
    }
  },
  menuButton: {
    backgroundColor: theme.common.white,
    '&:hover': {
      backgroundColor: theme.common.white
    }
  },
  linkName: {
    '&:hover': {
      color: theme.palette.success.light
    }
  },
  labelName: {
    [theme.breakpoints.up('lg')]: {
      display: 'block'
    }
  },
  title: {
    [theme.breakpoints.up('lg')]: {
      fontSize: theme.typography.h2.fontSize
    }
  },
  displayBlockXs: {
    [theme.breakpoints.up('lg')]: {
      display: 'none'
    },
    display: 'flex'
  },
  displayNoneXs: {
    [theme.breakpoints.down('md')]: {
      display: 'none'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Header/MainHeader/index.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/Header/MainHeader/index.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _MainHeader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MainHeader */ "./src/shared/components/Header/MainHeader/MainHeader.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _MainHeader__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Header/MobileMenu/MobileMenu.js":
/*!***************************************************************!*\
  !*** ./src/shared/components/Header/MobileMenu/MobileMenu.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./MobileMenuConstant */ "./src/shared/components/Header/MobileMenu/MobileMenuConstant.js");
/* harmony import */ var _MobileMenuStyles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./MobileMenuStyles */ "./src/shared/components/Header/MobileMenu/MobileMenuStyles.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Header\\MobileMenu\\MobileMenu.js";








/**
 * Name: MobileMenu
 * Desc: Render MobileMenu
 */

const MobileMenu = ({
  beforeLogin,
  setMenuType
}) => {
  const {
    0: openMobileMenu,
    1: setOpenMobileMenu
  } = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(true);
  const classes = Object(_MobileMenuStyles__WEBPACK_IMPORTED_MODULE_8__["default"])();
  const links = beforeLogin ? _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__["beforeLoginLinkArray"] : _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__["linkArray"];
  const actionLinks = beforeLogin ? _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__["beforeLoginPagesLinkArray"] : _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__["afterLoginPagesLinkArray"];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: openMobileMenu && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(classes.loginWrapper, beforeLogin && classes.beforeLoginWrapper),
      p: 3,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        mb: 11,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
          className: classes.menuButton,
          onClick: () => {
            setOpenMobileMenu(false);
            setMenuType(false);
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["X"], {
            strokeWidth: "3",
            color: "Indigo",
            size: 24
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 25
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        children: actionLinks.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 3.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
            href: "#",
            underline: "none",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
                strokeWidth: "2",
                color: "Indigo",
                size: 24
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 51,
                columnNumber: 41
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "h3.fontSize",
                color: "primary.main",
                fontFamily: "fontFamily.bold",
                ml: 1.5,
                children: item.text
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 52,
                columnNumber: 41
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 50,
              columnNumber: 37
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 33
          }, undefined)
        }, item.text, false, {
          fileName: _jsxFileName,
          lineNumber: 48,
          columnNumber: 29
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 21
      }, undefined), beforeLogin && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mt: 1.5,
        mb: 6,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          size: "large",
          color: "primary",
          variant: "contained",
          children: "Log In"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 29
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 25
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        children: links.map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          mb: 0.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
            className: clsx__WEBPACK_IMPORTED_MODULE_2___default()('linkBtn', classes.customButton),
            size: "medium",
            endIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
              color: "Indigo",
              size: 17
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 77,
              columnNumber: 46
            }, undefined),
            children: item.linkName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 74,
            columnNumber: 33
          }, undefined)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 29
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        position: "fixed",
        right: "-10px",
        zIndex: "-1",
        className: beforeLogin ? classes.topImagePosition : classes.bottomImagePosition,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_3___default.a, {
          src: "/clientLogo.svg",
          width: 160,
          height: 160,
          className: classes.image
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 90,
          columnNumber: 25
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 17
    }, undefined)
  }, void 0, false);
};

MobileMenu.propTypes = {
  beforeLogin: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
  setMenuType: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.func
};
/* harmony default export */ __webpack_exports__["default"] = (MobileMenu);

/***/ }),

/***/ "./src/shared/components/Header/MobileMenu/MobileMenuConstant.js":
/*!***********************************************************************!*\
  !*** ./src/shared/components/Header/MobileMenu/MobileMenuConstant.js ***!
  \***********************************************************************/
/*! exports provided: beforeLoginLinkArray, linkArray, afterLoginPagesLinkArray, beforeLoginPagesLinkArray */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "beforeLoginLinkArray", function() { return beforeLoginLinkArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "linkArray", function() { return linkArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "afterLoginPagesLinkArray", function() { return afterLoginPagesLinkArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "beforeLoginPagesLinkArray", function() { return beforeLoginPagesLinkArray; });
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_0__);

const beforeLoginLinkArray = [{
  linkName: 'About HACEP'
}, {
  linkName: 'Landlord Portal'
}, {
  linkName: 'Log Out'
}];
const linkArray = [{
  linkName: 'Español'
}, {
  linkName: 'Log Out'
}];
const afterLoginPagesLinkArray = [{
  text: 'Your Dashboard',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["Home"]
}, {
  text: 'Your Applications',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["FileText"]
}, {
  text: 'Your Account',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["User"]
}, {
  text: 'Help Center',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["HelpCircle"]
}];
const beforeLoginPagesLinkArray = [{
  text: 'Home',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["Home"]
}, {
  text: 'Get Started',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["Send"]
}, {
  text: 'Our Programs',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["FileText"]
}, {
  text: 'Help Center',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["HelpCircle"]
}];

/***/ }),

/***/ "./src/shared/components/Header/MobileMenu/MobileMenuStyles.js":
/*!*********************************************************************!*\
  !*** ./src/shared/components/Header/MobileMenu/MobileMenuStyles.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  loginWrapper: {
    position: 'fixed',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    width: '100%',
    height: '100vh',
    zIndex: '99999',
    backgroundColor: theme.palette.menus.menuBackground
  },
  beforeLoginWrapper: {
    backgroundColor: theme.palette.common.white
  },
  menuButton: {
    backgroundColor: theme.common.white
  },
  topImagePosition: {
    top: '40px'
  },
  bottomImagePosition: {
    bottom: '30px'
  },
  customButton: {
    fontSize: theme.typography.h6.fontSize,
    color: theme.palette.primary.main
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Header/MobileMenu/index.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/Header/MobileMenu/index.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _MobileMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MobileMenu */ "./src/shared/components/Header/MobileMenu/MobileMenu.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _MobileMenu__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Header/TopHeader/TopHeader.js":
/*!*************************************************************!*\
  !*** ./src/shared/components/Header/TopHeader/TopHeader.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/useMediaQuery */ "@material-ui/core/useMediaQuery");
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _TopHeaderStyles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./TopHeaderStyles */ "./src/shared/components/Header/TopHeader/TopHeaderStyles.js");
/* harmony import */ var _shared_components_ExitDialogBox__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/shared/components/ExitDialogBox */ "./src/shared/components/ExitDialogBox/index.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Header\\TopHeader\\TopHeader.js";







/**
 * Name: TopHeader
 * Desc: Render TopHeader
 * @param  {bool}  isWizard
 */

const TopHeader = ({
  isWizard,
  onClickBack,
  onExitClick,
  title = ''
}) => {
  const classes = Object(_TopHeaderStyles__WEBPACK_IMPORTED_MODULE_6__["default"])();
  const breakPoint = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_2___default()('(min-width:1152px)');
  const linkNameArray = [{
    linkName: 'Español'
  }, {
    linkName: 'About'
  }, {
    linkName: 'Landlord Portal'
  }];
  const {
    0: openDialog,
    1: setOpenDialog
  } = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false);

  const handleClose = () => {
    setOpenDialog(false);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    pt: 1,
    pr: breakPoint ? 6 : 1,
    pb: 1,
    pl: breakPoint ? 6 : 3,
    bgcolor: "menus.menuBackground",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        maxWidth: 750,
        children: [isWizard && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mr: 0.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
            onClick: onClickBack,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["ChevronLeft"], {
              strokeWidth: "2",
              color: "Indigo",
              size: 22
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 48,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 25
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.light",
          fontSize: 15,
          lineHeight: "21px",
          children: title ? title : 'Housing Assistance Eligiblity and PreApplication'
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        color: "primary.light",
        fontSize: "lg.fontSize",
        position: "relative",
        top: "-10px",
        display: !breakPoint ? 'flex' : 'none',
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["X"], {
            strokeWidth: "3",
            color: "Black",
            size: 15
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 66,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        alignItems: "center",
        display: breakPoint ? 'flex' : 'none',
        children: isWizard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            className: classes.link,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "/",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "body5.fontSize",
                color: "button.secondaryColor",
                children: "CANCEL APPLICATION"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 75,
                columnNumber: 41
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 37
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 33
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            className: classes.link,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              onClick: () => {
                setOpenDialog(true);
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "body5.fontSize",
                color: "button.secondaryColor",
                children: "SAVE AND EXIT"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 84,
                columnNumber: 41
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 81,
              columnNumber: 37
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 33
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Dialog"], {
            onClose: handleClose,
            "aria-labelledby": "simple-dialog-title",
            open: openDialog,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ExitDialogBox__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClose: handleClose,
              onConfirm: onExitClick
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 93,
              columnNumber: 37
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 33
          }, undefined)]
        }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
          children: linkNameArray.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "body5.fontSize",
                color: "button.secondaryColor",
                children: item.linkName
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 101,
                columnNumber: 45
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 100,
              columnNumber: 41
            }, undefined)
          }, item.linkName, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 37
          }, undefined))
        }, void 0, false)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 37,
    columnNumber: 9
  }, undefined);
};

TopHeader.defaultProps = {
  isWizard: false,
  title: null,
  onClickBack: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func
};
TopHeader.propTypes = {
  isWizard: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  onClickBack: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  onExitClick: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  title: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (TopHeader);

/***/ }),

/***/ "./src/shared/components/Header/TopHeader/TopHeaderStyles.js":
/*!*******************************************************************!*\
  !*** ./src/shared/components/Header/TopHeader/TopHeaderStyles.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  link: {
    '&:not(:last-child)': {
      marginRight: theme.spacing(6),
      position: 'relative',
      '&::after': {
        content: "'|'",
        position: 'absolute',
        right: '-26px',
        top: 0,
        bottom: 0,
        color: 'inherit'
      }
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Header/TopHeader/index.js":
/*!*********************************************************!*\
  !*** ./src/shared/components/Header/TopHeader/index.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TopHeader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TopHeader */ "./src/shared/components/Header/TopHeader/TopHeader.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _TopHeader__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/HelpCenter/HelpCenter.js":
/*!********************************************************!*\
  !*** ./src/shared/components/HelpCenter/HelpCenter.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/withWidth */ "@material-ui/core/withWidth");
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\HelpCenter\\HelpCenter.js";




/**
 * Name: HelpCenter
 * Desc: Render HelpCenter
 */

const HelpCenter = ({
  width
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    minHeight: width === 'xs' || width === 'sm' ? 277 : 355,
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "column",
    textAlign: "center",
    bgcolor: "menus.menuBackground",
    pl: 3,
    pr: 3,
    py: 5,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      color: "primary.light",
      fontSize: width === 'xs' || width === 'sm' ? 'h5.fontSize' : 'h3.fontSize',
      fontFamily: "fontFamily.semiBold",
      children: "Getting housing assistance can be a tough process."
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      color: "primary.light",
      fontSize: "h6.fontSize",
      pt: 2,
      pb: 3.75,
      children: "We\u2019re here to help you at every step"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 31,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
      size: "large",
      color: "primary",
      variant: "contained",
      children: "Help Center"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 9
  }, undefined);
};

HelpCenter.propTypes = {
  width: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default()()(HelpCenter));

/***/ }),

/***/ "./src/shared/components/HelpCenter/index.js":
/*!***************************************************!*\
  !*** ./src/shared/components/HelpCenter/index.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _HelpCenter__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HelpCenter */ "./src/shared/components/HelpCenter/HelpCenter.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _HelpCenter__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Indicators/Indicators.js":
/*!********************************************************!*\
  !*** ./src/shared/components/Indicators/Indicators.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! feather-icons-react */ "feather-icons-react");
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _IndicatorsStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./IndicatorsStyles */ "./src/shared/components/Indicators/IndicatorsStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Indicators\\Indicators.js";





/**
 * Name: Indicators
 * Desc: Render Indicators
 * @param { string } classNames
 */

const Indicators = ({
  status,
  size,
  iconName,
  iconSize,
  borderWidth,
  iconColor
}) => {
  const classes = Object(_IndicatorsStyles__WEBPACK_IMPORTED_MODULE_5__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    width: size,
    height: size,
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    margin: "0 auto",
    border: borderWidth,
    className: classes[status],
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default.a, {
      icon: iconName,
      size: iconSize,
      color: iconColor
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 9
  }, undefined);
};

Indicators.defaultProps = {
  size: 80,
  status: 'default',
  iconName: 'thumbs-up',
  iconSize: 36,
  borderWidth: 8
};
Indicators.propTypes = {
  status: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['success', 'failed', 'pending', 'default', 'complete']),
  size: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number,
  iconSize: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number,
  borderWidth: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number,
  iconName: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string,
  iconColor: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (Indicators);

/***/ }),

/***/ "./src/shared/components/Indicators/IndicatorsStyles.js":
/*!**************************************************************!*\
  !*** ./src/shared/components/Indicators/IndicatorsStyles.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  failed: {
    backgroundColor: theme.palette.error.light,
    borderColor: `${theme.palette.error.main} !important`
  },
  pending: {
    backgroundColor: theme.palette.pending.light,
    borderColor: `${theme.palette.pending.main} !important`
  },
  success: {
    backgroundColor: theme.palette.success.light,
    borderColor: `${theme.palette.success.main} !important`
  },
  default: {
    backgroundColor: 'transparent',
    borderColor: `${theme.palette.default.main} !important`
  },
  complete: {
    backgroundColor: theme.common.white,
    border: '8px solid rgba(255, 255, 255, .5)',
    '-webkit-background-clip': 'padding-box',
    backgroundClip: 'padding-box'
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Indicators/index.js":
/*!***************************************************!*\
  !*** ./src/shared/components/Indicators/index.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Indicators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Indicators */ "./src/shared/components/Indicators/Indicators.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Indicators__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/LogoHeading/LogoHeading.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/LogoHeading/LogoHeading.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _LogoHeadingStyles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./LogoHeadingStyles */ "./src/shared/components/LogoHeading/LogoHeadingStyles.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\LogoHeading\\LogoHeading.js";




/**
 * Name : LogoHeading
 * Desc : Render LogoHeading
 * @param  {string}  labelName
 * @param  {string}  title
 * @param  {boolean}  isLoggedIn
 * @param  {string}  breakPoint
 */

const LogoHeading = ({
  title,
  labelName,
  isLoggedIn,
  breakPoint
}) => {
  const classes = Object(_LogoHeadingStyles__WEBPACK_IMPORTED_MODULE_4__["default"])();
  const color = isLoggedIn ? 'common.white' : 'primary.light';
  const subTextColor = isLoggedIn ? 'common.white' : 'primary.light';
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    display: "flex",
    flexDirection: "column",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        fontSize: "h4.fontSize",
        fontFamily: "fontFamily.extraBold",
        color: color,
        overflow: "hidden",
        whiteSpace: "nowrap",
        maxWidth: "350px",
        textOverflow: "ellipsis",
        className: classes.title,
        children: !isLoggedIn || breakPoint ? title : ''
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "none",
        fontSize: "body5.fontSize",
        letterSpacing: "4px",
        color: subTextColor,
        className: classes.labelName,
        children: labelName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 17
      }, undefined)]
    }, void 0, true)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 9
  }, undefined);
};

LogoHeading.defaultProps = {};
LogoHeading.propTypes = {
  title: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  labelName: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  isLoggedIn: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
  breakPoint: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (LogoHeading);

/***/ }),

/***/ "./src/shared/components/LogoHeading/LogoHeadingStyles.js":
/*!****************************************************************!*\
  !*** ./src/shared/components/LogoHeading/LogoHeadingStyles.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  labelName: {
    [theme.breakpoints.up('lg')]: {
      display: 'block'
    }
  },
  title: {
    [theme.breakpoints.up('lg')]: {
      fontSize: theme.typography.h2.fontSize
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/LogoHeading/index.js":
/*!****************************************************!*\
  !*** ./src/shared/components/LogoHeading/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _LogoHeading__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./LogoHeading */ "./src/shared/components/LogoHeading/LogoHeading.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _LogoHeading__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/ObjectCard/ObjectCard.js":
/*!********************************************************!*\
  !*** ./src/shared/components/ObjectCard/ObjectCard.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! feather-icons-react */ "feather-icons-react");
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _shared_utils_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/shared/utils/utils */ "./src/shared/utils/utils.js");
/* harmony import */ var _Indicators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Indicators */ "./src/shared/components/Indicators/index.js");
/* harmony import */ var _ObjectCardStyle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ObjectCardStyle */ "./src/shared/components/ObjectCard/ObjectCardStyle.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\ObjectCard\\ObjectCard.js";







/**
 * Name : ObjectCard
 * Desc : Render ObjectCard
 **/

const ObjectCard = props => {
  const {
    children,
    variant,
    iconName,
    cardType,
    onClick,
    onDelete,
    isMember,
    onEditClick,
    showOptionMenu
  } = props;
  const classes = Object(_ObjectCardStyle__WEBPACK_IMPORTED_MODULE_7__["default"])();
  const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_4___default.a.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleEdit = () => {
    onEditClick();
    handleClose();
  };

  const handleDelete = () => {
    onDelete();
    handleClose();
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: cardType === 'objectCard' ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
      onClick: onClick,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        px: 2,
        py: 2.5,
        minHeight: 96,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Indicators__WEBPACK_IMPORTED_MODULE_6__["default"], {
            size: 37,
            status: variant,
            iconName: iconName,
            borderWidth: 3.7,
            iconSize: 18
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 25
        }, undefined), children && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          flexGrow: 2,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          pl: 1.5,
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 29
        }, undefined), showOptionMenu && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          p: 0.25,
          mr: -1.5,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          children: isMember ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
              color: "primary",
              onClick: handleClick,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default.a, {
                icon: "more-vertical",
                size: "24"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 72,
                columnNumber: 45
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 41
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Menu"], {
              id: "long-menu",
              anchorEl: anchorEl,
              keepMounted: true,
              open: open,
              onClose: handleClose,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                onClick: handleEdit,
                children: "Edit"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 45
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                onClick: handleDelete,
                children: "Delete"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 81,
                columnNumber: 45
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 41
            }, undefined)]
          }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
            color: "primary",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default.a, {
              icon: "more-vertical",
              size: "24"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 86,
              columnNumber: 41
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 85,
            columnNumber: 37
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 29
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 21
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 17
    }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      className: classes.rootUpload,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
        accept: "image/*",
        className: classes.input,
        id: "contained-button-file",
        multiple: true,
        type: "file"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
        htmlFor: "contained-button-file",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          variant: "contained",
          component: "span",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              px: 2,
              py: 1.5,
              minHeight: 96,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Indicators__WEBPACK_IMPORTED_MODULE_6__["default"], {
                  size: 37,
                  status: variant,
                  iconName: iconName,
                  borderWidth: 3.7,
                  iconSize: 18
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 113,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 112,
                columnNumber: 37
              }, undefined), children && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                flexGrow: 2,
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                pl: 2,
                children: children
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 122,
                columnNumber: 41
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 106,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 105,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 104,
          columnNumber: 25
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 103,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 17
    }, undefined)
  }, void 0, false);
};

ObjectCard.defaultProps = {
  variant: 'success',
  children: '',
  iconName: 'user',
  cardType: 'objectCard',
  onClick: _shared_utils_utils__WEBPACK_IMPORTED_MODULE_5__["noop"],
  isMember: false,
  onEditClick: _shared_utils_utils__WEBPACK_IMPORTED_MODULE_5__["noop"],
  onDelete: _shared_utils_utils__WEBPACK_IMPORTED_MODULE_5__["noop"],
  showOptionMenu: true
};
ObjectCard.propTypes = {
  variant: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['success', 'failed', 'pending']),
  cardType: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['objectCard', 'actionCard']),
  children: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.node,
  iconName: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string,
  onClick: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  isMember: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  onEditClick: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  onDelete: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  showOptionMenu: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (ObjectCard);

/***/ }),

/***/ "./src/shared/components/ObjectCard/ObjectCardStyle.js":
/*!*************************************************************!*\
  !*** ./src/shared/components/ObjectCard/ObjectCardStyle.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(() => ({
  rootUpload: {
    '& > *': {
      margin: 0
    },
    '& .MuiButton-root': {
      width: '100%',
      padding: '0'
    },
    '& .MuiCard-root': {
      width: '100%'
    }
  },
  input: {
    display: 'none'
  },
  '.MuiButtonBase-root': {
    padding: 0
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/ObjectCard/index.js":
/*!***************************************************!*\
  !*** ./src/shared/components/ObjectCard/index.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ObjectCard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ObjectCard */ "./src/shared/components/ObjectCard/ObjectCard.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _ObjectCard__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/PageHeading/PageHeading.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/PageHeading/PageHeading.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\PageHeading\\PageHeading.js";



/** 
 * Name : PageHeading
 * Desc : Render PageHeading
 * @param {string} title 
 **/

const PageHeading = ({
  title
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      color: "primary.main",
      fontFamily: "fontFamily.bold",
      letterSpacing: 8,
      pb: 3,
      className: "textTransform",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Typography"], {
        variant: "h2",
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 12
    }, undefined)
  }, void 0, false);
};

PageHeading.defaultProps = {};
PageHeading.propTypes = {
  title: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (PageHeading);

/***/ }),

/***/ "./src/shared/components/PageHeading/index.js":
/*!****************************************************!*\
  !*** ./src/shared/components/PageHeading/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PageHeading__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PageHeading */ "./src/shared/components/PageHeading/PageHeading.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _PageHeading__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/ProgramCard/ProgramCard.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/ProgramCard/ProgramCard.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/withWidth */ "@material-ui/core/withWidth");
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ProgramCardsStyle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ProgramCardsStyle */ "./src/shared/components/ProgramCard/ProgramCardsStyle.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\ProgramCard\\ProgramCard.js";








/**
 * Name : ProgramCard
 * Desc : Render ProgramCard
 **/

const ProgramCard = props => {
  const {
    children,
    showLeftArrow,
    variant,
    showDeleteBox,
    showImage,
    showLeftBorder,
    imgUrl,
    width
  } = props;
  const classes = Object(_ProgramCardsStyle__WEBPACK_IMPORTED_MODULE_8__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    position: "relative",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        children: [showLeftBorder && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          minWidth: 16,
          minHeight: 96,
          borderRadius: "50px 0 0 50px",
          position: width === 'xs' ? 'static' : 'absolute',
          left: "0",
          zIndex: 1,
          className: classes[variant]
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 25
        }, undefined), showImage && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          className: clsx__WEBPACK_IMPORTED_MODULE_3___default()(classes.overlay, classes[variant]),
          mr: 2.5,
          display: width === 'xs' ? 'none' : 'inherit',
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_4___default.a, {
            src: imgUrl,
            width: 133,
            height: 96
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 25
        }, undefined), children && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          flexGrow: 2,
          px: 1.5,
          py: 2,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 25
        }, undefined), showLeftArrow && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          p: 0.25,
          pr: 1.25,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_7__["ChevronRight"], {
              "stroke-width": "3",
              color: "Indigo",
              size: 24
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 72,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 71,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 25
        }, undefined), showDeleteBox && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          component: "button",
          p: 1.5,
          bgcolor: "error.dark",
          color: "common.white",
          minHeight: 96,
          minWidth: 96,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "column",
          border: 0,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_7__["Trash2"], {
            "stroke-width": "1.5",
            color: "white",
            size: 20
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 29
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            component: "body1",
            fontSize: "lg.fontSize",
            fontFamily: "fontFamily.regular",
            pt: 0.75,
            children: "DELETE"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 90,
            columnNumber: 29
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 25
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 28,
    columnNumber: 9
  }, undefined);
};

ProgramCard.defaultProps = {
  children: '',
  showLeftArrow: false,
  showDeleteBox: false,
  showImage: false,
  showLeftBorder: true,
  imgUrl: '/view.jpg'
};
ProgramCard.propTypes = {
  variant: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.oneOf(['success', 'failed', 'waiting']),
  children: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.node,
  showLeftArrow: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  showDeleteBox: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  showImage: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  showLeftBorder: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  imgUrl: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string,
  width: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default()()(ProgramCard));

/***/ }),

/***/ "./src/shared/components/ProgramCard/ProgramCardsStyle.js":
/*!****************************************************************!*\
  !*** ./src/shared/components/ProgramCard/ProgramCardsStyle.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  failed: {
    backgroundColor: theme.palette.error.main,
    '&:before': {
      background: 'rgba(245, 66, 15, 0.5) !important'
    }
  },
  waiting: {
    backgroundColor: theme.palette.pending.main,
    '&:before': {
      background: 'rgba(249, 191, 2, 0.5) !important'
    }
  },
  // pending: {
  //     backgroundColor: theme.palette.pending.main
  // },
  success: {
    backgroundColor: theme.palette.success.light,
    '&:before': {
      background: 'rgba(79, 240, 188, 0.5) !important'
    }
  },
  info: {
    backgroundColor: theme.palette.info.main
  },
  overlay: {
    position: 'relative',
    '&:before': {
      content: '""',
      width: '100%',
      height: '100%',
      position: 'absolute',
      top: '0',
      bottom: '0',
      left: '0',
      right: '0',
      zIndex: '1'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/ProgramCard/index.js":
/*!****************************************************!*\
  !*** ./src/shared/components/ProgramCard/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ProgramCard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ProgramCard */ "./src/shared/components/ProgramCard/ProgramCard.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _ProgramCard__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/WizardHeader/WizardHeader.js":
/*!************************************************************!*\
  !*** ./src/shared/components/WizardHeader/WizardHeader.js ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/withWidth */ "@material-ui/core/withWidth");
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _WizardHeaderStyles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./WizardHeaderStyles */ "./src/shared/components/WizardHeader/WizardHeaderStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\WizardHeader\\WizardHeader.js";






/**
 * Name : WizardHeader
 * Desc : Render WizardHeader
 */

const WizardHeader = ({
  onClickBack,
  title,
  children = null
}) => {
  const classes = Object(_WizardHeaderStyles__WEBPACK_IMPORTED_MODULE_6__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    bgcolor: "primary.main",
    className: classes.WizardHeaderWrapper,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Container"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        className: classes.deviceHeader,
        position: "relative",
        zIndex: 1,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
          className: classes.menuButton,
          onClick: onClickBack,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["ChevronLeft"], {
            color: "Indigo",
            size: 26,
            className: classes.visibleDesktop
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["ArrowLeft"], {
            color: "Indigo",
            size: 20,
            strokeWidth: 3,
            className: classes.visibleXs
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          fontSize: "h3.fontSize",
          color: "common.white",
          fontFamily: "fontFamily.bold",
          ml: 3,
          children: title
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 17
      }, undefined), children ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        width: "100%",
        position: "relative",
        zIndex: 1,
        className: classes.xsMargin,
        children: children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 21
      }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        className: classes.WizardHeaBox,
        display: "flex",
        alignItems: "center",
        flexWrap: "wrap",
        position: "relative",
        zIndex: 1,
        children: [{
          text: 'Continue'
        }, {
          text: 'Continue'
        }, {
          text: 'Continue'
        }, {
          text: 'Continue'
        }, {
          text: 'Continue'
        }, {
          text: 'Continue'
        }].map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          className: classes.links,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            fontSize: "h5.fontSize",
            color: "common.white",
            fontFamily: "fontFamily.regular",
            children: item.text
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 33
          }, undefined)
        }, `${item.text}_${index}`, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 29
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 9
  }, undefined);
};

WizardHeader.propTypes = {
  onClickBack: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  children: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.any,
  title: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default()()(WizardHeader));

/***/ }),

/***/ "./src/shared/components/WizardHeader/WizardHeaderStyles.js":
/*!******************************************************************!*\
  !*** ./src/shared/components/WizardHeader/WizardHeaderStyles.js ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  WizardHeaderWrapper: {
    backgroundSize: 'cover',
    backgroundPosition: 'center',
    borderBottomLeftRadius: theme.spacing(3),
    borderBottomRightRadius: theme.spacing(3),
    padding: '24px 0',
    position: 'relative',
    backgroundImage: `url('/splashMobile.svg')`,
    [theme.breakpoints.up('sm')]: {
      '&:after': {
        position: 'absolute',
        top: '0',
        left: '0',
        right: '0',
        width: '100%',
        content: '""',
        backgroundImage: `url('/splash.svg')`,
        minHeight: '461px',
        borderBottomLeftRadius: theme.spacing(3),
        borderBottomRightRadius: theme.spacing(3),
        backgroundPosition: 'center',
        backgroundSize: 'cover'
      }
    },
    [theme.breakpoints.down('xs')]: {
      minHeight: '155px'
    }
  },
  WizardHeaBox: {
    [theme.breakpoints.down('xs')]: {
      display: 'none'
    }
  },
  links: {
    '&:hover': {
      '& > div': {
        color: theme.palette.success.light
      }
    },
    [theme.breakpoints.down('md')]: {
      margin: `0 8px`
    }
  },
  menuButton: {
    backgroundColor: theme.common.white,
    '&:hover': {
      backgroundColor: theme.common.white,
      opacity: '0.5'
    }
  },
  deviceHeader: {
    [theme.breakpoints.up('sm')]: {
      display: 'none'
    }
  },
  xsMargin: {
    [theme.breakpoints.down('xs')]: {
      padding: '0 8px 56px'
    }
  },
  visibleDesktop: {
    display: 'none',
    [theme.breakpoints.up('sm')]: {
      display: 'block'
    }
  },
  visibleXs: {
    display: 'none',
    [theme.breakpoints.down('xs')]: {
      display: 'block'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/WizardHeader/index.js":
/*!*****************************************************!*\
  !*** ./src/shared/components/WizardHeader/index.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _WizardHeader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./WizardHeader */ "./src/shared/components/WizardHeader/WizardHeader.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _WizardHeader__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/constants/routesConstants.js":
/*!*************************************************!*\
  !*** ./src/shared/constants/routesConstants.js ***!
  \*************************************************/
/*! exports provided: ROUTES */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ROUTES", function() { return ROUTES; });
const ROUTES = {
  HOME: {
    ROUTE: '/',
    //Should be unique
    TITLE: 'Home',
    NAME: 'Home',
    PARENT_ROUTE: ''
  },
  EXAMPLES: {
    ROUTE: '/examples',
    //For learning purpose
    TITLE: 'Examples',
    NAME: 'Examples',
    PARENT_ROUTE: ''
  },
  USER_LOGIN: {
    ROUTE: '/login',
    //Should be unique
    TITLE: 'Login',
    NAME: 'Login'
  },
  LOGIN: {
    ROUTE: '/admin',
    //Should be unique
    TITLE: 'Admin',
    NAME: 'Login',
    PARENT_ROUTE: ''
  },
  PROFILE: {
    //need to add query params
    ROUTE: '/profile',
    //Should be unique
    TITLE: 'Profile',
    NAME: 'Profile',
    PARENT_ROUTE: ''
  },
  VOUCHER: {
    //need to add query params
    ROUTE: '/voucher',
    //Should be unique
    TITLE: 'Voucher',
    NAME: 'Voucher',
    PARENT_ROUTE: ''
  },
  ACCOUNT: {
    //need to add query params
    ROUTE: '/account',
    //Should be unique
    TITLE: 'Account',
    NAME: 'Account',
    PARENT_ROUTE: ''
  },
  ACCOUNT_DETAIL: {
    //need to add query params
    ROUTE: '/accountdetail',
    //Should be unique
    TITLE: 'Account Detail',
    NAME: 'Account Detail',
    PARENT_ROUTE: ''
  },
  GET_STARTED: {
    //need to add query params
    ROUTE: '/getstarted',
    //Should be unique
    TITLE: 'Get Started',
    NAME: 'Get Started',
    PARENT_ROUTE: ''
  },
  HELP: {
    //need to add query params
    ROUTE: '/help',
    //Should be unique
    TITLE: 'Help',
    NAME: 'Help',
    PARENT_ROUTE: ''
  },
  HELP_TOPICS: {
    //need to add query params
    ROUTE: '/helptopics',
    //Should be unique
    TITLE: 'Help Topics',
    NAME: 'Help Topics',
    PARENT_ROUTE: ''
  },
  CHANGE_PASSWORD: {
    //need to add query params
    ROUTE: '/changepassword',
    //Should be unique
    TITLE: 'Change Password',
    NAME: 'Change Password',
    PARENT_ROUTE: ''
  },
  FORGOT_PASSWORD: {
    ROUTE: '/forgotpassword',
    //Should be unique
    TITLE: 'Forgot Password',
    NAME: 'Forgot Password',
    PARENT_ROUTE: ''
  },
  COMMON_COMPONENT_STYLE: {
    ROUTE: '/commoncomponentstyle',
    //Should be unique
    TITLE: 'Common Component Style',
    NAME: 'Common Component Style',
    PARENT_ROUTE: ''
  },
  COMMON_FULLFLOWPAGE_STYLE: {
    ROUTE: '/commonfullpageflowstyle',
    //Should be unique
    TITLE: 'Common fullpageflow Style',
    NAME: 'Common fullpageflow Style',
    PARENT_ROUTE: ''
  },
  VOUCHER_RECEIVED: {
    ROUTE: '/voucherreceivedfullpagestyle',
    //Should be unique
    TITLE: 'Voucher Received Style',
    NAME: 'Voucher Received Style',
    PARENT_ROUTE: ''
  },
  DASHBOARD_PAGE_STYLE: {
    ROUTE: '/dashboardpagestyle',
    //Should be unique
    TITLE: 'Dashboard Page Style',
    NAME: 'Dashboard Page Style',
    PARENT_ROUTE: ''
  },
  LANDLORD_PAGE_STYLE: {
    ROUTE: '/landlordpagestyle',
    //Should be unique
    TITLE: 'Landlord Page Style',
    NAME: 'Landlord Page Style',
    PARENT_ROUTE: ''
  },
  SUPERVISOR_LOGIN: {
    ROUTE: '/admin/login',
    //Should be unique
    TITLE: 'Admin LOGIN',
    NAME: 'Admin LOGIN'
  },
  CHECK_ELIGIBILITY: {
    ROUTE: '/check-your-eligibility',
    //Should be unique
    TITLE: 'Check Your Eligibility',
    NAME: 'Check Your Eligibility',
    PARENT_ROUTE: ''
  },
  SUPERVISOR_DASHBOARD: {
    ROUTE: '/admin/dashboard',
    //Should be unique
    TITLE: 'Admin Dashboard',
    NAME: 'Admin Dashboard',
    PARENT_ROUTE: ''
  },
  CREATE_PROFILE: {
    ROUTE: '/create-profile',
    //Should be unique
    TITLE: 'Profile',
    NAME: 'Profile',
    PARENT_ROUTE: ''
  },
  ELIGIBILITY_CALCULATOR: {
    ROUTE: '/admin/calculator',
    //Should be unique
    TITLE: 'Eligibility Calculator',
    NAME: 'Eligibility Calculator',
    PARENT_ROUTE: ''
  },
  MANAGE_PROGRAMS: {
    ROUTE: '/admin/manage-programs',
    //Should be unique
    TITLE: 'Manage Programs',
    NAME: 'Manage Programs',
    PARENT_ROUTE: ''
  },
  MANAGE_SMTP: {
    ROUTE: '/admin/manage-smtp',
    //Should be unique
    TITLE: 'Manage Smtp',
    NAME: 'Manage Smtp',
    PARENT_ROUTE: ''
  },
  MANAGE_PREAPPLICATION: {
    ROUTE: '/admin/manage-preapplications',
    //Should be unique
    TITLE: 'Manage Preapplication',
    NAME: 'Manage Preapplication',
    PARENT_ROUTE: ''
  },
  HOUSE_HOLD_DETAIL: {
    ROUTE: '/house-hold-detail',
    //Should be unique
    TITLE: 'House Hold Detail',
    NAME: 'House Hold Detail',
    PARENT_ROUTE: ''
  },
  REVIEW_APPLICATION: {
    ROUTE: '/review-application',
    //Should be unique
    TITLE: 'Review Application',
    NAME: 'Review Application',
    PARENT_ROUTE: ''
  },
  HOUSEHOLD_INCOME: {
    ROUTE: '/household-income',
    //Should be unique
    TITLE: 'Household Income',
    NAME: 'Household Income',
    PARENT_ROUTE: ''
  },
  HOUSEHOLD_ASSETS: {
    ROUTE: '/household-assets',
    //Should be unique
    TITLE: 'Household Assets',
    NAME: 'Household Assets',
    PARENT_ROUTE: ''
  },
  HOUSEHOLD_SPECIAL_EXPENSES: {
    ROUTE: '/household-special-expenses',
    //Should be unique
    TITLE: 'Household Special Expenses',
    NAME: 'Household Special Expenses',
    PARENT_ROUTE: ''
  },
  RENT_AFFORDABILITY: {
    ROUTE: '/rent-affordability',
    //Should be unique
    TITLE: 'Rent Affordability',
    NAME: 'Rent Affordability',
    PARENT_ROUTE: ''
  },
  YOUR_DOCUMENTS: {
    ROUTE: '/your-documents',
    //Should be unique
    TITLE: 'Rour Documents',
    NAME: 'Rour Documents',
    PARENT_ROUTE: ''
  },
  REVIEW_AND_SIGN: {
    ROUTE: '/review-and-sign',
    //Should be unique
    TITLE: 'Review And Sign',
    NAME: 'Review And Sign',
    PARENT_ROUTE: ''
  }
};

/***/ }),

/***/ "./src/shared/utils/storeManager.js":
/*!******************************************!*\
  !*** ./src/shared/utils/storeManager.js ***!
  \******************************************/
/*! exports provided: setLocalStorage, getLocalStorage, removeLocalStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setLocalStorage", function() { return setLocalStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLocalStorage", function() { return getLocalStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeLocalStorage", function() { return removeLocalStorage; });
/**
 * set LocalStorage for given key and value
 * @param {*} key
 * @param {*} value
 */
const setLocalStorage = (key, value) => {
  let storageValue = value;

  if (typeof value === 'object') {
    storageValue = JSON.stringify(value);
  }

  window.localStorage.setItem(key, storageValue);
};
/**
 * Return the LocalStorage for given key
 * @param {*} key
 */

const getLocalStorage = key => {
  const value = window.localStorage.getItem(key);
  return value && JSON.parse(value);
};
/**
 * Return removed item
 */

const removeLocalStorage = key => {
  const value = getLocalStorage(key);
  window.localStorage.removeItem(key);
  return value;
};

/***/ }),

/***/ "./src/shared/utils/utils.js":
/*!***********************************!*\
  !*** ./src/shared/utils/utils.js ***!
  \***********************************/
/*! exports provided: getBaseUrl, noop, getLocalizeKey, getUserId, getAccessToken */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBaseUrl", function() { return getBaseUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "noop", function() { return noop; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLocalizeKey", function() { return getLocalizeKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUserId", function() { return getUserId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAccessToken", function() { return getAccessToken; });
/* harmony import */ var _storeManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./storeManager */ "./src/shared/utils/storeManager.js");
 //utility functions here

const getBaseUrl = () => {
  return "http://localhost:8000/";
}; // eslint-disable-next-line no-empty-function

const noop = () => {};
const getLocalizeKey = () => {
  return "6744e827e2252";
};
const getUserId = () => {
  const userDetail = Object(_storeManager__WEBPACK_IMPORTED_MODULE_0__["getLocalStorage"])('user_details') || {};
  return userDetail === null || userDetail === void 0 ? void 0 : userDetail.user_id;
};
const getAccessToken = () => {
  const userDetail = Object(_storeManager__WEBPACK_IMPORTED_MODULE_0__["getLocalStorage"])('user_details') || {};
  return userDetail === null || userDetail === void 0 ? void 0 : userDetail.access_token;
};

/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "@material-ui/core/Badge":
/*!******************************************!*\
  !*** external "@material-ui/core/Badge" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Badge");

/***/ }),

/***/ "@material-ui/core/Tab":
/*!****************************************!*\
  !*** external "@material-ui/core/Tab" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Tab");

/***/ }),

/***/ "@material-ui/core/Tabs":
/*!*****************************************!*\
  !*** external "@material-ui/core/Tabs" ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Tabs");

/***/ }),

/***/ "@material-ui/core/styles":
/*!*******************************************!*\
  !*** external "@material-ui/core/styles" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "@material-ui/core/useMediaQuery":
/*!**************************************************!*\
  !*** external "@material-ui/core/useMediaQuery" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/useMediaQuery");

/***/ }),

/***/ "@material-ui/core/withWidth":
/*!**********************************************!*\
  !*** external "@material-ui/core/withWidth" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/withWidth");

/***/ }),

/***/ "@material-ui/icons/Close":
/*!*******************************************!*\
  !*** external "@material-ui/icons/Close" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Close");

/***/ }),

/***/ "@material-ui/lab":
/*!***********************************!*\
  !*** external "@material-ui/lab" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/lab");

/***/ }),

/***/ "clsx":
/*!***********************!*\
  !*** external "clsx" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("clsx");

/***/ }),

/***/ "feather-icons-react":
/*!**************************************!*\
  !*** external "feather-icons-react" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("feather-icons-react");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-feather":
/*!********************************!*\
  !*** external "react-feather" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-feather");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0LmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9pbWFnZS1jb25maWcuanNcIiIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L2ltYWdlLnRzeCIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3JlcXVlc3QtaWRsZS1jYWxsYmFjay50cyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3VzZS1pbnRlcnNlY3Rpb24udHN4Iiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L2ltYWdlLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2V4dGVuZHMuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL25leHQvbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvRGFzaGJvYXJkUGFnZVN0eWxlTW9kdWxlL0Rhc2hib2FyZFBhZ2VTdHlsZU1vZHVsZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvbW9kdWxlcy9EYXNoYm9hcmRQYWdlU3R5bGVNb2R1bGUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BhZ2VzL2Rhc2hib2FyZHBhZ2VzdHlsZS9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvQWxlcnQvQWxlcnRzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9BbGVydC9BbGVydHNTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0FsZXJ0L2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Db21tb25DYXJkL0NvbW1vbkNhcmQuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0NvbW1vbkNhcmQvQ29tbW9uQ2FyZFN0eWxlLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Db21tb25DYXJkL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L0Rhc2hib2FyZEFjY291bnQvRGFzaGJvYXJkQWNjb3VudC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvRGFzaGJvYXJkUGFnZUNvbXBvbmVudC9EYXNoYm9hcmRBY2NvdW50L0Rhc2hib2FyZEFjY291bnRTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvRGFzaGJvYXJkUGFnZVN0eWxlTW9kdWxlL0Rhc2hib2FyZEFjY291bnQvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkQWNjb3VudERldGFpbHMvRGFzaGJvYXJkQWNjb3VudERldGFpbHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkQWNjb3VudERldGFpbHMvRGFzaGJvYXJkQWNjb3VudERldGFpbHNTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkQWNjb3VudERldGFpbHMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkQ29udGFjdFVzL0Rhc2hib2FyZENvbnRhY3RVcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvRGFzaGJvYXJkUGFnZUNvbXBvbmVudC9EYXNoYm9hcmRDb250YWN0VXMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkSGVscENlbnRlci9EYXNoYm9hcmRIZWxwQ2VudGVyLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L0Rhc2hib2FyZEhlbHBDZW50ZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkSGVscFRvcGljcy9EYXNoYm9hcmRIZWxwVG9waWNzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L0Rhc2hib2FyZEhlbHBUb3BpY3MvRGFzaGJvYXJkSGVscFRvcGljc1N0eWxlcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvRGFzaGJvYXJkUGFnZUNvbXBvbmVudC9EYXNoYm9hcmRIZWxwVG9waWNzL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L0Rhc2hib2FyZEhvbWUvRGFzaGJvYXJkSG9tZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvRGFzaGJvYXJkUGFnZUNvbXBvbmVudC9EYXNoYm9hcmRIb21lL0Rhc2hib2FyZEhvbWVTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvRGFzaGJvYXJkUGFnZVN0eWxlTW9kdWxlL0Rhc2hib2FyZEhvbWUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkTm9Qcm9ncmFtcy9EYXNoYm9hcmROb1Byb2dyYW1zLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L0Rhc2hib2FyZE5vUHJvZ3JhbXMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvRGFzaGJvYXJkUGFnZVN0eWxlTW9kdWxlL0Rhc2hib2FyZFBhZ2VTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkWW91ckFwcGxpY2F0aW9uL0Rhc2hib2FyZFlvdXJBcHBsaWNhdGlvbi5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvRGFzaGJvYXJkUGFnZUNvbXBvbmVudC9EYXNoYm9hcmRZb3VyQXBwbGljYXRpb24vaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvWW91clZvdWNoZXIvWW91clZvdWNoZXIuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvWW91clZvdWNoZXIvWW91clZvdWNoZXJTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvWW91clZvdWNoZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0V4aXREaWFsb2dCb3gvRXhpdERpYWxvZ0JveC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvbW9kdWxlcy9DaGVja1lvdXJFbGlnaWJpbGl0eS9FeGl0RGlhbG9nQm94L2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Gb290ZXIvRm9vdGVyLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Gb290ZXIvRm9vdGVyU3R5bGVzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Gb290ZXIvU3ViRm9vdGVyL1N1YkZvb3Rlci5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvRm9vdGVyL1N1YkZvb3Rlci9TdWJGb290ZXJTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Zvb3Rlci9TdWJGb290ZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Zvb3Rlci9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL01haW5IZWFkZXIvTWFpbkhlYWRlci5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL01haW5IZWFkZXIvTWFpbkhlYWRlclN0eWxlcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL01haW5IZWFkZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0hlYWRlci9Nb2JpbGVNZW51L01vYmlsZU1lbnUuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0hlYWRlci9Nb2JpbGVNZW51L01vYmlsZU1lbnVDb25zdGFudC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL01vYmlsZU1lbnUvTW9iaWxlTWVudVN0eWxlcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL01vYmlsZU1lbnUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0hlYWRlci9Ub3BIZWFkZXIvVG9wSGVhZGVyLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9IZWFkZXIvVG9wSGVhZGVyL1RvcEhlYWRlclN0eWxlcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL1RvcEhlYWRlci9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVscENlbnRlci9IZWxwQ2VudGVyLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL0hlbHBDZW50ZXIvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0luZGljYXRvcnMvSW5kaWNhdG9ycy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSW5kaWNhdG9ycy9JbmRpY2F0b3JzU3R5bGVzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9JbmRpY2F0b3JzL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Mb2dvSGVhZGluZy9Mb2dvSGVhZGluZy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvTG9nb0hlYWRpbmcvTG9nb0hlYWRpbmdTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0xvZ29IZWFkaW5nL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9PYmplY3RDYXJkL09iamVjdENhcmQuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL09iamVjdENhcmQvT2JqZWN0Q2FyZFN0eWxlLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9PYmplY3RDYXJkL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9QYWdlSGVhZGluZy9QYWdlSGVhZGluZy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvUGFnZUhlYWRpbmcvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL1Byb2dyYW1DYXJkL1Byb2dyYW1DYXJkLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Qcm9ncmFtQ2FyZC9Qcm9ncmFtQ2FyZHNTdHlsZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvUHJvZ3JhbUNhcmQvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL1dpemFyZEhlYWRlci9XaXphcmRIZWFkZXIuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL1dpemFyZEhlYWRlci9XaXphcmRIZWFkZXJTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL1dpemFyZEhlYWRlci9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbnN0YW50cy9yb3V0ZXNDb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy9zdG9yZU1hbmFnZXIuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy91dGlscy5qcyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL0JhZGdlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvVGFiXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvVGFic1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL3N0eWxlc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL3VzZU1lZGlhUXVlcnlcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS93aXRoV2lkdGhcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvQ2xvc2VcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvbGFiXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiY2xzeFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcImZlYXRoZXItaWNvbnMtcmVhY3RcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXh0L3JvdXRlclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInByb3AtdHlwZXNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0LWZlYXRoZXJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiJdLCJuYW1lcyI6WyJnbG9iYWwiLCJWQUxJRF9MT0FESU5HX1ZBTFVFUyIsImxvYWRlcnMiLCJWQUxJRF9MQVlPVVRfVkFMVUVTIiwiZGV2aWNlU2l6ZXMiLCJpbWFnZVNpemVzIiwibG9hZGVyIiwicGF0aCIsImRvbWFpbnMiLCJwcm9jZXNzIiwiaW1hZ2VDb25maWdEZWZhdWx0IiwiYWxsU2l6ZXMiLCJjb25maWdEZXZpY2VTaXplcyIsImEiLCJsYXlvdXQiLCJ3aWR0aHMiLCJraW5kIiwid2lkdGgiLCJ3IiwicCIsInNyY1NldCIsInNpemVzIiwiZ2V0V2lkdGhzIiwibGFzdCIsInNyYyIsImkiLCJwYXJzZUludCIsImxvYWQiLCJyb290IiwiVkFMSURfTE9BREVSUyIsImNvbmZpZ0xvYWRlciIsInVub3B0aW1pemVkIiwicHJpb3JpdHkiLCJhbGwiLCJyZXN0IiwidW5zaXplZCIsIkJvb2xlYW4iLCJKU09OIiwibG9hZGluZyIsImlzTGF6eSIsInJvb3RNYXJnaW4iLCJkaXNhYmxlZCIsImlzVmlzaWJsZSIsIndpZHRoSW50IiwiZ2V0SW50IiwiaGVpZ2h0SW50IiwicXVhbGl0eUludCIsImltZ1N0eWxlIiwidmlzaWJpbGl0eSIsInBvc2l0aW9uIiwidG9wIiwibGVmdCIsImJvdHRvbSIsInJpZ2h0IiwiYm94U2l6aW5nIiwicGFkZGluZyIsImJvcmRlciIsIm1hcmdpbiIsImRpc3BsYXkiLCJoZWlnaHQiLCJtaW5XaWR0aCIsIm1heFdpZHRoIiwibWluSGVpZ2h0IiwibWF4SGVpZ2h0IiwicXVvdGllbnQiLCJwYWRkaW5nVG9wIiwiaXNOYU4iLCJ3cmFwcGVyU3R5bGUiLCJvdmVyZmxvdyIsInNpemVyU3R5bGUiLCJzaXplclN2ZyIsImltZ0F0dHJpYnV0ZXMiLCJnZW5lcmF0ZUltZ0F0dHJzIiwicXVhbGl0eSIsInBhcmFtcyIsInBhcmFtc1N0cmluZyIsIm5vcm1hbGl6ZVNyYyIsIm1pc3NpbmdWYWx1ZXMiLCJwYXJzZWRTcmMiLCJjb25zb2xlIiwiY29uZmlnRG9tYWlucyIsImhvc3RuYW1lIiwiZW5jb2RlVVJJQ29tcG9uZW50IiwicmVxdWVzdElkbGVDYWxsYmFjayIsInNlbGYiLCJzdGFydCIsIkRhdGUiLCJzZXRUaW1lb3V0IiwiY2IiLCJkaWRUaW1lb3V0IiwidGltZVJlbWFpbmluZyIsIk1hdGgiLCJjYW5jZWxJZGxlQ2FsbGJhY2siLCJjbGVhclRpbWVvdXQiLCJoYXNJbnRlcnNlY3Rpb25PYnNlcnZlciIsImlzRGlzYWJsZWQiLCJ1bm9ic2VydmUiLCJzZXRSZWYiLCJlbCIsIm9ic2VydmUiLCJzZXRWaXNpYmxlIiwiaWRsZUNhbGxiYWNrIiwiY3JlYXRlT2JzZXJ2ZXIiLCJlbGVtZW50cyIsIm9ic2VydmVyIiwib2JzZXJ2ZXJzIiwiaWQiLCJvcHRpb25zIiwiaW5zdGFuY2UiLCJlbnRyaWVzIiwiZW50cnkiLCJjYWxsYmFjayIsIkRhc2hib2FyZFBhZ2VTdHlsZU1vZHVsZSIsImxpbmtBcnJheXMiLCJ0ZXh0IiwiaWNvbiIsIkhlbHBDaXJjbGUiLCJBcmNoaXZlIiwidGl0bGUiLCJzdWJ0aXRsZSIsInRpbWUiLCJtYXAiLCJpdGVtIiwiRGFzaGJvYXJkUGFnZVN0eWxlIiwiQWxlcnRzIiwidmFyaWFudCIsImljb25Db2xvciIsImNoaWxkcmVuIiwic2hvd0Nsb3NlQnRuIiwiY2xhc3NlcyIsInVzZVN0eWxlcyIsImRlZmF1bHRQcm9wcyIsInByb3BUeXBlcyIsIlByb3BUeXBlcyIsIm9uZU9mIiwibm9kZSIsImJvb2wiLCJtYWtlU3R5bGVzIiwidGhlbWUiLCJwcmltYXJ5QWxlcnQiLCJiYWNrZ3JvdW5kQ29sb3IiLCJwYWxldHRlIiwicHJpbWFyeSIsIm1haW4iLCJjb2xvciIsImNvbW1vbiIsIndoaXRlIiwiYm94U2hhZG93IiwiYm9yZGVyUmFkaXVzIiwic2Vjb25kYXJ5QWxlcnQiLCJtZW51cyIsIm1lbnVCYWNrZ3JvdW5kIiwibGlnaHQiLCJDb21tb25DYXJkIiwiYmdDb2xvciIsImlzU3RhdHVzQ2FyZCIsIm9uQ2xpY2tCYWNrIiwic2hvd0JhY2tCdG4iLCJzaG93SGVhZGVyIiwibm9NYXJnaW4iLCJiZ1NjcmVlbiIsImJhY2tCdG5Db2xvciIsInNwYWNlIiwicGFnZVZpZXciLCJsYW5kaW5nUGFnZUljb24iLCJjYXJkQ2xhc3MiLCJjbHN4Iiwid2VsY29tZVBhZ2UiLCJoZWFkZXIiLCJzdWJSb290IiwibW9iaWxlQmFja0J0biIsImljb25Sb290IiwiZ29CYWNrQnRuMSIsImdvQmFja0J0bjIiLCJ2aXNpYmxlWHMiLCJ2aXNpYmxlRGVza3RvcCIsInNob3dGYWNlQm9va0xvZ2luQnV0dG9uIiwiaXNQcm9maWxlU2V0dXAiLCJmdW5jIiwib25DbGlja0NvbnRpbnVlIiwiekluZGV4IiwiYnJlYWtwb2ludHMiLCJkb3duIiwibGciLCJ4cyIsImJhY2tncm91bmQiLCJncmF5IiwidHJhbnNwYXJlbnQiLCJ3ZWxjb21lIiwiYmFja2dyb3VuZFNpemUiLCJiYWNrZ3JvdW5kUG9zaXRpb24iLCJiYWNrZ3JvdW5kSW1hZ2UiLCJzdWNjZXNzIiwibm9uZSIsImZ1bGwiLCJhbGlnbkl0ZW1zIiwiaGFsZiIsImJhY2tCdG5QcmltYXJ5Iiwib3BhY2l0eSIsImJhY2tCdG5XaGl0ZSIsInVwIiwicGFkZGluZ0JvdHRvbSIsIkRhc2hib2FyZEFjY291bnQiLCJ2YWx1ZSIsInNldFZhbHVlIiwiUmVhY3QiLCJ1c2VTdGF0ZSIsImhhbmRsZUNoYW5nZSIsImV2ZW50IiwibmV3VmFsdWUiLCJhY2NvdW50TGlua3MiLCJVc2VyIiwicmlnaHRJY29uIiwiQ2hldnJvblJpZ2h0IiwiU2V0dGluZ3MiLCJTYXZlIiwiYWNjb3VudExpbmtOYW1lIiwibGFiZWwiLCJpbmZvIiwiY29udGFjdEluZm9ybWF0aW9uTGlua3MiLCJhMTF5UHJvcHMiLCJpbmRleCIsIlRhYlBhbmVsIiwicHJvcHMiLCJvdGhlciIsInRhYldyYXBwZXIiLCJ3ZWJUYWJzIiwidGFicyIsImNhcmRMaW5rcyIsImNhcmRMaW5rc1RleHQiLCJtb2JpbGVUYWJzIiwiYW55IiwibnVtYmVyIiwiYm9yZGVyQm90dG9tIiwiY3VzdG9tQ2FyZCIsIm1vYmlsZUJ0biIsIkRhc2hib2FyZEFjY291bnREZXRhaWxzIiwiRGFzaGJvYXJkQ29udGFjdFVzIiwiRGFzaGJvYXJkSGVscENlbnRlciIsImdldHRpbmdTdGFydGVkVGV4dCIsImVsaWdpYmlsaXR5UXVlc3Rpb25zVGV4dCIsIm90aGVyVG9waWNzVGV4dCIsImxpbmtBcnJheSIsIlBob25lIiwiSW5mbyIsIkRhc2hib2FyZEhlbHBUb3BpY3MiLCJEYXNoYm9hcmRIb21lIiwiUGx1cyIsIkVkaXQiLCJkYXNoYm9hcmRVcHBlcldyYXBwZXIiLCJsaW5rVGV4dCIsImxpbmtMaXN0IiwiaW1hZ2VOYW1lIiwiYm94V3JhcHBlciIsImltYWdlV3JhcHBlciIsIm1vYmlsZUFycm93Iiwid2ViQXJyb3ciLCJ0eXBlIiwic2Vjb25kYXJ5Iiwid2FybmluZyIsInBlbmRpbmciLCJleHRyYUxpZ2h0IiwibWFyZ2luQm90dG9tIiwic2Vjb25kYXJ5QmdDb2xvciIsIm1hcmdpblRvcCIsIkRhc2hib2FyZE5vUHJvZ3JhbXMiLCJEYXNoYm9hcmRZb3VyQXBwbGljYXRpb24iLCJwcm9ncmFtTmFtZSIsInN0YXR1cyIsIllvdXJWb3VjaGVyIiwiZmxleCIsImZvbnRTaXplIiwieHNCdG4iLCJzdHJpbmciLCJ3aXRoV2lkdGgiLCJqdXN0aWZ5Q29udGVudCIsImZsZXhEaXJlY3Rpb24iLCJFeGl0RGlhbG9nQm94Iiwib25Db25maXJtIiwib25DbG9zZSIsIkZvb3RlciIsImZvb3RlcldyYXBwZXIiLCJsb2dvV3JhcHBlciIsImxvZ29JbWFnZSIsImltYWdlIiwiY29tcGFueVRleHQiLCJsb2dvVGV4dCIsImNvbXBhbnlOYW1lIiwibW9iaWxlTGlua3MiLCJmb290ZXJHcmlkIiwidGl0bGVUZXh0IiwidHlwb2dyYXBoeSIsImg0IiwidGV4dEFsaWduIiwibWFyZ2luUmlnaHQiLCJmb250U3R5bGUiLCJTdWJGb290ZXIiLCJzdWJGb290ZXJXcmFwcGVyIiwicG93ZXJlZEJ5VGV4dCIsImJyZWFrZXIiLCJsaW5lSGVpZ2h0IiwiTWFpbkhlYWRlciIsImlzTG9nZ2VkSW4iLCJ1c2VyTmFtZSIsImhlYWRlclN1YnRpdGxlIiwibW9iaWxlVGl0bGUiLCJsYWJlbE5hbWUiLCJzaG93TW9iaWxlTWVudSIsIm1lbnVUeXBlIiwic2V0TWVudVR5cGUiLCJzaG93TWVudUJhciIsImJyZWFrUG9pbnQiLCJ1c2VNZWRpYVF1ZXJ5IiwiYnV0dG9uQ29sb3IiLCJidXR0b25UaXRsZSIsImxpbmtOYW1lQXJyYXkiLCJsaW5rTmFtZSIsImNvbnRpbnVlVG9Mb2dpbiIsIlVTRVJfTE9HSU4iLCJST1VURVMiLCJSb3V0ZXIiLCJwdXNoIiwiUk9VVEUiLCJtYWluSGVhZGVyV3JhcHBlciIsImRpc3BsYXlOb25lWHMiLCJtZW51QnV0dG9uIiwibGlua1dyYXBwZXIiLCJsZW5ndGgiLCJkaXNwbGF5QmxvY2tYcyIsImJhY2tncm91bmRSZXBlYXQiLCJib3JkZXJCb3R0b21MZWZ0UmFkaXVzIiwic3BhY2luZyIsImJvcmRlckJvdHRvbVJpZ2h0UmFkaXVzIiwiaDIiLCJNb2JpbGVNZW51IiwiYmVmb3JlTG9naW4iLCJvcGVuTW9iaWxlTWVudSIsInNldE9wZW5Nb2JpbGVNZW51IiwibGlua3MiLCJiZWZvcmVMb2dpbkxpbmtBcnJheSIsImFjdGlvbkxpbmtzIiwiYmVmb3JlTG9naW5QYWdlc0xpbmtBcnJheSIsImFmdGVyTG9naW5QYWdlc0xpbmtBcnJheSIsImxvZ2luV3JhcHBlciIsImJlZm9yZUxvZ2luV3JhcHBlciIsImN1c3RvbUJ1dHRvbiIsInRvcEltYWdlUG9zaXRpb24iLCJib3R0b21JbWFnZVBvc2l0aW9uIiwiSG9tZSIsIkZpbGVUZXh0IiwiU2VuZCIsImg2IiwiVG9wSGVhZGVyIiwiaXNXaXphcmQiLCJvbkV4aXRDbGljayIsIm9wZW5EaWFsb2ciLCJzZXRPcGVuRGlhbG9nIiwiaGFuZGxlQ2xvc2UiLCJsaW5rIiwiY29udGVudCIsIkhlbHBDZW50ZXIiLCJJbmRpY2F0b3JzIiwic2l6ZSIsImljb25OYW1lIiwiaWNvblNpemUiLCJib3JkZXJXaWR0aCIsImZhaWxlZCIsImVycm9yIiwiYm9yZGVyQ29sb3IiLCJkZWZhdWx0IiwiY29tcGxldGUiLCJiYWNrZ3JvdW5kQ2xpcCIsIkxvZ29IZWFkaW5nIiwic3ViVGV4dENvbG9yIiwiT2JqZWN0Q2FyZCIsImNhcmRUeXBlIiwib25DbGljayIsIm9uRGVsZXRlIiwiaXNNZW1iZXIiLCJvbkVkaXRDbGljayIsInNob3dPcHRpb25NZW51IiwiYW5jaG9yRWwiLCJzZXRBbmNob3JFbCIsIm9wZW4iLCJoYW5kbGVDbGljayIsImN1cnJlbnRUYXJnZXQiLCJoYW5kbGVFZGl0IiwiaGFuZGxlRGVsZXRlIiwicm9vdFVwbG9hZCIsImlucHV0Iiwibm9vcCIsIlBhZ2VIZWFkaW5nIiwiUHJvZ3JhbUNhcmQiLCJzaG93TGVmdEFycm93Iiwic2hvd0RlbGV0ZUJveCIsInNob3dJbWFnZSIsInNob3dMZWZ0Qm9yZGVyIiwiaW1nVXJsIiwib3ZlcmxheSIsIndhaXRpbmciLCJXaXphcmRIZWFkZXIiLCJXaXphcmRIZWFkZXJXcmFwcGVyIiwiZGV2aWNlSGVhZGVyIiwieHNNYXJnaW4iLCJXaXphcmRIZWFCb3giLCJIT01FIiwiVElUTEUiLCJOQU1FIiwiUEFSRU5UX1JPVVRFIiwiRVhBTVBMRVMiLCJMT0dJTiIsIlBST0ZJTEUiLCJWT1VDSEVSIiwiQUNDT1VOVCIsIkFDQ09VTlRfREVUQUlMIiwiR0VUX1NUQVJURUQiLCJIRUxQIiwiSEVMUF9UT1BJQ1MiLCJDSEFOR0VfUEFTU1dPUkQiLCJGT1JHT1RfUEFTU1dPUkQiLCJDT01NT05fQ09NUE9ORU5UX1NUWUxFIiwiQ09NTU9OX0ZVTExGTE9XUEFHRV9TVFlMRSIsIlZPVUNIRVJfUkVDRUlWRUQiLCJEQVNIQk9BUkRfUEFHRV9TVFlMRSIsIkxBTkRMT1JEX1BBR0VfU1RZTEUiLCJTVVBFUlZJU09SX0xPR0lOIiwiQ0hFQ0tfRUxJR0lCSUxJVFkiLCJTVVBFUlZJU09SX0RBU0hCT0FSRCIsIkNSRUFURV9QUk9GSUxFIiwiRUxJR0lCSUxJVFlfQ0FMQ1VMQVRPUiIsIk1BTkFHRV9QUk9HUkFNUyIsIk1BTkFHRV9TTVRQIiwiTUFOQUdFX1BSRUFQUExJQ0FUSU9OIiwiSE9VU0VfSE9MRF9ERVRBSUwiLCJSRVZJRVdfQVBQTElDQVRJT04iLCJIT1VTRUhPTERfSU5DT01FIiwiSE9VU0VIT0xEX0FTU0VUUyIsIkhPVVNFSE9MRF9TUEVDSUFMX0VYUEVOU0VTIiwiUkVOVF9BRkZPUkRBQklMSVRZIiwiWU9VUl9ET0NVTUVOVFMiLCJSRVZJRVdfQU5EX1NJR04iLCJzZXRMb2NhbFN0b3JhZ2UiLCJrZXkiLCJzdG9yYWdlVmFsdWUiLCJzdHJpbmdpZnkiLCJ3aW5kb3ciLCJsb2NhbFN0b3JhZ2UiLCJzZXRJdGVtIiwiZ2V0TG9jYWxTdG9yYWdlIiwiZ2V0SXRlbSIsInBhcnNlIiwicmVtb3ZlTG9jYWxTdG9yYWdlIiwicmVtb3ZlSXRlbSIsImdldEJhc2VVcmwiLCJnZXRMb2NhbGl6ZUtleSIsImdldFVzZXJJZCIsInVzZXJEZXRhaWwiLCJ1c2VyX2lkIiwiZ2V0QWNjZXNzVG9rZW4iLCJhY2Nlc3NfdG9rZW4iXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJO1FBQ0o7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7OztBQ3hGQSw4RDs7Ozs7Ozs7Ozs7QUNBQSxvRTs7Ozs7Ozs7Ozs7QUNBQSx5RTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFNQTs7QUFFQSxVQUFtQztBQUNqQztBQUFFQSxRQUFELHNCQUFDQSxHQUFELElBQUNBO0FBR0o7O0FBQUEsTUFBTUMsb0JBQW9CLEdBQUcsa0JBQTdCLFNBQTZCLENBQTdCO0FBYUEsTUFBTUMsT0FBTyxHQUFHLFFBR2QsQ0FDQSxVQURBLFdBQ0EsQ0FEQSxFQUVBLGVBRkEsZ0JBRUEsQ0FGQSxFQUdBLFdBSEEsWUFHQSxDQUhBLEVBSUEsWUFQRixhQU9FLENBSkEsQ0FIYyxDQUFoQjtBQVVBLE1BQU1DLG1CQUFtQixHQUFHLDZDQUE1QixTQUE0QixDQUE1QjtBQXNDQSxNQUFNO0FBQ0pDLGFBQVcsRUFEUDtBQUVKQyxZQUFVLEVBRk47QUFHSkMsUUFBTSxFQUhGO0FBSUpDLE1BQUksRUFKQTtBQUtKQyxTQUFPLEVBTEg7QUFBQSxJQU9GQywwSkFBeURDLGFBUDdELG1CLENBUUE7O0FBQ0EsTUFBTUMsUUFBUSxHQUFHLENBQUMsR0FBRCxtQkFBdUIsR0FBeEMsZ0JBQWlCLENBQWpCO0FBQ0FDLGlCQUFpQixDQUFqQkEsS0FBdUIsVUFBVUMsQ0FBQyxHQUFsQ0Q7QUFDQUQsUUFBUSxDQUFSQSxLQUFjLFVBQVVFLENBQUMsR0FBekJGOztBQUVBLGtDQUd5QztBQUN2QyxNQUNFLDZCQUNBRyxNQUFNLEtBRE4sVUFFQUEsTUFBTSxLQUhSLGNBSUU7QUFDQSxXQUFPO0FBQUVDLFlBQU0sRUFBUjtBQUE2QkMsVUFBSSxFQUF4QztBQUFPLEtBQVA7QUFHRjs7QUFBQSxRQUFNRCxNQUFNLEdBQUcsQ0FDYixHQUFHLFNBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVFFLEtBQUssR0FBRztBQUFoQjtBQUFBLFFBQ0dDLENBQUQsSUFBT1AsUUFBUSxDQUFSQSxLQUFlUSxDQUFELElBQU9BLENBQUMsSUFBdEJSLE1BQWdDQSxRQUFRLENBQUNBLFFBQVEsQ0FBUkEsU0FYdEQsQ0FXcUQsQ0FEakQsQ0FUQyxDQURVLENBQWY7QUFlQSxTQUFPO0FBQUE7QUFBVUssUUFBSSxFQUFyQjtBQUFPLEdBQVA7QUFtQkY7O0FBQUEsMEJBQTBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTFCO0FBQTBCLENBQTFCLEVBUXVDO0FBQ3JDLG1CQUFpQjtBQUNmLFdBQU87QUFBQTtBQUFPSSxZQUFNLEVBQWI7QUFBMEJDLFdBQUssRUFBdEM7QUFBTyxLQUFQO0FBR0Y7O0FBQUEsUUFBTTtBQUFBO0FBQUE7QUFBQSxNQUFtQkMsU0FBUyxRQUFsQyxNQUFrQyxDQUFsQztBQUNBLFFBQU1DLElBQUksR0FBR1IsTUFBTSxDQUFOQSxTQUFiO0FBRUEsU0FBTztBQUNMUyxPQUFHLEVBQUVsQixNQUFNLENBQUM7QUFBQTtBQUFBO0FBQWdCVyxXQUFLLEVBQUVGLE1BQU0sQ0FEcEMsSUFDb0M7QUFBN0IsS0FBRCxDQUROO0FBRUxNLFNBQUssRUFBRSxVQUFVTCxJQUFJLEtBQWQsZ0JBRkY7QUFHTEksVUFBTSxFQUFFTCxNQUFNLENBQU5BLElBRUosVUFDRyxHQUFFVCxNQUFNLENBQUM7QUFBQTtBQUFBO0FBQWdCVyxXQUFLLEVBQXRCO0FBQUMsS0FBRCxDQUE2QixJQUNwQ0QsSUFBSSxLQUFKQSxVQUFtQlMsQ0FBQyxHQUFHLENBQ3hCLEdBQUVULElBTERELFNBSFYsSUFHVUE7QUFISCxHQUFQO0FBY0Y7O0FBQUEsbUJBQWdEO0FBQzlDLE1BQUksYUFBSixVQUEyQjtBQUN6QjtBQUVGOztBQUFBLE1BQUksYUFBSixVQUEyQjtBQUN6QixXQUFPVyxRQUFRLElBQWYsRUFBZSxDQUFmO0FBRUY7O0FBQUE7QUFHRjs7QUFBQSx5Q0FBMkQ7QUFDekQsUUFBTUMsSUFBSSxHQUFHekIsT0FBTyxDQUFQQSxJQUFiLFlBQWFBLENBQWI7O0FBQ0EsWUFBVTtBQUNSLFdBQU95QixJQUFJO0FBQUdDLFVBQUksRUFBUDtBQUFBLE9BQVgsV0FBVyxFQUFYO0FBRUY7O0FBQUEsUUFBTSxVQUNILHlEQUF3REMscUNBRXZELGVBQWNDLFlBSGxCLEVBQU0sQ0FBTjtBQU9hOztBQUFBLHFCQWNBO0FBQUEsTUFkZTtBQUFBO0FBQUE7QUFHNUJDLGVBQVcsR0FIaUI7QUFJNUJDLFlBQVEsR0FKb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVk1QjFCLFVBQU0sR0Fac0I7QUFBQSxNQWNmO0FBQUEsTUFEVjJCLEdBQ1U7QUFDYixNQUFJQyxJQUF5QixHQUE3QjtBQUNBLE1BQUlwQixNQUFnQyxHQUFHTyxLQUFLLGtCQUE1QztBQUNBLE1BQUljLE9BQU8sR0FBWDs7QUFDQSxNQUFJLGFBQUosTUFBdUI7QUFDckJBLFdBQU8sR0FBR0MsT0FBTyxDQUFDRixJQUFJLENBQXRCQyxPQUFpQixDQUFqQkEsQ0FEcUIsQ0FFckI7O0FBQ0EsV0FBT0QsSUFBSSxDQUFYLFNBQVcsQ0FBWDtBQUhGLFNBSU8sSUFBSSxZQUFKLE1BQXNCO0FBQzNCO0FBQ0EsUUFBSUEsSUFBSSxDQUFSLFFBQWlCcEIsTUFBTSxHQUFHb0IsSUFBSSxDQUFicEIsT0FGVSxDQUkzQjs7QUFDQSxXQUFPb0IsSUFBSSxDQUFYLFFBQVcsQ0FBWDtBQUdGOztBQUFBLFlBQTJDO0FBQ3pDLFFBQUksQ0FBSixLQUFVO0FBQ1IsWUFBTSxVQUNILDBIQUF5SEcsSUFBSSxDQUFKQSxVQUN4SDtBQUFBO0FBQUE7QUFEd0hBO0FBQ3hILE9BRHdIQSxDQUQ1SCxFQUFNLENBQU47QUFNRjs7QUFBQSxRQUFJLENBQUNsQyxtQkFBbUIsQ0FBbkJBLFNBQUwsTUFBS0EsQ0FBTCxFQUEyQztBQUN6QyxZQUFNLFVBQ0gsbUJBQWtCcUIsR0FBSSw4Q0FBNkNWLE1BQU8sc0JBQXFCWCxtQkFBbUIsQ0FBbkJBLHFCQURsRyxHQUFNLENBQU47QUFNRjs7QUFBQSxRQUFJLENBQUNGLG9CQUFvQixDQUFwQkEsU0FBTCxPQUFLQSxDQUFMLEVBQTZDO0FBQzNDLFlBQU0sVUFDSCxtQkFBa0J1QixHQUFJLCtDQUE4Q2MsT0FBUSxzQkFBcUJyQyxvQkFBb0IsQ0FBcEJBLHFCQURwRyxHQUFNLENBQU47QUFNRjs7QUFBQSxRQUFJK0IsUUFBUSxJQUFJTSxPQUFPLEtBQXZCLFFBQW9DO0FBQ2xDLFlBQU0sVUFDSCxtQkFBa0JkLEdBRHJCLGlGQUFNLENBQU47QUFJRjs7QUFBQSxpQkFBYTtBQUNYLFlBQU0sVUFDSCxtQkFBa0JBLEdBRHJCLGlHQUFNLENBQU47QUFJSDtBQUVEOztBQUFBLE1BQUllLE1BQU0sR0FDUixjQUFjRCxPQUFPLEtBQVBBLFVBQXNCLG1CQUR0QyxXQUNFLENBREY7O0FBRUEsTUFBSWQsR0FBRyxJQUFJQSxHQUFHLENBQUhBLFdBQVgsT0FBV0EsQ0FBWCxFQUFvQztBQUNsQztBQUNBTyxlQUFXLEdBQVhBO0FBQ0FRLFVBQU0sR0FBTkE7QUFHRjs7QUFBQSxRQUFNLDBCQUEwQixzQ0FBa0M7QUFDaEVDLGNBQVUsRUFEc0Q7QUFFaEVDLFlBQVEsRUFBRSxDQUZaO0FBQWtFLEdBQWxDLENBQWhDO0FBSUEsUUFBTUMsU0FBUyxHQUFHLFdBQWxCO0FBRUEsUUFBTUMsUUFBUSxHQUFHQyxNQUFNLENBQXZCLEtBQXVCLENBQXZCO0FBQ0EsUUFBTUMsU0FBUyxHQUFHRCxNQUFNLENBQXhCLE1BQXdCLENBQXhCO0FBQ0EsUUFBTUUsVUFBVSxHQUFHRixNQUFNLENBQXpCLE9BQXlCLENBQXpCO0FBRUE7QUFDQTtBQUNBO0FBQ0EsTUFBSUcsUUFBcUMsR0FBRztBQUMxQ0MsY0FBVSxFQUFFTixTQUFTLGVBRHFCO0FBRzFDTyxZQUFRLEVBSGtDO0FBSTFDQyxPQUFHLEVBSnVDO0FBSzFDQyxRQUFJLEVBTHNDO0FBTTFDQyxVQUFNLEVBTm9DO0FBTzFDQyxTQUFLLEVBUHFDO0FBUzFDQyxhQUFTLEVBVGlDO0FBVTFDQyxXQUFPLEVBVm1DO0FBVzFDQyxVQUFNLEVBWG9DO0FBWTFDQyxVQUFNLEVBWm9DO0FBYzFDQyxXQUFPLEVBZG1DO0FBZTFDekMsU0FBSyxFQWZxQztBQWdCMUMwQyxVQUFNLEVBaEJvQztBQWlCMUNDLFlBQVEsRUFqQmtDO0FBa0IxQ0MsWUFBUSxFQWxCa0M7QUFtQjFDQyxhQUFTLEVBbkJpQztBQW9CMUNDLGFBQVMsRUFwQmlDO0FBQUE7QUFBNUM7QUFBNEMsR0FBNUM7O0FBeUJBLE1BQ0UsbUNBQ0EscUJBREEsZUFFQWpELE1BQU0sS0FIUixRQUlFO0FBQ0E7QUFDQSxVQUFNa0QsUUFBUSxHQUFHbkIsU0FBUyxHQUExQjtBQUNBLFVBQU1vQixVQUFVLEdBQUdDLEtBQUssQ0FBTEEsUUFBSyxDQUFMQSxZQUE0QixHQUFFRixRQUFRLEdBQUcsR0FBNUQ7O0FBQ0EsUUFBSWxELE1BQU0sS0FBVixjQUE2QjtBQUMzQjtBQUNBcUQsa0JBQVksR0FBRztBQUNiVCxlQUFPLEVBRE07QUFFYlUsZ0JBQVEsRUFGSztBQUdibkIsZ0JBQVEsRUFISztBQUtiSyxpQkFBUyxFQUxJO0FBTWJHLGNBQU0sRUFOUlU7QUFBZSxPQUFmQTtBQVFBRSxnQkFBVSxHQUFHO0FBQUVYLGVBQU8sRUFBVDtBQUFvQkosaUJBQVMsRUFBN0I7QUFBYmU7QUFBYSxPQUFiQTtBQVZGLFdBV08sSUFBSXZELE1BQU0sS0FBVixhQUE0QjtBQUNqQztBQUNBcUQsa0JBQVksR0FBRztBQUNiVCxlQUFPLEVBRE07QUFFYkcsZ0JBQVEsRUFGSztBQUdiTyxnQkFBUSxFQUhLO0FBSWJuQixnQkFBUSxFQUpLO0FBS2JLLGlCQUFTLEVBTEk7QUFNYkcsY0FBTSxFQU5SVTtBQUFlLE9BQWZBO0FBUUFFLGdCQUFVLEdBQUc7QUFDWGYsaUJBQVMsRUFERTtBQUVYSSxlQUFPLEVBRkk7QUFHWEcsZ0JBQVEsRUFIVlE7QUFBYSxPQUFiQTtBQUtBQyxjQUFRLEdBQUksZUFBYzNCLFFBQVMsYUFBWUUsU0FBL0N5QjtBQWZLLFdBZ0JBLElBQUl4RCxNQUFNLEtBQVYsU0FBd0I7QUFDN0I7QUFDQXFELGtCQUFZLEdBQUc7QUFDYkMsZ0JBQVEsRUFESztBQUViZCxpQkFBUyxFQUZJO0FBR2JJLGVBQU8sRUFITTtBQUliVCxnQkFBUSxFQUpLO0FBS2JoQyxhQUFLLEVBTFE7QUFNYjBDLGNBQU0sRUFOUlE7QUFBZSxPQUFmQTtBQVNIO0FBOUNELFNBOENPLElBQ0wsbUNBQ0EscUJBREEsZUFFQXJELE1BQU0sS0FIRCxRQUlMO0FBQ0E7QUFDQXFELGdCQUFZLEdBQUc7QUFDYlQsYUFBTyxFQURNO0FBRWJVLGNBQVEsRUFGSztBQUlibkIsY0FBUSxFQUpLO0FBS2JDLFNBQUcsRUFMVTtBQU1iQyxVQUFJLEVBTlM7QUFPYkMsWUFBTSxFQVBPO0FBUWJDLFdBQUssRUFSUTtBQVViQyxlQUFTLEVBVkk7QUFXYkcsWUFBTSxFQVhSVTtBQUFlLEtBQWZBO0FBTkssU0FtQkE7QUFDTDtBQUNBLGNBQTJDO0FBQ3pDLFlBQU0sVUFDSCxtQkFBa0IzQyxHQURyQix5RUFBTSxDQUFOO0FBSUg7QUFFRDs7QUFBQSxNQUFJK0MsYUFBZ0MsR0FBRztBQUNyQy9DLE9BQUcsRUFEa0M7QUFHckNKLFVBQU0sRUFIK0I7QUFJckNDLFNBQUssRUFKUDtBQUF1QyxHQUF2Qzs7QUFPQSxpQkFBZTtBQUNia0QsaUJBQWEsR0FBR0MsZ0JBQWdCLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFJL0J2RCxXQUFLLEVBSjBCO0FBSy9Cd0QsYUFBTyxFQUx3QjtBQUFBO0FBQWpDRjtBQUFpQyxLQUFELENBQWhDQTtBQVdGOztBQUFBLGVBQWE7QUFDWEosZ0JBQVksR0FBWkE7QUFDQUUsY0FBVSxHQUFWQTtBQUNBdEIsWUFBUSxHQUFSQTtBQUVGOztBQUFBLHNCQUNFO0FBQUssU0FBSyxFQUFWO0FBQUEsS0FDR3NCLFVBQVUsZ0JBQ1Q7QUFBSyxTQUFLLEVBQVY7QUFBQSxLQUNHQyxRQUFRLGdCQUNQO0FBQ0UsU0FBSyxFQUFFO0FBQ0xULGNBQVEsRUFESDtBQUVMSCxhQUFPLEVBRkY7QUFHTEQsWUFBTSxFQUhEO0FBSUxELFlBQU0sRUFKRDtBQUtMRCxhQUFPLEVBTlg7QUFDUyxLQURUO0FBUUUsT0FBRyxFQVJMO0FBU0UsbUJBVEY7QUFVRSxRQUFJLEVBVk47QUFXRSxPQUFHLEVBQUcsNkJBQTRCLCtCQVo3QjtBQUNQLElBRE8sR0FGRixJQUNULENBRFMsR0FEYixtQkFvQkU7QUFHRSxZQUFRLEVBSFY7QUFJRSxhQUFTLEVBSlg7QUFLRSxPQUFHLEVBTEw7QUFNRSxTQUFLLEVBMUJUO0FBb0JFLEtBcEJGLEVBNEJHdkIsUUFBUTtBQUFBO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUFDLE1BQUQsNEJBQ0U7QUFDRSxPQUFHLEVBQ0QsWUFDQXVDLGFBQWEsQ0FEYixNQUVBQSxhQUFhLENBRmIsU0FHQUEsYUFBYSxDQUxqQjtBQU9FLE9BQUcsRUFQTDtBQVFFLE1BQUUsRUFSSjtBQVNFLFFBQUksRUFBRUEsYUFBYSxDQUFiQSxxQkFBbUNBLGFBQWEsQ0FBQy9DLEdBVHpELENBVUU7QUFWRjtBQVdFLGVBQVcsRUFBRStDLGFBQWEsQ0FBQ25ELE1BWDdCLENBWUU7QUFaRjtBQWFFLGNBQVUsRUFBRW1ELGFBQWEsQ0FwQnRCO0FBT0wsSUFERixDQU5PLEdBN0JiLElBQ0UsQ0FERjtBQXlERixDLENBQUE7OztBQUVBLDJCQUEyQztBQUN6QyxTQUFPL0MsR0FBRyxDQUFIQSxDQUFHLENBQUhBLFdBQWlCQSxHQUFHLENBQUhBLE1BQWpCQSxDQUFpQkEsQ0FBakJBLEdBQVA7QUFHRjs7QUFBQSxxQkFBcUI7QUFBQTtBQUFBO0FBQUE7QUFBckI7QUFBcUIsQ0FBckIsRUFLb0M7QUFDbEM7QUFDQSxRQUFNa0QsTUFBTSxHQUFHLDJCQUEyQixPQUExQyxLQUFlLENBQWY7QUFDQSxNQUFJQyxZQUFZLEdBQWhCOztBQUNBLGVBQWE7QUFDWEQsVUFBTSxDQUFOQSxLQUFZLE9BQVpBO0FBR0Y7O0FBQUEsTUFBSUEsTUFBTSxDQUFWLFFBQW1CO0FBQ2pCQyxnQkFBWSxHQUFHLE1BQU1ELE1BQU0sQ0FBTkEsS0FBckJDLEdBQXFCRCxDQUFyQkM7QUFFRjs7QUFBQSxTQUFRLEdBQUUvQyxJQUFLLEdBQUVnRCxZQUFZLEtBQU0sR0FBRUQsWUFBckM7QUFHRjs7QUFBQSxzQkFBc0I7QUFBQTtBQUFBO0FBQXRCO0FBQXNCLENBQXRCLEVBQTZFO0FBQzNFLFNBQVEsR0FBRS9DLElBQUssR0FBRWdELFlBQVksS0FBTSxZQUFXM0QsS0FBOUM7QUFHRjs7QUFBQSwwQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBMUI7QUFBMEIsQ0FBMUIsRUFLb0M7QUFDbEM7QUFDQSxRQUFNeUQsTUFBTSxHQUFHLHNCQUFzQixPQUF0QixPQUFvQyxRQUFRRCxPQUFPLElBQWxFLE1BQW1ELENBQXBDLENBQWY7QUFDQSxNQUFJRSxZQUFZLEdBQUdELE1BQU0sQ0FBTkEsWUFBbkI7QUFDQSxTQUFRLEdBQUU5QyxJQUFLLEdBQUUrQyxZQUFhLEdBQUVDLFlBQVksS0FBNUM7QUFHRjs7QUFBQSx1QkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBdkI7QUFBdUIsQ0FBdkIsRUFLb0M7QUFDbEMsWUFBMkM7QUFDekMsVUFBTUMsYUFBYSxHQUFuQixHQUR5QyxDQUd6Qzs7QUFDQSxRQUFJLENBQUosS0FBVUEsYUFBYSxDQUFiQTtBQUNWLFFBQUksQ0FBSixPQUFZQSxhQUFhLENBQWJBOztBQUVaLFFBQUlBLGFBQWEsQ0FBYkEsU0FBSixHQUE4QjtBQUM1QixZQUFNLFVBQ0gsb0NBQW1DQSxhQUFhLENBQWJBLFVBRWxDLGdHQUErRnhDLElBQUksQ0FBSkEsVUFDL0Y7QUFBQTtBQUFBO0FBRCtGQTtBQUMvRixPQUQrRkEsQ0FIbkcsRUFBTSxDQUFOO0FBU0Y7O0FBQUEsUUFBSWIsR0FBRyxDQUFIQSxXQUFKLElBQUlBLENBQUosRUFBMEI7QUFDeEIsWUFBTSxVQUNILHdCQUF1QkEsR0FEMUIsMEdBQU0sQ0FBTjtBQUtGOztBQUFBLFFBQUksQ0FBQ0EsR0FBRyxDQUFIQSxXQUFELEdBQUNBLENBQUQsSUFBSixlQUEyQztBQUN6Qzs7QUFDQSxVQUFJO0FBQ0ZzRCxpQkFBUyxHQUFHLFFBQVpBLEdBQVksQ0FBWkE7QUFDQSxPQUZGLENBRUUsWUFBWTtBQUNaQyxlQUFPLENBQVBBO0FBQ0EsY0FBTSxVQUNILHdCQUF1QnZELEdBRDFCLGlJQUFNLENBQU47QUFLRjs7QUFBQSxVQUFJLENBQUN3RCxhQUFhLENBQWJBLFNBQXVCRixTQUFTLENBQXJDLFFBQUtFLENBQUwsRUFBaUQ7QUFDL0MsY0FBTSxVQUNILHFCQUFvQnhELEdBQUksa0NBQWlDc0QsU0FBUyxDQUFDRyxRQUFwRSwrREFBQyxHQURILG9FQUFNLENBQU47QUFLSDtBQUNGO0FBRUQ7O0FBQUEsU0FBUSxHQUFFckQsSUFBSyxRQUFPc0Qsa0JBQWtCLEtBQU0sTUFBS2pFLEtBQU0sTUFBS3dELE9BQU8sSUFBSSxFQUF6RTtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNWdCTSxNQUFNVSxtQkFBbUIsR0FDN0IsK0JBQStCQyxJQUFJLENBQXBDLG1CQUFDLElBQ0QsY0FFa0I7QUFDaEIsTUFBSUMsS0FBSyxHQUFHQyxJQUFJLENBQWhCLEdBQVlBLEVBQVo7QUFDQSxTQUFPQyxVQUFVLENBQUMsWUFBWTtBQUM1QkMsTUFBRSxDQUFDO0FBQ0RDLGdCQUFVLEVBRFQ7QUFFREMsbUJBQWEsRUFBRSxZQUFZO0FBQ3pCLGVBQU9DLElBQUksQ0FBSkEsT0FBWSxNQUFNTCxJQUFJLENBQUpBLFFBQXpCLEtBQW1CLENBQVpLLENBQVA7QUFISkg7QUFBRyxLQUFELENBQUZBO0FBRGUsS0FBakIsQ0FBaUIsQ0FBakI7QUFORzs7OztBQWdCQSxNQUFNSSxrQkFBa0IsR0FDNUIsK0JBQStCUixJQUFJLENBQXBDLGtCQUFDLElBQ0QsY0FBeUM7QUFDdkMsU0FBT1MsWUFBWSxDQUFuQixFQUFtQixDQUFuQjtBQUhHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkNQOztBQUNBOztBQWNBLE1BQU1DLHVCQUF1QixHQUFHLGdDQUFoQzs7QUFFTyx5QkFBNEM7QUFBQTtBQUE1QztBQUE0QyxDQUE1QyxFQUdxRDtBQUMxRCxRQUFNQyxVQUFtQixHQUFHdEQsUUFBUSxJQUFJLENBQXhDO0FBRUEsUUFBTXVELFNBQVMsR0FBRyxXQUFsQixNQUFrQixHQUFsQjtBQUNBLFFBQU0sd0JBQXdCLHFCQUE5QixLQUE4QixDQUE5QjtBQUVBLFFBQU1DLE1BQU0sR0FBRyx3QkFDWkMsRUFBRCxJQUFrQjtBQUNoQixRQUFJRixTQUFTLENBQWIsU0FBdUI7QUFDckJBLGVBQVMsQ0FBVEE7QUFDQUEsZUFBUyxDQUFUQTtBQUdGOztBQUFBLFFBQUlELFVBQVUsSUFBZCxTQUEyQjs7QUFFM0IsUUFBSUcsRUFBRSxJQUFJQSxFQUFFLENBQVosU0FBc0I7QUFDcEJGLGVBQVMsQ0FBVEEsVUFBb0JHLE9BQU8sS0FFeEJ6RCxTQUFELElBQWVBLFNBQVMsSUFBSTBELFVBQVUsQ0FGYixTQUVhLENBRmIsRUFHekI7QUFIRko7QUFHRSxPQUh5QixDQUEzQkE7QUFNSDtBQWhCWSxLQWlCYix5QkFqQkYsT0FpQkUsQ0FqQmEsQ0FBZjtBQW9CQSx3QkFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFKLHlCQUE4QjtBQUM1QixVQUFJLENBQUosU0FBYztBQUNaLGNBQU1LLFlBQVksR0FBRyw4Q0FBb0IsTUFBTUQsVUFBVSxDQUF6RCxJQUF5RCxDQUFwQyxDQUFyQjtBQUNBLGVBQU8sTUFBTSw2Q0FBYixZQUFhLENBQWI7QUFFSDtBQUNGO0FBUEQsS0FPRyxDQVBILE9BT0csQ0FQSDtBQVNBLFNBQU8sU0FBUCxPQUFPLENBQVA7QUFHRjs7QUFBQSw2Q0FJYztBQUNaLFFBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUE2QkUsY0FBYyxDQUFqRCxPQUFpRCxDQUFqRDtBQUNBQyxVQUFRLENBQVJBO0FBRUFDLFVBQVEsQ0FBUkE7QUFDQSxTQUFPLHFCQUEyQjtBQUNoQ0QsWUFBUSxDQUFSQTtBQUNBQyxZQUFRLENBQVJBLG1CQUZnQyxDQUloQzs7QUFDQSxRQUFJRCxRQUFRLENBQVJBLFNBQUosR0FBeUI7QUFDdkJDLGNBQVEsQ0FBUkE7QUFDQUMsZUFBUyxDQUFUQTtBQUVIO0FBVEQ7QUFZRjs7QUFBQSxNQUFNQSxTQUFTLEdBQUcsSUFBbEIsR0FBa0IsRUFBbEI7O0FBQ0EsaUNBQXdFO0FBQ3RFLFFBQU1DLEVBQUUsR0FBR0MsT0FBTyxDQUFQQSxjQUFYO0FBQ0EsTUFBSUMsUUFBUSxHQUFHSCxTQUFTLENBQVRBLElBQWYsRUFBZUEsQ0FBZjs7QUFDQSxnQkFBYztBQUNaO0FBR0Y7O0FBQUEsUUFBTUYsUUFBUSxHQUFHLElBQWpCLEdBQWlCLEVBQWpCO0FBQ0EsUUFBTUMsUUFBUSxHQUFHLHlCQUEwQkssT0FBRCxJQUFhO0FBQ3JEQSxXQUFPLENBQVBBLFFBQWlCQyxLQUFELElBQVc7QUFDekIsWUFBTUMsUUFBUSxHQUFHUixRQUFRLENBQVJBLElBQWFPLEtBQUssQ0FBbkMsTUFBaUJQLENBQWpCO0FBQ0EsWUFBTTdELFNBQVMsR0FBR29FLEtBQUssQ0FBTEEsa0JBQXdCQSxLQUFLLENBQUxBLG9CQUExQzs7QUFDQSxVQUFJQyxRQUFRLElBQVosV0FBMkI7QUFDekJBLGdCQUFRLENBQVJBLFNBQVEsQ0FBUkE7QUFFSDtBQU5ERjtBQURlLEtBQWpCLE9BQWlCLENBQWpCO0FBVUFKLFdBQVMsQ0FBVEEsUUFFR0csUUFBUSxHQUFHO0FBQUE7QUFBQTtBQUZkSDtBQUVjLEdBRmRBO0FBUUE7QUFDRCxDOzs7Ozs7Ozs7OztBQzNHRCxpQkFBaUIsbUJBQU8sQ0FBQyxxRUFBcUI7Ozs7Ozs7Ozs7OztBQ0E5QztBQUNBO0FBQ0EsbUJBQW1CLHNCQUFzQjtBQUN6Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBLDBCOzs7Ozs7Ozs7OztBQ2xCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHdDOzs7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsYUFBYSx1QkFBdUI7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSwrQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNmQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTU8sd0JBQXdCLEdBQUcsTUFBTTtBQUNuQyxRQUFNQyxVQUFVLEdBQUcsQ0FDZjtBQUFFQyxRQUFJLEVBQUUsMEJBQVI7QUFBb0NDLFFBQUksRUFBRUMsd0RBQVVBO0FBQXBELEdBRGUsRUFFZjtBQUFFRixRQUFJLEVBQUUsa0NBQVI7QUFBNENDLFFBQUksRUFBRUUscURBQU9BO0FBQXpELEdBRmUsQ0FBbkI7QUFLQSxzQkFDSTtBQUFBLDJCQUNJLHFFQUFDLHNEQUFEO0FBQU0sZUFBUyxNQUFmO0FBQUEsOEJBQ0kscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxDQUFUO0FBQUEsaUNBQ0kscUVBQUMsdUVBQUQ7QUFBYSxpQkFBSyxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBSUkscUVBQUMsMEVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKSixlQUtJLHFFQUFDLDJFQUFEO0FBQ0ksb0JBQVUsRUFBRSxJQURoQjtBQUVJLGtCQUFRLEVBQUMsY0FGYjtBQUdJLHdCQUFjLEVBQUM7QUFIbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFMSixlQVVJLHFFQUFDLGdHQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVkosZUFXSSxxRUFBQyxzRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVhKLGVBWUkscUVBQUMsa0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFaSixlQWFJLHFFQUFDLDRFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBaUJJLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLEVBQWY7QUFBbUIsVUFBRSxFQUFFLEVBQXZCO0FBQUEsZ0NBQ0kscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsQ0FBVDtBQUFBLGlDQUNJLHFFQUFDLHVFQUFEO0FBQWEsaUJBQUssRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQUlJLHFFQUFDLDJFQUFEO0FBQ0ksb0JBQVUsRUFBRSxJQURoQjtBQUVJLHdCQUFjLEVBQUUsSUFGcEI7QUFHSSxxQkFBVyxFQUFDLGNBSGhCO0FBSUksa0JBQVEsRUFBRTtBQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkosZUFVSSxxRUFBQyxrR0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZKLGVBV0kscUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFYSixlQVlJLHFFQUFDLGtFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWkosZUFhSSxxRUFBQyw0RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFqQkosZUFnQ0kscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxDQUFUO0FBQUEsaUNBQ0kscUVBQUMsdUVBQUQ7QUFBYSxpQkFBSyxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBSUkscUVBQUMsMkVBQUQ7QUFDSSxvQkFBVSxFQUFFLElBRGhCO0FBRUkscUJBQVcsRUFBRSxJQUZqQjtBQUdJLHFCQUFXLEVBQUMsaUJBSGhCO0FBSUksa0JBQVEsRUFBRTtBQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkosZUFVSSxxRUFBQywyREFBRDtBQUFBLGlDQUNJLHFFQUFDLHlHQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZKLGVBYUkscUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFiSixlQWNJLHFFQUFDLGtFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZEosZUFlSSxxRUFBQyw0RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoQ0osZUFpREkscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxDQUFUO0FBQUEsaUNBQ0kscUVBQUMsdUVBQUQ7QUFBYSxpQkFBSyxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBSUkscUVBQUMsd0VBQUQ7QUFBYyxlQUFLLEVBQUM7QUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKSixlQU1JLHFFQUFDLHFFQUFEO0FBQUEsaUNBQ0kscUVBQUMsOEZBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpESixlQTJESSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBQSxpQ0FDSSxxRUFBQyx1RUFBRDtBQUFhLGlCQUFLLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFJSSxxRUFBQywyRUFBRDtBQUNJLG9CQUFVLEVBQUUsSUFEaEI7QUFFSSxxQkFBVyxFQUFDLGFBRmhCO0FBR0ksa0JBQVEsRUFBRSxLQUhkO0FBSUksd0JBQWMsRUFBRTtBQUpwQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpKLGVBVUkscUVBQUMsMkRBQUQ7QUFBQSxpQ0FDSSxxRUFBQyxzR0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFWSixlQWFJLHFFQUFDLHNFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYkosZUFjSSxxRUFBQyxrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWRKLGVBZUkscUVBQUMsNEVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM0RKLGVBNEVJLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLEVBQWY7QUFBbUIsVUFBRSxFQUFFLEVBQXZCO0FBQUEsZ0NBQ0kscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsQ0FBVDtBQUFBLGlDQUNJLHFFQUFDLHVFQUFEO0FBQWEsaUJBQUssRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQUtJLHFFQUFDLDJFQUFEO0FBQ0ksb0JBQVUsRUFBRSxJQURoQjtBQUVJLHFCQUFXLEVBQUUsSUFGakI7QUFHSSxxQkFBVyxFQUFDLGFBSGhCO0FBSUksa0JBQVEsRUFBRTtBQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTEosZUFXSSxxRUFBQywyREFBRDtBQUFBLGlDQUNJLHFFQUFDLHNHQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVhKLGVBY0kscUVBQUMsc0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFkSixlQWVJLHFFQUFDLGtFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZkosZUFnQkkscUVBQUMsNEVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTVFSixlQThGSSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBQSxpQ0FDSSxxRUFBQyx1RUFBRDtBQUFhLGlCQUFLLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFJSSxxRUFBQywyRUFBRDtBQUNJLG9CQUFVLEVBQUUsSUFEaEI7QUFFSSxxQkFBVyxFQUFFLElBRmpCO0FBR0kscUJBQVcsRUFBQyxZQUhoQjtBQUlJLGtCQUFRLEVBQUU7QUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpKLGVBV0kscUVBQUMscUdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFYSixlQWFJLHFFQUFDLHNFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBYkosZUFjSSxxRUFBQyxrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWRKLGVBZUkscUVBQUMsNEVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBOUZKLGVBK0dJLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLEVBQWY7QUFBbUIsVUFBRSxFQUFFLEVBQXZCO0FBQTJCLGFBQUssRUFBQyxNQUFqQztBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBQSxpQ0FDSSxxRUFBQyx1RUFBRDtBQUFhLGlCQUFLLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFJSSxxRUFBQyxxREFBRDtBQUFLLGlCQUFPLEVBQUMsc0JBQWI7QUFBQSxrQ0FDSSxxRUFBQywyRUFBRDtBQUNJLHNCQUFVLEVBQUUsSUFEaEI7QUFFSSx1QkFBVyxFQUFFLElBRmpCO0FBR0ksdUJBQVcsRUFBQyxhQUhoQjtBQUlJLG9CQUFRLEVBQUU7QUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBUUkscUVBQUMsMkRBQUQ7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUFLLGdCQUFFLEVBQUUsQ0FBVDtBQUFZLGdCQUFFLEVBQUUsQ0FBaEI7QUFBbUIsZ0JBQUUsRUFBRSxDQUF2QjtBQUEwQixnQkFBRSxFQUFFLENBQTlCO0FBQUEsd0JBQ0ssQ0FDRztBQUNJQyxxQkFBSyxFQUFFLDRCQURYO0FBRUlDLHdCQUFRLEVBQ0oseUVBSFI7QUFJSUMsb0JBQUksRUFBRTtBQUpWLGVBREgsRUFPRztBQUNJRixxQkFBSyxFQUFFLHdCQURYO0FBRUlDLHdCQUFRLEVBQ0osa0VBSFI7QUFJSUMsb0JBQUksRUFBRTtBQUpWLGVBUEgsRUFhRztBQUNJRixxQkFBSyxFQUFFLFlBRFg7QUFFSUMsd0JBQVEsRUFDSiwwREFIUjtBQUlJQyxvQkFBSSxFQUFFO0FBSlYsZUFiSCxFQW1CRztBQUNJRixxQkFBSyxFQUFFLHNCQURYO0FBRUlDLHdCQUFRLEVBQ0oseUVBSFI7QUFJSUMsb0JBQUksRUFBRTtBQUpWLGVBbkJILEVBeUJHO0FBQ0lGLHFCQUFLLEVBQUUsc0JBRFg7QUFFSUMsd0JBQVEsRUFDSix5RUFIUjtBQUlJQyxvQkFBSSxFQUFFO0FBSlYsZUF6QkgsRUErQkc7QUFDSUYscUJBQUssRUFBRSx3QkFEWDtBQUVJQyx3QkFBUSxFQUNKLHlFQUhSO0FBSUlDLG9CQUFJLEVBQUU7QUFKVixlQS9CSCxFQXFDQ0MsR0FyQ0QsQ0FxQ01DLElBQUQsaUJBQ0YscUVBQUMscURBQUQ7QUFBSyxrQkFBRSxFQUFFLENBQVQ7QUFBQSx1Q0FDSSxxRUFBQyxnRUFBRDtBQUFBLHlDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksMkJBQU8sRUFBQyxNQURaO0FBRUksOEJBQVUsRUFBQyxRQUZmO0FBR0ksa0NBQWMsRUFBQyxlQUhuQjtBQUFBLDRDQUlJLHFFQUFDLHFEQUFEO0FBQUEsOENBQ0kscUVBQUMscURBQUQ7QUFDSSxnQ0FBUSxFQUFDLGFBRGI7QUFFSSxrQ0FBVSxFQUFDLGlCQUZmO0FBR0ksNkJBQUssRUFBQyxvQkFIVjtBQUFBLGtDQUlLQSxJQUFJLENBQUNKO0FBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FESixlQU9JLHFFQUFDLHFEQUFEO0FBQ0ksZ0NBQVEsRUFBQyxhQURiO0FBRUksNkJBQUssRUFBQyxvQkFGVjtBQUdJLDBCQUFFLEVBQUUsR0FIUjtBQUFBLGtDQUlLSSxJQUFJLENBQUNIO0FBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBSkosZUFrQkkscUVBQUMscURBQUQ7QUFDSSw2QkFBTyxFQUFDLE1BRFo7QUFFSSw4QkFBUSxFQUFDLE1BRmI7QUFHSSw0QkFBTSxFQUFDLE1BSFg7QUFJSSxnQ0FBVSxFQUFDLFFBSmY7QUFLSSxvQ0FBYyxFQUFDLFVBTG5CO0FBTUksOEJBQVEsRUFBQyxhQU5iO0FBT0ksZ0NBQVUsRUFBQyxpQkFQZjtBQVFJLDJCQUFLLEVBQUMsaUJBUlY7QUFTSSx3QkFBRSxFQUFFLENBQUMsQ0FUVDtBQUFBLDhDQVVJLHFFQUFDLHFEQUFEO0FBQ0ksK0JBQU8sRUFBQyxjQURaO0FBRUksNkJBQUssRUFBRSxDQUZYO0FBR0ksOEJBQU0sRUFBRSxDQUhaO0FBSUksK0JBQU8sRUFBQyxZQUpaO0FBS0ksb0NBQVksRUFBQyxLQUxqQjtBQU1JLDBCQUFFLEVBQUU7QUFOUjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQVZKLEVBaUJLRyxJQUFJLENBQUNGLElBakJWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FsQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLGlCQUFpQkUsSUFBSSxDQUFDSixLQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQXRDSDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFvRkkscUVBQUMscURBQUQ7QUFDSSxzQkFBUSxFQUFDLGFBRGI7QUFFSSx3QkFBVSxFQUFDLG1CQUZmO0FBR0kscUJBQU8sRUFBQyxNQUhaO0FBSUksNEJBQWMsRUFBQyxRQUpuQjtBQUtJLGdCQUFFLEVBQUUsQ0FMUjtBQU1JLGdCQUFFLEVBQUUsQ0FOUjtBQUFBLHFDQU9JLHFFQUFDLHNEQUFEO0FBQU0sb0JBQUksRUFBQyxHQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFwRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL0dKLGVBMk5JLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLEVBQWY7QUFBbUIsVUFBRSxFQUFFLEVBQXZCO0FBQUEsZ0NBQ0kscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsQ0FBVDtBQUFBLGlDQUNJLHFFQUFDLHVFQUFEO0FBQWEsaUJBQUssRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQUlJLHFFQUFDLHFEQUFEO0FBQUssaUJBQU8sRUFBQyxzQkFBYjtBQUFBLGtDQUNJLHFFQUFDLDJFQUFEO0FBQ0ksc0JBQVUsRUFBQyxNQURmO0FBRUksbUJBQU8sRUFBQyxVQUZaO0FBR0ksb0JBQVEsRUFBQyxjQUhiO0FBSUksMEJBQWMsRUFBQztBQUpuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBT0kscUVBQUMscUVBQUQ7QUFBWSxtQkFBTyxFQUFDLGFBQXBCO0FBQWtDLHVCQUFXLEVBQUUsS0FBL0M7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUNJLGdCQUFFLEVBQUUsQ0FEUjtBQUVJLHlCQUFXLEVBQUMsY0FGaEI7QUFHSSxvQkFBTSxFQUFDLFlBSFg7QUFJSSwwQkFBWSxFQUFDLE1BSmpCO0FBQUEscUNBS0kscUVBQUMsc0VBQUQ7QUFBWSx3QkFBUSxFQUFDLFlBQXJCO0FBQWtDLHdCQUFRLEVBQUMsTUFBM0M7QUFBQSx1Q0FDSSxxRUFBQyxxREFBRDtBQUNJLHVCQUFLLEVBQUMsY0FEVjtBQUVJLDBCQUFRLEVBQUMsYUFGYjtBQUdJLDRCQUFVLEVBQUMsbUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQWVJLHFFQUFDLHFEQUFEO0FBQUssZ0JBQUUsRUFBRSxHQUFUO0FBQUEsd0JBQ0tMLFVBQVUsQ0FBQ1EsR0FBWCxDQUFnQkMsSUFBRCxpQkFDWixxRUFBQyxxREFBRDtBQUFLLGtCQUFFLEVBQUUsQ0FBVDtBQUFBLHVDQUNJLHFFQUFDLHNEQUFEO0FBQU0sc0JBQUksRUFBQyxHQUFYO0FBQWUsMkJBQVMsRUFBQyxNQUF6QjtBQUFBLHlDQUNJLHFFQUFDLHFEQUFEO0FBQUssMkJBQU8sRUFBQyxNQUFiO0FBQW9CLDhCQUFVLEVBQUMsUUFBL0I7QUFBQSw0Q0FDSSxxRUFBQyxJQUFELENBQU0sSUFBTjtBQUNJLGlDQUFXLEVBQUMsR0FEaEI7QUFFSSwyQkFBSyxFQUFDLFFBRlY7QUFHSSwwQkFBSSxFQUFFO0FBSFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FESixlQU1JLHFFQUFDLHFEQUFEO0FBQ0ksOEJBQVEsRUFBQyxhQURiO0FBRUksMkJBQUssRUFBQyxjQUZWO0FBR0ksZ0NBQVUsRUFBQyxtQkFIZjtBQUlJLHdCQUFFLEVBQUUsR0FKUjtBQUFBLGdDQUtLQSxJQUFJLENBQUNSO0FBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosaUJBQWlCUSxJQUFJLENBQUNSLElBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkosZUFrREkscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsQ0FBVDtBQUFBLGlDQUNJLHFFQUFDLHNHQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWxESixlQXFESSxxRUFBQyxzRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXJESixlQXNESSxxRUFBQyxrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXRESixlQXVESSxxRUFBQyw0RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXZESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM05KLGVBb1JJLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLEVBQWY7QUFBbUIsVUFBRSxFQUFFLEVBQXZCO0FBQUEsZ0NBQ0kscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsQ0FBVDtBQUFBLGlDQUNJLHFFQUFDLHVFQUFEO0FBQWEsaUJBQUssRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQUlJLHFFQUFDLDJFQUFEO0FBQ0ksb0JBQVUsRUFBQyxNQURmO0FBRUksaUJBQU8sRUFBQyxVQUZaO0FBR0ksa0JBQVEsRUFBQyxtQkFIYjtBQUlJLHdCQUFjLEVBQUM7QUFKbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKSixlQVVJLHFFQUFDLHFFQUFEO0FBQVksaUJBQU8sRUFBQyxhQUFwQjtBQUFrQyxxQkFBVyxFQUFFLEtBQS9DO0FBQUEsaUNBQ0kscUVBQUMsMkdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVkosZUFhSSxxRUFBQyxzRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWJKLGVBY0kscUVBQUMsa0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFkSixlQWVJLHFFQUFDLDRFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXBSSixlQXFTSSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBQSxpQ0FDSSxxRUFBQyx1RUFBRDtBQUFhLGlCQUFLLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFJSSxxRUFBQyxxREFBRDtBQUFLLGlCQUFPLEVBQUMsc0JBQWI7QUFBQSxrQ0FDSSxxRUFBQywyRUFBRDtBQUNJLHNCQUFVLEVBQUUsSUFEaEI7QUFFSSx1QkFBVyxFQUFFLElBRmpCO0FBR0ksdUJBQVcsRUFBQyxTQUhoQjtBQUlJLG9CQUFRLEVBQUU7QUFKZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBT0kscUVBQUMsMkRBQUQ7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUFLLGdCQUFFLEVBQUUsQ0FBVDtBQUFBLHdCQUNLLENBQ0c7QUFDSUkscUJBQUssRUFBRSx3QkFEWDtBQUVJQyx3QkFBUSxFQUFFO0FBRmQsZUFESCxFQUtHO0FBQ0lELHFCQUFLLEVBQUUsc0JBRFg7QUFFSUMsd0JBQVEsRUFBRTtBQUZkLGVBTEgsRUFTRztBQUFFRCxxQkFBSyxFQUFFLGdCQUFUO0FBQTJCQyx3QkFBUSxFQUFFO0FBQXJDLGVBVEgsRUFVRztBQUFFRCxxQkFBSyxFQUFFLG1CQUFUO0FBQThCQyx3QkFBUSxFQUFFO0FBQXhDLGVBVkgsRUFXRztBQUFFRCxxQkFBSyxFQUFFLGtCQUFUO0FBQTZCQyx3QkFBUSxFQUFFO0FBQXZDLGVBWEgsRUFZRztBQUFFRCxxQkFBSyxFQUFFLGFBQVQ7QUFBd0JDLHdCQUFRLEVBQUU7QUFBbEMsZUFaSCxFQWFDRSxHQWJELENBYU1DLElBQUQsaUJBQ0YscUVBQUMscURBQUQ7QUFBSyxrQkFBRSxFQUFFLENBQVQ7QUFBQSx1Q0FDSSxxRUFBQyx1RUFBRDtBQUNJLHlCQUFPLEVBQUMsTUFEWjtBQUVJLDJCQUFTLEVBQUUsSUFGZjtBQUdJLGdDQUFjLEVBQUUsSUFIcEI7QUFBQSwwQ0FJSSxxRUFBQyxxREFBRDtBQUNJLHlCQUFLLEVBQUMsY0FEVjtBQUVJLDRCQUFRLEVBQUMsYUFGYjtBQUdJLDhCQUFVLEVBQUMsbUJBSGY7QUFBQSw4QkFJS0EsSUFBSSxDQUFDSjtBQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSkosZUFVSSxxRUFBQyxxREFBRDtBQUNJLDZCQUFTLEVBQUMsT0FEZDtBQUVJLHlCQUFLLEVBQUMsZUFGVjtBQUdJLDRCQUFRLEVBQUMsYUFIYjtBQUlJLDhCQUFVLEVBQUMsb0JBSmY7QUFBQSw4QkFLS0ksSUFBSSxDQUFDSDtBQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosaUJBQWlCRyxJQUFJLENBQUNKLEtBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBZEg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFQSixlQThDSSxxRUFBQyxrRUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTlDSixlQStDSSxxRUFBQyw0RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQS9DSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXJTSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFESjtBQWdXSCxDQXRXRDs7QUF3V2VOLHVGQUFmLEU7Ozs7Ozs7Ozs7OztBQ3JZQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSxTQUFTVyxrQkFBVCxHQUE4QjtBQUMxQixzQkFDSTtBQUFBLDJCQUNJLHFFQUFDLHlFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFESjtBQUtIOztBQUVjQSxpRkFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1DLE1BQU0sR0FBRyxDQUFDO0FBQUVDLFNBQUY7QUFBV0MsV0FBWDtBQUFzQkMsVUFBdEI7QUFBZ0NDO0FBQWhDLENBQUQsS0FBb0Q7QUFDL0QsUUFBTUMsT0FBTyxHQUFHQyw2REFBUyxFQUF6QjtBQUNBLHNCQUNJO0FBQUEsMkJBQ0kscUVBQUMsc0RBQUQ7QUFBTSxlQUFTLEVBQUVELE9BQU8sQ0FBQ0osT0FBRCxDQUF4QjtBQUFBLDZCQUNJLHFFQUFDLHNEQUFEO0FBQ0ksY0FBTSxFQUNGRyxZQUFZLGlCQUNSLHFFQUFDLDREQUFEO0FBQUEsaUNBQ0kscUVBQUMsK0NBQUQ7QUFBRyx1QkFBVyxFQUFDLEdBQWY7QUFBbUIsaUJBQUssRUFBRUY7QUFBMUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSFo7QUFBQSxrQkFRRUMsUUFBUSxJQUFJQTtBQVJkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosbUJBREo7QUFnQkgsQ0FsQkQ7O0FBb0JBSCxNQUFNLENBQUNPLFlBQVAsR0FBcUI7QUFDakJILGNBQVksRUFBRTtBQURHLENBQXJCO0FBSUFKLE1BQU0sQ0FBQ1EsU0FBUCxHQUFtQjtBQUNmUCxTQUFPLEVBQUVRLGlEQUFTLENBQUNDLEtBQVYsQ0FBZ0IsQ0FBQyxjQUFELEVBQWlCLGdCQUFqQixDQUFoQixDQURNO0FBRWZSLFdBQVMsRUFBRU8saURBQVMsQ0FBQ0MsS0FBVixDQUFnQixDQUFDLE9BQUQsRUFBVSxRQUFWLENBQWhCLENBRkk7QUFHZlAsVUFBUSxFQUFFTSxpREFBUyxDQUFDRSxJQUhMO0FBSWZQLGNBQVksRUFBRUssaURBQVMsQ0FBQ0c7QUFKVCxDQUFuQjtBQU1lWixxRUFBZixFOzs7Ozs7Ozs7Ozs7QUMxQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQSxNQUFNTSxTQUFTLEdBQUdPLG9FQUFVLENBQUVDLEtBQUQsS0FBWTtBQUNyQ0MsY0FBWSxFQUFDO0FBQ1RDLG1CQUFlLEVBQUNGLEtBQUssQ0FBQ0csT0FBTixDQUFjQyxPQUFkLENBQXNCQyxJQUQ3QjtBQUVUQyxTQUFLLEVBQUNOLEtBQUssQ0FBQ08sTUFBTixDQUFhQyxLQUZWO0FBR1RDLGFBQVMsRUFBQyxNQUhEO0FBSVRDLGdCQUFZLEVBQUM7QUFKSixHQUR3QjtBQU9yQ0MsZ0JBQWMsRUFBQztBQUNYVCxtQkFBZSxFQUFDRixLQUFLLENBQUNHLE9BQU4sQ0FBY1MsS0FBZCxDQUFvQkMsY0FEekI7QUFFWFAsU0FBSyxFQUFDTixLQUFLLENBQUNHLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQlUsS0FGakI7QUFHWEwsYUFBUyxFQUFDLE1BSEM7QUFJWEMsZ0JBQVksRUFBQztBQUpGO0FBUHNCLENBQVosQ0FBRCxDQUE1QjtBQWNlbEIsd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDZkE7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTXVCLFVBQVUsR0FBRyxDQUFDO0FBQ2hCQyxTQURnQjtBQUVoQkMsY0FGZ0I7QUFHaEJDLGFBSGdCO0FBSWhCQyxhQUpnQjtBQUtoQkMsWUFMZ0I7QUFNaEJDLFVBTmdCO0FBT2hCaEMsVUFQZ0I7QUFRaEJpQyxVQVJnQjtBQVNoQkMsY0FUZ0I7QUFVaEJDLE9BVmdCO0FBV2hCQyxVQVhnQjtBQVloQkM7QUFaZ0IsQ0FBRCxLQWFiO0FBQ0YsUUFBTW5DLE9BQU8sR0FBR0MsZ0VBQVMsRUFBekI7QUFDQSxRQUFNbUMsU0FBUyxHQUFHQywyQ0FBSSxDQUNsQnJDLE9BQU8sQ0FBQ3JHLElBRFUsRUFFbEJxRyxPQUFPLENBQUN5QixPQUFELENBRlcsRUFHbEJ6QixPQUFPLENBQUMrQixRQUFELENBSFcsRUFJbEIvQixPQUFPLENBQUNpQyxLQUFELENBSlcsRUFLbEJqQyxPQUFPLENBQUNrQyxRQUFELENBTFcsRUFNbEI7QUFDSSxLQUFDbEMsT0FBTyxDQUFDOEIsUUFBVCxHQUFvQkEsUUFEeEI7QUFFSSxLQUFDOUIsT0FBTyxDQUFDc0MsV0FBVCxHQUF1QlosWUFGM0I7QUFHSSxLQUFDMUIsT0FBTyxDQUFDdUMsTUFBVCxHQUFrQlY7QUFIdEIsR0FOa0IsQ0FBdEI7QUFhQSxzQkFDSSxxRUFBQyxzREFBRDtBQUFNLGFBQVMsRUFBRU8sU0FBakI7QUFBQSwyQkFDSSxxRUFBQyxxREFBRDtBQUFLLGVBQVMsRUFBRXBDLE9BQU8sQ0FBQ3dDLE9BQXhCO0FBQUEsaUJBQ0tMLGVBQWUsaUJBQ1oscUVBQUMscURBQUQ7QUFBSyxVQUFFLEVBQUUsQ0FBVDtBQUFBLCtCQUNJLHFFQUFDLDREQUFEO0FBQVksbUJBQVMsRUFBRW5DLE9BQU8sQ0FBQ3lDLGFBQS9CO0FBQThDLGlCQUFPLEVBQUVkLFdBQXZEO0FBQUEsaUNBQ0kscUVBQUMsdURBQUQ7QUFBVyxpQkFBSyxFQUFDLFFBQWpCO0FBQTBCLHVCQUFXLEVBQUUsQ0FBdkM7QUFBMEMsZ0JBQUksRUFBRTtBQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRlIsRUFTS0MsV0FBVyxpQkFDUixxRUFBQyxxREFBRDtBQUFLLGVBQU8sRUFBQyxNQUFiO0FBQW9CLGtCQUFVLEVBQUMsUUFBL0I7QUFBd0MsaUJBQVMsRUFBRTVCLE9BQU8sQ0FBQzBDLFFBQTNEO0FBQUEsZ0NBQ0kscUVBQUMsNERBQUQ7QUFDSSxtQkFBUyxFQUFFTCwyQ0FBSSxDQUNYckMsT0FBTyxDQUFDZ0MsWUFBRCxDQURJLEVBRVhOLFlBQVksR0FBRzFCLE9BQU8sQ0FBQzJDLFVBQVgsR0FBd0IzQyxPQUFPLENBQUM0QyxVQUZqQyxDQURuQjtBQUtJLGlCQUFPLEVBQUVqQixXQUxiO0FBQUEsa0NBTUkscUVBQUMsdURBQUQ7QUFBVyxpQkFBSyxFQUFDLFFBQWpCO0FBQTBCLGdCQUFJLEVBQUUsRUFBaEM7QUFBb0MscUJBQVMsRUFBRTNCLE9BQU8sQ0FBQzZDO0FBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTkosZUFPSSxxRUFBQyx5REFBRDtBQUNJLGlCQUFLLEVBQUMsUUFEVjtBQUVJLGdCQUFJLEVBQUUsRUFGVjtBQUdJLHFCQUFTLEVBQUU3QyxPQUFPLENBQUM4QztBQUh2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQWNJLHFFQUFDLHFEQUFEO0FBQ0ksZUFBSyxFQUNEZCxZQUFZLEtBQUssZ0JBQWpCLEdBQ00sY0FETixHQUVNLHVCQUpkO0FBTUksWUFBRSxFQUFFLENBTlI7QUFPSSxtQkFBUyxFQUFFaEMsT0FBTyxDQUFDOEMsY0FQdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVZSLEVBb0NLaEQsUUFwQ0w7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBMENILENBdEVEOztBQXdFQTBCLFVBQVUsQ0FBQ3RCLFlBQVgsR0FBMEI7QUFDdEJ1QixTQUFPLEVBQUUsT0FEYTtBQUV0QkksWUFBVSxFQUFFLEtBRlU7QUFHdEIvQixVQUFRLEVBQUUsRUFIWTtBQUl0QmlELHlCQUF1QixFQUFFLEtBSkg7QUFLdEJDLGdCQUFjLEVBQUUsS0FMTTtBQU10QnRCLGNBQVksRUFBRSxLQU5RO0FBT3RCSSxVQUFRLEVBQUUsS0FQWTtBQVF0QkYsYUFBVyxFQUFFLElBUlM7QUFTdEJHLFVBQVEsRUFBRSxNQVRZO0FBVXRCQyxjQUFZLEVBQUUsZ0JBVlE7QUFXdEJDLE9BQUssRUFBRSxJQVhlO0FBWXRCQyxVQUFRLEVBQUUsTUFaWTtBQWF0QkMsaUJBQWUsRUFBRTtBQWJLLENBQTFCO0FBZ0JBWCxVQUFVLENBQUNyQixTQUFYLEdBQXVCO0FBQ25Cc0IsU0FBTyxFQUFFckIsaURBQVMsQ0FBQ0MsS0FBVixDQUFnQixDQUFDLE9BQUQsRUFBVSxTQUFWLEVBQXFCLE1BQXJCLEVBQTZCLGFBQTdCLENBQWhCLENBRFU7QUFFbkJzQixhQUFXLEVBQUV2QixpREFBUyxDQUFDNkMsSUFGSjtBQUduQkMsaUJBQWUsRUFBRTlDLGlEQUFTLENBQUM2QyxJQUhSO0FBSW5CcEIsWUFBVSxFQUFFekIsaURBQVMsQ0FBQ0csSUFKSDtBQUtuQlQsVUFBUSxFQUFFTSxpREFBUyxDQUFDRSxJQUxEO0FBTW5CeUMseUJBQXVCLEVBQUUzQyxpREFBUyxDQUFDRyxJQU5oQjtBQU9uQnlDLGdCQUFjLEVBQUU1QyxpREFBUyxDQUFDRyxJQVBQO0FBUW5CbUIsY0FBWSxFQUFFdEIsaURBQVMsQ0FBQ0csSUFSTDtBQVNuQnVCLFVBQVEsRUFBRTFCLGlEQUFTLENBQUNHLElBVEQ7QUFVbkJxQixhQUFXLEVBQUV4QixpREFBUyxDQUFDRyxJQVZKO0FBV25Cd0IsVUFBUSxFQUFFM0IsaURBQVMsQ0FBQ0MsS0FBVixDQUFnQixDQUFDLFNBQUQsRUFBWSxTQUFaLEVBQXVCLE1BQXZCLENBQWhCLENBWFM7QUFZbkIyQixjQUFZLEVBQUU1QixpREFBUyxDQUFDQyxLQUFWLENBQWdCLENBQUMsY0FBRCxFQUFpQixnQkFBakIsQ0FBaEIsQ0FaSztBQWFuQjRCLE9BQUssRUFBRTdCLGlEQUFTLENBQUNDLEtBQVYsQ0FBZ0IsQ0FBQyxJQUFELEVBQU8sSUFBUCxDQUFoQixDQWJZO0FBY25CNkIsVUFBUSxFQUFFOUIsaURBQVMsQ0FBQ0MsS0FBVixDQUFnQixDQUFDLE1BQUQsRUFBUyxNQUFULENBQWhCLENBZFM7QUFlbkI4QixpQkFBZSxFQUFFL0IsaURBQVMsQ0FBQ0c7QUFmUixDQUF2QjtBQWtCZWlCLHlFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3RIQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU12QixTQUFTLEdBQUdPLDJFQUFVLENBQUVDLEtBQUQsS0FBWTtBQUNyQzlHLE1BQUksRUFBRTtBQUNGMkIsV0FBTyxFQUFFLGdCQURQO0FBRUZNLFlBQVEsRUFBRSxPQUZSO0FBR0ZaLFlBQVEsRUFBRSxVQUhSO0FBSUZtSSxVQUFNLEVBQUUsR0FKTjtBQUtGLEtBQUMxQyxLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCL0gsYUFBTyxFQUFFO0FBRG1CO0FBTDlCLEdBRCtCO0FBVXJDZ0ksSUFBRSxFQUFFO0FBQ0E5SCxVQUFNLEVBQUUsUUFEUjtBQUVBLEtBQUNpRixLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCN0gsWUFBTSxFQUFFO0FBRG9CO0FBRmhDLEdBVmlDO0FBZ0JyQytILElBQUUsRUFBRTtBQUNBL0gsVUFBTSxFQUFFO0FBRFIsR0FoQmlDO0FBb0JyQ3FGLFNBQU8sRUFBRTtBQUNMMkMsY0FBVSxFQUFFL0MsS0FBSyxDQUFDRyxPQUFOLENBQWNTLEtBQWQsQ0FBb0JDO0FBRDNCLEdBcEI0QjtBQXdCckNMLE9BQUssRUFBRTtBQUNIdUMsY0FBVSxFQUFFL0MsS0FBSyxDQUFDRyxPQUFOLENBQWNJLE1BQWQsQ0FBcUJDO0FBRDlCLEdBeEI4QjtBQTJCckN3QyxNQUFJLEVBQUU7QUFDRkQsY0FBVSxFQUFFL0MsS0FBSyxDQUFDTyxNQUFOLENBQWF5QztBQUR2QixHQTNCK0I7QUErQnJDQyxhQUFXLEVBQUU7QUFDVEYsY0FBVSxFQUFFLGFBREg7QUFFVHRDLGFBQVMsRUFBRSxNQUZGO0FBR1QsS0FBQ1QsS0FBSyxDQUFDMkMsV0FBTixDQUFrQkMsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBRCxHQUFnQztBQUM1QjdILFlBQU0sRUFBRTtBQURvQjtBQUh2QixHQS9Cd0I7QUF1Q3JDbUksU0FBTyxFQUFFO0FBQ0xDLGtCQUFjLEVBQUUsT0FEWDtBQUVMQyxzQkFBa0IsRUFBRSxRQUZmO0FBR0xDLG1CQUFlLEVBQUcsb0JBSGI7QUFJTCxLQUFDckQsS0FBSyxDQUFDMkMsV0FBTixDQUFrQkMsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBRCxHQUFnQztBQUM1QlMscUJBQWUsRUFBRztBQURVO0FBSjNCLEdBdkM0QjtBQWdEckNDLFNBQU8sRUFBRTtBQUNMSCxrQkFBYyxFQUFFLE9BRFg7QUFFTEMsc0JBQWtCLEVBQUUsUUFGZjtBQUdMQyxtQkFBZSxFQUFHLHVCQUhiO0FBSUwsS0FBQ3JELEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JDLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUJTLHFCQUFlLEVBQUc7QUFEVTtBQUozQixHQWhENEI7QUF3RHJDRSxNQUFJLEVBQUU7QUFDRkYsbUJBQWUsRUFBRTtBQURmLEdBeEQrQjtBQTREckN0QixTQUFPLEVBQUU7QUFDTDVHLFlBQVEsRUFBRSxPQURMO0FBRUxKLFVBQU0sRUFBRSxRQUZIO0FBR0x4QyxTQUFLLEVBQUUsTUFIRjtBQUlMNkMsYUFBUyxFQUFFLE9BSk47QUFLTCxLQUFDNEUsS0FBSyxDQUFDMkMsV0FBTixDQUFrQkMsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBRCxHQUFnQztBQUM1QnhILGVBQVMsRUFBRTtBQURpQjtBQUwzQixHQTVENEI7QUFxRXJDb0ksTUFBSSxFQUFFO0FBQ0ZwSSxhQUFTLEVBQUUsT0FEVDtBQUVGN0MsU0FBSyxFQUFFLE1BRkw7QUFHRjRDLFlBQVEsRUFBRSxPQUhSO0FBSUZILFdBQU8sRUFBRSxNQUpQO0FBS0Z5SSxjQUFVLEVBQUUsUUFMVjtBQU1GL0MsZ0JBQVksRUFBRSxHQU5aO0FBT0YsS0FBQ1YsS0FBSyxDQUFDMkMsV0FBTixDQUFrQkMsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBRCxHQUFnQztBQUM1QjdILFlBQU0sRUFBRTtBQURvQjtBQVA5QixHQXJFK0I7QUFpRnJDMkksTUFBSSxFQUFFO0FBQ0Z0SSxhQUFTLEVBQUU7QUFEVCxHQWpGK0I7QUFxRnJDMEcsUUFBTSxFQUFFO0FBQ0oxRyxhQUFTLEVBQUU7QUFEUCxHQXJGNkI7QUF5RnJDdUksZ0JBQWMsRUFBRTtBQUNaekQsbUJBQWUsRUFBRSwwQkFETDtBQUVaLGVBQVc7QUFDUEEscUJBQWUsRUFBRUYsS0FBSyxDQUFDTyxNQUFOLENBQWFDLEtBRHZCO0FBRVBvRCxhQUFPLEVBQUU7QUFGRixLQUZDO0FBTVosS0FBQzVELEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JDLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUI1SCxhQUFPLEVBQUU7QUFEbUI7QUFOcEIsR0F6RnFCO0FBbUdyQzZJLGNBQVksRUFBRTtBQUNWM0QsbUJBQWUsRUFBRUYsS0FBSyxDQUFDTyxNQUFOLENBQWFDLEtBRHBCO0FBRVYsZUFBVztBQUNQTixxQkFBZSxFQUFFRixLQUFLLENBQUNPLE1BQU4sQ0FBYUMsS0FEdkI7QUFFUG9ELGFBQU8sRUFBRTtBQUZGO0FBRkQsR0FuR3VCO0FBMkdyQ3ZCLGdCQUFjLEVBQUU7QUFDWnJILFdBQU8sRUFBRSxNQURHO0FBRVosS0FBQ2dGLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCOUksYUFBTyxFQUFFO0FBRGlCO0FBRmxCLEdBM0dxQjtBQWlIckNvSCxXQUFTLEVBQUU7QUFDUHBILFdBQU8sRUFBRSxNQURGO0FBRVAsS0FBQ2dGLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JDLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUI1SCxhQUFPLEVBQUU7QUFEbUI7QUFGekIsR0FqSDBCO0FBdUhyQ2lILFVBQVEsRUFBRTtBQUNOOEIsaUJBQWEsRUFBRSxNQURUO0FBRU4sS0FBQy9ELEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JDLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUJtQixtQkFBYSxFQUFFO0FBRGEsS0FGMUI7QUFLTixLQUFDL0QsS0FBSyxDQUFDMkMsV0FBTixDQUFrQkMsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBRCxHQUFnQztBQUM1QjVILGFBQU8sRUFBRTtBQURtQjtBQUwxQixHQXZIMkI7QUFnSXJDZ0gsZUFBYSxFQUFDO0FBQ1ZoSCxXQUFPLEVBQUMsTUFERTtBQUVWLEtBQUNnRixLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCMUMscUJBQWUsRUFBRUYsS0FBSyxDQUFDTyxNQUFOLENBQWFDLEtBREY7QUFFNUJ4RixhQUFPLEVBQUMsT0FGb0I7QUFHNUIsaUJBQVc7QUFDUGtGLHVCQUFlLEVBQUVGLEtBQUssQ0FBQ08sTUFBTixDQUFhQyxLQUR2QjtBQUVQb0QsZUFBTyxFQUFFO0FBRkY7QUFIaUI7QUFGdEI7QUFoSXVCLENBQVosQ0FBRCxDQUE1QjtBQThJZXBFLHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ2hKQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNd0UsZ0JBQWdCLEdBQUcsTUFBTTtBQUMzQixRQUFNekUsT0FBTyxHQUFHQyx1RUFBUyxFQUF6QjtBQUNBLFFBQU0sQ0FBQ3lFLEtBQUQsRUFBUUMsUUFBUixJQUFvQkMsNENBQUssQ0FBQ0MsUUFBTixDQUFlLENBQWYsQ0FBMUI7O0FBRUEsUUFBTUMsWUFBWSxHQUFHLENBQUNDLEtBQUQsRUFBUUMsUUFBUixLQUFxQjtBQUN0Q0wsWUFBUSxDQUFDSyxRQUFELENBQVI7QUFDSCxHQUZEOztBQUdBLFFBQU1DLFlBQVksR0FBRyxDQUNqQjtBQUFFaEcsUUFBSSxFQUFFLGlCQUFSO0FBQTJCQyxRQUFJLEVBQUVnRyxrREFBakM7QUFBdUNDLGFBQVMsRUFBRUMsMERBQVlBO0FBQTlELEdBRGlCLEVBRWpCO0FBQUVuRyxRQUFJLEVBQUUsbUJBQVI7QUFBNkJDLFFBQUksRUFBRW1HLHNEQUFuQztBQUE2Q0YsYUFBUyxFQUFFQywwREFBWUE7QUFBcEUsR0FGaUIsRUFHakI7QUFBRW5HLFFBQUksRUFBRSxpQkFBUjtBQUEyQkMsUUFBSSxFQUFFb0csa0RBQWpDO0FBQXVDSCxhQUFTLEVBQUVDLDBEQUFZQTtBQUE5RCxHQUhpQixFQUlqQjtBQUFFbkcsUUFBSSxFQUFFLHVCQUFSO0FBQWlDQyxRQUFJLEVBQUVFLHFEQUF2QztBQUFnRCtGLGFBQVMsRUFBRUMsMERBQVlBO0FBQXZFLEdBSmlCLENBQXJCO0FBTUEsUUFBTUcsZUFBZSxHQUFHLENBQ3BCO0FBQUVDLFNBQUssRUFBRSxNQUFUO0FBQWlCQyxRQUFJLEVBQUU7QUFBdkIsR0FEb0IsRUFFcEI7QUFBRUQsU0FBSyxFQUFFLFVBQVQ7QUFBcUJDLFFBQUksRUFBRTtBQUEzQixHQUZvQixFQUdwQjtBQUFFRCxTQUFLLEVBQUUsY0FBVDtBQUF5QkMsUUFBSSxFQUFFO0FBQS9CLEdBSG9CLEVBSXBCO0FBQUVELFNBQUssRUFBRSxlQUFUO0FBQTBCQyxRQUFJLEVBQUU7QUFBaEMsR0FKb0IsRUFLcEI7QUFBRUQsU0FBSyxFQUFFLEVBQVQ7QUFBYUMsUUFBSSxFQUFFO0FBQW5CLEdBTG9CLEVBTXBCO0FBQUVELFNBQUssRUFBRSxFQUFUO0FBQWFDLFFBQUksRUFBRTtBQUFuQixHQU5vQixDQUF4QjtBQVFBLFFBQU1DLHVCQUF1QixHQUFHLENBQzVCO0FBQUVGLFNBQUssRUFBRSxnQkFBVDtBQUEyQkMsUUFBSSxFQUFFO0FBQWpDLEdBRDRCLEVBRTVCO0FBQUVELFNBQUssRUFBRSxZQUFUO0FBQXVCQyxRQUFJLEVBQUU7QUFBN0IsR0FGNEIsRUFHNUI7QUFDSUQsU0FBSyxFQUFFLFNBRFg7QUFFSUMsUUFBSSxlQUNBLHFFQUFDLHFEQUFEO0FBQUEsOEJBQ0kscUVBQUMscURBQUQ7QUFBSyxVQUFFLEVBQUUsQ0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQUVJLHFFQUFDLHFEQUFEO0FBQUssVUFBRSxFQUFFLENBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkosZUFHSSxxRUFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIUixHQUg0QixFQWE1QjtBQUFFRCxTQUFLLEVBQUUsc0JBQVQ7QUFBaUNDLFFBQUksRUFBRTtBQUF2QyxHQWI0QixDQUFoQzs7QUFnQkEsV0FBU0UsU0FBVCxDQUFtQkMsS0FBbkIsRUFBMEI7QUFDdEIsV0FBTztBQUNIbkgsUUFBRSxFQUFHLGdCQUFlbUgsS0FBTSxFQUR2QjtBQUVILHVCQUFrQixxQkFBb0JBLEtBQU07QUFGekMsS0FBUDtBQUlIOztBQUNELFdBQVNDLFFBQVQsQ0FBa0JDLEtBQWxCLEVBQXlCO0FBQ3JCLFVBQU07QUFBRWhHLGNBQUY7QUFBWTRFLFdBQVo7QUFBbUJrQjtBQUFuQixRQUF1Q0UsS0FBN0M7QUFBQSxVQUFtQ0MsS0FBbkMsNEJBQTZDRCxLQUE3Qzs7QUFFQSx3QkFDSSxxRUFBQyxxREFBRDtBQUNJLFdBQUssRUFBQyxNQURWO0FBRUksY0FBUSxFQUFDLE9BRmI7QUFHSSxVQUFJLEVBQUMsVUFIVDtBQUlJLFlBQU0sRUFBRXBCLEtBQUssS0FBS2tCLEtBSnRCO0FBS0ksUUFBRSxFQUFHLHFCQUFvQkEsS0FBTSxFQUxuQztBQU1JLHlCQUFrQixnQkFBZUEsS0FBTSxFQU4zQztBQU9JLGVBQVMsRUFBRTVGLE9BQU8sQ0FBQ2dHO0FBUHZCLE9BUVFELEtBUlI7QUFBQSxnQkFTS3JCLEtBQUssS0FBS2tCLEtBQVYsaUJBQ0cscUVBQUMscUVBQUQ7QUFBWSxtQkFBVyxFQUFFLEtBQXpCO0FBQUEsK0JBQ0kscUVBQUMscURBQUQ7QUFBQSxvQkFBTTlGO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFWUjtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREo7QUFpQkg7O0FBQ0Qsc0JBQ0kscUVBQUMscURBQUQ7QUFBQSw0QkFDSSxxRUFBQyxxREFBRDtBQUFLLGFBQU8sRUFBQyxNQUFiO0FBQW9CLGVBQVMsRUFBRUUsT0FBTyxDQUFDaUcsT0FBdkM7QUFBZ0QsUUFBRSxFQUFFLEVBQXBEO0FBQUEsNkJBQ0kscUVBQUMsMkRBQUQ7QUFBQSwrQkFDSSxxRUFBQyxxREFBRDtBQUFLLGlCQUFPLEVBQUMsTUFBYjtBQUFvQixZQUFFLEVBQUUsRUFBeEI7QUFBQSxrQ0FDSSxxRUFBQyxxREFBRDtBQUFBLG9DQUNJLHFFQUFDLHFEQUFEO0FBQ0ksbUJBQUssRUFBQyxlQURWO0FBRUksc0JBQVEsRUFBQyxhQUZiO0FBR0ksd0JBQVUsRUFBQyxpQkFIZjtBQUlJLHVCQUFTLEVBQUMsT0FKZDtBQUtJLHNCQUFRLEVBQUMsVUFMYjtBQU1JLGlCQUFHLEVBQUMsT0FOUjtBQU9JLGdCQUFFLEVBQUUsQ0FQUjtBQUFBLHNDQVFJLHFFQUFDLHFEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVJKLG9CQVFvQixxRUFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFScEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBV0kscUVBQUMsNkRBQUQ7QUFDSSx5QkFBVyxFQUFDLFVBRGhCO0FBRUkscUJBQU8sRUFBQyxZQUZaO0FBR0ksbUJBQUssRUFBRXZCLEtBSFg7QUFJSSxzQkFBUSxFQUFFSSxZQUpkO0FBS0ksNEJBQVcsdUJBTGY7QUFNSSx1QkFBUyxFQUFFOUUsT0FBTyxDQUFDa0csSUFOdkI7QUFBQSx3QkFPS2pCLFlBQVksQ0FBQ3pGLEdBQWIsQ0FBa0JDLElBQUQsaUJBQ2QscUVBQUMsNERBQUQ7QUFFSSxxQkFBSyxlQUNELHFFQUFDLHFEQUFEO0FBQ0kseUJBQU8sRUFBQyxNQURaO0FBRUksNEJBQVUsRUFBQyxRQUZmO0FBR0ksZ0NBQWMsRUFBQyxlQUhuQjtBQUlJLDJCQUFTLEVBQUVPLE9BQU8sQ0FBQ21HLFNBSnZCO0FBQUEseUNBS0kscUVBQUMscURBQUQ7QUFBSywyQkFBTyxFQUFDLE1BQWI7QUFBb0IsOEJBQVUsRUFBQyxRQUEvQjtBQUFBLDRDQUNJLHFFQUFDLHFEQUFEO0FBQUssNkJBQU8sRUFBQyxNQUFiO0FBQW9CLGdDQUFVLEVBQUMsUUFBL0I7QUFBQSw4Q0FDSSxxRUFBQyxxREFBRDtBQUNJLDBCQUFFLEVBQUUsQ0FEUjtBQUVJLDZCQUFLLEVBQUMsY0FGVjtBQUdJLGdDQUFRLEVBQUMsYUFIYjtBQUlJLCtCQUFPLEVBQUMsTUFKWjtBQUtJLGtDQUFVLEVBQUMsUUFMZjtBQU1JLGtDQUFVLEVBQUMsbUJBTmY7QUFBQSwrQ0FPSSxxRUFBQyxJQUFELENBQU0sSUFBTjtBQUFXLCtCQUFLLEVBQUMsUUFBakI7QUFBMEIsOEJBQUksRUFBRTtBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FESixlQVdJLHFFQUFDLHFEQUFEO0FBQ0ksMEJBQUUsRUFBRSxDQURSO0FBRUksZ0NBQVEsRUFBQyxPQUZiO0FBR0ksNkJBQUssRUFBQyxjQUhWO0FBSUksZ0NBQVEsRUFBQyxhQUpiO0FBS0ksa0NBQVUsRUFBQyxtQkFMZjtBQU1JLGtDQUFVLEVBQUMsUUFOZjtBQUFBLGtDQU9LMUcsSUFBSSxDQUFDUjtBQVBWO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURKLGVBc0JJLHFFQUFDLHFEQUFEO0FBQUssNkJBQU8sRUFBQyxNQUFiO0FBQW9CLCtCQUFTLEVBQUMsT0FBOUI7QUFBQSw2Q0FDSSxxRUFBQyxJQUFELENBQU0sU0FBTjtBQUFnQiw2QkFBSyxFQUFDLFFBQXRCO0FBQStCLDRCQUFJLEVBQUU7QUFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBdEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFIUixpQkFvQ1EwRyxTQUFTLENBQUMsQ0FBRCxDQXBDakIsR0FDU2xHLElBQUksQ0FBQ1IsSUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURIO0FBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosZUE2REkscUVBQUMscURBQUQ7QUFBSyxpQkFBSyxFQUFDLE1BQVg7QUFBQSxvQ0FDSSxxRUFBQyxRQUFEO0FBQVUsbUJBQUssRUFBRXlGLEtBQWpCO0FBQXdCLG1CQUFLLEVBQUUsQ0FBL0I7QUFBQSxxQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHVCQUFPLEVBQUMsTUFBYjtBQUFvQix3QkFBUSxFQUFDLE9BQTdCO0FBQUEsd0NBQ0kscUVBQUMscURBQUQ7QUFDSSx1QkFBSyxFQUFDLGVBRFY7QUFFSSwwQkFBUSxFQUFDLGFBRmI7QUFHSSw0QkFBVSxFQUFDLGlCQUhmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKLGVBT0kscUVBQUMscURBQUQ7QUFBQSw0QkFDS2EsZUFBZSxDQUFDL0YsR0FBaEIsQ0FBcUJDLElBQUQsaUJBQ2pCLHFFQUFDLHFEQUFEO0FBQ0ksMkJBQU8sRUFBQyxNQURaO0FBRUksOEJBQVUsRUFBQyxRQUZmO0FBR0ksa0NBQWMsRUFBQyxlQUhuQjtBQUlJLHNCQUFFLEVBQUUsQ0FKUjtBQUtJLHNCQUFFLEVBQUUsQ0FMUjtBQU1JLDZCQUFTLEVBQUMsTUFOZDtBQU9JLDZCQUFTLEVBQUVPLE9BQU8sQ0FBQ21HLFNBUHZCO0FBQUEsMkNBU0kscUVBQUMsc0RBQUQ7QUFDSSwwQkFBSSxFQUFDLEdBRFQ7QUFFSSwrQkFBUyxFQUFDLE1BRmQ7QUFHSSwrQkFBUyxFQUFFbkcsT0FBTyxDQUFDb0csYUFIdkI7QUFBQSw2Q0FJSSxxRUFBQyxxREFBRDtBQUFLLCtCQUFPLEVBQUMsTUFBYjtBQUFvQixrQ0FBVSxFQUFDLFFBQS9CO0FBQUEsZ0RBQ0kscUVBQUMscURBQUQ7QUFBSyxpQ0FBTyxFQUFDLE1BQWI7QUFBb0IsdUNBQWEsRUFBQyxRQUFsQztBQUFBLGtEQUNJLHFFQUFDLHFEQUFEO0FBQ0ksaUNBQUssRUFBQyxvQkFEVjtBQUVJLG9DQUFRLEVBQUMsZUFGYjtBQUFBLHNDQUdLM0csSUFBSSxDQUFDK0Y7QUFIVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVDQURKLGVBT0kscUVBQUMscURBQUQ7QUFDSSw4QkFBRSxFQUFFLENBRFI7QUFFSSxpQ0FBSyxFQUFDLGVBRlY7QUFHSSxvQ0FBUSxFQUFDLGFBSGI7QUFBQSxzQ0FJSy9GLElBQUksQ0FBQ2dHO0FBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBREosZUFlSSxxRUFBQyxxREFBRDtBQUFLLGlDQUFPLEVBQUMsTUFBYjtBQUFvQixvQ0FBVSxFQUFDLE1BQS9CO0FBQUEsaURBQ0kscUVBQUMsMERBQUQ7QUFDSSxpQ0FBSyxFQUFDLFFBRFY7QUFFSSxnQ0FBSSxFQUFFO0FBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVRKLHFCQVFTaEcsSUFSVDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURIO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFQSixlQWdESSxxRUFBQyxxREFBRDtBQUNJLHVCQUFLLEVBQUMsZUFEVjtBQUVJLDBCQUFRLEVBQUMsYUFGYjtBQUdJLDRCQUFVLEVBQUMsaUJBSGY7QUFJSSxvQkFBRSxFQUFFLENBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBaERKLGVBdURJLHFFQUFDLHFEQUFEO0FBQUssb0JBQUUsRUFBRSxDQUFUO0FBQUEsNEJBQ0tpRyx1QkFBdUIsQ0FBQ2xHLEdBQXhCLENBQTZCQyxJQUFELGlCQUN6QixxRUFBQyxxREFBRDtBQUNJLDJCQUFPLEVBQUMsTUFEWjtBQUVJLDhCQUFVLEVBQUMsUUFGZjtBQUdJLGtDQUFjLEVBQUMsZUFIbkI7QUFJSSxzQkFBRSxFQUFFLENBSlI7QUFLSSxzQkFBRSxFQUFFLENBTFI7QUFNSSw2QkFBUyxFQUFDLE1BTmQ7QUFPSSw2QkFBUyxFQUFFTyxPQUFPLENBQUNtRyxTQVB2QjtBQUFBLDJDQVNJLHFFQUFDLHNEQUFEO0FBQ0ksMEJBQUksRUFBQyxHQURUO0FBRUksK0JBQVMsRUFBQyxNQUZkO0FBR0ksK0JBQVMsRUFBRW5HLE9BQU8sQ0FBQ29HLGFBSHZCO0FBQUEsNkNBSUkscUVBQUMscURBQUQ7QUFBSywrQkFBTyxFQUFDLE1BQWI7QUFBb0Isa0NBQVUsRUFBQyxRQUEvQjtBQUFBLGdEQUNJLHFFQUFDLHFEQUFEO0FBQUssaUNBQU8sRUFBQyxNQUFiO0FBQW9CLHVDQUFhLEVBQUMsUUFBbEM7QUFBQSxrREFDSSxxRUFBQyxxREFBRDtBQUNJLGlDQUFLLEVBQUMsb0JBRFY7QUFFSSxvQ0FBUSxFQUFDLGVBRmI7QUFBQSxzQ0FHSzNHLElBQUksQ0FBQytGO0FBSFY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1Q0FESixlQU9JLHFFQUFDLHFEQUFEO0FBQ0ksOEJBQUUsRUFBRSxDQURSO0FBRUksaUNBQUssRUFBQyxlQUZWO0FBR0ksb0NBQVEsRUFBQyxhQUhiO0FBQUEsc0NBSUsvRixJQUFJLENBQUNnRztBQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUNBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQURKLGVBZUkscUVBQUMscURBQUQ7QUFBSyxpQ0FBTyxFQUFDLE1BQWI7QUFBb0Isb0NBQVUsRUFBQyxNQUEvQjtBQUFBLGlEQUNJLHFFQUFDLDBEQUFEO0FBQ0ksaUNBQUssRUFBQyxRQURWO0FBRUksZ0NBQUksRUFBRTtBQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFUSixxQkFRU2hHLElBUlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFESDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBdkRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFvR0kscUVBQUMsUUFBRDtBQUFVLG1CQUFLLEVBQUVpRixLQUFqQjtBQUF3QixtQkFBSyxFQUFFLENBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQXBHSixlQXVHSSxxRUFBQyxRQUFEO0FBQVUsbUJBQUssRUFBRUEsS0FBakI7QUFBd0IsbUJBQUssRUFBRSxDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkF2R0osZUEwR0kscUVBQUMsUUFBRDtBQUFVLG1CQUFLLEVBQUVBLEtBQWpCO0FBQXdCLG1CQUFLLEVBQUUsQ0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBMUdKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE3REo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFpTEkscUVBQUMscURBQUQ7QUFBSyxZQUFNLEVBQUMsYUFBWjtBQUEwQixlQUFTLEVBQUUxRSxPQUFPLENBQUNxRyxVQUE3QztBQUFBLGdCQUNLcEIsWUFBWSxDQUFDekYsR0FBYixDQUFrQkMsSUFBRCxpQkFDZCxxRUFBQyxxREFBRDtBQUNJLGVBQU8sRUFBQyxNQURaO0FBRUksa0JBQVUsRUFBQyxRQUZmO0FBR0ksc0JBQWMsRUFBQyxlQUhuQjtBQUlJLFVBQUUsRUFBRSxDQUpSO0FBS0ksVUFBRSxFQUFFLENBTFI7QUFNSSxpQkFBUyxFQUFFTyxPQUFPLENBQUNtRyxTQU52QjtBQUFBLCtCQVFJLHFFQUFDLHNEQUFEO0FBQU0sY0FBSSxFQUFDLEdBQVg7QUFBZSxtQkFBUyxFQUFDLE1BQXpCO0FBQWdDLG1CQUFTLEVBQUVuRyxPQUFPLENBQUNvRyxhQUFuRDtBQUFBLGlDQUNJLHFFQUFDLHFEQUFEO0FBQUssbUJBQU8sRUFBQyxNQUFiO0FBQW9CLHNCQUFVLEVBQUMsUUFBL0I7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHFCQUFPLEVBQUMsTUFBYjtBQUFvQix3QkFBVSxFQUFDLFFBQS9CO0FBQUEsc0NBQ0kscUVBQUMscURBQUQ7QUFDSSxrQkFBRSxFQUFFLENBRFI7QUFFSSxxQkFBSyxFQUFDLGVBRlY7QUFHSSx3QkFBUSxFQUFDLGFBSGI7QUFJSSx1QkFBTyxFQUFDLE1BSlo7QUFLSSwwQkFBVSxFQUFDLFFBTGY7QUFNSSwwQkFBVSxFQUFDLG1CQU5mO0FBQUEsdUNBT0kscUVBQUMsSUFBRCxDQUFNLElBQU47QUFBVyx1QkFBSyxFQUFDLFFBQWpCO0FBQTBCLHNCQUFJLEVBQUU7QUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFXSSxxRUFBQyxxREFBRDtBQUNJLGtCQUFFLEVBQUUsQ0FEUjtBQUVJLHdCQUFRLEVBQUMsT0FGYjtBQUdJLHFCQUFLLEVBQUMsZUFIVjtBQUlJLHdCQUFRLEVBQUMsYUFKYjtBQUtJLDBCQUFVLEVBQUMsbUJBTGY7QUFBQSwwQkFNSzNHLElBQUksQ0FBQ1I7QUFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQXFCSSxxRUFBQyxxREFBRDtBQUFLLHFCQUFPLEVBQUMsTUFBYjtBQUFvQix3QkFBVSxFQUFDLE1BQS9CO0FBQUEscUNBQ0kscUVBQUMsMERBQUQ7QUFBYyxxQkFBSyxFQUFDLFFBQXBCO0FBQTZCLG9CQUFJLEVBQUU7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFSSixTQU9TUSxJQVBUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWpMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQTROSCxDQTVSRDs7QUE2UkFnRixnQkFBZ0IsQ0FBQ3RFLFNBQWpCLEdBQTZCO0FBQ3pCTCxVQUFRLEVBQUVNLGlEQUFTLENBQUNrRyxHQURLO0FBRXpCNUIsT0FBSyxFQUFFdEUsaURBQVMsQ0FBQ21HLE1BRlE7QUFHekJYLE9BQUssRUFBRXhGLGlEQUFTLENBQUNtRztBQUhRLENBQTdCO0FBS2U5QiwrRUFBZixFOzs7Ozs7Ozs7Ozs7QUMvU0E7QUFBQTtBQUFBO0FBQUE7QUFFQSxNQUFNeEUsU0FBUyxHQUFHTywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckMwRixXQUFTLEVBQUU7QUFDUCwwQkFBc0I7QUFDbEJLLGtCQUFZLEVBQUcsYUFBWS9GLEtBQUssQ0FBQ08sTUFBTixDQUFheUMsSUFBSztBQUQzQjtBQURmLEdBRDBCO0FBTXJDZ0QsWUFBVSxFQUFFO0FBQ1JuTCxXQUFPLEVBQUUsQ0FERDtBQUVSTixZQUFRLEVBQUUsVUFGRjtBQUdSbUksVUFBTSxFQUFFO0FBSEEsR0FOeUI7QUFXckNpRCxlQUFhLEVBQUU7QUFDWHBOLFNBQUssRUFBRTtBQURJLEdBWHNCO0FBY3JDME4sV0FBUyxFQUFFO0FBQ1AsS0FBQ2pHLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JDLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUJySSxjQUFRLEVBQUUsVUFEa0I7QUFFNUJHLFlBQU0sRUFBRSxHQUZvQjtBQUc1QkQsVUFBSSxFQUFFLEdBSHNCO0FBSTVCRSxXQUFLLEVBQUU7QUFKcUI7QUFEekIsR0FkMEI7QUFzQnJDNEssWUFBVSxFQUFFO0FBQ1IsZUFBVztBQUNQbkssZUFBUyxFQUFFLE9BREo7QUFFUDJJLG1CQUFhLEVBQUU7QUFGUjtBQURILEdBdEJ5QjtBQTRCckM2QixZQUFVLEVBQUU7QUFDUixLQUFDNUYsS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI5SSxhQUFPLEVBQUU7QUFEaUI7QUFEdEIsR0E1QnlCO0FBaUNyQ3dLLFNBQU8sRUFBRTtBQUNMLEtBQUN4RixLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjlJLGFBQU8sRUFBRTtBQURpQjtBQUR6QjtBQWpDNEIsQ0FBWixDQUFELENBQTVCO0FBd0Nld0Usd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDMUNBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNMEcsdUJBQXVCLEdBQUcsTUFBTTtBQUNsQyxRQUFNM0csT0FBTyxHQUFHQyw4RUFBUyxFQUF6QjtBQUNBLFFBQU1nRixZQUFZLEdBQUcsQ0FDakI7QUFBRU8sU0FBSyxFQUFFLE1BQVQ7QUFBaUJDLFFBQUksRUFBRTtBQUF2QixHQURpQixFQUVqQjtBQUFFRCxTQUFLLEVBQUUsVUFBVDtBQUFxQkMsUUFBSSxFQUFFO0FBQTNCLEdBRmlCLEVBR2pCO0FBQUVELFNBQUssRUFBRSxjQUFUO0FBQXlCQyxRQUFJLEVBQUU7QUFBL0IsR0FIaUIsRUFJakI7QUFBRUQsU0FBSyxFQUFFLGVBQVQ7QUFBMEJDLFFBQUksRUFBRTtBQUFoQyxHQUppQixFQUtqQjtBQUFFRCxTQUFLLEVBQUUsRUFBVDtBQUFhQyxRQUFJLEVBQUU7QUFBbkIsR0FMaUIsRUFNakI7QUFBRUQsU0FBSyxFQUFFLEVBQVQ7QUFBYUMsUUFBSSxFQUFFO0FBQW5CLEdBTmlCLENBQXJCO0FBUUEsUUFBTUMsdUJBQXVCLEdBQUcsQ0FDNUI7QUFBRUYsU0FBSyxFQUFFLGdCQUFUO0FBQTJCQyxRQUFJLEVBQUU7QUFBakMsR0FENEIsRUFFNUI7QUFBRUQsU0FBSyxFQUFFLFlBQVQ7QUFBdUJDLFFBQUksRUFBRTtBQUE3QixHQUY0QixFQUc1QjtBQUNJRCxTQUFLLEVBQUUsU0FEWDtBQUVJQyxRQUFJLGVBQ0EscUVBQUMscURBQUQ7QUFBQSw4QkFDSSxxRUFBQyxxREFBRDtBQUFLLFVBQUUsRUFBRSxDQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBRUkscUVBQUMscURBQUQ7QUFBSyxVQUFFLEVBQUUsQ0FBVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGSixlQUdJLHFFQUFDLHFEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLEdBSDRCLEVBYTVCO0FBQUVELFNBQUssRUFBRSxzQkFBVDtBQUFpQ0MsUUFBSSxFQUFFO0FBQXZDLEdBYjRCLENBQWhDO0FBZUEsc0JBQ0kscUVBQUMscURBQUQ7QUFBQSwyQkFDSSxxRUFBQyxxREFBRDtBQUFLLGFBQU8sRUFBQyxVQUFiO0FBQUEsOEJBQ0kscUVBQUMscURBQUQ7QUFBSyxhQUFLLEVBQUMsZUFBWDtBQUEyQixnQkFBUSxFQUFDLGFBQXBDO0FBQWtELGtCQUFVLEVBQUMsaUJBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBSUkscUVBQUMscURBQUQ7QUFBQSxrQkFDS1IsWUFBWSxDQUFDekYsR0FBYixDQUFrQkMsSUFBRCxpQkFDZCxxRUFBQyxxREFBRDtBQUNJLGlCQUFPLEVBQUMsTUFEWjtBQUVJLG9CQUFVLEVBQUMsUUFGZjtBQUdJLHdCQUFjLEVBQUMsZUFIbkI7QUFJSSxZQUFFLEVBQUUsQ0FKUjtBQUtJLFlBQUUsRUFBRSxDQUxSO0FBTUksbUJBQVMsRUFBQyxNQU5kO0FBT0ksbUJBQVMsRUFBRU8sT0FBTyxDQUFDbUcsU0FQdkI7QUFBQSxpQ0FTSSxxRUFBQyxzREFBRDtBQUFNLGdCQUFJLEVBQUMsR0FBWDtBQUFlLHFCQUFTLEVBQUMsTUFBekI7QUFBZ0MscUJBQVMsRUFBRW5HLE9BQU8sQ0FBQ29HLGFBQW5EO0FBQUEsbUNBQ0kscUVBQUMscURBQUQ7QUFBSyxxQkFBTyxFQUFDLE1BQWI7QUFBb0Isd0JBQVUsRUFBQyxRQUEvQjtBQUFBLHNDQUNJLHFFQUFDLHFEQUFEO0FBQUssdUJBQU8sRUFBQyxNQUFiO0FBQW9CLDZCQUFhLEVBQUMsUUFBbEM7QUFBQSx3Q0FDSSxxRUFBQyxxREFBRDtBQUFLLHVCQUFLLEVBQUMsb0JBQVg7QUFBZ0MsMEJBQVEsRUFBQyxlQUF6QztBQUFBLDRCQUNLM0csSUFBSSxDQUFDK0Y7QUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKLGVBS0kscUVBQUMscURBQUQ7QUFBSyxvQkFBRSxFQUFFLENBQVQ7QUFBWSx1QkFBSyxFQUFDLGVBQWxCO0FBQWtDLDBCQUFRLEVBQUMsYUFBM0M7QUFBQSw0QkFDSy9GLElBQUksQ0FBQ2dHO0FBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFVSSxxRUFBQyxxREFBRDtBQUFLLHVCQUFPLEVBQUMsTUFBYjtBQUFvQiwwQkFBVSxFQUFDLE1BQS9CO0FBQUEsdUNBQ0kscUVBQUMsMERBQUQ7QUFBYyx1QkFBSyxFQUFDLFFBQXBCO0FBQTZCLHNCQUFJLEVBQUU7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVRKLFdBUVNoRyxJQVJUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpKLGVBa0NJLHFFQUFDLHFEQUFEO0FBQ0ksYUFBSyxFQUFDLGVBRFY7QUFFSSxnQkFBUSxFQUFDLGFBRmI7QUFHSSxrQkFBVSxFQUFDLGlCQUhmO0FBSUksVUFBRSxFQUFFLENBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbENKLGVBeUNJLHFFQUFDLHFEQUFEO0FBQUssVUFBRSxFQUFFLENBQVQ7QUFBQSxrQkFDS2lHLHVCQUF1QixDQUFDbEcsR0FBeEIsQ0FBNkJDLElBQUQsaUJBQ3pCLHFFQUFDLHFEQUFEO0FBQ0ksaUJBQU8sRUFBQyxNQURaO0FBRUksb0JBQVUsRUFBQyxRQUZmO0FBR0ksd0JBQWMsRUFBQyxlQUhuQjtBQUlJLFlBQUUsRUFBRSxDQUpSO0FBS0ksWUFBRSxFQUFFLENBTFI7QUFNSSxtQkFBUyxFQUFDLE1BTmQ7QUFPSSxtQkFBUyxFQUFFTyxPQUFPLENBQUNtRyxTQVB2QjtBQUFBLGlDQVNJLHFFQUFDLHNEQUFEO0FBQU0sZ0JBQUksRUFBQyxHQUFYO0FBQWUscUJBQVMsRUFBQyxNQUF6QjtBQUFnQyxxQkFBUyxFQUFFbkcsT0FBTyxDQUFDb0csYUFBbkQ7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHFCQUFPLEVBQUMsTUFBYjtBQUFvQix3QkFBVSxFQUFDLFFBQS9CO0FBQUEsc0NBQ0kscUVBQUMscURBQUQ7QUFBSyx1QkFBTyxFQUFDLE1BQWI7QUFBb0IsNkJBQWEsRUFBQyxRQUFsQztBQUFBLHdDQUNJLHFFQUFDLHFEQUFEO0FBQUssdUJBQUssRUFBQyxvQkFBWDtBQUFnQywwQkFBUSxFQUFDLGVBQXpDO0FBQUEsNEJBQ0szRyxJQUFJLENBQUMrRjtBQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUFLSSxxRUFBQyxxREFBRDtBQUFLLG9CQUFFLEVBQUUsQ0FBVDtBQUFZLHVCQUFLLEVBQUMsZUFBbEI7QUFBa0MsMEJBQVEsRUFBQyxhQUEzQztBQUFBLDRCQUNLL0YsSUFBSSxDQUFDZ0c7QUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESixlQVVJLHFFQUFDLHFEQUFEO0FBQUssdUJBQU8sRUFBQyxNQUFiO0FBQW9CLDBCQUFVLEVBQUMsTUFBL0I7QUFBQSx1Q0FDSSxxRUFBQywwREFBRDtBQUFjLHVCQUFLLEVBQUMsUUFBcEI7QUFBNkIsc0JBQUksRUFBRTtBQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVEosV0FRU2hHLElBUlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQTRFSCxDQXJHRDs7QUF1R2VrSCxzRkFBZixFOzs7Ozs7Ozs7Ozs7QUNoSEE7QUFBQTtBQUFBO0FBQUE7QUFFQSxNQUFNMUcsU0FBUyxHQUFHTywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckMwRixXQUFTLEVBQUU7QUFDUEssZ0JBQVksRUFBRyxhQUFZL0YsS0FBSyxDQUFDTyxNQUFOLENBQWF5QyxJQUFLO0FBRHRDLEdBRDBCO0FBSXJDMkMsZUFBYSxFQUFFO0FBQ1hwTixTQUFLLEVBQUU7QUFESTtBQUpzQixDQUFaLENBQUQsQ0FBNUI7QUFTZWlILHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ1hBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU0yRyxrQkFBa0IsR0FBRyxNQUFNO0FBQzdCLHNCQUNJLHFFQUFDLHFEQUFEO0FBQUEsNEJBQ0kscUVBQUMscURBQUQ7QUFBSyxhQUFPLEVBQUMsc0JBQWI7QUFBb0MsUUFBRSxFQUFFLENBQXhDO0FBQTJDLFFBQUUsRUFBRSxDQUEvQztBQUFBLDZCQUNJLHFFQUFDLDJEQUFEO0FBQUEsK0JBQ0kscUVBQUMsc0RBQUQ7QUFBTSxtQkFBUyxNQUFmO0FBQWdCLGlCQUFPLEVBQUUsQ0FBekI7QUFBNEIsb0JBQVUsRUFBQyxRQUF2QztBQUFBLGtDQUNJLHFFQUFDLHNEQUFEO0FBQU0sZ0JBQUksTUFBVjtBQUFXLGNBQUUsRUFBRSxFQUFmO0FBQW1CLGNBQUUsRUFBRSxDQUF2QjtBQUFBLG1DQUNJLHFFQUFDLHFEQUFEO0FBQUEscUNBQ0kscUVBQUMsd0RBQUQ7QUFDSSxxQkFBSyxFQUFFO0FBQ0hsTCx3QkFBTSxFQUFFLE9BREw7QUFFSDFDLHVCQUFLLEVBQUU7QUFGSixpQkFEWDtBQUtJLG1CQUFHLEVBQUMsTUFMUjtBQU1JLG1CQUFHLEVBQUMsaUJBTlI7QUFPSSx1QkFBTyxFQUFDO0FBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBY0kscUVBQUMsc0RBQUQ7QUFBTSxnQkFBSSxNQUFWO0FBQVcsY0FBRSxFQUFFLEVBQWY7QUFBbUIsY0FBRSxFQUFFLENBQXZCO0FBQUEsb0NBQ0kscUVBQUMscURBQUQ7QUFDSSxtQkFBSyxFQUFDLG1CQURWO0FBRUksc0JBQVEsRUFBQyxhQUZiO0FBR0ksd0JBQVUsRUFBQyxxQkFIZjtBQUlJLGdCQUFFLEVBQUUsQ0FKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQVFJLHFFQUFDLHFEQUFEO0FBQUssbUJBQUssRUFBQyxlQUFYO0FBQTJCLHNCQUFRLEVBQUMsYUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUkosZUFXSSxxRUFBQyxxREFBRDtBQUFLLG1CQUFLLEVBQUMsZUFBWDtBQUEyQixzQkFBUSxFQUFDLGFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVhKLGVBY0kscUVBQUMsc0RBQUQ7QUFBTSxrQkFBSSxFQUFDLEdBQVg7QUFBZSx1QkFBUyxFQUFDLE1BQXpCO0FBQUEscUNBQ0kscUVBQUMscURBQUQ7QUFBSyxxQkFBSyxFQUFDLGNBQVg7QUFBMEIsd0JBQVEsRUFBQyxhQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBZEosZUFtQkkscUVBQUMscURBQUQ7QUFBSyxnQkFBRSxFQUFFLENBQVQ7QUFBWSxnQkFBRSxFQUFFLENBQWhCO0FBQUEscUNBQ0kscUVBQUMsd0RBQUQ7QUFBUSxvQkFBSSxFQUFDLE9BQWI7QUFBcUIscUJBQUssRUFBQyxTQUEzQjtBQUFxQyx1QkFBTyxFQUFDLFdBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFuQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBNkNJLHFFQUFDLHFEQUFEO0FBQUssUUFBRSxFQUFFLENBQVQ7QUFBWSxRQUFFLEVBQUUsQ0FBaEI7QUFBQSw2QkFDSSxxRUFBQywyREFBRDtBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksZUFBSyxFQUFDLGVBRFY7QUFFSSxrQkFBUSxFQUFDLGFBRmI7QUFHSSxvQkFBVSxFQUFDLGlCQUhmO0FBSUksWUFBRSxFQUFFLENBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFRSSxxRUFBQyxxREFBRDtBQUFLLGVBQUssRUFBQyxvQkFBWDtBQUFnQyxrQkFBUSxFQUFDLGFBQXpDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVJKLGVBV0kscUVBQUMscURBQUQ7QUFBSyxlQUFLLEVBQUMsb0JBQVg7QUFBZ0Msa0JBQVEsRUFBQyxhQUF6QztBQUF1RCxZQUFFLEVBQUUsQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWEosZUFjSSxxRUFBQyxxREFBRDtBQUNJLGVBQUssRUFBQyxlQURWO0FBRUksa0JBQVEsRUFBQyxhQUZiO0FBR0ksb0JBQVUsRUFBQyxpQkFIZjtBQUlJLFlBQUUsRUFBRSxDQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWRKLGVBcUJJLHFFQUFDLHFEQUFEO0FBQUssZUFBSyxFQUFDLG9CQUFYO0FBQWdDLGtCQUFRLEVBQUMsYUFBekM7QUFBdUQsWUFBRSxFQUFFLENBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXJCSixlQXdCSSxxRUFBQyx3REFBRDtBQUFRLGNBQUksRUFBQyxPQUFiO0FBQXFCLGVBQUssRUFBQyxTQUEzQjtBQUFxQyxpQkFBTyxFQUFDLFdBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXhCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTdDSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQThFSCxDQS9FRDs7QUFpRmU0TixpRkFBZixFOzs7Ozs7Ozs7Ozs7QUN6RkE7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUMsbUJBQW1CLEdBQUcsTUFBTTtBQUM5QixRQUFNN0csT0FBTyxHQUFHQywwRUFBUyxFQUF6QjtBQUNBLFFBQU0sQ0FBQ3lFLEtBQUQsRUFBUUMsUUFBUixJQUFvQkMsNENBQUssQ0FBQ0MsUUFBTixDQUFlLENBQWYsQ0FBMUI7O0FBRUEsUUFBTUMsWUFBWSxHQUFHLENBQUNDLEtBQUQsRUFBUUMsUUFBUixLQUFxQjtBQUN0Q0wsWUFBUSxDQUFDSyxRQUFELENBQVI7QUFDSCxHQUZEOztBQUdBLFFBQU04QixrQkFBa0IsR0FBRyxDQUN2QjtBQUFFN0gsUUFBSSxFQUFFO0FBQVIsR0FEdUIsRUFFdkI7QUFBRUEsUUFBSSxFQUFFO0FBQVIsR0FGdUIsRUFHdkI7QUFBRUEsUUFBSSxFQUFFO0FBQVIsR0FIdUIsQ0FBM0I7QUFLQSxRQUFNOEgsd0JBQXdCLEdBQUcsQ0FDN0I7QUFBRTlILFFBQUksRUFBRTtBQUFSLEdBRDZCLEVBRTdCO0FBQUVBLFFBQUksRUFBRTtBQUFSLEdBRjZCLENBQWpDO0FBSUEsUUFBTStILGVBQWUsR0FBRyxDQUNwQjtBQUFFL0gsUUFBSSxFQUFFO0FBQVIsR0FEb0IsRUFFcEI7QUFBRUEsUUFBSSxFQUFFO0FBQVIsR0FGb0IsRUFHcEI7QUFBRUEsUUFBSSxFQUFFO0FBQVIsR0FIb0IsRUFJcEI7QUFBRUEsUUFBSSxFQUFFO0FBQVIsR0FKb0IsQ0FBeEI7QUFPQSxRQUFNZ0ksU0FBUyxHQUFHLENBQ2Q7QUFBRWhJLFFBQUksRUFBRSxhQUFSO0FBQXVCQyxRQUFJLEVBQUVDLHdEQUE3QjtBQUF5Q2dHLGFBQVMsRUFBRUMsMERBQVlBO0FBQWhFLEdBRGMsRUFFZDtBQUFFbkcsUUFBSSxFQUFFLFlBQVI7QUFBc0JDLFFBQUksRUFBRWdJLG1EQUE1QjtBQUFtQy9CLGFBQVMsRUFBRUMsMERBQVlBO0FBQTFELEdBRmMsRUFHZDtBQUFFbkcsUUFBSSxFQUFFLHFCQUFSO0FBQStCQyxRQUFJLEVBQUVpSSxrREFBckM7QUFBMkNoQyxhQUFTLEVBQUVDLDBEQUFZQTtBQUFsRSxHQUhjLENBQWxCOztBQU1BLFdBQVNPLFNBQVQsQ0FBbUJDLEtBQW5CLEVBQTBCO0FBQ3RCLFdBQU87QUFDSG5ILFFBQUUsRUFBRyxnQkFBZW1ILEtBQU0sRUFEdkI7QUFFSCx1QkFBa0IscUJBQW9CQSxLQUFNO0FBRnpDLEtBQVA7QUFJSDs7QUFDRCxXQUFTQyxRQUFULENBQWtCQyxLQUFsQixFQUF5QjtBQUNyQixVQUFNO0FBQUVoRyxjQUFGO0FBQVk0RSxXQUFaO0FBQW1Ca0I7QUFBbkIsUUFBdUNFLEtBQTdDO0FBQUEsVUFBbUNDLEtBQW5DLDRCQUE2Q0QsS0FBN0M7O0FBRUEsd0JBQ0kscUVBQUMscURBQUQ7QUFDSSxXQUFLLEVBQUMsTUFEVjtBQUVJLGNBQVEsRUFBQyxPQUZiO0FBR0ksVUFBSSxFQUFDLFVBSFQ7QUFJSSxZQUFNLEVBQUVwQixLQUFLLEtBQUtrQixLQUp0QjtBQUtJLFFBQUUsRUFBRyxxQkFBb0JBLEtBQU0sRUFMbkM7QUFNSSx5QkFBa0IsZ0JBQWVBLEtBQU0sRUFOM0M7QUFPSSxlQUFTLEVBQUU1RixPQUFPLENBQUNnRztBQVB2QixPQVFRRCxLQVJSO0FBQUEsZ0JBU0tyQixLQUFLLEtBQUtrQixLQUFWLGlCQUNHLHFFQUFDLHFFQUFEO0FBQVksbUJBQVcsRUFBRSxLQUF6QjtBQUFBLCtCQUNJLHFFQUFDLHFEQUFEO0FBQUEsb0JBQU05RjtBQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKO0FBaUJIOztBQUNELHNCQUNJLHFFQUFDLHFEQUFEO0FBQUEsNEJBQ0kscUVBQUMscURBQUQ7QUFBSyxhQUFPLEVBQUMsTUFBYjtBQUFvQixlQUFTLEVBQUVFLE9BQU8sQ0FBQ2lHLE9BQXZDO0FBQWdELFFBQUUsRUFBRSxFQUFwRDtBQUFBLDZCQUNJLHFFQUFDLDJEQUFEO0FBQUEsK0JBQ0kscUVBQUMscURBQUQ7QUFBSyxpQkFBTyxFQUFDLE1BQWI7QUFBb0IsWUFBRSxFQUFFLEVBQXhCO0FBQUEsa0NBQ0kscUVBQUMscURBQUQ7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsZUFEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsaUJBSGY7QUFJSSx1QkFBUyxFQUFDLE9BSmQ7QUFLSSxzQkFBUSxFQUFDLFVBTGI7QUFNSSxpQkFBRyxFQUFDLE9BTlI7QUFPSSxnQkFBRSxFQUFFLENBUFI7QUFBQSxzQ0FRSSxxRUFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFSSixvQkFRb0IscUVBQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQVdJLHFFQUFDLDZEQUFEO0FBQ0kseUJBQVcsRUFBQyxVQURoQjtBQUVJLHFCQUFPLEVBQUMsWUFGWjtBQUdJLG1CQUFLLEVBQUV2QixLQUhYO0FBSUksc0JBQVEsRUFBRUksWUFKZDtBQUtJLDRCQUFXLHVCQUxmO0FBTUksdUJBQVMsRUFBRTlFLE9BQU8sQ0FBQ2tHLElBTnZCO0FBQUEsd0JBT0tlLFNBQVMsQ0FBQ3pILEdBQVYsQ0FBZUMsSUFBRCxpQkFDWCxxRUFBQyw0REFBRDtBQUVJLHFCQUFLLGVBQ0QscUVBQUMscURBQUQ7QUFDSSx5QkFBTyxFQUFDLE1BRFo7QUFFSSw0QkFBVSxFQUFDLFFBRmY7QUFHSSxnQ0FBYyxFQUFDLGVBSG5CO0FBSUksMkJBQVMsRUFBRU8sT0FBTyxDQUFDbUcsU0FKdkI7QUFBQSx5Q0FLSSxxRUFBQyxxREFBRDtBQUFLLDJCQUFPLEVBQUMsTUFBYjtBQUFvQiw4QkFBVSxFQUFDLFFBQS9CO0FBQUEsNENBQ0kscUVBQUMscURBQUQ7QUFBSyw2QkFBTyxFQUFDLE1BQWI7QUFBb0IsZ0NBQVUsRUFBQyxRQUEvQjtBQUFBLDhDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksMEJBQUUsRUFBRSxDQURSO0FBRUksNkJBQUssRUFBQyxjQUZWO0FBR0ksZ0NBQVEsRUFBQyxhQUhiO0FBSUksK0JBQU8sRUFBQyxNQUpaO0FBS0ksa0NBQVUsRUFBQyxRQUxmO0FBTUksa0NBQVUsRUFBQyxtQkFOZjtBQUFBLCtDQU9JLHFFQUFDLElBQUQsQ0FBTSxJQUFOO0FBQVcsK0JBQUssRUFBQyxRQUFqQjtBQUEwQiw4QkFBSSxFQUFFO0FBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQURKLGVBV0kscUVBQUMscURBQUQ7QUFDSSwwQkFBRSxFQUFFLENBRFI7QUFFSSxnQ0FBUSxFQUFDLE9BRmI7QUFHSSw2QkFBSyxFQUFDLGNBSFY7QUFJSSxnQ0FBUSxFQUFDLGFBSmI7QUFLSSxrQ0FBVSxFQUFDLG1CQUxmO0FBTUksa0NBQVUsRUFBQyxRQU5mO0FBQUEsa0NBT0sxRyxJQUFJLENBQUNSO0FBUFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FYSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBREosZUFzQkkscUVBQUMscURBQUQ7QUFBSyw2QkFBTyxFQUFDLE1BQWI7QUFBb0IsK0JBQVMsRUFBQyxPQUE5QjtBQUFBLDZDQUNJLHFFQUFDLElBQUQsQ0FBTSxTQUFOO0FBQWdCLDZCQUFLLEVBQUMsUUFBdEI7QUFBK0IsNEJBQUksRUFBRTtBQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0F0Qko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUhSLGlCQW9DUTBHLFNBQVMsQ0FBQyxDQUFELENBcENqQixHQUNTbEcsSUFBSSxDQUFDUixJQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREg7QUFQTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESixlQTZESSxxRUFBQyxxREFBRDtBQUFLLGlCQUFLLEVBQUMsTUFBWDtBQUFBLG9DQUNJLHFFQUFDLFFBQUQ7QUFBVSxtQkFBSyxFQUFFeUYsS0FBakI7QUFBd0IsbUJBQUssRUFBRSxDQUEvQjtBQUFBLHFDQUNJLHFFQUFDLHFEQUFEO0FBQUssdUJBQU8sRUFBQyxNQUFiO0FBQW9CLHdCQUFRLEVBQUMsT0FBN0I7QUFBQSx3Q0FDSSxxRUFBQyxxREFBRDtBQUNJLHVCQUFLLEVBQUMsZUFEVjtBQUVJLDBCQUFRLEVBQUMsYUFGYjtBQUdJLDRCQUFVLEVBQUMsaUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUFPSSxxRUFBQyxxREFBRDtBQUFBLDRCQUNLb0Msa0JBQWtCLENBQUN0SCxHQUFuQixDQUF3QkMsSUFBRCxpQkFDcEIscUVBQUMscURBQUQ7QUFDSSwyQkFBTyxFQUFDLE1BRFo7QUFFSSw4QkFBVSxFQUFDLFFBRmY7QUFHSSxrQ0FBYyxFQUFDLGVBSG5CO0FBSUksc0JBQUUsRUFBRSxDQUpSO0FBS0ksc0JBQUUsRUFBRSxDQUxSO0FBTUksNkJBQVMsRUFBQyxNQU5kO0FBT0ksNkJBQVMsRUFBRU8sT0FBTyxDQUFDbUcsU0FQdkI7QUFBQSwyQ0FTSSxxRUFBQyxzREFBRDtBQUNJLDBCQUFJLEVBQUMsR0FEVDtBQUVJLCtCQUFTLEVBQUMsTUFGZDtBQUdJLCtCQUFTLEVBQUVuRyxPQUFPLENBQUNvRyxhQUh2QjtBQUFBLDZDQUlJLHFFQUFDLHFEQUFEO0FBQUssK0JBQU8sRUFBQyxNQUFiO0FBQW9CLGtDQUFVLEVBQUMsUUFBL0I7QUFBQSxnREFDSSxxRUFBQyxxREFBRDtBQUNJLDRCQUFFLEVBQUUsQ0FEUjtBQUVJLCtCQUFLLEVBQUMsY0FGVjtBQUdJLGtDQUFRLEVBQUMsYUFIYjtBQUFBLG9DQUlLM0csSUFBSSxDQUFDUjtBQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBREosZUFRSSxxRUFBQyxxREFBRDtBQUFLLGlDQUFPLEVBQUMsTUFBYjtBQUFvQixvQ0FBVSxFQUFDLE1BQS9CO0FBQUEsaURBQ0kscUVBQUMsMERBQUQ7QUFDSSxpQ0FBSyxFQUFDLFFBRFY7QUFFSSxnQ0FBSSxFQUFFO0FBRlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUNBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVRKLHFCQVFTUSxJQVJUO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVBKLGVBeUNJLHFFQUFDLHFEQUFEO0FBQ0ksdUJBQUssRUFBQyxlQURWO0FBRUksMEJBQVEsRUFBQyxhQUZiO0FBR0ksNEJBQVUsRUFBQyxpQkFIZjtBQUlJLG9CQUFFLEVBQUUsQ0FKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF6Q0osZUFnREkscUVBQUMscURBQUQ7QUFBSyxvQkFBRSxFQUFFLENBQVQ7QUFBQSw0QkFDS3NILHdCQUF3QixDQUFDdkgsR0FBekIsQ0FBOEJDLElBQUQsaUJBQzFCLHFFQUFDLHFEQUFEO0FBQ0ksMkJBQU8sRUFBQyxNQURaO0FBRUksOEJBQVUsRUFBQyxRQUZmO0FBR0ksa0NBQWMsRUFBQyxlQUhuQjtBQUlJLHNCQUFFLEVBQUUsQ0FKUjtBQUtJLHNCQUFFLEVBQUUsQ0FMUjtBQU1JLDZCQUFTLEVBQUMsTUFOZDtBQU9JLDZCQUFTLEVBQUVPLE9BQU8sQ0FBQ21HLFNBUHZCO0FBQUEsMkNBU0kscUVBQUMsc0RBQUQ7QUFDSSwwQkFBSSxFQUFDLEdBRFQ7QUFFSSwrQkFBUyxFQUFDLE1BRmQ7QUFHSSwrQkFBUyxFQUFFbkcsT0FBTyxDQUFDb0csYUFIdkI7QUFBQSw2Q0FJSSxxRUFBQyxxREFBRDtBQUFLLCtCQUFPLEVBQUMsTUFBYjtBQUFvQixrQ0FBVSxFQUFDLFFBQS9CO0FBQUEsZ0RBQ0kscUVBQUMscURBQUQ7QUFDSSw0QkFBRSxFQUFFLENBRFI7QUFFSSwrQkFBSyxFQUFDLGNBRlY7QUFHSSxrQ0FBUSxFQUFDLGFBSGI7QUFBQSxvQ0FJSzNHLElBQUksQ0FBQ1I7QUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQURKLGVBUUkscUVBQUMscURBQUQ7QUFBSyxpQ0FBTyxFQUFDLE1BQWI7QUFBb0Isb0NBQVUsRUFBQyxNQUEvQjtBQUFBLGlEQUNJLHFFQUFDLDBEQUFEO0FBQ0ksaUNBQUssRUFBQyxRQURWO0FBRUksZ0NBQUksRUFBRTtBQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFUSixxQkFRU1EsSUFSVDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURIO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFoREosZUFrRkkscUVBQUMscURBQUQ7QUFDSSx1QkFBSyxFQUFDLGVBRFY7QUFFSSwwQkFBUSxFQUFDLGFBRmI7QUFHSSw0QkFBVSxFQUFDLGlCQUhmO0FBSUksb0JBQUUsRUFBRSxDQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWxGSixlQXlGSSxxRUFBQyxxREFBRDtBQUFBLDRCQUNLdUgsZUFBZSxDQUFDeEgsR0FBaEIsQ0FBcUJDLElBQUQsaUJBQ2pCLHFFQUFDLHFEQUFEO0FBQ0ksMkJBQU8sRUFBQyxNQURaO0FBRUksOEJBQVUsRUFBQyxRQUZmO0FBR0ksa0NBQWMsRUFBQyxlQUhuQjtBQUlJLHNCQUFFLEVBQUUsQ0FKUjtBQUtJLHNCQUFFLEVBQUUsQ0FMUjtBQU1JLDZCQUFTLEVBQUMsTUFOZDtBQU9JLDZCQUFTLEVBQUVPLE9BQU8sQ0FBQ21HLFNBUHZCO0FBQUEsMkNBU0kscUVBQUMsc0RBQUQ7QUFDSSwwQkFBSSxFQUFDLEdBRFQ7QUFFSSwrQkFBUyxFQUFDLE1BRmQ7QUFHSSwrQkFBUyxFQUFFbkcsT0FBTyxDQUFDb0csYUFIdkI7QUFBQSw2Q0FJSSxxRUFBQyxxREFBRDtBQUFLLCtCQUFPLEVBQUMsTUFBYjtBQUFvQixrQ0FBVSxFQUFDLFFBQS9CO0FBQUEsZ0RBQ0kscUVBQUMscURBQUQ7QUFDSSw0QkFBRSxFQUFFLENBRFI7QUFFSSwrQkFBSyxFQUFDLGNBRlY7QUFHSSxrQ0FBUSxFQUFDLGFBSGI7QUFBQSxvQ0FJSzNHLElBQUksQ0FBQ1I7QUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQURKLGVBUUkscUVBQUMscURBQUQ7QUFBSyxpQ0FBTyxFQUFDLE1BQWI7QUFBb0Isb0NBQVUsRUFBQyxNQUEvQjtBQUFBLGlEQUNJLHFFQUFDLDBEQUFEO0FBQ0ksaUNBQUssRUFBQyxRQURWO0FBRUksZ0NBQUksRUFBRTtBQUZWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFDQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFUSixxQkFRU1EsSUFSVDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURIO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkF6Rko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQStISSxxRUFBQyxRQUFEO0FBQVUsbUJBQUssRUFBRWlGLEtBQWpCO0FBQXdCLG1CQUFLLEVBQUUsQ0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBL0hKLGVBa0lJLHFFQUFDLFFBQUQ7QUFBVSxtQkFBSyxFQUFFQSxLQUFqQjtBQUF3QixtQkFBSyxFQUFFLENBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWxJSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBN0RKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBeU1JLHFFQUFDLHFEQUFEO0FBQUssWUFBTSxFQUFDLFlBQVo7QUFBeUIsZUFBUyxFQUFFMUUsT0FBTyxDQUFDcUcsVUFBNUM7QUFBQSxnQkFDS1ksU0FBUyxDQUFDekgsR0FBVixDQUFlQyxJQUFELGlCQUNYLHFFQUFDLHFEQUFEO0FBQ0ksZUFBTyxFQUFDLE1BRFo7QUFFSSxrQkFBVSxFQUFDLFFBRmY7QUFHSSxzQkFBYyxFQUFDLGVBSG5CO0FBSUksVUFBRSxFQUFFLENBSlI7QUFLSSxVQUFFLEVBQUUsQ0FMUjtBQU1JLGlCQUFTLEVBQUVPLE9BQU8sQ0FBQ21HLFNBTnZCO0FBQUEsK0JBUUkscUVBQUMsc0RBQUQ7QUFBTSxjQUFJLEVBQUMsR0FBWDtBQUFlLG1CQUFTLEVBQUMsTUFBekI7QUFBZ0MsbUJBQVMsRUFBRW5HLE9BQU8sQ0FBQ29HLGFBQW5EO0FBQUEsaUNBQ0kscUVBQUMscURBQUQ7QUFBSyxtQkFBTyxFQUFDLE1BQWI7QUFBb0Isc0JBQVUsRUFBQyxRQUEvQjtBQUFBLG9DQUNJLHFFQUFDLHFEQUFEO0FBQUsscUJBQU8sRUFBQyxNQUFiO0FBQW9CLHdCQUFVLEVBQUMsUUFBL0I7QUFBQSxzQ0FDSSxxRUFBQyxxREFBRDtBQUNJLGtCQUFFLEVBQUUsQ0FEUjtBQUVJLHFCQUFLLEVBQUMsZUFGVjtBQUdJLHdCQUFRLEVBQUMsYUFIYjtBQUlJLHVCQUFPLEVBQUMsTUFKWjtBQUtJLDBCQUFVLEVBQUMsUUFMZjtBQU1JLDBCQUFVLEVBQUMsbUJBTmY7QUFBQSx1Q0FPSSxxRUFBQyxJQUFELENBQU0sSUFBTjtBQUFXLHVCQUFLLEVBQUMsUUFBakI7QUFBMEIsc0JBQUksRUFBRTtBQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESixlQVdJLHFFQUFDLHFEQUFEO0FBQ0ksa0JBQUUsRUFBRSxDQURSO0FBRUksd0JBQVEsRUFBQyxPQUZiO0FBR0kscUJBQUssRUFBQyxlQUhWO0FBSUksd0JBQVEsRUFBQyxhQUpiO0FBS0ksMEJBQVUsRUFBQyxtQkFMZjtBQUFBLDBCQU1LM0csSUFBSSxDQUFDUjtBQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBcUJJLHFFQUFDLHFEQUFEO0FBQUsscUJBQU8sRUFBQyxNQUFiO0FBQW9CLHdCQUFVLEVBQUMsTUFBL0I7QUFBQSxxQ0FDSSxxRUFBQywwREFBRDtBQUFjLHFCQUFLLEVBQUMsUUFBcEI7QUFBNkIsb0JBQUksRUFBRTtBQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFyQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVJKLFNBT1NRLElBUFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBek1KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBb1BILENBNVNEOztBQThTQW9ILG1CQUFtQixDQUFDMUcsU0FBcEIsR0FBZ0M7QUFDNUJMLFVBQVEsRUFBRU0saURBQVMsQ0FBQ2tHLEdBRFE7QUFFNUI1QixPQUFLLEVBQUV0RSxpREFBUyxDQUFDbUcsTUFGVztBQUc1QlgsT0FBSyxFQUFFeEYsaURBQVMsQ0FBQ21HO0FBSFcsQ0FBaEM7QUFLZU0sa0ZBQWYsRTs7Ozs7Ozs7Ozs7O0FQalVBO0FBQUE7QUFBQTtBQUFBO0FBRUEsTUFBTTVHLFNBQVMsR0FBR08sMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3JDMEYsV0FBUyxFQUFFO0FBQ1AsMEJBQXNCO0FBQ2xCSyxrQkFBWSxFQUFHLGFBQVkvRixLQUFLLENBQUNPLE1BQU4sQ0FBYXlDLElBQUs7QUFEM0I7QUFEZixHQUQwQjtBQU1yQ2dELFlBQVUsRUFBRTtBQUNSbkwsV0FBTyxFQUFFLENBREQ7QUFFUk4sWUFBUSxFQUFFLFVBRkY7QUFHUm1JLFVBQU0sRUFBRTtBQUhBLEdBTnlCO0FBV3JDaUQsZUFBYSxFQUFFO0FBQ1hwTixTQUFLLEVBQUU7QUFESSxHQVhzQjtBQWNyQzBOLFdBQVMsRUFBRTtBQUNQLEtBQUNqRyxLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCckksY0FBUSxFQUFFLFVBRGtCO0FBRTVCRyxZQUFNLEVBQUUsR0FGb0I7QUFHNUJELFVBQUksRUFBRSxHQUhzQjtBQUk1QkUsV0FBSyxFQUFFO0FBSnFCO0FBRHpCLEdBZDBCO0FBc0JyQzRLLFlBQVUsRUFBRTtBQUNSLGVBQVc7QUFDUG5LLGVBQVMsRUFBRSxPQURKO0FBRVAySSxtQkFBYSxFQUFFO0FBRlI7QUFESCxHQXRCeUI7QUE0QnJDNkIsWUFBVSxFQUFFO0FBQ1IsS0FBQzVGLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCOUksYUFBTyxFQUFFO0FBRGlCO0FBRHRCLEdBNUJ5QjtBQWlDckN3SyxTQUFPLEVBQUU7QUFDTCxLQUFDeEYsS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI5SSxhQUFPLEVBQUU7QUFEaUI7QUFEekI7QUFqQzRCLENBQVosQ0FBRCxDQUE1QjtBQXdDZXdFLHdFQUFmLEU7Ozs7Ozs7Ozs7OztBUTFDQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNbUgsbUJBQW1CLEdBQUcsTUFBTTtBQUM5QixRQUFNcEgsT0FBTyxHQUFHQywwRUFBUyxFQUF6QjtBQUNBLFFBQU0sQ0FBQ3lFLEtBQUQsRUFBUUMsUUFBUixJQUFvQkMsNENBQUssQ0FBQ0MsUUFBTixDQUFlLENBQWYsQ0FBMUI7O0FBRUEsUUFBTUMsWUFBWSxHQUFHLENBQUNDLEtBQUQsRUFBUUMsUUFBUixLQUFxQjtBQUN0Q0wsWUFBUSxDQUFDSyxRQUFELENBQVI7QUFDSCxHQUZEOztBQUdBLFdBQVNXLFNBQVQsQ0FBbUJDLEtBQW5CLEVBQTBCO0FBQ3RCLFdBQU87QUFDSG5ILFFBQUUsRUFBRyxnQkFBZW1ILEtBQU0sRUFEdkI7QUFFSCx1QkFBa0IscUJBQW9CQSxLQUFNO0FBRnpDLEtBQVA7QUFJSDs7QUFDRCxXQUFTQyxRQUFULENBQWtCQyxLQUFsQixFQUF5QjtBQUNyQixVQUFNO0FBQUVoRyxjQUFGO0FBQVk0RSxXQUFaO0FBQW1Ca0I7QUFBbkIsUUFBdUNFLEtBQTdDO0FBQUEsVUFBbUNDLEtBQW5DLDRCQUE2Q0QsS0FBN0M7O0FBRUEsd0JBQ0kscUVBQUMscURBQUQ7QUFDSSxXQUFLLEVBQUMsTUFEVjtBQUVJLGNBQVEsRUFBQyxPQUZiO0FBR0ksVUFBSSxFQUFDLFVBSFQ7QUFJSSxZQUFNLEVBQUVwQixLQUFLLEtBQUtrQixLQUp0QjtBQUtJLFFBQUUsRUFBRyxxQkFBb0JBLEtBQU0sRUFMbkM7QUFNSSx5QkFBa0IsZ0JBQWVBLEtBQU0sRUFOM0M7QUFPSSxlQUFTLEVBQUU1RixPQUFPLENBQUNnRztBQVB2QixPQVFRRCxLQVJSO0FBQUEsZ0JBU0tyQixLQUFLLEtBQUtrQixLQUFWLGlCQUNHLHFFQUFDLHFFQUFEO0FBQVksbUJBQVcsRUFBRSxLQUF6QjtBQUFBLCtCQUNJLHFFQUFDLHFEQUFEO0FBQUEsb0JBQU05RjtBQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVlI7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKO0FBaUJIOztBQUNELFFBQU1tRixZQUFZLEdBQUcsQ0FDakI7QUFBRWhHLFFBQUksRUFBRSxhQUFSO0FBQXVCQyxRQUFJLEVBQUVnRyxrREFBN0I7QUFBbUNDLGFBQVMsRUFBRUMsMERBQVlBO0FBQTFELEdBRGlCLEVBRWpCO0FBQUVuRyxRQUFJLEVBQUUsWUFBUjtBQUFzQkMsUUFBSSxFQUFFbUcsc0RBQTVCO0FBQXNDRixhQUFTLEVBQUVDLDBEQUFZQTtBQUE3RCxHQUZpQixFQUdqQjtBQUFFbkcsUUFBSSxFQUFFLHFCQUFSO0FBQStCQyxRQUFJLEVBQUVvRyxrREFBckM7QUFBMkNILGFBQVMsRUFBRUMsMERBQVlBO0FBQWxFLEdBSGlCLENBQXJCO0FBS0EsUUFBTTBCLGtCQUFrQixHQUFHLENBQ3ZCO0FBQUU3SCxRQUFJLEVBQUU7QUFBUixHQUR1QixFQUV2QjtBQUFFQSxRQUFJLEVBQUU7QUFBUixHQUZ1QixFQUd2QjtBQUFFQSxRQUFJLEVBQUU7QUFBUixHQUh1QixDQUEzQjtBQUtBLFFBQU04SCx3QkFBd0IsR0FBRyxDQUM3QjtBQUFFOUgsUUFBSSxFQUFFO0FBQVIsR0FENkIsRUFFN0I7QUFBRUEsUUFBSSxFQUFFO0FBQVIsR0FGNkIsQ0FBakM7QUFJQSxRQUFNK0gsZUFBZSxHQUFHLENBQ3BCO0FBQUUvSCxRQUFJLEVBQUU7QUFBUixHQURvQixFQUVwQjtBQUFFQSxRQUFJLEVBQUU7QUFBUixHQUZvQixFQUdwQjtBQUFFQSxRQUFJLEVBQUU7QUFBUixHQUhvQixFQUlwQjtBQUFFQSxRQUFJLEVBQUU7QUFBUixHQUpvQixDQUF4QjtBQU1BLHNCQUNJLHFFQUFDLHFEQUFEO0FBQUEsNEJBQ0kscUVBQUMscURBQUQ7QUFBSyxhQUFPLEVBQUMsTUFBYjtBQUFvQixlQUFTLEVBQUVlLE9BQU8sQ0FBQ2lHLE9BQXZDO0FBQWdELFFBQUUsRUFBRSxFQUFwRDtBQUFBLDZCQUNJLHFFQUFDLDJEQUFEO0FBQUEsK0JBQ0kscUVBQUMscURBQUQ7QUFBSyxpQkFBTyxFQUFDLE1BQWI7QUFBb0IsWUFBRSxFQUFFLEVBQXhCO0FBQUEsa0NBQ0kscUVBQUMscURBQUQ7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsZUFEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsaUJBSGY7QUFJSSx1QkFBUyxFQUFDLE9BSmQ7QUFLSSxzQkFBUSxFQUFDLFVBTGI7QUFNSSxpQkFBRyxFQUFDLE9BTlI7QUFPSSxnQkFBRSxFQUFFLENBUFI7QUFBQSxzQ0FRSSxxRUFBQyxxREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFSSixvQkFRb0IscUVBQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUnBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQVdJLHFFQUFDLDZEQUFEO0FBQ0kseUJBQVcsRUFBQyxVQURoQjtBQUVJLHFCQUFPLEVBQUMsWUFGWjtBQUdJLG1CQUFLLEVBQUV2QixLQUhYO0FBSUksc0JBQVEsRUFBRUksWUFKZDtBQUtJLDRCQUFXLHVCQUxmO0FBTUksdUJBQVMsRUFBRTlFLE9BQU8sQ0FBQ2tHLElBTnZCO0FBQUEsd0JBT0tqQixZQUFZLENBQUN6RixHQUFiLENBQWtCQyxJQUFELGlCQUNkLHFFQUFDLDREQUFEO0FBRUkscUJBQUssZUFDRCxxRUFBQyxxREFBRDtBQUNJLHlCQUFPLEVBQUMsTUFEWjtBQUVJLDRCQUFVLEVBQUMsUUFGZjtBQUdJLGdDQUFjLEVBQUMsZUFIbkI7QUFJSSwyQkFBUyxFQUFFTyxPQUFPLENBQUNtRyxTQUp2QjtBQUFBLHlDQUtJLHFFQUFDLHFEQUFEO0FBQUssMkJBQU8sRUFBQyxNQUFiO0FBQW9CLDhCQUFVLEVBQUMsUUFBL0I7QUFBQSw0Q0FDSSxxRUFBQyxxREFBRDtBQUFLLDZCQUFPLEVBQUMsTUFBYjtBQUFvQixnQ0FBVSxFQUFDLFFBQS9CO0FBQUEsOENBQ0kscUVBQUMscURBQUQ7QUFDSSwwQkFBRSxFQUFFLENBRFI7QUFFSSw2QkFBSyxFQUFDLGNBRlY7QUFHSSxnQ0FBUSxFQUFDLGFBSGI7QUFJSSwrQkFBTyxFQUFDLE1BSlo7QUFLSSxrQ0FBVSxFQUFDLFFBTGY7QUFNSSxrQ0FBVSxFQUFDLG1CQU5mO0FBQUEsK0NBT0kscUVBQUMsSUFBRCxDQUFNLElBQU47QUFBVywrQkFBSyxFQUFDLFFBQWpCO0FBQTBCLDhCQUFJLEVBQUU7QUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUNBREosZUFXSSxxRUFBQyxxREFBRDtBQUNJLDBCQUFFLEVBQUUsQ0FEUjtBQUVJLGdDQUFRLEVBQUMsT0FGYjtBQUdJLDZCQUFLLEVBQUMsY0FIVjtBQUlJLGdDQUFRLEVBQUMsYUFKYjtBQUtJLGtDQUFVLEVBQUMsbUJBTGY7QUFNSSxrQ0FBVSxFQUFDLFFBTmY7QUFBQSxrQ0FPSzFHLElBQUksQ0FBQ1I7QUFQVjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1DQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQ0FESixlQXNCSSxxRUFBQyxxREFBRDtBQUFLLDZCQUFPLEVBQUMsTUFBYjtBQUFvQiwrQkFBUyxFQUFDLE9BQTlCO0FBQUEsNkNBQ0kscUVBQUMsSUFBRCxDQUFNLFNBQU47QUFBZ0IsNkJBQUssRUFBQyxRQUF0QjtBQUErQiw0QkFBSSxFQUFFO0FBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSFIsaUJBb0NRMEcsU0FBUyxDQUFDLENBQUQsQ0FwQ2pCLEdBQ1NsRyxJQUFJLENBQUNSLElBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESDtBQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBNkRJLHFFQUFDLHFEQUFEO0FBQUssaUJBQUssRUFBQyxNQUFYO0FBQUEsb0NBQ0kscUVBQUMsUUFBRDtBQUFVLG1CQUFLLEVBQUV5RixLQUFqQjtBQUF3QixtQkFBSyxFQUFFLENBQS9CO0FBQUEscUNBQ0kscUVBQUMscURBQUQ7QUFBSyx1QkFBTyxFQUFDLE1BQWI7QUFBb0Isd0JBQVEsRUFBQyxPQUE3QjtBQUFBLHdDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksdUJBQUssRUFBQyxlQURWO0FBRUksMEJBQVEsRUFBQyxhQUZiO0FBR0ksNEJBQVUsRUFBQyxpQkFIZjtBQUlJLG9CQUFFLEVBQUUsQ0FKUjtBQUtJLG9CQUFFLEVBQUUsQ0FMUjtBQU1JLDJCQUFTLEVBQUUxRSxPQUFPLENBQUNYLEtBTnZCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKLGVBVUkscUVBQUMscURBQUQ7QUFDSSx1QkFBSyxFQUFDLGVBRFY7QUFFSSwwQkFBUSxFQUFDLGFBRmI7QUFHSSw0QkFBVSxFQUFDLGlCQUhmO0FBSUksb0JBQUUsRUFBRSxDQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQVZKLGVBaUJJLHFFQUFDLHFEQUFEO0FBQUssdUJBQUssRUFBQyxlQUFYO0FBQTJCLDBCQUFRLEVBQUMsYUFBcEM7QUFBa0Qsb0JBQUUsRUFBRSxDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFqQkosZUF1QkkscUVBQUMscURBQUQ7QUFBSyx1QkFBSyxFQUFDLGVBQVg7QUFBMkIsMEJBQVEsRUFBQyxhQUFwQztBQUFrRCxvQkFBRSxFQUFFLENBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQXZCSixlQTZCSSxxRUFBQyxxREFBRDtBQUFLLG9CQUFFLEVBQUUsQ0FBVDtBQUFBLHlDQUNJLHFFQUFDLHdEQUFEO0FBQVEsd0JBQUksRUFBQyxRQUFiO0FBQXNCLHlCQUFLLEVBQUMsU0FBNUI7QUFBc0MsMkJBQU8sRUFBQyxXQUE5QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBN0JKLGVBa0NJLHFFQUFDLHFEQUFEO0FBQUssOEJBQVksRUFBQyxLQUFsQjtBQUF3QiwwQkFBUSxFQUFDLFFBQWpDO0FBQTBDLG9CQUFFLEVBQUUsQ0FBOUM7QUFBQSx5Q0FDSSxxRUFBQyx3REFBRDtBQUNJLHlCQUFLLEVBQUU7QUFDSDNELDRCQUFNLEVBQUUsT0FETDtBQUVIMUMsMkJBQUssRUFBRTtBQUZKLHFCQURYO0FBS0ksdUJBQUcsRUFBQyxNQUxSO0FBTUksdUJBQUcsRUFBQyxXQU5SO0FBT0ksMkJBQU8sRUFBQztBQVBaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQWxDSixlQTZDSSxxRUFBQyxxREFBRDtBQUNJLHVCQUFLLEVBQUMsZUFEVjtBQUVJLDBCQUFRLEVBQUMsYUFGYjtBQUdJLDRCQUFVLEVBQUMsaUJBSGY7QUFJSSxvQkFBRSxFQUFFLENBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBN0NKLGVBb0RJLHFFQUFDLHFEQUFEO0FBQUssdUJBQUssRUFBQyxlQUFYO0FBQTJCLDBCQUFRLEVBQUMsYUFBcEM7QUFBa0Qsb0JBQUUsRUFBRSxDQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFwREosZUEwREkscUVBQUMscURBQUQ7QUFBSyxvQkFBRSxFQUFFLENBQVQ7QUFBQSx5Q0FDSSxxRUFBQyx3REFBRDtBQUFRLHdCQUFJLEVBQUMsUUFBYjtBQUFzQix5QkFBSyxFQUFDLFNBQTVCO0FBQXNDLDJCQUFPLEVBQUMsV0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQTFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBbUVJLHFFQUFDLFFBQUQ7QUFBVSxtQkFBSyxFQUFFMEwsS0FBakI7QUFBd0IsbUJBQUssRUFBRSxDQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFuRUosZUFzRUkscUVBQUMsUUFBRDtBQUFVLG1CQUFLLEVBQUVBLEtBQWpCO0FBQXdCLG1CQUFLLEVBQUUsQ0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBdEVKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkE3REo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUE2SUkscUVBQUMscURBQUQ7QUFBSyxZQUFNLEVBQUMsZUFBWjtBQUE0QixlQUFTLEVBQUUxRSxPQUFPLENBQUNxRyxVQUEvQztBQUFBLDhCQUNJLHFFQUFDLHFEQUFEO0FBQUssYUFBSyxFQUFDLGVBQVg7QUFBMkIsZ0JBQVEsRUFBQyxhQUFwQztBQUFrRCxrQkFBVSxFQUFDLGlCQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQUlJLHFFQUFDLHFEQUFEO0FBQUEsa0JBQ0tTLGtCQUFrQixDQUFDdEgsR0FBbkIsQ0FBd0JDLElBQUQsaUJBQ3BCLHFFQUFDLHFEQUFEO0FBQ0ksaUJBQU8sRUFBQyxNQURaO0FBRUksb0JBQVUsRUFBQyxRQUZmO0FBR0ksd0JBQWMsRUFBQyxlQUhuQjtBQUlJLFlBQUUsRUFBRSxDQUpSO0FBS0ksWUFBRSxFQUFFLENBTFI7QUFNSSxtQkFBUyxFQUFDLE1BTmQ7QUFPSSxtQkFBUyxFQUFFTyxPQUFPLENBQUNtRyxTQVB2QjtBQUFBLGlDQVNJLHFFQUFDLHNEQUFEO0FBQU0sZ0JBQUksRUFBQyxHQUFYO0FBQWUscUJBQVMsRUFBQyxNQUF6QjtBQUFnQyxxQkFBUyxFQUFFbkcsT0FBTyxDQUFDb0csYUFBbkQ7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHFCQUFPLEVBQUMsTUFBYjtBQUFvQix3QkFBVSxFQUFDLFFBQS9CO0FBQUEsc0NBQ0kscUVBQUMscURBQUQ7QUFBSyxrQkFBRSxFQUFFLENBQVQ7QUFBWSxxQkFBSyxFQUFDLGNBQWxCO0FBQWlDLHdCQUFRLEVBQUMsYUFBMUM7QUFBQSwwQkFDSzNHLElBQUksQ0FBQ1I7QUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURKLGVBS0kscUVBQUMscURBQUQ7QUFBSyx1QkFBTyxFQUFDLE1BQWI7QUFBb0IsMEJBQVUsRUFBQyxNQUEvQjtBQUFBLHVDQUNJLHFFQUFDLDBEQUFEO0FBQWMsdUJBQUssRUFBQyxRQUFwQjtBQUE2QixzQkFBSSxFQUFFO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFUSixXQVFTUSxJQVJUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpKLGVBNkJJLHFFQUFDLHFEQUFEO0FBQ0ksYUFBSyxFQUFDLGVBRFY7QUFFSSxnQkFBUSxFQUFDLGFBRmI7QUFHSSxrQkFBVSxFQUFDLGlCQUhmO0FBSUksVUFBRSxFQUFFLENBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBN0JKLGVBb0NJLHFFQUFDLHFEQUFEO0FBQUssVUFBRSxFQUFFLENBQVQ7QUFBQSxrQkFDS3NILHdCQUF3QixDQUFDdkgsR0FBekIsQ0FBOEJDLElBQUQsaUJBQzFCLHFFQUFDLHFEQUFEO0FBQ0ksaUJBQU8sRUFBQyxNQURaO0FBRUksb0JBQVUsRUFBQyxRQUZmO0FBR0ksd0JBQWMsRUFBQyxlQUhuQjtBQUlJLFlBQUUsRUFBRSxDQUpSO0FBS0ksWUFBRSxFQUFFLENBTFI7QUFNSSxtQkFBUyxFQUFDLE1BTmQ7QUFPSSxtQkFBUyxFQUFFTyxPQUFPLENBQUNtRyxTQVB2QjtBQUFBLGlDQVNJLHFFQUFDLHNEQUFEO0FBQU0sZ0JBQUksRUFBQyxHQUFYO0FBQWUscUJBQVMsRUFBQyxNQUF6QjtBQUFnQyxxQkFBUyxFQUFFbkcsT0FBTyxDQUFDb0csYUFBbkQ7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHFCQUFPLEVBQUMsTUFBYjtBQUFvQix3QkFBVSxFQUFDLFFBQS9CO0FBQUEsc0NBQ0kscUVBQUMscURBQUQ7QUFBSyxrQkFBRSxFQUFFLENBQVQ7QUFBWSxxQkFBSyxFQUFDLGNBQWxCO0FBQWlDLHdCQUFRLEVBQUMsYUFBMUM7QUFBQSwwQkFDSzNHLElBQUksQ0FBQ1I7QUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURKLGVBS0kscUVBQUMscURBQUQ7QUFBSyx1QkFBTyxFQUFDLE1BQWI7QUFBb0IsMEJBQVUsRUFBQyxNQUEvQjtBQUFBLHVDQUNJLHFFQUFDLDBEQUFEO0FBQWMsdUJBQUssRUFBQyxRQUFwQjtBQUE2QixzQkFBSSxFQUFFO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFUSixXQVFTUSxJQVJUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXBDSixlQTZESSxxRUFBQyxxREFBRDtBQUNJLGFBQUssRUFBQyxlQURWO0FBRUksZ0JBQVEsRUFBQyxhQUZiO0FBR0ksa0JBQVUsRUFBQyxpQkFIZjtBQUlJLFVBQUUsRUFBRSxDQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdESixlQW9FSSxxRUFBQyxxREFBRDtBQUFLLFVBQUUsRUFBRSxDQUFUO0FBQUEsa0JBQ0t1SCxlQUFlLENBQUN4SCxHQUFoQixDQUFxQkMsSUFBRCxpQkFDakIscUVBQUMscURBQUQ7QUFDSSxpQkFBTyxFQUFDLE1BRFo7QUFFSSxvQkFBVSxFQUFDLFFBRmY7QUFHSSx3QkFBYyxFQUFDLGVBSG5CO0FBSUksWUFBRSxFQUFFLENBSlI7QUFLSSxZQUFFLEVBQUUsQ0FMUjtBQU1JLG1CQUFTLEVBQUMsTUFOZDtBQU9JLG1CQUFTLEVBQUVPLE9BQU8sQ0FBQ21HLFNBUHZCO0FBQUEsaUNBU0kscUVBQUMsc0RBQUQ7QUFBTSxnQkFBSSxFQUFDLEdBQVg7QUFBZSxxQkFBUyxFQUFDLE1BQXpCO0FBQWdDLHFCQUFTLEVBQUVuRyxPQUFPLENBQUNvRyxhQUFuRDtBQUFBLG1DQUNJLHFFQUFDLHFEQUFEO0FBQUsscUJBQU8sRUFBQyxNQUFiO0FBQW9CLHdCQUFVLEVBQUMsUUFBL0I7QUFBQSxzQ0FDSSxxRUFBQyxxREFBRDtBQUFLLGtCQUFFLEVBQUUsQ0FBVDtBQUFZLHFCQUFLLEVBQUMsY0FBbEI7QUFBaUMsd0JBQVEsRUFBQyxhQUExQztBQUFBLDBCQUNLM0csSUFBSSxDQUFDUjtBQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFLSSxxRUFBQyxxREFBRDtBQUFLLHVCQUFPLEVBQUMsTUFBYjtBQUFvQiwwQkFBVSxFQUFDLE1BQS9CO0FBQUEsdUNBQ0kscUVBQUMsMERBQUQ7QUFBYyx1QkFBSyxFQUFDLFFBQXBCO0FBQTZCLHNCQUFJLEVBQUU7QUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVRKLFdBUVNRLElBUlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBcEVKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE3SUo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUE4T0gsQ0FwU0Q7O0FBc1NBMkgsbUJBQW1CLENBQUNqSCxTQUFwQixHQUFnQztBQUM1QkwsVUFBUSxFQUFFTSxpREFBUyxDQUFDa0csR0FEUTtBQUU1QjVCLE9BQUssRUFBRXRFLGlEQUFTLENBQUNtRyxNQUZXO0FBRzVCWCxPQUFLLEVBQUV4RixpREFBUyxDQUFDbUc7QUFIVyxDQUFoQztBQUtlYSxrRkFBZixFOzs7Ozs7Ozs7Ozs7QUN4VEE7QUFBQTtBQUFBO0FBQUE7QUFFQSxNQUFNbkgsU0FBUyxHQUFHTywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckMwRixXQUFTLEVBQUU7QUFDUCwwQkFBc0I7QUFDbEJLLGtCQUFZLEVBQUcsYUFBWS9GLEtBQUssQ0FBQ08sTUFBTixDQUFheUMsSUFBSztBQUQzQjtBQURmLEdBRDBCO0FBTXJDMkMsZUFBYSxFQUFFO0FBQ1hwTixTQUFLLEVBQUU7QUFESSxHQU5zQjtBQVNyQ2dOLFlBQVUsRUFBRTtBQUNSLGVBQVc7QUFDUG5LLGVBQVMsRUFBRSxPQURKO0FBRVAySSxtQkFBYSxFQUFFO0FBRlI7QUFESCxHQVR5QjtBQWVyQzZCLFlBQVUsRUFBRTtBQUNSLEtBQUM1RixLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjlJLGFBQU8sRUFBRTtBQURpQjtBQUR0QixHQWZ5QjtBQW9CckN3SyxTQUFPLEVBQUU7QUFDTCxLQUFDeEYsS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI5SSxhQUFPLEVBQUU7QUFEaUI7QUFEekIsR0FwQjRCO0FBeUJyQzRELE9BQUssRUFBRTtBQUNIbUgsZ0JBQVksRUFBRyxhQUFZL0YsS0FBSyxDQUFDTyxNQUFOLENBQWF5QyxJQUFLO0FBRDFDO0FBekI4QixDQUFaLENBQUQsQ0FBNUI7QUE4QmV4RCx3RUFBZixFOzs7Ozs7Ozs7Ozs7QUNoQ0E7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1vSCxhQUFhLEdBQUcsTUFBTTtBQUN4QixRQUFNckgsT0FBTyxHQUFHQyxvRUFBUyxFQUF6QjtBQUNBLFFBQU1nSCxTQUFTLEdBQUcsQ0FDZDtBQUFFaEksUUFBSSxFQUFFLDRCQUFSO0FBQXNDQyxRQUFJLEVBQUVvSSxrREFBSUE7QUFBaEQsR0FEYyxFQUVkO0FBQUVySSxRQUFJLEVBQUUsZ0NBQVI7QUFBMENDLFFBQUksRUFBRXFJLGtEQUFJQTtBQUFwRCxHQUZjLEVBR2Q7QUFBRXRJLFFBQUksRUFBRSxrQ0FBUjtBQUE0Q0MsUUFBSSxFQUFFRSxxREFBT0E7QUFBekQsR0FIYyxDQUFsQjtBQU1BLHNCQUNJO0FBQUEsNEJBQ0kscUVBQUMscURBQUQ7QUFBSyxRQUFFLEVBQUUsQ0FBVDtBQUFZLGFBQU8sRUFBQyxzQkFBcEI7QUFBMkMsZUFBUyxFQUFFWSxPQUFPLENBQUN3SCxxQkFBOUQ7QUFBQSw2QkFDSSxxRUFBQywyREFBRDtBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksWUFBRSxFQUFFLENBRFI7QUFFSSxZQUFFLEVBQUUsQ0FGUjtBQUdJLGtCQUFRLEVBQUMsYUFIYjtBQUlJLG9CQUFVLEVBQUMsaUJBSmY7QUFLSSxlQUFLLEVBQUMsZUFMVjtBQU1JLGlCQUFPLEVBQUMsTUFOWjtBQU9JLG1CQUFTLEVBQUV4SCxPQUFPLENBQUN5SCxRQVB2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQVlJLHFFQUFDLHNEQUFEO0FBQU0sbUJBQVMsTUFBZjtBQUFnQixpQkFBTyxFQUFFLENBQXpCO0FBQUEsa0NBQ0kscUVBQUMsc0RBQUQ7QUFBTSxnQkFBSSxNQUFWO0FBQVcsY0FBRSxFQUFFLEVBQWY7QUFBbUIsY0FBRSxFQUFFLENBQXZCO0FBQUEsbUNBQ0kscUVBQUMscURBQUQ7QUFBSyxnQkFBRSxFQUFFLENBQUMsQ0FBVjtBQUFhLHVCQUFTLEVBQUV6SCxPQUFPLENBQUMwSCxRQUFoQztBQUFBLHNDQUNJLHFFQUFDLHFEQUFEO0FBQUssa0JBQUUsRUFBRSxDQUFUO0FBQUEsdUNBQ0kscUVBQUMsc0VBQUQ7QUFDSSx5QkFBTyxFQUFDLFNBRFo7QUFFSSwyQkFBUyxFQUFFLElBRmY7QUFHSSwrQkFBYSxFQUFFLElBSG5CO0FBQUEsMENBSUkscUVBQUMscURBQUQ7QUFDSSx5QkFBSyxFQUFDLGNBRFY7QUFFSSw0QkFBUSxFQUFDLGFBRmI7QUFHSSw4QkFBVSxFQUFDLG1CQUhmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUpKLGVBVUkscUVBQUMscURBQUQ7QUFDSSw2QkFBUyxFQUFDLE9BRGQ7QUFFSSx5QkFBSyxFQUFDLGVBRlY7QUFHSSw0QkFBUSxFQUFDLGFBSGI7QUFJSSw4QkFBVSxFQUFDLG9CQUpmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFxQkkscUVBQUMscURBQUQ7QUFBSyxrQkFBRSxFQUFFLENBQVQ7QUFBQSx1Q0FDSSxxRUFBQyxzRUFBRDtBQUNJLHlCQUFPLEVBQUMsU0FEWjtBQUVJLDJCQUFTLEVBQUUsSUFGZjtBQUdJLCtCQUFhLEVBQUUsSUFIbkI7QUFBQSwwQ0FJSSxxRUFBQyxxREFBRDtBQUNJLHlCQUFLLEVBQUMsY0FEVjtBQUVJLDRCQUFRLEVBQUMsYUFGYjtBQUdJLDhCQUFVLEVBQUMsbUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSkosZUFVSSxxRUFBQyxxREFBRDtBQUNJLDZCQUFTLEVBQUMsT0FEZDtBQUVJLHlCQUFLLEVBQUMsZUFGVjtBQUdJLDRCQUFRLEVBQUMsYUFIYjtBQUlJLDhCQUFVLEVBQUMsb0JBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFyQkosZUF5Q0kscUVBQUMscURBQUQ7QUFBSyxrQkFBRSxFQUFFLENBQVQ7QUFBQSx1Q0FDSSxxRUFBQyxzRUFBRDtBQUNJLHlCQUFPLEVBQUMsUUFEWjtBQUVJLDJCQUFTLEVBQUUsSUFGZjtBQUdJLCtCQUFhLEVBQUUsSUFIbkI7QUFBQSwwQ0FJSSxxRUFBQyxxREFBRDtBQUNJLHlCQUFLLEVBQUMsY0FEVjtBQUVJLDRCQUFRLEVBQUMsYUFGYjtBQUdJLDhCQUFVLEVBQUMsbUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSkosZUFVSSxxRUFBQyxxREFBRDtBQUNJLDZCQUFTLEVBQUMsT0FEZDtBQUVJLHlCQUFLLEVBQUMsZUFGVjtBQUdJLDRCQUFRLEVBQUMsYUFIYjtBQUlJLDhCQUFVLEVBQUMsb0JBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkF6Q0osZUE2REkscUVBQUMscURBQUQ7QUFBSyxrQkFBRSxFQUFFLENBQVQ7QUFBQSx1Q0FDSSxxRUFBQyxzRUFBRDtBQUNJLDJCQUFTLEVBQUUsSUFEZjtBQUVJLCtCQUFhLEVBQUUsS0FGbkI7QUFHSSxnQ0FBYyxFQUFFLEtBSHBCO0FBQUEsMENBSUkscUVBQUMscURBQUQ7QUFDSSx5QkFBSyxFQUFDLGNBRFY7QUFFSSw0QkFBUSxFQUFDLGFBRmI7QUFHSSw4QkFBVSxFQUFDLG1CQUhmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUpKLGVBVUkscUVBQUMscURBQUQ7QUFDSSw2QkFBUyxFQUFDLE9BRGQ7QUFFSSx5QkFBSyxFQUFDLGVBRlY7QUFHSSw0QkFBUSxFQUFDLGFBSGI7QUFJSSw4QkFBVSxFQUFDLG9CQUpmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBN0RKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosZUFxRkkscUVBQUMsc0RBQUQ7QUFBTSxnQkFBSSxNQUFWO0FBQVcsY0FBRSxFQUFFLEVBQWY7QUFBbUIsY0FBRSxFQUFFLENBQXZCO0FBQUEsbUNBQ0kscUVBQUMscURBQUQ7QUFBQSx3QkFDS1QsU0FBUyxDQUFDekgsR0FBVixDQUFlQyxJQUFELGlCQUNYLHFFQUFDLHFEQUFEO0FBQUssa0JBQUUsRUFBRSxDQUFUO0FBQUEsdUNBQ0kscUVBQUMsc0RBQUQ7QUFBTSxzQkFBSSxFQUFDLEdBQVg7QUFBZSwyQkFBUyxFQUFDLE1BQXpCO0FBQUEseUNBQ0kscUVBQUMscURBQUQ7QUFBSywyQkFBTyxFQUFDLE1BQWI7QUFBb0IsOEJBQVUsRUFBQyxRQUEvQjtBQUFBLDRDQUNJLHFFQUFDLElBQUQsQ0FBTSxJQUFOO0FBQ0ksaUNBQVcsRUFBQyxHQURoQjtBQUVJLDJCQUFLLEVBQUMsUUFGVjtBQUdJLDBCQUFJLEVBQUU7QUFIVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQURKLGVBTUkscUVBQUMscURBQUQ7QUFDSSw4QkFBUSxFQUFDLGFBRGI7QUFFSSwyQkFBSyxFQUFDLGNBRlY7QUFHSSxnQ0FBVSxFQUFDLG1CQUhmO0FBSUksd0JBQUUsRUFBRSxHQUpSO0FBQUEsZ0NBS0tBLElBQUksQ0FBQ1I7QUFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixpQkFBaUJRLElBQUksQ0FBQ1IsSUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXJGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQStISSxxRUFBQywyREFBRDtBQUFBLDhCQUNJLHFFQUFDLHFEQUFEO0FBQ0ksVUFBRSxFQUFFLENBRFI7QUFFSSxVQUFFLEVBQUUsQ0FGUjtBQUdJLGdCQUFRLEVBQUMsYUFIYjtBQUlJLGtCQUFVLEVBQUMsaUJBSmY7QUFLSSxhQUFLLEVBQUMsb0JBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFTSSxxRUFBQyxzREFBRDtBQUFNLGlCQUFTLE1BQWY7QUFBZ0IsZUFBTyxFQUFFLENBQXpCO0FBQUEsa0JBQ0ssQ0FDRztBQUNJMEksbUJBQVMsRUFBRSxhQURmO0FBRUkxSSxjQUFJLEVBQUU7QUFGVixTQURILEVBS0c7QUFDSTBJLG1CQUFTLEVBQUUsYUFEZjtBQUVJMUksY0FBSSxFQUFFLHFDQUZWO0FBR0l3QyxpQkFBTyxFQUFFO0FBSGIsU0FMSCxFQVVHO0FBQ0lrRyxtQkFBUyxFQUFFLGFBRGY7QUFFSTFJLGNBQUksRUFBRSw2QkFGVjtBQUdJd0MsaUJBQU8sRUFBRTtBQUhiLFNBVkgsRUFlRztBQUNJa0csbUJBQVMsRUFBRSxhQURmO0FBRUkxSSxjQUFJLEVBQUU7QUFGVixTQWZILEVBbUJDTyxHQW5CRCxDQW1CTUMsSUFBRCxpQkFDRixxRUFBQyxzREFBRDtBQUFNLGNBQUksTUFBVjtBQUFXLFlBQUUsRUFBRSxDQUFmO0FBQWtCLFlBQUUsRUFBRSxDQUF0QjtBQUFBLGlDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksYUFBQyxFQUFFLENBRFA7QUFFSSx3QkFBWSxFQUFDLE1BRmpCO0FBR0ksY0FBRSxFQUFFLENBSFI7QUFJSSxxQkFBUyxFQUFFNEMsMkNBQUksQ0FDWHJDLE9BQU8sQ0FBQzRILFVBREcsRUFFWG5JLElBQUksQ0FBQ2dDLE9BQUwsSUFBZ0J6QixPQUFPLENBQUNQLElBQUksQ0FBQ2dDLE9BQU4sQ0FGWixDQUpuQjtBQUFBLG9DQVFJLHFFQUFDLHFEQUFEO0FBQUssMEJBQVksRUFBQyxNQUFsQjtBQUF5QixnQkFBRSxFQUFFLENBQTdCO0FBQWdDLHVCQUFTLEVBQUV6QixPQUFPLENBQUM2SCxZQUFuRDtBQUFBLHFDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksdUJBQU8sRUFBQyxNQURaO0FBRUksOEJBQWMsRUFBQyxRQUZuQjtBQUdJLHdCQUFRLEVBQUMsVUFIYjtBQUlJLG1CQUFHLEVBQUMsT0FKUjtBQUFBLHVDQUtJLHFFQUFDLGlEQUFEO0FBQU8scUJBQUcsRUFBRXBJLElBQUksQ0FBQ2tJLFNBQWpCO0FBQTRCLHVCQUFLLEVBQUUsR0FBbkM7QUFBd0Msd0JBQU0sRUFBRTtBQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUkosZUFpQkkscUVBQUMscURBQUQ7QUFBQSxxQ0FDSSxxRUFBQyxzREFBRDtBQUFNLG9CQUFJLEVBQUMsR0FBWDtBQUFlLHlCQUFTLEVBQUMsTUFBekI7QUFBQSx1Q0FDSSxxRUFBQyxxREFBRDtBQUFLLHlCQUFPLEVBQUMsTUFBYjtBQUFvQiw0QkFBVSxFQUFDLFFBQS9CO0FBQUEseUNBQ0kscUVBQUMscURBQUQ7QUFBSywyQkFBTyxFQUFDLE1BQWI7QUFBb0Isa0NBQWMsRUFBQyxZQUFuQztBQUFBLDRDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksOEJBQVEsRUFBQyxhQURiO0FBRUksMkJBQUssRUFBQyxlQUZWO0FBR0ksZ0NBQVUsRUFBQyxtQkFIZjtBQUlJLHdCQUFFLEVBQUUsQ0FKUjtBQUFBLGlDQUtLbEksSUFBSSxDQUFDUixJQUxWLGVBTUkscUVBQUMscURBQUQ7QUFDSSxpQ0FBUyxFQUFDLE1BRGQ7QUFFSSxnQ0FBUSxFQUFDLFVBRmI7QUFHSSwyQkFBRyxFQUFDLEtBSFI7QUFJSSw0QkFBSSxFQUFDLEtBSlQ7QUFLSSxpQ0FBUyxFQUFFZSxPQUFPLENBQUM4SCxXQUx2QjtBQUFBLCtDQU1JLHFFQUFDLDBEQUFEO0FBQ0kscUNBQVcsRUFBRSxDQURqQjtBQUVJLCtCQUFLLEVBQUMsUUFGVjtBQUdJLDhCQUFJLEVBQUU7QUFIVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUNBREosZUFvQkkscUVBQUMscURBQUQ7QUFDSSw4QkFBUSxFQUFDLGFBRGI7QUFFSSwyQkFBSyxFQUFDLGVBRlY7QUFHSSxnQ0FBVSxFQUFDLG1CQUhmO0FBSUksNkJBQU8sRUFBQyxNQUpaO0FBS0ksK0JBQVMsRUFBRTlILE9BQU8sQ0FBQytILFFBTHZCO0FBQUEsNkNBTUkscUVBQUMsMERBQUQ7QUFDSSxtQ0FBVyxFQUFFLENBRGpCO0FBRUksNkJBQUssRUFBQyxRQUZWO0FBR0ksNEJBQUksRUFBRTtBQUhWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlDQXBCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLFdBQThCdEksSUFBSSxDQUFDdUksSUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFwQkg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkEvSEo7QUFBQSxrQkFESjtBQThOSCxDQXRPRDs7QUF3T2VYLDRFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3JQQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU1wSCxTQUFTLEdBQUdPLDJFQUFVLENBQUVDLEtBQUQsS0FBWTtBQUNyQ2dILFVBQVEsRUFBRTtBQUNOLEtBQUNoSCxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjlJLGFBQU8sRUFBRTtBQURpQjtBQUR4QixHQUQyQjtBQU1yQ3NJLFNBQU8sRUFBRTtBQUNMLEtBQUN0RCxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjVELHFCQUFlLEVBQUcsR0FBRUYsS0FBSyxDQUFDRyxPQUFOLENBQWNxSCxTQUFkLENBQXdCMUcsS0FBTTtBQUR4QixLQUR6QjtBQUlMLDJCQUF1QjtBQUNuQixPQUFDZCxLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCMUMsdUJBQWUsRUFBRyxHQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY3FILFNBQWQsQ0FBd0IxRyxLQUFNO0FBRHRCO0FBRGI7QUFKbEIsR0FONEI7QUFnQnJDMkcsU0FBTyxFQUFFO0FBQ0wsS0FBQ3pILEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCNUQscUJBQWUsRUFBRyxHQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY3VILE9BQWQsQ0FBc0JDLFVBQVc7QUFEM0IsS0FEekI7QUFJTCwyQkFBdUI7QUFDbkIsT0FBQzNILEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JDLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUIxQyx1QkFBZSxFQUFHLEdBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjdUgsT0FBZCxDQUFzQkMsVUFBVztBQUR6QjtBQURiO0FBSmxCLEdBaEI0QjtBQTBCckNSLFlBQVUsRUFBRTtBQUNSLEtBQUNuSCxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjhELGtCQUFZLEVBQUUsT0FEWTtBQUUxQjFILHFCQUFlLEVBQUVGLEtBQUssQ0FBQ08sTUFBTixDQUFhc0gsZ0JBRko7QUFHMUJoTixhQUFPLEVBQUU7QUFIaUI7QUFEdEIsR0ExQnlCO0FBaUNyQ3VNLGNBQVksRUFBRTtBQUNWbEgsbUJBQWUsRUFBRUYsS0FBSyxDQUFDTyxNQUFOLENBQWFzSCxnQkFEcEI7QUFFVixLQUFDN0gsS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI1RCxxQkFBZSxFQUFFLGFBRFM7QUFFMUIwSCxrQkFBWSxFQUFFO0FBRlk7QUFGcEIsR0FqQ3VCO0FBd0NyQ1gsVUFBUSxFQUFFO0FBQ04sS0FBQ2pILEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCZ0UsZUFBUyxFQUFFO0FBRGU7QUFEeEIsR0F4QzJCO0FBNkNyQ2YsdUJBQXFCLEVBQUU7QUFDbkIsS0FBQy9HLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCQyxtQkFBYSxFQUFFO0FBRFc7QUFEWCxHQTdDYztBQWtEckNzRCxhQUFXLEVBQUU7QUFDVCxLQUFDckgsS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI5SSxhQUFPLEVBQUU7QUFEaUI7QUFEckIsR0FsRHdCO0FBdURyQ3NNLFVBQVEsRUFBRTtBQUNOLEtBQUN0SCxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjlJLGFBQU8sRUFBRTtBQURpQjtBQUR4QjtBQXZEMkIsQ0FBWixDQUFELENBQTVCO0FBOERld0Usd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDaEVBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU11SSxtQkFBbUIsR0FBRyxNQUFNO0FBQzlCLFFBQU14SSxPQUFPLEdBQUdDLDZFQUFTLEVBQXpCO0FBQ0Esc0JBQ0k7QUFBQSwyQkFDSSxxRUFBQywyREFBRDtBQUFBLDhCQUNJLHFFQUFDLHFEQUFEO0FBQ0ksVUFBRSxFQUFFLEdBRFI7QUFFSSxVQUFFLEVBQUUsQ0FGUjtBQUdJLGdCQUFRLEVBQUMsYUFIYjtBQUlJLGtCQUFVLEVBQUMsaUJBSmY7QUFLSSxhQUFLLEVBQUMsZUFMVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQVNJLHFFQUFDLHNEQUFEO0FBQU0saUJBQVMsTUFBZjtBQUFnQixlQUFPLEVBQUUsQ0FBekI7QUFBQSxrQkFDSyxDQUNHO0FBQ0kwSCxtQkFBUyxFQUFFLGFBRGY7QUFFSTFJLGNBQUksRUFBRTtBQUZWLFNBREgsRUFLRztBQUNJMEksbUJBQVMsRUFBRSxhQURmO0FBRUkxSSxjQUFJLEVBQUUsd0NBRlY7QUFHSXdDLGlCQUFPLEVBQUU7QUFIYixTQUxILEVBVUc7QUFDSWtHLG1CQUFTLEVBQUUsYUFEZjtBQUVJMUksY0FBSSxFQUFFLG9DQUZWO0FBR0l3QyxpQkFBTyxFQUFFO0FBSGIsU0FWSCxFQWVHO0FBQ0lrRyxtQkFBUyxFQUFFLGFBRGY7QUFFSTFJLGNBQUksRUFBRTtBQUZWLFNBZkgsRUFtQkNPLEdBbkJELENBbUJNQyxJQUFELGlCQUNGLHFFQUFDLHNEQUFEO0FBQU0sY0FBSSxNQUFWO0FBQVcsWUFBRSxFQUFFLENBQWY7QUFBa0IsWUFBRSxFQUFFLENBQXRCO0FBQUEsaUNBQ0kscUVBQUMscURBQUQ7QUFDSSxhQUFDLEVBQUUsQ0FEUDtBQUVJLHdCQUFZLEVBQUMsTUFGakI7QUFHSSxjQUFFLEVBQUUsQ0FIUjtBQUlJLHFCQUFTLEVBQUU0QywyQ0FBSSxDQUNYckMsT0FBTyxDQUFDNEgsVUFERyxFQUVYbkksSUFBSSxDQUFDZ0MsT0FBTCxJQUFnQnpCLE9BQU8sQ0FBQ1AsSUFBSSxDQUFDZ0MsT0FBTixDQUZaLENBSm5CO0FBQUEsb0NBUUkscUVBQUMscURBQUQ7QUFBSywwQkFBWSxFQUFDLE1BQWxCO0FBQXlCLGdCQUFFLEVBQUUsQ0FBN0I7QUFBZ0MsdUJBQVMsRUFBRXpCLE9BQU8sQ0FBQzZILFlBQW5EO0FBQUEscUNBQ0kscUVBQUMscURBQUQ7QUFDSSx1QkFBTyxFQUFDLE1BRFo7QUFFSSw4QkFBYyxFQUFDLFFBRm5CO0FBR0ksd0JBQVEsRUFBQyxVQUhiO0FBSUksbUJBQUcsRUFBQyxPQUpSO0FBQUEsdUNBS0kscUVBQUMsaURBQUQ7QUFBTyxxQkFBRyxFQUFFcEksSUFBSSxDQUFDa0ksU0FBakI7QUFBNEIsdUJBQUssRUFBRSxHQUFuQztBQUF3Qyx3QkFBTSxFQUFFO0FBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFSSixlQWlCSSxxRUFBQyxxREFBRDtBQUFBLHFDQUNJLHFFQUFDLHNEQUFEO0FBQU0sb0JBQUksRUFBQyxHQUFYO0FBQWUseUJBQVMsRUFBQyxNQUF6QjtBQUFBLHVDQUNJLHFFQUFDLHFEQUFEO0FBQUsseUJBQU8sRUFBQyxNQUFiO0FBQW9CLDRCQUFVLEVBQUMsUUFBL0I7QUFBQSx5Q0FDSSxxRUFBQyxxREFBRDtBQUFLLDJCQUFPLEVBQUMsTUFBYjtBQUFvQixrQ0FBYyxFQUFDLFlBQW5DO0FBQUEsMkNBQ0kscUVBQUMscURBQUQ7QUFDSSw4QkFBUSxFQUFDLGFBRGI7QUFFSSwyQkFBSyxFQUFDLGVBRlY7QUFHSSxnQ0FBVSxFQUFDLG1CQUhmO0FBSUksd0JBQUUsRUFBRSxDQUpSO0FBQUEsZ0NBS0tsSSxJQUFJLENBQUNSO0FBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLFdBQThCUSxJQUFJLENBQUN1SSxJQUFuQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXBCSDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosbUJBREo7QUF3RUgsQ0ExRUQ7O0FBNEVlUSxrRkFBZixFOzs7Ozs7Ozs7Ozs7QUN2RkE7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU12SSxTQUFTLEdBQUdPLDJFQUFVLENBQUVDLEtBQUQsS0FBWTtBQUNyQ2dILFVBQVEsRUFBRTtBQUNOLEtBQUNoSCxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjlJLGFBQU8sRUFBRTtBQURpQjtBQUR4QixHQUQyQjtBQU1yQ3NJLFNBQU8sRUFBRTtBQUNMLEtBQUN0RCxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjVELHFCQUFlLEVBQUcsR0FBRUYsS0FBSyxDQUFDRyxPQUFOLENBQWNxSCxTQUFkLENBQXdCMUcsS0FBTTtBQUR4QixLQUR6QjtBQUlMLDJCQUF1QjtBQUNuQixPQUFDZCxLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCMUMsdUJBQWUsRUFBRyxHQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY3FILFNBQWQsQ0FBd0IxRyxLQUFNO0FBRHRCO0FBRGI7QUFKbEIsR0FONEI7QUFnQnJDMkcsU0FBTyxFQUFFO0FBQ0wsS0FBQ3pILEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCNUQscUJBQWUsRUFBRyxHQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY3VILE9BQWQsQ0FBc0JDLFVBQVc7QUFEM0IsS0FEekI7QUFJTCwyQkFBdUI7QUFDbkIsT0FBQzNILEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JDLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUIxQyx1QkFBZSxFQUFHLEdBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjdUgsT0FBZCxDQUFzQkMsVUFBVztBQUR6QjtBQURiO0FBSmxCLEdBaEI0QjtBQTBCckNSLFlBQVUsRUFBRTtBQUNSLEtBQUNuSCxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjhELGtCQUFZLEVBQUUsT0FEWTtBQUUxQjFILHFCQUFlLEVBQUVGLEtBQUssQ0FBQ08sTUFBTixDQUFhc0gsZ0JBRko7QUFHMUJoTixhQUFPLEVBQUU7QUFIaUI7QUFEdEIsR0ExQnlCO0FBaUNyQ3VNLGNBQVksRUFBRTtBQUNWbEgsbUJBQWUsRUFBRUYsS0FBSyxDQUFDTyxNQUFOLENBQWFzSCxnQkFEcEI7QUFFVixLQUFDN0gsS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI1RCxxQkFBZSxFQUFFLGFBRFM7QUFFMUIwSCxrQkFBWSxFQUFFO0FBRlk7QUFGcEIsR0FqQ3VCO0FBd0NyQ1gsVUFBUSxFQUFFO0FBQ04sS0FBQ2pILEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCZ0UsZUFBUyxFQUFFO0FBRGU7QUFEeEI7QUF4QzJCLENBQVosQ0FBRCxDQUE1QjtBQStDZXRJLHdFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNd0ksd0JBQXdCLEdBQUcsTUFBTTtBQUNuQyxRQUFNeEIsU0FBUyxHQUFHLENBQ2Q7QUFBRWhJLFFBQUksRUFBRSw0QkFBUjtBQUFzQ0MsUUFBSSxFQUFFb0ksa0RBQUlBO0FBQWhELEdBRGMsRUFFZDtBQUFFckksUUFBSSxFQUFFLGdDQUFSO0FBQTBDQyxRQUFJLEVBQUVxSSxrREFBSUE7QUFBcEQsR0FGYyxFQUdkO0FBQUV0SSxRQUFJLEVBQUUsa0NBQVI7QUFBNENDLFFBQUksRUFBRUUscURBQU9BO0FBQXpELEdBSGMsQ0FBbEI7QUFNQSxzQkFDSTtBQUFBLDRCQUNBLHFFQUFDLHFEQUFEO0FBQUssUUFBRSxFQUFFLEdBQVQ7QUFBQSxpQkFDSyxDQUNHO0FBQUNzSixtQkFBVyxFQUFDLHdCQUFiO0FBQXVDQyxjQUFNLEVBQUM7QUFBOUMsT0FESCxFQUVHO0FBQUNELG1CQUFXLEVBQUMsb0JBQWI7QUFBbUNDLGNBQU0sRUFBQztBQUExQyxPQUZILEVBR0c7QUFBQ0QsbUJBQVcsRUFBQyxZQUFiO0FBQTJCQyxjQUFNLEVBQUM7QUFBbEMsT0FISCxFQUlHO0FBQUNELG1CQUFXLEVBQUMsc0JBQWI7QUFBcUNDLGNBQU0sRUFBQztBQUE1QyxPQUpILEVBS0NuSixHQUxELENBS01DLElBQUQsaUJBQ0YscUVBQUMscURBQUQ7QUFBSyxVQUFFLEVBQUUsQ0FBVDtBQUFBLCtCQUNJLHFFQUFDLG9EQUFEO0FBQ0ksaUJBQU8sRUFBQyxTQURaO0FBRUksbUJBQVMsRUFBRSxJQUZmO0FBR0ksd0JBQWMsRUFBRSxJQUhwQjtBQUlJLHVCQUFhLEVBQUUsSUFKbkI7QUFBQSxrQ0FNSSxxRUFBQyxxREFBRDtBQUNJLGlCQUFLLEVBQUMsY0FEVjtBQUVJLG9CQUFRLEVBQUMsYUFGYjtBQUdJLHNCQUFVLEVBQUMsbUJBSGY7QUFBQSxzQkFJS0EsSUFBSSxDQUFDaUo7QUFKVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU5KLGVBWUkscUVBQUMscURBQUQ7QUFDSSxxQkFBUyxFQUFDLE9BRGQ7QUFFSSxpQkFBSyxFQUFDLGVBRlY7QUFHSSxvQkFBUSxFQUFDLGFBSGI7QUFJSSxzQkFBVSxFQUFDLG9CQUpmO0FBQUEsc0JBS0tqSixJQUFJLENBQUNrSjtBQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosU0FBaUJsSixJQUFJLENBQUNpSixXQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5ILENBREwsZUE4QkkscUVBQUMscURBQUQ7QUFDSSxVQUFFLEVBQUUsQ0FEUjtBQUVJLG1CQUFXLEVBQUMsY0FGaEI7QUFHSSxjQUFNLEVBQUMsWUFIWDtBQUlJLG9CQUFZLEVBQUMsTUFKakI7QUFBQSwrQkFLSSxxRUFBQyxtREFBRDtBQUFZLGtCQUFRLEVBQUMsWUFBckI7QUFBa0Msa0JBQVEsRUFBQyxNQUEzQztBQUFBLGlDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksaUJBQUssRUFBQyxjQURWO0FBRUksb0JBQVEsRUFBQyxhQUZiO0FBR0ksc0JBQVUsRUFBQyxtQkFIZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTlCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREEsZUE4Q0EscUVBQUMscURBQUQ7QUFBQSxnQkFDS3pCLFNBQVMsQ0FBQ3pILEdBQVYsQ0FBZUMsSUFBRCxpQkFDWCxxRUFBQyxxREFBRDtBQUFLLFVBQUUsRUFBRSxDQUFUO0FBQUEsK0JBQ0kscUVBQUMsc0RBQUQ7QUFBTSxjQUFJLEVBQUMsR0FBWDtBQUFlLG1CQUFTLEVBQUMsTUFBekI7QUFBQSxpQ0FDSSxxRUFBQyxxREFBRDtBQUFLLG1CQUFPLEVBQUMsTUFBYjtBQUFvQixzQkFBVSxFQUFDLFFBQS9CO0FBQUEsb0NBQ0kscUVBQUMsSUFBRCxDQUFNLElBQU47QUFDSSx5QkFBVyxFQUFDLEdBRGhCO0FBRUksbUJBQUssRUFBQyxRQUZWO0FBR0ksa0JBQUksRUFBRTtBQUhWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFNSSxxRUFBQyxxREFBRDtBQUNJLHNCQUFRLEVBQUMsYUFEYjtBQUVJLG1CQUFLLEVBQUMsY0FGVjtBQUdJLHdCQUFVLEVBQUMsbUJBSGY7QUFJSSxnQkFBRSxFQUFFLEdBSlI7QUFBQSx3QkFLS0EsSUFBSSxDQUFDUjtBQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLFNBQWlCUSxJQUFJLENBQUNSLElBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQTlDQTtBQUFBLGtCQURKO0FBd0VILENBL0VEOztBQWlGZXdKLHVGQUFmLEU7Ozs7Ozs7Ozs7OztBQzVGQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUcsV0FBVyxHQUFHLENBQUM7QUFBRTVQO0FBQUYsQ0FBRCxLQUFlO0FBQy9CLFFBQU1nSCxPQUFPLEdBQUdDLGtFQUFTLEVBQXpCO0FBQ0Esc0JBQ0kscUVBQUMscURBQUQ7QUFBSyxhQUFTLEVBQUVELE9BQU8sQ0FBQzZJLElBQXhCO0FBQThCLFNBQUssRUFBQyxNQUFwQztBQUFBLDJCQUNJLHFFQUFDLHFEQUFEO0FBQUssV0FBSyxFQUFDLE1BQVg7QUFBQSw4QkFDSSxxRUFBQyxxREFBRDtBQUFLLFVBQUUsRUFBRTdQLEtBQUssS0FBSyxJQUFWLElBQWtCQSxLQUFLLEtBQUssSUFBNUIsR0FBbUMsQ0FBbkMsR0FBdUMsQ0FBaEQ7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxDQUFUO0FBQVksWUFBRSxFQUFFLENBQWhCO0FBQUEsa0NBQ0kscUVBQUMscURBQUQ7QUFDSSxpQkFBSyxFQUFDLGVBRFY7QUFFSSxvQkFBUSxFQUFDLGFBRmI7QUFHSSxzQkFBVSxFQUFDLG1CQUhmO0FBSUksY0FBRSxFQUFFLENBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosZUFRSSxxRUFBQyxxREFBRDtBQUFLLGlCQUFLLEVBQUMsZUFBWDtBQUEyQixvQkFBUSxFQUFDLGFBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQWFJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBQSxrQ0FDSSxxRUFBQyxxREFBRDtBQUNJLGlCQUFLLEVBQUMsZUFEVjtBQUVJLG9CQUFRLEVBQUMsYUFGYjtBQUdJLHNCQUFVLEVBQUMsbUJBSGY7QUFJSSxjQUFFLEVBQUUsQ0FKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESixlQVFJLHFFQUFDLHFEQUFEO0FBQUssaUJBQUssRUFBQyxlQUFYO0FBQTJCLG9CQUFRLEVBQUMsYUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWJKLGVBeUJJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBQSxrQ0FDSSxxRUFBQyxxREFBRDtBQUNJLGlCQUFLLEVBQUMsZUFEVjtBQUVJLG9CQUFRLEVBQUMsYUFGYjtBQUdJLHNCQUFVLEVBQUMsbUJBSGY7QUFJSSxjQUFFLEVBQUUsQ0FKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESixlQVFJLHFFQUFDLHFEQUFEO0FBQUssaUJBQUssRUFBQyxlQUFYO0FBQTJCLG9CQUFRLEVBQUMsYUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXpCSixlQXFDSSxxRUFBQyxxREFBRDtBQUFBLGtDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksaUJBQUssRUFBQyxlQURWO0FBRUksb0JBQVEsRUFBQyxhQUZiO0FBR0ksc0JBQVUsRUFBQyxtQkFIZjtBQUlJLGNBQUUsRUFBRSxDQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBUUkscUVBQUMscURBQUQ7QUFBSyxpQkFBSyxFQUFDLGVBQVg7QUFBMkIsb0JBQVEsRUFBQyxhQUFwQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFSSixlQVdJLHFFQUFDLHFEQUFEO0FBQUssY0FBRSxFQUFFLENBQVQ7QUFBQSxtQ0FDSSxxRUFBQyx3REFBRDtBQUNJLG1CQUFLLEVBQUU7QUFDSCtILHFCQUFLLEVBQUUsUUFESjtBQUVIK0gsd0JBQVEsRUFBRTtBQUZQLGVBRFg7QUFLSSxrQkFBSSxFQUFDLFFBTFQ7QUFNSSx1QkFBUyxFQUFDLFNBTmQ7QUFPSSxxQkFBTyxlQUFFLHFFQUFDLDBEQUFEO0FBQWMscUJBQUssRUFBQyxRQUFwQjtBQUE2QixvQkFBSSxFQUFFO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFyQ0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBK0RJLHFFQUFDLHFEQUFEO0FBQUssaUJBQVMsRUFBRTlJLE9BQU8sQ0FBQytJLEtBQXhCO0FBQUEsK0JBQ0kscUVBQUMsd0RBQUQ7QUFDSSxjQUFJLEVBQUMsT0FEVDtBQUVJLGVBQUssRUFBQyxXQUZWO0FBR0ksaUJBQU8sRUFBQyxXQUhaO0FBSUksbUJBQVMsRUFBRS9QLEtBQUssS0FBSyxJQUFWLElBQWtCQSxLQUFLLEtBQUssSUFBNUIsR0FBbUMsSUFBbkMsR0FBMEMsS0FKekQ7QUFLSSxtQkFBUyxFQUFFcUosMkNBQUksQ0FBQ3JKLEtBQUssS0FBSyxJQUFWLElBQWtCQSxLQUFLLEtBQUssSUFBNUIsR0FBbUMsWUFBbkMsR0FBa0QsRUFBbkQsQ0FMbkI7QUFNSSxtQkFBUyxlQUFFLHFFQUFDLHNEQUFEO0FBQVUsaUJBQUssRUFBQyxRQUFoQjtBQUF5QixnQkFBSSxFQUFFLEVBQS9CO0FBQW1DLHVCQUFXLEVBQUU7QUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFOZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBL0RKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQStFSCxDQWpGRDs7QUFtRkE0UCxXQUFXLENBQUN6SSxTQUFaLEdBQXdCO0FBQ3BCbkgsT0FBSyxFQUFFb0gsaURBQVMsQ0FBQzRJO0FBREcsQ0FBeEI7QUFHZUMsaUlBQVMsR0FBR0wsV0FBSCxDQUF4QixFOzs7Ozs7Ozs7Ozs7QUNuR0E7QUFBQTtBQUFBO0FBQUE7QUFFQSxNQUFNM0ksU0FBUyxHQUFHTywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckNvSSxNQUFJLEVBQUU7QUFDRnBOLFdBQU8sRUFBRSxNQURQO0FBRUZ5SSxjQUFVLEVBQUUsUUFGVjtBQUdGZ0Ysa0JBQWMsRUFBRSxlQUhkO0FBSUY1TixXQUFPLEVBQUUsUUFKUDtBQUtGLEtBQUNtRixLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCOEYsbUJBQWEsRUFBRSxRQURhO0FBRTVCN04sYUFBTyxFQUFFLFlBRm1CO0FBRzVCNEksZ0JBQVUsRUFBRTtBQUhnQjtBQUw5QixHQUQrQjtBQVlyQzZFLE9BQUssRUFBRTtBQUNILEtBQUN0SSxLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCckksY0FBUSxFQUFFLFVBRGtCO0FBRTVCRyxZQUFNLEVBQUUsR0FGb0I7QUFHNUJELFVBQUksRUFBRSxHQUhzQjtBQUk1QkUsV0FBSyxFQUFFLEdBSnFCO0FBSzVCcEMsV0FBSyxFQUFFO0FBTHFCO0FBRDdCO0FBWjhCLENBQVosQ0FBRCxDQUE1QjtBQXVCZWlILHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3pCQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNbUosYUFBYSxHQUFHLENBQUM7QUFBRUMsV0FBRjtBQUFhQztBQUFiLENBQUQsS0FBNEI7QUFDOUMsc0JBQ0k7QUFBQSw0QkFDSSxxRUFBQyw2REFBRDtBQUFhLFFBQUUsRUFBQyxxQkFBaEI7QUFBQSw2QkFDSSxxRUFBQyw0REFBRDtBQUFZLHNCQUFXLE9BQXZCO0FBQStCLGVBQU8sRUFBRUEsT0FBeEM7QUFBQSwrQkFDSSxxRUFBQywrREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREosZUFNSSxxRUFBQywrREFBRDtBQUFBLDZCQUNJLHFFQUFDLHFEQUFEO0FBQUssaUJBQVMsRUFBQyxRQUFmO0FBQXdCLFVBQUUsRUFBRSxHQUE1QjtBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksa0JBQVEsRUFBQyxhQURiO0FBRUksb0JBQVUsRUFBQyxpQkFGZjtBQUdJLGVBQUssRUFBQyxlQUhWO0FBSUksWUFBRSxFQUFFLENBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFRSSxxRUFBQyxxREFBRDtBQUFLLGtCQUFRLEVBQUMsYUFBZDtBQUE0QixlQUFLLEVBQUMsb0JBQWxDO0FBQXVELFlBQUUsRUFBRSxDQUEzRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5KLGVBb0JJLHFFQUFDLHFEQUFEO0FBQUEsOEJBQ0kscUVBQUMsd0RBQUQ7QUFDSSxpQkFBUyxNQURiO0FBRUksWUFBSSxFQUFDLE9BRlQ7QUFHSSxhQUFLLEVBQUMsV0FIVjtBQUlJLGlCQUFTLEVBQUMsWUFKZDtBQUtJLGVBQU8sRUFBQyxXQUxaO0FBTUksYUFBSyxFQUFFO0FBQ0huSSxzQkFBWSxFQUFFO0FBRFgsU0FOWDtBQVNJLGVBQU8sRUFBRWtJLFNBVGI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFhSSxxRUFBQyx3REFBRDtBQUNJLGlCQUFTLE1BRGI7QUFFSSxZQUFJLEVBQUMsT0FGVDtBQUdJLGFBQUssRUFBQyxTQUhWO0FBSUksaUJBQVMsRUFBQyxZQUpkO0FBS0ksZUFBTyxFQUFDLFdBTFo7QUFNSSxlQUFPLEVBQUVDLE9BTmI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXBCSjtBQUFBLGtCQURKO0FBOENILENBL0NEOztBQWdEQUYsYUFBYSxDQUFDakosU0FBZCxHQUEwQjtBQUN0QmtKLFdBQVMsRUFBRWpKLGlEQUFTLENBQUM2QyxJQURDO0FBRXRCcUcsU0FBTyxFQUFFbEosaURBQVMsQ0FBQzZDO0FBRkcsQ0FBMUI7QUFJZW1HLDRFQUFmLEU7Ozs7Ozs7Ozs7OztBQzlEQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUcsTUFBTSxHQUFHLENBQUM7QUFBRXZRO0FBQUYsQ0FBRCxLQUFlO0FBQzFCLFFBQU1nSCxPQUFPLEdBQUdDLDZEQUFTLEVBQXpCO0FBRUEsc0JBQ0kscUVBQUMscURBQUQ7QUFBSyxXQUFPLEVBQUMsY0FBYjtBQUE0QixNQUFFLEVBQUUsQ0FBaEM7QUFBbUMsTUFBRSxFQUFFLENBQXZDO0FBQTBDLE1BQUUsRUFBRSxDQUE5QztBQUFpRCxNQUFFLEVBQUUsQ0FBckQ7QUFBd0QsYUFBUyxFQUFFRCxPQUFPLENBQUN3SixhQUEzRTtBQUFBLDJCQUNJLHFFQUFDLHNEQUFEO0FBQU0sZUFBUyxNQUFmO0FBQWdCLGFBQU8sRUFBRSxDQUF6QjtBQUFBLDhCQUNJLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLEVBQWY7QUFBbUIsVUFBRSxFQUFFLENBQXZCO0FBQUEsZ0NBQ0kscUVBQUMscURBQUQ7QUFBSyxpQkFBTyxFQUFDLE1BQWI7QUFBb0Isb0JBQVUsRUFBQyxRQUEvQjtBQUF3QyxZQUFFLEVBQUUsQ0FBNUM7QUFBK0MsbUJBQVMsRUFBRXhKLE9BQU8sQ0FBQ3lKLFdBQWxFO0FBQUEsa0NBQ0kscUVBQUMscURBQUQ7QUFDSSxtQkFBTyxFQUFDLE1BRFo7QUFFSSwwQkFBYyxFQUFDLFFBRm5CO0FBR0ksY0FBRSxFQUFFLENBSFI7QUFJSSxxQkFBUyxFQUFFekosT0FBTyxDQUFDMEosU0FKdkI7QUFLSSxnQkFBSSxFQUFFMVEsS0FBSyxLQUFLLElBQVYsSUFBa0JBLEtBQUssS0FBSyxJQUE1QixHQUFtQyxVQUFuQyxHQUFnRCxXQUwxRDtBQUFBLG1DQU1JLHFFQUFDLGlEQUFEO0FBQ0ksaUJBQUcsRUFBQyxpQkFEUjtBQUVJLG1CQUFLLEVBQUUsRUFGWDtBQUdJLG9CQUFNLEVBQUUsRUFIWjtBQUlJLHVCQUFTLEVBQUVnSCxPQUFPLENBQUMySjtBQUp2QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESixlQWNJLHFFQUFDLHFEQUFEO0FBQUEsb0NBQ0kscUVBQUMscURBQUQ7QUFDSSxtQkFBSyxFQUFDLGNBRFY7QUFFSSxzQkFBUSxFQUFDLGFBRmI7QUFHSSx1QkFBUyxFQUFDLE1BSGQ7QUFJSSx1QkFBUyxFQUFFM0osT0FBTyxDQUFDNEosV0FKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFRSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsY0FEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsaUJBSGY7QUFJSSx1QkFBUyxFQUFDLE1BSmQ7QUFLSSx1QkFBUyxFQUFFNUosT0FBTyxDQUFDNkosUUFMdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQWlDSSxxRUFBQyxxREFBRDtBQUNJLGlCQUFPLEVBQUMsTUFEWjtBQUVJLFlBQUUsRUFBRSxDQUZSO0FBR0ksWUFBRSxFQUFFLENBSFI7QUFJSSxvQkFBVSxFQUFDLFlBSmY7QUFLSSxtQkFBUyxFQUFFN0osT0FBTyxDQUFDOEosV0FMdkI7QUFBQSxrQ0FNSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFPLEVBQUMsTUFEWjtBQUVJLDBCQUFjLEVBQUMsUUFGbkI7QUFHSSxjQUFFLEVBQUUsQ0FIUjtBQUlJLGdCQUFJLEVBQUU5USxLQUFLLEtBQUssSUFBVixJQUFrQkEsS0FBSyxLQUFLLElBQTVCLEdBQW1DLFFBQW5DLEdBQThDLE1BSnhEO0FBQUEsbUNBS0kscUVBQUMsaURBQUQ7QUFDSSxpQkFBRyxFQUFDLFdBRFI7QUFFSSxtQkFBSyxFQUFFQSxLQUFLLEtBQUssSUFBVixJQUFrQkEsS0FBSyxLQUFLLElBQTVCLEdBQW1DLEVBQW5DLEdBQXdDLEVBRm5EO0FBR0ksb0JBQU0sRUFBRUEsS0FBSyxLQUFLLElBQVYsSUFBa0JBLEtBQUssS0FBSyxJQUE1QixHQUFtQyxFQUFuQyxHQUF3QztBQUhwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFOSixlQWlCSSxxRUFBQyxxREFBRDtBQUFLLGlCQUFLLEVBQUMsY0FBWDtBQUEwQixvQkFBUSxFQUFDLGFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBakNKLGVBc0RJLHFFQUFDLHFEQUFEO0FBQUssbUJBQVMsRUFBRWdILE9BQU8sQ0FBQytKLFdBQXhCO0FBQUEsaUNBQ0kscUVBQUMscURBQUQ7QUFBQSxzQkFDSyxDQUNHO0FBQUU5SyxrQkFBSSxFQUFFO0FBQVIsYUFESCxFQUVHO0FBQUVBLGtCQUFJLEVBQUU7QUFBUixhQUZILEVBR0c7QUFBRUEsa0JBQUksRUFBRTtBQUFSLGFBSEgsRUFJRztBQUFFQSxrQkFBSSxFQUFFO0FBQVIsYUFKSCxFQUtDTyxHQUxELENBS01DLElBQUQsaUJBQ0YscUVBQUMscURBQUQ7QUFBSyxnQkFBRSxFQUFFLEdBQVQ7QUFBQSxxQ0FDSSxxRUFBQyxzREFBRDtBQUFNLG9CQUFJLEVBQUMsR0FBWDtBQUFlLHlCQUFTLEVBQUMsTUFBekI7QUFBQSx1Q0FDSSxxRUFBQyxxREFBRDtBQUFLLHlCQUFPLEVBQUMsTUFBYjtBQUFvQiw0QkFBVSxFQUFDLFFBQS9CO0FBQUEsMENBQ0kscUVBQUMscURBQUQ7QUFBSyw0QkFBUSxFQUFDLGFBQWQ7QUFBNEIseUJBQUssRUFBQyxjQUFsQztBQUFpRCxzQkFBRSxFQUFFLENBQXJEO0FBQUEsOEJBQ0tBLElBQUksQ0FBQ1I7QUFEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQURKLGVBSUkscUVBQUMsMERBQUQ7QUFBYywrQkFBVyxFQUFDLEdBQTFCO0FBQThCLHlCQUFLLEVBQUMsT0FBcEM7QUFBNEMsd0JBQUksRUFBRTtBQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixlQUFtQlEsSUFBSSxDQUFDUixJQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU5IO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdERKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQTZFSSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxDQUF2QjtBQUEwQixpQkFBUyxFQUFFZSxPQUFPLENBQUNnSyxVQUE3QztBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksZUFBSyxFQUFDLGNBRFY7QUFFSSxrQkFBUSxFQUFDLGFBRmI7QUFHSSxvQkFBVSxFQUFDLGlCQUhmO0FBSUksWUFBRSxFQUFFLENBSlI7QUFLSSxZQUFFLEVBQUUsQ0FMUjtBQU1JLG1CQUFTLEVBQUVoSyxPQUFPLENBQUNpSyxTQU52QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQVVJLHFFQUFDLHFEQUFEO0FBQUEsa0NBQ0kscUVBQUMscURBQUQ7QUFBSyxjQUFFLEVBQUUsQ0FBVDtBQUFZLG1CQUFPLEVBQUMsTUFBcEI7QUFBQSxtQ0FDSSxxRUFBQyxzREFBRDtBQUFNLGtCQUFJLEVBQUMsR0FBWDtBQUFlLHVCQUFTLEVBQUMsTUFBekI7QUFBQSxxQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHVCQUFPLEVBQUMsTUFBYjtBQUFvQiwwQkFBVSxFQUFDLFFBQS9CO0FBQUEsd0NBQ0kscUVBQUMscURBQUQ7QUFBSywwQkFBUSxFQUFDLGFBQWQ7QUFBNEIsdUJBQUssRUFBQyxjQUFsQztBQUFpRCxvQkFBRSxFQUFFLENBQXJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQURKLGVBSUkscUVBQUMsMERBQUQ7QUFBYyw2QkFBVyxFQUFDLEdBQTFCO0FBQThCLHVCQUFLLEVBQUMsT0FBcEM7QUFBNEMsc0JBQUksRUFBRTtBQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBWUkscUVBQUMscURBQUQ7QUFBSyxjQUFFLEVBQUUsQ0FBVDtBQUFBLG1DQUNJLHFFQUFDLHFEQUFEO0FBQUsscUJBQU8sRUFBQyxNQUFiO0FBQW9CLHdCQUFVLEVBQUMsUUFBL0I7QUFBQSxxQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHdCQUFRLEVBQUMsYUFBZDtBQUE0QixxQkFBSyxFQUFDLGNBQWxDO0FBQWlELGtCQUFFLEVBQUUsQ0FBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFaSixlQW1CSSxxRUFBQyxxREFBRDtBQUFLLGNBQUUsRUFBRSxDQUFUO0FBQUEsbUNBQ0kscUVBQUMscURBQUQ7QUFBSyxxQkFBTyxFQUFDLE1BQWI7QUFBb0Isd0JBQVUsRUFBQyxRQUEvQjtBQUFBLHFDQUNJLHFFQUFDLHFEQUFEO0FBQUssd0JBQVEsRUFBQyxhQUFkO0FBQTRCLHFCQUFLLEVBQUMsY0FBbEM7QUFBaUQsa0JBQUUsRUFBRSxDQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQW5CSixlQTBCSSxxRUFBQyxxREFBRDtBQUFLLGNBQUUsRUFBRSxDQUFUO0FBQVksY0FBRSxFQUFFLENBQWhCO0FBQUEsbUNBQ0kscUVBQUMsd0RBQUQ7QUFDSSxrQkFBSSxFQUNBalIsS0FBSyxLQUFLLElBQVYsSUFBa0JBLEtBQUssS0FBSyxJQUE1QixJQUFvQ0EsS0FBSyxLQUFLLElBQTlDLEdBQ00sT0FETixHQUVNLE9BSmQ7QUFNSSxtQkFBSyxFQUFDLFNBTlY7QUFPSSxxQkFBTyxFQUFDLFdBUFo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTFCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdFSixlQStISSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxDQUF2QjtBQUEwQixpQkFBUyxFQUFFZ0gsT0FBTyxDQUFDZ0ssVUFBN0M7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUNJLGVBQUssRUFBQyxjQURWO0FBRUksa0JBQVEsRUFBQyxhQUZiO0FBR0ksb0JBQVUsRUFBQyxpQkFIZjtBQUlJLFlBQUUsRUFBRSxDQUpSO0FBS0ksWUFBRSxFQUFFLENBTFI7QUFNSSxtQkFBUyxFQUFFaEssT0FBTyxDQUFDaUssU0FOdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFVSSxxRUFBQyxxREFBRDtBQUFBLG9CQUNLLENBQ0c7QUFBRWhMLGdCQUFJLEVBQUU7QUFBUixXQURILEVBRUc7QUFBRUEsZ0JBQUksRUFBRTtBQUFSLFdBRkgsRUFHRztBQUFFQSxnQkFBSSxFQUFFO0FBQVIsV0FISCxFQUlHO0FBQUVBLGdCQUFJLEVBQUU7QUFBUixXQUpILEVBS0NPLEdBTEQsQ0FLTUMsSUFBRCxpQkFDRixxRUFBQyxxREFBRDtBQUFLLGNBQUUsRUFBRSxDQUFUO0FBQVksbUJBQU8sRUFBQyxNQUFwQjtBQUFBLG1DQUNJLHFFQUFDLHNEQUFEO0FBQU0sa0JBQUksRUFBQyxHQUFYO0FBQWUsdUJBQVMsRUFBQyxNQUF6QjtBQUFBLHFDQUNJLHFFQUFDLHFEQUFEO0FBQUssdUJBQU8sRUFBQyxNQUFiO0FBQW9CLDBCQUFVLEVBQUMsUUFBL0I7QUFBQSx3Q0FDSSxxRUFBQyxxREFBRDtBQUFLLDBCQUFRLEVBQUMsYUFBZDtBQUE0Qix1QkFBSyxFQUFDLGNBQWxDO0FBQWlELG9CQUFFLEVBQUUsQ0FBckQ7QUFBQSw0QkFDS0EsSUFBSSxDQUFDUjtBQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUFJSSxxRUFBQywwREFBRDtBQUFjLDZCQUFXLEVBQUMsR0FBMUI7QUFBOEIsdUJBQUssRUFBQyxPQUFwQztBQUE0QyxzQkFBSSxFQUFFO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLGFBQWdDUSxJQUFJLENBQUNSLElBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTkg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEvSEosZUE2SkkscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsQ0FBdkI7QUFBMEIsaUJBQVMsRUFBRWUsT0FBTyxDQUFDZ0ssVUFBN0M7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUNJLGVBQUssRUFBQyxjQURWO0FBRUksa0JBQVEsRUFBQyxhQUZiO0FBR0ksb0JBQVUsRUFBQyxpQkFIZjtBQUlJLFlBQUUsRUFBRSxDQUpSO0FBS0ksWUFBRSxFQUFFLENBTFI7QUFNSSxtQkFBUyxFQUFFaEssT0FBTyxDQUFDaUssU0FOdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFVSSxxRUFBQyxxREFBRDtBQUFBLG9CQUNLLENBQ0c7QUFBRWhMLGdCQUFJLEVBQUU7QUFBUixXQURILEVBRUc7QUFBRUEsZ0JBQUksRUFBRTtBQUFSLFdBRkgsRUFHRztBQUFFQSxnQkFBSSxFQUFFO0FBQVIsV0FISCxFQUlHO0FBQUVBLGdCQUFJLEVBQUU7QUFBUixXQUpILEVBS0NPLEdBTEQsQ0FLTUMsSUFBRCxpQkFDRixxRUFBQyxxREFBRDtBQUFLLGNBQUUsRUFBRSxDQUFUO0FBQVksbUJBQU8sRUFBQyxNQUFwQjtBQUFBLG1DQUNJLHFFQUFDLHNEQUFEO0FBQU0sa0JBQUksRUFBQyxHQUFYO0FBQWUsdUJBQVMsRUFBQyxNQUF6QjtBQUFBLHFDQUNJLHFFQUFDLHFEQUFEO0FBQUssdUJBQU8sRUFBQyxNQUFiO0FBQW9CLDBCQUFVLEVBQUMsUUFBL0I7QUFBQSx3Q0FDSSxxRUFBQyxxREFBRDtBQUFLLDBCQUFRLEVBQUMsYUFBZDtBQUE0Qix1QkFBSyxFQUFDLGNBQWxDO0FBQWlELG9CQUFFLEVBQUUsQ0FBckQ7QUFBQSw0QkFDS0EsSUFBSSxDQUFDUjtBQURWO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREosZUFJSSxxRUFBQywwREFBRDtBQUFjLDZCQUFXLEVBQUMsR0FBMUI7QUFBOEIsdUJBQUssRUFBQyxPQUFwQztBQUE0QyxzQkFBSSxFQUFFO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLGFBQWdDUSxJQUFJLENBQUNSLElBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTkg7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE3Sko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBZ01ILENBbk1EOztBQW9NQXNLLE1BQU0sQ0FBQ3BKLFNBQVAsR0FBbUI7QUFDZm5ILE9BQUssRUFBRW9ILGlEQUFTLENBQUM0STtBQURGLENBQW5CO0FBR2VDLGlJQUFTLEdBQUdNLE1BQUgsQ0FBeEIsRTs7Ozs7Ozs7Ozs7O0FDbk5BO0FBQUE7QUFBQTtBQUFBO0FBRUEsTUFBTXRKLFNBQVMsR0FBR08sMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3JDK0ksZUFBYSxFQUFFO0FBQ1gsS0FBQy9JLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCakosYUFBTyxFQUFFO0FBRGlCO0FBRG5CLEdBRHNCO0FBTXJDMk8sV0FBUyxFQUFFO0FBQ1B6RCxnQkFBWSxFQUFHLGFBQVkvRixLQUFLLENBQUNHLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQnVILFVBQVc7QUFEckQsR0FOMEI7QUFTckM0QixZQUFVLEVBQUU7QUFDUnZPLFdBQU8sRUFBRSxNQUREO0FBRVIsS0FBQ2dGLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCOUksYUFBTyxFQUFFO0FBRGlCLEtBRnRCO0FBS1IsdUJBQWtCO0FBQ2QsaUJBQVc7QUFDUHNGLGFBQUssRUFBRU4sS0FBSyxDQUFDRyxPQUFOLENBQWNtRCxPQUFkLENBQXNCeEM7QUFEdEI7QUFERztBQUxWLEdBVHlCO0FBb0JyQ2tJLGFBQVcsRUFBRTtBQUNULEtBQUNoSixLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCbUQsa0JBQVksRUFBRyxhQUFZL0YsS0FBSyxDQUFDRyxPQUFOLENBQWNDLE9BQWQsQ0FBc0J1SCxVQUFXO0FBRGhDLEtBRHZCO0FBSVQsS0FBQzNILEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCNEUsbUJBQWEsRUFBRSxRQURXO0FBRTFCN04sYUFBTyxFQUFFLENBRmlCO0FBRzFCQyxZQUFNLEVBQUU7QUFIa0I7QUFKckIsR0FwQndCO0FBOEJyQ3NPLFVBQVEsRUFBRTtBQUNOLEtBQUNwSixLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQnVFLGNBQVEsRUFBRXJJLEtBQUssQ0FBQ3lKLFVBQU4sQ0FBaUJDLEVBQWpCLENBQW9CckIsUUFESjtBQUUxQnNCLGVBQVMsRUFBRSxRQUZlO0FBRzFCeE8sY0FBUSxFQUFFO0FBSGdCO0FBRHhCLEdBOUIyQjtBQXFDckM4TixXQUFTLEVBQUU7QUFDUCxLQUFDakosS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI4RCxrQkFBWSxFQUFFLE1BRFk7QUFFMUIsaUJBQVc7QUFDUGdDLG1CQUFXLEVBQUUsQ0FETjtBQUVQLG9CQUFZO0FBQ1IscUJBQVc7QUFDUDNPLGtCQUFNLEVBQUUsT0FERDtBQUVQMUMsaUJBQUssRUFBRTtBQUZBO0FBREg7QUFGTDtBQUZlLEtBRHZCO0FBYVAsS0FBQ3lILEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JDLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUIsaUJBQVc7QUFDUCxvQkFBWTtBQUNSLHFCQUFXO0FBQ1AzSCxrQkFBTSxFQUFFLE1BREQ7QUFFUDFDLGlCQUFLLEVBQUU7QUFGQTtBQURIO0FBREw7QUFEaUI7QUFiekIsR0FyQzBCO0FBNkRyQzRRLGFBQVcsRUFBRTtBQUNUVSxhQUFTLEVBQUUsUUFERjtBQUVULEtBQUM3SixLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjlJLGFBQU8sRUFBRTtBQURpQjtBQUZyQixHQTdEd0I7QUFtRXJDc08sYUFBVyxFQUFFO0FBQ1QsS0FBQ3RKLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCOUksYUFBTyxFQUFFO0FBRGlCO0FBRHJCLEdBbkV3QjtBQXdFckNxTyxhQUFXLEVBQUU7QUFDVCxLQUFDckosS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI5SSxhQUFPLEVBQUU7QUFEaUI7QUFEckI7QUF4RXdCLENBQVosQ0FBRCxDQUE1QjtBQStFZXdFLHdFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pGQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1zSyxTQUFTLEdBQUcsTUFBTTtBQUNwQixRQUFNdkssT0FBTyxHQUFHQyxnRUFBUyxFQUF6QjtBQUVBLHNCQUNJLHFFQUFDLHFEQUFEO0FBQUssV0FBTyxFQUFDLHVCQUFiO0FBQXFDLEtBQUMsRUFBRSxDQUF4QztBQUEyQyxhQUFTLEVBQUVELE9BQU8sQ0FBQ3dLLGdCQUE5RDtBQUFBLDJCQUNJLHFFQUFDLHFEQUFEO0FBQUssYUFBTyxFQUFDLE1BQWI7QUFBb0IsZ0JBQVUsRUFBQyxRQUEvQjtBQUF3QyxvQkFBYyxFQUFDLGVBQXZEO0FBQXVFLGNBQVEsRUFBQyxNQUFoRjtBQUFBLDhCQUNJLHFFQUFDLHFEQUFEO0FBQUssZUFBTyxFQUFDLE1BQWI7QUFBb0Isa0JBQVUsRUFBQyxRQUEvQjtBQUF3QyxpQkFBUyxFQUFFeEssT0FBTyxDQUFDOEosV0FBM0Q7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUFLLGlCQUFPLEVBQUMsTUFBYjtBQUFvQix3QkFBYyxFQUFDLFFBQW5DO0FBQTRDLFlBQUUsRUFBRSxDQUFoRDtBQUFBLGlDQUNJLHFFQUFDLGlEQUFEO0FBQU8sZUFBRyxFQUFDLFdBQVg7QUFBdUIsaUJBQUssRUFBRSxFQUE5QjtBQUFrQyxrQkFBTSxFQUFFO0FBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBSUkscUVBQUMscURBQUQ7QUFBSyxlQUFLLEVBQUMsY0FBWDtBQUEwQixrQkFBUSxFQUFDLGFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQVNJLHFFQUFDLHFEQUFEO0FBQ0ksZUFBTyxFQUFDLE1BRFo7QUFFSSxrQkFBVSxFQUFDLFlBRmY7QUFHSSxxQkFBYSxFQUFDLFFBSGxCO0FBSUksa0JBQVUsRUFBQyxNQUpmO0FBS0ksaUJBQVMsRUFBRTlKLE9BQU8sQ0FBQ3lLLGFBTHZCO0FBQUEsZ0NBTUkscUVBQUMscURBQUQ7QUFBSyxlQUFLLEVBQUMsY0FBWDtBQUEwQixrQkFBUSxFQUFDLGFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU5KLGVBU0kscUVBQUMscURBQUQ7QUFDSSxpQkFBTyxFQUFDLE1BRFo7QUFFSSxlQUFLLEVBQUMsY0FGVjtBQUdJLGtCQUFRLEVBQUMsYUFIYjtBQUlJLFlBQUUsRUFBRSxHQUpSO0FBS0ksWUFBRSxFQUFFLEdBTFI7QUFNSSxtQkFBUyxFQUFFekssT0FBTyxDQUFDMEssT0FOdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVEosZUFrQkkscUVBQUMscURBQUQ7QUFBSyxlQUFLLEVBQUMsY0FBWDtBQUEwQixrQkFBUSxFQUFDLGFBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWxCSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBb0NILENBdkNEOztBQXlDZUgsd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDbkRBO0FBQUE7QUFBQTtBQUFBO0FBRUEsTUFBTXRLLFNBQVMsR0FBR08sMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3JDcUosYUFBVyxFQUFFO0FBQ1QsS0FBQ3JKLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCOUksYUFBTyxFQUFFLE1BRGlCO0FBRTFCNE0sa0JBQVksRUFBRTtBQUZZO0FBRHJCLEdBRHdCO0FBT3JDbUMsa0JBQWdCLEVBQUU7QUFDZCxLQUFDL0osS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUJqSixhQUFPLEVBQUU7QUFEaUI7QUFEaEIsR0FQbUI7QUFZckNtUCxlQUFhLEVBQUU7QUFDWCxLQUFDaEssS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI0RSxtQkFBYSxFQUFFLEtBRFc7QUFFMUJqRixnQkFBVSxFQUFFLFFBRmM7QUFHMUJ5RyxnQkFBVSxFQUFFLFFBSGM7QUFJMUJ0QyxrQkFBWSxFQUFFO0FBSlk7QUFEbkIsR0Fac0I7QUFvQnJDcUMsU0FBTyxFQUFFO0FBQ0wsS0FBQ2pLLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCOUksYUFBTyxFQUFFO0FBRGlCO0FBRHpCO0FBcEI0QixDQUFaLENBQUQsQ0FBNUI7QUEyQmV3RSx3RUFBZixFOzs7Ozs7Ozs7Ozs7QUM3QkE7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNMkssVUFBVSxHQUFHLENBQUM7QUFDaEJDLFlBRGdCO0FBRWhCQyxVQUZnQjtBQUdoQkMsZ0JBSGdCO0FBSWhCbkosYUFKZ0I7QUFLaEJvSixhQUxnQjtBQU1oQjNMLE9BTmdCO0FBT2hCNEwsV0FQZ0I7QUFRaEJDO0FBUmdCLENBQUQsS0FTYjtBQUNGLFFBQU07QUFBQSxPQUFDQyxRQUFEO0FBQUEsT0FBV0M7QUFBWCxNQUEwQnZHLHNEQUFRLENBQUMsS0FBRCxDQUF4Qzs7QUFDQSxRQUFNd0csV0FBVyxHQUFHLE1BQU07QUFDdEJELGVBQVcsQ0FBQyxJQUFELENBQVg7QUFDSCxHQUZEOztBQUdBLFFBQU1wTCxPQUFPLEdBQUdDLGtFQUFTLEVBQXpCO0FBQ0EsUUFBTXFMLFVBQVUsR0FBR0Msc0VBQWEsQ0FBQyxvQkFBRCxDQUFoQztBQUNBLFFBQU14SyxLQUFLLEdBQUc4SixVQUFVLEdBQUcsY0FBSCxHQUFvQixlQUE1QztBQUNBLFFBQU1XLFdBQVcsR0FBR1gsVUFBVSxHQUFHLFdBQUgsR0FBaUIsU0FBL0M7QUFDQSxRQUFNWSxXQUFXLEdBQUdaLFVBQVUsR0FBRyxhQUFILEdBQW1CLFFBQWpEO0FBQ0EsUUFBTWEsYUFBYSxHQUFHLENBQ2xCO0FBQ0lDLFlBQVEsRUFBRTtBQURkLEdBRGtCLEVBSWxCO0FBQ0lBLFlBQVEsRUFBRTtBQURkLEdBSmtCLEVBT2xCO0FBQ0lBLFlBQVEsRUFBRTtBQURkLEdBUGtCLENBQXRCOztBQVlBLFFBQU1DLGVBQWUsR0FBRyxNQUFNO0FBQzFCLFVBQU07QUFBRUM7QUFBRixRQUFpQkMseUVBQXZCO0FBQ0FDLHNEQUFNLENBQUNDLElBQVAsQ0FBWUgsVUFBVSxDQUFDSSxLQUF2QjtBQUNILEdBSEQ7O0FBS0Esc0JBQ0kscUVBQUMscURBQUQ7QUFDSSxXQUFPLEVBQUUsQ0FEYjtBQUVJLFdBQU8sRUFBQyxjQUZaO0FBR0ksYUFBUyxFQUFFLENBSGY7QUFJSSxhQUFTLEVBQUU1SiwyQ0FBSSxDQUFDd0ksVUFBVSxJQUFJN0ssT0FBTyxDQUFDa00saUJBQXZCLENBSm5CO0FBQUEsNEJBS0kscUVBQUMscURBQUQ7QUFDSSxhQUFPLEVBQUMsTUFEWjtBQUVJLGdCQUFVLEVBQUMsUUFGZjtBQUdJLG9CQUFjLEVBQUMsZUFIbkI7QUFJSSxlQUFTLEVBQUV0SyxXQUFXLElBQUlzSixjQUFmLEdBQWdDbEwsT0FBTyxDQUFDbU0sYUFBeEMsR0FBd0QsRUFKdkU7QUFBQSw4QkFLSSxxRUFBQyxxREFBRDtBQUFLLGVBQU8sRUFBQyxNQUFiO0FBQW9CLGtCQUFVLEVBQUMsUUFBL0I7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUFLLGlCQUFPLEVBQUMsTUFBYjtBQUFvQixvQkFBVSxFQUFDLFFBQS9CO0FBQXdDLFlBQUUsRUFBRWIsVUFBVSxHQUFHLENBQUgsR0FBTyxDQUE3RDtBQUFBLGtDQUNJLHFFQUFDLHFEQUFEO0FBQUssbUJBQU8sRUFBQyxNQUFiO0FBQW9CLHFCQUFTLEVBQUV0TCxPQUFPLENBQUMwSixTQUF2QztBQUFBLG1DQUNJLHFFQUFDLGlEQUFEO0FBQU8saUJBQUcsRUFBQyxXQUFYO0FBQXVCLG1CQUFLLEVBQUUsRUFBOUI7QUFBa0Msb0JBQU0sRUFBRTtBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESixlQUlJLHFFQUFDLHFEQUFEO0FBQUssbUJBQU8sRUFBRTRCLFVBQVUsR0FBRyxNQUFILEdBQVksTUFBcEM7QUFBQSxzQkFDSyxDQUFDMUosV0FBRCxnQkFDRyxxRUFBQyw0REFBRDtBQUFZLHVCQUFTLEVBQUU1QixPQUFPLENBQUNvTSxVQUEvQjtBQUEyQyxxQkFBTyxFQUFFZixXQUFwRDtBQUFBLHFDQUNJLHFFQUFDLGtEQUFEO0FBQU0sMkJBQVcsRUFBQyxHQUFsQjtBQUFzQixxQkFBSyxFQUFDLFFBQTVCO0FBQXFDLG9CQUFJLEVBQUU7QUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREgsZ0JBS0cscUVBQUMsNERBQUQ7QUFBWSx1QkFBUyxFQUFFckwsT0FBTyxDQUFDb00sVUFBL0I7QUFBMkMscUJBQU8sRUFBRWYsV0FBcEQ7QUFBQSxxQ0FDSSxxRUFBQyxrREFBRDtBQUFNLDJCQUFXLEVBQUMsR0FBbEI7QUFBc0IscUJBQUssRUFBQyxRQUE1QjtBQUFxQyxvQkFBSSxFQUFFO0FBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFpQkkscUVBQUMsc0VBQUQ7QUFDSSxlQUFLLEVBQUVoTSxLQURYO0FBRUksbUJBQVMsRUFBRTRMLFNBRmY7QUFHSSxvQkFBVSxFQUFFSixVQUhoQjtBQUlJLG9CQUFVLEVBQUVTO0FBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMSixlQTZCSSxxRUFBQyxxREFBRDtBQUFLLGVBQU8sRUFBQyxNQUFiO0FBQW9CLGtCQUFVLEVBQUMsUUFBL0I7QUFBd0MsVUFBRSxFQUFFQSxVQUFVLEdBQUcsQ0FBSCxHQUFPLENBQTdEO0FBQUEsZ0NBQ0kscUVBQUMscURBQUQ7QUFDSSxpQkFBTyxFQUFDLE1BRFo7QUFFSSxvQkFBVSxFQUFDLFFBRmY7QUFHSSxZQUFFLEVBQUVULFVBQVUsR0FBRyxDQUFILEdBQU8sR0FIekI7QUFJSSxtQkFBUyxFQUFFN0ssT0FBTyxDQUFDcU0sV0FKdkI7QUFBQSxvQkFLS1gsYUFBYSxDQUFDbE0sR0FBZCxDQUFrQixDQUFDQyxJQUFELEVBQU9tRyxLQUFQLGtCQUNmLHFFQUFDLHFEQUFEO0FBRUksY0FBRSxFQUFFQSxLQUFLLEtBQUs4RixhQUFhLENBQUNZLE1BQWQsR0FBdUIsQ0FBakMsSUFBc0MsQ0FGOUM7QUFHSSxvQkFBUSxFQUFDLE1BSGI7QUFBQSxtQ0FJSSxxRUFBQyxzREFBRDtBQUFNLGtCQUFJLEVBQUMsR0FBWDtBQUFlLHVCQUFTLEVBQUMsTUFBekI7QUFBQSxxQ0FDSSxxRUFBQyxxREFBRDtBQUNJLHdCQUFRLEVBQUMsYUFEYjtBQUVJLDBCQUFVLEVBQUMsbUJBRmY7QUFHSSxxQkFBSyxFQUFFdkwsS0FIWDtBQUlJLHlCQUFTLEVBQUVmLE9BQU8sQ0FBQzJMLFFBSnZCO0FBQUEsMEJBS0tsTSxJQUFJLENBQUNrTTtBQUxWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkosYUFDU2xNLElBQUksQ0FBQ2tNLFFBRGQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESDtBQUxMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosRUF3QkssQ0FBQ2QsVUFBRCxJQUFlUyxVQUFmLGdCQUNHLHFFQUFDLHdEQUFEO0FBQ0ksaUJBQU8sRUFBRSxNQUFNTSxlQUFlLEVBRGxDO0FBRUksY0FBSSxFQUFFTixVQUFVLEdBQUcsT0FBSCxHQUFhLE9BRmpDO0FBR0ksZUFBSyxFQUFFRSxXQUhYO0FBSUksaUJBQU8sRUFBQyxXQUpaO0FBQUEsb0JBS0tDO0FBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESCxHQVFHLElBaENSLEVBaUNLWixVQUFVLGdCQUNQLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBQSxpQ0FDSSxxRUFBQyw4REFBRDtBQUFPLHdCQUFZLEVBQUUsQ0FBckI7QUFBd0IsaUJBQUssRUFBQyxPQUE5QjtBQUFBLG1DQUNJLHFFQUFDLGtEQUFEO0FBQU0seUJBQVcsRUFBQyxHQUFsQjtBQUFzQixtQkFBSyxFQUFDLE9BQTVCO0FBQW9DLGtCQUFJLEVBQUUsRUFBMUM7QUFBOEMsa0JBQUksRUFBQztBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRE8sR0FNUCxJQXZDUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBN0JKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMSixFQTRFS0MsUUFBUSxpQkFDTCxxRUFBQyxxREFBRDtBQUNJLGFBQU8sRUFBQyxNQURaO0FBRUksbUJBQWEsRUFBQyxRQUZsQjtBQUdJLGVBQVMsRUFBQyxRQUhkO0FBSUksUUFBRSxFQUFFUSxVQUFVLEdBQUcsQ0FBSCxHQUFPLENBSnpCO0FBS0ksUUFBRSxFQUFFQSxVQUFVLEdBQUcsQ0FBSCxHQUFPLEVBTHpCO0FBTUksV0FBSyxFQUFDLGNBTlY7QUFPSSxlQUFTLEVBQUUxSixXQUFXLEdBQUc1QixPQUFPLENBQUNtTSxhQUFYLEdBQTJCLEVBUHJEO0FBQUEsOEJBUUkscUVBQUMscURBQUQ7QUFDSSxrQkFBVSxFQUFDLEtBRGY7QUFFSSxnQkFBUSxFQUFFYixVQUFVLEdBQUcsYUFBSCxHQUFtQixhQUYzQztBQUdJLGtCQUFVLEVBQUMsaUJBSGY7QUFJSSxVQUFFLEVBQUUsQ0FKUjtBQUFBLGtCQUtLUjtBQUxMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUkosZUFlSSxxRUFBQyxxREFBRDtBQUNJLGdCQUFRLEVBQUVRLFVBQVUsR0FBRyxhQUFILEdBQW1CLGFBRDNDO0FBRUksa0JBQVUsRUFBRUEsVUFBVSxHQUFHLE1BQUgsR0FBWSxNQUZ0QztBQUdJLGFBQUssRUFBQyxjQUhWO0FBSUksZ0JBQVEsRUFBQyxPQUpiO0FBS0ksY0FBTSxFQUFDLFFBTFg7QUFBQSxrQkFNS1A7QUFOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE3RVIsRUF1R0ssQ0FBQ25KLFdBQVcsSUFBSXNKLGNBQWhCLGtCQUNHLHFFQUFDLHFEQUFEO0FBQ0ksYUFBTyxFQUFDLE1BRFo7QUFFSSxnQkFBVSxFQUFDLFFBRmY7QUFHSSxlQUFTLEVBQUV0SixXQUFXLElBQUlzSixjQUFmLEdBQWdDbEwsT0FBTyxDQUFDdU0sY0FBeEMsR0FBeUQsRUFIeEU7QUFBQSw4QkFJSSxxRUFBQyw0REFBRDtBQUFZLGlCQUFTLEVBQUV2TSxPQUFPLENBQUNvTSxVQUEvQjtBQUEyQyxlQUFPLEVBQUVmLFdBQXBEO0FBQUEsa0JBQ0t6SixXQUFXLGdCQUNSLHFFQUFDLHlEQUFEO0FBQWEscUJBQVcsRUFBQyxHQUF6QjtBQUE2QixlQUFLLEVBQUMsUUFBbkM7QUFBNEMsY0FBSSxFQUFFO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRFEsZ0JBR1IscUVBQUMsa0RBQUQ7QUFBTSxxQkFBVyxFQUFDLEdBQWxCO0FBQXNCLGVBQUssRUFBQyxRQUE1QjtBQUFxQyxjQUFJLEVBQUU7QUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkosZUFXSSxxRUFBQyxxREFBRDtBQUNJLGdCQUFRLEVBQUMsYUFEYjtBQUVJLGtCQUFVLEVBQUMsc0JBRmY7QUFHSSxhQUFLLEVBQUViLEtBSFg7QUFJSSxnQkFBUSxFQUFDLFFBSmI7QUFLSSxrQkFBVSxFQUFDLFFBTGY7QUFNSSxnQkFBUSxFQUFDLE9BTmI7QUFPSSxvQkFBWSxFQUFDLFVBUGpCO0FBUUksbUJBQVcsRUFBRSxHQVJqQjtBQVNJLGlCQUFTLEVBQUVmLE9BQU8sQ0FBQ1gsS0FUdkI7QUFBQSxrQkFVSzJMO0FBVkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFYSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBeEdSLEVBaUlLRyxRQUFRLGlCQUFJLHFFQUFDLDZFQUFEO0FBQVksaUJBQVcsRUFBRSxLQUF6QjtBQUFnQyxpQkFBVyxFQUFFQztBQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWpJakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFxSUgsQ0F6S0Q7O0FBMktBUixVQUFVLENBQUMxSyxZQUFYLEdBQTBCO0FBQ3RCMEIsYUFBVyxFQUFFLEtBRFM7QUFFdEJvSixhQUFXLEVBQUUsR0FGUztBQUd0QjNMLE9BQUssRUFBRSxTQUhlO0FBSXRCNEwsV0FBUyxFQUFFO0FBSlcsQ0FBMUI7QUFNQUwsVUFBVSxDQUFDekssU0FBWCxHQUF1QjtBQUNuQjBLLFlBQVUsRUFBRXpLLGlEQUFTLENBQUNHLElBREg7QUFFbkJ1SyxVQUFRLEVBQUUxSyxpREFBUyxDQUFDNEksTUFGRDtBQUduQitCLGdCQUFjLEVBQUUzSyxpREFBUyxDQUFDNEksTUFIUDtBQUluQnBILGFBQVcsRUFBRXhCLGlEQUFTLENBQUNHLElBSko7QUFLbkJ5SyxhQUFXLEVBQUU1SyxpREFBUyxDQUFDNEksTUFMSjtBQU1uQjNKLE9BQUssRUFBRWUsaURBQVMsQ0FBQzRJLE1BTkU7QUFPbkJpQyxXQUFTLEVBQUU3SyxpREFBUyxDQUFDNEksTUFQRjtBQVFuQmtDLGdCQUFjLEVBQUU5SyxpREFBUyxDQUFDRztBQVJQLENBQXZCO0FBV2VxSyx5RUFBZixFOzs7Ozs7Ozs7Ozs7QUNoTkE7QUFBQTtBQUFBO0FBQUE7QUFFQSxNQUFNM0ssU0FBUyxHQUFHTywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckN5TCxtQkFBaUIsRUFBRTtBQUNmcEksbUJBQWUsRUFBRSxvQkFERjtBQUVmMEksb0JBQWdCLEVBQUUsV0FGSDtBQUdmM0ksc0JBQWtCLEVBQUUsUUFITDtBQUlmRCxrQkFBYyxFQUFFLE9BSkQ7QUFLZjZJLDBCQUFzQixFQUFFaE0sS0FBSyxDQUFDaU0sT0FBTixDQUFjLElBQWQsQ0FMVDtBQU1mQywyQkFBdUIsRUFBRWxNLEtBQUssQ0FBQ2lNLE9BQU4sQ0FBYyxJQUFkO0FBTlYsR0FEa0I7QUFTckNoRCxXQUFTLEVBQUU7QUFDUCxLQUFDakosS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI5SSxhQUFPLEVBQUU7QUFEaUI7QUFEdkIsR0FUMEI7QUFjckM0USxhQUFXLEVBQUU7QUFDVCxLQUFDNUwsS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI5SSxhQUFPLEVBQUU7QUFEaUI7QUFEckIsR0Fkd0I7QUFtQnJDMlEsWUFBVSxFQUFFO0FBQ1J6TCxtQkFBZSxFQUFFRixLQUFLLENBQUNPLE1BQU4sQ0FBYUMsS0FEdEI7QUFFUixlQUFXO0FBQ1BOLHFCQUFlLEVBQUVGLEtBQUssQ0FBQ08sTUFBTixDQUFhQztBQUR2QjtBQUZILEdBbkJ5QjtBQXlCckMwSyxVQUFRLEVBQUU7QUFDTixlQUFXO0FBQ1A1SyxXQUFLLEVBQUVOLEtBQUssQ0FBQ0csT0FBTixDQUFjbUQsT0FBZCxDQUFzQnhDO0FBRHRCO0FBREwsR0F6QjJCO0FBOEJyQzBKLFdBQVMsRUFBRTtBQUNQLEtBQUN4SyxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjlJLGFBQU8sRUFBRTtBQURpQjtBQUR2QixHQTlCMEI7QUFtQ3JDNEQsT0FBSyxFQUFFO0FBQ0gsS0FBQ29CLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCdUUsY0FBUSxFQUFFckksS0FBSyxDQUFDeUosVUFBTixDQUFpQjBDLEVBQWpCLENBQW9COUQ7QUFESjtBQUQzQixHQW5DOEI7QUF3Q3JDeUQsZ0JBQWMsRUFBRTtBQUNaLEtBQUM5TCxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjlJLGFBQU8sRUFBRTtBQURpQixLQURsQjtBQUlaQSxXQUFPLEVBQUU7QUFKRyxHQXhDcUI7QUE4Q3JDMFEsZUFBYSxFQUFFO0FBQ1gsS0FBQzFMLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JDLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUI1SCxhQUFPLEVBQUU7QUFEbUI7QUFEckI7QUE5Q3NCLENBQVosQ0FBRCxDQUE1QjtBQXFEZXdFLHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3ZEQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFNQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU00TSxVQUFVLEdBQUcsQ0FBQztBQUFFQyxhQUFGO0FBQWUxQjtBQUFmLENBQUQsS0FBa0M7QUFDakQsUUFBTTtBQUFBLE9BQUMyQixjQUFEO0FBQUEsT0FBaUJDO0FBQWpCLE1BQXNDbkksc0RBQVEsQ0FBQyxJQUFELENBQXBEO0FBQ0EsUUFBTTdFLE9BQU8sR0FBR0MsaUVBQVMsRUFBekI7QUFFQSxRQUFNZ04sS0FBSyxHQUFHSCxXQUFXLEdBQUdJLHdFQUFILEdBQTBCakcsNkRBQW5EO0FBQ0EsUUFBTWtHLFdBQVcsR0FBR0wsV0FBVyxHQUFHTSw2RUFBSCxHQUErQkMsNEVBQTlEO0FBRUEsc0JBQ0k7QUFBQSxjQUNLTixjQUFjLGlCQUNYLHFFQUFDLHFEQUFEO0FBQ0ksZUFBUyxFQUFFMUssMkNBQUksQ0FDWHJDLE9BQU8sQ0FBQ3NOLFlBREcsRUFFWFIsV0FBVyxJQUFJOU0sT0FBTyxDQUFDdU4sa0JBRlosQ0FEbkI7QUFLSSxPQUFDLEVBQUUsQ0FMUDtBQUFBLDhCQU1JLHFFQUFDLHFEQUFEO0FBQUssZUFBTyxFQUFDLE1BQWI7QUFBb0IsVUFBRSxFQUFFLEVBQXhCO0FBQUEsK0JBQ0kscUVBQUMsNERBQUQ7QUFDSSxtQkFBUyxFQUFFdk4sT0FBTyxDQUFDb00sVUFEdkI7QUFFSSxpQkFBTyxFQUFFLE1BQU07QUFDWFksNkJBQWlCLENBQUMsS0FBRCxDQUFqQjtBQUNBNUIsdUJBQVcsQ0FBQyxLQUFELENBQVg7QUFDSCxXQUxMO0FBQUEsaUNBTUkscUVBQUMsK0NBQUQ7QUFBRyx1QkFBVyxFQUFDLEdBQWY7QUFBbUIsaUJBQUssRUFBQyxRQUF6QjtBQUFrQyxnQkFBSSxFQUFFO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFOSixlQWdCSSxxRUFBQyxxREFBRDtBQUFBLGtCQUNLK0IsV0FBVyxDQUFDM04sR0FBWixDQUFpQkMsSUFBRCxpQkFDYixxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxHQUFUO0FBQUEsaUNBQ0kscUVBQUMsc0RBQUQ7QUFBTSxnQkFBSSxFQUFDLEdBQVg7QUFBZSxxQkFBUyxFQUFDLE1BQXpCO0FBQUEsbUNBQ0kscUVBQUMscURBQUQ7QUFBSyxxQkFBTyxFQUFDLE1BQWI7QUFBb0Isd0JBQVUsRUFBQyxRQUEvQjtBQUFBLHNDQUNJLHFFQUFDLElBQUQsQ0FBTSxJQUFOO0FBQVcsMkJBQVcsRUFBQyxHQUF2QjtBQUEyQixxQkFBSyxFQUFDLFFBQWpDO0FBQTBDLG9CQUFJLEVBQUU7QUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFESixlQUVJLHFFQUFDLHFEQUFEO0FBQ0ksd0JBQVEsRUFBQyxhQURiO0FBRUkscUJBQUssRUFBQyxjQUZWO0FBR0ksMEJBQVUsRUFBQyxpQkFIZjtBQUlJLGtCQUFFLEVBQUUsR0FKUjtBQUFBLDBCQUtLQSxJQUFJLENBQUNSO0FBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosV0FBbUJRLElBQUksQ0FBQ1IsSUFBeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBaEJKLEVBa0NLNk4sV0FBVyxpQkFDUixxRUFBQyxxREFBRDtBQUFLLFVBQUUsRUFBRSxHQUFUO0FBQWMsVUFBRSxFQUFFLENBQWxCO0FBQUEsK0JBQ0kscUVBQUMsd0RBQUQ7QUFBUSxjQUFJLEVBQUMsT0FBYjtBQUFxQixlQUFLLEVBQUMsU0FBM0I7QUFBcUMsaUJBQU8sRUFBQyxXQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBbkNSLGVBeUNJLHFFQUFDLHFEQUFEO0FBQUEsa0JBQ0tHLEtBQUssQ0FBQ3pOLEdBQU4sQ0FBVSxDQUFDQyxJQUFELEVBQU9tRyxLQUFQLGtCQUNQLHFFQUFDLHFEQUFEO0FBQUssaUJBQU8sRUFBQyxNQUFiO0FBQWdDLFlBQUUsRUFBRSxHQUFwQztBQUFBLGlDQUNJLHFFQUFDLHdEQUFEO0FBQ0kscUJBQVMsRUFBRXZELDJDQUFJLENBQUMsU0FBRCxFQUFZckMsT0FBTyxDQUFDd04sWUFBcEIsQ0FEbkI7QUFFSSxnQkFBSSxFQUFDLFFBRlQ7QUFHSSxtQkFBTyxlQUFFLHFFQUFDLDBEQUFEO0FBQWMsbUJBQUssRUFBQyxRQUFwQjtBQUE2QixrQkFBSSxFQUFFO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSGI7QUFBQSxzQkFJSy9OLElBQUksQ0FBQ2tNO0FBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLFdBQXlCL0YsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBekNKLGVBcURJLHFFQUFDLHFEQUFEO0FBQ0ksZ0JBQVEsRUFBQyxPQURiO0FBRUksYUFBSyxFQUFDLE9BRlY7QUFHSSxjQUFNLEVBQUMsSUFIWDtBQUlJLGlCQUFTLEVBQ0xrSCxXQUFXLEdBQUc5TSxPQUFPLENBQUN5TixnQkFBWCxHQUE4QnpOLE9BQU8sQ0FBQzBOLG1CQUx6RDtBQUFBLCtCQU9JLHFFQUFDLGlEQUFEO0FBQ0ksYUFBRyxFQUFDLGlCQURSO0FBRUksZUFBSyxFQUFFLEdBRlg7QUFHSSxnQkFBTSxFQUFFLEdBSFo7QUFJSSxtQkFBUyxFQUFFMU4sT0FBTyxDQUFDMko7QUFKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBckRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZSLG1CQURKO0FBMEVILENBakZEOztBQWtGQWtELFVBQVUsQ0FBQzFNLFNBQVgsR0FBdUI7QUFDbkIyTSxhQUFXLEVBQUUxTSxpREFBUyxDQUFDRyxJQURKO0FBRW5CNkssYUFBVyxFQUFFaEwsaURBQVMsQ0FBQzZDO0FBRkosQ0FBdkI7QUFJZTRKLHlFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3pHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ08sTUFBTUssb0JBQW9CLEdBQUcsQ0FDaEM7QUFDSXZCLFVBQVEsRUFBRTtBQURkLENBRGdDLEVBSWhDO0FBQ0lBLFVBQVEsRUFBRTtBQURkLENBSmdDLEVBT2hDO0FBQ0lBLFVBQVEsRUFBRTtBQURkLENBUGdDLENBQTdCO0FBWUEsTUFBTTFFLFNBQVMsR0FBRyxDQUNyQjtBQUNJMEUsVUFBUSxFQUFFO0FBRGQsQ0FEcUIsRUFJckI7QUFDSUEsVUFBUSxFQUFFO0FBRGQsQ0FKcUIsQ0FBbEI7QUFRQSxNQUFNMEIsd0JBQXdCLEdBQUcsQ0FDcEM7QUFBRXBPLE1BQUksRUFBRSxnQkFBUjtBQUEwQkMsTUFBSSxFQUFFeU8sa0RBQUlBO0FBQXBDLENBRG9DLEVBRXBDO0FBQUUxTyxNQUFJLEVBQUUsbUJBQVI7QUFBNkJDLE1BQUksRUFBRTBPLHNEQUFRQTtBQUEzQyxDQUZvQyxFQUdwQztBQUFFM08sTUFBSSxFQUFFLGNBQVI7QUFBd0JDLE1BQUksRUFBRWdHLGtEQUFJQTtBQUFsQyxDQUhvQyxFQUlwQztBQUFFakcsTUFBSSxFQUFFLGFBQVI7QUFBdUJDLE1BQUksRUFBRUMsd0RBQVVBO0FBQXZDLENBSm9DLENBQWpDO0FBTUEsTUFBTWlPLHlCQUF5QixHQUFHLENBQ3JDO0FBQUVuTyxNQUFJLEVBQUUsTUFBUjtBQUFnQkMsTUFBSSxFQUFFeU8sa0RBQUlBO0FBQTFCLENBRHFDLEVBRXJDO0FBQUUxTyxNQUFJLEVBQUUsYUFBUjtBQUF1QkMsTUFBSSxFQUFFMk8sa0RBQUlBO0FBQWpDLENBRnFDLEVBR3JDO0FBQUU1TyxNQUFJLEVBQUUsY0FBUjtBQUF3QkMsTUFBSSxFQUFFME8sc0RBQVFBO0FBQXRDLENBSHFDLEVBSXJDO0FBQUUzTyxNQUFJLEVBQUUsYUFBUjtBQUF1QkMsTUFBSSxFQUFFQyx3REFBVUE7QUFBdkMsQ0FKcUMsQ0FBbEMsQzs7Ozs7Ozs7Ozs7O0FDM0JQO0FBQUE7QUFBQTtBQUFBO0FBRUEsTUFBTWMsU0FBUyxHQUFHTywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckM2TSxjQUFZLEVBQUU7QUFDVnRTLFlBQVEsRUFBRSxPQURBO0FBRVZFLFFBQUksRUFBRSxDQUZJO0FBR1ZFLFNBQUssRUFBRSxDQUhHO0FBSVZILE9BQUcsRUFBRSxDQUpLO0FBS1ZFLFVBQU0sRUFBRSxDQUxFO0FBTVZuQyxTQUFLLEVBQUUsTUFORztBQU9WMEMsVUFBTSxFQUFFLE9BUEU7QUFRVnlILFVBQU0sRUFBRSxPQVJFO0FBU1Z4QyxtQkFBZSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY1MsS0FBZCxDQUFvQkM7QUFUM0IsR0FEdUI7QUFZckNpTSxvQkFBa0IsRUFBRTtBQUNoQjVNLG1CQUFlLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjSSxNQUFkLENBQXFCQztBQUR0QixHQVppQjtBQWVyQ21MLFlBQVUsRUFBRTtBQUNSekwsbUJBQWUsRUFBRUYsS0FBSyxDQUFDTyxNQUFOLENBQWFDO0FBRHRCLEdBZnlCO0FBa0JyQ3dNLGtCQUFnQixFQUFFO0FBQ2R4UyxPQUFHLEVBQUU7QUFEUyxHQWxCbUI7QUFxQnJDeVMscUJBQW1CLEVBQUU7QUFDakJ2UyxVQUFNLEVBQUU7QUFEUyxHQXJCZ0I7QUF3QnJDcVMsY0FBWSxFQUFFO0FBQ1YxRSxZQUFRLEVBQUVySSxLQUFLLENBQUN5SixVQUFOLENBQWlCNEQsRUFBakIsQ0FBb0JoRixRQURwQjtBQUVWL0gsU0FBSyxFQUFFTixLQUFLLENBQUNHLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQkM7QUFGbkI7QUF4QnVCLENBQVosQ0FBRCxDQUE1QjtBQThCZWIsd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDaENBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUdBLE1BQU04TixTQUFTLEdBQUcsQ0FBQztBQUFFQyxVQUFGO0FBQVlyTSxhQUFaO0FBQXlCc00sYUFBekI7QUFBc0M1TyxPQUFLLEdBQUM7QUFBNUMsQ0FBRCxLQUFxRDtBQUNuRSxRQUFNVyxPQUFPLEdBQUdDLGdFQUFTLEVBQXpCO0FBQ0EsUUFBTXFMLFVBQVUsR0FBR0Msc0VBQWEsQ0FBQyxvQkFBRCxDQUFoQztBQUNBLFFBQU1HLGFBQWEsR0FBRyxDQUNsQjtBQUNJQyxZQUFRLEVBQUU7QUFEZCxHQURrQixFQUlsQjtBQUNJQSxZQUFRLEVBQUU7QUFEZCxHQUprQixFQU9sQjtBQUNJQSxZQUFRLEVBQUU7QUFEZCxHQVBrQixDQUF0QjtBQVlBLFFBQU07QUFBQSxPQUFDdUMsVUFBRDtBQUFBLE9BQWFDO0FBQWIsTUFBOEJ0SixzREFBUSxDQUFDLEtBQUQsQ0FBNUM7O0FBQ0EsUUFBTXVKLFdBQVcsR0FBRyxNQUFNO0FBQ3RCRCxpQkFBYSxDQUFDLEtBQUQsQ0FBYjtBQUNILEdBRkQ7O0FBSUEsc0JBQ0kscUVBQUMscURBQUQ7QUFDSSxNQUFFLEVBQUUsQ0FEUjtBQUVJLE1BQUUsRUFBRTdDLFVBQVUsR0FBRyxDQUFILEdBQU8sQ0FGekI7QUFHSSxNQUFFLEVBQUUsQ0FIUjtBQUlJLE1BQUUsRUFBRUEsVUFBVSxHQUFHLENBQUgsR0FBTyxDQUp6QjtBQUtJLFdBQU8sRUFBQyxzQkFMWjtBQUFBLDJCQU1JLHFFQUFDLHFEQUFEO0FBQUssYUFBTyxFQUFDLE1BQWI7QUFBb0IsZ0JBQVUsRUFBQyxRQUEvQjtBQUF3QyxvQkFBYyxFQUFDLGVBQXZEO0FBQUEsOEJBQ0kscUVBQUMscURBQUQ7QUFBSyxlQUFPLEVBQUMsTUFBYjtBQUFvQixrQkFBVSxFQUFDLFFBQS9CO0FBQXdDLGdCQUFRLEVBQUUsR0FBbEQ7QUFBQSxtQkFDSzBDLFFBQVEsaUJBQ0wscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsR0FBVDtBQUFBLGlDQUNJLHFFQUFDLDREQUFEO0FBQVksbUJBQU8sRUFBRXJNLFdBQXJCO0FBQUEsbUNBQ0kscUVBQUMseURBQUQ7QUFBYSx5QkFBVyxFQUFDLEdBQXpCO0FBQTZCLG1CQUFLLEVBQUMsUUFBbkM7QUFBNEMsa0JBQUksRUFBRTtBQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRlIsZUFRSSxxRUFBQyxxREFBRDtBQUNJLGVBQUssRUFBQyxlQURWO0FBRUksa0JBQVEsRUFBRSxFQUZkO0FBR0ksb0JBQVUsRUFBQyxNQUhmO0FBQUEsb0JBSU10QyxLQUFLLEdBQUdBLEtBQUgsR0FBVztBQUp0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQWdCSSxxRUFBQyxxREFBRDtBQUNJLGFBQUssRUFBQyxlQURWO0FBRUksZ0JBQVEsRUFBQyxhQUZiO0FBR0ksZ0JBQVEsRUFBQyxVQUhiO0FBSUksV0FBRyxFQUFDLE9BSlI7QUFLSSxlQUFPLEVBQUUsQ0FBQ2lNLFVBQUQsR0FBYyxNQUFkLEdBQXVCLE1BTHBDO0FBQUEsK0JBTUkscUVBQUMsNERBQUQ7QUFBQSxpQ0FDSSxxRUFBQywrQ0FBRDtBQUFHLHVCQUFXLEVBQUMsR0FBZjtBQUFtQixpQkFBSyxFQUFDLE9BQXpCO0FBQWlDLGdCQUFJLEVBQUU7QUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWhCSixlQTBCSSxxRUFBQyxxREFBRDtBQUFLLGtCQUFVLEVBQUMsUUFBaEI7QUFBeUIsZUFBTyxFQUFFQSxVQUFVLEdBQUcsTUFBSCxHQUFZLE1BQXhEO0FBQUEsa0JBRVEwQyxRQUFRLGdCQUNKO0FBQUEsa0NBQ0kscUVBQUMscURBQUQ7QUFBSyxxQkFBUyxFQUFFaE8sT0FBTyxDQUFDcU8sSUFBeEI7QUFBQSxtQ0FDSSxxRUFBQyxzREFBRDtBQUFNLGtCQUFJLEVBQUMsR0FBWDtBQUFlLHVCQUFTLEVBQUMsTUFBekI7QUFBQSxxQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHdCQUFRLEVBQUMsZ0JBQWQ7QUFBK0IscUJBQUssRUFBQyx1QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESixlQVFJLHFFQUFDLHFEQUFEO0FBQUsscUJBQVMsRUFBRXJPLE9BQU8sQ0FBQ3FPLElBQXhCO0FBQUEsbUNBQ0kscUVBQUMsc0RBQUQ7QUFBTSxrQkFBSSxFQUFDLEdBQVg7QUFBZSx1QkFBUyxFQUFDLE1BQXpCO0FBQWdDLHFCQUFPLEVBQUUsTUFBTTtBQUMzQ0YsNkJBQWEsQ0FBQyxJQUFELENBQWI7QUFDSCxlQUZEO0FBQUEscUNBR0kscUVBQUMscURBQUQ7QUFBSyx3QkFBUSxFQUFDLGdCQUFkO0FBQStCLHFCQUFLLEVBQUMsdUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUkosZUFpQkkscUVBQUMsd0RBQUQ7QUFDSSxtQkFBTyxFQUFFQyxXQURiO0FBRUksK0JBQWdCLHFCQUZwQjtBQUdJLGdCQUFJLEVBQUVGLFVBSFY7QUFBQSxtQ0FJSSxxRUFBQyx3RUFBRDtBQUFlLHFCQUFPLEVBQUVFLFdBQXhCO0FBQXFDLHVCQUFTLEVBQUVIO0FBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWpCSjtBQUFBLHdCQURJLGdCQTBCSjtBQUFBLG9CQUNLdkMsYUFBYSxDQUFDbE0sR0FBZCxDQUFtQkMsSUFBRCxpQkFDZixxRUFBQyxxREFBRDtBQUFBLG1DQUNJLHFFQUFDLHNEQUFEO0FBQU0sa0JBQUksRUFBQyxHQUFYO0FBQWUsdUJBQVMsRUFBQyxNQUF6QjtBQUFBLHFDQUNJLHFFQUFDLHFEQUFEO0FBQUssd0JBQVEsRUFBQyxnQkFBZDtBQUErQixxQkFBSyxFQUFDLHVCQUFyQztBQUFBLDBCQUNLQSxJQUFJLENBQUNrTTtBQURWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosYUFBVWxNLElBQUksQ0FBQ2tNLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESDtBQURMO0FBNUJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQThFSCxDQWxHRDs7QUFtR0FvQyxTQUFTLENBQUM3TixZQUFWLEdBQXlCO0FBQ3JCOE4sVUFBUSxFQUFFLEtBRFc7QUFFckIzTyxPQUFLLEVBQUUsSUFGYztBQUdyQnNDLGFBQVcsRUFBRXZCLGlEQUFTLENBQUM2QztBQUhGLENBQXpCO0FBS0E4SyxTQUFTLENBQUM1TixTQUFWLEdBQXNCO0FBQ2xCNk4sVUFBUSxFQUFFNU4saURBQVMsQ0FBQ0csSUFERjtBQUVsQm9CLGFBQVcsRUFBRXZCLGlEQUFTLENBQUM2QyxJQUZMO0FBR2xCZ0wsYUFBVyxFQUFFN04saURBQVMsQ0FBQzZDLElBSEw7QUFJbEI1RCxPQUFLLEVBQUVlLGlEQUFTLENBQUM0STtBQUpDLENBQXRCO0FBTWUrRSx3RUFBZixFOzs7Ozs7Ozs7Ozs7QUM3SEE7QUFBQTtBQUFBO0FBQUE7QUFFQSxNQUFNOU4sU0FBUyxHQUFHTywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckM0TixNQUFJLEVBQUU7QUFDRiwwQkFBc0I7QUFDbEJoRSxpQkFBVyxFQUFDNUosS0FBSyxDQUFDaU0sT0FBTixDQUFjLENBQWQsQ0FETTtBQUVsQjFSLGNBQVEsRUFBRSxVQUZRO0FBR2xCLGtCQUFZO0FBQ1JzVCxlQUFPLEVBQUUsS0FERDtBQUVSdFQsZ0JBQVEsRUFBRSxVQUZGO0FBR1JJLGFBQUssRUFBRSxPQUhDO0FBSVJILFdBQUcsRUFBRSxDQUpHO0FBS1JFLGNBQU0sRUFBRSxDQUxBO0FBTVI0RixhQUFLLEVBQUU7QUFOQztBQUhNO0FBRHBCO0FBRCtCLENBQVosQ0FBRCxDQUE1QjtBQWlCZWQsd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDbkJBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTXNPLFVBQVUsR0FBRyxDQUFDO0FBQUV2VjtBQUFGLENBQUQsS0FBZTtBQUM5QixzQkFDSSxxRUFBQyxxREFBRDtBQUNJLGFBQVMsRUFBRUEsS0FBSyxLQUFLLElBQVYsSUFBa0JBLEtBQUssS0FBSyxJQUE1QixHQUFtQyxHQUFuQyxHQUF5QyxHQUR4RDtBQUVJLFNBQUssRUFBQyxNQUZWO0FBR0ksV0FBTyxFQUFDLE1BSFo7QUFJSSxjQUFVLEVBQUMsUUFKZjtBQUtJLGtCQUFjLEVBQUMsUUFMbkI7QUFNSSxpQkFBYSxFQUFDLFFBTmxCO0FBT0ksYUFBUyxFQUFDLFFBUGQ7QUFRSSxXQUFPLEVBQUMsc0JBUlo7QUFTSSxNQUFFLEVBQUUsQ0FUUjtBQVVJLE1BQUUsRUFBRSxDQVZSO0FBV0ksTUFBRSxFQUFFLENBWFI7QUFBQSw0QkFZSSxxRUFBQyxxREFBRDtBQUNJLFdBQUssRUFBQyxlQURWO0FBRUksY0FBUSxFQUFFQSxLQUFLLEtBQUssSUFBVixJQUFrQkEsS0FBSyxLQUFLLElBQTVCLEdBQW1DLGFBQW5DLEdBQW1ELGFBRmpFO0FBR0ksZ0JBQVUsRUFBQyxxQkFIZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFaSixlQWtCSSxxRUFBQyxxREFBRDtBQUFLLFdBQUssRUFBQyxlQUFYO0FBQTJCLGNBQVEsRUFBQyxhQUFwQztBQUFrRCxRQUFFLEVBQUUsQ0FBdEQ7QUFBeUQsUUFBRSxFQUFFLElBQTdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWxCSixlQXFCSSxxRUFBQyx3REFBRDtBQUFRLFVBQUksRUFBQyxPQUFiO0FBQXFCLFdBQUssRUFBQyxTQUEzQjtBQUFxQyxhQUFPLEVBQUMsV0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBMkJILENBNUJEOztBQTZCQXVWLFVBQVUsQ0FBQ3BPLFNBQVgsR0FBdUI7QUFDbkJuSCxPQUFLLEVBQUVvSCxpREFBUyxDQUFDNEk7QUFERSxDQUF2QjtBQUdlQyxpSUFBUyxHQUFHc0YsVUFBSCxDQUF4QixFOzs7Ozs7Ozs7Ozs7QUMxQ0E7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1DLFVBQVUsR0FBRyxDQUFDO0FBQUU3RixRQUFGO0FBQVU4RixNQUFWO0FBQWdCQyxVQUFoQjtBQUEwQkMsVUFBMUI7QUFBb0NDLGFBQXBDO0FBQWlEL087QUFBakQsQ0FBRCxLQUFrRTtBQUNqRixRQUFNRyxPQUFPLEdBQUdDLGlFQUFTLEVBQXpCO0FBQ0Esc0JBQ0kscUVBQUMscURBQUQ7QUFDSSxTQUFLLEVBQUV3TyxJQURYO0FBRUksVUFBTSxFQUFFQSxJQUZaO0FBR0ksZ0JBQVksRUFBQyxLQUhqQjtBQUlJLFdBQU8sRUFBQyxNQUpaO0FBS0ksY0FBVSxFQUFDLFFBTGY7QUFNSSxrQkFBYyxFQUFDLFFBTm5CO0FBT0ksVUFBTSxFQUFDLFFBUFg7QUFRSSxVQUFNLEVBQUVHLFdBUlo7QUFTSSxhQUFTLEVBQUU1TyxPQUFPLENBQUMySSxNQUFELENBVHRCO0FBQUEsMkJBVUkscUVBQUMsMERBQUQ7QUFBYSxVQUFJLEVBQUUrRixRQUFuQjtBQUE2QixVQUFJLEVBQUVDLFFBQW5DO0FBQTZDLFdBQUssRUFBRTlPO0FBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFWSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFjSCxDQWhCRDs7QUFrQkEyTyxVQUFVLENBQUN0TyxZQUFYLEdBQTBCO0FBQ3RCdU8sTUFBSSxFQUFFLEVBRGdCO0FBRXRCOUYsUUFBTSxFQUFFLFNBRmM7QUFHdEIrRixVQUFRLEVBQUUsV0FIWTtBQUl0QkMsVUFBUSxFQUFFLEVBSlk7QUFLdEJDLGFBQVcsRUFBRTtBQUxTLENBQTFCO0FBUUFKLFVBQVUsQ0FBQ3JPLFNBQVgsR0FBdUI7QUFDbkJ3SSxRQUFNLEVBQUV2SSxpREFBUyxDQUFDQyxLQUFWLENBQWdCLENBQUMsU0FBRCxFQUFZLFFBQVosRUFBc0IsU0FBdEIsRUFBaUMsU0FBakMsRUFBNEMsVUFBNUMsQ0FBaEIsQ0FEVztBQUVuQm9PLE1BQUksRUFBRXJPLGlEQUFTLENBQUNtRyxNQUZHO0FBR25Cb0ksVUFBUSxFQUFFdk8saURBQVMsQ0FBQ21HLE1BSEQ7QUFJbkJxSSxhQUFXLEVBQUV4TyxpREFBUyxDQUFDbUcsTUFKSjtBQUtuQm1JLFVBQVEsRUFBRXRPLGlEQUFTLENBQUM0SSxNQUxEO0FBTW5CbkosV0FBUyxFQUFFTyxpREFBUyxDQUFDNEk7QUFORixDQUF2QjtBQVNld0YseUVBQWYsRTs7Ozs7Ozs7Ozs7O0FDL0NBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsTUFBTXZPLFNBQVMsR0FBR08sb0VBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3JDb08sUUFBTSxFQUFFO0FBQ0psTyxtQkFBZSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY2tPLEtBQWQsQ0FBb0J2TixLQURqQztBQUVKd04sZUFBVyxFQUFHLEdBQUV0TyxLQUFLLENBQUNHLE9BQU4sQ0FBY2tPLEtBQWQsQ0FBb0JoTyxJQUFLO0FBRnJDLEdBRDZCO0FBS3JDcUgsU0FBTyxFQUFFO0FBQ0x4SCxtQkFBZSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY3VILE9BQWQsQ0FBc0I1RyxLQURsQztBQUVMd04sZUFBVyxFQUFHLEdBQUV0TyxLQUFLLENBQUNHLE9BQU4sQ0FBY3VILE9BQWQsQ0FBc0JySCxJQUFLO0FBRnRDLEdBTDRCO0FBU3JDaUQsU0FBTyxFQUFFO0FBQ0xwRCxtQkFBZSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY21ELE9BQWQsQ0FBc0J4QyxLQURsQztBQUVMd04sZUFBVyxFQUFHLEdBQUV0TyxLQUFLLENBQUNHLE9BQU4sQ0FBY21ELE9BQWQsQ0FBc0JqRCxJQUFLO0FBRnRDLEdBVDRCO0FBYXJDa08sU0FBTyxFQUFFO0FBQ0xyTyxtQkFBZSxFQUFFLGFBRFo7QUFFTG9PLGVBQVcsRUFBRyxHQUFFdE8sS0FBSyxDQUFDRyxPQUFOLENBQWNvTyxPQUFkLENBQXNCbE8sSUFBSztBQUZ0QyxHQWI0QjtBQWlCckNtTyxVQUFRLEVBQUU7QUFDTnRPLG1CQUFlLEVBQUVGLEtBQUssQ0FBQ08sTUFBTixDQUFhQyxLQUR4QjtBQUVOMUYsVUFBTSxFQUFFLG1DQUZGO0FBR04sK0JBQTJCLGFBSHJCO0FBSU4yVCxrQkFBYyxFQUFFO0FBSlY7QUFqQjJCLENBQVosQ0FBRCxDQUE1QjtBQXdCZWpQLHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3pCQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTWtQLFdBQVcsR0FBRyxDQUFDO0FBQUU5UCxPQUFGO0FBQVM0TCxXQUFUO0FBQW9CSixZQUFwQjtBQUFnQ1M7QUFBaEMsQ0FBRCxLQUFrRDtBQUNsRSxRQUFNdEwsT0FBTyxHQUFHQyxrRUFBUyxFQUF6QjtBQUNBLFFBQU1jLEtBQUssR0FBRzhKLFVBQVUsR0FBRyxjQUFILEdBQW9CLGVBQTVDO0FBQ0EsUUFBTXVFLFlBQVksR0FBR3ZFLFVBQVUsR0FBRyxjQUFILEdBQW9CLGVBQW5EO0FBQ0Esc0JBQ0kscUVBQUMscURBQUQ7QUFBSyxXQUFPLEVBQUMsTUFBYjtBQUFvQixpQkFBYSxFQUFDLFFBQWxDO0FBQUEsMkJBQ0k7QUFBQSw4QkFDSSxxRUFBQyxxREFBRDtBQUNJLGdCQUFRLEVBQUMsYUFEYjtBQUVJLGtCQUFVLEVBQUMsc0JBRmY7QUFHSSxhQUFLLEVBQUU5SixLQUhYO0FBSUksZ0JBQVEsRUFBQyxRQUpiO0FBS0ksa0JBQVUsRUFBQyxRQUxmO0FBTUksZ0JBQVEsRUFBQyxPQU5iO0FBT0ksb0JBQVksRUFBQyxVQVBqQjtBQVFJLGlCQUFTLEVBQUVmLE9BQU8sQ0FBQ1gsS0FSdkI7QUFBQSxrQkFTSyxDQUFDd0wsVUFBRCxJQUFlUyxVQUFmLEdBQTRCak0sS0FBNUIsR0FBb0M7QUFUekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQVlJLHFFQUFDLHFEQUFEO0FBQ0ksZUFBTyxFQUFDLE1BRFo7QUFFSSxnQkFBUSxFQUFDLGdCQUZiO0FBR0kscUJBQWEsRUFBQyxLQUhsQjtBQUlJLGFBQUssRUFBRStQLFlBSlg7QUFLSSxpQkFBUyxFQUFFcFAsT0FBTyxDQUFDaUwsU0FMdkI7QUFBQSxrQkFNS0E7QUFOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpKO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUF5QkgsQ0E3QkQ7O0FBK0JBa0UsV0FBVyxDQUFDalAsWUFBWixHQUEyQixFQUEzQjtBQUNBaVAsV0FBVyxDQUFDaFAsU0FBWixHQUF3QjtBQUNwQmQsT0FBSyxFQUFFZSxpREFBUyxDQUFDNEksTUFERztBQUVwQmlDLFdBQVMsRUFBRTdLLGlEQUFTLENBQUM0SSxNQUZEO0FBR3BCNkIsWUFBVSxFQUFFekssaURBQVMsQ0FBQ0csSUFIRjtBQUlwQitLLFlBQVUsRUFBRWxMLGlEQUFTLENBQUNHO0FBSkYsQ0FBeEI7QUFPZTRPLDBFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3JEQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU1sUCxTQUFTLEdBQUdPLDJFQUFVLENBQUVDLEtBQUQsS0FBWTtBQUNyQ3dLLFdBQVMsRUFBRTtBQUNQLEtBQUN4SyxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQjlJLGFBQU8sRUFBRTtBQURpQjtBQUR2QixHQUQwQjtBQU1yQzRELE9BQUssRUFBRTtBQUNILEtBQUNvQixLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQnVFLGNBQVEsRUFBRXJJLEtBQUssQ0FBQ3lKLFVBQU4sQ0FBaUIwQyxFQUFqQixDQUFvQjlEO0FBREo7QUFEM0I7QUFOOEIsQ0FBWixDQUFELENBQTVCO0FBYWU3SSx3RUFBZixFOzs7Ozs7Ozs7Ozs7QUNmQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNb1AsVUFBVSxHQUFJdkosS0FBRCxJQUFXO0FBQzFCLFFBQU07QUFBRWhHLFlBQUY7QUFBWUYsV0FBWjtBQUFxQjhPLFlBQXJCO0FBQStCWSxZQUEvQjtBQUF5Q0MsV0FBekM7QUFBa0RDLFlBQWxEO0FBQTREQyxZQUE1RDtBQUFzRUMsZUFBdEU7QUFBbUZDO0FBQW5GLE1BQ0Y3SixLQURKO0FBRUEsUUFBTTlGLE9BQU8sR0FBR0MsZ0VBQVMsRUFBekI7QUFDQSxRQUFNLENBQUMyUCxRQUFELEVBQVdDLFdBQVgsSUFBMEJqTCw0Q0FBSyxDQUFDQyxRQUFOLENBQWUsSUFBZixDQUFoQztBQUNBLFFBQU1pTCxJQUFJLEdBQUczVixPQUFPLENBQUN5VixRQUFELENBQXBCOztBQUVBLFFBQU1HLFdBQVcsR0FBSWhMLEtBQUQsSUFBVztBQUMzQjhLLGVBQVcsQ0FBQzlLLEtBQUssQ0FBQ2lMLGFBQVAsQ0FBWDtBQUNILEdBRkQ7O0FBSUEsUUFBTTVCLFdBQVcsR0FBRyxNQUFNO0FBQ3RCeUIsZUFBVyxDQUFDLElBQUQsQ0FBWDtBQUNILEdBRkQ7O0FBSUEsUUFBTUksVUFBVSxHQUFHLE1BQU07QUFDckJQLGVBQVc7QUFDWHRCLGVBQVc7QUFDZCxHQUhEOztBQUlBLFFBQU04QixZQUFZLEdBQUcsTUFBTTtBQUN2QlYsWUFBUTtBQUNScEIsZUFBVztBQUNkLEdBSEQ7O0FBS0Esc0JBQ0k7QUFBQSxjQUNLa0IsUUFBUSxLQUFLLFlBQWIsZ0JBQ0cscUVBQUMsc0RBQUQ7QUFBTSxhQUFPLEVBQUVDLE9BQWY7QUFBQSw2QkFDSSxxRUFBQyxxREFBRDtBQUFLLGVBQU8sRUFBQyxNQUFiO0FBQW9CLGtCQUFVLEVBQUMsUUFBL0I7QUFBd0MsVUFBRSxFQUFFLENBQTVDO0FBQStDLFVBQUUsRUFBRSxHQUFuRDtBQUF3RCxpQkFBUyxFQUFFLEVBQW5FO0FBQUEsZ0NBQ0kscUVBQUMscURBQUQ7QUFBQSxpQ0FDSSxxRUFBQyxtREFBRDtBQUNJLGdCQUFJLEVBQUUsRUFEVjtBQUVJLGtCQUFNLEVBQUUzUCxPQUZaO0FBR0ksb0JBQVEsRUFBRThPLFFBSGQ7QUFJSSx1QkFBVyxFQUFFLEdBSmpCO0FBS0ksb0JBQVEsRUFBRTtBQUxkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLEVBVUs1TyxRQUFRLGlCQUNMLHFFQUFDLHFEQUFEO0FBQ0ksa0JBQVEsRUFBRSxDQURkO0FBRUksaUJBQU8sRUFBQyxNQUZaO0FBR0ksdUJBQWEsRUFBQyxRQUhsQjtBQUlJLHdCQUFjLEVBQUMsUUFKbkI7QUFLSSxZQUFFLEVBQUUsR0FMUjtBQUFBLG9CQU1LQTtBQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWFIsRUFvQks2UCxjQUFjLGlCQUNYLHFFQUFDLHFEQUFEO0FBQ0ksV0FBQyxFQUFFLElBRFA7QUFFSSxZQUFFLEVBQUUsQ0FBQyxHQUZUO0FBR0ksaUJBQU8sRUFBQyxNQUhaO0FBSUksd0JBQWMsRUFBQyxRQUpuQjtBQUtJLG9CQUFVLEVBQUMsUUFMZjtBQUFBLG9CQU1LRixRQUFRLGdCQUNMO0FBQUEsb0NBQ0kscUVBQUMsNERBQUQ7QUFBWSxtQkFBSyxFQUFDLFNBQWxCO0FBQTRCLHFCQUFPLEVBQUVNLFdBQXJDO0FBQUEscUNBQ0kscUVBQUMsMERBQUQ7QUFBYSxvQkFBSSxFQUFDLGVBQWxCO0FBQWtDLG9CQUFJLEVBQUM7QUFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFJSSxxRUFBQyxzREFBRDtBQUNJLGdCQUFFLEVBQUMsV0FEUDtBQUVJLHNCQUFRLEVBQUVILFFBRmQ7QUFHSSx5QkFBVyxNQUhmO0FBSUksa0JBQUksRUFBRUUsSUFKVjtBQUtJLHFCQUFPLEVBQUUxQixXQUxiO0FBQUEsc0NBTUkscUVBQUMsMERBQUQ7QUFBVSx1QkFBTyxFQUFFNkIsVUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTkosZUFPSSxxRUFBQywwREFBRDtBQUFVLHVCQUFPLEVBQUVDLFlBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKSjtBQUFBLDBCQURLLGdCQWdCTCxxRUFBQyw0REFBRDtBQUFZLGlCQUFLLEVBQUMsU0FBbEI7QUFBQSxtQ0FDSSxxRUFBQywwREFBRDtBQUFhLGtCQUFJLEVBQUMsZUFBbEI7QUFBa0Msa0JBQUksRUFBQztBQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXRCUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXJCUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURILGdCQXVERyxxRUFBQyxxREFBRDtBQUFLLGVBQVMsRUFBRWxRLE9BQU8sQ0FBQ21RLFVBQXhCO0FBQUEsOEJBQ0k7QUFDSSxjQUFNLEVBQUMsU0FEWDtBQUVJLGlCQUFTLEVBQUVuUSxPQUFPLENBQUNvUSxLQUZ2QjtBQUdJLFVBQUUsRUFBQyx1QkFIUDtBQUlJLGdCQUFRLE1BSlo7QUFLSSxZQUFJLEVBQUM7QUFMVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBUUk7QUFBTyxlQUFPLEVBQUMsdUJBQWY7QUFBQSwrQkFDSSxxRUFBQyx3REFBRDtBQUFRLGlCQUFPLEVBQUMsV0FBaEI7QUFBNEIsbUJBQVMsRUFBQyxNQUF0QztBQUFBLGlDQUNJLHFFQUFDLHNEQUFEO0FBQUEsbUNBQ0kscUVBQUMscURBQUQ7QUFDSSxxQkFBTyxFQUFDLE1BRFo7QUFFSSx3QkFBVSxFQUFDLFFBRmY7QUFHSSxnQkFBRSxFQUFFLENBSFI7QUFJSSxnQkFBRSxFQUFFLEdBSlI7QUFLSSx1QkFBUyxFQUFFLEVBTGY7QUFBQSxzQ0FNSSxxRUFBQyxxREFBRDtBQUFBLHVDQUNJLHFFQUFDLG1EQUFEO0FBQ0ksc0JBQUksRUFBRSxFQURWO0FBRUksd0JBQU0sRUFBRXhRLE9BRlo7QUFHSSwwQkFBUSxFQUFFOE8sUUFIZDtBQUlJLDZCQUFXLEVBQUUsR0FKakI7QUFLSSwwQkFBUSxFQUFFO0FBTGQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTkosRUFlSzVPLFFBQVEsaUJBQ0wscUVBQUMscURBQUQ7QUFDSSx3QkFBUSxFQUFFLENBRGQ7QUFFSSx1QkFBTyxFQUFDLE1BRlo7QUFHSSw2QkFBYSxFQUFDLFFBSGxCO0FBSUksOEJBQWMsRUFBQyxRQUpuQjtBQUtJLGtCQUFFLEVBQUUsQ0FMUjtBQUFBLDBCQU1LQTtBQU5MO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaEJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUF4RFIsbUJBREo7QUFxR0gsQ0E3SEQ7O0FBK0hBdVAsVUFBVSxDQUFDblAsWUFBWCxHQUEwQjtBQUN0Qk4sU0FBTyxFQUFFLFNBRGE7QUFFdEJFLFVBQVEsRUFBRSxFQUZZO0FBR3RCNE8sVUFBUSxFQUFFLE1BSFk7QUFJdEJZLFVBQVEsRUFBRSxZQUpZO0FBS3RCQyxTQUFPLEVBQUVjLHdEQUxhO0FBTXRCWixVQUFRLEVBQUUsS0FOWTtBQU90QkMsYUFBVyxFQUFFVyx3REFQUztBQVF0QmIsVUFBUSxFQUFFYSx3REFSWTtBQVN0QlYsZ0JBQWMsRUFBRztBQVRLLENBQTFCO0FBWUFOLFVBQVUsQ0FBQ2xQLFNBQVgsR0FBdUI7QUFDbkJQLFNBQU8sRUFBRVEsaURBQVMsQ0FBQ0MsS0FBVixDQUFnQixDQUFDLFNBQUQsRUFBWSxRQUFaLEVBQXNCLFNBQXRCLENBQWhCLENBRFU7QUFFbkJpUCxVQUFRLEVBQUVsUCxpREFBUyxDQUFDQyxLQUFWLENBQWdCLENBQUMsWUFBRCxFQUFlLFlBQWYsQ0FBaEIsQ0FGUztBQUduQlAsVUFBUSxFQUFFTSxpREFBUyxDQUFDRSxJQUhEO0FBSW5Cb08sVUFBUSxFQUFFdE8saURBQVMsQ0FBQzRJLE1BSkQ7QUFLbkJ1RyxTQUFPLEVBQUVuUCxpREFBUyxDQUFDNkMsSUFMQTtBQU1uQndNLFVBQVEsRUFBRXJQLGlEQUFTLENBQUNHLElBTkQ7QUFPbkJtUCxhQUFXLEVBQUV0UCxpREFBUyxDQUFDNkMsSUFQSjtBQVFuQnVNLFVBQVEsRUFBRXBQLGlEQUFTLENBQUM2QyxJQVJEO0FBU25CME0sZ0JBQWMsRUFBR3ZQLGlEQUFTLENBQUNHO0FBVFIsQ0FBdkI7QUFZZThPLHlFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3BLQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU1wUCxTQUFTLEdBQUdPLDJFQUFVLENBQUMsT0FBTztBQUNoQzJQLFlBQVUsRUFBRTtBQUNSLGFBQVM7QUFDTDNVLFlBQU0sRUFBRTtBQURILEtBREQ7QUFJUix5QkFBcUI7QUFDakJ4QyxXQUFLLEVBQUUsTUFEVTtBQUVqQnNDLGFBQU8sRUFBRTtBQUZRLEtBSmI7QUFRUix1QkFBbUI7QUFDZnRDLFdBQUssRUFBRTtBQURRO0FBUlgsR0FEb0I7QUFhaENvWCxPQUFLLEVBQUU7QUFDSDNVLFdBQU8sRUFBRTtBQUROLEdBYnlCO0FBZ0JoQyx5QkFBdUI7QUFDbkJILFdBQU8sRUFBRTtBQURVO0FBaEJTLENBQVAsQ0FBRCxDQUE1QjtBQXFCZTJFLHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3ZCQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTXFRLFdBQVcsR0FBRyxDQUFDO0FBQUVqUjtBQUFGLENBQUQsS0FBZTtBQUMvQixzQkFDSTtBQUFBLDJCQUNHLHFFQUFDLHFEQUFEO0FBQUssV0FBSyxFQUFDLGNBQVg7QUFBMEIsZ0JBQVUsRUFBQyxpQkFBckM7QUFBdUQsbUJBQWEsRUFBRSxDQUF0RTtBQUF5RSxRQUFFLEVBQUUsQ0FBN0U7QUFBZ0YsZUFBUyxFQUFDLGVBQTFGO0FBQUEsNkJBQ0sscUVBQUMsNERBQUQ7QUFBWSxlQUFPLEVBQUMsSUFBcEI7QUFBQSxrQkFDSUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURILG1CQURKO0FBU0gsQ0FWRDs7QUFXQWlSLFdBQVcsQ0FBQ3BRLFlBQVosR0FBMkIsRUFBM0I7QUFDQW9RLFdBQVcsQ0FBQ25RLFNBQVosR0FBd0I7QUFDcEJkLE9BQUssRUFBRWUsaURBQVMsQ0FBQzRJO0FBREcsQ0FBeEI7QUFJZXNILDBFQUFmLEU7Ozs7Ozs7Ozs7OztBQzFCQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1DLFdBQVcsR0FBSXpLLEtBQUQsSUFBVztBQUMzQixRQUFNO0FBQ0ZoRyxZQURFO0FBRUYwUSxpQkFGRTtBQUdGNVEsV0FIRTtBQUlGNlEsaUJBSkU7QUFLRkMsYUFMRTtBQU1GQyxrQkFORTtBQU9GQyxVQVBFO0FBUUY1WDtBQVJFLE1BU0Y4TSxLQVRKO0FBVUEsUUFBTTlGLE9BQU8sR0FBR0Msa0VBQVMsRUFBekI7QUFDQSxzQkFDSSxxRUFBQyxxREFBRDtBQUFLLFlBQVEsRUFBQyxVQUFkO0FBQUEsMkJBQ0kscUVBQUMsc0RBQUQ7QUFBQSw2QkFDSSxxRUFBQyxxREFBRDtBQUFLLGVBQU8sRUFBQyxNQUFiO0FBQUEsbUJBQ0swUSxjQUFjLGlCQUNYLHFFQUFDLHFEQUFEO0FBQ0ksa0JBQVEsRUFBRSxFQURkO0FBRUksbUJBQVMsRUFBRSxFQUZmO0FBR0ksc0JBQVksRUFBQyxlQUhqQjtBQUlJLGtCQUFRLEVBQUUzWCxLQUFLLEtBQUssSUFBVixHQUFpQixRQUFqQixHQUE0QixVQUoxQztBQUtJLGNBQUksRUFBQyxHQUxUO0FBTUksZ0JBQU0sRUFBRSxDQU5aO0FBT0ksbUJBQVMsRUFBRWdILE9BQU8sQ0FBQ0osT0FBRDtBQVB0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZSLEVBYUs4USxTQUFTLGlCQUNOLHFFQUFDLHFEQUFEO0FBQ0ksbUJBQVMsRUFBRXJPLDJDQUFJLENBQUNyQyxPQUFPLENBQUM2USxPQUFULEVBQWtCN1EsT0FBTyxDQUFDSixPQUFELENBQXpCLENBRG5CO0FBRUksWUFBRSxFQUFFLEdBRlI7QUFHSSxpQkFBTyxFQUFFNUcsS0FBSyxLQUFLLElBQVYsR0FBaUIsTUFBakIsR0FBMEIsU0FIdkM7QUFBQSxpQ0FJSSxxRUFBQyxpREFBRDtBQUFPLGVBQUcsRUFBRTRYLE1BQVo7QUFBb0IsaUJBQUssRUFBRSxHQUEzQjtBQUFnQyxrQkFBTSxFQUFFO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWRSLEVBc0JLOVEsUUFBUSxpQkFDTCxxRUFBQyxxREFBRDtBQUNJLGtCQUFRLEVBQUUsQ0FEZDtBQUVJLFlBQUUsRUFBRSxHQUZSO0FBR0ksWUFBRSxFQUFFLENBSFI7QUFJSSxpQkFBTyxFQUFDLE1BSlo7QUFLSSx1QkFBYSxFQUFDLFFBTGxCO0FBTUksd0JBQWMsRUFBQyxRQU5uQjtBQUFBLG9CQU9LQTtBQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdkJSLEVBa0NLMFEsYUFBYSxpQkFDVixxRUFBQyxxREFBRDtBQUNJLFdBQUMsRUFBRSxJQURQO0FBRUksWUFBRSxFQUFFLElBRlI7QUFHSSxpQkFBTyxFQUFDLE1BSFo7QUFJSSx3QkFBYyxFQUFDLFFBSm5CO0FBS0ksb0JBQVUsRUFBQyxRQUxmO0FBQUEsaUNBTUkscUVBQUMsNERBQUQ7QUFBQSxtQ0FDSSxxRUFBQywwREFBRDtBQUFjLDhCQUFhLEdBQTNCO0FBQStCLG1CQUFLLEVBQUMsUUFBckM7QUFBOEMsa0JBQUksRUFBRTtBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbkNSLEVBOENLQyxhQUFhLGlCQUNWLHFFQUFDLHFEQUFEO0FBQ0ksbUJBQVMsRUFBQyxRQURkO0FBRUksV0FBQyxFQUFFLEdBRlA7QUFHSSxpQkFBTyxFQUFDLFlBSFo7QUFJSSxlQUFLLEVBQUMsY0FKVjtBQUtJLG1CQUFTLEVBQUUsRUFMZjtBQU1JLGtCQUFRLEVBQUUsRUFOZDtBQU9JLGlCQUFPLEVBQUMsTUFQWjtBQVFJLHdCQUFjLEVBQUMsUUFSbkI7QUFTSSxvQkFBVSxFQUFDLFFBVGY7QUFVSSx1QkFBYSxFQUFDLFFBVmxCO0FBV0ksZ0JBQU0sRUFBRSxDQVhaO0FBQUEsa0NBWUkscUVBQUMsb0RBQUQ7QUFBUSw0QkFBYSxLQUFyQjtBQUEyQixpQkFBSyxFQUFDLE9BQWpDO0FBQXlDLGdCQUFJLEVBQUU7QUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFaSixlQWFJLHFFQUFDLHFEQUFEO0FBQ0kscUJBQVMsRUFBQyxPQURkO0FBRUksb0JBQVEsRUFBQyxhQUZiO0FBR0ksc0JBQVUsRUFBQyxvQkFIZjtBQUlJLGNBQUUsRUFBRSxJQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkEvQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQTRFSCxDQXhGRDs7QUEwRkFGLFdBQVcsQ0FBQ3JRLFlBQVosR0FBMkI7QUFDdkJKLFVBQVEsRUFBRSxFQURhO0FBRXZCMFEsZUFBYSxFQUFFLEtBRlE7QUFHdkJDLGVBQWEsRUFBRSxLQUhRO0FBSXZCQyxXQUFTLEVBQUUsS0FKWTtBQUt2QkMsZ0JBQWMsRUFBRSxJQUxPO0FBTXZCQyxRQUFNLEVBQUU7QUFOZSxDQUEzQjtBQVNBTCxXQUFXLENBQUNwUSxTQUFaLEdBQXdCO0FBQ3BCUCxTQUFPLEVBQUVRLGlEQUFTLENBQUNDLEtBQVYsQ0FBZ0IsQ0FBQyxTQUFELEVBQVksUUFBWixFQUFzQixTQUF0QixDQUFoQixDQURXO0FBRXBCUCxVQUFRLEVBQUVNLGlEQUFTLENBQUNFLElBRkE7QUFHcEJrUSxlQUFhLEVBQUVwUSxpREFBUyxDQUFDRyxJQUhMO0FBSXBCa1EsZUFBYSxFQUFFclEsaURBQVMsQ0FBQ0csSUFKTDtBQUtwQm1RLFdBQVMsRUFBRXRRLGlEQUFTLENBQUNHLElBTEQ7QUFNcEJvUSxnQkFBYyxFQUFFdlEsaURBQVMsQ0FBQ0csSUFOTjtBQU9wQnFRLFFBQU0sRUFBRXhRLGlEQUFTLENBQUM0SSxNQVBFO0FBUXBCaFEsT0FBSyxFQUFFb0gsaURBQVMsQ0FBQzRJO0FBUkcsQ0FBeEI7QUFXZUMsaUlBQVMsR0FBR3NILFdBQUgsQ0FBeEIsRTs7Ozs7Ozs7Ozs7O0FDNUhBO0FBQUE7QUFBQTtBQUFBO0FBRUEsTUFBTXRRLFNBQVMsR0FBR08sMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3JDb08sUUFBTSxFQUFFO0FBQ0psTyxtQkFBZSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY2tPLEtBQWQsQ0FBb0JoTyxJQURqQztBQUVKLGdCQUFZO0FBQ1IwQyxnQkFBVSxFQUFFO0FBREo7QUFGUixHQUQ2QjtBQU9yQ3NOLFNBQU8sRUFBRTtBQUNMblEsbUJBQWUsRUFBRUYsS0FBSyxDQUFDRyxPQUFOLENBQWN1SCxPQUFkLENBQXNCckgsSUFEbEM7QUFFTCxnQkFBWTtBQUNSMEMsZ0JBQVUsRUFBRTtBQURKO0FBRlAsR0FQNEI7QUFhckM7QUFDQTtBQUNBO0FBQ0FPLFNBQU8sRUFBRTtBQUNMcEQsbUJBQWUsRUFBRUYsS0FBSyxDQUFDRyxPQUFOLENBQWNtRCxPQUFkLENBQXNCeEMsS0FEbEM7QUFFTCxnQkFBWTtBQUNSaUMsZ0JBQVUsRUFBRTtBQURKO0FBRlAsR0FoQjRCO0FBc0JyQ2lDLE1BQUksRUFBQztBQUNEOUUsbUJBQWUsRUFBQ0YsS0FBSyxDQUFDRyxPQUFOLENBQWM2RSxJQUFkLENBQW1CM0U7QUFEbEMsR0F0QmdDO0FBeUJyQytQLFNBQU8sRUFBRTtBQUNMN1YsWUFBUSxFQUFFLFVBREw7QUFFTCxnQkFBWTtBQUNSc1QsYUFBTyxFQUFFLElBREQ7QUFFUnRWLFdBQUssRUFBRSxNQUZDO0FBR1IwQyxZQUFNLEVBQUUsTUFIQTtBQUlSVixjQUFRLEVBQUUsVUFKRjtBQUtSQyxTQUFHLEVBQUUsR0FMRztBQU1SRSxZQUFNLEVBQUUsR0FOQTtBQU9SRCxVQUFJLEVBQUUsR0FQRTtBQVFSRSxXQUFLLEVBQUUsR0FSQztBQVNSK0gsWUFBTSxFQUFFO0FBVEE7QUFGUDtBQXpCNEIsQ0FBWixDQUFELENBQTVCO0FBeUNlbEQsd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDM0NBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU04USxZQUFZLEdBQUcsQ0FBQztBQUFFcFAsYUFBRjtBQUFldEMsT0FBZjtBQUFzQlMsVUFBUSxHQUFHO0FBQWpDLENBQUQsS0FBNkM7QUFDOUQsUUFBTUUsT0FBTyxHQUFHQyxtRUFBUyxFQUF6QjtBQUVBLHNCQUNJLHFFQUFDLHFEQUFEO0FBQUssV0FBTyxFQUFDLGNBQWI7QUFBNEIsYUFBUyxFQUFFRCxPQUFPLENBQUNnUixtQkFBL0M7QUFBQSwyQkFDSSxxRUFBQywyREFBRDtBQUFBLDhCQUNJLHFFQUFDLHFEQUFEO0FBQ0ksZUFBTyxFQUFDLE1BRFo7QUFFSSxrQkFBVSxFQUFDLFFBRmY7QUFHSSxpQkFBUyxFQUFFaFIsT0FBTyxDQUFDaVIsWUFIdkI7QUFJSSxnQkFBUSxFQUFDLFVBSmI7QUFLSSxjQUFNLEVBQUUsQ0FMWjtBQUFBLGdDQU1JLHFFQUFDLDREQUFEO0FBQVksbUJBQVMsRUFBRWpSLE9BQU8sQ0FBQ29NLFVBQS9CO0FBQTJDLGlCQUFPLEVBQUV6SyxXQUFwRDtBQUFBLGtDQUNJLHFFQUFDLHlEQUFEO0FBQWEsaUJBQUssRUFBQyxRQUFuQjtBQUE0QixnQkFBSSxFQUFFLEVBQWxDO0FBQXNDLHFCQUFTLEVBQUUzQixPQUFPLENBQUM4QztBQUF6RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBRUkscUVBQUMsdURBQUQ7QUFDSSxpQkFBSyxFQUFDLFFBRFY7QUFFSSxnQkFBSSxFQUFFLEVBRlY7QUFHSSx1QkFBVyxFQUFFLENBSGpCO0FBSUkscUJBQVMsRUFBRTlDLE9BQU8sQ0FBQzZDO0FBSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU5KLGVBZUkscUVBQUMscURBQUQ7QUFDSSxrQkFBUSxFQUFDLGFBRGI7QUFFSSxlQUFLLEVBQUMsY0FGVjtBQUdJLG9CQUFVLEVBQUMsaUJBSGY7QUFJSSxZQUFFLEVBQUUsQ0FKUjtBQUFBLG9CQU1LeEQ7QUFOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixFQXlCS1MsUUFBUSxnQkFDTCxxRUFBQyxxREFBRDtBQUNJLGVBQU8sRUFBQyxNQURaO0FBRUksa0JBQVUsRUFBQyxRQUZmO0FBR0ksc0JBQWMsRUFBQyxRQUhuQjtBQUlJLGFBQUssRUFBQyxNQUpWO0FBS0ksZ0JBQVEsRUFBQyxVQUxiO0FBTUksY0FBTSxFQUFFLENBTlo7QUFPSSxpQkFBUyxFQUFFRSxPQUFPLENBQUNrUixRQVB2QjtBQUFBLGtCQVFLcFI7QUFSTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURLLGdCQVlMLHFFQUFDLHFEQUFEO0FBQ0ksaUJBQVMsRUFBRUUsT0FBTyxDQUFDbVIsWUFEdkI7QUFFSSxlQUFPLEVBQUMsTUFGWjtBQUdJLGtCQUFVLEVBQUMsUUFIZjtBQUlJLGdCQUFRLEVBQUMsTUFKYjtBQUtJLGdCQUFRLEVBQUMsVUFMYjtBQU1JLGNBQU0sRUFBRSxDQU5aO0FBQUEsa0JBT0ssQ0FDRztBQUFFbFMsY0FBSSxFQUFFO0FBQVIsU0FESCxFQUVHO0FBQUVBLGNBQUksRUFBRTtBQUFSLFNBRkgsRUFHRztBQUFFQSxjQUFJLEVBQUU7QUFBUixTQUhILEVBSUc7QUFBRUEsY0FBSSxFQUFFO0FBQVIsU0FKSCxFQUtHO0FBQUVBLGNBQUksRUFBRTtBQUFSLFNBTEgsRUFNRztBQUFFQSxjQUFJLEVBQUU7QUFBUixTQU5ILEVBT0NPLEdBUEQsQ0FPSyxDQUFDQyxJQUFELEVBQU9tRyxLQUFQLGtCQUNGLHFFQUFDLHdEQUFEO0FBQVEsbUJBQVMsRUFBRTVGLE9BQU8sQ0FBQ2lOLEtBQTNCO0FBQUEsaUNBQ0kscUVBQUMscURBQUQ7QUFDSSxvQkFBUSxFQUFDLGFBRGI7QUFFSSxpQkFBSyxFQUFDLGNBRlY7QUFHSSxzQkFBVSxFQUFDLG9CQUhmO0FBQUEsc0JBSUt4TixJQUFJLENBQUNSO0FBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLFdBQXdDLEdBQUVRLElBQUksQ0FBQ1IsSUFBSyxJQUFHMkcsS0FBTSxFQUE3RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVJIO0FBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFyQ1I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBb0VILENBdkVEOztBQXdFQW1MLFlBQVksQ0FBQzVRLFNBQWIsR0FBeUI7QUFDckJ3QixhQUFXLEVBQUV2QixpREFBUyxDQUFDNkMsSUFERjtBQUVyQm5ELFVBQVEsRUFBRU0saURBQVMsQ0FBQ2tHLEdBRkM7QUFHckJqSCxPQUFLLEVBQUVlLGlEQUFTLENBQUM0STtBQUhJLENBQXpCO0FBS2VDLGlJQUFTLEdBQUc4SCxZQUFILENBQXhCLEU7Ozs7Ozs7Ozs7OztBQ3hGQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU05USxTQUFTLEdBQUdPLDJFQUFVLENBQUVDLEtBQUQsS0FBWTtBQUNyQ3VRLHFCQUFtQixFQUFFO0FBQ2pCcE4sa0JBQWMsRUFBRSxPQURDO0FBRWpCQyxzQkFBa0IsRUFBRSxRQUZIO0FBR2pCNEksMEJBQXNCLEVBQUVoTSxLQUFLLENBQUNpTSxPQUFOLENBQWMsQ0FBZCxDQUhQO0FBSWpCQywyQkFBdUIsRUFBRWxNLEtBQUssQ0FBQ2lNLE9BQU4sQ0FBYyxDQUFkLENBSlI7QUFLakJwUixXQUFPLEVBQUUsUUFMUTtBQU1qQk4sWUFBUSxFQUFFLFVBTk87QUFPakI4SSxtQkFBZSxFQUFHLDBCQVBEO0FBU2pCLEtBQUNyRCxLQUFLLENBQUMyQyxXQUFOLENBQWtCbUIsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQixpQkFBVztBQUNQdkosZ0JBQVEsRUFBRSxVQURIO0FBRVBDLFdBQUcsRUFBRSxHQUZFO0FBR1BDLFlBQUksRUFBRSxHQUhDO0FBSVBFLGFBQUssRUFBRSxHQUpBO0FBS1BwQyxhQUFLLEVBQUUsTUFMQTtBQU1Qc1YsZUFBTyxFQUFFLElBTkY7QUFPUHhLLHVCQUFlLEVBQUcsb0JBUFg7QUFRUGpJLGlCQUFTLEVBQUUsT0FSSjtBQVNQNFEsOEJBQXNCLEVBQUVoTSxLQUFLLENBQUNpTSxPQUFOLENBQWMsQ0FBZCxDQVRqQjtBQVVQQywrQkFBdUIsRUFBRWxNLEtBQUssQ0FBQ2lNLE9BQU4sQ0FBYyxDQUFkLENBVmxCO0FBV1A3SSwwQkFBa0IsRUFBRSxRQVhiO0FBWVBELHNCQUFjLEVBQUU7QUFaVDtBQURlLEtBVGI7QUF5QmpCLEtBQUNuRCxLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCeEgsZUFBUyxFQUFFO0FBRGlCO0FBekJmLEdBRGdCO0FBOEJyQ3NWLGNBQVksRUFBRTtBQUNWLEtBQUMxUSxLQUFLLENBQUMyQyxXQUFOLENBQWtCQyxJQUFsQixDQUF1QixJQUF2QixDQUFELEdBQWdDO0FBQzVCNUgsYUFBTyxFQUFFO0FBRG1CO0FBRHRCLEdBOUJ1QjtBQW9DckN3UixPQUFLLEVBQUU7QUFDSCxlQUFXO0FBQ1AsaUJBQVc7QUFDUGxNLGFBQUssRUFBRU4sS0FBSyxDQUFDRyxPQUFOLENBQWNtRCxPQUFkLENBQXNCeEM7QUFEdEI7QUFESixLQURSO0FBTUgsS0FBQ2QsS0FBSyxDQUFDMkMsV0FBTixDQUFrQkMsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBRCxHQUFnQztBQUM1QjdILFlBQU0sRUFBRztBQURtQjtBQU43QixHQXBDOEI7QUE4Q3JDNFEsWUFBVSxFQUFFO0FBQ1J6TCxtQkFBZSxFQUFFRixLQUFLLENBQUNPLE1BQU4sQ0FBYUMsS0FEdEI7QUFFUixlQUFXO0FBQ1BOLHFCQUFlLEVBQUVGLEtBQUssQ0FBQ08sTUFBTixDQUFhQyxLQUR2QjtBQUVQb0QsYUFBTyxFQUFFO0FBRkY7QUFGSCxHQTlDeUI7QUFxRHJDNE0sY0FBWSxFQUFFO0FBQ1YsS0FBQ3hRLEtBQUssQ0FBQzJDLFdBQU4sQ0FBa0JtQixFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCOUksYUFBTyxFQUFFO0FBRGlCO0FBRHBCLEdBckR1QjtBQTBEckN5VixVQUFRLEVBQUM7QUFDTCxLQUFDelEsS0FBSyxDQUFDMkMsV0FBTixDQUFrQkMsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBRCxHQUFnQztBQUM1Qi9ILGFBQU8sRUFBQztBQURvQjtBQUQzQixHQTFENEI7QUErRHJDd0gsZ0JBQWMsRUFBRTtBQUNackgsV0FBTyxFQUFFLE1BREc7QUFFWixLQUFDZ0YsS0FBSyxDQUFDMkMsV0FBTixDQUFrQm1CLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUI5SSxhQUFPLEVBQUU7QUFEaUI7QUFGbEIsR0EvRHFCO0FBcUVyQ29ILFdBQVMsRUFBRTtBQUNQcEgsV0FBTyxFQUFFLE1BREY7QUFFUCxLQUFDZ0YsS0FBSyxDQUFDMkMsV0FBTixDQUFrQkMsSUFBbEIsQ0FBdUIsSUFBdkIsQ0FBRCxHQUFnQztBQUM1QjVILGFBQU8sRUFBRTtBQURtQjtBQUZ6QjtBQXJFMEIsQ0FBWixDQUFELENBQTVCO0FBNkVld0Usd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDL0VBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQTtBQUFPLE1BQU02TCxNQUFNLEdBQUc7QUFDbEJzRixNQUFJLEVBQUU7QUFDRm5GLFNBQUssRUFBRSxHQURMO0FBQ1U7QUFDWm9GLFNBQUssRUFBRSxNQUZMO0FBR0ZDLFFBQUksRUFBRSxNQUhKO0FBSUZDLGdCQUFZLEVBQUU7QUFKWixHQURZO0FBT2xCQyxVQUFRLEVBQUU7QUFDTnZGLFNBQUssRUFBRSxXQUREO0FBQ2M7QUFDcEJvRixTQUFLLEVBQUUsVUFGRDtBQUdOQyxRQUFJLEVBQUUsVUFIQTtBQUlOQyxnQkFBWSxFQUFFO0FBSlIsR0FQUTtBQWFsQjFGLFlBQVUsRUFBRTtBQUNSSSxTQUFLLEVBQUUsUUFEQztBQUNTO0FBQ2pCb0YsU0FBSyxFQUFFLE9BRkM7QUFHUkMsUUFBSSxFQUFFO0FBSEUsR0FiTTtBQWtCbEJHLE9BQUssRUFBRTtBQUNIeEYsU0FBSyxFQUFFLFFBREo7QUFDYztBQUNqQm9GLFNBQUssRUFBRSxPQUZKO0FBR0hDLFFBQUksRUFBRSxPQUhIO0FBSUhDLGdCQUFZLEVBQUU7QUFKWCxHQWxCVztBQXlCbEJHLFNBQU8sRUFBRTtBQUNMO0FBQ0F6RixTQUFLLEVBQUUsVUFGRjtBQUVjO0FBQ25Cb0YsU0FBSyxFQUFFLFNBSEY7QUFJTEMsUUFBSSxFQUFFLFNBSkQ7QUFLTEMsZ0JBQVksRUFBRTtBQUxULEdBekJTO0FBZ0NsQkksU0FBTyxFQUFFO0FBQ0w7QUFDQTFGLFNBQUssRUFBRSxVQUZGO0FBRWM7QUFDbkJvRixTQUFLLEVBQUUsU0FIRjtBQUlMQyxRQUFJLEVBQUUsU0FKRDtBQUtMQyxnQkFBWSxFQUFFO0FBTFQsR0FoQ1M7QUF3Q2xCSyxTQUFPLEVBQUU7QUFDTDtBQUNBM0YsU0FBSyxFQUFFLFVBRkY7QUFFYztBQUNuQm9GLFNBQUssRUFBRSxTQUhGO0FBSUxDLFFBQUksRUFBRSxTQUpEO0FBS0xDLGdCQUFZLEVBQUU7QUFMVCxHQXhDUztBQWdEbEJNLGdCQUFjLEVBQUU7QUFDWjtBQUNBNUYsU0FBSyxFQUFFLGdCQUZLO0FBRWE7QUFDekJvRixTQUFLLEVBQUUsZ0JBSEs7QUFJWkMsUUFBSSxFQUFFLGdCQUpNO0FBS1pDLGdCQUFZLEVBQUU7QUFMRixHQWhERTtBQXdEbEJPLGFBQVcsRUFBRTtBQUNUO0FBQ0E3RixTQUFLLEVBQUUsYUFGRTtBQUVhO0FBQ3RCb0YsU0FBSyxFQUFFLGFBSEU7QUFJVEMsUUFBSSxFQUFFLGFBSkc7QUFLVEMsZ0JBQVksRUFBRTtBQUxMLEdBeERLO0FBZ0VsQlEsTUFBSSxFQUFFO0FBQ0Y7QUFDQTlGLFNBQUssRUFBRSxPQUZMO0FBRWM7QUFDaEJvRixTQUFLLEVBQUUsTUFITDtBQUlGQyxRQUFJLEVBQUUsTUFKSjtBQUtGQyxnQkFBWSxFQUFFO0FBTFosR0FoRVk7QUF3RWxCUyxhQUFXLEVBQUU7QUFDVDtBQUNBL0YsU0FBSyxFQUFFLGFBRkU7QUFFYTtBQUN0Qm9GLFNBQUssRUFBRSxhQUhFO0FBSVRDLFFBQUksRUFBRSxhQUpHO0FBS1RDLGdCQUFZLEVBQUU7QUFMTCxHQXhFSztBQWdGbEJVLGlCQUFlLEVBQUU7QUFDYjtBQUNBaEcsU0FBSyxFQUFFLGlCQUZNO0FBRWE7QUFDMUJvRixTQUFLLEVBQUUsaUJBSE07QUFJYkMsUUFBSSxFQUFFLGlCQUpPO0FBS2JDLGdCQUFZLEVBQUU7QUFMRCxHQWhGQztBQXdGbEJXLGlCQUFlLEVBQUU7QUFDYmpHLFNBQUssRUFBRSxpQkFETTtBQUNhO0FBQzFCb0YsU0FBSyxFQUFFLGlCQUZNO0FBR2JDLFFBQUksRUFBRSxpQkFITztBQUliQyxnQkFBWSxFQUFFO0FBSkQsR0F4RkM7QUE4RmxCWSx3QkFBc0IsRUFBRTtBQUNwQmxHLFNBQUssRUFBRSx1QkFEYTtBQUNZO0FBQ2hDb0YsU0FBSyxFQUFFLHdCQUZhO0FBR3BCQyxRQUFJLEVBQUUsd0JBSGM7QUFJcEJDLGdCQUFZLEVBQUU7QUFKTSxHQTlGTjtBQW9HbEJhLDJCQUF5QixFQUFFO0FBQ3ZCbkcsU0FBSyxFQUFFLDBCQURnQjtBQUNZO0FBQ25Db0YsU0FBSyxFQUFFLDJCQUZnQjtBQUd2QkMsUUFBSSxFQUFFLDJCQUhpQjtBQUl2QkMsZ0JBQVksRUFBRTtBQUpTLEdBcEdUO0FBMEdsQmMsa0JBQWdCLEVBQUU7QUFDZHBHLFNBQUssRUFBRSwrQkFETztBQUMwQjtBQUN4Q29GLFNBQUssRUFBRSx3QkFGTztBQUdkQyxRQUFJLEVBQUUsd0JBSFE7QUFJZEMsZ0JBQVksRUFBRTtBQUpBLEdBMUdBO0FBZ0hsQmUsc0JBQW9CLEVBQUU7QUFDbEJyRyxTQUFLLEVBQUUscUJBRFc7QUFDWTtBQUM5Qm9GLFNBQUssRUFBRSxzQkFGVztBQUdsQkMsUUFBSSxFQUFFLHNCQUhZO0FBSWxCQyxnQkFBWSxFQUFFO0FBSkksR0FoSEo7QUFzSGxCZ0IscUJBQW1CLEVBQUU7QUFDakJ0RyxTQUFLLEVBQUUsb0JBRFU7QUFDWTtBQUM3Qm9GLFNBQUssRUFBRSxxQkFGVTtBQUdqQkMsUUFBSSxFQUFFLHFCQUhXO0FBSWpCQyxnQkFBWSxFQUFFO0FBSkcsR0F0SEg7QUE0SGxCaUIsa0JBQWdCLEVBQUU7QUFDZHZHLFNBQUssRUFBRSxjQURPO0FBQ1M7QUFDdkJvRixTQUFLLEVBQUUsYUFGTztBQUdkQyxRQUFJLEVBQUU7QUFIUSxHQTVIQTtBQWlJbEJtQixtQkFBaUIsRUFBRTtBQUNmeEcsU0FBSyxFQUFFLHlCQURRO0FBQ21CO0FBQ2xDb0YsU0FBSyxFQUFFLHdCQUZRO0FBR2ZDLFFBQUksRUFBRSx3QkFIUztBQUlmQyxnQkFBWSxFQUFFO0FBSkMsR0FqSUQ7QUF1SWxCbUIsc0JBQW9CLEVBQUU7QUFDbEJ6RyxTQUFLLEVBQUUsa0JBRFc7QUFDUztBQUMzQm9GLFNBQUssRUFBRSxpQkFGVztBQUdsQkMsUUFBSSxFQUFFLGlCQUhZO0FBSWxCQyxnQkFBWSxFQUFFO0FBSkksR0F2SUo7QUE2SWxCb0IsZ0JBQWMsRUFBRTtBQUNaMUcsU0FBSyxFQUFFLGlCQURLO0FBQ2M7QUFDMUJvRixTQUFLLEVBQUUsU0FGSztBQUdaQyxRQUFJLEVBQUUsU0FITTtBQUlaQyxnQkFBWSxFQUFFO0FBSkYsR0E3SUU7QUFtSmxCcUIsd0JBQXNCLEVBQUU7QUFDcEIzRyxTQUFLLEVBQUUsbUJBRGE7QUFDUTtBQUM1Qm9GLFNBQUssRUFBRSx3QkFGYTtBQUdwQkMsUUFBSSxFQUFFLHdCQUhjO0FBSXBCQyxnQkFBWSxFQUFFO0FBSk0sR0FuSk47QUF5SmxCc0IsaUJBQWUsRUFBRTtBQUNiNUcsU0FBSyxFQUFFLHdCQURNO0FBQ29CO0FBQ2pDb0YsU0FBSyxFQUFFLGlCQUZNO0FBR2JDLFFBQUksRUFBRSxpQkFITztBQUliQyxnQkFBWSxFQUFFO0FBSkQsR0F6SkM7QUErSmxCdUIsYUFBVyxFQUFFO0FBQ1Q3RyxTQUFLLEVBQUUsb0JBREU7QUFDb0I7QUFDN0JvRixTQUFLLEVBQUUsYUFGRTtBQUdUQyxRQUFJLEVBQUUsYUFIRztBQUlUQyxnQkFBWSxFQUFFO0FBSkwsR0EvSks7QUFxS2xCd0IsdUJBQXFCLEVBQUU7QUFDbkI5RyxTQUFLLEVBQUUsK0JBRFk7QUFDcUI7QUFDeENvRixTQUFLLEVBQUUsdUJBRlk7QUFHbkJDLFFBQUksRUFBRSx1QkFIYTtBQUluQkMsZ0JBQVksRUFBRTtBQUpLLEdBcktMO0FBMktsQnlCLG1CQUFpQixFQUFFO0FBQ2YvRyxTQUFLLEVBQUUsb0JBRFE7QUFDYztBQUM3Qm9GLFNBQUssRUFBRSxtQkFGUTtBQUdmQyxRQUFJLEVBQUUsbUJBSFM7QUFJZkMsZ0JBQVksRUFBRTtBQUpDLEdBM0tEO0FBaUxsQjBCLG9CQUFrQixFQUFFO0FBQ2hCaEgsU0FBSyxFQUFFLHFCQURTO0FBQ2M7QUFDOUJvRixTQUFLLEVBQUUsb0JBRlM7QUFHaEJDLFFBQUksRUFBRSxvQkFIVTtBQUloQkMsZ0JBQVksRUFBRTtBQUpFLEdBakxGO0FBdUxsQjJCLGtCQUFnQixFQUFFO0FBQ2RqSCxTQUFLLEVBQUUsbUJBRE87QUFDYztBQUM1Qm9GLFNBQUssRUFBRSxrQkFGTztBQUdkQyxRQUFJLEVBQUUsa0JBSFE7QUFJZEMsZ0JBQVksRUFBRTtBQUpBLEdBdkxBO0FBNkxsQjRCLGtCQUFnQixFQUFFO0FBQ2RsSCxTQUFLLEVBQUUsbUJBRE87QUFDYztBQUM1Qm9GLFNBQUssRUFBRSxrQkFGTztBQUdkQyxRQUFJLEVBQUUsa0JBSFE7QUFJZEMsZ0JBQVksRUFBRTtBQUpBLEdBN0xBO0FBbU1sQjZCLDRCQUEwQixFQUFFO0FBQ3hCbkgsU0FBSyxFQUFFLDZCQURpQjtBQUNjO0FBQ3RDb0YsU0FBSyxFQUFFLDRCQUZpQjtBQUd4QkMsUUFBSSxFQUFFLDRCQUhrQjtBQUl4QkMsZ0JBQVksRUFBRTtBQUpVLEdBbk1WO0FBeU1sQjhCLG9CQUFrQixFQUFFO0FBQ2hCcEgsU0FBSyxFQUFFLHFCQURTO0FBQ2M7QUFDOUJvRixTQUFLLEVBQUUsb0JBRlM7QUFHaEJDLFFBQUksRUFBRSxvQkFIVTtBQUloQkMsZ0JBQVksRUFBRTtBQUpFLEdBek1GO0FBK01sQitCLGdCQUFjLEVBQUU7QUFDWnJILFNBQUssRUFBRSxpQkFESztBQUNjO0FBQzFCb0YsU0FBSyxFQUFFLGdCQUZLO0FBR1pDLFFBQUksRUFBRSxnQkFITTtBQUlaQyxnQkFBWSxFQUFFO0FBSkYsR0EvTUU7QUFxTmxCZ0MsaUJBQWUsRUFBRTtBQUNidEgsU0FBSyxFQUFFLGtCQURNO0FBQ2M7QUFDM0JvRixTQUFLLEVBQUUsaUJBRk07QUFHYkMsUUFBSSxFQUFFLGlCQUhPO0FBSWJDLGdCQUFZLEVBQUU7QUFKRDtBQXJOQyxDQUFmLEM7Ozs7Ozs7Ozs7OztBQ0FQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1pQyxlQUFlLEdBQUcsQ0FBQ0MsR0FBRCxFQUFNL08sS0FBTixLQUFnQjtBQUMzQyxNQUFJZ1AsWUFBWSxHQUFHaFAsS0FBbkI7O0FBQ0EsTUFBSSxPQUFPQSxLQUFQLEtBQWlCLFFBQXJCLEVBQStCO0FBQzNCZ1AsZ0JBQVksR0FBR3RaLElBQUksQ0FBQ3VaLFNBQUwsQ0FBZWpQLEtBQWYsQ0FBZjtBQUNIOztBQUNEa1AsUUFBTSxDQUFDQyxZQUFQLENBQW9CQyxPQUFwQixDQUE0QkwsR0FBNUIsRUFBaUNDLFlBQWpDO0FBQ0gsQ0FOTTtBQVFQO0FBQ0E7QUFDQTtBQUNBOztBQUNPLE1BQU1LLGVBQWUsR0FBSU4sR0FBRCxJQUFTO0FBQ3BDLFFBQU0vTyxLQUFLLEdBQUdrUCxNQUFNLENBQUNDLFlBQVAsQ0FBb0JHLE9BQXBCLENBQTRCUCxHQUE1QixDQUFkO0FBQ0EsU0FBTy9PLEtBQUssSUFBSXRLLElBQUksQ0FBQzZaLEtBQUwsQ0FBV3ZQLEtBQVgsQ0FBaEI7QUFDSCxDQUhNO0FBS1A7QUFDQTtBQUNBOztBQUNPLE1BQU13UCxrQkFBa0IsR0FBSVQsR0FBRCxJQUFTO0FBQ3ZDLFFBQU0vTyxLQUFLLEdBQUdxUCxlQUFlLENBQUNOLEdBQUQsQ0FBN0I7QUFDQUcsUUFBTSxDQUFDQyxZQUFQLENBQW9CTSxVQUFwQixDQUErQlYsR0FBL0I7QUFDQSxTQUFPL08sS0FBUDtBQUNILENBSk0sQzs7Ozs7Ozs7Ozs7O0FDekJQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0NBRUE7O0FBQ08sTUFBTTBQLFVBQVUsR0FBRyxNQUFNO0FBQzVCLFNBQU81Yix3QkFBUDtBQUNILENBRk0sQyxDQUdQOztBQUNPLE1BQU02WCxJQUFJLEdBQUcsTUFBTSxDQUFFLENBQXJCO0FBRUEsTUFBTWdFLGNBQWMsR0FBRyxNQUFNO0FBQ2hDLFNBQU83YixlQUFQO0FBQ0gsQ0FGTTtBQUlBLE1BQU04YixTQUFTLEdBQUcsTUFBTTtBQUMzQixRQUFNQyxVQUFVLEdBQUdSLHFFQUFlLENBQUMsY0FBRCxDQUFmLElBQW1DLEVBQXREO0FBQ0EsU0FBT1EsVUFBUCxhQUFPQSxVQUFQLHVCQUFPQSxVQUFVLENBQUVDLE9BQW5CO0FBQ0gsQ0FITTtBQUtBLE1BQU1DLGNBQWMsR0FBRyxNQUFNO0FBQ2hDLFFBQU1GLFVBQVUsR0FBR1IscUVBQWUsQ0FBQyxjQUFELENBQWYsSUFBbUMsRUFBdEQ7QUFDQSxTQUFPUSxVQUFQLGFBQU9BLFVBQVAsdUJBQU9BLFVBQVUsQ0FBRUcsWUFBbkI7QUFDSCxDQUhNLEM7Ozs7Ozs7Ozs7O0FDbEJQLDhDOzs7Ozs7Ozs7OztBQ0FBLG9EOzs7Ozs7Ozs7OztBQ0FBLGtEOzs7Ozs7Ozs7OztBQ0FBLG1EOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLDREOzs7Ozs7Ozs7OztBQ0FBLHdEOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLDZDOzs7Ozs7Ozs7OztBQ0FBLGlDOzs7Ozs7Ozs7OztBQ0FBLGdEOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLHVDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLDBDOzs7Ozs7Ozs7OztBQ0FBLGtEIiwiZmlsZSI6InBhZ2VzL2Rhc2hib2FyZHBhZ2VzdHlsZS5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0gcmVxdWlyZSgnLi4vc3NyLW1vZHVsZS1jYWNoZS5qcycpO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHR2YXIgdGhyZXcgPSB0cnVlO1xuIFx0XHR0cnkge1xuIFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuIFx0XHRcdHRocmV3ID0gZmFsc2U7XG4gXHRcdH0gZmluYWxseSB7XG4gXHRcdFx0aWYodGhyZXcpIGRlbGV0ZSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXTtcbiBcdFx0fVxuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSBcIi4vc3JjL3BhZ2VzL2Rhc2hib2FyZHBhZ2VzdHlsZS9pbmRleC5qc1wiKTtcbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvaGVhZC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL3RvLWJhc2UtNjQuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9pbWFnZS1jb25maWcuanNcIik7IiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IEhlYWQgZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL2hlYWQnXG5pbXBvcnQgeyB0b0Jhc2U2NCB9IGZyb20gJy4uL25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0J1xuaW1wb3J0IHtcbiAgSW1hZ2VDb25maWcsXG4gIGltYWdlQ29uZmlnRGVmYXVsdCxcbiAgTG9hZGVyVmFsdWUsXG4gIFZBTElEX0xPQURFUlMsXG59IGZyb20gJy4uL25leHQtc2VydmVyL3NlcnZlci9pbWFnZS1jb25maWcnXG5pbXBvcnQgeyB1c2VJbnRlcnNlY3Rpb24gfSBmcm9tICcuL3VzZS1pbnRlcnNlY3Rpb24nXG5cbmlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xuICA7KGdsb2JhbCBhcyBhbnkpLl9fTkVYVF9JTUFHRV9JTVBPUlRFRCA9IHRydWVcbn1cblxuY29uc3QgVkFMSURfTE9BRElOR19WQUxVRVMgPSBbJ2xhenknLCAnZWFnZXInLCB1bmRlZmluZWRdIGFzIGNvbnN0XG50eXBlIExvYWRpbmdWYWx1ZSA9IHR5cGVvZiBWQUxJRF9MT0FESU5HX1ZBTFVFU1tudW1iZXJdXG5cbmV4cG9ydCB0eXBlIEltYWdlTG9hZGVyID0gKHJlc29sdmVyUHJvcHM6IEltYWdlTG9hZGVyUHJvcHMpID0+IHN0cmluZ1xuXG5leHBvcnQgdHlwZSBJbWFnZUxvYWRlclByb3BzID0ge1xuICBzcmM6IHN0cmluZ1xuICB3aWR0aDogbnVtYmVyXG4gIHF1YWxpdHk/OiBudW1iZXJcbn1cblxudHlwZSBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcyA9IEltYWdlTG9hZGVyUHJvcHMgJiB7IHJvb3Q6IHN0cmluZyB9XG5cbmNvbnN0IGxvYWRlcnMgPSBuZXcgTWFwPFxuICBMb2FkZXJWYWx1ZSxcbiAgKHByb3BzOiBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcykgPT4gc3RyaW5nXG4+KFtcbiAgWydpbWdpeCcsIGltZ2l4TG9hZGVyXSxcbiAgWydjbG91ZGluYXJ5JywgY2xvdWRpbmFyeUxvYWRlcl0sXG4gIFsnYWthbWFpJywgYWthbWFpTG9hZGVyXSxcbiAgWydkZWZhdWx0JywgZGVmYXVsdExvYWRlcl0sXG5dKVxuXG5jb25zdCBWQUxJRF9MQVlPVVRfVkFMVUVTID0gW1xuICAnZmlsbCcsXG4gICdmaXhlZCcsXG4gICdpbnRyaW5zaWMnLFxuICAncmVzcG9uc2l2ZScsXG4gIHVuZGVmaW5lZCxcbl0gYXMgY29uc3RcbnR5cGUgTGF5b3V0VmFsdWUgPSB0eXBlb2YgVkFMSURfTEFZT1VUX1ZBTFVFU1tudW1iZXJdXG5cbnR5cGUgSW1nRWxlbWVudFN0eWxlID0gTm9uTnVsbGFibGU8SlNYLkludHJpbnNpY0VsZW1lbnRzWydpbWcnXVsnc3R5bGUnXT5cblxuZXhwb3J0IHR5cGUgSW1hZ2VQcm9wcyA9IE9taXQ8XG4gIEpTWC5JbnRyaW5zaWNFbGVtZW50c1snaW1nJ10sXG4gICdzcmMnIHwgJ3NyY1NldCcgfCAncmVmJyB8ICd3aWR0aCcgfCAnaGVpZ2h0JyB8ICdsb2FkaW5nJyB8ICdzdHlsZSdcbj4gJiB7XG4gIHNyYzogc3RyaW5nXG4gIGxvYWRlcj86IEltYWdlTG9hZGVyXG4gIHF1YWxpdHk/OiBudW1iZXIgfCBzdHJpbmdcbiAgcHJpb3JpdHk/OiBib29sZWFuXG4gIGxvYWRpbmc/OiBMb2FkaW5nVmFsdWVcbiAgdW5vcHRpbWl6ZWQ/OiBib29sZWFuXG4gIG9iamVjdEZpdD86IEltZ0VsZW1lbnRTdHlsZVsnb2JqZWN0Rml0J11cbiAgb2JqZWN0UG9zaXRpb24/OiBJbWdFbGVtZW50U3R5bGVbJ29iamVjdFBvc2l0aW9uJ11cbn0gJiAoXG4gICAgfCB7XG4gICAgICAgIHdpZHRoPzogbmV2ZXJcbiAgICAgICAgaGVpZ2h0PzogbmV2ZXJcbiAgICAgICAgLyoqIEBkZXByZWNhdGVkIFVzZSBgbGF5b3V0PVwiZmlsbFwiYCBpbnN0ZWFkICovXG4gICAgICAgIHVuc2l6ZWQ6IHRydWVcbiAgICAgIH1cbiAgICB8IHsgd2lkdGg/OiBuZXZlcjsgaGVpZ2h0PzogbmV2ZXI7IGxheW91dDogJ2ZpbGwnIH1cbiAgICB8IHtcbiAgICAgICAgd2lkdGg6IG51bWJlciB8IHN0cmluZ1xuICAgICAgICBoZWlnaHQ6IG51bWJlciB8IHN0cmluZ1xuICAgICAgICBsYXlvdXQ/OiBFeGNsdWRlPExheW91dFZhbHVlLCAnZmlsbCc+XG4gICAgICB9XG4gIClcblxuY29uc3Qge1xuICBkZXZpY2VTaXplczogY29uZmlnRGV2aWNlU2l6ZXMsXG4gIGltYWdlU2l6ZXM6IGNvbmZpZ0ltYWdlU2l6ZXMsXG4gIGxvYWRlcjogY29uZmlnTG9hZGVyLFxuICBwYXRoOiBjb25maWdQYXRoLFxuICBkb21haW5zOiBjb25maWdEb21haW5zLFxufSA9XG4gICgocHJvY2Vzcy5lbnYuX19ORVhUX0lNQUdFX09QVFMgYXMgYW55KSBhcyBJbWFnZUNvbmZpZykgfHwgaW1hZ2VDb25maWdEZWZhdWx0XG4vLyBzb3J0IHNtYWxsZXN0IHRvIGxhcmdlc3RcbmNvbnN0IGFsbFNpemVzID0gWy4uLmNvbmZpZ0RldmljZVNpemVzLCAuLi5jb25maWdJbWFnZVNpemVzXVxuY29uZmlnRGV2aWNlU2l6ZXMuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5hbGxTaXplcy5zb3J0KChhLCBiKSA9PiBhIC0gYilcblxuZnVuY3Rpb24gZ2V0V2lkdGhzKFxuICB3aWR0aDogbnVtYmVyIHwgdW5kZWZpbmVkLFxuICBsYXlvdXQ6IExheW91dFZhbHVlXG4pOiB7IHdpZHRoczogbnVtYmVyW107IGtpbmQ6ICd3JyB8ICd4JyB9IHtcbiAgaWYgKFxuICAgIHR5cGVvZiB3aWR0aCAhPT0gJ251bWJlcicgfHxcbiAgICBsYXlvdXQgPT09ICdmaWxsJyB8fFxuICAgIGxheW91dCA9PT0gJ3Jlc3BvbnNpdmUnXG4gICkge1xuICAgIHJldHVybiB7IHdpZHRoczogY29uZmlnRGV2aWNlU2l6ZXMsIGtpbmQ6ICd3JyB9XG4gIH1cblxuICBjb25zdCB3aWR0aHMgPSBbXG4gICAgLi4ubmV3IFNldChcbiAgICAgIC8vID4gVGhpcyBtZWFucyB0aGF0IG1vc3QgT0xFRCBzY3JlZW5zIHRoYXQgc2F5IHRoZXkgYXJlIDN4IHJlc29sdXRpb24sXG4gICAgICAvLyA+IGFyZSBhY3R1YWxseSAzeCBpbiB0aGUgZ3JlZW4gY29sb3IsIGJ1dCBvbmx5IDEuNXggaW4gdGhlIHJlZCBhbmRcbiAgICAgIC8vID4gYmx1ZSBjb2xvcnMuIFNob3dpbmcgYSAzeCByZXNvbHV0aW9uIGltYWdlIGluIHRoZSBhcHAgdnMgYSAyeFxuICAgICAgLy8gPiByZXNvbHV0aW9uIGltYWdlIHdpbGwgYmUgdmlzdWFsbHkgdGhlIHNhbWUsIHRob3VnaCB0aGUgM3ggaW1hZ2VcbiAgICAgIC8vID4gdGFrZXMgc2lnbmlmaWNhbnRseSBtb3JlIGRhdGEuIEV2ZW4gdHJ1ZSAzeCByZXNvbHV0aW9uIHNjcmVlbnMgYXJlXG4gICAgICAvLyA+IHdhc3RlZnVsIGFzIHRoZSBodW1hbiBleWUgY2Fubm90IHNlZSB0aGF0IGxldmVsIG9mIGRldGFpbCB3aXRob3V0XG4gICAgICAvLyA+IHNvbWV0aGluZyBsaWtlIGEgbWFnbmlmeWluZyBnbGFzcy5cbiAgICAgIC8vIGh0dHBzOi8vYmxvZy50d2l0dGVyLmNvbS9lbmdpbmVlcmluZy9lbl91cy90b3BpY3MvaW5mcmFzdHJ1Y3R1cmUvMjAxOS9jYXBwaW5nLWltYWdlLWZpZGVsaXR5LW9uLXVsdHJhLWhpZ2gtcmVzb2x1dGlvbi1kZXZpY2VzLmh0bWxcbiAgICAgIFt3aWR0aCwgd2lkdGggKiAyIC8qLCB3aWR0aCAqIDMqL10ubWFwKFxuICAgICAgICAodykgPT4gYWxsU2l6ZXMuZmluZCgocCkgPT4gcCA+PSB3KSB8fCBhbGxTaXplc1thbGxTaXplcy5sZW5ndGggLSAxXVxuICAgICAgKVxuICAgICksXG4gIF1cbiAgcmV0dXJuIHsgd2lkdGhzLCBraW5kOiAneCcgfVxufVxuXG50eXBlIEdlbkltZ0F0dHJzRGF0YSA9IHtcbiAgc3JjOiBzdHJpbmdcbiAgdW5vcHRpbWl6ZWQ6IGJvb2xlYW5cbiAgbGF5b3V0OiBMYXlvdXRWYWx1ZVxuICBsb2FkZXI6IEltYWdlTG9hZGVyXG4gIHdpZHRoPzogbnVtYmVyXG4gIHF1YWxpdHk/OiBudW1iZXJcbiAgc2l6ZXM/OiBzdHJpbmdcbn1cblxudHlwZSBHZW5JbWdBdHRyc1Jlc3VsdCA9IHtcbiAgc3JjOiBzdHJpbmdcbiAgc3JjU2V0OiBzdHJpbmcgfCB1bmRlZmluZWRcbiAgc2l6ZXM6IHN0cmluZyB8IHVuZGVmaW5lZFxufVxuXG5mdW5jdGlvbiBnZW5lcmF0ZUltZ0F0dHJzKHtcbiAgc3JjLFxuICB1bm9wdGltaXplZCxcbiAgbGF5b3V0LFxuICB3aWR0aCxcbiAgcXVhbGl0eSxcbiAgc2l6ZXMsXG4gIGxvYWRlcixcbn06IEdlbkltZ0F0dHJzRGF0YSk6IEdlbkltZ0F0dHJzUmVzdWx0IHtcbiAgaWYgKHVub3B0aW1pemVkKSB7XG4gICAgcmV0dXJuIHsgc3JjLCBzcmNTZXQ6IHVuZGVmaW5lZCwgc2l6ZXM6IHVuZGVmaW5lZCB9XG4gIH1cblxuICBjb25zdCB7IHdpZHRocywga2luZCB9ID0gZ2V0V2lkdGhzKHdpZHRoLCBsYXlvdXQpXG4gIGNvbnN0IGxhc3QgPSB3aWR0aHMubGVuZ3RoIC0gMVxuXG4gIHJldHVybiB7XG4gICAgc3JjOiBsb2FkZXIoeyBzcmMsIHF1YWxpdHksIHdpZHRoOiB3aWR0aHNbbGFzdF0gfSksXG4gICAgc2l6ZXM6ICFzaXplcyAmJiBraW5kID09PSAndycgPyAnMTAwdncnIDogc2l6ZXMsXG4gICAgc3JjU2V0OiB3aWR0aHNcbiAgICAgIC5tYXAoXG4gICAgICAgICh3LCBpKSA9PlxuICAgICAgICAgIGAke2xvYWRlcih7IHNyYywgcXVhbGl0eSwgd2lkdGg6IHcgfSl9ICR7XG4gICAgICAgICAgICBraW5kID09PSAndycgPyB3IDogaSArIDFcbiAgICAgICAgICB9JHtraW5kfWBcbiAgICAgIClcbiAgICAgIC5qb2luKCcsICcpLFxuICB9XG59XG5cbmZ1bmN0aW9uIGdldEludCh4OiB1bmtub3duKTogbnVtYmVyIHwgdW5kZWZpbmVkIHtcbiAgaWYgKHR5cGVvZiB4ID09PSAnbnVtYmVyJykge1xuICAgIHJldHVybiB4XG4gIH1cbiAgaWYgKHR5cGVvZiB4ID09PSAnc3RyaW5nJykge1xuICAgIHJldHVybiBwYXJzZUludCh4LCAxMClcbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkXG59XG5cbmZ1bmN0aW9uIGRlZmF1bHRJbWFnZUxvYWRlcihsb2FkZXJQcm9wczogSW1hZ2VMb2FkZXJQcm9wcykge1xuICBjb25zdCBsb2FkID0gbG9hZGVycy5nZXQoY29uZmlnTG9hZGVyKVxuICBpZiAobG9hZCkge1xuICAgIHJldHVybiBsb2FkKHsgcm9vdDogY29uZmlnUGF0aCwgLi4ubG9hZGVyUHJvcHMgfSlcbiAgfVxuICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgYFVua25vd24gXCJsb2FkZXJcIiBmb3VuZCBpbiBcIm5leHQuY29uZmlnLmpzXCIuIEV4cGVjdGVkOiAke1ZBTElEX0xPQURFUlMuam9pbihcbiAgICAgICcsICdcbiAgICApfS4gUmVjZWl2ZWQ6ICR7Y29uZmlnTG9hZGVyfWBcbiAgKVxufVxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBJbWFnZSh7XG4gIHNyYyxcbiAgc2l6ZXMsXG4gIHVub3B0aW1pemVkID0gZmFsc2UsXG4gIHByaW9yaXR5ID0gZmFsc2UsXG4gIGxvYWRpbmcsXG4gIGNsYXNzTmFtZSxcbiAgcXVhbGl0eSxcbiAgd2lkdGgsXG4gIGhlaWdodCxcbiAgb2JqZWN0Rml0LFxuICBvYmplY3RQb3NpdGlvbixcbiAgbG9hZGVyID0gZGVmYXVsdEltYWdlTG9hZGVyLFxuICAuLi5hbGxcbn06IEltYWdlUHJvcHMpIHtcbiAgbGV0IHJlc3Q6IFBhcnRpYWw8SW1hZ2VQcm9wcz4gPSBhbGxcbiAgbGV0IGxheW91dDogTm9uTnVsbGFibGU8TGF5b3V0VmFsdWU+ID0gc2l6ZXMgPyAncmVzcG9uc2l2ZScgOiAnaW50cmluc2ljJ1xuICBsZXQgdW5zaXplZCA9IGZhbHNlXG4gIGlmICgndW5zaXplZCcgaW4gcmVzdCkge1xuICAgIHVuc2l6ZWQgPSBCb29sZWFuKHJlc3QudW5zaXplZClcbiAgICAvLyBSZW1vdmUgcHJvcGVydHkgc28gaXQncyBub3Qgc3ByZWFkIGludG8gaW1hZ2U6XG4gICAgZGVsZXRlIHJlc3RbJ3Vuc2l6ZWQnXVxuICB9IGVsc2UgaWYgKCdsYXlvdXQnIGluIHJlc3QpIHtcbiAgICAvLyBPdmVycmlkZSBkZWZhdWx0IGxheW91dCBpZiB0aGUgdXNlciBzcGVjaWZpZWQgb25lOlxuICAgIGlmIChyZXN0LmxheW91dCkgbGF5b3V0ID0gcmVzdC5sYXlvdXRcblxuICAgIC8vIFJlbW92ZSBwcm9wZXJ0eSBzbyBpdCdzIG5vdCBzcHJlYWQgaW50byBpbWFnZTpcbiAgICBkZWxldGUgcmVzdFsnbGF5b3V0J11cbiAgfVxuXG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgaWYgKCFzcmMpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEltYWdlIGlzIG1pc3NpbmcgcmVxdWlyZWQgXCJzcmNcIiBwcm9wZXJ0eS4gTWFrZSBzdXJlIHlvdSBwYXNzIFwic3JjXCIgaW4gcHJvcHMgdG8gdGhlIFxcYG5leHQvaW1hZ2VcXGAgY29tcG9uZW50LiBSZWNlaXZlZDogJHtKU09OLnN0cmluZ2lmeShcbiAgICAgICAgICB7IHdpZHRoLCBoZWlnaHQsIHF1YWxpdHkgfVxuICAgICAgICApfWBcbiAgICAgIClcbiAgICB9XG4gICAgaWYgKCFWQUxJRF9MQVlPVVRfVkFMVUVTLmluY2x1ZGVzKGxheW91dCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaGFzIGludmFsaWQgXCJsYXlvdXRcIiBwcm9wZXJ0eS4gUHJvdmlkZWQgXCIke2xheW91dH1cIiBzaG91bGQgYmUgb25lIG9mICR7VkFMSURfTEFZT1VUX1ZBTFVFUy5tYXAoXG4gICAgICAgICAgU3RyaW5nXG4gICAgICAgICkuam9pbignLCcpfS5gXG4gICAgICApXG4gICAgfVxuICAgIGlmICghVkFMSURfTE9BRElOR19WQUxVRVMuaW5jbHVkZXMobG9hZGluZykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaGFzIGludmFsaWQgXCJsb2FkaW5nXCIgcHJvcGVydHkuIFByb3ZpZGVkIFwiJHtsb2FkaW5nfVwiIHNob3VsZCBiZSBvbmUgb2YgJHtWQUxJRF9MT0FESU5HX1ZBTFVFUy5tYXAoXG4gICAgICAgICAgU3RyaW5nXG4gICAgICAgICkuam9pbignLCcpfS5gXG4gICAgICApXG4gICAgfVxuICAgIGlmIChwcmlvcml0eSAmJiBsb2FkaW5nID09PSAnbGF6eScpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaGFzIGJvdGggXCJwcmlvcml0eVwiIGFuZCBcImxvYWRpbmc9J2xhenknXCIgcHJvcGVydGllcy4gT25seSBvbmUgc2hvdWxkIGJlIHVzZWQuYFxuICAgICAgKVxuICAgIH1cbiAgICBpZiAodW5zaXplZCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgZGVwcmVjYXRlZCBcInVuc2l6ZWRcIiBwcm9wZXJ0eSwgd2hpY2ggd2FzIHJlbW92ZWQgaW4gZmF2b3Igb2YgdGhlIFwibGF5b3V0PSdmaWxsJ1wiIHByb3BlcnR5YFxuICAgICAgKVxuICAgIH1cbiAgfVxuXG4gIGxldCBpc0xhenkgPVxuICAgICFwcmlvcml0eSAmJiAobG9hZGluZyA9PT0gJ2xhenknIHx8IHR5cGVvZiBsb2FkaW5nID09PSAndW5kZWZpbmVkJylcbiAgaWYgKHNyYyAmJiBzcmMuc3RhcnRzV2l0aCgnZGF0YTonKSkge1xuICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0hUVFAvQmFzaWNzX29mX0hUVFAvRGF0YV9VUklzXG4gICAgdW5vcHRpbWl6ZWQgPSB0cnVlXG4gICAgaXNMYXp5ID0gZmFsc2VcbiAgfVxuXG4gIGNvbnN0IFtzZXRSZWYsIGlzSW50ZXJzZWN0ZWRdID0gdXNlSW50ZXJzZWN0aW9uPEhUTUxJbWFnZUVsZW1lbnQ+KHtcbiAgICByb290TWFyZ2luOiAnMjAwcHgnLFxuICAgIGRpc2FibGVkOiAhaXNMYXp5LFxuICB9KVxuICBjb25zdCBpc1Zpc2libGUgPSAhaXNMYXp5IHx8IGlzSW50ZXJzZWN0ZWRcblxuICBjb25zdCB3aWR0aEludCA9IGdldEludCh3aWR0aClcbiAgY29uc3QgaGVpZ2h0SW50ID0gZ2V0SW50KGhlaWdodClcbiAgY29uc3QgcXVhbGl0eUludCA9IGdldEludChxdWFsaXR5KVxuXG4gIGxldCB3cmFwcGVyU3R5bGU6IEpTWC5JbnRyaW5zaWNFbGVtZW50c1snZGl2J11bJ3N0eWxlJ10gfCB1bmRlZmluZWRcbiAgbGV0IHNpemVyU3R5bGU6IEpTWC5JbnRyaW5zaWNFbGVtZW50c1snZGl2J11bJ3N0eWxlJ10gfCB1bmRlZmluZWRcbiAgbGV0IHNpemVyU3ZnOiBzdHJpbmcgfCB1bmRlZmluZWRcbiAgbGV0IGltZ1N0eWxlOiBJbWdFbGVtZW50U3R5bGUgfCB1bmRlZmluZWQgPSB7XG4gICAgdmlzaWJpbGl0eTogaXNWaXNpYmxlID8gJ2luaGVyaXQnIDogJ2hpZGRlbicsXG5cbiAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICB0b3A6IDAsXG4gICAgbGVmdDogMCxcbiAgICBib3R0b206IDAsXG4gICAgcmlnaHQ6IDAsXG5cbiAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICBwYWRkaW5nOiAwLFxuICAgIGJvcmRlcjogJ25vbmUnLFxuICAgIG1hcmdpbjogJ2F1dG8nLFxuXG4gICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICB3aWR0aDogMCxcbiAgICBoZWlnaHQ6IDAsXG4gICAgbWluV2lkdGg6ICcxMDAlJyxcbiAgICBtYXhXaWR0aDogJzEwMCUnLFxuICAgIG1pbkhlaWdodDogJzEwMCUnLFxuICAgIG1heEhlaWdodDogJzEwMCUnLFxuXG4gICAgb2JqZWN0Rml0LFxuICAgIG9iamVjdFBvc2l0aW9uLFxuICB9XG4gIGlmIChcbiAgICB0eXBlb2Ygd2lkdGhJbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGhlaWdodEludCAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICBsYXlvdXQgIT09ICdmaWxsJ1xuICApIHtcbiAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIC8+XG4gICAgY29uc3QgcXVvdGllbnQgPSBoZWlnaHRJbnQgLyB3aWR0aEludFxuICAgIGNvbnN0IHBhZGRpbmdUb3AgPSBpc05hTihxdW90aWVudCkgPyAnMTAwJScgOiBgJHtxdW90aWVudCAqIDEwMH0lYFxuICAgIGlmIChsYXlvdXQgPT09ICdyZXNwb25zaXZlJykge1xuICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJyZXNwb25zaXZlXCIgLz5cbiAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcblxuICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgbWFyZ2luOiAwLFxuICAgICAgfVxuICAgICAgc2l6ZXJTdHlsZSA9IHsgZGlzcGxheTogJ2Jsb2NrJywgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsIHBhZGRpbmdUb3AgfVxuICAgIH0gZWxzZSBpZiAobGF5b3V0ID09PSAnaW50cmluc2ljJykge1xuICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJpbnRyaW5zaWNcIiAvPlxuICAgICAgd3JhcHBlclN0eWxlID0ge1xuICAgICAgICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyxcbiAgICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgIG1hcmdpbjogMCxcbiAgICAgIH1cbiAgICAgIHNpemVyU3R5bGUgPSB7XG4gICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICBtYXhXaWR0aDogJzEwMCUnLFxuICAgICAgfVxuICAgICAgc2l6ZXJTdmcgPSBgPHN2ZyB3aWR0aD1cIiR7d2lkdGhJbnR9XCIgaGVpZ2h0PVwiJHtoZWlnaHRJbnR9XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZlcnNpb249XCIxLjFcIi8+YFxuICAgIH0gZWxzZSBpZiAobGF5b3V0ID09PSAnZml4ZWQnKSB7XG4gICAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIGxheW91dD1cImZpeGVkXCIgLz5cbiAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgZGlzcGxheTogJ2lubGluZS1ibG9jaycsXG4gICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgICB3aWR0aDogd2lkdGhJbnQsXG4gICAgICAgIGhlaWdodDogaGVpZ2h0SW50LFxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIGlmIChcbiAgICB0eXBlb2Ygd2lkdGhJbnQgPT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGhlaWdodEludCA9PT0gJ3VuZGVmaW5lZCcgJiZcbiAgICBsYXlvdXQgPT09ICdmaWxsJ1xuICApIHtcbiAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiBsYXlvdXQ9XCJmaWxsXCIgLz5cbiAgICB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuXG4gICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgIHRvcDogMCxcbiAgICAgIGxlZnQ6IDAsXG4gICAgICBib3R0b206IDAsXG4gICAgICByaWdodDogMCxcblxuICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICBtYXJnaW46IDAsXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIC8+XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgbXVzdCB1c2UgXCJ3aWR0aFwiIGFuZCBcImhlaWdodFwiIHByb3BlcnRpZXMgb3IgXCJsYXlvdXQ9J2ZpbGwnXCIgcHJvcGVydHkuYFxuICAgICAgKVxuICAgIH1cbiAgfVxuXG4gIGxldCBpbWdBdHRyaWJ1dGVzOiBHZW5JbWdBdHRyc1Jlc3VsdCA9IHtcbiAgICBzcmM6XG4gICAgICAnZGF0YTppbWFnZS9naWY7YmFzZTY0LFIwbEdPRGxoQVFBQkFJQUFBQUFBQVAvLy95SDVCQUVBQUFBQUxBQUFBQUFCQUFFQUFBSUJSQUE3JyxcbiAgICBzcmNTZXQ6IHVuZGVmaW5lZCxcbiAgICBzaXplczogdW5kZWZpbmVkLFxuICB9XG5cbiAgaWYgKGlzVmlzaWJsZSkge1xuICAgIGltZ0F0dHJpYnV0ZXMgPSBnZW5lcmF0ZUltZ0F0dHJzKHtcbiAgICAgIHNyYyxcbiAgICAgIHVub3B0aW1pemVkLFxuICAgICAgbGF5b3V0LFxuICAgICAgd2lkdGg6IHdpZHRoSW50LFxuICAgICAgcXVhbGl0eTogcXVhbGl0eUludCxcbiAgICAgIHNpemVzLFxuICAgICAgbG9hZGVyLFxuICAgIH0pXG4gIH1cblxuICBpZiAodW5zaXplZCkge1xuICAgIHdyYXBwZXJTdHlsZSA9IHVuZGVmaW5lZFxuICAgIHNpemVyU3R5bGUgPSB1bmRlZmluZWRcbiAgICBpbWdTdHlsZSA9IHVuZGVmaW5lZFxuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17d3JhcHBlclN0eWxlfT5cbiAgICAgIHtzaXplclN0eWxlID8gKFxuICAgICAgICA8ZGl2IHN0eWxlPXtzaXplclN0eWxlfT5cbiAgICAgICAgICB7c2l6ZXJTdmcgPyAoXG4gICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICAgICAgICAgIG1hcmdpbjogMCxcbiAgICAgICAgICAgICAgICBib3JkZXI6ICdub25lJyxcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBhbHQ9XCJcIlxuICAgICAgICAgICAgICBhcmlhLWhpZGRlbj17dHJ1ZX1cbiAgICAgICAgICAgICAgcm9sZT1cInByZXNlbnRhdGlvblwiXG4gICAgICAgICAgICAgIHNyYz17YGRhdGE6aW1hZ2Uvc3ZnK3htbDtiYXNlNjQsJHt0b0Jhc2U2NChzaXplclN2Zyl9YH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IG51bGx9XG4gICAgICA8aW1nXG4gICAgICAgIHsuLi5yZXN0fVxuICAgICAgICB7Li4uaW1nQXR0cmlidXRlc31cbiAgICAgICAgZGVjb2Rpbmc9XCJhc3luY1wiXG4gICAgICAgIGNsYXNzTmFtZT17Y2xhc3NOYW1lfVxuICAgICAgICByZWY9e3NldFJlZn1cbiAgICAgICAgc3R5bGU9e2ltZ1N0eWxlfVxuICAgICAgLz5cbiAgICAgIHtwcmlvcml0eSA/IChcbiAgICAgICAgLy8gTm90ZSBob3cgd2Ugb21pdCB0aGUgYGhyZWZgIGF0dHJpYnV0ZSwgYXMgaXQgd291bGQgb25seSBiZSByZWxldmFudFxuICAgICAgICAvLyBmb3IgYnJvd3NlcnMgdGhhdCBkbyBub3Qgc3VwcG9ydCBgaW1hZ2VzcmNzZXRgLCBhbmQgaW4gdGhvc2UgY2FzZXNcbiAgICAgICAgLy8gaXQgd291bGQgbGlrZWx5IGNhdXNlIHRoZSBpbmNvcnJlY3QgaW1hZ2UgdG8gYmUgcHJlbG9hZGVkLlxuICAgICAgICAvL1xuICAgICAgICAvLyBodHRwczovL2h0bWwuc3BlYy53aGF0d2cub3JnL211bHRpcGFnZS9zZW1hbnRpY3MuaHRtbCNhdHRyLWxpbmstaW1hZ2VzcmNzZXRcbiAgICAgICAgPEhlYWQ+XG4gICAgICAgICAgPGxpbmtcbiAgICAgICAgICAgIGtleT17XG4gICAgICAgICAgICAgICdfX25pbWctJyArXG4gICAgICAgICAgICAgIGltZ0F0dHJpYnV0ZXMuc3JjICtcbiAgICAgICAgICAgICAgaW1nQXR0cmlidXRlcy5zcmNTZXQgK1xuICAgICAgICAgICAgICBpbWdBdHRyaWJ1dGVzLnNpemVzXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZWw9XCJwcmVsb2FkXCJcbiAgICAgICAgICAgIGFzPVwiaW1hZ2VcIlxuICAgICAgICAgICAgaHJlZj17aW1nQXR0cmlidXRlcy5zcmNTZXQgPyB1bmRlZmluZWQgOiBpbWdBdHRyaWJ1dGVzLnNyY31cbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmU6IGltYWdlc3Jjc2V0IGlzIG5vdCB5ZXQgaW4gdGhlIGxpbmsgZWxlbWVudCB0eXBlXG4gICAgICAgICAgICBpbWFnZXNyY3NldD17aW1nQXR0cmlidXRlcy5zcmNTZXR9XG4gICAgICAgICAgICAvLyBAdHMtaWdub3JlOiBpbWFnZXNpemVzIGlzIG5vdCB5ZXQgaW4gdGhlIGxpbmsgZWxlbWVudCB0eXBlXG4gICAgICAgICAgICBpbWFnZXNpemVzPXtpbWdBdHRyaWJ1dGVzLnNpemVzfVxuICAgICAgICAgID48L2xpbms+XG4gICAgICAgIDwvSGVhZD5cbiAgICAgICkgOiBudWxsfVxuICAgIDwvZGl2PlxuICApXG59XG5cbi8vQlVJTFQgSU4gTE9BREVSU1xuXG5mdW5jdGlvbiBub3JtYWxpemVTcmMoc3JjOiBzdHJpbmcpOiBzdHJpbmcge1xuICByZXR1cm4gc3JjWzBdID09PSAnLycgPyBzcmMuc2xpY2UoMSkgOiBzcmNcbn1cblxuZnVuY3Rpb24gaW1naXhMb2FkZXIoe1xuICByb290LFxuICBzcmMsXG4gIHdpZHRoLFxuICBxdWFsaXR5LFxufTogRGVmYXVsdEltYWdlTG9hZGVyUHJvcHMpOiBzdHJpbmcge1xuICAvLyBEZW1vOiBodHRwczovL3N0YXRpYy5pbWdpeC5uZXQvZGFpc3kucG5nP2Zvcm1hdD1hdXRvJmZpdD1tYXgmdz0zMDBcbiAgY29uc3QgcGFyYW1zID0gWydhdXRvPWZvcm1hdCcsICdmaXQ9bWF4JywgJ3c9JyArIHdpZHRoXVxuICBsZXQgcGFyYW1zU3RyaW5nID0gJydcbiAgaWYgKHF1YWxpdHkpIHtcbiAgICBwYXJhbXMucHVzaCgncT0nICsgcXVhbGl0eSlcbiAgfVxuXG4gIGlmIChwYXJhbXMubGVuZ3RoKSB7XG4gICAgcGFyYW1zU3RyaW5nID0gJz8nICsgcGFyYW1zLmpvaW4oJyYnKVxuICB9XG4gIHJldHVybiBgJHtyb290fSR7bm9ybWFsaXplU3JjKHNyYyl9JHtwYXJhbXNTdHJpbmd9YFxufVxuXG5mdW5jdGlvbiBha2FtYWlMb2FkZXIoeyByb290LCBzcmMsIHdpZHRoIH06IERlZmF1bHRJbWFnZUxvYWRlclByb3BzKTogc3RyaW5nIHtcbiAgcmV0dXJuIGAke3Jvb3R9JHtub3JtYWxpemVTcmMoc3JjKX0/aW13aWR0aD0ke3dpZHRofWBcbn1cblxuZnVuY3Rpb24gY2xvdWRpbmFyeUxvYWRlcih7XG4gIHJvb3QsXG4gIHNyYyxcbiAgd2lkdGgsXG4gIHF1YWxpdHksXG59OiBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcyk6IHN0cmluZyB7XG4gIC8vIERlbW86IGh0dHBzOi8vcmVzLmNsb3VkaW5hcnkuY29tL2RlbW8vaW1hZ2UvdXBsb2FkL3dfMzAwLGNfbGltaXQscV9hdXRvL3R1cnRsZXMuanBnXG4gIGNvbnN0IHBhcmFtcyA9IFsnZl9hdXRvJywgJ2NfbGltaXQnLCAnd18nICsgd2lkdGgsICdxXycgKyAocXVhbGl0eSB8fCAnYXV0bycpXVxuICBsZXQgcGFyYW1zU3RyaW5nID0gcGFyYW1zLmpvaW4oJywnKSArICcvJ1xuICByZXR1cm4gYCR7cm9vdH0ke3BhcmFtc1N0cmluZ30ke25vcm1hbGl6ZVNyYyhzcmMpfWBcbn1cblxuZnVuY3Rpb24gZGVmYXVsdExvYWRlcih7XG4gIHJvb3QsXG4gIHNyYyxcbiAgd2lkdGgsXG4gIHF1YWxpdHksXG59OiBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcyk6IHN0cmluZyB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgY29uc3QgbWlzc2luZ1ZhbHVlcyA9IFtdXG5cbiAgICAvLyB0aGVzZSBzaG91bGQgYWx3YXlzIGJlIHByb3ZpZGVkIGJ1dCBtYWtlIHN1cmUgdGhleSBhcmVcbiAgICBpZiAoIXNyYykgbWlzc2luZ1ZhbHVlcy5wdXNoKCdzcmMnKVxuICAgIGlmICghd2lkdGgpIG1pc3NpbmdWYWx1ZXMucHVzaCgnd2lkdGgnKVxuXG4gICAgaWYgKG1pc3NpbmdWYWx1ZXMubGVuZ3RoID4gMCkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgTmV4dCBJbWFnZSBPcHRpbWl6YXRpb24gcmVxdWlyZXMgJHttaXNzaW5nVmFsdWVzLmpvaW4oXG4gICAgICAgICAgJywgJ1xuICAgICAgICApfSB0byBiZSBwcm92aWRlZC4gTWFrZSBzdXJlIHlvdSBwYXNzIHRoZW0gYXMgcHJvcHMgdG8gdGhlIFxcYG5leHQvaW1hZ2VcXGAgY29tcG9uZW50LiBSZWNlaXZlZDogJHtKU09OLnN0cmluZ2lmeShcbiAgICAgICAgICB7IHNyYywgd2lkdGgsIHF1YWxpdHkgfVxuICAgICAgICApfWBcbiAgICAgIClcbiAgICB9XG5cbiAgICBpZiAoc3JjLnN0YXJ0c1dpdGgoJy8vJykpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEZhaWxlZCB0byBwYXJzZSBzcmMgXCIke3NyY31cIiBvbiBcXGBuZXh0L2ltYWdlXFxgLCBwcm90b2NvbC1yZWxhdGl2ZSBVUkwgKC8vKSBtdXN0IGJlIGNoYW5nZWQgdG8gYW4gYWJzb2x1dGUgVVJMIChodHRwOi8vIG9yIGh0dHBzOi8vKWBcbiAgICAgIClcbiAgICB9XG5cbiAgICBpZiAoIXNyYy5zdGFydHNXaXRoKCcvJykgJiYgY29uZmlnRG9tYWlucykge1xuICAgICAgbGV0IHBhcnNlZFNyYzogVVJMXG4gICAgICB0cnkge1xuICAgICAgICBwYXJzZWRTcmMgPSBuZXcgVVJMKHNyYylcbiAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICBjb25zb2xlLmVycm9yKGVycilcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGBGYWlsZWQgdG8gcGFyc2Ugc3JjIFwiJHtzcmN9XCIgb24gXFxgbmV4dC9pbWFnZVxcYCwgaWYgdXNpbmcgcmVsYXRpdmUgaW1hZ2UgaXQgbXVzdCBzdGFydCB3aXRoIGEgbGVhZGluZyBzbGFzaCBcIi9cIiBvciBiZSBhbiBhYnNvbHV0ZSBVUkwgKGh0dHA6Ly8gb3IgaHR0cHM6Ly8pYFxuICAgICAgICApXG4gICAgICB9XG5cbiAgICAgIGlmICghY29uZmlnRG9tYWlucy5pbmNsdWRlcyhwYXJzZWRTcmMuaG9zdG5hbWUpKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICBgSW52YWxpZCBzcmMgcHJvcCAoJHtzcmN9KSBvbiBcXGBuZXh0L2ltYWdlXFxgLCBob3N0bmFtZSBcIiR7cGFyc2VkU3JjLmhvc3RuYW1lfVwiIGlzIG5vdCBjb25maWd1cmVkIHVuZGVyIGltYWdlcyBpbiB5b3VyIFxcYG5leHQuY29uZmlnLmpzXFxgXFxuYCArXG4gICAgICAgICAgICBgU2VlIG1vcmUgaW5mbzogaHR0cHM6Ly9lcnIuc2gvbmV4dC5qcy9uZXh0LWltYWdlLXVuY29uZmlndXJlZC1ob3N0YFxuICAgICAgICApXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGAke3Jvb3R9P3VybD0ke2VuY29kZVVSSUNvbXBvbmVudChzcmMpfSZ3PSR7d2lkdGh9JnE9JHtxdWFsaXR5IHx8IDc1fWBcbn1cbiIsInR5cGUgUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSA9IGFueVxudHlwZSBSZXF1ZXN0SWRsZUNhbGxiYWNrT3B0aW9ucyA9IHtcbiAgdGltZW91dDogbnVtYmVyXG59XG50eXBlIFJlcXVlc3RJZGxlQ2FsbGJhY2tEZWFkbGluZSA9IHtcbiAgcmVhZG9ubHkgZGlkVGltZW91dDogYm9vbGVhblxuICB0aW1lUmVtYWluaW5nOiAoKSA9PiBudW1iZXJcbn1cblxuZGVjbGFyZSBnbG9iYWwge1xuICBpbnRlcmZhY2UgV2luZG93IHtcbiAgICByZXF1ZXN0SWRsZUNhbGxiYWNrOiAoXG4gICAgICBjYWxsYmFjazogKGRlYWRsaW5lOiBSZXF1ZXN0SWRsZUNhbGxiYWNrRGVhZGxpbmUpID0+IHZvaWQsXG4gICAgICBvcHRzPzogUmVxdWVzdElkbGVDYWxsYmFja09wdGlvbnNcbiAgICApID0+IFJlcXVlc3RJZGxlQ2FsbGJhY2tIYW5kbGVcbiAgICBjYW5jZWxJZGxlQ2FsbGJhY2s6IChpZDogUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSkgPT4gdm9pZFxuICB9XG59XG5cbmV4cG9ydCBjb25zdCByZXF1ZXN0SWRsZUNhbGxiYWNrID1cbiAgKHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyAmJiBzZWxmLnJlcXVlc3RJZGxlQ2FsbGJhY2spIHx8XG4gIGZ1bmN0aW9uIChcbiAgICBjYjogKGRlYWRsaW5lOiBSZXF1ZXN0SWRsZUNhbGxiYWNrRGVhZGxpbmUpID0+IHZvaWRcbiAgKTogTm9kZUpTLlRpbWVvdXQge1xuICAgIGxldCBzdGFydCA9IERhdGUubm93KClcbiAgICByZXR1cm4gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICBjYih7XG4gICAgICAgIGRpZFRpbWVvdXQ6IGZhbHNlLFxuICAgICAgICB0aW1lUmVtYWluaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIE1hdGgubWF4KDAsIDUwIC0gKERhdGUubm93KCkgLSBzdGFydCkpXG4gICAgICAgIH0sXG4gICAgICB9KVxuICAgIH0sIDEpXG4gIH1cblxuZXhwb3J0IGNvbnN0IGNhbmNlbElkbGVDYWxsYmFjayA9XG4gICh0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcgJiYgc2VsZi5jYW5jZWxJZGxlQ2FsbGJhY2spIHx8XG4gIGZ1bmN0aW9uIChpZDogUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSkge1xuICAgIHJldHVybiBjbGVhclRpbWVvdXQoaWQpXG4gIH1cbiIsImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7XG4gIHJlcXVlc3RJZGxlQ2FsbGJhY2ssXG4gIGNhbmNlbElkbGVDYWxsYmFjayxcbn0gZnJvbSAnLi9yZXF1ZXN0LWlkbGUtY2FsbGJhY2snXG5cbnR5cGUgVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0ID0gUGljazxJbnRlcnNlY3Rpb25PYnNlcnZlckluaXQsICdyb290TWFyZ2luJz5cbnR5cGUgVXNlSW50ZXJzZWN0aW9uID0geyBkaXNhYmxlZD86IGJvb2xlYW4gfSAmIFVzZUludGVyc2VjdGlvbk9ic2VydmVySW5pdFxudHlwZSBPYnNlcnZlQ2FsbGJhY2sgPSAoaXNWaXNpYmxlOiBib29sZWFuKSA9PiB2b2lkXG50eXBlIE9ic2VydmVyID0ge1xuICBpZDogc3RyaW5nXG4gIG9ic2VydmVyOiBJbnRlcnNlY3Rpb25PYnNlcnZlclxuICBlbGVtZW50czogTWFwPEVsZW1lbnQsIE9ic2VydmVDYWxsYmFjaz5cbn1cblxuY29uc3QgaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPSB0eXBlb2YgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgIT09ICd1bmRlZmluZWQnXG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VJbnRlcnNlY3Rpb248VCBleHRlbmRzIEVsZW1lbnQ+KHtcbiAgcm9vdE1hcmdpbixcbiAgZGlzYWJsZWQsXG59OiBVc2VJbnRlcnNlY3Rpb24pOiBbKGVsZW1lbnQ6IFQgfCBudWxsKSA9PiB2b2lkLCBib29sZWFuXSB7XG4gIGNvbnN0IGlzRGlzYWJsZWQ6IGJvb2xlYW4gPSBkaXNhYmxlZCB8fCAhaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXJcblxuICBjb25zdCB1bm9ic2VydmUgPSB1c2VSZWY8RnVuY3Rpb24+KClcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3Qgc2V0UmVmID0gdXNlQ2FsbGJhY2soXG4gICAgKGVsOiBUIHwgbnVsbCkgPT4ge1xuICAgICAgaWYgKHVub2JzZXJ2ZS5jdXJyZW50KSB7XG4gICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50KClcbiAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQgPSB1bmRlZmluZWRcbiAgICAgIH1cblxuICAgICAgaWYgKGlzRGlzYWJsZWQgfHwgdmlzaWJsZSkgcmV0dXJuXG5cbiAgICAgIGlmIChlbCAmJiBlbC50YWdOYW1lKSB7XG4gICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gb2JzZXJ2ZShcbiAgICAgICAgICBlbCxcbiAgICAgICAgICAoaXNWaXNpYmxlKSA9PiBpc1Zpc2libGUgJiYgc2V0VmlzaWJsZShpc1Zpc2libGUpLFxuICAgICAgICAgIHsgcm9vdE1hcmdpbiB9XG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9LFxuICAgIFtpc0Rpc2FibGVkLCByb290TWFyZ2luLCB2aXNpYmxlXVxuICApXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWhhc0ludGVyc2VjdGlvbk9ic2VydmVyKSB7XG4gICAgICBpZiAoIXZpc2libGUpIHtcbiAgICAgICAgY29uc3QgaWRsZUNhbGxiYWNrID0gcmVxdWVzdElkbGVDYWxsYmFjaygoKSA9PiBzZXRWaXNpYmxlKHRydWUpKVxuICAgICAgICByZXR1cm4gKCkgPT4gY2FuY2VsSWRsZUNhbGxiYWNrKGlkbGVDYWxsYmFjaylcbiAgICAgIH1cbiAgICB9XG4gIH0sIFt2aXNpYmxlXSlcblxuICByZXR1cm4gW3NldFJlZiwgdmlzaWJsZV1cbn1cblxuZnVuY3Rpb24gb2JzZXJ2ZShcbiAgZWxlbWVudDogRWxlbWVudCxcbiAgY2FsbGJhY2s6IE9ic2VydmVDYWxsYmFjayxcbiAgb3B0aW9uczogVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0XG4pOiAoKSA9PiB2b2lkIHtcbiAgY29uc3QgeyBpZCwgb2JzZXJ2ZXIsIGVsZW1lbnRzIH0gPSBjcmVhdGVPYnNlcnZlcihvcHRpb25zKVxuICBlbGVtZW50cy5zZXQoZWxlbWVudCwgY2FsbGJhY2spXG5cbiAgb2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50KVxuICByZXR1cm4gZnVuY3Rpb24gdW5vYnNlcnZlKCk6IHZvaWQge1xuICAgIGVsZW1lbnRzLmRlbGV0ZShlbGVtZW50KVxuICAgIG9ic2VydmVyLnVub2JzZXJ2ZShlbGVtZW50KVxuXG4gICAgLy8gRGVzdHJveSBvYnNlcnZlciB3aGVuIHRoZXJlJ3Mgbm90aGluZyBsZWZ0IHRvIHdhdGNoOlxuICAgIGlmIChlbGVtZW50cy5zaXplID09PSAwKSB7XG4gICAgICBvYnNlcnZlci5kaXNjb25uZWN0KClcbiAgICAgIG9ic2VydmVycy5kZWxldGUoaWQpXG4gICAgfVxuICB9XG59XG5cbmNvbnN0IG9ic2VydmVycyA9IG5ldyBNYXA8c3RyaW5nLCBPYnNlcnZlcj4oKVxuZnVuY3Rpb24gY3JlYXRlT2JzZXJ2ZXIob3B0aW9uczogVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0KTogT2JzZXJ2ZXIge1xuICBjb25zdCBpZCA9IG9wdGlvbnMucm9vdE1hcmdpbiB8fCAnJ1xuICBsZXQgaW5zdGFuY2UgPSBvYnNlcnZlcnMuZ2V0KGlkKVxuICBpZiAoaW5zdGFuY2UpIHtcbiAgICByZXR1cm4gaW5zdGFuY2VcbiAgfVxuXG4gIGNvbnN0IGVsZW1lbnRzID0gbmV3IE1hcDxFbGVtZW50LCBPYnNlcnZlQ2FsbGJhY2s+KClcbiAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcbiAgICBlbnRyaWVzLmZvckVhY2goKGVudHJ5KSA9PiB7XG4gICAgICBjb25zdCBjYWxsYmFjayA9IGVsZW1lbnRzLmdldChlbnRyeS50YXJnZXQpXG4gICAgICBjb25zdCBpc1Zpc2libGUgPSBlbnRyeS5pc0ludGVyc2VjdGluZyB8fCBlbnRyeS5pbnRlcnNlY3Rpb25SYXRpbyA+IDBcbiAgICAgIGlmIChjYWxsYmFjayAmJiBpc1Zpc2libGUpIHtcbiAgICAgICAgY2FsbGJhY2soaXNWaXNpYmxlKVxuICAgICAgfVxuICAgIH0pXG4gIH0sIG9wdGlvbnMpXG5cbiAgb2JzZXJ2ZXJzLnNldChcbiAgICBpZCxcbiAgICAoaW5zdGFuY2UgPSB7XG4gICAgICBpZCxcbiAgICAgIG9ic2VydmVyLFxuICAgICAgZWxlbWVudHMsXG4gICAgfSlcbiAgKVxuICByZXR1cm4gaW5zdGFuY2Vcbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9kaXN0L2NsaWVudC9pbWFnZScpXG4iLCJmdW5jdGlvbiBfZXh0ZW5kcygpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBfZXh0ZW5kcyA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24gKHRhcmdldCkge1xuICAgIGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgc291cmNlID0gYXJndW1lbnRzW2ldO1xuXG4gICAgICBmb3IgKHZhciBrZXkgaW4gc291cmNlKSB7XG4gICAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoc291cmNlLCBrZXkpKSB7XG4gICAgICAgICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0YXJnZXQ7XG4gIH07XG5cbiAgcmV0dXJuIF9leHRlbmRzLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2V4dGVuZHM7IiwiZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICBcImRlZmF1bHRcIjogb2JqXG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdDsiLCJmdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShzb3VyY2UsIGV4Y2x1ZGVkKSB7XG4gIGlmIChzb3VyY2UgPT0gbnVsbCkgcmV0dXJuIHt9O1xuICB2YXIgdGFyZ2V0ID0ge307XG4gIHZhciBzb3VyY2VLZXlzID0gT2JqZWN0LmtleXMoc291cmNlKTtcbiAgdmFyIGtleSwgaTtcblxuICBmb3IgKGkgPSAwOyBpIDwgc291cmNlS2V5cy5sZW5ndGg7IGkrKykge1xuICAgIGtleSA9IHNvdXJjZUtleXNbaV07XG4gICAgaWYgKGV4Y2x1ZGVkLmluZGV4T2Yoa2V5KSA+PSAwKSBjb250aW51ZTtcbiAgICB0YXJnZXRba2V5XSA9IHNvdXJjZVtrZXldO1xuICB9XG5cbiAgcmV0dXJuIHRhcmdldDtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZTsiLCJpbXBvcnQgeyBCb3gsIENvbnRhaW5lciwgR3JpZCwgTGluayB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IHsgZGVmYXVsdCBhcyBSZWFjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQXJjaGl2ZSwgSGVscENpcmNsZSB9IGZyb20gJ3JlYWN0LWZlYXRoZXInO1xyXG5pbXBvcnQgTWFpbkhlYWRlciBmcm9tICdzaGFyZWQvY29tcG9uZW50cy9IZWFkZXIvTWFpbkhlYWRlcic7XHJcbmltcG9ydCBUb3BIZWFkZXIgZnJvbSAnc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL1RvcEhlYWRlcic7XHJcbmltcG9ydCBBbGVydCBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0FsZXJ0JztcclxuaW1wb3J0IENvbW1vbkNhcmQgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9Db21tb25DYXJkJztcclxuaW1wb3J0IERhc2hib2FyZEFjY291bnQgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L0Rhc2hib2FyZEFjY291bnQnO1xyXG5pbXBvcnQgRGFzaGJvYXJkQWNjb3VudERldGFpbHMgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L0Rhc2hib2FyZEFjY291bnREZXRhaWxzJztcclxuaW1wb3J0IERhc2hib2FyZENvbnRhY3RVcyBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkQ29udGFjdFVzJztcclxuaW1wb3J0IERhc2hib2FyZEhlbHBDZW50ZXIgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L0Rhc2hib2FyZEhlbHBDZW50ZXInO1xyXG5pbXBvcnQgRGFzaGJvYXJkSGVscFRvcGljcyBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0Rhc2hib2FyZFBhZ2VDb21wb25lbnQvRGFzaGJvYXJkSGVscFRvcGljcyc7XHJcbmltcG9ydCBEYXNoYm9hcmRIb21lIGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvRGFzaGJvYXJkUGFnZUNvbXBvbmVudC9EYXNoYm9hcmRIb21lJztcclxuaW1wb3J0IERhc2hib2FyZE5vUHJvZ3JhbXMgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L0Rhc2hib2FyZE5vUHJvZ3JhbXMnO1xyXG5pbXBvcnQgRGFzaGJvYXJkWW91ckFwcGxpY2F0aW9uIGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvRGFzaGJvYXJkUGFnZUNvbXBvbmVudC9EYXNoYm9hcmRZb3VyQXBwbGljYXRpb24nO1xyXG5pbXBvcnQgWW91clZvdWNoZXIgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9EYXNoYm9hcmRQYWdlQ29tcG9uZW50L1lvdXJWb3VjaGVyJztcclxuaW1wb3J0IEZvb3RlciBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0Zvb3Rlcic7XHJcbmltcG9ydCBTdWJGb290ZXIgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9Gb290ZXIvU3ViRm9vdGVyJztcclxuaW1wb3J0IEhlbHBDZW50ZXIgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9IZWxwQ2VudGVyJztcclxuaW1wb3J0IE9iamVjdENhcmQgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9PYmplY3RDYXJkJztcclxuaW1wb3J0IFBhZ2VIZWFkaW5nIGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvUGFnZUhlYWRpbmcnO1xyXG5pbXBvcnQgUHJvZ3JhbUNhcmQgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9Qcm9ncmFtQ2FyZCc7XHJcbmltcG9ydCBXaXphcmRIZWFkZXIgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9XaXphcmRIZWFkZXInO1xyXG5cclxuLyoqXHJcbiAqIE5hbWU6IERhc2hib2FyZFBhZ2VTdHlsZU1vZHVsZVxyXG4gKiBEZXNjOiBSZW5kZXIgRGFzaGJvYXJkUGFnZVN0eWxlTW9kdWxlXHJcbiAqL1xyXG5cclxuY29uc3QgRGFzaGJvYXJkUGFnZVN0eWxlTW9kdWxlID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbGlua0FycmF5cyA9IFtcclxuICAgICAgICB7IHRleHQ6ICdTZWUgaWYgeW914oCZcmUgZWxpZ2libGUgPicsIGljb246IEhlbHBDaXJjbGUgfSxcclxuICAgICAgICB7IHRleHQ6ICdWaWV3ICg2KSBhcmNoaXZlZCBhcHBsaWNhdGlvbnMgPicsIGljb246IEFyY2hpdmUgfVxyXG4gICAgXTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxHcmlkIGNvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbXQ9ezV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnZUhlYWRpbmcgdGl0bGU9XCJEYXNoYm9hcmQgSG9tZVwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRvcEhlYWRlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxNYWluSGVhZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lPVwiSGVsbG8sIEVyaWthXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGVhZGVyU3VidGl0bGU9XCJWaWV3IHlvdXIgYWN0aXZlIGhvdXNpbmcgYXBwbGljYXRpb25zIGJlbG93IG9uIHlvdXIgZGFzaGJvYXJkIGJlbG93LlwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8RGFzaGJvYXJkSG9tZSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxIZWxwQ2VudGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdWJGb290ZXIgLz5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuXHJcbiAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gbWQ9ezEyfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG10PXs1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFBhZ2VIZWFkaW5nIHRpdGxlPVwiRGFzaGJvYXJkIEFjY291bnRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxNYWluSGVhZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dNb2JpbGVNZW51PXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2JpbGVUaXRsZT1cIllvdXIgQWNjb3VudFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dCZWxsPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxEYXNoYm9hcmRBY2NvdW50IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPEhlbHBDZW50ZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9vdGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFN1YkZvb3RlciAvPlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtdD17NX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIkRhc2hib2FyZCBBY2NvdW50IERldGFpbHNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxNYWluSGVhZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dCYWNrQnRuPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2JpbGVUaXRsZT1cIkFjY291bnQgRGV0YWlsc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dCZWxsPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxEYXNoYm9hcmRBY2NvdW50RGV0YWlscyAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxIZWxwQ2VudGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdWJGb290ZXIgLz5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbXQ9ezV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnZUhlYWRpbmcgdGl0bGU9XCJEYXNoYm9hcmQgLSBWb3VjaGVyXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8V2l6YXJkSGVhZGVyIHRpdGxlPVwiWW91ciBWb3VjaGVyXCIgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPENvbW1vbkNhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxZb3VyVm91Y2hlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29tbW9uQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbXQ9ezV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnZUhlYWRpbmcgdGl0bGU9XCJEYXNoYm9hcmQgSGVscCBDZW50ZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxNYWluSGVhZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1vYmlsZVRpdGxlPVwiSGVscCBDZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93QmVsbD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dNb2JpbGVNZW51PXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPENvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPERhc2hib2FyZEhlbHBDZW50ZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICA8SGVscENlbnRlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGb290ZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8U3ViRm9vdGVyIC8+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gbWQ9ezEyfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG10PXs1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFBhZ2VIZWFkaW5nIHRpdGxlPVwiRGFzaGJvYXJkIC0gSGVscCBUb3BpY3NcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8TWFpbkhlYWRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0xvZ2dlZEluPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93QmFja0J0bj17dHJ1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbW9iaWxlVGl0bGU9XCJIZWxwIFRvcGljc1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dCZWxsPXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxEYXNoYm9hcmRIZWxwVG9waWNzIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEhlbHBDZW50ZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9vdGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFN1YkZvb3RlciAvPlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtdD17NX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIkRhc2hib2FyZCAtIENvbnRhY3QgVXNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxNYWluSGVhZGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dCYWNrQnRuPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtb2JpbGVUaXRsZT1cIkNvbnRhY3QgVXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93QmVsbD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPERhc2hib2FyZENvbnRhY3RVcyAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8SGVscENlbnRlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxGb290ZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8U3ViRm9vdGVyIC8+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gbWQ9ezEyfSB3aWR0aD1cIjEwMCVcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG10PXs1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFBhZ2VIZWFkaW5nIHRpdGxlPVwiRGFzaGJvYXJkIEFsZXJ0c1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBiZ2NvbG9yPVwic2Vjb25kYXJ5LmV4dHJhTGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE1haW5IZWFkZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93QmFja0J0bj17dHJ1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vYmlsZVRpdGxlPVwiWW91ciBBbGVydHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0JlbGw9e2ZhbHNlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggcGI9ezN9IHBsPXsxfSBwcj17MX0gbXQ9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlOiAnUHJvZ3JhbSBOYW1lIGZvciB0aGUgQWxlcnQnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VidGl0bGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ1lvdXIgbmFtZSBoYXMgYmVlbiByZWFjaGVkIGFuZCB5b3UgbWF5IGNvbXBsZXRlIGEgZnVsbCBhcHBsaWNhdGlvbiBub3cuJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWU6ICcxZCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdIb3VzaW5nIENob2ljZSBWb3VjaGVyJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnRpdGxlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdZb3VyIGFwcGxpY2F0aW9uIGlzIGluY29tcGxldGUuIEZpbmlzaCBpdCBub3cgdG8ga2VlcCB5b3VyIHNwb3QuJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWU6ICczZCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU6ICdUYXlzICgxQlIpJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnRpdGxlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdUaGVyZSBpcyBhbiB1cGRhdGUgb24geW91ciBhcHBsaWNhdGlvbiBmb3IgdGhpcyBwcm9ncmFtLicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lOiAnMjR3J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ1NpZXN0YSBHYXJkZW5zICgyQlIpJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnRpdGxlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdZb3VyIGFwcGxpY2F0aW9uIGhhcyBiZWVuIGFwcHJvdmVkISBDbGljayBoZXJlIHRvIGZpbmQgeW91ciBuZXh0IHN0ZXBzLicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lOiAnNTJ3J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ1NpZXN0YSBHYXJkZW5zICgyQlIpJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnRpdGxlOlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdZb3VyIGFwcGxpY2F0aW9uIGhhcyBiZWVuIGFwcHJvdmVkISBDbGljayBoZXJlIHRvIGZpbmQgeW91ciBuZXh0IHN0ZXBzLicsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lOiAnNTJ3J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0hvdXNpbmcgQ2hvaWNlIFZvdWNoZXInLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VidGl0bGU6XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ1lvdXIgYXBwbGljYXRpb24gaGFzIGJlZW4gYXBwcm92ZWQhIENsaWNrIGhlcmUgdG8gZmluZCB5b3VyIG5leHQgc3RlcHMuJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWU6ICc1MncnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IHB0PXszfSBrZXk9e2l0ZW0udGl0bGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEFsZXJ0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmV4dHJhTGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwibWQuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5leHRyYUxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdD17MC41fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5zdWJ0aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluV2lkdGg9XCI1MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodD1cIjEwMCVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImZsZXgtZW5kXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwieHMuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImNvbW1vbi5ncmF5VGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17LTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJpbmxpbmUtYmxvY2tcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoPXs5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodD17OX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiZ2NvbG9yPVwiZXJyb3IubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzPVwiNTAlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17MC43NX0+PC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQWxlcnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB0PXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBiPXs2fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiPkxvYWQgT2xkZXIgTWVzc2FnZXMgKzwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbXQ9ezV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnZUhlYWRpbmcgdGl0bGU9XCJObyBQcm9ncmFtc1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBiZ2NvbG9yPVwic2Vjb25kYXJ5LmV4dHJhTGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE1haW5IZWFkZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49XCJ0cnVlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc9XCIwIDAgMjRweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1c2VyTmFtZT1cIkhlbGxvLCBFcmlrYVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJTdWJ0aXRsZT1cIllvdSBkb27igJl0IGhhdmUgYW55IGFjdGl2ZSBwcm9ncmFtIGFwcGxpY2F0aW9ucyByaWdodCBub3cuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENvbW1vbkNhcmQgYmdDb2xvcj1cInRyYW5zcGFyZW50XCIgc2hvd0JhY2tCdG49e2ZhbHNlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYj17M31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJDb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyPVwiMXB4IGRhc2hlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzPVwiMjFweFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxPYmplY3RDYXJkIGNhcmRUeXBlPVwiYWN0aW9uQ2FyZFwiIGljb25OYW1lPVwicGx1c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg2LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU3RhcnQgYSBOZXcgUHJlLUFwcGxpY2F0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvT2JqZWN0Q2FyZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBwdD17Mi41fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGlua0FycmF5cy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17Mn0ga2V5PXtpdGVtLnRleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIiNcIiB1bmRlcmxpbmU9XCJub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGl0ZW0uaWNvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3Ryb2tlV2lkdGg9XCIyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiSW5kaWdvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezE1fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5tYWluXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtbD17MS41fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NvbW1vbkNhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17N30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxEYXNoYm9hcmROb1Byb2dyYW1zIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEhlbHBDZW50ZXIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8Rm9vdGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPFN1YkZvb3RlciAvPlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtdD17NX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIllvdXIgQXBwbGljYXRpb25zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8TWFpbkhlYWRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc0xvZ2dlZEluPVwidHJ1ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhZGRpbmc9XCIwIDAgMjRweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXJOYW1lPVwiWW91ciBBcHBsaWNhdGlvbnNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBoZWFkZXJTdWJ0aXRsZT1cIlZpZXcgeW91ciBhY3RpdmUgaG91c2luZyBhcHBsaWNhdGlvbnMgIG9yIHN0YXJ0IGEgbmV3IGFwcGxpY2F0aW9uIGJlbG93LlwiXHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8Q29tbW9uQ2FyZCBiZ0NvbG9yPVwidHJhbnNwYXJlbnRcIiBzaG93QmFja0J0bj17ZmFsc2V9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8RGFzaGJvYXJkWW91ckFwcGxpY2F0aW9uIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db21tb25DYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgIDxIZWxwQ2VudGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxTdWJGb290ZXIgLz5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbXQ9ezV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UGFnZUhlYWRpbmcgdGl0bGU9XCJBcmNoaXZlZCBBcHBsaWNhdGlvblwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBiZ2NvbG9yPVwic2Vjb25kYXJ5LmV4dHJhTGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE1haW5IZWFkZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93QmFja0J0bj17dHJ1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1vYmlsZVRpdGxlPVwiQXJjaGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93QmVsbD17ZmFsc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IHBiPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ0hvdXNpbmcgQ2hvaWNlIFZvdWNoZXInLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VidGl0bGU6ICdBcmNoaXZlZCA1LzE2LzIyJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aXRsZTogJ1NpZXN0YSBHYXJkZW5zICgyQlIpJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1YnRpdGxlOiAnQXBwbGljYXRpb24gTm90IEFwcHJvdmVkJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHRpdGxlOiAnRGVXZXR0ZXIgKDJCUiknLCBzdWJ0aXRsZTogJ0FyY2hpdmVkIDUvMTYvMjInIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdGl0bGU6ICdLYXRoeSBXaGl0ZSAoMkJSKScsIHN1YnRpdGxlOiAnQXJjaGl2ZWQgNS8xNi8yMicgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0aXRsZTogJ0Vpc2VuaG93ZXIgKDJCUiknLCBzdWJ0aXRsZTogJ0FyY2hpdmVkIDUvMTYvMjInIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdGl0bGU6ICdLcnVwcCAoMkJSKScsIHN1YnRpdGxlOiAnQXJjaGl2ZWQgNS8xNi8yMicgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggcHQ9ezN9IGtleT17aXRlbS50aXRsZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UHJvZ3JhbUNhcmRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiaW5mb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0ltYWdlPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dMZWZ0Qm9yZGVyPXt0cnVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5tYWluXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudD1cImJvZHkxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LnJlZ3VsYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uc3VidGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Byb2dyYW1DYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEZvb3RlciAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U3ViRm9vdGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICA8Lz5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmRQYWdlU3R5bGVNb2R1bGU7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL0Rhc2hib2FyZFBhZ2VTdHlsZU1vZHVsZSciLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgRGFzaGJvYXJkUGFnZVN0eWxlTW9kdWxlIGZyb20gJ34vbW9kdWxlcy9EYXNoYm9hcmRQYWdlU3R5bGVNb2R1bGUnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWUgOiBEYXNoYm9hcmRQYWdlU3R5bGVcclxuICogZGVzYyA6IFJlbmRlciBEYXNoYm9hcmRQYWdlU3R5bGVcclxuICoqL1xyXG5mdW5jdGlvbiBEYXNoYm9hcmRQYWdlU3R5bGUoKSB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxEYXNoYm9hcmRQYWdlU3R5bGVNb2R1bGUvPlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGFzaGJvYXJkUGFnZVN0eWxlOyIsImltcG9ydCB7IENhcmQsIEljb25CdXR0b24gfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCB7IEFsZXJ0IH0gZnJvbSAnQG1hdGVyaWFsLXVpL2xhYic7XHJcbmltcG9ydCB7IFggfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL0FsZXJ0c1N0eWxlcyc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcblxyXG4vKipcclxuICogTmFtZTogQWxlcnRzXHJcbiAqIERlc2M6IFJlbmRlciBBbGVydHNcclxuICovXHJcblxyXG5jb25zdCBBbGVydHMgPSAoeyB2YXJpYW50LCBpY29uQ29sb3IsIGNoaWxkcmVuLCBzaG93Q2xvc2VCdG4gfSkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9e2NsYXNzZXNbdmFyaWFudF19PlxyXG4gICAgICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aW9uPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0Nsb3NlQnRuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHN0cm9rZVdpZHRoPVwiM1wiIGNvbG9yPXtpY29uQ29sb3J9Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7IGNoaWxkcmVuICYmIGNoaWxkcmVuIH1cclxuICAgICAgICAgICAgICAgIDwvQWxlcnQ+XHJcbiAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuQWxlcnRzLmRlZmF1bHRQcm9wcyA9e1xyXG4gICAgc2hvd0Nsb3NlQnRuOiBmYWxzZVxyXG59O1xyXG5cclxuQWxlcnRzLnByb3BUeXBlcyA9IHtcclxuICAgIHZhcmlhbnQ6IFByb3BUeXBlcy5vbmVPZihbXCJwcmltYXJ5QWxlcnRcIiwgXCJzZWNvbmRhcnlBbGVydFwiXSksXHJcbiAgICBpY29uQ29sb3I6IFByb3BUeXBlcy5vbmVPZihbXCJ3aGl0ZVwiLCBcImluZGlnb1wiXSksXHJcbiAgICBjaGlsZHJlbjogUHJvcFR5cGVzLm5vZGUsXHJcbiAgICBzaG93Q2xvc2VCdG46IFByb3BUeXBlcy5ib29sXHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IEFsZXJ0c1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICAgIHByaW1hcnlBbGVydDp7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOnRoZW1lLnBhbGV0dGUucHJpbWFyeS5tYWluLFxyXG4gICAgICAgIGNvbG9yOnRoZW1lLmNvbW1vbi53aGl0ZSxcclxuICAgICAgICBib3hTaGFkb3c6XCJub25lXCIsXHJcbiAgICAgICAgYm9yZGVyUmFkaXVzOlwiMFwiXHJcbiAgICB9LFxyXG4gICAgc2Vjb25kYXJ5QWxlcnQ6e1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjp0aGVtZS5wYWxldHRlLm1lbnVzLm1lbnVCYWNrZ3JvdW5kLFxyXG4gICAgICAgIGNvbG9yOnRoZW1lLnBhbGV0dGUucHJpbWFyeS5saWdodCxcclxuICAgICAgICBib3hTaGFkb3c6XCJub25lXCIsXHJcbiAgICAgICAgYm9yZGVyUmFkaXVzOlwiMFwiXHJcbiAgICB9XHJcbn0pKTtcclxuZXhwb3J0IGRlZmF1bHQgdXNlU3R5bGVzOyIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL0FsZXJ0cyciLCJpbXBvcnQgeyBCb3gsIENhcmQsIEljb25CdXR0b24gfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBjbHN4IGZyb20gJ2Nsc3gnO1xyXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBBcnJvd0xlZnQsIENoZXZyb25MZWZ0IH0gZnJvbSAncmVhY3QtZmVhdGhlcic7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi9Db21tb25DYXJkU3R5bGUnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWU6IENvbW1vbkNhcmRcclxuICogRGVzYzogUmVuZGVyIENvbW1vbkNhcmRcclxuICovXHJcblxyXG5jb25zdCBDb21tb25DYXJkID0gKHtcclxuICAgIGJnQ29sb3IsXHJcbiAgICBpc1N0YXR1c0NhcmQsXHJcbiAgICBvbkNsaWNrQmFjayxcclxuICAgIHNob3dCYWNrQnRuLFxyXG4gICAgc2hvd0hlYWRlcixcclxuICAgIG5vTWFyZ2luLFxyXG4gICAgY2hpbGRyZW4sXHJcbiAgICBiZ1NjcmVlbixcclxuICAgIGJhY2tCdG5Db2xvcixcclxuICAgIHNwYWNlLFxyXG4gICAgcGFnZVZpZXcsXHJcbiAgICBsYW5kaW5nUGFnZUljb25cclxufSkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgY2FyZENsYXNzID0gY2xzeChcclxuICAgICAgICBjbGFzc2VzLnJvb3QsXHJcbiAgICAgICAgY2xhc3Nlc1tiZ0NvbG9yXSxcclxuICAgICAgICBjbGFzc2VzW2JnU2NyZWVuXSxcclxuICAgICAgICBjbGFzc2VzW3NwYWNlXSxcclxuICAgICAgICBjbGFzc2VzW3BhZ2VWaWV3XSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIFtjbGFzc2VzLm5vTWFyZ2luXTogbm9NYXJnaW4sXHJcbiAgICAgICAgICAgIFtjbGFzc2VzLndlbGNvbWVQYWdlXTogaXNTdGF0dXNDYXJkLFxyXG4gICAgICAgICAgICBbY2xhc3Nlcy5oZWFkZXJdOiBzaG93SGVhZGVyXHJcbiAgICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxDYXJkIGNsYXNzTmFtZT17Y2FyZENsYXNzfT5cclxuICAgICAgICAgICAgPEJveCBjbGFzc05hbWU9e2NsYXNzZXMuc3ViUm9vdH0+XHJcbiAgICAgICAgICAgICAgICB7bGFuZGluZ1BhZ2VJY29uICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b24gY2xhc3NOYW1lPXtjbGFzc2VzLm1vYmlsZUJhY2tCdG59IG9uQ2xpY2s9e29uQ2xpY2tCYWNrfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd0xlZnQgY29sb3I9XCJJbmRpZ29cIiBzdHJva2VXaWR0aD17M30gc2l6ZT17MjB9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICAgICAge3Nob3dCYWNrQnRuICYmIChcclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIGNsYXNzTmFtZT17Y2xhc3Nlcy5pY29uUm9vdH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Nsc3goXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3Nlc1tiYWNrQnRuQ29sb3JdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlzU3RhdHVzQ2FyZCA/IGNsYXNzZXMuZ29CYWNrQnRuMSA6IGNsYXNzZXMuZ29CYWNrQnRuMlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xpY2tCYWNrfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBcnJvd0xlZnQgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyMH0gY2xhc3NOYW1lPXtjbGFzc2VzLnZpc2libGVYc30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uTGVmdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiSW5kaWdvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXszMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMudmlzaWJsZURlc2t0b3B9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBiYWNrQnRuQ29sb3IgIT09ICdiYWNrQnRuUHJpbWFyeSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyAnY29tbW9uLndoaXRlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA6ICdidXR0b24uc2Vjb25kYXJ5Q29sb3InXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtbD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy52aXNpYmxlRGVza3RvcH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBHbyBCYWNrXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9DYXJkPlxyXG4gICAgKTtcclxufTtcclxuXHJcbkNvbW1vbkNhcmQuZGVmYXVsdFByb3BzID0ge1xyXG4gICAgYmdDb2xvcjogJ3doaXRlJyxcclxuICAgIHNob3dIZWFkZXI6IGZhbHNlLFxyXG4gICAgY2hpbGRyZW46ICcnLFxyXG4gICAgc2hvd0ZhY2VCb29rTG9naW5CdXR0b246IGZhbHNlLFxyXG4gICAgaXNQcm9maWxlU2V0dXA6IGZhbHNlLFxyXG4gICAgaXNTdGF0dXNDYXJkOiBmYWxzZSxcclxuICAgIG5vTWFyZ2luOiBmYWxzZSxcclxuICAgIHNob3dCYWNrQnRuOiB0cnVlLFxyXG4gICAgYmdTY3JlZW46ICdub25lJyxcclxuICAgIGJhY2tCdG5Db2xvcjogJ2JhY2tCdG5QcmltYXJ5JyxcclxuICAgIHNwYWNlOiAnbGcnLFxyXG4gICAgcGFnZVZpZXc6ICdoYWxmJyxcclxuICAgIGxhbmRpbmdQYWdlSWNvbjogZmFsc2VcclxufTtcclxuXHJcbkNvbW1vbkNhcmQucHJvcFR5cGVzID0ge1xyXG4gICAgYmdDb2xvcjogUHJvcFR5cGVzLm9uZU9mKFsnd2hpdGUnLCAncHJpbWFyeScsICdncmF5JywgJ3RyYW5zcGFyZW50J10pLFxyXG4gICAgb25DbGlja0JhY2s6IFByb3BUeXBlcy5mdW5jLFxyXG4gICAgb25DbGlja0NvbnRpbnVlOiBQcm9wVHlwZXMuZnVuYyxcclxuICAgIHNob3dIZWFkZXI6IFByb3BUeXBlcy5ib29sLFxyXG4gICAgY2hpbGRyZW46IFByb3BUeXBlcy5ub2RlLFxyXG4gICAgc2hvd0ZhY2VCb29rTG9naW5CdXR0b246IFByb3BUeXBlcy5ib29sLFxyXG4gICAgaXNQcm9maWxlU2V0dXA6IFByb3BUeXBlcy5ib29sLFxyXG4gICAgaXNTdGF0dXNDYXJkOiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIG5vTWFyZ2luOiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIHNob3dCYWNrQnRuOiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIGJnU2NyZWVuOiBQcm9wVHlwZXMub25lT2YoWyd3ZWxjb21lJywgJ3N1Y2Nlc3MnLCAnbm9uZSddKSxcclxuICAgIGJhY2tCdG5Db2xvcjogUHJvcFR5cGVzLm9uZU9mKFsnYmFja0J0bldoaXRlJywgJ2JhY2tCdG5QcmltYXJ5J10pLFxyXG4gICAgc3BhY2U6IFByb3BUeXBlcy5vbmVPZihbJ2xnJywgJ3hzJ10pLFxyXG4gICAgcGFnZVZpZXc6IFByb3BUeXBlcy5vbmVPZihbJ2Z1bGwnLCAnaGFsZiddKSxcclxuICAgIGxhbmRpbmdQYWdlSWNvbjogUHJvcFR5cGVzLmJvb2xcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbW1vbkNhcmQ7XHJcbiIsImltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgICByb290OiB7XHJcbiAgICAgICAgcGFkZGluZzogJzI0cHggMjRweCA1MnB4JyxcclxuICAgICAgICBtYXhXaWR0aDogJzk2MHB4JyxcclxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcclxuICAgICAgICB6SW5kZXg6ICcxJyxcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bigneHMnKV06IHtcclxuICAgICAgICAgICAgcGFkZGluZzogJzI0cHggMjRweCA1MnB4J1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBsZzoge1xyXG4gICAgICAgIG1hcmdpbjogJzAgYXV0bycsXHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLmRvd24oJ3hzJyldOiB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogJy02NnB4IDI0cHggMCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgeHM6IHtcclxuICAgICAgICBtYXJnaW46IDBcclxuICAgIH0sXHJcblxyXG4gICAgcHJpbWFyeToge1xyXG4gICAgICAgIGJhY2tncm91bmQ6IHRoZW1lLnBhbGV0dGUubWVudXMubWVudUJhY2tncm91bmRcclxuICAgIH0sXHJcblxyXG4gICAgd2hpdGU6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB0aGVtZS5wYWxldHRlLmNvbW1vbi53aGl0ZVxyXG4gICAgfSxcclxuICAgIGdyYXk6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB0aGVtZS5jb21tb24uZ3JheVxyXG4gICAgfSxcclxuXHJcbiAgICB0cmFuc3BhcmVudDoge1xyXG4gICAgICAgIGJhY2tncm91bmQ6ICd0cmFuc3BhcmVudCcsXHJcbiAgICAgICAgYm94U2hhZG93OiAnbm9uZScsXHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLmRvd24oJ3hzJyldOiB7XHJcbiAgICAgICAgICAgIG1hcmdpbjogJy02OHB4IDBweCAwJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgd2VsY29tZToge1xyXG4gICAgICAgIGJhY2tncm91bmRTaXplOiAnY292ZXInLFxyXG4gICAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogJ2NlbnRlcicsXHJcbiAgICAgICAgYmFja2dyb3VuZEltYWdlOiBgdXJsKCcvc3BsYXNoLnN2ZycpYCxcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bignc20nKV06IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZEltYWdlOiBgdXJsKCcvc3BsYXNoTW9iaWxlLnN2ZycpYFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcblxyXG4gICAgc3VjY2Vzczoge1xyXG4gICAgICAgIGJhY2tncm91bmRTaXplOiAnY292ZXInLFxyXG4gICAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogJ2NlbnRlcicsXHJcbiAgICAgICAgYmFja2dyb3VuZEltYWdlOiBgdXJsKCcvc3VjY2Vzc0JnLnN2ZycpYCxcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bignc20nKV06IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZEltYWdlOiBgdXJsKCcvc3VjY2Vzc0JnTW9iaWxlLnN2ZycpYFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBub25lOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZEltYWdlOiAnbm9uZSdcclxuICAgIH0sXHJcblxyXG4gICAgc3ViUm9vdDoge1xyXG4gICAgICAgIG1heFdpZHRoOiAnOTYwcHgnLFxyXG4gICAgICAgIG1hcmdpbjogJzAgYXV0bycsXHJcbiAgICAgICAgd2lkdGg6ICcxMDAlJyxcclxuICAgICAgICBtaW5IZWlnaHQ6ICcxNjBweCcsXHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLmRvd24oJ3NtJyldOiB7XHJcbiAgICAgICAgICAgIG1pbkhlaWdodDogJ2F1dG8nLFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBmdWxsOiB7XHJcbiAgICAgICAgbWluSGVpZ2h0OiAnMTAwdmgnLFxyXG4gICAgICAgIHdpZHRoOiAnMTAwJScsXHJcbiAgICAgICAgbWF4V2lkdGg6ICd1bnNldCcsXHJcbiAgICAgICAgZGlzcGxheTogJ2ZsZXgnLFxyXG4gICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxyXG4gICAgICAgIGJvcmRlclJhZGl1czogJzAnLFxyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCd4cycpXToge1xyXG4gICAgICAgICAgICBtYXJnaW46ICcwIGF1dG8nXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICBoYWxmOiB7XHJcbiAgICAgICAgbWluSGVpZ2h0OiAnYXV0bydcclxuICAgIH0sXHJcblxyXG4gICAgaGVhZGVyOiB7XHJcbiAgICAgICAgbWluSGVpZ2h0OiAnY2FsYygxMDB2aCAtIDc4cHgpJ1xyXG4gICAgfSxcclxuXHJcbiAgICBiYWNrQnRuUHJpbWFyeToge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3JnYmEoMTUxLCAxNTEsIDE5MSwgMC4yKScsXHJcbiAgICAgICAgJyY6aG92ZXInOiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUuY29tbW9uLndoaXRlLFxyXG4gICAgICAgICAgICBvcGFjaXR5OiAnMC41J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLmRvd24oJ3hzJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdub25lJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBiYWNrQnRuV2hpdGU6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbW1vbi53aGl0ZSxcclxuICAgICAgICAnJjpob3Zlcic6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb21tb24ud2hpdGUsXHJcbiAgICAgICAgICAgIG9wYWNpdHk6ICcwLjUnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuXHJcbiAgICB2aXNpYmxlRGVza3RvcDoge1xyXG4gICAgICAgIGRpc3BsYXk6ICdub25lJyxcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ21kJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaydcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdmlzaWJsZVhzOiB7XHJcbiAgICAgICAgZGlzcGxheTogJ25vbmUnLFxyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCdzbScpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGljb25Sb290OiB7XHJcbiAgICAgICAgcGFkZGluZ0JvdHRvbTogJzMwcHgnLFxyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCdzbScpXToge1xyXG4gICAgICAgICAgICBwYWRkaW5nQm90dG9tOiAnMTBweCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCd4cycpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnbm9uZSdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgbW9iaWxlQmFja0J0bjp7XHJcbiAgICAgICAgZGlzcGxheTonbm9uZScsXHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLmRvd24oJ3hzJyldOiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUuY29tbW9uLndoaXRlLFxyXG4gICAgICAgICAgICBkaXNwbGF5OidibG9jaycsXHJcbiAgICAgICAgICAgICcmOmhvdmVyJzoge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb21tb24ud2hpdGUsXHJcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiAnMC41J1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIFxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL0NvbW1vbkNhcmQnO1xyXG4iLCJpbXBvcnQgeyBCb3gsIENvbnRhaW5lciwgTGluayB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IFRhYiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9UYWInO1xyXG5pbXBvcnQgVGFicyBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9UYWJzJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQXJjaGl2ZSwgQ2hldnJvblJpZ2h0LCBTYXZlLCBTZXR0aW5ncywgVXNlciB9IGZyb20gJ3JlYWN0LWZlYXRoZXInO1xyXG5pbXBvcnQgQ29tbW9uQ2FyZCBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0NvbW1vbkNhcmQnO1xyXG5pbXBvcnQgdXNlU3R5bGVzIGZyb20gJy4vRGFzaGJvYXJkQWNjb3VudFN0eWxlcyc7XHJcbi8qKlxyXG4gKiBOYW1lOiBEYXNoYm9hcmRBY2NvdW50XHJcbiAqIERlc2M6IFJlbmRlciBEYXNoYm9hcmRBY2NvdW50XHJcbiAqL1xyXG5cclxuY29uc3QgRGFzaGJvYXJkQWNjb3VudCA9ICgpID0+IHtcclxuICAgIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuICAgIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gUmVhY3QudXNlU3RhdGUoMCk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2hhbmdlID0gKGV2ZW50LCBuZXdWYWx1ZSkgPT4ge1xyXG4gICAgICAgIHNldFZhbHVlKG5ld1ZhbHVlKTtcclxuICAgIH07XHJcbiAgICBjb25zdCBhY2NvdW50TGlua3MgPSBbXHJcbiAgICAgICAgeyB0ZXh0OiAnQWNjb3VudCBEZXRhaWxzJywgaWNvbjogVXNlciwgcmlnaHRJY29uOiBDaGV2cm9uUmlnaHQgfSxcclxuICAgICAgICB7IHRleHQ6ICdIb3VzZWhvbGQgRGV0YWlscycsIGljb246IFNldHRpbmdzLCByaWdodEljb246IENoZXZyb25SaWdodCB9LFxyXG4gICAgICAgIHsgdGV4dDogJ1NhdmVkIERvY3VtZW50cycsIGljb246IFNhdmUsIHJpZ2h0SWNvbjogQ2hldnJvblJpZ2h0IH0sXHJcbiAgICAgICAgeyB0ZXh0OiAnQXJjaGl2ZWQgQXBwbGljYXRpb25zJywgaWNvbjogQXJjaGl2ZSwgcmlnaHRJY29uOiBDaGV2cm9uUmlnaHQgfVxyXG4gICAgXTtcclxuICAgIGNvbnN0IGFjY291bnRMaW5rTmFtZSA9IFtcclxuICAgICAgICB7IGxhYmVsOiAnTmFtZScsIGluZm86ICdFcmlrYSBBbGV4YW5kZXInIH0sXHJcbiAgICAgICAgeyBsYWJlbDogJ1QtTnVtYmVyJywgaW5mbzogJ1QtMTIzNDU2JyB9LFxyXG4gICAgICAgIHsgbGFiZWw6ICdZb3VyIFZvdWNoZXInLCBpbmZvOiAnQWN0aXZlJyB9LFxyXG4gICAgICAgIHsgbGFiZWw6ICdFbWFpbCBBZGRyZXNzJywgaW5mbzogJ2VtYWlsQGVtYWlsLmNvbScgfSxcclxuICAgICAgICB7IGxhYmVsOiAnJywgaW5mbzogJ1VwZGF0ZSBZb3VyIFBhc3N3b3JkJyB9LFxyXG4gICAgICAgIHsgbGFiZWw6ICcnLCBpbmZvOiAnQ29ubmVjdGVkIEZhY2Vib29rIEFjY291bnQnIH1cclxuICAgIF07XHJcbiAgICBjb25zdCBjb250YWN0SW5mb3JtYXRpb25MaW5rcyA9IFtcclxuICAgICAgICB7IGxhYmVsOiAnTGFuZGxpbmUgUGhvbmUnLCBpbmZvOiAnKDkxNSkgNTU1LTEyMzQnIH0sXHJcbiAgICAgICAgeyBsYWJlbDogJ0NlbGwgUGhvbmUnLCBpbmZvOiAnKDkxNSkgNTU1LTEyMzQnIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBsYWJlbDogJ0FkZHJlc3MnLFxyXG4gICAgICAgICAgICBpbmZvOiAoXHJcbiAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezF9PkFkZHJlc3MgTGluZSBPbmU8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsxfT5BZGRyZXNzIExpbmUgVHdvPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveD5DaXR5LCBTdGF0ZSwgWmlwIENvZGU8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7IGxhYmVsOiAnWW91ciBUcnVzdGVkIENvbnRhY3QnLCBpbmZvOiAnRmlyc3RuYW1lIExhc3RuYW1lJyB9XHJcbiAgICBdO1xyXG5cclxuICAgIGZ1bmN0aW9uIGExMXlQcm9wcyhpbmRleCkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGlkOiBgdmVydGljYWwtdGFiLSR7aW5kZXh9YCxcclxuICAgICAgICAgICAgJ2FyaWEtY29udHJvbHMnOiBgdmVydGljYWwtdGFicGFuZWwtJHtpbmRleH1gXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIFRhYlBhbmVsKHByb3BzKSB7XHJcbiAgICAgICAgY29uc3QgeyBjaGlsZHJlbiwgdmFsdWUsIGluZGV4LCAuLi5vdGhlciB9ID0gcHJvcHM7XHJcblxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgIHdpZHRoPVwiMTAwJVwiXHJcbiAgICAgICAgICAgICAgICBtYXhXaWR0aD1cIjY0MHB4XCJcclxuICAgICAgICAgICAgICAgIHJvbGU9XCJ0YWJwYW5lbFwiXHJcbiAgICAgICAgICAgICAgICBoaWRkZW49e3ZhbHVlICE9PSBpbmRleH1cclxuICAgICAgICAgICAgICAgIGlkPXtgdmVydGljYWwtdGFicGFuZWwtJHtpbmRleH1gfVxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PXtgdmVydGljYWwtdGFiLSR7aW5kZXh9YH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy50YWJXcmFwcGVyfVxyXG4gICAgICAgICAgICAgICAgey4uLm90aGVyfT5cclxuICAgICAgICAgICAgICAgIHt2YWx1ZSA9PT0gaW5kZXggJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxDb21tb25DYXJkIHNob3dCYWNrQnRuPXtmYWxzZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3g+e2NoaWxkcmVufTwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29tbW9uQ2FyZD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cIm5vbmVcIiBjbGFzc05hbWU9e2NsYXNzZXMud2ViVGFic30gbWI9ezEyfT5cclxuICAgICAgICAgICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIG10PXsxMH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImgxLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ249XCJyaWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb249XCJyZWxhdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdG9wPVwiMTQwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1yPXs1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94PllvdXI8L0JveD4gPEJveD5BY2NvdW50PC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3JpZW50YXRpb249XCJ2ZXJ0aWNhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInNjcm9sbGFibGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt2YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJWZXJ0aWNhbCB0YWJzIGV4YW1wbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy50YWJzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWNjb3VudExpbmtzLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3N9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1yPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDUuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGl0ZW0uaWNvbiBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1yPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhXaWR0aD1cIjQwMHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2hpdGVTcGFjZT1cIm5vV3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgY2xhc3NOYW1lPVwiYXJyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aXRlbS5yaWdodEljb24gY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5hMTF5UHJvcHMoMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhYnM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94IHdpZHRoPVwiMTAwJVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhYlBhbmVsIHZhbHVlPXt2YWx1ZX0gaW5kZXg9ezB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggcGFkZGluZz1cIjE2cHhcIiBtYXhXaWR0aD1cIjU5MnB4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFjY291bnQgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWNjb3VudExpbmtOYW1lLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHQ9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBiPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHQ9XCI5MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRMaW5rc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9XCIjXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuZGVybGluZT1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRMaW5rc1RleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgZmxleERpcmVjdGlvbj1cImNvbHVtblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkuZXh0cmFMaWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cIm1keGwuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1yPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmluZm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBtYXJnaW5MZWZ0PVwiYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cIkluZGlnb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsyNH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXQ9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29udGFjdCBJbmZvcm1hdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17Nn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y29udGFjdEluZm9ybWF0aW9uTGlua3MubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbkhlaWdodD1cIjkwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuY2FyZExpbmtzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaHJlZj1cIiNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5kZXJsaW5lPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuY2FyZExpbmtzVGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBmbGV4RGlyZWN0aW9uPVwiY29sdW1uXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5leHRyYUxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwibWR4bC5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubGFiZWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXI9ezF9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0uaW5mb31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIG1hcmdpbkxlZnQ9XCJhdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiSW5kaWdvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezI0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGFiUGFuZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFiUGFuZWwgdmFsdWU9e3ZhbHVlfSBpbmRleD17MX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSXRlbSBUd29cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGFiUGFuZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFiUGFuZWwgdmFsdWU9e3ZhbHVlfSBpbmRleD17Mn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSXRlbSBUaHJlZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UYWJQYW5lbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJQYW5lbCB2YWx1ZT17dmFsdWV9IGluZGV4PXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJdGVtIFRocmVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhYlBhbmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPEJveCBtYXJnaW49XCIwIDI0cHggNTBweFwiIGNsYXNzTmFtZT17Y2xhc3Nlcy5tb2JpbGVUYWJzfT5cclxuICAgICAgICAgICAgICAgIHthY2NvdW50TGlua3MubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwdD17M31cclxuICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3NUZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXI9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNS5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGl0ZW0uaWNvbiBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1yPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4V2lkdGg9XCI0MDBweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNS5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBtYXJnaW5MZWZ0PVwiYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgKTtcclxufTtcclxuRGFzaGJvYXJkQWNjb3VudC5wcm9wVHlwZXMgPSB7XHJcbiAgICBjaGlsZHJlbjogUHJvcFR5cGVzLmFueSxcclxuICAgIHZhbHVlOiBQcm9wVHlwZXMubnVtYmVyLFxyXG4gICAgaW5kZXg6IFByb3BUeXBlcy5udW1iZXJcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgRGFzaGJvYXJkQWNjb3VudDtcclxuIiwiaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICAgIGNhcmRMaW5rczoge1xyXG4gICAgICAgICcmOm5vdCg6bGFzdC1jaGlsZCknOiB7XHJcbiAgICAgICAgICAgIGJvcmRlckJvdHRvbTogYDFweCBzb2xpZCAke3RoZW1lLmNvbW1vbi5ncmF5fWBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgY3VzdG9tQ2FyZDoge1xyXG4gICAgICAgIHBhZGRpbmc6IDAsXHJcbiAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXHJcbiAgICAgICAgekluZGV4OiAnMSdcclxuICAgIH0sXHJcbiAgICBjYXJkTGlua3NUZXh0OiB7XHJcbiAgICAgICAgd2lkdGg6ICcxMDAlJ1xyXG4gICAgfSxcclxuICAgIG1vYmlsZUJ0bjoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCdzbScpXToge1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcclxuICAgICAgICAgICAgYm90dG9tOiAnMCcsXHJcbiAgICAgICAgICAgIGxlZnQ6ICcwJyxcclxuICAgICAgICAgICAgcmlnaHQ6ICcwJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICB0YWJXcmFwcGVyOiB7XHJcbiAgICAgICAgJyYgPiBkaXYnOiB7XHJcbiAgICAgICAgICAgIG1pbkhlaWdodDogJzgwMHB4JyxcclxuICAgICAgICAgICAgcGFkZGluZ0JvdHRvbTogJzhweCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgbW9iaWxlVGFiczoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnc20nKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ25vbmUnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHdlYlRhYnM6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ3NtJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaydcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHVzZVN0eWxlcztcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vRGFzaGJvYXJkQWNjb3VudCc7XHJcbiIsImltcG9ydCB7IEJveCwgTGluayB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2hldnJvblJpZ2h0IH0gZnJvbSAncmVhY3QtZmVhdGhlcic7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi9EYXNoYm9hcmRBY2NvdW50RGV0YWlsc1N0eWxlcyc7XHJcbi8qKlxyXG4gKiBOYW1lOiBEYXNoYm9hcmRBY2NvdW50RGV0YWlsc1xyXG4gKiBEZXNjOiBSZW5kZXIgRGFzaGJvYXJkQWNjb3VudERldGFpbHNcclxuICovXHJcblxyXG5jb25zdCBEYXNoYm9hcmRBY2NvdW50RGV0YWlscyA9ICgpID0+IHtcclxuICAgIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuICAgIGNvbnN0IGFjY291bnRMaW5rcyA9IFtcclxuICAgICAgICB7IGxhYmVsOiAnTmFtZScsIGluZm86ICdFcmlrYSBBbGV4YW5kZXInIH0sXHJcbiAgICAgICAgeyBsYWJlbDogJ1QtTnVtYmVyJywgaW5mbzogJ1QtMTIzNDU2JyB9LFxyXG4gICAgICAgIHsgbGFiZWw6ICdZb3VyIFZvdWNoZXInLCBpbmZvOiAnQWN0aXZlJyB9LFxyXG4gICAgICAgIHsgbGFiZWw6ICdFbWFpbCBBZGRyZXNzJywgaW5mbzogJ2VtYWlsQGVtYWlsLmNvbScgfSxcclxuICAgICAgICB7IGxhYmVsOiAnJywgaW5mbzogJ1VwZGF0ZSBZb3VyIFBhc3N3b3JkJyB9LFxyXG4gICAgICAgIHsgbGFiZWw6ICcnLCBpbmZvOiAnQ29ubmVjdGVkIEZhY2Vib29rIEFjY291bnQnIH1cclxuICAgIF07XHJcbiAgICBjb25zdCBjb250YWN0SW5mb3JtYXRpb25MaW5rcyA9IFtcclxuICAgICAgICB7IGxhYmVsOiAnTGFuZGxpbmUgUGhvbmUnLCBpbmZvOiAnKDkxNSkgNTU1LTEyMzQnIH0sXHJcbiAgICAgICAgeyBsYWJlbDogJ0NlbGwgUGhvbmUnLCBpbmZvOiAnKDkxNSkgNTU1LTEyMzQnIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBsYWJlbDogJ0FkZHJlc3MnLFxyXG4gICAgICAgICAgICBpbmZvOiAoXHJcbiAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezF9PkFkZHJlc3MgTGluZSBPbmU8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsxfT5BZGRyZXNzIExpbmUgVHdvPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveD5DaXR5LCBTdGF0ZSwgWmlwIENvZGU8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICApXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7IGxhYmVsOiAnWW91ciBUcnVzdGVkIENvbnRhY3QnLCBpbmZvOiAnRmlyc3RuYW1lIExhc3RuYW1lJyB9XHJcbiAgICBdO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICA8Qm94IHBhZGRpbmc9XCIyNHB4IDhweFwiPlxyXG4gICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cInByaW1hcnkubGlnaHRcIiBmb250U2l6ZT1cImg1LmZvbnRTaXplXCIgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEFjY291bnQgSW5mb3JtYXRpb25cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveD5cclxuICAgICAgICAgICAgICAgICAgICB7YWNjb3VudExpbmtzLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdD17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBiPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluSGVpZ2h0PVwiOTBweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuY2FyZExpbmtzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3NUZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgZmxleERpcmVjdGlvbj1cImNvbHVtblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cInByaW1hcnkuZXh0cmFMaWdodFwiIGZvbnRTaXplPVwibWR4bC5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxhYmVsfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtcj17MX0gY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmluZm99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBtYXJnaW5MZWZ0PVwiYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDUuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG10PXs2fT5cclxuICAgICAgICAgICAgICAgICAgICBDb250YWN0IEluZm9ybWF0aW9uXHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDxCb3ggbWI9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtjb250YWN0SW5mb3JtYXRpb25MaW5rcy5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHQ9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYj17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbkhlaWdodD1cIjkwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRMaW5rc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHVuZGVybGluZT1cIm5vbmVcIiBjbGFzc05hbWU9e2NsYXNzZXMuY2FyZExpbmtzVGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGZsZXhEaXJlY3Rpb249XCJjb2x1bW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggY29sb3I9XCJwcmltYXJ5LmV4dHJhTGlnaHRcIiBmb250U2l6ZT1cIm1keGwuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5sYWJlbH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbXI9ezF9IGNvbG9yPVwicHJpbWFyeS5saWdodFwiIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5pbmZvfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgbWFyZ2luTGVmdD1cImF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IERhc2hib2FyZEFjY291bnREZXRhaWxzO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgY2FyZExpbmtzOiB7XHJcbiAgICAgICAgYm9yZGVyQm90dG9tOiBgMXB4IHNvbGlkICR7dGhlbWUuY29tbW9uLmdyYXl9YFxyXG4gICAgfSxcclxuICAgIGNhcmRMaW5rc1RleHQ6IHtcclxuICAgICAgICB3aWR0aDogJzEwMCUnXHJcbiAgICB9XHJcbn0pKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHVzZVN0eWxlcztcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vRGFzaGJvYXJkQWNjb3VudERldGFpbHMnO1xyXG4iLCJpbXBvcnQgeyBBdmF0YXIsIEJveCwgQnV0dG9uLCBDb250YWluZXIsIEdyaWQsIExpbmsgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcblxyXG4vKipcclxuICogTmFtZSA6IERhc2hib2FyZENvbnRhY3RVc1xyXG4gKiBEZXNjIDogRGFzaGJvYXJkQ29udGFjdFVzXHJcbiAqL1xyXG5cclxuY29uc3QgRGFzaGJvYXJkQ29udGFjdFVzID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICA8Qm94IGJnY29sb3I9XCJzZWNvbmRhcnkuZXh0cmFMaWdodFwiIHB0PXszfSBwYj17M30+XHJcbiAgICAgICAgICAgICAgICA8Q29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxHcmlkIGNvbnRhaW5lciBzcGFjaW5nPXszfSBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17Nn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxBdmF0YXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzI5MnB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAnMTAwJSdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwidmlld1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNyYz1cIi9jb250YWN0SW1nLmpwZ1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzcXVhcmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gbWQ9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiY29tbW9uLmxpZ2h0QmxhY2tcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDUuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LnNlbWlCb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYj17Mn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSG93IFNvbWV0aGluZyBFbHNlIFdvcmtzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDUzMDAgRS4gUGFpc2FubyBEcml2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGNvbG9yPVwicHJpbWFyeS5saWdodFwiIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbCBQYXNvLCBUZXhhcyA3OTkwNVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHVuZGVybGluZT1cIm5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGNvbG9yPVwicHJpbWFyeS5tYWluXCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHZXQgRGlyZWN0aW9uc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtdD17NH0gcGI9ezN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cImxhcmdlXCIgY29sb3I9XCJwcmltYXJ5XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAoOTE1KSA4NDktMzEyNFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIDxCb3ggcHQ9ezd9IHBiPXs2fT5cclxuICAgICAgICAgICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1iPXsxfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgT2ZmaWNlIEhvdXJzXHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cInByaW1hcnkuZXh0cmFMaWdodFwiIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTW9uZGF5IHRocm91Z2hcclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGNvbG9yPVwicHJpbWFyeS5leHRyYUxpZ2h0XCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiIG1iPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRnJpZGF5IDggYS5tLiB0byA1IHAubS5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDUuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWI9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBTcGVjaWFsIEFzc2lzdGFuY2VcclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGNvbG9yPVwicHJpbWFyeS5leHRyYUxpZ2h0XCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiIG1iPXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgRGVhZiBvciBoYXJkIG9mIGhlYXJpbmcgY2xpZW50cyBtYXkgdXNlIHRoZSBUREQgdGVsZXBob25lIGxpbmVcclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJsYXJnZVwiIGNvbG9yPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgTG9nIEluXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGFzaGJvYXJkQ29udGFjdFVzO1xyXG4iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9EYXNoYm9hcmRDb250YWN0VXMnO1xyXG4iLCJpbXBvcnQgeyBCb3gsIENvbnRhaW5lciwgTGluayB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IFRhYiBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9UYWInO1xyXG5pbXBvcnQgVGFicyBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9UYWJzJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2hldnJvblJpZ2h0LCBIZWxwQ2lyY2xlLCBJbmZvLCBQaG9uZSB9IGZyb20gJ3JlYWN0LWZlYXRoZXInO1xyXG5pbXBvcnQgQ29tbW9uQ2FyZCBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0NvbW1vbkNhcmQnO1xyXG5pbXBvcnQgdXNlU3R5bGVzIGZyb20gJy4vRGFzaGJvYXJkSGVscENlbnRlclN0eWxlcyc7XHJcblxyXG4vKipcclxuICogTmFtZTogRGFzaGJvYXJkSGVscENlbnRlclxyXG4gKiBEZXNjOiBSZW5kZXIgRGFzaGJvYXJkSGVscENlbnRlclxyXG4gKi9cclxuXHJcbmNvbnN0IERhc2hib2FyZEhlbHBDZW50ZXIgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgICBjb25zdCBbdmFsdWUsIHNldFZhbHVlXSA9IFJlYWN0LnVzZVN0YXRlKDApO1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChldmVudCwgbmV3VmFsdWUpID0+IHtcclxuICAgICAgICBzZXRWYWx1ZShuZXdWYWx1ZSk7XHJcbiAgICB9O1xyXG4gICAgY29uc3QgZ2V0dGluZ1N0YXJ0ZWRUZXh0ID0gW1xyXG4gICAgICAgIHsgdGV4dDogJ0ZpcnN0IHRpbWUgdXNlcnMgZ2V0dGluZyBzdGFydGVkIHdpdGggaG91c2luZyBhc3Npc3RhbmNlJyB9LFxyXG4gICAgICAgIHsgdGV4dDogJ0hlbHBpbmcgYSByZWxhdGl2ZSwgcGF0aWVudCwgb3IgY2xpZW50IHdpdGggYW4gYXBwbGljYXRpb24nIH0sXHJcbiAgICAgICAgeyB0ZXh0OiAnV2hhdCB0byBleHBlY3QgZnJvbSB0aGUgYXBwbGljYXRpb24gcHJvY2VzcycgfVxyXG4gICAgXTtcclxuICAgIGNvbnN0IGVsaWdpYmlsaXR5UXVlc3Rpb25zVGV4dCA9IFtcclxuICAgICAgICB7IHRleHQ6ICdGaW5kaW5nIG91dCBpZiB5b3UgYXJlIGVsaWdpYmxlIGZvciBwcm9ncmFtIGFzc2lzdGFuY2UnIH0sXHJcbiAgICAgICAgeyB0ZXh0OiAnV2h5IHdhc27igJl0IEkgZWxpZ2libGUgZm9yIEhBQ0VQ4oCZcyBwcm9ncmFtcz8nIH1cclxuICAgIF07XHJcbiAgICBjb25zdCBvdGhlclRvcGljc1RleHQgPSBbXHJcbiAgICAgICAgeyB0ZXh0OiAnV2hhdCB0byBkbyB3aGVuIHlvdXIgZmluYW5jaWFsIHNpdHVhdGlvbiBvciBob3VzZWhvbGQgaGFzIGNoYW5nZWQnIH0sXHJcbiAgICAgICAgeyB0ZXh0OiAnVGhlc2UgZWFjaCB3b3VsZCBnZXQgYSBwYWdlIHdoZXJlIEhBQ0VQIGNhbiBlbnRlciB0ZXh0JyB9LFxyXG4gICAgICAgIHsgdGV4dDogJ1RoZXNlIHdpbGwgYWxsIGJlIHB1cmVseSBjb250ZW50IHRoYXQgSEFDRVAgZGV0ZXJtaW5lcyAnIH0sXHJcbiAgICAgICAgeyB0ZXh0OiAnQWRkIGFzIG1hbnkgc2VjdGlvbnMgYW5kIHRvcGljcyB0aGF0IGFyZSBuZWVkZWQnIH1cclxuICAgIF07XHJcblxyXG4gICAgY29uc3QgbGlua0FycmF5ID0gW1xyXG4gICAgICAgIHsgdGV4dDogJ0hlbHAgVG9waWNzJywgaWNvbjogSGVscENpcmNsZSwgcmlnaHRJY29uOiBDaGV2cm9uUmlnaHQgfSxcclxuICAgICAgICB7IHRleHQ6ICdDb250YWN0IFVzJywgaWNvbjogUGhvbmUsIHJpZ2h0SWNvbjogQ2hldnJvblJpZ2h0IH0sXHJcbiAgICAgICAgeyB0ZXh0OiAnUHJvZ3JhbSBJbmZvcm1hdGlvbicsIGljb246IEluZm8sIHJpZ2h0SWNvbjogQ2hldnJvblJpZ2h0IH1cclxuICAgIF07XHJcblxyXG4gICAgZnVuY3Rpb24gYTExeVByb3BzKGluZGV4KSB7XHJcbiAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgaWQ6IGB2ZXJ0aWNhbC10YWItJHtpbmRleH1gLFxyXG4gICAgICAgICAgICAnYXJpYS1jb250cm9scyc6IGB2ZXJ0aWNhbC10YWJwYW5lbC0ke2luZGV4fWBcclxuICAgICAgICB9O1xyXG4gICAgfVxyXG4gICAgZnVuY3Rpb24gVGFiUGFuZWwocHJvcHMpIHtcclxuICAgICAgICBjb25zdCB7IGNoaWxkcmVuLCB2YWx1ZSwgaW5kZXgsIC4uLm90aGVyIH0gPSBwcm9wcztcclxuXHJcbiAgICAgICAgcmV0dXJuIChcclxuICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgd2lkdGg9XCIxMDAlXCJcclxuICAgICAgICAgICAgICAgIG1heFdpZHRoPVwiNjQwcHhcIlxyXG4gICAgICAgICAgICAgICAgcm9sZT1cInRhYnBhbmVsXCJcclxuICAgICAgICAgICAgICAgIGhpZGRlbj17dmFsdWUgIT09IGluZGV4fVxyXG4gICAgICAgICAgICAgICAgaWQ9e2B2ZXJ0aWNhbC10YWJwYW5lbC0ke2luZGV4fWB9XHJcbiAgICAgICAgICAgICAgICBhcmlhLWxhYmVsbGVkYnk9e2B2ZXJ0aWNhbC10YWItJHtpbmRleH1gfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnRhYldyYXBwZXJ9XHJcbiAgICAgICAgICAgICAgICB7Li4ub3RoZXJ9PlxyXG4gICAgICAgICAgICAgICAge3ZhbHVlID09PSBpbmRleCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgPENvbW1vbkNhcmQgc2hvd0JhY2tCdG49e2ZhbHNlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveD57Y2hpbGRyZW59PC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Db21tb25DYXJkPlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgKTtcclxuICAgIH1cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEJveD5cclxuICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwibm9uZVwiIGNsYXNzTmFtZT17Y2xhc3Nlcy53ZWJUYWJzfSBtYj17MTJ9PlxyXG4gICAgICAgICAgICAgICAgPENvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgbXQ9ezEwfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDEuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbj1cInJpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbj1cInJlbGF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A9XCIxNDBweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXI9ezV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3g+SGVscDwvQm94PiA8Qm94PkNlbnRlcjwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFic1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9yaWVudGF0aW9uPVwidmVydGljYWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJzY3JvbGxhYmxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17dmFsdWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPVwiVmVydGljYWwgdGFicyBleGFtcGxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMudGFic30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xpbmtBcnJheS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhYlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtLnRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbD17XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuY2FyZExpbmtzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpdGVtLmljb24gY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17MX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWF4V2lkdGg9XCI0MDBweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5tYWluXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNS5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdoaXRlU3BhY2U9XCJub1dyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGNsYXNzTmFtZT1cImFycm93XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGl0ZW0ucmlnaHRJY29uIGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Li4uYTExeVByb3BzKDApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UYWJzPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCB3aWR0aD1cIjEwMCVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJQYW5lbCB2YWx1ZT17dmFsdWV9IGluZGV4PXswfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IHBhZGRpbmc9XCIxNnB4XCIgbWF4V2lkdGg9XCI1OTJweFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNS5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHZXR0aW5nIFN0YXJ0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Z2V0dGluZ1N0YXJ0ZWRUZXh0Lm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHQ9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBiPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHQ9XCI5MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRMaW5rc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtpdGVtfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhyZWY9XCIjXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVuZGVybGluZT1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRMaW5rc1RleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1yPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIG1hcmdpbkxlZnQ9XCJhdXRvXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiSW5kaWdvXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezI0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDUuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtdD17Nn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBFbGlnaWJpbGl0eSBRdWVzdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2VsaWdpYmlsaXR5UXVlc3Rpb25zVGV4dC5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB0PXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYj17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluSGVpZ2h0PVwiOTBweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiI1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bmRlcmxpbmU9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3NUZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17MX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg2LmZvbnRTaXplXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBtYXJnaW5MZWZ0PVwiYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cIkluZGlnb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsyNH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXQ9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgT3RoZXIgVG9waWNzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge290aGVyVG9waWNzVGV4dC5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB0PXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYj17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWluSGVpZ2h0PVwiOTBweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBocmVmPVwiI1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bmRlcmxpbmU9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3NUZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17MX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg2LmZvbnRTaXplXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnRleHR9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBtYXJnaW5MZWZ0PVwiYXV0b1wiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cIkluZGlnb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsyNH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhYlBhbmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhYlBhbmVsIHZhbHVlPXt2YWx1ZX0gaW5kZXg9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEl0ZW0gVHdvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhYlBhbmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhYlBhbmVsIHZhbHVlPXt2YWx1ZX0gaW5kZXg9ezJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEl0ZW0gVGhyZWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvVGFiUGFuZWw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICA8Qm94IG1hcmdpbj1cIjAgOHB4IDUwcHhcIiBjbGFzc05hbWU9e2NsYXNzZXMubW9iaWxlVGFic30+XHJcbiAgICAgICAgICAgICAgICB7bGlua0FycmF5Lm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcHQ9ezN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBiPXszfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuY2FyZExpbmtzfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHVuZGVybGluZT1cIm5vbmVcIiBjbGFzc05hbWU9e2NsYXNzZXMuY2FyZExpbmtzVGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1yPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDUuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpdGVtLmljb24gY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17MX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1heFdpZHRoPVwiNDAwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDUuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgbWFyZ2luTGVmdD1cImF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICA8L0JveD5cclxuICAgICk7XHJcbn07XHJcblxyXG5EYXNoYm9hcmRIZWxwQ2VudGVyLnByb3BUeXBlcyA9IHtcclxuICAgIGNoaWxkcmVuOiBQcm9wVHlwZXMuYW55LFxyXG4gICAgdmFsdWU6IFByb3BUeXBlcy5udW1iZXIsXHJcbiAgICBpbmRleDogUHJvcFR5cGVzLm51bWJlclxyXG59O1xyXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmRIZWxwQ2VudGVyO1xyXG4iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9EYXNoYm9hcmRIZWxwQ2VudGVyJztcclxuIiwiaW1wb3J0IHsgQXZhdGFyLCBCb3gsIEJ1dHRvbiwgQ29udGFpbmVyLCBMaW5rIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5pbXBvcnQgVGFiIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL1RhYic7XHJcbmltcG9ydCBUYWJzIGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL1RhYnMnO1xyXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBDaGV2cm9uUmlnaHQsIFNhdmUsIFNldHRpbmdzLCBVc2VyIH0gZnJvbSAncmVhY3QtZmVhdGhlcic7XHJcbmltcG9ydCBDb21tb25DYXJkIGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvQ29tbW9uQ2FyZCc7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi9EYXNoYm9hcmRIZWxwVG9waWNzU3R5bGVzJztcclxuLyoqXHJcbiAqIE5hbWU6IERhc2hib2FyZEhlbHBUb3BpY3NcclxuICogRGVzYzogUmVuZGVyIERhc2hib2FyZEhlbHBUb3BpY3NcclxuICovXHJcblxyXG5jb25zdCBEYXNoYm9hcmRIZWxwVG9waWNzID0gKCkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgW3ZhbHVlLCBzZXRWYWx1ZV0gPSBSZWFjdC51c2VTdGF0ZSgwKTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDaGFuZ2UgPSAoZXZlbnQsIG5ld1ZhbHVlKSA9PiB7XHJcbiAgICAgICAgc2V0VmFsdWUobmV3VmFsdWUpO1xyXG4gICAgfTtcclxuICAgIGZ1bmN0aW9uIGExMXlQcm9wcyhpbmRleCkge1xyXG4gICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgIGlkOiBgdmVydGljYWwtdGFiLSR7aW5kZXh9YCxcclxuICAgICAgICAgICAgJ2FyaWEtY29udHJvbHMnOiBgdmVydGljYWwtdGFicGFuZWwtJHtpbmRleH1gXHJcbiAgICAgICAgfTtcclxuICAgIH1cclxuICAgIGZ1bmN0aW9uIFRhYlBhbmVsKHByb3BzKSB7XHJcbiAgICAgICAgY29uc3QgeyBjaGlsZHJlbiwgdmFsdWUsIGluZGV4LCAuLi5vdGhlciB9ID0gcHJvcHM7XHJcblxyXG4gICAgICAgIHJldHVybiAoXHJcbiAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgIHdpZHRoPVwiMTAwJVwiXHJcbiAgICAgICAgICAgICAgICBtYXhXaWR0aD1cIjY0MHB4XCJcclxuICAgICAgICAgICAgICAgIHJvbGU9XCJ0YWJwYW5lbFwiXHJcbiAgICAgICAgICAgICAgICBoaWRkZW49e3ZhbHVlICE9PSBpbmRleH1cclxuICAgICAgICAgICAgICAgIGlkPXtgdmVydGljYWwtdGFicGFuZWwtJHtpbmRleH1gfVxyXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbGxlZGJ5PXtgdmVydGljYWwtdGFiLSR7aW5kZXh9YH1cclxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy50YWJXcmFwcGVyfVxyXG4gICAgICAgICAgICAgICAgey4uLm90aGVyfT5cclxuICAgICAgICAgICAgICAgIHt2YWx1ZSA9PT0gaW5kZXggJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgIDxDb21tb25DYXJkIHNob3dCYWNrQnRuPXtmYWxzZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3g+e2NoaWxkcmVufTwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQ29tbW9uQ2FyZD5cclxuICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICk7XHJcbiAgICB9XHJcbiAgICBjb25zdCBhY2NvdW50TGlua3MgPSBbXHJcbiAgICAgICAgeyB0ZXh0OiAnSGVscCBUb3BpY3MnLCBpY29uOiBVc2VyLCByaWdodEljb246IENoZXZyb25SaWdodCB9LFxyXG4gICAgICAgIHsgdGV4dDogJ0NvbnRhY3QgVXMnLCBpY29uOiBTZXR0aW5ncywgcmlnaHRJY29uOiBDaGV2cm9uUmlnaHQgfSxcclxuICAgICAgICB7IHRleHQ6ICdQcm9ncmFtIEluZm9ybWF0aW9uJywgaWNvbjogU2F2ZSwgcmlnaHRJY29uOiBDaGV2cm9uUmlnaHQgfVxyXG4gICAgXTtcclxuICAgIGNvbnN0IGdldHRpbmdTdGFydGVkVGV4dCA9IFtcclxuICAgICAgICB7IHRleHQ6ICdGaXJzdCB0aW1lIHVzZXJzIGdldHRpbmcgc3RhcnRlZCB3aXRoIGhvdXNpbmcgYXNzaXN0YW5jZScgfSxcclxuICAgICAgICB7IHRleHQ6ICdIZWxwaW5nIGEgcmVsYXRpdmUsIHBhdGllbnQsIG9yIGNsaWVudCB3aXRoIGFuIGFwcGxpY2F0aW9uJyB9LFxyXG4gICAgICAgIHsgdGV4dDogJ1doYXQgdG8gZXhwZWN0IGZyb20gdGhlIGFwcGxpY2F0aW9uIHByb2Nlc3MnIH1cclxuICAgIF07XHJcbiAgICBjb25zdCBlbGlnaWJpbGl0eVF1ZXN0aW9uc1RleHQgPSBbXHJcbiAgICAgICAgeyB0ZXh0OiAnRmluZGluZyBvdXQgaWYgeW91IGFyZSBlbGlnaWJsZSBmb3IgcHJvZ3JhbSBhc3Npc3RhbmNlJyB9LFxyXG4gICAgICAgIHsgdGV4dDogJ1doeSB3YXNu4oCZdCBJIGVsaWdpYmxlIGZvciBIQUNFUOKAmXMgcHJvZ3JhbXM/JyB9XHJcbiAgICBdO1xyXG4gICAgY29uc3Qgb3RoZXJUb3BpY3NUZXh0ID0gW1xyXG4gICAgICAgIHsgdGV4dDogJ1doYXQgdG8gZG8gd2hlbiB5b3VyIGZpbmFuY2lhbCBzaXR1YXRpb24gb3IgaG91c2Vob2xkIGhhcyBjaGFuZ2VkJyB9LFxyXG4gICAgICAgIHsgdGV4dDogJ1RoZXNlIGVhY2ggd291bGQgZ2V0IGEgcGFnZSB3aGVyZSBIQUNFUCBjYW4gZW50ZXIgdGV4dCcgfSxcclxuICAgICAgICB7IHRleHQ6ICdUaGVzZSB3aWxsIGFsbCBiZSBwdXJlbHkgY29udGVudCB0aGF0IEhBQ0VQIGRldGVybWluZXMgJyB9LFxyXG4gICAgICAgIHsgdGV4dDogJ0FkZCBhcyBtYW55IHNlY3Rpb25zIGFuZCB0b3BpY3MgdGhhdCBhcmUgbmVlZGVkJyB9XHJcbiAgICBdO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJub25lXCIgY2xhc3NOYW1lPXtjbGFzc2VzLndlYlRhYnN9IG1iPXsxMn0+XHJcbiAgICAgICAgICAgICAgICA8Q29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBtdD17MTB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoMS5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dEFsaWduPVwicmlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uPVwicmVsYXRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRvcD1cIjE0MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17NX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveD5IZWxwPC9Cb3g+IDxCb3g+Q2VudGVyPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb3JpZW50YXRpb249XCJ2ZXJ0aWNhbFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInNjcm9sbGFibGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt2YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJWZXJ0aWNhbCB0YWJzIGV4YW1wbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy50YWJzfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7YWNjb3VudExpbmtzLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGFiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3N9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1yPXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDUuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPGl0ZW0uaWNvbiBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1yPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYXhXaWR0aD1cIjQwMHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2hpdGVTcGFjZT1cIm5vV3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgY2xhc3NOYW1lPVwiYXJyb3dcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aXRlbS5yaWdodEljb24gY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsuLi5hMTF5UHJvcHMoMCl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhYnM+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94IHdpZHRoPVwiMTAwJVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRhYlBhbmVsIHZhbHVlPXt2YWx1ZX0gaW5kZXg9ezB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggcGFkZGluZz1cIjE2cHhcIiBtYXhXaWR0aD1cIjU5MnB4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYj17NH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy50aXRsZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDcmVhdGluZyBZb3VyIEFjY291bnQgd2l0aCBIQUNFUOKAmXMgQXBwTmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYj17Mn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBIb3cgU29tZXRoaW5nIFdvcmtzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGNvbG9yPVwicHJpbWFyeS5saWdodFwiIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIiBtYj17NX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpcHN1bSBkb2xvciBzaXQgYW1ldCwgY29uc2VjdGV0dXIgYWRpcGlzY2luZyBlbGl0LiBBcmN1XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwcmV0aXVtIHVsdHJpY2VzIHZpdGFlIHByZXRpdW0gdm9sdXRwYXQgbmliaC4gRG9sb3JcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHVsbGFtY29ycGVyIGlkIGV0IGNvbW1vZG8uIEF0IHZlbCBtYXVyaXMgdnVscHV0YXRlIG1hbGVzdWFkYVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXVjdG9yIGRpcyBldSBzZWQuIEFjIG9ybmFyZSBkaWFtIHZpdmVycmEgbGFvcmVldC5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiIG1iPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVsZW1lbnR1bSBwcmV0aXVtIG51bGxhIG5lcXVlLCBjb252YWxsaXMgdG9ydG9yIG5pc2wgbnVsbGFtXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW5jaWR1bnQgY29tbW9kby4gTGVvIHZpdGFlIGdyYXZpZGEgZHVpIGJpYmVuZHVtIG51bGxhLlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJvaW4gc2VkIGlkIG1hdHRpcyBzZWQgdmVuZW5hdGlzIG1hbGVzdWFkYSByaXN1cyBzZW1wZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGV0aWFtLiBEaWFtIGlkIHZpdmVycmEgdXJuYSBjdW0gdG9ydG9yIHNlZCBhcmN1IHNlbSBzZWQuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs3fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cIm1lZGl1bVwiIGNvbG9yPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdXR0b24gTGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGJvcmRlclJhZGl1cz1cIjVweFwiIG92ZXJmbG93PVwiaGlkZGVuXCIgbWI9ezN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEF2YXRhclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzI5MnB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6ICcxMDAlJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWx0PVwidmlld1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPVwiL3ZpZXcuanBnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwic3F1YXJlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1iPXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEhvdyBTb21ldGhpbmcgRWxzZSBXb3Jrc1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cInByaW1hcnkubGlnaHRcIiBmb250U2l6ZT1cImg2LmZvbnRTaXplXCIgbWI9ezN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXBzdW0gZG9sb3Igc2l0IGFtZXQsIGNvbnNlY3RldHVyIGFkaXBpc2NpbmcgZWxpdC4gQXJjdVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHJldGl1bSB1bHRyaWNlcyB2aXRhZSBwcmV0aXVtIHZvbHV0cGF0IG5pYmguIERvbG9yXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB1bGxhbWNvcnBlciBpZCBldCBjb21tb2RvLiBBdCB2ZWwgbWF1cmlzIHZ1bHB1dGF0ZSBtYWxlc3VhZGFcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1Y3RvciBkaXMgZXUgc2VkLiBBYyBvcm5hcmUgZGlhbSB2aXZlcnJhIGxhb3JlZXQuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs3fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cIm1lZGl1bVwiIGNvbG9yPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCdXR0b24gTGlua1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UYWJQYW5lbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJQYW5lbCB2YWx1ZT17dmFsdWV9IGluZGV4PXsxfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJdGVtIFR3b1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9UYWJQYW5lbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUYWJQYW5lbCB2YWx1ZT17dmFsdWV9IGluZGV4PXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJdGVtIFRocmVlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1RhYlBhbmVsPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQ29udGFpbmVyPlxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPEJveCBtYXJnaW49XCIzMHB4IDhweCA1MHB4XCIgY2xhc3NOYW1lPXtjbGFzc2VzLm1vYmlsZVRhYnN9PlxyXG4gICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cInByaW1hcnkubGlnaHRcIiBmb250U2l6ZT1cImg1LmZvbnRTaXplXCIgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIEdldHRpbmcgU3RhcnRlZFxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgIHtnZXR0aW5nU3RhcnRlZFRleHQubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB0PXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHQ9XCI5MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIiNcIiB1bmRlcmxpbmU9XCJub25lXCIgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRMaW5rc1RleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbXI9ezF9IGNvbG9yPVwicHJpbWFyeS5tYWluXCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgbWFyZ2luTGVmdD1cImF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICBtdD17Nn0+XHJcbiAgICAgICAgICAgICAgICAgICAgRWxpZ2liaWxpdHkgUXVlc3Rpb25zXHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDxCb3ggbWI9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtlbGlnaWJpbGl0eVF1ZXN0aW9uc1RleHQubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB0PXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHQ9XCI5MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIiNcIiB1bmRlcmxpbmU9XCJub25lXCIgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRMaW5rc1RleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbXI9ezF9IGNvbG9yPVwicHJpbWFyeS5tYWluXCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgbWFyZ2luTGVmdD1cImF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICBtdD17Nn0+XHJcbiAgICAgICAgICAgICAgICAgICAgT3RoZXIgVG9waWNzXHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDxCb3ggbWI9ezZ9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtvdGhlclRvcGljc1RleHQubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB0PXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHQ9XCI5MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5jYXJkTGlua3N9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2l0ZW19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIiNcIiB1bmRlcmxpbmU9XCJub25lXCIgY2xhc3NOYW1lPXtjbGFzc2VzLmNhcmRMaW5rc1RleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbXI9ezF9IGNvbG9yPVwicHJpbWFyeS5tYWluXCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgbWFyZ2luTGVmdD1cImF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgKTtcclxufTtcclxuXHJcbkRhc2hib2FyZEhlbHBUb3BpY3MucHJvcFR5cGVzID0ge1xyXG4gICAgY2hpbGRyZW46IFByb3BUeXBlcy5hbnksXHJcbiAgICB2YWx1ZTogUHJvcFR5cGVzLm51bWJlcixcclxuICAgIGluZGV4OiBQcm9wVHlwZXMubnVtYmVyXHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IERhc2hib2FyZEhlbHBUb3BpY3M7XHJcbiIsImltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgICBjYXJkTGlua3M6IHtcclxuICAgICAgICAnJjpub3QoOmxhc3QtY2hpbGQpJzoge1xyXG4gICAgICAgICAgICBib3JkZXJCb3R0b206IGAxcHggc29saWQgJHt0aGVtZS5jb21tb24uZ3JheX1gXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGNhcmRMaW5rc1RleHQ6IHtcclxuICAgICAgICB3aWR0aDogJzEwMCUnXHJcbiAgICB9LFxyXG4gICAgdGFiV3JhcHBlcjoge1xyXG4gICAgICAgICcmID4gZGl2Jzoge1xyXG4gICAgICAgICAgICBtaW5IZWlnaHQ6ICc4MDBweCcsXHJcbiAgICAgICAgICAgIHBhZGRpbmdCb3R0b206ICc4cHgnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIG1vYmlsZVRhYnM6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ21kJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdub25lJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICB3ZWJUYWJzOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdtZCcpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHRpdGxlOiB7XHJcbiAgICAgICAgYm9yZGVyQm90dG9tOiBgMXB4IHNvbGlkICR7dGhlbWUuY29tbW9uLmdyYXl9YFxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL0Rhc2hib2FyZEhlbHBUb3BpY3MnO1xyXG4iLCJpbXBvcnQgeyBCb3gsIENvbnRhaW5lciwgR3JpZCwgTGluayB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IGNsc3ggZnJvbSAnY2xzeCc7XHJcbmltcG9ydCBJbWFnZSBmcm9tICduZXh0L2ltYWdlJztcclxuaW1wb3J0IHsgZGVmYXVsdCBhcyBSZWFjdCB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQXJjaGl2ZSwgQ2hldnJvblJpZ2h0LCBFZGl0LCBQbHVzIH0gZnJvbSAncmVhY3QtZmVhdGhlcic7XHJcbmltcG9ydCBQcm9ncmFtQ2FyZCBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL1Byb2dyYW1DYXJkJztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL0Rhc2hib2FyZEhvbWVTdHlsZXMnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWU6IERhc2hib2FyZEhvbWVcclxuICogRGVzYzogUmVuZGVyIERhc2hib2FyZEhvbWVcclxuICovXHJcblxyXG5jb25zdCBEYXNoYm9hcmRIb21lID0gKCkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgbGlua0FycmF5ID0gW1xyXG4gICAgICAgIHsgdGV4dDogJ0FwcGx5IGZvciBvdGhlciBwcm9ncmFtcyA+JywgaWNvbjogUGx1cyB9LFxyXG4gICAgICAgIHsgdGV4dDogJ1VwZGF0ZSB5b3VyIGVsaWdpYmlsaXR5IGluZm8gPicsIGljb246IEVkaXQgfSxcclxuICAgICAgICB7IHRleHQ6ICdWaWV3ICg2KSBhcmNoaXZlZCBhcHBsaWNhdGlvbnMgPicsIGljb246IEFyY2hpdmUgfVxyXG4gICAgXTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxCb3ggcGI9ezJ9IGJnY29sb3I9XCJzZWNvbmRhcnkuZXh0cmFMaWdodFwiIGNsYXNzTmFtZT17Y2xhc3Nlcy5kYXNoYm9hcmRVcHBlcldyYXBwZXJ9PlxyXG4gICAgICAgICAgICAgICAgPENvbnRhaW5lcj5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHB0PXs5fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYj17NX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNS5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5saW5rVGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFlvdXIgUHJvZ3JhbSBBcHBsaWNhdGlvbnNcclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPEdyaWQgY29udGFpbmVyIHNwYWNpbmc9ezR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gbWQ9ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtdD17LTh9IGNsYXNzTmFtZT17Y2xhc3Nlcy5saW5rTGlzdH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17M30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQcm9ncmFtQ2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cInN1Y2Nlc3NcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0ltYWdlPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0xlZnRBcnJvdz17dHJ1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2dyYW0gVGl0bGUgb24gQ2FyZCAoMUJSKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiYm9keTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBvc2l0aXZlIHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUHJvZ3JhbUNhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17M30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQcm9ncmFtQ2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIndhaXRpbmdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0ltYWdlPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0xlZnRBcnJvdz17dHJ1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2dyYW0gVGl0bGUgb24gQ2FyZCAoMUJSKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiYm9keTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBvc2l0aXZlIHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUHJvZ3JhbUNhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17M30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxQcm9ncmFtQ2FyZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImZhaWxlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93SW1hZ2U9e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93TGVmdEFycm93PXt0cnVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUHJvZ3JhbSBUaXRsZSBvbiBDYXJkICgxQlIpXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQ9XCJib2R5MVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5yZWd1bGFyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUG9zaXRpdmUgc3RhdHVzXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Qcm9ncmFtQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFByb2dyYW1DYXJkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93SW1hZ2U9e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaG93TGVmdEFycm93PXtmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNob3dMZWZ0Qm9yZGVyPXtmYWxzZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2dyYW0gVGl0bGUgb24gQ2FyZCAoMUJSKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiYm9keTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFBvc2l0aXZlIHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUHJvZ3JhbUNhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gbWQ9ezR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7bGlua0FycmF5Lm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXszfSBrZXk9e2l0ZW0udGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHVuZGVybGluZT1cIm5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8aXRlbS5pY29uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD1cIjJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJJbmRpZ29cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MTV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwibGcuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1sPXsxLjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICA8Q29udGFpbmVyPlxyXG4gICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgIG10PXs4fVxyXG4gICAgICAgICAgICAgICAgICAgIG1iPXs1fVxyXG4gICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDUuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5leHRyYUxpZ2h0XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgTW9yZSBSZXNvdXJjZXNcclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgY29udGFpbmVyIHNwYWNpbmc9ezR9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtbXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGltYWdlTmFtZTogJy9GcmFtZTEucG5nJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6ICdDYWxjdWxhdGUgd2hhdCB5b3UgY2FuIGFmZm9yZCB0byByZW50J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbWFnZU5hbWU6ICcvRnJhbWUyLnBuZycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnQnJvd3NlIEVsIFBhc28gaG91c2luZyBvcHBvcnR1bml0ZXMnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmdDb2xvcjogJ3N1Y2Nlc3MnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGltYWdlTmFtZTogJy9GcmFtZTEucG5nJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6ICdGaW5kIG91dCBpZiB5b3XigJlyZSBlbGlnaWJsZScsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiZ0NvbG9yOiAnd2FybmluZydcclxuICAgICAgICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW1hZ2VOYW1lOiAnL0ZyYW1lMi5wbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogJ1VwZGF0ZSB5b3VyIGZhbWlseSBvciBmaW5hbmNpYWwgaW5mbydcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIF0ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezZ9IG1kPXszfSBrZXk9e2l0ZW0udHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcD17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM9XCIxNnB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYj17OH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Nsc3goXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzZXMuYm94V3JhcHBlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5iZ0NvbG9yICYmIGNsYXNzZXNbaXRlbS5iZ0NvbG9yXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggYm9yZGVyUmFkaXVzPVwiMTZweFwiIG1iPXsyfSBjbGFzc05hbWU9e2NsYXNzZXMuaW1hZ2VXcmFwcGVyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb249XCJyZWxhdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A9XCItMTZweFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz17aXRlbS5pbWFnZU5hbWV9IHdpZHRoPXsyMDd9IGhlaWdodD17MTg2fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHVuZGVybGluZT1cIm5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGp1c3RpZnlDb250ZW50PVwiZmxleC1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXI9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQ9XCJzcGFuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbj1cInJlbGF0aXZlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A9XCIzcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ9XCI1cHhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5tb2JpbGVBcnJvd30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17M31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJpbmRpZ29cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsxNn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg0LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cIm5vbmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLndlYkFycm93fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHJva2VXaWR0aD17M31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImluZGlnb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17MTZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICA8L0NvbnRhaW5lcj5cclxuICAgICAgICA8Lz5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEYXNoYm9hcmRIb21lO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgbGlua1RleHQ6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ3NtJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaydcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgc3VjY2Vzczoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnc20nKV06IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBgJHt0aGVtZS5wYWxldHRlLnNlY29uZGFyeS5saWdodH0gIWltcG9ydGFudGBcclxuICAgICAgICB9LFxyXG4gICAgICAgICcmID4gZGl2OmZpcnN0LWNoaWxkJzoge1xyXG4gICAgICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bignc20nKV06IHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogYCR7dGhlbWUucGFsZXR0ZS5zZWNvbmRhcnkubGlnaHR9ICFpbXBvcnRhbnRgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgd2FybmluZzoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnc20nKV06IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBgJHt0aGVtZS5wYWxldHRlLnBlbmRpbmcuZXh0cmFMaWdodH0gIWltcG9ydGFudGBcclxuICAgICAgICB9LFxyXG4gICAgICAgICcmID4gZGl2OmZpcnN0LWNoaWxkJzoge1xyXG4gICAgICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bignc20nKV06IHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogYCR7dGhlbWUucGFsZXR0ZS5wZW5kaW5nLmV4dHJhTGlnaHR9ICFpbXBvcnRhbnRgXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgYm94V3JhcHBlcjoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnc20nKV06IHtcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMTAwcHgnLFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbW1vbi5zZWNvbmRhcnlCZ0NvbG9yLFxyXG4gICAgICAgICAgICBwYWRkaW5nOiAnMHB4IDI0cHggMjRweCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgaW1hZ2VXcmFwcGVyOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb21tb24uc2Vjb25kYXJ5QmdDb2xvcixcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ3NtJyldOiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50JyxcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAwXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGxpbmtMaXN0OiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdzbScpXToge1xyXG4gICAgICAgICAgICBtYXJnaW5Ub3A6IDBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgZGFzaGJvYXJkVXBwZXJXcmFwcGVyOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdzbScpXToge1xyXG4gICAgICAgICAgICBwYWRkaW5nQm90dG9tOiAnNjRweCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgbW9iaWxlQXJyb3c6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ3NtJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdub25lJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICB3ZWJBcnJvdzoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnc20nKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJ1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSkpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXNlU3R5bGVzO1xyXG4iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9EYXNoYm9hcmRIb21lJztcclxuIiwiaW1wb3J0IHsgQm94LCBMaW5rLCBDb250YWluZXIsIEdyaWQgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi4vRGFzaGJvYXJkUGFnZUNvbXBvbmVudFN0eWxlcyc7XHJcbmltcG9ydCBjbHN4IGZyb20gJ2Nsc3gnO1xyXG5pbXBvcnQgSW1hZ2UgZnJvbSAnbmV4dC9pbWFnZSc7XHJcblxyXG4vKipcclxuICogTmFtZTogRGFzaGJvYXJkTm9Qcm9ncmFtc1xyXG4gKiBEZXNjOiBSZW5kZXIgRGFzaGJvYXJkTm9Qcm9ncmFtc1xyXG4gKi9cclxuXHJcbmNvbnN0IERhc2hib2FyZE5vUHJvZ3JhbXMgPSAoKSA9PiB7XHJcbiAgICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgbXQ9ezUuNX1cclxuICAgICAgICAgICAgICAgICAgICBtYj17NX1cclxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIj5cclxuICAgICAgICAgICAgICAgICAgICBNb3JlIFJlc291cmNlc1xyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8R3JpZCBjb250YWluZXIgc3BhY2luZz17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW1hZ2VOYW1lOiAnL0ZyYW1lMS5wbmcnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dDogJ1JlbnQgQWZmb3JkYWJpbGl0eSBDYWxjdWxhdG9yJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbWFnZU5hbWU6ICcvRnJhbWUyLnBuZycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnQnJvd3NlIFJlbnRhbCBQcm9wZXJ0aWVzIG9uIEdvU2VjdGlvbjgnLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYmdDb2xvcjogJ3N1Y2Nlc3MnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGltYWdlTmFtZTogJy9GcmFtZTEucG5nJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRleHQ6ICdDYWxjdWxhdGUgd2hhdCByZW50IHlvdSBjYW4gYWZmb3JkJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJnQ29sb3I6ICd3YXJuaW5nJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpbWFnZU5hbWU6ICcvRnJhbWUyLnBuZycsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0OiAnQ2FsY3VsYXRlIHdoYXQgcmVudCB5b3UgY2FuIGFmZm9yZCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgIF0ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezZ9IG1kPXszfSBrZXk9e2l0ZW0udHlwZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcD17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM9XCIxNnB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtYj17MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Nsc3goXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzZXMuYm94V3JhcHBlcixcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaXRlbS5iZ0NvbG9yICYmIGNsYXNzZXNbaXRlbS5iZ0NvbG9yXVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICl9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggYm9yZGVyUmFkaXVzPVwiMTZweFwiIG1iPXsyfSBjbGFzc05hbWU9e2NsYXNzZXMuaW1hZ2VXcmFwcGVyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb249XCJyZWxhdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b3A9XCItMTZweFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz17aXRlbS5pbWFnZU5hbWV9IHdpZHRoPXsyMDd9IGhlaWdodD17MTg2fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHVuZGVybGluZT1cIm5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGp1c3RpZnlDb250ZW50PVwiZmxleC1zdGFydFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXI9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgPC9Db250YWluZXI+ICBcclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGFzaGJvYXJkTm9Qcm9ncmFtc1xyXG4iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9EYXNoYm9hcmROb1Byb2dyYW1zJyIsImltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgICBsaW5rVGV4dDoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnc20nKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBzdWNjZXNzOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdzbScpXToge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGAke3RoZW1lLnBhbGV0dGUuc2Vjb25kYXJ5LmxpZ2h0fSAhaW1wb3J0YW50YFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJyYgPiBkaXY6Zmlyc3QtY2hpbGQnOiB7XHJcbiAgICAgICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCdzbScpXToge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBgJHt0aGVtZS5wYWxldHRlLnNlY29uZGFyeS5saWdodH0gIWltcG9ydGFudGBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICB3YXJuaW5nOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdzbScpXToge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGAke3RoZW1lLnBhbGV0dGUucGVuZGluZy5leHRyYUxpZ2h0fSAhaW1wb3J0YW50YFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgJyYgPiBkaXY6Zmlyc3QtY2hpbGQnOiB7XHJcbiAgICAgICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCdzbScpXToge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBgJHt0aGVtZS5wYWxldHRlLnBlbmRpbmcuZXh0cmFMaWdodH0gIWltcG9ydGFudGBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBib3hXcmFwcGVyOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdzbScpXToge1xyXG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcxMDBweCcsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUuY29tbW9uLnNlY29uZGFyeUJnQ29sb3IsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6ICcwcHggMjRweCAyNHB4J1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBpbWFnZVdyYXBwZXI6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbW1vbi5zZWNvbmRhcnlCZ0NvbG9yLFxyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnc20nKV06IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxyXG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206IDBcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgbGlua0xpc3Q6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ3NtJyldOiB7XHJcbiAgICAgICAgICAgIG1hcmdpblRvcDogMFxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSkpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXNlU3R5bGVzO1xyXG4iLCJpbXBvcnQgeyBCb3gsIExpbmsgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IFBsdXMsIEFyY2hpdmUsIEVkaXQgfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IFByb2dyYW1DYXJkIGZyb20gJy4uLy4uL1Byb2dyYW1DYXJkJztcclxuaW1wb3J0IE9iamVjdENhcmQgZnJvbSAnLi4vLi4vT2JqZWN0Q2FyZCc7XHJcblxyXG4vKipcclxuICogTmFtZTogRGFzaGJvYXJkWW91ckFwcGxpY2F0aW9uXHJcbiAqIERlc2M6IFJlbmRlciBEYXNoYm9hcmRZb3VyQXBwbGljYXRpb25cclxuICovXHJcblxyXG5jb25zdCBEYXNoYm9hcmRZb3VyQXBwbGljYXRpb24gPSAoKSA9PiB7XHJcbiAgICBjb25zdCBsaW5rQXJyYXkgPSBbXHJcbiAgICAgICAgeyB0ZXh0OiAnQXBwbHkgZm9yIG90aGVyIHByb2dyYW1zID4nLCBpY29uOiBQbHVzIH0sXHJcbiAgICAgICAgeyB0ZXh0OiAnVXBkYXRlIHlvdXIgZWxpZ2liaWxpdHkgaW5mbyA+JywgaWNvbjogRWRpdCB9LFxyXG4gICAgICAgIHsgdGV4dDogJ1ZpZXcgKDYpIGFyY2hpdmVkIGFwcGxpY2F0aW9ucyA+JywgaWNvbjogQXJjaGl2ZSB9XHJcbiAgICBdO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICA8Qm94IHBiPXs0LjV9PlxyXG4gICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAge3Byb2dyYW1OYW1lOidIb3VzaW5nIENob2ljZSBWb3VjaGVyJywgc3RhdHVzOlwiT24gV2FpdGxpc3RcIn0sXHJcbiAgICAgICAgICAgICAgICB7cHJvZ3JhbU5hbWU6J1Byb2dyYW0gTmFtZSAoMkJSKScsIHN0YXR1czpcIk9uIFdhaXRsaXN0XCJ9LFxyXG4gICAgICAgICAgICAgICAge3Byb2dyYW1OYW1lOidUYXlzICgxQlIpJywgc3RhdHVzOlwiT24gV2FpdGxpc3RcIn0sXHJcbiAgICAgICAgICAgICAgICB7cHJvZ3JhbU5hbWU6J1NpZXN0YSBHYXJkZW5zICgyQlIpJywgc3RhdHVzOlwiUGVuZGluZyBSZXZpZXdcIn0sXHJcbiAgICAgICAgICAgIF0ubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8Qm94IG1iPXszfSBrZXk9e2l0ZW0ucHJvZ3JhbU5hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxQcm9ncmFtQ2FyZCBcclxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cIndhaXRpbmdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93SW1hZ2U9e3RydWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHNob3dMZWZ0Qm9yZGVyPXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzaG93TGVmdEFycm93PXt0cnVlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5tYWluXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS5wcm9ncmFtTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudD1cImJvZHkxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LnJlZ3VsYXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLnN0YXR1c31cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qcm9ncmFtQ2FyZD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgbWI9ezN9XHJcbiAgICAgICAgICAgICAgICBib3JkZXJDb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICBib3JkZXI9XCIxcHggZGFzaGVkXCJcclxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1cz1cIjIxcHhcIj5cclxuICAgICAgICAgICAgICAgIDxPYmplY3RDYXJkIGNhcmRUeXBlPVwiYWN0aW9uQ2FyZFwiIGljb25OYW1lPVwicGx1c1wiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg2LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFN0YXJ0IGEgTmV3IFByZS1BcHBsaWNhdGlvblxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9PYmplY3RDYXJkPlxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICA8L0JveD5cclxuICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICB7bGlua0FycmF5Lm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPEJveCBtYj17Mn0ga2V5PXtpdGVtLnRleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPGl0ZW0uaWNvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPVwiMlwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJJbmRpZ29cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezE1fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtbD17MS41fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICApKX1cclxuICAgICAgICA8L0JveD5cclxuICAgICAgICBcclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGFzaGJvYXJkWW91ckFwcGxpY2F0aW9uXHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL0Rhc2hib2FyZFlvdXJBcHBsaWNhdGlvbiciLCJpbXBvcnQgeyBCb3gsIEJ1dHRvbiB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IHdpdGhXaWR0aCBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS93aXRoV2lkdGgnO1xyXG5pbXBvcnQgY2xzeCBmcm9tICdjbHN4JztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2hldnJvblJpZ2h0LCBEb3dubG9hZCB9IGZyb20gJ3JlYWN0LWZlYXRoZXInO1xyXG5pbXBvcnQgdXNlU3R5bGVzIGZyb20gJy4vWW91clZvdWNoZXJTdHlsZXMnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWUgOiBZb3VyVm91Y2hlclxyXG4gKiBEZXNjIDogWW91clZvdWNoZXJcclxuICovXHJcblxyXG5jb25zdCBZb3VyVm91Y2hlciA9ICh7IHdpZHRoIH0pID0+IHtcclxuICAgIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEJveCBjbGFzc05hbWU9e2NsYXNzZXMuZmxleH0gd2lkdGg9XCIxMDAlXCI+XHJcbiAgICAgICAgICAgIDxCb3ggd2lkdGg9XCIxMDAlXCI+XHJcbiAgICAgICAgICAgICAgICA8Qm94IHBiPXt3aWR0aCA9PT0gJ3hzJyB8fCB3aWR0aCA9PT0gJ3NtJyA/IDIgOiA2fT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs1fSBwdD17Mn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg2LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYj17MX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGNvbG9yPVwicHJpbWFyeS5saWdodFwiIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIEZpcnN0bmFtZSBMYXN0bmFtZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBiPXsxfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFZvdWNoZXIgTnVtYmVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGNvbG9yPVwicHJpbWFyeS5saWdodFwiIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFQxMjM0NTZcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17NX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg2LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYj17MX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBNYXhpbXVtIFVuaXQgU2l6ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cInByaW1hcnkubGlnaHRcIiBmb250U2l6ZT1cImg2LmZvbnRTaXplXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB1cCB0byBbWF0gYmVkcm9vbShzKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgVm91Y2hlciBFeHBpcmF0aW9uIERhdGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgW0RhdGUgb2YgRXhwaXJhdGlvbl1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggcHQ9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yOiAnSW5kaWdvJyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6ICcxNXB4J1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cIm1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibGlua0J0blwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZW5kSWNvbj17PENoZXZyb25SaWdodCBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezE0fSAvPn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgUmVxdWVzdCBhbiBFeHRlbnNpb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveCBjbGFzc05hbWU9e2NsYXNzZXMueHNCdG59PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoPXt3aWR0aCA9PT0gJ3hzJyB8fCB3aWR0aCA9PT0gJ3NtJyA/IHRydWUgOiBmYWxzZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbHN4KHdpZHRoID09PSAneHMnIHx8IHdpZHRoID09PSAnc20nID8gJ3NlbWlCb3JkZXInIDogJycpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBzdGFydEljb249ezxEb3dubG9hZCBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezIxfSBzdHJva2VXaWR0aD17M30gLz59PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBEb3dubG9hZCBWb3VjaGVyXHJcbiAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5cclxuWW91clZvdWNoZXIucHJvcFR5cGVzID0ge1xyXG4gICAgd2lkdGg6IFByb3BUeXBlcy5zdHJpbmdcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgd2l0aFdpZHRoKCkoWW91clZvdWNoZXIpO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgZmxleDoge1xyXG4gICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAgICBhbGlnbkl0ZW1zOiAnY2VudGVyJyxcclxuICAgICAgICBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWJldHdlZW4nLFxyXG4gICAgICAgIHBhZGRpbmc6ICcwIDk2cHgnLFxyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCdzbScpXToge1xyXG4gICAgICAgICAgICBmbGV4RGlyZWN0aW9uOiAnY29sdW1uJyxcclxuICAgICAgICAgICAgcGFkZGluZzogJzAgMCAzOHB4IDAnLFxyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOiAnZmxleC1zdGFydCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgeHNCdG46IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bignc20nKV06IHtcclxuICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgICAgICAgIGJvdHRvbTogJzAnLFxyXG4gICAgICAgICAgICBsZWZ0OiAnMCcsXHJcbiAgICAgICAgICAgIHJpZ2h0OiAnMCcsXHJcbiAgICAgICAgICAgIHdpZHRoOiAnMTAwJSdcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHVzZVN0eWxlcztcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vWW91clZvdWNoZXInO1xyXG4iLCJpbXBvcnQgeyBCb3gsIEJ1dHRvbiwgRGlhbG9nQ29udGVudCwgRGlhbG9nVGl0bGUsIEljb25CdXR0b24gfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBDbG9zZUljb24gZnJvbSAnQG1hdGVyaWFsLXVpL2ljb25zL0Nsb3NlJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuXHJcbi8qKlxyXG4gKiBOYW1lOiBFeGl0RGlhbG9nQm94XHJcbiAqIERlc2M6IFJlbmRlciBFeGl0RGlhbG9nQm94XHJcbiAqL1xyXG5cclxuY29uc3QgRXhpdERpYWxvZ0JveCA9ICh7IG9uQ29uZmlybSwgb25DbG9zZSB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgIDxEaWFsb2dUaXRsZSBpZD1cInNpbXBsZS1kaWFsb2ctdGl0bGVcIj5cclxuICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGFyaWEtbGFiZWw9XCJjbG9zZVwiIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxDbG9zZUljb24gLz5cclxuICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgPC9EaWFsb2dUaXRsZT5cclxuICAgICAgICAgICAgPERpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICA8Qm94IHRleHRBbGlnbj1cImNlbnRlclwiIHB0PXsyLjV9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoMy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYj17MX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFyZSB5b3Ugc3VyZSB5b3Ugd2FudCB0byBleGl0IGJlZm9yZSBmaW5pc2hpbmc/XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cImxnLmZvbnRTaXplXCIgY29sb3I9XCJwcmltYXJ5LmV4dHJhTGlnaHRcIiBtYj17M30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIEFueSBwcm9ncmVzcyB5b3XigJl2ZSBtYWRlIHdvbuKAmXQgYmUgc2F2ZWQgeWV0LlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIDwvRGlhbG9nQ29udGVudD5cclxuICAgICAgICAgICAgPEJveD5cclxuICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgICAgICBzaXplPVwibGFyZ2VcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZW1pQm9yZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgICBzdHlsZT17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDBcclxuICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ29uZmlybX0+XHJcbiAgICAgICAgICAgICAgICAgICAgWWVzLCBFeGl0IE5vd1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInNlbWlCb3JkZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9e29uQ2xvc2V9PlxyXG4gICAgICAgICAgICAgICAgICAgIE5vLCBLZWVwIEdvaW5nXHJcbiAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59O1xyXG5FeGl0RGlhbG9nQm94LnByb3BUeXBlcyA9IHtcclxuICAgIG9uQ29uZmlybTogUHJvcFR5cGVzLmZ1bmMsXHJcbiAgICBvbkNsb3NlOiBQcm9wVHlwZXMuZnVuY1xyXG59O1xyXG5leHBvcnQgZGVmYXVsdCBFeGl0RGlhbG9nQm94O1xyXG4iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9FeGl0RGlhbG9nQm94JztcclxuIiwiaW1wb3J0IHsgQm94LCBCdXR0b24sIEdyaWQsIExpbmsgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCB3aXRoV2lkdGggZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvd2l0aFdpZHRoJztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBDaGV2cm9uUmlnaHQgfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL0Zvb3RlclN0eWxlcyc7XHJcbi8qKlxyXG4gKiBOYW1lIDogRm9vdGVyXHJcbiAqIERlc2MgOiBSZW5kZXIgRm9vdGVyXHJcbiAqL1xyXG5cclxuY29uc3QgRm9vdGVyID0gKHsgd2lkdGggfSkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG5cclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEJveCBiZ2NvbG9yPVwicHJpbWFyeS5tYWluXCIgcHQ9ezd9IHBiPXsyfSBwcj17NH0gcGw9ezR9IGNsYXNzTmFtZT17Y2xhc3Nlcy5mb290ZXJXcmFwcGVyfT5cclxuICAgICAgICAgICAgPEdyaWQgY29udGFpbmVyIHNwYWNpbmc9ezh9PlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXszfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIHBiPXs0fSBjbGFzc05hbWU9e2NsYXNzZXMubG9nb1dyYXBwZXJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5sb2dvSW1hZ2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmbGV4PXt3aWR0aCA9PT0gJ3hzJyB8fCB3aWR0aCA9PT0gJ3NtJyA/ICcwIDAgNjNweCcgOiAnMCAwIDE2M3B4J30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2VcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzcmM9XCIvY2xpZW50TG9nby5zdmdcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoPXs4MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9ezgwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5pbWFnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiY29tbW9uLndoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cIm1kLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0ZXh0QWxpZ249XCJsZWZ0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuY29tcGFueVRleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEhBQ0VQXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImNvbW1vbi53aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNS5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGV4dEFsaWduPVwibGVmdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmxvZ29UZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBIb3VzaW5nIEF1dGhvcml0eSBvZiB0aGUgQ2l0eSBvZiBFbCBQYXNvXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG10PXszfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYj17M31cclxuICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImZsZXgtc3RhcnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMuY29tcGFueU5hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXg9e3dpZHRoID09PSAneHMnIHx8IHdpZHRoID09PSAnc20nID8gJzAgMCA0NicgOiAnbm9uZSd9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPVwiL2hvbWUuc3ZnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aWR0aD17d2lkdGggPT09ICd4cycgfHwgd2lkdGggPT09ICdzbScgPyA0NiA6IDQwfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodD17d2lkdGggPT09ICd4cycgfHwgd2lkdGggPT09ICdzbScgPyA0MyA6IDM3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggY29sb3I9XCJjb21tb24ud2hpdGVcIiBmb250U2l6ZT1cImg2LmZvbnRTaXplXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBXZeKAmXJlIGEgcHJvdWQgZXF1YWwgaG91c2luZyBvcHBvcnR1bml0eSBwcm92aWRlci5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBjbGFzc05hbWU9e2NsYXNzZXMubW9iaWxlTGlua3N9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHRleHQ6ICcgUHJpdmFjeSBQb2xpY3knIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0ZXh0OiAnVGVybXMgYW5kIENvbmRpdGlvbnMnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0ZXh0OiAnQWNjZXNzaWJpbGl0eScgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHRleHQ6ICdFcXVhbCBPcHBvcnR1bml0eScgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgXS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsxLjV9IGtleT17aXRlbS50ZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIiNcIiB1bmRlcmxpbmU9XCJub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZm9udFNpemU9XCJtZC5mb250U2l6ZVwiIGNvbG9yPVwiY29tbW9uLndoaXRlXCIgbXI9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uUmlnaHQgc3Ryb2tlV2lkdGg9XCIyXCIgY29sb3I9XCJ3aGl0ZVwiIHNpemU9ezE0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17M30gY2xhc3NOYW1lPXtjbGFzc2VzLmZvb3RlckdyaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJjb21tb24ud2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBiPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYj17M31cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnRpdGxlVGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIFZpc2l0IEhBQ0VQXHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17Mn0gZGlzcGxheT1cImZsZXhcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZm9udFNpemU9XCJsZy5mb250U2l6ZVwiIGNvbG9yPVwiY29tbW9uLndoaXRlXCIgbXI9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgTWFpbiBXZWJzaXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IHN0cm9rZVdpZHRoPVwiMlwiIGNvbG9yPVwid2hpdGVcIiBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cImxnLmZvbnRTaXplXCIgY29sb3I9XCJjb21tb24ud2hpdGVcIiBtcj17MX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDUzMDAgRS4gUGFpc2FubyBEcml2ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cImxnLmZvbnRTaXplXCIgY29sb3I9XCJjb21tb24ud2hpdGVcIiBtcj17MX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVsIFBhc28sIFRleGFzIDc5OTA1XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezJ9IG10PXs0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGggPT09ICd4cycgfHwgd2lkdGggPT09ICdzbScgfHwgd2lkdGggPT09ICdtZCdcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgID8gJ3NtYWxsJ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiAnbGFyZ2UnXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiaW5oZXJpdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdldCBEaXJlY3Rpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gbWQ9ezN9IGNsYXNzTmFtZT17Y2xhc3Nlcy5mb290ZXJHcmlkfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiY29tbW9uLndoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNS5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYj17MX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbWI9ezN9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy50aXRsZVRleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBHZXQgSGVscCAmIFN1cHBvcnRcclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0ZXh0OiAnSGVscCBDZW50ZXInIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHRleHQ6ICdDb250YWN0IFVzJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0ZXh0OiAnVEREICg5MTUpIDg0Ny0zNzM3JyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0ZXh0OiAnKDkxNSkgODQ5LTM3NDInIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgXS5tYXAoKGl0ZW0pID0+IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezJ9IGRpc3BsYXk9XCJmbGV4XCIga2V5PXtpdGVtLnRleHR9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cImxnLmZvbnRTaXplXCIgY29sb3I9XCJjb21tb24ud2hpdGVcIiBtcj17MX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25SaWdodCBzdHJva2VXaWR0aD1cIjJcIiBjb2xvcj1cIndoaXRlXCIgc2l6ZT17MTR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17M30gY2xhc3NOYW1lPXtjbGFzc2VzLmZvb3RlckdyaWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJjb21tb24ud2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBiPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYj17M31cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnRpdGxlVGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIExlZ2FsIEluZm9ybWF0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge1tcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdGV4dDogJ0VxdWFsIEhvdXNpbmcgT3Bwb3J0dW5pdHknIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHRleHQ6ICdBY2Nlc3NpYmlsaXR5JyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0ZXh0OiAnTm9uLURpc2NyaW1pbmF0aW9uJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0ZXh0OiAnUHJpdmFjeSAmIFRlcm1zIG9mIFVzZScgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBdLm1hcCgoaXRlbSkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17Mn0gZGlzcGxheT1cImZsZXhcIiBrZXk9e2l0ZW0udGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmsgaHJlZj1cIiNcIiB1bmRlcmxpbmU9XCJub25lXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGZvbnRTaXplPVwibGcuZm9udFNpemVcIiBjb2xvcj1cImNvbW1vbi53aGl0ZVwiIG1yPXsxfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IHN0cm9rZVdpZHRoPVwiMlwiIGNvbG9yPVwid2hpdGVcIiBzaXplPXsxNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5Gb290ZXIucHJvcFR5cGVzID0ge1xyXG4gICAgd2lkdGg6IFByb3BUeXBlcy5zdHJpbmdcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgd2l0aFdpZHRoKCkoRm9vdGVyKTtcclxuIiwiaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICAgIGZvb3RlcldyYXBwZXI6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ2xnJyldOiB7XHJcbiAgICAgICAgICAgIHBhZGRpbmc6ICc3MnB4IDcycHggNTZweCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdGl0bGVUZXh0OiB7XHJcbiAgICAgICAgYm9yZGVyQm90dG9tOiBgMnB4IHNvbGlkICR7dGhlbWUucGFsZXR0ZS5wcmltYXJ5LmV4dHJhTGlnaHR9YFxyXG4gICAgfSxcclxuICAgIGZvb3RlckdyaWQ6IHtcclxuICAgICAgICBkaXNwbGF5OiAnbm9uZScsXHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdtZCcpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnJiAuTXVpTGluay1yb290Jzp7XHJcbiAgICAgICAgICAgICcmOmhvdmVyJzoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHRoZW1lLnBhbGV0dGUuc3VjY2Vzcy5saWdodFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGxvZ29XcmFwcGVyOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLmRvd24oJ21kJyldOiB7XHJcbiAgICAgICAgICAgIGJvcmRlckJvdHRvbTogYDJweCBzb2xpZCAke3RoZW1lLnBhbGV0dGUucHJpbWFyeS5leHRyYUxpZ2h0fWBcclxuICAgICAgICB9LFxyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnbWQnKV06IHtcclxuICAgICAgICAgICAgZmxleERpcmVjdGlvbjogJ2NvbHVtbicsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6IDAsXHJcbiAgICAgICAgICAgIGJvcmRlcjogMFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBsb2dvVGV4dDoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnbWQnKV06IHtcclxuICAgICAgICAgICAgZm9udFNpemU6IHRoZW1lLnR5cG9ncmFwaHkuaDQuZm9udFNpemUsXHJcbiAgICAgICAgICAgIHRleHRBbGlnbjogJ2NlbnRlcicsXHJcbiAgICAgICAgICAgIG1heFdpZHRoOiAnMjkwcHgnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGxvZ29JbWFnZToge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnbWQnKV06IHtcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMjRweCcsXHJcbiAgICAgICAgICAgICcmID4gZGl2Jzoge1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luUmlnaHQ6IDAsXHJcbiAgICAgICAgICAgICAgICAnJiA+IGRpdiAnOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJyYgPiBpbWcnOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzEzMHB4JyxcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg6ICcxMzBweCdcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCdzbScpXToge1xyXG4gICAgICAgICAgICAnJiA+IGRpdic6IHtcclxuICAgICAgICAgICAgICAgICcmID4gZGl2ICc6IHtcclxuICAgICAgICAgICAgICAgICAgICAnJiA+IGltZyc6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAnNjZweCcsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoOiAnNjNweCdcclxuICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgY29tcGFueVRleHQ6IHtcclxuICAgICAgICBmb250U3R5bGU6ICdpdGFsaWMnLFxyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnbWQnKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ25vbmUnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIG1vYmlsZUxpbmtzOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdtZCcpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnbm9uZSdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgY29tcGFueU5hbWU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ21kJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdub25lJ1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSkpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXNlU3R5bGVzO1xyXG4iLCJpbXBvcnQgeyBCb3ggfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBJbWFnZSBmcm9tICduZXh0L2ltYWdlJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL1N1YkZvb3RlclN0eWxlcyc7XHJcblxyXG4vKipcclxuICogTmFtZSA6IFN1YkZvb3RlclxyXG4gKiBEZXNjIDogUmVuZGVyIFN1YkZvb3RlclxyXG4gKi9cclxuXHJcbmNvbnN0IFN1YkZvb3RlciA9ICgpID0+IHtcclxuICAgIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3ggYmdjb2xvcj1cImJ1dHRvbi5zZWNvbmRhcnlDb2xvclwiIHA9ezN9IGNsYXNzTmFtZT17Y2xhc3Nlcy5zdWJGb290ZXJXcmFwcGVyfT5cclxuICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBqdXN0aWZ5Q29udGVudD1cInNwYWNlLWJldHdlZW5cIiBmbGV4V3JhcD1cIndyYXBcIj5cclxuICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cIm5vbmVcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIgY2xhc3NOYW1lPXtjbGFzc2VzLmNvbXBhbnlOYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIiBtcj17Mn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaG9tZS5zdmdcIiB3aWR0aD17NDB9IGhlaWdodD17Mzd9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cImNvbW1vbi53aGl0ZVwiIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgV2XigJlyZSBhIHByb3VkIGVxdWFsIGhvdXNpbmcgb3Bwb3J0dW5pdHkgcHJvdmlkZXIuXHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImZsZXgtc3RhcnRcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb249XCJjb2x1bW5cIlxyXG4gICAgICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ9XCIyOHB4XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMucG93ZXJlZEJ5VGV4dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cImNvbW1vbi53aGl0ZVwiIGZvbnRTaXplPVwibWQuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgwqkyMDIxIEhvdXNpbmcgQXV0aG9yaXR5IG9mIHRoZSBDaXR5IG9mIEVsIFBhc29cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJjb21tb24ud2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cIm1kLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGw9ezAuOH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgcHI9ezAuOH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmJyZWFrZXJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB8XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cImNvbW1vbi53aGl0ZVwiIGZvbnRTaXplPVwibWQuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgUG93ZXJlZCBieSBBcHBOYW1lXHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgU3ViRm9vdGVyO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgY29tcGFueU5hbWU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ21kJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdmbGV4JyxcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnOHB4J1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBzdWJGb290ZXJXcmFwcGVyOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdtZCcpXToge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAnMjBweCA1NnB4IDEycHggNTZweCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgcG93ZXJlZEJ5VGV4dDoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnbWQnKV06IHtcclxuICAgICAgICAgICAgZmxleERpcmVjdGlvbjogJ3JvdycsXHJcbiAgICAgICAgICAgIGFsaWduSXRlbXM6ICdjZW50ZXInLFxyXG4gICAgICAgICAgICBsaW5lSGVpZ2h0OiAnbm9ybWFsJyxcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnOHB4J1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBicmVha2VyOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdtZCcpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnZmxleCdcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHVzZVN0eWxlcztcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vU3ViRm9vdGVyJztcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vRm9vdGVyJztcclxuIiwiaW1wb3J0IHsgQm94LCBCdXR0b24sIEljb25CdXR0b24sIExpbmsgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBCYWRnZSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9CYWRnZSc7XHJcbmltcG9ydCB1c2VNZWRpYVF1ZXJ5IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3VzZU1lZGlhUXVlcnknO1xyXG5pbXBvcnQgY2xzeCBmcm9tICdjbHN4JztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgUm91dGVyIGZyb20gJ25leHQvcm91dGVyJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBCZWxsLCBDaGV2cm9uTGVmdCwgTWVudSB9IGZyb20gJ3JlYWN0LWZlYXRoZXInO1xyXG5pbXBvcnQgTG9nb0hlYWRpbmcgZnJvbSAnc2hhcmVkL2NvbXBvbmVudHMvTG9nb0hlYWRpbmcnO1xyXG5pbXBvcnQgTW9iaWxlTWVudSBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0hlYWRlci9Nb2JpbGVNZW51JztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnfi9zaGFyZWQvY29uc3RhbnRzL3JvdXRlc0NvbnN0YW50cyc7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi9NYWluSGVhZGVyU3R5bGVzJztcclxuXHJcbi8qKlxyXG4gKiBOYW1lOiBNYWluSGVhZGVyXHJcbiAqIERlc2M6IFJlbmRlciBNYWluSGVhZGVyXHJcbiAqIEBwYXJhbSAge2Jvb2x9ICBpc0xvZ2dlZEluXHJcbiAqL1xyXG5cclxuY29uc3QgTWFpbkhlYWRlciA9ICh7XHJcbiAgICBpc0xvZ2dlZEluLFxyXG4gICAgdXNlck5hbWUsXHJcbiAgICBoZWFkZXJTdWJ0aXRsZSxcclxuICAgIHNob3dCYWNrQnRuLFxyXG4gICAgbW9iaWxlVGl0bGUsXHJcbiAgICB0aXRsZSxcclxuICAgIGxhYmVsTmFtZSxcclxuICAgIHNob3dNb2JpbGVNZW51XHJcbn0pID0+IHtcclxuICAgIGNvbnN0IFttZW51VHlwZSwgc2V0TWVudVR5cGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3Qgc2hvd01lbnVCYXIgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0TWVudVR5cGUodHJ1ZSk7XHJcbiAgICB9O1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgYnJlYWtQb2ludCA9IHVzZU1lZGlhUXVlcnkoJyhtaW4td2lkdGg6MTE1MnB4KScpO1xyXG4gICAgY29uc3QgY29sb3IgPSBpc0xvZ2dlZEluID8gJ2NvbW1vbi53aGl0ZScgOiAncHJpbWFyeS5saWdodCc7XHJcbiAgICBjb25zdCBidXR0b25Db2xvciA9IGlzTG9nZ2VkSW4gPyAnc2Vjb25kYXJ5JyA6ICdwcmltYXJ5JztcclxuICAgIGNvbnN0IGJ1dHRvblRpdGxlID0gaXNMb2dnZWRJbiA/ICdIZWxwIENlbnRlcicgOiAnTG9nIEluJztcclxuICAgIGNvbnN0IGxpbmtOYW1lQXJyYXkgPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBsaW5rTmFtZTogJ1Byb2dyYW1zJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBsaW5rTmFtZTogJ0hlbHAgQ2VudGVyJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBsaW5rTmFtZTogJ0dldCBTdGFydGVkJ1xyXG4gICAgICAgIH1cclxuICAgIF07XHJcblxyXG4gICAgY29uc3QgY29udGludWVUb0xvZ2luID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgVVNFUl9MT0dJTiB9ID0gUk9VVEVTO1xyXG4gICAgICAgIFJvdXRlci5wdXNoKFVTRVJfTE9HSU4uUk9VVEUpO1xyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3hcclxuICAgICAgICAgICAgcGFkZGluZz17M31cclxuICAgICAgICAgICAgYmdjb2xvcj1cImNvbW1vbi53aGl0ZVwiXHJcbiAgICAgICAgICAgIGJveFNoYWRvdz17Mn1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbHN4KGlzTG9nZ2VkSW4gJiYgY2xhc3Nlcy5tYWluSGVhZGVyV3JhcHBlcil9PlxyXG4gICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3Nob3dCYWNrQnRuIHx8IHNob3dNb2JpbGVNZW51ID8gY2xhc3Nlcy5kaXNwbGF5Tm9uZVhzIDogJyd9PlxyXG4gICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIG1yPXticmVha1BvaW50ID8gMiA6IDB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJub25lXCIgY2xhc3NOYW1lPXtjbGFzc2VzLmxvZ29JbWFnZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2xvZ28uc3ZnXCIgd2lkdGg9ezY2fSBoZWlnaHQ9ezYzfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PXticmVha1BvaW50ID8gJ25vbmUnIDogJ2ZsZXgnfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshc2hvd0JhY2tCdG4gPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b24gY2xhc3NOYW1lPXtjbGFzc2VzLm1lbnVCdXR0b259IG9uQ2xpY2s9e3Nob3dNZW51QmFyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnUgc3Ryb2tlV2lkdGg9XCIyXCIgY29sb3I9XCJJbmRpZ29cIiBzaXplPXszMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGNsYXNzTmFtZT17Y2xhc3Nlcy5tZW51QnV0dG9ufSBvbkNsaWNrPXtzaG93TWVudUJhcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51IHN0cm9rZVdpZHRoPVwiMlwiIGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPExvZ29IZWFkaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXt0aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWxOYW1lPXtsYWJlbE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49e2lzTG9nZ2VkSW59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrUG9pbnQ9e2JyZWFrUG9pbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBwbD17YnJlYWtQb2ludCA/IDMgOiAwfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1yPXtpc0xvZ2dlZEluID8gNSA6IDkuNX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmxpbmtXcmFwcGVyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xpbmtOYW1lQXJyYXkubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5saW5rTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17aW5kZXggIT09IGxpbmtOYW1lQXJyYXkubGVuZ3RoIC0gMSAmJiA4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhXcmFwPVwid3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg2LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj17Y29sb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMubGlua05hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubGlua05hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgeyFpc0xvZ2dlZEluIHx8IGJyZWFrUG9pbnQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbnRpbnVlVG9Mb2dpbigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17YnJlYWtQb2ludCA/ICdsYXJnZScgOiAnc21hbGwnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e2J1dHRvbkNvbG9yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2J1dHRvblRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICB7aXNMb2dnZWRJbiA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtbD17M30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgYmFkZ2VDb250ZW50PXs0fSBjb2xvcj1cImVycm9yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJlbGwgc3Ryb2tlV2lkdGg9XCIzXCIgY29sb3I9XCJ3aGl0ZVwiIHNpemU9ezI2fSBmaWxsPVwid2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIHt1c2VyTmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb249XCJjb2x1bW5cIlxyXG4gICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcHQ9e2JyZWFrUG9pbnQgPyA1IDogMX1cclxuICAgICAgICAgICAgICAgICAgICBwYj17YnJlYWtQb2ludCA/IDUgOiAxMH1cclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImNvbW1vbi53aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzaG93QmFja0J0biA/IGNsYXNzZXMuZGlzcGxheU5vbmVYcyA6ICcnfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ9XCI3MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT17YnJlYWtQb2ludCA/ICdoMS5mb250U2l6ZScgOiAnaDMuZm9udFNpemUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlck5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT17YnJlYWtQb2ludCA/ICdoNS5mb250U2l6ZScgOiAnaDYuZm9udFNpemUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0PXticmVha1BvaW50ID8gJzM1cHgnIDogJzI2cHgnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImNvbW1vbi53aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heFdpZHRoPVwiNTYwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW49XCIwIGF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2hlYWRlclN1YnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7KHNob3dCYWNrQnRuIHx8IHNob3dNb2JpbGVNZW51KSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17c2hvd0JhY2tCdG4gfHwgc2hvd01vYmlsZU1lbnUgPyBjbGFzc2VzLmRpc3BsYXlCbG9ja1hzIDogJyd9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGNsYXNzTmFtZT17Y2xhc3Nlcy5tZW51QnV0dG9ufSBvbkNsaWNrPXtzaG93TWVudUJhcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93QmFja0J0biA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uTGVmdCBzdHJva2VXaWR0aD1cIjJcIiBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnUgc3Ryb2tlV2lkdGg9XCIyXCIgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg0LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuZXh0cmFCb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e2NvbG9yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvdmVyZmxvdz1cImhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoaXRlU3BhY2U9XCJub3dyYXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhXaWR0aD1cIjM1MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dE92ZXJmbG93PVwiZWxsaXBzaXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nTGVmdD17Mi40fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bW9iaWxlVGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge21lbnVUeXBlICYmIDxNb2JpbGVNZW51IGJlZm9yZUxvZ2luPXtmYWxzZX0gc2V0TWVudVR5cGU9e3NldE1lbnVUeXBlfSAvPn1cclxuICAgICAgICA8L0JveD5cclxuICAgICk7XHJcbn07XHJcblxyXG5NYWluSGVhZGVyLmRlZmF1bHRQcm9wcyA9IHtcclxuICAgIHNob3dCYWNrQnRuOiBmYWxzZSxcclxuICAgIG1vYmlsZVRpdGxlOiAnICcsXHJcbiAgICB0aXRsZTogJ0FwcE5hbWUnLFxyXG4gICAgbGFiZWxOYW1lOiAnRUwgUEFTTydcclxufTtcclxuTWFpbkhlYWRlci5wcm9wVHlwZXMgPSB7XHJcbiAgICBpc0xvZ2dlZEluOiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIHVzZXJOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgaGVhZGVyU3VidGl0bGU6IFByb3BUeXBlcy5zdHJpbmcsXHJcbiAgICBzaG93QmFja0J0bjogUHJvcFR5cGVzLmJvb2wsXHJcbiAgICBtb2JpbGVUaXRsZTogUHJvcFR5cGVzLnN0cmluZyxcclxuICAgIHRpdGxlOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgbGFiZWxOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgc2hvd01vYmlsZU1lbnU6IFByb3BUeXBlcy5ib29sXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNYWluSGVhZGVyO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgbWFpbkhlYWRlcldyYXBwZXI6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6ICd1cmwoL2hlYWRlckJnLnN2ZyknLFxyXG4gICAgICAgIGJhY2tncm91bmRSZXBlYXQ6ICduby1yZXBlYXQnLFxyXG4gICAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogJ2NlbnRlcicsXHJcbiAgICAgICAgYmFja2dyb3VuZFNpemU6ICdjb3ZlcicsXHJcbiAgICAgICAgYm9yZGVyQm90dG9tTGVmdFJhZGl1czogdGhlbWUuc3BhY2luZygyLjYzKSxcclxuICAgICAgICBib3JkZXJCb3R0b21SaWdodFJhZGl1czogdGhlbWUuc3BhY2luZygyLjYzKVxyXG4gICAgfSxcclxuICAgIGxvZ29JbWFnZToge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnbGcnKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBsaW5rV3JhcHBlcjoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnbGcnKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIG1lbnVCdXR0b246IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbW1vbi53aGl0ZSxcclxuICAgICAgICAnJjpob3Zlcic6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb21tb24ud2hpdGVcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgbGlua05hbWU6IHtcclxuICAgICAgICAnJjpob3Zlcic6IHtcclxuICAgICAgICAgICAgY29sb3I6IHRoZW1lLnBhbGV0dGUuc3VjY2Vzcy5saWdodFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBsYWJlbE5hbWU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ2xnJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaydcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdGl0bGU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ2xnJyldOiB7XHJcbiAgICAgICAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5LmgyLmZvbnRTaXplXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGRpc3BsYXlCbG9ja1hzOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdsZycpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnbm9uZSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGRpc3BsYXk6ICdmbGV4J1xyXG4gICAgfSxcclxuICAgIGRpc3BsYXlOb25lWHM6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bignbWQnKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ25vbmUnXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL01haW5IZWFkZXInO1xyXG4iLCJpbXBvcnQgeyBCb3gsIEJ1dHRvbiwgSWNvbkJ1dHRvbiwgTGluayB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IGNsc3ggZnJvbSAnY2xzeCc7XHJcbmltcG9ydCBJbWFnZSBmcm9tICduZXh0L2ltYWdlJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBDaGV2cm9uUmlnaHQsIFggfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IHtcclxuICAgIGFmdGVyTG9naW5QYWdlc0xpbmtBcnJheSxcclxuICAgIGJlZm9yZUxvZ2luTGlua0FycmF5LFxyXG4gICAgYmVmb3JlTG9naW5QYWdlc0xpbmtBcnJheSxcclxuICAgIGxpbmtBcnJheVxyXG59IGZyb20gJy4vTW9iaWxlTWVudUNvbnN0YW50JztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL01vYmlsZU1lbnVTdHlsZXMnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWU6IE1vYmlsZU1lbnVcclxuICogRGVzYzogUmVuZGVyIE1vYmlsZU1lbnVcclxuICovXHJcblxyXG5jb25zdCBNb2JpbGVNZW51ID0gKHsgYmVmb3JlTG9naW4sIHNldE1lbnVUeXBlIH0pID0+IHtcclxuICAgIGNvbnN0IFtvcGVuTW9iaWxlTWVudSwgc2V0T3Blbk1vYmlsZU1lbnVdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcblxyXG4gICAgY29uc3QgbGlua3MgPSBiZWZvcmVMb2dpbiA/IGJlZm9yZUxvZ2luTGlua0FycmF5IDogbGlua0FycmF5O1xyXG4gICAgY29uc3QgYWN0aW9uTGlua3MgPSBiZWZvcmVMb2dpbiA/IGJlZm9yZUxvZ2luUGFnZXNMaW5rQXJyYXkgOiBhZnRlckxvZ2luUGFnZXNMaW5rQXJyYXk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICB7b3Blbk1vYmlsZU1lbnUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xzeChcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3Nlcy5sb2dpbldyYXBwZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJlZm9yZUxvZ2luICYmIGNsYXNzZXMuYmVmb3JlTG9naW5XcmFwcGVyXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICBwPXszfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgbWI9ezExfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5tZW51QnV0dG9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE9wZW5Nb2JpbGVNZW51KGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRNZW51VHlwZShmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHN0cm9rZVdpZHRoPVwiM1wiIGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWN0aW9uTGlua3MubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXszLjV9IGtleT17aXRlbS50ZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHVuZGVybGluZT1cIm5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpdGVtLmljb24gc3Ryb2tlV2lkdGg9XCIyXCIgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImgzLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWw9ezEuNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAge2JlZm9yZUxvZ2luICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtdD17MS41fSBtYj17Nn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJsYXJnZVwiIGNvbG9yPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMb2cgSW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5rcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIga2V5PXtpbmRleH0gbWI9ezAuNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Nsc3goJ2xpbmtCdG4nLCBjbGFzc2VzLmN1c3RvbUJ1dHRvbil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJtZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmRJY29uPXs8Q2hldnJvblJpZ2h0IGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MTd9IC8+fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubGlua05hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbj1cImZpeGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQ9XCItMTBweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleD1cIi0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJlZm9yZUxvZ2luID8gY2xhc3Nlcy50b3BJbWFnZVBvc2l0aW9uIDogY2xhc3Nlcy5ib3R0b21JbWFnZVBvc2l0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPVwiL2NsaWVudExvZ28uc3ZnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoPXsxNjB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9ezE2MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5pbWFnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufTtcclxuTW9iaWxlTWVudS5wcm9wVHlwZXMgPSB7XHJcbiAgICBiZWZvcmVMb2dpbjogUHJvcFR5cGVzLmJvb2wsXHJcbiAgICBzZXRNZW51VHlwZTogUHJvcFR5cGVzLmZ1bmNcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgTW9iaWxlTWVudTtcclxuIiwiaW1wb3J0IHsgRmlsZVRleHQsIEhlbHBDaXJjbGUsIEhvbWUsIFNlbmQsIFVzZXIgfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuZXhwb3J0IGNvbnN0IGJlZm9yZUxvZ2luTGlua0FycmF5ID0gW1xyXG4gICAge1xyXG4gICAgICAgIGxpbmtOYW1lOiAnQWJvdXQgSEFDRVAnXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIGxpbmtOYW1lOiAnTGFuZGxvcmQgUG9ydGFsJ1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBsaW5rTmFtZTogJ0xvZyBPdXQnXHJcbiAgICB9XHJcbl07XHJcblxyXG5leHBvcnQgY29uc3QgbGlua0FycmF5ID0gW1xyXG4gICAge1xyXG4gICAgICAgIGxpbmtOYW1lOiAnRXNwYcOxb2wnXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIGxpbmtOYW1lOiAnTG9nIE91dCdcclxuICAgIH1cclxuXTtcclxuZXhwb3J0IGNvbnN0IGFmdGVyTG9naW5QYWdlc0xpbmtBcnJheSA9IFtcclxuICAgIHsgdGV4dDogJ1lvdXIgRGFzaGJvYXJkJywgaWNvbjogSG9tZSB9LFxyXG4gICAgeyB0ZXh0OiAnWW91ciBBcHBsaWNhdGlvbnMnLCBpY29uOiBGaWxlVGV4dCB9LFxyXG4gICAgeyB0ZXh0OiAnWW91ciBBY2NvdW50JywgaWNvbjogVXNlciB9LFxyXG4gICAgeyB0ZXh0OiAnSGVscCBDZW50ZXInLCBpY29uOiBIZWxwQ2lyY2xlIH1cclxuXTtcclxuZXhwb3J0IGNvbnN0IGJlZm9yZUxvZ2luUGFnZXNMaW5rQXJyYXkgPSBbXHJcbiAgICB7IHRleHQ6ICdIb21lJywgaWNvbjogSG9tZSB9LFxyXG4gICAgeyB0ZXh0OiAnR2V0IFN0YXJ0ZWQnLCBpY29uOiBTZW5kIH0sXHJcbiAgICB7IHRleHQ6ICdPdXIgUHJvZ3JhbXMnLCBpY29uOiBGaWxlVGV4dCB9LFxyXG4gICAgeyB0ZXh0OiAnSGVscCBDZW50ZXInLCBpY29uOiBIZWxwQ2lyY2xlIH1cclxuXTtcclxuIiwiaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICAgIGxvZ2luV3JhcHBlcjoge1xyXG4gICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxyXG4gICAgICAgIGxlZnQ6IDAsXHJcbiAgICAgICAgcmlnaHQ6IDAsXHJcbiAgICAgICAgdG9wOiAwLFxyXG4gICAgICAgIGJvdHRvbTogMCxcclxuICAgICAgICB3aWR0aDogJzEwMCUnLFxyXG4gICAgICAgIGhlaWdodDogJzEwMHZoJyxcclxuICAgICAgICB6SW5kZXg6ICc5OTk5OScsXHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLm1lbnVzLm1lbnVCYWNrZ3JvdW5kXHJcbiAgICB9LFxyXG4gICAgYmVmb3JlTG9naW5XcmFwcGVyOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLmNvbW1vbi53aGl0ZVxyXG4gICAgfSxcclxuICAgIG1lbnVCdXR0b246IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbW1vbi53aGl0ZVxyXG4gICAgfSxcclxuICAgIHRvcEltYWdlUG9zaXRpb246IHtcclxuICAgICAgICB0b3A6ICc0MHB4J1xyXG4gICAgfSxcclxuICAgIGJvdHRvbUltYWdlUG9zaXRpb246IHtcclxuICAgICAgICBib3R0b206ICczMHB4J1xyXG4gICAgfSxcclxuICAgIGN1c3RvbUJ1dHRvbjoge1xyXG4gICAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5Lmg2LmZvbnRTaXplLFxyXG4gICAgICAgIGNvbG9yOiB0aGVtZS5wYWxldHRlLnByaW1hcnkubWFpblxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL01vYmlsZU1lbnUnO1xyXG4iLCJpbXBvcnQgeyBCb3gsIEljb25CdXR0b24sIExpbmssIERpYWxvZyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IHVzZU1lZGlhUXVlcnkgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvdXNlTWVkaWFRdWVyeSc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2hldnJvbkxlZnQsIFggfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL1RvcEhlYWRlclN0eWxlcyc7XHJcbmltcG9ydCBFeGl0RGlhbG9nQm94IGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvRXhpdERpYWxvZ0JveCc7XHJcblxyXG4vKipcclxuICogTmFtZTogVG9wSGVhZGVyXHJcbiAqIERlc2M6IFJlbmRlciBUb3BIZWFkZXJcclxuICogQHBhcmFtICB7Ym9vbH0gIGlzV2l6YXJkXHJcbiAqL1xyXG5cclxuXHJcbmNvbnN0IFRvcEhlYWRlciA9ICh7IGlzV2l6YXJkLCBvbkNsaWNrQmFjaywgb25FeGl0Q2xpY2ssIHRpdGxlPScnfSkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgYnJlYWtQb2ludCA9IHVzZU1lZGlhUXVlcnkoJyhtaW4td2lkdGg6MTE1MnB4KScpO1xyXG4gICAgY29uc3QgbGlua05hbWVBcnJheSA9IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGxpbmtOYW1lOiAnRXNwYcOxb2wnXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGxpbmtOYW1lOiAnQWJvdXQnXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGxpbmtOYW1lOiAnTGFuZGxvcmQgUG9ydGFsJ1xyXG4gICAgICAgIH1cclxuICAgIF07XHJcblxyXG4gICAgY29uc3QgW29wZW5EaWFsb2csIHNldE9wZW5EaWFsb2ddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgaGFuZGxlQ2xvc2UgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0T3BlbkRpYWxvZyhmYWxzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgIHB0PXsxfVxyXG4gICAgICAgICAgICBwcj17YnJlYWtQb2ludCA/IDYgOiAxfVxyXG4gICAgICAgICAgICBwYj17MX1cclxuICAgICAgICAgICAgcGw9e2JyZWFrUG9pbnQgPyA2IDogM31cclxuICAgICAgICAgICAgYmdjb2xvcj1cIm1lbnVzLm1lbnVCYWNrZ3JvdW5kXCI+XHJcbiAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIG1heFdpZHRoPXs3NTB9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtpc1dpemFyZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbXI9ezAuNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrQmFja30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25MZWZ0IHN0cm9rZVdpZHRoPVwiMlwiIGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MjJ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT17MTV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ9XCIyMXB4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgdGl0bGUgPyB0aXRsZSA6ICdIb3VzaW5nIEFzc2lzdGFuY2UgRWxpZ2libGl0eSBhbmQgUHJlQXBwbGljYXRpb24nIH1cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb249XCJyZWxhdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdG9wPVwiLTEwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9eyFicmVha1BvaW50ID8gJ2ZsZXgnIDogJ25vbmUnfT5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFggc3Ryb2tlV2lkdGg9XCIzXCIgY29sb3I9XCJCbGFja1wiIHNpemU9ezE1fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveCBhbGlnbkl0ZW1zPVwiY2VudGVyXCIgZGlzcGxheT17YnJlYWtQb2ludCA/ICdmbGV4JyA6ICdub25lJ30+XHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc1dpemFyZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBjbGFzc05hbWU9e2NsYXNzZXMubGlua30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvXCIgdW5kZXJsaW5lPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cImJvZHk1LmZvbnRTaXplXCIgY29sb3I9XCJidXR0b24uc2Vjb25kYXJ5Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDQU5DRUwgQVBQTElDQVRJT05cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBjbGFzc05hbWU9e2NsYXNzZXMubGlua30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE9wZW5EaWFsb2codHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cImJvZHk1LmZvbnRTaXplXCIgY29sb3I9XCJidXR0b24uc2Vjb25kYXJ5Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTQVZFIEFORCBFWElUXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEaWFsb2dcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWxsZWRieT1cInNpbXBsZS1kaWFsb2ctdGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGVuPXtvcGVuRGlhbG9nfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV4aXREaWFsb2dCb3ggb25DbG9zZT17aGFuZGxlQ2xvc2V9IG9uQ29uZmlybT17b25FeGl0Q2xpY2t9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9EaWFsb2c+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xpbmtOYW1lQXJyYXkubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3gga2V5PXtpdGVtLmxpbmtOYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZm9udFNpemU9XCJib2R5NS5mb250U2l6ZVwiIGNvbG9yPVwiYnV0dG9uLnNlY29uZGFyeUNvbG9yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxpbmtOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgKTtcclxufTtcclxuVG9wSGVhZGVyLmRlZmF1bHRQcm9wcyA9IHtcclxuICAgIGlzV2l6YXJkOiBmYWxzZSxcclxuICAgIHRpdGxlOiBudWxsLFxyXG4gICAgb25DbGlja0JhY2s6IFByb3BUeXBlcy5mdW5jLFxyXG59O1xyXG5Ub3BIZWFkZXIucHJvcFR5cGVzID0ge1xyXG4gICAgaXNXaXphcmQ6IFByb3BUeXBlcy5ib29sLFxyXG4gICAgb25DbGlja0JhY2s6IFByb3BUeXBlcy5mdW5jLFxyXG4gICAgb25FeGl0Q2xpY2s6IFByb3BUeXBlcy5mdW5jLFxyXG4gICAgdGl0bGU6IFByb3BUeXBlcy5zdHJpbmdcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgVG9wSGVhZGVyO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgbGluazoge1xyXG4gICAgICAgICcmOm5vdCg6bGFzdC1jaGlsZCknOiB7XHJcbiAgICAgICAgICAgIG1hcmdpblJpZ2h0OnRoZW1lLnNwYWNpbmcoNiksXHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxyXG4gICAgICAgICAgICAnJjo6YWZ0ZXInOiB7XHJcbiAgICAgICAgICAgICAgICBjb250ZW50OiBcIid8J1wiLFxyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgICAgICAgICAgICByaWdodDogJy0yNnB4JyxcclxuICAgICAgICAgICAgICAgIHRvcDogMCxcclxuICAgICAgICAgICAgICAgIGJvdHRvbTogMCxcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAnaW5oZXJpdCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSkpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXNlU3R5bGVzO1xyXG4iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9Ub3BIZWFkZXInO1xyXG4iLCJpbXBvcnQgeyBCb3gsIEJ1dHRvbiB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IHdpdGhXaWR0aCBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS93aXRoV2lkdGgnO1xyXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWU6IEhlbHBDZW50ZXJcclxuICogRGVzYzogUmVuZGVyIEhlbHBDZW50ZXJcclxuICovXHJcblxyXG5jb25zdCBIZWxwQ2VudGVyID0gKHsgd2lkdGggfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgIG1pbkhlaWdodD17d2lkdGggPT09ICd4cycgfHwgd2lkdGggPT09ICdzbScgPyAyNzcgOiAzNTV9XHJcbiAgICAgICAgICAgIHdpZHRoPVwiMTAwJVwiXHJcbiAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwiY2VudGVyXCJcclxuICAgICAgICAgICAgZmxleERpcmVjdGlvbj1cImNvbHVtblwiXHJcbiAgICAgICAgICAgIHRleHRBbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgICAgIGJnY29sb3I9XCJtZW51cy5tZW51QmFja2dyb3VuZFwiXHJcbiAgICAgICAgICAgIHBsPXszfVxyXG4gICAgICAgICAgICBwcj17M31cclxuICAgICAgICAgICAgcHk9ezV9PlxyXG4gICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU9e3dpZHRoID09PSAneHMnIHx8IHdpZHRoID09PSAnc20nID8gJ2g1LmZvbnRTaXplJyA6ICdoMy5mb250U2l6ZSd9XHJcbiAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5zZW1pQm9sZFwiPlxyXG4gICAgICAgICAgICAgICAgR2V0dGluZyBob3VzaW5nIGFzc2lzdGFuY2UgY2FuIGJlIGEgdG91Z2ggcHJvY2Vzcy5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIDxCb3ggY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCIgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiIHB0PXsyfSBwYj17My43NX0+XHJcbiAgICAgICAgICAgICAgICBXZeKAmXJlIGhlcmUgdG8gaGVscCB5b3UgYXQgZXZlcnkgc3RlcFxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibGFyZ2VcIiBjb2xvcj1cInByaW1hcnlcIiB2YXJpYW50PVwiY29udGFpbmVkXCI+XHJcbiAgICAgICAgICAgICAgICBIZWxwIENlbnRlclxyXG4gICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICA8L0JveD5cclxuICAgICk7XHJcbn07XHJcbkhlbHBDZW50ZXIucHJvcFR5cGVzID0ge1xyXG4gICAgd2lkdGg6IFByb3BUeXBlcy5zdHJpbmdcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgd2l0aFdpZHRoKCkoSGVscENlbnRlcik7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL0hlbHBDZW50ZXInO1xyXG4iLCJpbXBvcnQgeyBCb3ggfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBGZWF0aGVySWNvbiBmcm9tICdmZWF0aGVyLWljb25zLXJlYWN0JztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL0luZGljYXRvcnNTdHlsZXMnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWU6IEluZGljYXRvcnNcclxuICogRGVzYzogUmVuZGVyIEluZGljYXRvcnNcclxuICogQHBhcmFtIHsgc3RyaW5nIH0gY2xhc3NOYW1lc1xyXG4gKi9cclxuXHJcbmNvbnN0IEluZGljYXRvcnMgPSAoeyBzdGF0dXMsIHNpemUsIGljb25OYW1lLCBpY29uU2l6ZSwgYm9yZGVyV2lkdGgsIGljb25Db2xvciB9KSA9PiB7XHJcbiAgICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3hcclxuICAgICAgICAgICAgd2lkdGg9e3NpemV9XHJcbiAgICAgICAgICAgIGhlaWdodD17c2l6ZX1cclxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzPVwiNTAlXCJcclxuICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICBtYXJnaW49XCIwIGF1dG9cIlxyXG4gICAgICAgICAgICBib3JkZXI9e2JvcmRlcldpZHRofVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXNbc3RhdHVzXX0+XHJcbiAgICAgICAgICAgIDxGZWF0aGVySWNvbiBpY29uPXtpY29uTmFtZX0gc2l6ZT17aWNvblNpemV9IGNvbG9yPXtpY29uQ29sb3J9IC8+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5cclxuSW5kaWNhdG9ycy5kZWZhdWx0UHJvcHMgPSB7XHJcbiAgICBzaXplOiA4MCxcclxuICAgIHN0YXR1czogJ2RlZmF1bHQnLFxyXG4gICAgaWNvbk5hbWU6ICd0aHVtYnMtdXAnLFxyXG4gICAgaWNvblNpemU6IDM2LFxyXG4gICAgYm9yZGVyV2lkdGg6IDhcclxufTtcclxuXHJcbkluZGljYXRvcnMucHJvcFR5cGVzID0ge1xyXG4gICAgc3RhdHVzOiBQcm9wVHlwZXMub25lT2YoWydzdWNjZXNzJywgJ2ZhaWxlZCcsICdwZW5kaW5nJywgJ2RlZmF1bHQnLCAnY29tcGxldGUnXSksXHJcbiAgICBzaXplOiBQcm9wVHlwZXMubnVtYmVyLFxyXG4gICAgaWNvblNpemU6IFByb3BUeXBlcy5udW1iZXIsXHJcbiAgICBib3JkZXJXaWR0aDogUHJvcFR5cGVzLm51bWJlcixcclxuICAgIGljb25OYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgaWNvbkNvbG9yOiBQcm9wVHlwZXMuc3RyaW5nXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbmRpY2F0b3JzO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICAgIGZhaWxlZDoge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5lcnJvci5saWdodCxcclxuICAgICAgICBib3JkZXJDb2xvcjogYCR7dGhlbWUucGFsZXR0ZS5lcnJvci5tYWlufSAhaW1wb3J0YW50YFxyXG4gICAgfSxcclxuICAgIHBlbmRpbmc6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUucGVuZGluZy5saWdodCxcclxuICAgICAgICBib3JkZXJDb2xvcjogYCR7dGhlbWUucGFsZXR0ZS5wZW5kaW5nLm1haW59ICFpbXBvcnRhbnRgXHJcbiAgICB9LFxyXG4gICAgc3VjY2Vzczoge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5zdWNjZXNzLmxpZ2h0LFxyXG4gICAgICAgIGJvcmRlckNvbG9yOiBgJHt0aGVtZS5wYWxldHRlLnN1Y2Nlc3MubWFpbn0gIWltcG9ydGFudGBcclxuICAgIH0sXHJcbiAgICBkZWZhdWx0OiB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxyXG4gICAgICAgIGJvcmRlckNvbG9yOiBgJHt0aGVtZS5wYWxldHRlLmRlZmF1bHQubWFpbn0gIWltcG9ydGFudGBcclxuICAgIH0sXHJcbiAgICBjb21wbGV0ZToge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUuY29tbW9uLndoaXRlLFxyXG4gICAgICAgIGJvcmRlcjogJzhweCBzb2xpZCByZ2JhKDI1NSwgMjU1LCAyNTUsIC41KScsXHJcbiAgICAgICAgJy13ZWJraXQtYmFja2dyb3VuZC1jbGlwJzogJ3BhZGRpbmctYm94JyxcclxuICAgICAgICBiYWNrZ3JvdW5kQ2xpcDogJ3BhZGRpbmctYm94J1xyXG4gICAgfVxyXG59KSk7XHJcbmV4cG9ydCBkZWZhdWx0IHVzZVN0eWxlcztcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vSW5kaWNhdG9ycyciLCJpbXBvcnQgeyBCb3ggfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi9Mb2dvSGVhZGluZ1N0eWxlcyc7XHJcblxyXG4vKipcclxuICogTmFtZSA6IExvZ29IZWFkaW5nXHJcbiAqIERlc2MgOiBSZW5kZXIgTG9nb0hlYWRpbmdcclxuICogQHBhcmFtICB7c3RyaW5nfSAgbGFiZWxOYW1lXHJcbiAqIEBwYXJhbSAge3N0cmluZ30gIHRpdGxlXHJcbiAqIEBwYXJhbSAge2Jvb2xlYW59ICBpc0xvZ2dlZEluXHJcbiAqIEBwYXJhbSAge3N0cmluZ30gIGJyZWFrUG9pbnRcclxuICovXHJcblxyXG5jb25zdCBMb2dvSGVhZGluZyA9ICh7IHRpdGxlLCBsYWJlbE5hbWUsIGlzTG9nZ2VkSW4sIGJyZWFrUG9pbnQgfSkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgY29sb3IgPSBpc0xvZ2dlZEluID8gJ2NvbW1vbi53aGl0ZScgOiAncHJpbWFyeS5saWdodCc7XHJcbiAgICBjb25zdCBzdWJUZXh0Q29sb3IgPSBpc0xvZ2dlZEluID8gJ2NvbW1vbi53aGl0ZScgOiAncHJpbWFyeS5saWdodCc7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBmbGV4RGlyZWN0aW9uPVwiY29sdW1uXCI+XHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNC5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuZXh0cmFCb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj17Y29sb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcmZsb3c9XCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgIHdoaXRlU3BhY2U9XCJub3dyYXBcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1heFdpZHRoPVwiMzUwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRleHRPdmVyZmxvdz1cImVsbGlwc2lzXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHshaXNMb2dnZWRJbiB8fCBicmVha1BvaW50ID8gdGl0bGUgOiAnJ31cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImJvZHk1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nPVwiNHB4XCJcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj17c3ViVGV4dENvbG9yfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5sYWJlbE5hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtsYWJlbE5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5cclxuTG9nb0hlYWRpbmcuZGVmYXVsdFByb3BzID0ge307XHJcbkxvZ29IZWFkaW5nLnByb3BUeXBlcyA9IHtcclxuICAgIHRpdGxlOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgbGFiZWxOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgaXNMb2dnZWRJbjogUHJvcFR5cGVzLmJvb2wsXHJcbiAgICBicmVha1BvaW50OiBQcm9wVHlwZXMuYm9vbFxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9nb0hlYWRpbmc7XHJcbiIsImltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgICBsYWJlbE5hbWU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ2xnJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaydcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdGl0bGU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ2xnJyldOiB7XHJcbiAgICAgICAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5LmgyLmZvbnRTaXplXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7ZGVmYXVsdH0gZnJvbSAnLi9Mb2dvSGVhZGluZyc7IiwiaW1wb3J0IHsgQm94LCBCdXR0b24sIENhcmQsIEljb25CdXR0b24sIE1lbnUsIE1lbnVJdGVtIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5pbXBvcnQgRmVhdGhlckljb24gZnJvbSAnZmVhdGhlci1pY29ucy1yZWFjdCc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IG5vb3AgfSBmcm9tICd+L3NoYXJlZC91dGlscy91dGlscyc7XHJcbmltcG9ydCBJbmRpY2F0b3IgZnJvbSAnLi4vSW5kaWNhdG9ycyc7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi9PYmplY3RDYXJkU3R5bGUnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWUgOiBPYmplY3RDYXJkXHJcbiAqIERlc2MgOiBSZW5kZXIgT2JqZWN0Q2FyZFxyXG4gKiovXHJcblxyXG5jb25zdCBPYmplY3RDYXJkID0gKHByb3BzKSA9PiB7XHJcbiAgICBjb25zdCB7IGNoaWxkcmVuLCB2YXJpYW50LCBpY29uTmFtZSwgY2FyZFR5cGUsIG9uQ2xpY2ssIG9uRGVsZXRlLCBpc01lbWJlciwgb25FZGl0Q2xpY2ssIHNob3dPcHRpb25NZW51IH0gPVxyXG4gICAgICAgIHByb3BzO1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgW2FuY2hvckVsLCBzZXRBbmNob3JFbF0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcclxuICAgIGNvbnN0IG9wZW4gPSBCb29sZWFuKGFuY2hvckVsKTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDbGljayA9IChldmVudCkgPT4ge1xyXG4gICAgICAgIHNldEFuY2hvckVsKGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDbG9zZSA9ICgpID0+IHtcclxuICAgICAgICBzZXRBbmNob3JFbChudWxsKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlRWRpdCA9ICgpID0+IHtcclxuICAgICAgICBvbkVkaXRDbGljaygpO1xyXG4gICAgICAgIGhhbmRsZUNsb3NlKCk7XHJcbiAgICB9O1xyXG4gICAgY29uc3QgaGFuZGxlRGVsZXRlID0gKCkgPT4ge1xyXG4gICAgICAgIG9uRGVsZXRlKCk7XHJcbiAgICAgICAgaGFuZGxlQ2xvc2UoKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICB7Y2FyZFR5cGUgPT09ICdvYmplY3RDYXJkJyA/IChcclxuICAgICAgICAgICAgICAgIDxDYXJkIG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIgcHg9ezJ9IHB5PXsyLjV9IG1pbkhlaWdodD17OTZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEluZGljYXRvclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezM3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1cz17dmFyaWFudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uTmFtZT17aWNvbk5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyV2lkdGg9ezMuN31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uU2l6ZT17MTh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NoaWxkcmVuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmbGV4R3Jvdz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbj1cImNvbHVtblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsPXsxLjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2hvd09wdGlvbk1lbnUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHA9ezAuMjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXI9ey0xLjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzTWVtYmVyID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b24gY29sb3I9XCJwcmltYXJ5XCIgb25DbGljaz17aGFuZGxlQ2xpY2t9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGZWF0aGVySWNvbiBpY29uPVwibW9yZS12ZXJ0aWNhbFwiIHNpemU9XCIyNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVudVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibG9uZy1tZW51XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbmNob3JFbD17YW5jaG9yRWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2VlcE1vdW50ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGVuPXtvcGVufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVudUl0ZW0gb25DbGljaz17aGFuZGxlRWRpdH0+RWRpdDwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIG9uQ2xpY2s9e2hhbmRsZURlbGV0ZX0+RGVsZXRlPC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTWVudT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b24gY29sb3I9XCJwcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmVhdGhlckljb24gaWNvbj1cIm1vcmUtdmVydGljYWxcIiBzaXplPVwiMjRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxCb3ggY2xhc3NOYW1lPXtjbGFzc2VzLnJvb3RVcGxvYWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmlucHV0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvbnRhaW5lZC1idXR0b24tZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG11bHRpcGxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY29udGFpbmVkLWJ1dHRvbi1maWxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGNvbXBvbmVudD1cInNwYW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB5PXsxLjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbkhlaWdodD17OTZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEluZGljYXRvclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezM3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1cz17dmFyaWFudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uTmFtZT17aWNvbk5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyV2lkdGg9ezMuN31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uU2l6ZT17MTh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NoaWxkcmVuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmbGV4R3Jvdz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbj1cImNvbHVtblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsPXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufTtcclxuXHJcbk9iamVjdENhcmQuZGVmYXVsdFByb3BzID0ge1xyXG4gICAgdmFyaWFudDogJ3N1Y2Nlc3MnLFxyXG4gICAgY2hpbGRyZW46ICcnLFxyXG4gICAgaWNvbk5hbWU6ICd1c2VyJyxcclxuICAgIGNhcmRUeXBlOiAnb2JqZWN0Q2FyZCcsXHJcbiAgICBvbkNsaWNrOiBub29wLFxyXG4gICAgaXNNZW1iZXI6IGZhbHNlLFxyXG4gICAgb25FZGl0Q2xpY2s6IG5vb3AsXHJcbiAgICBvbkRlbGV0ZTogbm9vcCxcclxuICAgIHNob3dPcHRpb25NZW51IDogdHJ1ZVxyXG59O1xyXG5cclxuT2JqZWN0Q2FyZC5wcm9wVHlwZXMgPSB7XHJcbiAgICB2YXJpYW50OiBQcm9wVHlwZXMub25lT2YoWydzdWNjZXNzJywgJ2ZhaWxlZCcsICdwZW5kaW5nJ10pLFxyXG4gICAgY2FyZFR5cGU6IFByb3BUeXBlcy5vbmVPZihbJ29iamVjdENhcmQnLCAnYWN0aW9uQ2FyZCddKSxcclxuICAgIGNoaWxkcmVuOiBQcm9wVHlwZXMubm9kZSxcclxuICAgIGljb25OYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgb25DbGljazogUHJvcFR5cGVzLmZ1bmMsXHJcbiAgICBpc01lbWJlcjogUHJvcFR5cGVzLmJvb2wsXHJcbiAgICBvbkVkaXRDbGljazogUHJvcFR5cGVzLmZ1bmMsXHJcbiAgICBvbkRlbGV0ZTogUHJvcFR5cGVzLmZ1bmMsXHJcbiAgICBzaG93T3B0aW9uTWVudSA6IFByb3BUeXBlcy5ib29sLFxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgT2JqZWN0Q2FyZDtcclxuIiwiaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCgpID0+ICh7XHJcbiAgICByb290VXBsb2FkOiB7XHJcbiAgICAgICAgJyYgPiAqJzoge1xyXG4gICAgICAgICAgICBtYXJnaW46IDBcclxuICAgICAgICB9LFxyXG4gICAgICAgICcmIC5NdWlCdXR0b24tcm9vdCc6IHtcclxuICAgICAgICAgICAgd2lkdGg6ICcxMDAlJyxcclxuICAgICAgICAgICAgcGFkZGluZzogJzAnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnJiAuTXVpQ2FyZC1yb290Jzoge1xyXG4gICAgICAgICAgICB3aWR0aDogJzEwMCUnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGlucHV0OiB7XHJcbiAgICAgICAgZGlzcGxheTogJ25vbmUnXHJcbiAgICB9LFxyXG4gICAgJy5NdWlCdXR0b25CYXNlLXJvb3QnOiB7XHJcbiAgICAgICAgcGFkZGluZzogMFxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL09iamVjdENhcmQnO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBCb3gsIFR5cG9ncmFwaHkgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcblxyXG4vKiogXHJcbiAqIE5hbWUgOiBQYWdlSGVhZGluZ1xyXG4gKiBEZXNjIDogUmVuZGVyIFBhZ2VIZWFkaW5nXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSB0aXRsZSBcclxuICoqL1xyXG5cclxuY29uc3QgUGFnZUhlYWRpbmcgPSAoeyB0aXRsZSB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgPEJveCBjb2xvcj0ncHJpbWFyeS5tYWluJyBmb250RmFtaWx5PSdmb250RmFtaWx5LmJvbGQnIGxldHRlclNwYWNpbmc9ezh9IHBiPXszfSBjbGFzc05hbWU9J3RleHRUcmFuc2Zvcm0nPlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImgyXCI+XHJcbiAgICAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDwvQm94PiAgXHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59O1xyXG5QYWdlSGVhZGluZy5kZWZhdWx0UHJvcHMgPSB7fTtcclxuUGFnZUhlYWRpbmcucHJvcFR5cGVzID0ge1xyXG4gICAgdGl0bGU6IFByb3BUeXBlcy5zdHJpbmcsXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYWdlSGVhZGluZ1xyXG4iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9QYWdlSGVhZGluZyciLCJpbXBvcnQgeyBCb3gsIENhcmQsIEljb25CdXR0b24gfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCB3aXRoV2lkdGggZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvd2l0aFdpZHRoJztcclxuaW1wb3J0IGNsc3ggZnJvbSAnY2xzeCc7XHJcbmltcG9ydCBJbWFnZSBmcm9tICduZXh0L2ltYWdlJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2hldnJvblJpZ2h0LCBUcmFzaDIgfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL1Byb2dyYW1DYXJkc1N0eWxlJztcclxuXHJcbi8qKlxyXG4gKiBOYW1lIDogUHJvZ3JhbUNhcmRcclxuICogRGVzYyA6IFJlbmRlciBQcm9ncmFtQ2FyZFxyXG4gKiovXHJcblxyXG5jb25zdCBQcm9ncmFtQ2FyZCA9IChwcm9wcykgPT4ge1xyXG4gICAgY29uc3Qge1xyXG4gICAgICAgIGNoaWxkcmVuLFxyXG4gICAgICAgIHNob3dMZWZ0QXJyb3csXHJcbiAgICAgICAgdmFyaWFudCxcclxuICAgICAgICBzaG93RGVsZXRlQm94LFxyXG4gICAgICAgIHNob3dJbWFnZSxcclxuICAgICAgICBzaG93TGVmdEJvcmRlcixcclxuICAgICAgICBpbWdVcmwsXHJcbiAgICAgICAgd2lkdGhcclxuICAgIH0gPSBwcm9wcztcclxuICAgIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEJveCBwb3NpdGlvbj1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzaG93TGVmdEJvcmRlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbldpZHRoPXsxNn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbkhlaWdodD17OTZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM9XCI1MHB4IDAgMCA1MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uPXt3aWR0aCA9PT0gJ3hzJyA/ICdzdGF0aWMnIDogJ2Fic29sdXRlJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ9XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleD17MX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlc1t2YXJpYW50XX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7c2hvd0ltYWdlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbHN4KGNsYXNzZXMub3ZlcmxheSwgY2xhc3Nlc1t2YXJpYW50XSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17Mi41fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT17d2lkdGggPT09ICd4cycgPyAnbm9uZScgOiAnaW5oZXJpdCd9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz17aW1nVXJsfSB3aWR0aD17MTMzfSBoZWlnaHQ9ezk2fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7Y2hpbGRyZW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmbGV4R3Jvdz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB4PXsxLjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBweT17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb249XCJjb2x1bW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge3Nob3dMZWZ0QXJyb3cgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwPXswLjI1fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHI9ezEuMjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IHN0cm9rZS13aWR0aD1cIjNcIiBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHtzaG93RGVsZXRlQm94ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHA9ezEuNX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJnY29sb3I9XCJlcnJvci5kYXJrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiY29tbW9uLndoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbkhlaWdodD17OTZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5XaWR0aD17OTZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb249XCJjb2x1bW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyPXswfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgc3Ryb2tlLXdpZHRoPVwiMS41XCIgY29sb3I9XCJ3aGl0ZVwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudD1cImJvZHkxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5yZWd1bGFyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdD17MC43NX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgREVMRVRFXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5cclxuUHJvZ3JhbUNhcmQuZGVmYXVsdFByb3BzID0ge1xyXG4gICAgY2hpbGRyZW46ICcnLFxyXG4gICAgc2hvd0xlZnRBcnJvdzogZmFsc2UsXHJcbiAgICBzaG93RGVsZXRlQm94OiBmYWxzZSxcclxuICAgIHNob3dJbWFnZTogZmFsc2UsXHJcbiAgICBzaG93TGVmdEJvcmRlcjogdHJ1ZSxcclxuICAgIGltZ1VybDogJy92aWV3LmpwZydcclxufTtcclxuXHJcblByb2dyYW1DYXJkLnByb3BUeXBlcyA9IHtcclxuICAgIHZhcmlhbnQ6IFByb3BUeXBlcy5vbmVPZihbJ3N1Y2Nlc3MnLCAnZmFpbGVkJywgJ3dhaXRpbmcnXSksXHJcbiAgICBjaGlsZHJlbjogUHJvcFR5cGVzLm5vZGUsXHJcbiAgICBzaG93TGVmdEFycm93OiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIHNob3dEZWxldGVCb3g6IFByb3BUeXBlcy5ib29sLFxyXG4gICAgc2hvd0ltYWdlOiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIHNob3dMZWZ0Qm9yZGVyOiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIGltZ1VybDogUHJvcFR5cGVzLnN0cmluZyxcclxuICAgIHdpZHRoOiBQcm9wVHlwZXMuc3RyaW5nXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCB3aXRoV2lkdGgoKShQcm9ncmFtQ2FyZCk7XHJcbiIsImltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgICBmYWlsZWQ6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUuZXJyb3IubWFpbixcclxuICAgICAgICAnJjpiZWZvcmUnOiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICdyZ2JhKDI0NSwgNjYsIDE1LCAwLjUpICFpbXBvcnRhbnQnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHdhaXRpbmc6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUucGVuZGluZy5tYWluLFxyXG4gICAgICAgICcmOmJlZm9yZSc6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMjQ5LCAxOTEsIDIsIDAuNSkgIWltcG9ydGFudCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy8gcGVuZGluZzoge1xyXG4gICAgLy8gICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5wZW5kaW5nLm1haW5cclxuICAgIC8vIH0sXHJcbiAgICBzdWNjZXNzOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLnN1Y2Nlc3MubGlnaHQsXHJcbiAgICAgICAgJyY6YmVmb3JlJzoge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAncmdiYSg3OSwgMjQwLCAxODgsIDAuNSkgIWltcG9ydGFudCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgaW5mbzp7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOnRoZW1lLnBhbGV0dGUuaW5mby5tYWluXHJcbiAgICB9LFxyXG4gICAgb3ZlcmxheToge1xyXG4gICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxyXG4gICAgICAgICcmOmJlZm9yZSc6IHtcclxuICAgICAgICAgICAgY29udGVudDogJ1wiXCInLFxyXG4gICAgICAgICAgICB3aWR0aDogJzEwMCUnLFxyXG4gICAgICAgICAgICBoZWlnaHQ6ICcxMDAlJyxcclxuICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgICAgICAgIHRvcDogJzAnLFxyXG4gICAgICAgICAgICBib3R0b206ICcwJyxcclxuICAgICAgICAgICAgbGVmdDogJzAnLFxyXG4gICAgICAgICAgICByaWdodDogJzAnLFxyXG4gICAgICAgICAgICB6SW5kZXg6ICcxJ1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSkpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXNlU3R5bGVzOyIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL1Byb2dyYW1DYXJkJyIsImltcG9ydCB7IEJveCwgQnV0dG9uLCBDb250YWluZXIsIEljb25CdXR0b24gfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCB3aXRoV2lkdGggZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvd2l0aFdpZHRoJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQXJyb3dMZWZ0LCBDaGV2cm9uTGVmdCB9IGZyb20gJ3JlYWN0LWZlYXRoZXInO1xyXG5pbXBvcnQgdXNlU3R5bGVzIGZyb20gJy4vV2l6YXJkSGVhZGVyU3R5bGVzJztcclxuLyoqXHJcbiAqIE5hbWUgOiBXaXphcmRIZWFkZXJcclxuICogRGVzYyA6IFJlbmRlciBXaXphcmRIZWFkZXJcclxuICovXHJcblxyXG5jb25zdCBXaXphcmRIZWFkZXIgPSAoeyBvbkNsaWNrQmFjaywgdGl0bGUsIGNoaWxkcmVuID0gbnVsbCB9KSA9PiB7XHJcbiAgICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Qm94IGJnY29sb3I9XCJwcmltYXJ5Lm1haW5cIiBjbGFzc05hbWU9e2NsYXNzZXMuV2l6YXJkSGVhZGVyV3JhcHBlcn0+XHJcbiAgICAgICAgICAgIDxDb250YWluZXI+XHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5kZXZpY2VIZWFkZXJ9XHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb249XCJyZWxhdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgekluZGV4PXsxfT5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBjbGFzc05hbWU9e2NsYXNzZXMubWVudUJ1dHRvbn0gb25DbGljaz17b25DbGlja0JhY2t9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvbkxlZnQgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNn0gY2xhc3NOYW1lPXtjbGFzc2VzLnZpc2libGVEZXNrdG9wfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QXJyb3dMZWZ0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cIkluZGlnb1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzaXplPXsyMH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0cm9rZVdpZHRoPXszfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnZpc2libGVYc31cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImgzLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJjb21tb24ud2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgbWw9ezN9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIHtjaGlsZHJlbiA/IChcclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgd2lkdGg9XCIxMDAlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcG9zaXRpb249XCJyZWxhdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleD17MX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnhzTWFyZ2lufT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NoaWxkcmVufVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5XaXphcmRIZWFCb3h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhXcmFwPVwid3JhcFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uPVwicmVsYXRpdmVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB6SW5kZXg9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7W1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0ZXh0OiAnQ29udGludWUnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHRleHQ6ICdDb250aW51ZScgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdGV4dDogJ0NvbnRpbnVlJyB9LFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgeyB0ZXh0OiAnQ29udGludWUnIH0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7IHRleHQ6ICdDb250aW51ZScgfSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHsgdGV4dDogJ0NvbnRpbnVlJyB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIF0ubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBjbGFzc05hbWU9e2NsYXNzZXMubGlua3N9IGtleT17YCR7aXRlbS50ZXh0fV8ke2luZGV4fWB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNS5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiY29tbW9uLndoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7aXRlbS50ZXh0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgPC9Db250YWluZXI+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5XaXphcmRIZWFkZXIucHJvcFR5cGVzID0ge1xyXG4gICAgb25DbGlja0JhY2s6IFByb3BUeXBlcy5mdW5jLFxyXG4gICAgY2hpbGRyZW46IFByb3BUeXBlcy5hbnksXHJcbiAgICB0aXRsZTogUHJvcFR5cGVzLnN0cmluZ1xyXG59O1xyXG5leHBvcnQgZGVmYXVsdCB3aXRoV2lkdGgoKShXaXphcmRIZWFkZXIpO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgV2l6YXJkSGVhZGVyV3JhcHBlcjoge1xyXG4gICAgICAgIGJhY2tncm91bmRTaXplOiAnY292ZXInLFxyXG4gICAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogJ2NlbnRlcicsXHJcbiAgICAgICAgYm9yZGVyQm90dG9tTGVmdFJhZGl1czogdGhlbWUuc3BhY2luZygzKSxcclxuICAgICAgICBib3JkZXJCb3R0b21SaWdodFJhZGl1czogdGhlbWUuc3BhY2luZygzKSxcclxuICAgICAgICBwYWRkaW5nOiAnMjRweCAwJyxcclxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcclxuICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6IGB1cmwoJy9zcGxhc2hNb2JpbGUuc3ZnJylgLFxyXG5cclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ3NtJyldOiB7XHJcbiAgICAgICAgICAgICcmOmFmdGVyJzoge1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgICAgICAgICAgICB0b3A6ICcwJyxcclxuICAgICAgICAgICAgICAgIGxlZnQ6ICcwJyxcclxuICAgICAgICAgICAgICAgIHJpZ2h0OiAnMCcsXHJcbiAgICAgICAgICAgICAgICB3aWR0aDogJzEwMCUnLFxyXG4gICAgICAgICAgICAgICAgY29udGVudDogJ1wiXCInLFxyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZEltYWdlOiBgdXJsKCcvc3BsYXNoLnN2ZycpYCxcclxuICAgICAgICAgICAgICAgIG1pbkhlaWdodDogJzQ2MXB4JyxcclxuICAgICAgICAgICAgICAgIGJvcmRlckJvdHRvbUxlZnRSYWRpdXM6IHRoZW1lLnNwYWNpbmcoMyksXHJcbiAgICAgICAgICAgICAgICBib3JkZXJCb3R0b21SaWdodFJhZGl1czogdGhlbWUuc3BhY2luZygzKSxcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogJ2NlbnRlcicsXHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kU2l6ZTogJ2NvdmVyJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bigneHMnKV06IHtcclxuICAgICAgICAgICAgbWluSGVpZ2h0OiAnMTU1cHgnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIFdpemFyZEhlYUJveDoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy5kb3duKCd4cycpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnbm9uZSdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG5cclxuICAgIGxpbmtzOiB7XHJcbiAgICAgICAgJyY6aG92ZXInOiB7XHJcbiAgICAgICAgICAgICcmID4gZGl2Jzoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IHRoZW1lLnBhbGV0dGUuc3VjY2Vzcy5saWdodFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bignbWQnKV06IHtcclxuICAgICAgICAgICAgbWFyZ2luOiBgMCA4cHhgXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIG1lbnVCdXR0b246IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbW1vbi53aGl0ZSxcclxuICAgICAgICAnJjpob3Zlcic6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb21tb24ud2hpdGUsXHJcbiAgICAgICAgICAgIG9wYWNpdHk6ICcwLjUnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGRldmljZUhlYWRlcjoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnc20nKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ25vbmUnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHhzTWFyZ2luOntcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bigneHMnKV06IHtcclxuICAgICAgICAgICAgcGFkZGluZzonMCA4cHggNTZweCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdmlzaWJsZURlc2t0b3A6IHtcclxuICAgICAgICBkaXNwbGF5OiAnbm9uZScsXHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdzbScpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHZpc2libGVYczoge1xyXG4gICAgICAgIGRpc3BsYXk6ICdub25lJyxcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bigneHMnKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbn0pKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHVzZVN0eWxlcztcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vV2l6YXJkSGVhZGVyJztcclxuIiwiZXhwb3J0IGNvbnN0IFJPVVRFUyA9IHtcclxuICAgIEhPTUU6IHtcclxuICAgICAgICBST1VURTogJy8nLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0hvbWUnLFxyXG4gICAgICAgIE5BTUU6ICdIb21lJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgRVhBTVBMRVM6IHtcclxuICAgICAgICBST1VURTogJy9leGFtcGxlcycsIC8vRm9yIGxlYXJuaW5nIHB1cnBvc2VcclxuICAgICAgICBUSVRMRTogJ0V4YW1wbGVzJyxcclxuICAgICAgICBOQU1FOiAnRXhhbXBsZXMnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBVU0VSX0xPR0lOOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvbG9naW4nLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0xvZ2luJyxcclxuICAgICAgICBOQU1FOiAnTG9naW4nXHJcbiAgICB9LFxyXG4gICAgTE9HSU46IHtcclxuICAgICAgICBST1VURTogJy9hZG1pbicsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnQWRtaW4nLFxyXG4gICAgICAgIE5BTUU6ICdMb2dpbicsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuXHJcbiAgICBQUk9GSUxFOiB7XHJcbiAgICAgICAgLy9uZWVkIHRvIGFkZCBxdWVyeSBwYXJhbXNcclxuICAgICAgICBST1VURTogJy9wcm9maWxlJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdQcm9maWxlJyxcclxuICAgICAgICBOQU1FOiAnUHJvZmlsZScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIFZPVUNIRVI6IHtcclxuICAgICAgICAvL25lZWQgdG8gYWRkIHF1ZXJ5IHBhcmFtc1xyXG4gICAgICAgIFJPVVRFOiAnL3ZvdWNoZXInLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ1ZvdWNoZXInLFxyXG4gICAgICAgIE5BTUU6ICdWb3VjaGVyJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG5cclxuICAgIEFDQ09VTlQ6IHtcclxuICAgICAgICAvL25lZWQgdG8gYWRkIHF1ZXJ5IHBhcmFtc1xyXG4gICAgICAgIFJPVVRFOiAnL2FjY291bnQnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0FjY291bnQnLFxyXG4gICAgICAgIE5BTUU6ICdBY2NvdW50JyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG5cclxuICAgIEFDQ09VTlRfREVUQUlMOiB7XHJcbiAgICAgICAgLy9uZWVkIHRvIGFkZCBxdWVyeSBwYXJhbXNcclxuICAgICAgICBST1VURTogJy9hY2NvdW50ZGV0YWlsJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdBY2NvdW50IERldGFpbCcsXHJcbiAgICAgICAgTkFNRTogJ0FjY291bnQgRGV0YWlsJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG5cclxuICAgIEdFVF9TVEFSVEVEOiB7XHJcbiAgICAgICAgLy9uZWVkIHRvIGFkZCBxdWVyeSBwYXJhbXNcclxuICAgICAgICBST1VURTogJy9nZXRzdGFydGVkJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdHZXQgU3RhcnRlZCcsXHJcbiAgICAgICAgTkFNRTogJ0dldCBTdGFydGVkJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG5cclxuICAgIEhFTFA6IHtcclxuICAgICAgICAvL25lZWQgdG8gYWRkIHF1ZXJ5IHBhcmFtc1xyXG4gICAgICAgIFJPVVRFOiAnL2hlbHAnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0hlbHAnLFxyXG4gICAgICAgIE5BTUU6ICdIZWxwJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG5cclxuICAgIEhFTFBfVE9QSUNTOiB7XHJcbiAgICAgICAgLy9uZWVkIHRvIGFkZCBxdWVyeSBwYXJhbXNcclxuICAgICAgICBST1VURTogJy9oZWxwdG9waWNzJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdIZWxwIFRvcGljcycsXHJcbiAgICAgICAgTkFNRTogJ0hlbHAgVG9waWNzJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG5cclxuICAgIENIQU5HRV9QQVNTV09SRDoge1xyXG4gICAgICAgIC8vbmVlZCB0byBhZGQgcXVlcnkgcGFyYW1zXHJcbiAgICAgICAgUk9VVEU6ICcvY2hhbmdlcGFzc3dvcmQnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0NoYW5nZSBQYXNzd29yZCcsXHJcbiAgICAgICAgTkFNRTogJ0NoYW5nZSBQYXNzd29yZCcsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuXHJcbiAgICBGT1JHT1RfUEFTU1dPUkQ6IHtcclxuICAgICAgICBST1VURTogJy9mb3Jnb3RwYXNzd29yZCcsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnRm9yZ290IFBhc3N3b3JkJyxcclxuICAgICAgICBOQU1FOiAnRm9yZ290IFBhc3N3b3JkJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgQ09NTU9OX0NPTVBPTkVOVF9TVFlMRToge1xyXG4gICAgICAgIFJPVVRFOiAnL2NvbW1vbmNvbXBvbmVudHN0eWxlJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdDb21tb24gQ29tcG9uZW50IFN0eWxlJyxcclxuICAgICAgICBOQU1FOiAnQ29tbW9uIENvbXBvbmVudCBTdHlsZScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIENPTU1PTl9GVUxMRkxPV1BBR0VfU1RZTEU6IHtcclxuICAgICAgICBST1VURTogJy9jb21tb25mdWxscGFnZWZsb3dzdHlsZScsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnQ29tbW9uIGZ1bGxwYWdlZmxvdyBTdHlsZScsXHJcbiAgICAgICAgTkFNRTogJ0NvbW1vbiBmdWxscGFnZWZsb3cgU3R5bGUnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBWT1VDSEVSX1JFQ0VJVkVEOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvdm91Y2hlcnJlY2VpdmVkZnVsbHBhZ2VzdHlsZScsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnVm91Y2hlciBSZWNlaXZlZCBTdHlsZScsXHJcbiAgICAgICAgTkFNRTogJ1ZvdWNoZXIgUmVjZWl2ZWQgU3R5bGUnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBEQVNIQk9BUkRfUEFHRV9TVFlMRToge1xyXG4gICAgICAgIFJPVVRFOiAnL2Rhc2hib2FyZHBhZ2VzdHlsZScsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnRGFzaGJvYXJkIFBhZ2UgU3R5bGUnLFxyXG4gICAgICAgIE5BTUU6ICdEYXNoYm9hcmQgUGFnZSBTdHlsZScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIExBTkRMT1JEX1BBR0VfU1RZTEU6IHtcclxuICAgICAgICBST1VURTogJy9sYW5kbG9yZHBhZ2VzdHlsZScsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnTGFuZGxvcmQgUGFnZSBTdHlsZScsXHJcbiAgICAgICAgTkFNRTogJ0xhbmRsb3JkIFBhZ2UgU3R5bGUnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBTVVBFUlZJU09SX0xPR0lOOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvYWRtaW4vbG9naW4nLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0FkbWluIExPR0lOJyxcclxuICAgICAgICBOQU1FOiAnQWRtaW4gTE9HSU4nXHJcbiAgICB9LFxyXG4gICAgQ0hFQ0tfRUxJR0lCSUxJVFk6IHtcclxuICAgICAgICBST1VURTogJy9jaGVjay15b3VyLWVsaWdpYmlsaXR5JywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdDaGVjayBZb3VyIEVsaWdpYmlsaXR5JyxcclxuICAgICAgICBOQU1FOiAnQ2hlY2sgWW91ciBFbGlnaWJpbGl0eScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIFNVUEVSVklTT1JfREFTSEJPQVJEOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvYWRtaW4vZGFzaGJvYXJkJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdBZG1pbiBEYXNoYm9hcmQnLFxyXG4gICAgICAgIE5BTUU6ICdBZG1pbiBEYXNoYm9hcmQnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBDUkVBVEVfUFJPRklMRToge1xyXG4gICAgICAgIFJPVVRFOiAnL2NyZWF0ZS1wcm9maWxlJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdQcm9maWxlJyxcclxuICAgICAgICBOQU1FOiAnUHJvZmlsZScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIEVMSUdJQklMSVRZX0NBTENVTEFUT1I6IHtcclxuICAgICAgICBST1VURTogJy9hZG1pbi9jYWxjdWxhdG9yJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdFbGlnaWJpbGl0eSBDYWxjdWxhdG9yJyxcclxuICAgICAgICBOQU1FOiAnRWxpZ2liaWxpdHkgQ2FsY3VsYXRvcicsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIE1BTkFHRV9QUk9HUkFNUzoge1xyXG4gICAgICAgIFJPVVRFOiAnL2FkbWluL21hbmFnZS1wcm9ncmFtcycsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnTWFuYWdlIFByb2dyYW1zJyxcclxuICAgICAgICBOQU1FOiAnTWFuYWdlIFByb2dyYW1zJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgTUFOQUdFX1NNVFA6IHtcclxuICAgICAgICBST1VURTogJy9hZG1pbi9tYW5hZ2Utc210cCcsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnTWFuYWdlIFNtdHAnLFxyXG4gICAgICAgIE5BTUU6ICdNYW5hZ2UgU210cCcgLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBNQU5BR0VfUFJFQVBQTElDQVRJT046IHtcclxuICAgICAgICBST1VURTogJy9hZG1pbi9tYW5hZ2UtcHJlYXBwbGljYXRpb25zJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdNYW5hZ2UgUHJlYXBwbGljYXRpb24nLFxyXG4gICAgICAgIE5BTUU6ICdNYW5hZ2UgUHJlYXBwbGljYXRpb24nLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBIT1VTRV9IT0xEX0RFVEFJTDoge1xyXG4gICAgICAgIFJPVVRFOiAnL2hvdXNlLWhvbGQtZGV0YWlsJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdIb3VzZSBIb2xkIERldGFpbCcsXHJcbiAgICAgICAgTkFNRTogJ0hvdXNlIEhvbGQgRGV0YWlsJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgUkVWSUVXX0FQUExJQ0FUSU9OOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvcmV2aWV3LWFwcGxpY2F0aW9uJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdSZXZpZXcgQXBwbGljYXRpb24nLFxyXG4gICAgICAgIE5BTUU6ICdSZXZpZXcgQXBwbGljYXRpb24nLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBIT1VTRUhPTERfSU5DT01FOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvaG91c2Vob2xkLWluY29tZScsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnSG91c2Vob2xkIEluY29tZScsXHJcbiAgICAgICAgTkFNRTogJ0hvdXNlaG9sZCBJbmNvbWUnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBIT1VTRUhPTERfQVNTRVRTOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvaG91c2Vob2xkLWFzc2V0cycsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnSG91c2Vob2xkIEFzc2V0cycsXHJcbiAgICAgICAgTkFNRTogJ0hvdXNlaG9sZCBBc3NldHMnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBIT1VTRUhPTERfU1BFQ0lBTF9FWFBFTlNFUzoge1xyXG4gICAgICAgIFJPVVRFOiAnL2hvdXNlaG9sZC1zcGVjaWFsLWV4cGVuc2VzJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdIb3VzZWhvbGQgU3BlY2lhbCBFeHBlbnNlcycsXHJcbiAgICAgICAgTkFNRTogJ0hvdXNlaG9sZCBTcGVjaWFsIEV4cGVuc2VzJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgUkVOVF9BRkZPUkRBQklMSVRZOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvcmVudC1hZmZvcmRhYmlsaXR5JywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdSZW50IEFmZm9yZGFiaWxpdHknLFxyXG4gICAgICAgIE5BTUU6ICdSZW50IEFmZm9yZGFiaWxpdHknLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBZT1VSX0RPQ1VNRU5UUzoge1xyXG4gICAgICAgIFJPVVRFOiAnL3lvdXItZG9jdW1lbnRzJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdSb3VyIERvY3VtZW50cycsXHJcbiAgICAgICAgTkFNRTogJ1JvdXIgRG9jdW1lbnRzJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgUkVWSUVXX0FORF9TSUdOOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvcmV2aWV3LWFuZC1zaWduJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdSZXZpZXcgQW5kIFNpZ24nLFxyXG4gICAgICAgIE5BTUU6ICdSZXZpZXcgQW5kIFNpZ24nLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH1cclxufTtcclxuIiwiLyoqXHJcbiAqIHNldCBMb2NhbFN0b3JhZ2UgZm9yIGdpdmVuIGtleSBhbmQgdmFsdWVcclxuICogQHBhcmFtIHsqfSBrZXlcclxuICogQHBhcmFtIHsqfSB2YWx1ZVxyXG4gKi9cclxuZXhwb3J0IGNvbnN0IHNldExvY2FsU3RvcmFnZSA9IChrZXksIHZhbHVlKSA9PiB7XHJcbiAgICBsZXQgc3RvcmFnZVZhbHVlID0gdmFsdWU7XHJcbiAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xyXG4gICAgICAgIHN0b3JhZ2VWYWx1ZSA9IEpTT04uc3RyaW5naWZ5KHZhbHVlKTtcclxuICAgIH1cclxuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2Uuc2V0SXRlbShrZXksIHN0b3JhZ2VWYWx1ZSk7XHJcbn07XHJcblxyXG4vKipcclxuICogUmV0dXJuIHRoZSBMb2NhbFN0b3JhZ2UgZm9yIGdpdmVuIGtleVxyXG4gKiBAcGFyYW0geyp9IGtleVxyXG4gKi9cclxuZXhwb3J0IGNvbnN0IGdldExvY2FsU3RvcmFnZSA9IChrZXkpID0+IHtcclxuICAgIGNvbnN0IHZhbHVlID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKGtleSk7XHJcbiAgICByZXR1cm4gdmFsdWUgJiYgSlNPTi5wYXJzZSh2YWx1ZSk7XHJcbn07XHJcblxyXG4vKipcclxuICogUmV0dXJuIHJlbW92ZWQgaXRlbVxyXG4gKi9cclxuZXhwb3J0IGNvbnN0IHJlbW92ZUxvY2FsU3RvcmFnZSA9IChrZXkpID0+IHtcclxuICAgIGNvbnN0IHZhbHVlID0gZ2V0TG9jYWxTdG9yYWdlKGtleSk7XHJcbiAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oa2V5KTtcclxuICAgIHJldHVybiB2YWx1ZTtcclxufTtcclxuIiwiaW1wb3J0IHsgZ2V0TG9jYWxTdG9yYWdlIH0gZnJvbSAnLi9zdG9yZU1hbmFnZXInO1xyXG5cclxuLy91dGlsaXR5IGZ1bmN0aW9ucyBoZXJlXHJcbmV4cG9ydCBjb25zdCBnZXRCYXNlVXJsID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIHByb2Nlc3MuZW52Lk5FWFRfUFVCTElDX0FQSV9CQVNFX1VSTDtcclxufTtcclxuLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWVtcHR5LWZ1bmN0aW9uXHJcbmV4cG9ydCBjb25zdCBub29wID0gKCkgPT4ge307XHJcblxyXG5leHBvcnQgY29uc3QgZ2V0TG9jYWxpemVLZXkgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfTE9DQUxJWkVfSlNfS0VZO1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGdldFVzZXJJZCA9ICgpID0+IHtcclxuICAgIGNvbnN0IHVzZXJEZXRhaWwgPSBnZXRMb2NhbFN0b3JhZ2UoJ3VzZXJfZGV0YWlscycpIHx8IHt9O1xyXG4gICAgcmV0dXJuIHVzZXJEZXRhaWw/LnVzZXJfaWQ7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgZ2V0QWNjZXNzVG9rZW4gPSAoKSA9PiB7XHJcbiAgICBjb25zdCB1c2VyRGV0YWlsID0gZ2V0TG9jYWxTdG9yYWdlKCd1c2VyX2RldGFpbHMnKSB8fCB7fTtcclxuICAgIHJldHVybiB1c2VyRGV0YWlsPy5hY2Nlc3NfdG9rZW47XHJcbn07IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvQmFkZ2VcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvVGFiXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL1RhYnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9jb3JlL3VzZU1lZGlhUXVlcnlcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvd2l0aFdpZHRoXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9DbG9zZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvbGFiXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImNsc3hcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiZmVhdGhlci1pY29ucy1yZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L3JvdXRlclwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJwcm9wLXR5cGVzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LWZlYXRoZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=