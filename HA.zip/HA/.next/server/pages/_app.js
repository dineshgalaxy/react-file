module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/modules/Admin/Login/Utils/LoginConstants.js":
/*!*********************************************************!*\
  !*** ./src/modules/Admin/Login/Utils/LoginConstants.js ***!
  \*********************************************************/
/*! exports provided: loginConstants, initialState */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginConstants", function() { return loginConstants; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
const loginConstants = {
  LOGIN_SUCCESS: 'LOGIN_SUCCESS',
  LOGIN_FAIL: 'LOGIN_FAIL',
  LOGIN_INIT: 'LOGIN_INIT'
};
const initialState = {
  userData: {
    loading: false,
    data: []
  }
};

/***/ }),

/***/ "./src/modules/Admin/Login/Utils/LoginReducer.js":
/*!*******************************************************!*\
  !*** ./src/modules/Admin/Login/Utils/LoginReducer.js ***!
  \*******************************************************/
/*! exports provided: loginReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "loginReducer", function() { return loginReducer; });
/* harmony import */ var _LoginConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./LoginConstants */ "./src/modules/Admin/Login/Utils/LoginConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  LOGIN_SUCCESS,
  LOGIN_FAIL,
  LOGIN_INIT
} = _LoginConstants__WEBPACK_IMPORTED_MODULE_0__["loginConstants"];
const loginReducer = (state = _LoginConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"], {
  type,
  payload
}) => {
  switch (type) {
    case LOGIN_INIT:
      return _objectSpread(_objectSpread({}, state), {}, {
        userData: _objectSpread(_objectSpread({}, state.userData), {}, {
          loading: true
        })
      });

    case LOGIN_SUCCESS:
      return _objectSpread(_objectSpread({}, state), {}, {
        userData: _objectSpread(_objectSpread({}, state.userData), {}, {
          loading: false,
          data: payload
        })
      });

    case LOGIN_FAIL:
      return _objectSpread(_objectSpread({}, state), {}, {
        userData: _objectSpread(_objectSpread({}, state.userData), {}, {
          loading: false
        })
      });

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/modules/CheckYourEligibility/Utils/CheckYourEligibilityConstants.js":
/*!*********************************************************************************!*\
  !*** ./src/modules/CheckYourEligibility/Utils/CheckYourEligibilityConstants.js ***!
  \*********************************************************************************/
/*! exports provided: initialState, eligibilityConstants, STEPS, eligibilityStatusConstant, eligibilityStatusData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "eligibilityConstants", function() { return eligibilityConstants; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STEPS", function() { return STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "eligibilityStatusConstant", function() { return eligibilityStatusConstant; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "eligibilityStatusData", function() { return eligibilityStatusData; });
const initialState = {
  activeStepIndex: 1,
  welcomeContinue: false,
  eligibilityCheck: false,
  familyMember: '',
  monthlyIncome: '',
  eligibilityStatus: 0,
  sexOffenderStatus: true,
  methaStatus: true
};
const eligibilityConstants = {
  ELIGIBILITY_ACTIVE_INDEX: 'ELIGIBILITY_ACTIVE_INDEX',
  SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
  CONTINUE_WELCOME: 'CONTINUE_WELCOME',
  ELIGIBILITY_CHECK: 'ELIGIBILITY_CHECK',
  SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
  RESET_FORM: 'RESET_FORM',
  ELIGIBILITY_STATUS: 'ELIGIBILITY_STATUS',
  METHA_STATUS: 'METHA_STATUS',
  SEX_OFFENDER_STATUS: 'SEX_OFFENDER_STATUS'
};
const STEPS = {
  STEP1: 1,
  STEP2: 2,
  STEP3: 3,
  STEP4: 4,
  STEP5: 5,
  STEP6: 6
};
const eligibilityStatusConstant = {
  SUCCESS: 1,
  FAILED: 2,
  PENDING: 3
};
const eligibilityStatusData = {
  [eligibilityStatusConstant.SUCCESS]: {
    iconName: 'thumbs-up',
    status: 'success',
    title: 'Good news! it looks like you may be a candidate for housing assistance.',
    subTitle: "Some copy about how if you'd like to continue, we'll need more information from you, including such and such, and will take about 30 minutes. Would you like to continue?",
    subTitle2: '',
    buttonText: 'Continue',
    linkText: 'Or Not Right now'
  },
  [eligibilityStatusConstant.FAILED]: {
    iconName: 'thumbs-down',
    status: 'failed',
    title: "It doesn't look like you're a candidate for assistance at this time.",
    subTitle: "Based on the information you entered, your household doesn't meet the criteria for our housing assistance program. if you'd like to read more about eligibility requirement, you can visit our help Section, or contact us for more information.",
    subTitle2: '',
    buttonText: 'Exit',
    linkText: 'Or Try Again'
  },
  [eligibilityStatusConstant.PENDING]: {
    iconName: 'alert-triangle',
    status: 'pending',
    title: 'You may or may not be a candidate based on your income.',
    subTitle: 'Your monthly income looks like it might be too high to be eligible for assistance, but only by a small amount.',
    subTitle2: "In some situations, individuals may still be able to quality. if you'd like to find out for sure, you may continue anyway, or contact our office to speak with a representative about your eligibility.",
    buttonText: 'Exit',
    linkText: 'Or Continue Anyway'
  }
};

/***/ }),

/***/ "./src/modules/CheckYourEligibility/Utils/CheckYourEligibilityReducers.js":
/*!********************************************************************************!*\
  !*** ./src/modules/CheckYourEligibility/Utils/CheckYourEligibilityReducers.js ***!
  \********************************************************************************/
/*! exports provided: CheckYourEligibility */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CheckYourEligibility", function() { return CheckYourEligibility; });
/* harmony import */ var _CheckYourEligibilityConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CheckYourEligibilityConstants */ "./src/modules/CheckYourEligibility/Utils/CheckYourEligibilityConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  ELIGIBILITY_ACTIVE_INDEX,
  SAVE_MONTHLY_INCOME,
  SAVE_FAMILY_INFO,
  CONTINUE_WELCOME,
  ELIGIBILITY_CHECK,
  RESET_FORM,
  ELIGIBILITY_STATUS,
  METHA_STATUS,
  SEX_OFFENDER_STATUS
} = _CheckYourEligibilityConstants__WEBPACK_IMPORTED_MODULE_0__["eligibilityConstants"];
const CheckYourEligibility = (state = _CheckYourEligibilityConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"], action) => {
  switch (action.type) {
    case CONTINUE_WELCOME:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          welcomeContinue: action.payload.welcomeContinue
        });
      }

    case ELIGIBILITY_CHECK:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          eligibilityCheck: action.payload.eligibilityCheck
        });
      }

    case SAVE_FAMILY_INFO:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          familyMember: action.payload.familyMember
        });
      }

    case SAVE_MONTHLY_INCOME:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          monthlyIncome: action.payload.monthlyIncome
        });
      }

    case ELIGIBILITY_ACTIVE_INDEX:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: action.payload
        });
      }

    case RESET_FORM:
      {
        return _objectSpread({}, _CheckYourEligibilityConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"]);
      }

    case METHA_STATUS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          methaStatus: action.payload
        });
      }

    case SEX_OFFENDER_STATUS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          sexOffenderStatus: action.payload
        });
      }

    case ELIGIBILITY_STATUS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: 7,
          eligibilityStatus: action.payload
        });
      }

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/modules/CreateProfileModule/Utils/CreateProfileConstants.js":
/*!*************************************************************************!*\
  !*** ./src/modules/CreateProfileModule/Utils/CreateProfileConstants.js ***!
  \*************************************************************************/
/*! exports provided: initialState, STEPS, profileConstants */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STEPS", function() { return STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "profileConstants", function() { return profileConstants; });
const initialState = {
  activeStepIndex: 1
};
const STEPS = {
  STEP1: 1,
  STEP2: 2,
  STEP3: 3,
  STEP4: 4,
  STEP5: 5
};
const profileConstants = {
  RESET_FORM: 'RESET_FORM',
  PROFILE_ACTIVE_INDEX: 'PROFILE_ACTIVE_INDEX',
  SAVE_PROFILE: 'SAVE_PROFILE',
  SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME'
};

/***/ }),

/***/ "./src/modules/CreateProfileModule/Utils/CreateProfileReducers.js":
/*!************************************************************************!*\
  !*** ./src/modules/CreateProfileModule/Utils/CreateProfileReducers.js ***!
  \************************************************************************/
/*! exports provided: CreateProfile */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreateProfile", function() { return CreateProfile; });
/* harmony import */ var _CreateProfileConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./CreateProfileConstants */ "./src/modules/CreateProfileModule/Utils/CreateProfileConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  RESET_FORM,
  PROFILE_ACTIVE_INDEX,
  SAVE_PROFILE
} = _CreateProfileConstants__WEBPACK_IMPORTED_MODULE_0__["profileConstants"];
const CreateProfile = (state = _CreateProfileConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"], action) => {
  switch (action.type) {
    case PROFILE_ACTIVE_INDEX:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: action.payload
        });
      }

    case SAVE_PROFILE:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          user_profile_data: _objectSpread(_objectSpread({}, state === null || state === void 0 ? void 0 : state.user_profile_data), action.payload)
        });
      }

    case RESET_FORM:
      {
        return _objectSpread({}, _CreateProfileConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"]);
      }

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/modules/HouseHoldModule/Utils/HouseHoldConstants.js":
/*!*****************************************************************!*\
  !*** ./src/modules/HouseHoldModule/Utils/HouseHoldConstants.js ***!
  \*****************************************************************/
/*! exports provided: initialState, STEPS, houseHoldConstants, MEMBER_FORM_FILED, HOUSE_HOLD_FORMS_COUNTS, OTHER_FORMS, statusCardData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STEPS", function() { return STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "houseHoldConstants", function() { return houseHoldConstants; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MEMBER_FORM_FILED", function() { return MEMBER_FORM_FILED; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HOUSE_HOLD_FORMS_COUNTS", function() { return HOUSE_HOLD_FORMS_COUNTS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OTHER_FORMS", function() { return OTHER_FORMS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "statusCardData", function() { return statusCardData; });
const initialState = {
  activeStepIndex: 1,
  infoContinue: false,
  additionalMember: 0,
  memberFormSteps: [],
  activeMember: 1,
  houseHoldFormCount: 1,
  additionalFormInfo: {},
  reviewContinue: false,
  accommodations: {},
  shelterInfo: {},
  militaryInfo: {},
  otherInfo: {},
  reviewDetailConfirm: false,
  programs: []
};
const STEPS = {
  STEP1: 1,
  STEP2: 2,
  STEP3: 3,
  STEP4: 4,
  STEP5: 5,
  STEP6: 6,
  STEP7: 7,
  STEP8: 8,
  STEP9: 9,
  STEP10: 10
};
const houseHoldConstants = {
  RESET_FORM: 'RESET_FORM',
  HOUSE_HOLD_ACTIVE_INDEX: 'HOUSE_HOLD_ACTIVE_INDEX',
  HOUSE_HOLD_INFO_CONTINUE: 'HOUSE_HOLD_INFO_CONTINUE',
  HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER: 'HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER',
  HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM: 'HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM',
  HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM: 'HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM',
  SET_ADDITIONAL_FORM_STEP: 'SET_ADDITIONAL_FORM_STEP',
  BACK_ADDITIONAL_FORM_STEP2: 'BACK_ADDITIONAL_FORM_STEP2',
  BACK_ADDITIONAL_FORM_STEP1: 'BACK_ADDITIONAL_FORM_STEP1',
  RESET_ADDITIONAL_MEMBER: 'RESET_ADDITIONAL_MEMBER',
  ADDITIONAL_REVIEW_CONTINUE: 'ADDITIONAL_REVIEW_CONTINUE',
  SAVE_ACCOMMODATIONS: 'SAVE_ACCOMMODATIONS',
  SAVE_SHELTER_INFO: 'SAVE_SHELTER_INFO',
  SAVE_MILITARY_IFO: 'SAVE_MILITARY_IFO',
  SAVE_OTHER_INFO: 'SAVE_OTHER_INFO',
  ADD_MORE_MEMBER: 'ADD_MORE_MEMBER',
  REMOVE_MEMBER: 'REMOVE_MEMBER',
  EDIT_MEMBER: 'EDIT_MEMBER',
  RENDER_EDIT_FORMS: 'RENDER_EDIT_FORMS',
  CONFIRM_REVIEW_DETAIL: 'CONFIRM_REVIEW_DETAIL',
  SAVE_PROGRAMS: 'SAVE_PROGRAMS'
};
const MEMBER_FORM_FILED = {
  firstName: 'fname',
  middleName: 'mname',
  lastName: 'lname',
  maidenName: 'maiden_name',
  relationShipId: 'relationship_id',
  citizenShipId: 'citizenship_id',
  dateOfBirth: 'dob',
  gender: 'gender_id',
  socialSecurityNumber: 'social_security_number',
  yearlyIncome: 'yearly_income',
  payFrequencyId: 'pay_frequency_id',
  paycheckAmount: 'paycheck_amount',
  isDisabled: 'is_disabled',
  isFulltimeStudent: 'is_fulltime_student',
  isStudentNextYear: 'is_student_next_year',
  lifetimeSexOffenderReg: 'lifetime_sex_offender_reg',
  raceEthnics: 'raceEthnics'
};
const HOUSE_HOLD_FORMS_COUNTS = {
  FORM1: 1,
  FORM2: 2
};
const OTHER_FORMS = {
  SAVE_ACCOMMODATION_FORM_INFO: 'saveAccommodation',
  SAVE_SHELTER_FORM_INFO: 'saveShelterInfo',
  SAVE_MILITARY_FORM_INFO: 'saveMilitaryInfo',
  SAVE_OTHER_FORM_INFO: 'saveOtherInfo'
};
const statusCardData = {
  title: "It doesn't look like you're a candidate for any programs.",
  subTitle: "We're sorry. based on the information you've provided you don't meet the criteria for any of our programs.",
  subTitle2: 'You can review the eligibility criteria and learn more about the programs here. If you think there is a mistake on eligibility. You can contact us for help.',
  showButton: true,
  buttonText: 'Exit to Dashboard',
  buttonType: 'white',
  iconName: 'thumbs-down',
  iconStatus: 'failed'
};

/***/ }),

/***/ "./src/modules/HouseHoldModule/Utils/HouseHoldReducers.js":
/*!****************************************************************!*\
  !*** ./src/modules/HouseHoldModule/Utils/HouseHoldReducers.js ***!
  \****************************************************************/
/*! exports provided: HouseHoldReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HouseHoldReducer", function() { return HouseHoldReducer; });
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _HouseHoldConstants__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./HouseHoldConstants */ "./src/modules/HouseHoldModule/Utils/HouseHoldConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const {
  RESET_FORM,
  HOUSE_HOLD_ACTIVE_INDEX,
  HOUSE_HOLD_INFO_CONTINUE,
  HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER,
  HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM,
  HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM,
  SET_ADDITIONAL_FORM_STEP,
  BACK_ADDITIONAL_FORM_STEP2,
  BACK_ADDITIONAL_FORM_STEP1,
  RESET_ADDITIONAL_MEMBER,
  ADDITIONAL_REVIEW_CONTINUE,
  SAVE_ACCOMMODATIONS,
  SAVE_SHELTER_INFO,
  SAVE_MILITARY_IFO,
  SAVE_OTHER_INFO,
  ADD_MORE_MEMBER,
  REMOVE_MEMBER,
  EDIT_MEMBER,
  RENDER_EDIT_FORMS,
  CONFIRM_REVIEW_DETAIL,
  SAVE_PROGRAMS
} = _HouseHoldConstants__WEBPACK_IMPORTED_MODULE_1__["houseHoldConstants"];

const convertBooleanToString = value => {
  return value ? 'true' : 'false';
};

const getRaceEthnicData = raceEthnics => {
  let raceEthnicsArr = [];
  raceEthnics === null || raceEthnics === void 0 ? void 0 : raceEthnics.values.forEach(value => {
    raceEthnicsArr = [...raceEthnicsArr, value === null || value === void 0 ? void 0 : value.id];
  });
  return raceEthnicsArr;
};

const HouseHoldReducer = (state = _HouseHoldConstants__WEBPACK_IMPORTED_MODULE_1__["initialState"], action) => {
  const {
    additionalFormInfo
  } = state;

  switch (action.type) {
    case HOUSE_HOLD_ACTIVE_INDEX:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: action.payload
        });
      }

    case HOUSE_HOLD_INFO_CONTINUE:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          infoContinue: action.payload.infoContinue
        });
      }

    case HOUSE_HOLD_SAVE_ADDITIONAL_MEMBER:
      {
        let stepsArr = new Array(action.payload.additionalMember).fill(1);
        stepsArr.forEach((item, index) => {
          stepsArr[index] = index + 1;
        });
        return _objectSpread(_objectSpread({}, state), {}, {
          additionalMember: action.payload.additionalMember,
          memberFormSteps: stepsArr,
          houseHoldFormCount: 1,
          activeMember: 1
        });
      }

    case HOUSE_HOLD_SAVE_FIRST_ADDITIONAL_FORM:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          additionalFormInfo: _objectSpread(_objectSpread({}, additionalFormInfo), {}, {
            [action.payload.activeMember]: _objectSpread(_objectSpread({}, additionalFormInfo[action.payload.activeMember]), action.payload)
          }),
          houseHoldFormCount: 2
        });
      }

    case HOUSE_HOLD_SAVE_FINAL_ADDITIONAL_FORM:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          additionalFormInfo: _objectSpread(_objectSpread({}, additionalFormInfo), {}, {
            [action.payload.activeMember]: _objectSpread(_objectSpread({}, additionalFormInfo[action.payload.activeMember]), action.payload)
          }),
          houseHoldFormCount: 1
        });
      }

    case SET_ADDITIONAL_FORM_STEP:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeMember: action.payload
        });
      }

    case BACK_ADDITIONAL_FORM_STEP2:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          houseHoldFormCount: 1
        });
      }

    case BACK_ADDITIONAL_FORM_STEP1:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          houseHoldFormCount: 2
        });
      }

    case RESET_ADDITIONAL_MEMBER:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          memberFormSteps: [],
          activeMember: 0
        });
      }

    case ADDITIONAL_REVIEW_CONTINUE:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          reviewContinue: action.payload.reviewContinue
        });
      }

    case SAVE_ACCOMMODATIONS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          accommodations: action.payload
        });
      }

    case SAVE_SHELTER_INFO:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          shelterInfo: action.payload
        });
      }

    case SAVE_MILITARY_IFO:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          militaryInfo: action.payload
        });
      }

    case SAVE_OTHER_INFO:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          otherInfo: action.payload
        });
      }

    case RESET_FORM:
      {
        return _objectSpread({}, _HouseHoldConstants__WEBPACK_IMPORTED_MODULE_1__["initialState"]);
      }

    case ADD_MORE_MEMBER:
      {
        let stepsArr = new Array(Object.keys(additionalFormInfo).length + 1).fill(1);
        stepsArr.forEach((item, index) => {
          stepsArr[index] = index + 1;
        });
        return _objectSpread(_objectSpread({}, state), {}, {
          additionalMember: stepsArr.length || 1,
          memberFormSteps: stepsArr,
          houseHoldFormCount: 1,
          activeMember: stepsArr.length || 1,
          activeStepIndex: 2
        });
      }

    case REMOVE_MEMBER:
      {
        const additionalFormInfoData = _objectSpread({}, additionalFormInfo);

        const removedMember = lodash__WEBPACK_IMPORTED_MODULE_0___default.a.omit(additionalFormInfoData, action.payload);

        return _objectSpread(_objectSpread({}, state), {}, {
          additionalFormInfo: _objectSpread({}, removedMember)
        });
      }

    case EDIT_MEMBER:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          houseHoldFormCount: 1,
          activeStepIndex: 2,
          activeMember: action.payload.activeMember
        });
      }

    case RENDER_EDIT_FORMS:
      {
        const existMember = [...action.payload];
        let stepsArr = new Array(action.payload.length).fill(1);
        stepsArr.forEach((item, index) => {
          stepsArr[index] = index + 1;
        });
        let memberInfo = {};
        existMember.forEach((item, index) => {
          memberInfo = _objectSpread(_objectSpread({}, memberInfo), {}, {
            [index + 1]: _objectSpread(_objectSpread({}, item), {}, {
              is_disabled: convertBooleanToString(item.is_disabled),
              is_fulltime_student: convertBooleanToString(item.is_fulltime_student),
              is_student_next_year: convertBooleanToString(item.is_student_next_year),
              lifetime_sex_offender_reg: convertBooleanToString(item.lifetime_sex_offender_reg),
              raceEthnics: getRaceEthnicData(item.race_ethinic)
            })
          });
        });
        return _objectSpread(_objectSpread({}, state), {}, {
          additionalMember: action.payload.length,
          memberFormSteps: stepsArr,
          additionalFormInfo: _objectSpread({}, memberInfo)
        });
      }

    case CONFIRM_REVIEW_DETAIL:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          reviewDetailConfirm: action.payload.reviewDetailConfirm
        });
      }

    case SAVE_PROGRAMS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          programs: action.payload
        });
      }

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/modules/HouseholdAssets/Utils/HouseholdAssetsConstants.js":
/*!***********************************************************************!*\
  !*** ./src/modules/HouseholdAssets/Utils/HouseholdAssetsConstants.js ***!
  \***********************************************************************/
/*! exports provided: initialState, householdAssetsConstants, STEPS, householdAssetsStatusConstant, householdAssetsStatusData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "householdAssetsConstants", function() { return householdAssetsConstants; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STEPS", function() { return STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "householdAssetsStatusConstant", function() { return householdAssetsStatusConstant; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "householdAssetsStatusData", function() { return householdAssetsStatusData; });
const initialState = {
  activeStepIndex: 1,
  welcomeContinue: false,
  householdAssetsCheck: false,
  reviewStatus: 0
};
const householdAssetsConstants = {
  HOUSEHOLD_ASSETS_ACTIVE_INDEX: 'HOUSEHOLD_ASSETS_ACTIVE_INDEX',
  SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
  CONTINUE_WELCOME: 'CONTINUE_WELCOME',
  HOUSEHOLD_ASSETS_CHECK: 'HOUSEHOLD_ASSETS_CHECK',
  SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
  RESET_FORM: 'RESET_FORM',
  HOUSEHOLD_ASSETS_STATUS: 'HOUSEHOLD_ASSETS_STATUS'
};
const STEPS = {
  STEP1: 1,
  STEP2: 2,
  STEP3: 3,
  STEP4: 4,
  STEP5: 5,
  STEP6: 6
};
const householdAssetsStatusConstant = {
  SUCCESS: 1,
  FAILED: 2,
  PENDING: 3
};
const householdAssetsStatusData = {};

/***/ }),

/***/ "./src/modules/HouseholdAssets/Utils/HouseholdAssetsReducers.js":
/*!**********************************************************************!*\
  !*** ./src/modules/HouseholdAssets/Utils/HouseholdAssetsReducers.js ***!
  \**********************************************************************/
/*! exports provided: HouseholdAssets */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HouseholdAssets", function() { return HouseholdAssets; });
/* harmony import */ var _HouseholdAssetsConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HouseholdAssetsConstants */ "./src/modules/HouseholdAssets/Utils/HouseholdAssetsConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  HOUSEHOLD_ASSETS_ACTIVE_INDEX,
  CONTINUE_WELCOME,
  HOUSEHOLD_ASSETS_CHECK,
  RESET_FORM,
  HOUSEHOLD_ASSETS_STATUS
} = _HouseholdAssetsConstants__WEBPACK_IMPORTED_MODULE_0__["householdAssetsConstants"];
const HouseholdAssets = (state = _HouseholdAssetsConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"], action) => {
  switch (action.type) {
    case CONTINUE_WELCOME:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          welcomeContinue: action.payload.welcomeContinue
        });
      }

    case HOUSEHOLD_ASSETS_CHECK:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          householdAssetsCheck: action.payload.householdAssetsCheck
        });
      }

    case HOUSEHOLD_ASSETS_ACTIVE_INDEX:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: action.payload
        });
      }

    case RESET_FORM:
      {
        return _objectSpread({}, _HouseholdAssetsConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"]);
      }

    case HOUSEHOLD_ASSETS_STATUS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: 5,
          householdAssetsStatus: action.payload
        });
      }

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/modules/HouseholdIncome/Utils/HouseholdIncomeConstants.js":
/*!***********************************************************************!*\
  !*** ./src/modules/HouseholdIncome/Utils/HouseholdIncomeConstants.js ***!
  \***********************************************************************/
/*! exports provided: initialState, householdIncomeConstants, STEPS, householdIncomeStatusConstant, householdIncomeStatusData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "householdIncomeConstants", function() { return householdIncomeConstants; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STEPS", function() { return STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "householdIncomeStatusConstant", function() { return householdIncomeStatusConstant; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "householdIncomeStatusData", function() { return householdIncomeStatusData; });
const initialState = {
  activeStepIndex: 1,
  welcomeContinue: false,
  householdIncomeCheck: false,
  familyMember: '',
  monthlyIncome: '',
  reviewStatus: 0
};
const householdIncomeConstants = {
  HOUSEHOLD_ACTIVE_INDEX: 'HOUSEHOLD_ACTIVE_INDEX',
  SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
  CONTINUE_WELCOME: 'CONTINUE_WELCOME',
  HOUSEHOLD_CHECK: 'HOUSEHOLD_CHECK',
  SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
  RESET_FORM: 'RESET_FORM',
  HOUSEHOLD_STATUS: 'HOUSEHOLD_STATUS'
};
const STEPS = {
  STEP1: 1,
  STEP2: 2,
  STEP3: 3,
  STEP4: 4,
  STEP5: 5,
  STEP6: 6
};
const householdIncomeStatusConstant = {
  SUCCESS: 1,
  FAILED: 2,
  PENDING: 3
};
const householdIncomeStatusData = {};

/***/ }),

/***/ "./src/modules/HouseholdIncome/Utils/HouseholdIncomeReducers.js":
/*!**********************************************************************!*\
  !*** ./src/modules/HouseholdIncome/Utils/HouseholdIncomeReducers.js ***!
  \**********************************************************************/
/*! exports provided: HouseholdIncome */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HouseholdIncome", function() { return HouseholdIncome; });
/* harmony import */ var _HouseholdIncomeConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HouseholdIncomeConstants */ "./src/modules/HouseholdIncome/Utils/HouseholdIncomeConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  HOUSEHOLD_ACTIVE_INDEX,
  CONTINUE_WELCOME,
  HOUSEHOLD_CHECK,
  RESET_FORM,
  HOUSEHOLD_STATUS
} = _HouseholdIncomeConstants__WEBPACK_IMPORTED_MODULE_0__["householdIncomeConstants"];
const HouseholdIncome = (state = _HouseholdIncomeConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"], action) => {
  switch (action.type) {
    case CONTINUE_WELCOME:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          welcomeContinue: action.payload.welcomeContinue
        });
      }

    case HOUSEHOLD_CHECK:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          householdIncomeCheck: action.payload.householdIncomeCheck
        });
      }

    case HOUSEHOLD_ACTIVE_INDEX:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: action.payload
        });
      }

    case RESET_FORM:
      {
        return _objectSpread({}, _HouseholdIncomeConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"]);
      }

    case HOUSEHOLD_STATUS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: 5,
          householdIncomeStatus: action.payload
        });
      }

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesConstants.js":
/*!*****************************************************************************************!*\
  !*** ./src/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesConstants.js ***!
  \*****************************************************************************************/
/*! exports provided: initialState, householdSpecialExpensesConstants, STEPS, householdSpecialExpensesStatusConstant, householdSpecialExpensesStatusData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "householdSpecialExpensesConstants", function() { return householdSpecialExpensesConstants; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STEPS", function() { return STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "householdSpecialExpensesStatusConstant", function() { return householdSpecialExpensesStatusConstant; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "householdSpecialExpensesStatusData", function() { return householdSpecialExpensesStatusData; });
const initialState = {
  activeStepIndex: 1,
  welcomeContinue: false,
  householdSpecialExpensesCheck: false,
  reviewStatus: 0
};
const householdSpecialExpensesConstants = {
  HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX: 'HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX',
  SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
  CONTINUE_WELCOME: 'CONTINUE_WELCOME',
  HOUSEHOLD_SPECIAL_EXPENSES_CHECK: 'HOUSEHOLD_SPECIAL_EXPENSES_CHECK',
  SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
  RESET_FORM: 'RESET_FORM',
  HOUSEHOLD_SPECIAL_EXPENSES_STATUS: 'HOUSEHOLD_SPECIAL_EXPENSES_STATUS'
};
const STEPS = {
  STEP1: 1,
  STEP2: 2,
  STEP3: 3,
  STEP4: 4,
  STEP5: 5
};
const householdSpecialExpensesStatusConstant = {
  SUCCESS: 1,
  FAILED: 2,
  PENDING: 3
};
const householdSpecialExpensesStatusData = {};

/***/ }),

/***/ "./src/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesReducers.js":
/*!****************************************************************************************!*\
  !*** ./src/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesReducers.js ***!
  \****************************************************************************************/
/*! exports provided: HouseholdSpecialExpenses */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HouseholdSpecialExpenses", function() { return HouseholdSpecialExpenses; });
/* harmony import */ var _HouseholdSpecialExpensesConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HouseholdSpecialExpensesConstants */ "./src/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX,
  CONTINUE_WELCOME,
  HOUSEHOLD_SPECIAL_EXPENSES_CHECK,
  RESET_FORM,
  HOUSEHOLD_SPECIAL_EXPENSES_STATUS
} = _HouseholdSpecialExpensesConstants__WEBPACK_IMPORTED_MODULE_0__["householdSpecialExpensesConstants"];
const HouseholdSpecialExpenses = (state = _HouseholdSpecialExpensesConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"], action) => {
  switch (action.type) {
    case CONTINUE_WELCOME:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          welcomeContinue: action.payload.welcomeContinue
        });
      }

    case HOUSEHOLD_SPECIAL_EXPENSES_CHECK:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          householdSpecialExpensesCheck: action.payload.householdSpecialExpensesCheck
        });
      }

    case HOUSEHOLD_SPECIAL_EXPENSES_ACTIVE_INDEX:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: action.payload
        });
      }

    case RESET_FORM:
      {
        return _objectSpread({}, _HouseholdSpecialExpensesConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"]);
      }

    case HOUSEHOLD_SPECIAL_EXPENSES_STATUS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: 5,
          householdSpecialExpensesStatus: action.payload
        });
      }

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/modules/RentAffordability/Utils/RentAffordabilityConstants.js":
/*!***************************************************************************!*\
  !*** ./src/modules/RentAffordability/Utils/RentAffordabilityConstants.js ***!
  \***************************************************************************/
/*! exports provided: initialState, rentAffordabilityConstants, STEPS, rentAffordabilityStatusConstant, rentAffordabilityStatusData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rentAffordabilityConstants", function() { return rentAffordabilityConstants; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STEPS", function() { return STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rentAffordabilityStatusConstant", function() { return rentAffordabilityStatusConstant; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "rentAffordabilityStatusData", function() { return rentAffordabilityStatusData; });
const initialState = {
  activeStepIndex: 1,
  welcomeContinue: false,
  rentAffordabilityCheck: false,
  reviewStatus: 0
};
const rentAffordabilityConstants = {
  RENT_AFFORDABILITY_ACTIVE_INDEX: 'RENT_AFFORDABILITY_ACTIVE_INDEX',
  SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
  CONTINUE_WELCOME: 'CONTINUE_WELCOME',
  RENT_AFFORDABILITY_CHECK: 'RENT_AFFORDABILITY_CHECK',
  SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
  RESET_FORM: 'RESET_FORM',
  RENT_AFFORDABILITY_STATUS: 'RENT_AFFORDABILITY_STATUS'
};
const STEPS = {
  STEP1: 1,
  STEP2: 2
};
const rentAffordabilityStatusConstant = {
  SUCCESS: 1,
  FAILED: 2,
  PENDING: 3
};
const rentAffordabilityStatusData = {};

/***/ }),

/***/ "./src/modules/RentAffordability/Utils/RentAffordabilityReducers.js":
/*!**************************************************************************!*\
  !*** ./src/modules/RentAffordability/Utils/RentAffordabilityReducers.js ***!
  \**************************************************************************/
/*! exports provided: RentAffordability */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RentAffordability", function() { return RentAffordability; });
/* harmony import */ var _RentAffordabilityConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./RentAffordabilityConstants */ "./src/modules/RentAffordability/Utils/RentAffordabilityConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  RENT_AFFORDABILITY_ACTIVE_INDEX,
  CONTINUE_WELCOME,
  RENT_AFFORDABILITY_CHECK,
  RESET_FORM,
  RENT_AFFORDABILITY_STATUS
} = _RentAffordabilityConstants__WEBPACK_IMPORTED_MODULE_0__["rentAffordabilityConstants"];
const RentAffordability = (state = _RentAffordabilityConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"], action) => {
  switch (action.type) {
    case CONTINUE_WELCOME:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          welcomeContinue: action.payload.welcomeContinue
        });
      }

    case RENT_AFFORDABILITY_CHECK:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          rentAffordabilityCheck: action.payload.rentAffordabilityCheck
        });
      }

    case RENT_AFFORDABILITY_ACTIVE_INDEX:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: action.payload
        });
      }

    case RESET_FORM:
      {
        return _objectSpread({}, _RentAffordabilityConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"]);
      }

    case RENT_AFFORDABILITY_STATUS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: 5,
          rentAffordabilityStatus: action.payload
        });
      }

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/modules/ReviewApplication/Utils/ReviewApplicationConstants.js":
/*!***************************************************************************!*\
  !*** ./src/modules/ReviewApplication/Utils/ReviewApplicationConstants.js ***!
  \***************************************************************************/
/*! exports provided: initialState, reviewConstants, STEPS, reviewStatusConstant, reviewStatusData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reviewConstants", function() { return reviewConstants; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STEPS", function() { return STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reviewStatusConstant", function() { return reviewStatusConstant; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "reviewStatusData", function() { return reviewStatusData; });
const initialState = {
  activeStepIndex: 1,
  welcomeContinue: false,
  reviewCheck: false,
  familyMember: '',
  monthlyIncome: '',
  reviewStatus: 0
};
const reviewConstants = {
  REVIEW_ACTIVE_INDEX: 'REVIEW_ACTIVE_INDEX',
  SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
  CONTINUE_WELCOME: 'CONTINUE_WELCOME',
  REVIEW_CHECK: 'REVIEW_CHECK',
  SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
  RESET_FORM: 'RESET_FORM',
  REVIEW_STATUS: 'REVIEW_STATUS'
};
const STEPS = {
  STEP1: 1,
  STEP2: 2,
  STEP3: 3,
  STEP4: 4,
  STEP5: 5,
  STEP6: 6,
  STEP7: 7,
  STEP8: 8,
  STEP9: 9
};
const reviewStatusConstant = {
  SUCCESS: 1,
  FAILED: 2,
  PENDING: 3
};
const reviewStatusData = {};

/***/ }),

/***/ "./src/modules/ReviewApplication/Utils/ReviewApplicationReducers.js":
/*!**************************************************************************!*\
  !*** ./src/modules/ReviewApplication/Utils/ReviewApplicationReducers.js ***!
  \**************************************************************************/
/*! exports provided: ReviewApplication */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReviewApplication", function() { return ReviewApplication; });
/* harmony import */ var _ReviewApplicationConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ReviewApplicationConstants */ "./src/modules/ReviewApplication/Utils/ReviewApplicationConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  REVIEW_ACTIVE_INDEX,
  CONTINUE_WELCOME,
  REVIEW_CHECK,
  RESET_FORM,
  REVIEW_STATUS
} = _ReviewApplicationConstants__WEBPACK_IMPORTED_MODULE_0__["reviewConstants"];
const ReviewApplication = (state = _ReviewApplicationConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"], action) => {
  switch (action.type) {
    case CONTINUE_WELCOME:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          welcomeContinue: action.payload.welcomeContinue
        });
      }

    case REVIEW_CHECK:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          reviewCheck: action.payload.reviewCheck
        });
      }

    case REVIEW_ACTIVE_INDEX:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: action.payload
        });
      }

    case RESET_FORM:
      {
        return _objectSpread({}, _ReviewApplicationConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"]);
      }

    case REVIEW_STATUS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: 5,
          reviewStatus: action.payload
        });
      }

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/modules/YourDocuments/Utils/YourDocumentsConstants.js":
/*!*******************************************************************!*\
  !*** ./src/modules/YourDocuments/Utils/YourDocumentsConstants.js ***!
  \*******************************************************************/
/*! exports provided: initialState, yourDocumentsConstants, STEPS, yourDocumentsStatusConstant, yourDocumentsStatusData */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initialState", function() { return initialState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yourDocumentsConstants", function() { return yourDocumentsConstants; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "STEPS", function() { return STEPS; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yourDocumentsStatusConstant", function() { return yourDocumentsStatusConstant; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "yourDocumentsStatusData", function() { return yourDocumentsStatusData; });
const initialState = {
  activeStepIndex: 1,
  welcomeContinue: false,
  yourDocumentsCheck: false,
  reviewStatus: 0
};
const yourDocumentsConstants = {
  YOUR_DOCUMENTS_ACTIVE_INDEX: 'YOUR_DOCUMENTS_ACTIVE_INDEX',
  SAVE_FAMILY_INFO: 'SAVE_FAMILY_INFO',
  CONTINUE_WELCOME: 'CONTINUE_WELCOME',
  YOUR_DOCUMENTS_CHECK: 'YOUR_DOCUMENTS_CHECK',
  SAVE_MONTHLY_INCOME: 'SAVE_MONTHLY_INCOME',
  RESET_FORM: 'RESET_FORM',
  YOUR_DOCUMENTS_STATUS: 'YOUR_DOCUMENTS_STATUS'
};
const STEPS = {
  STEP1: 1,
  STEP2: 2
};
const yourDocumentsStatusConstant = {
  SUCCESS: 1,
  FAILED: 2,
  PENDING: 3
};
const yourDocumentsStatusData = {};

/***/ }),

/***/ "./src/modules/YourDocuments/Utils/YourDocumentsReducers.js":
/*!******************************************************************!*\
  !*** ./src/modules/YourDocuments/Utils/YourDocumentsReducers.js ***!
  \******************************************************************/
/*! exports provided: YourDocuments */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "YourDocuments", function() { return YourDocuments; });
/* harmony import */ var _YourDocumentsConstants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./YourDocumentsConstants */ "./src/modules/YourDocuments/Utils/YourDocumentsConstants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }


const {
  YOUR_DOCUMENTS_ACTIVE_INDEX,
  CONTINUE_WELCOME,
  YOUR_DOCUMENTS_CHECK,
  RESET_FORM,
  YOUR_DOCUMENTS_STATUS
} = _YourDocumentsConstants__WEBPACK_IMPORTED_MODULE_0__["yourDocumentsConstants"];
const YourDocuments = (state = _YourDocumentsConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"], action) => {
  switch (action.type) {
    case CONTINUE_WELCOME:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          welcomeContinue: action.payload.welcomeContinue
        });
      }

    case YOUR_DOCUMENTS_CHECK:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          yourDocumentsCheck: action.payload.yourDocumentsCheck
        });
      }

    case YOUR_DOCUMENTS_ACTIVE_INDEX:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: action.payload
        });
      }

    case RESET_FORM:
      {
        return _objectSpread({}, _YourDocumentsConstants__WEBPACK_IMPORTED_MODULE_0__["initialState"]);
      }

    case YOUR_DOCUMENTS_STATUS:
      {
        return _objectSpread(_objectSpread({}, state), {}, {
          activeStepIndex: 5,
          yourDocumentsStatus: action.payload
        });
      }

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/pages/_app.js":
/*!***************************!*\
  !*** ./src/pages/_app.js ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MyApp; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _date_io_date_fns__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @date-io/date-fns */ "@date-io/date-fns");
/* harmony import */ var _date_io_date_fns__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_date_io_date_fns__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/CssBaseline */ "@material-ui/core/CssBaseline");
/* harmony import */ var _material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _material_ui_pickers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/pickers */ "@material-ui/pickers");
/* harmony import */ var _material_ui_pickers__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/head */ "next/head");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "react-redux");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-toast-notifications */ "react-toast-notifications");
/* harmony import */ var react_toast_notifications__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_toast_notifications__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! redux-persist */ "redux-persist");
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! redux-persist/integration/react */ "redux-persist/integration/react");
/* harmony import */ var redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var shared_redux_store__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! shared/redux/store */ "./src/shared/redux/store.js");
/* harmony import */ var shared_styles_globals_scss__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! shared/styles/globals.scss */ "./src/shared/styles/globals.scss");
/* harmony import */ var shared_styles_globals_scss__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(shared_styles_globals_scss__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var shared_utils_theme__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! shared/utils/theme */ "./src/shared/utils/theme.js");
/* harmony import */ var _shared_utils_globalStyles__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ~/shared/utils/globalStyles */ "./src/shared/utils/globalStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\pages\\_app.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }
















/**
 * Name : App
 * Desc : Render App
 **/

function MyApp(props) {
  const {
    Component,
    pageProps
  } = props;
  const store = Object(shared_redux_store__WEBPACK_IMPORTED_MODULE_12__["useStore"])(pageProps.initialReduxState);
  const persistor = Object(redux_persist__WEBPACK_IMPORTED_MODULE_10__["persistStore"])(store, {}, function () {
    persistor.persist();
  }); // var hideWidget = (window.location.href.indexOf("Home") > -1) ? true : false;
  // Remove the server-side injected CSS.

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react__WEBPACK_IMPORTED_MODULE_7___default.a.Fragment, {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_head__WEBPACK_IMPORTED_MODULE_5___default.a, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("title", {
        children: "Hacep"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
        rel: "icon",
        type: "image/png",
        sizes: "32x32",
        href: "/Client_Logo.png"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
        name: "viewport",
        content: "minimum-scale=1, initial-scale=1, width=device-width"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
        async: true,
        src: "https://global.localizecdn.com/localize.js"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
        children: `!function(a){if(!a.Localize){a.Localize={};
                    for(var e=["translate","untranslate","phrase","initialize","translatePage","setLanguage","getLanguage","getSourceLanguage","detectLanguage","getAvailableLanguages","untranslatePage","bootstrap","prefetch","on","off","hideWidget","showWidget"],
                    t=0;t<e.length;t++)a.Localize[e[t]]=function(){}}}(window);`
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 43,
        columnNumber: 17
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("script", {
        children: `Localize.initialize({ key: '6744e827e2252', rememberLanguage: true, });`
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 48,
        columnNumber: 17
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 13
    }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_toast_notifications__WEBPACK_IMPORTED_MODULE_9__["ToastProvider"], {
      autoDismiss: true,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__["ThemeProvider"], {
        theme: shared_utils_theme__WEBPACK_IMPORTED_MODULE_14__["default"],
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_utils_globalStyles__WEBPACK_IMPORTED_MODULE_15__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 56,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_CssBaseline__WEBPACK_IMPORTED_MODULE_2___default.a, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 21
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_redux__WEBPACK_IMPORTED_MODULE_8__["Provider"], {
          store: store,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(redux_persist_integration_react__WEBPACK_IMPORTED_MODULE_11__["PersistGate"], {
            loading: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              children: "loading"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 59,
              columnNumber: 47
            }, this),
            persistor: persistor,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_pickers__WEBPACK_IMPORTED_MODULE_4__["MuiPickersUtilsProvider"], {
              utils: _date_io_date_fns__WEBPACK_IMPORTED_MODULE_1___default.a,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Component, _objectSpread({}, pageProps), void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 61,
                columnNumber: 33
              }, this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 60,
              columnNumber: 29
            }, this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 59,
            columnNumber: 25
          }, this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 21
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 54,
        columnNumber: 17
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 53,
      columnNumber: 13
    }, this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 33,
    columnNumber: 9
  }, this);
}
MyApp.propTypes = {
  Component: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.elementType.isRequired,
  pageProps: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.object.isRequired
};

/***/ }),

/***/ "./src/shared/redux/constants.js":
/*!***************************************!*\
  !*** ./src/shared/redux/constants.js ***!
  \***************************************/
/*! exports provided: TICK, INCREMENT, DECREMENT, RESET */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TICK", function() { return TICK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "INCREMENT", function() { return INCREMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DECREMENT", function() { return DECREMENT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RESET", function() { return RESET; });
// REDUX ACTION TYPES
const TICK = 'TICK';
const INCREMENT = 'INCREMENT';
const DECREMENT = 'DECREMENT';
const RESET = 'RESET';

/***/ }),

/***/ "./src/shared/redux/exampleReducer.js":
/*!********************************************!*\
  !*** ./src/shared/redux/exampleReducer.js ***!
  \********************************************/
/*! exports provided: counterReducer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "counterReducer", function() { return counterReducer; });
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./constants */ "./src/shared/redux/constants.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // INITIAL TIMER STATE

const initialState = {
  counter: 0
}; // COUNTER REDUCER

const counterReducer = (state = initialState, {
  type
}) => {
  switch (type) {
    case _constants__WEBPACK_IMPORTED_MODULE_0__["INCREMENT"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        counter: state.counter + 1
      });

    case _constants__WEBPACK_IMPORTED_MODULE_0__["DECREMENT"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        counter: state.counter - 1
      });

    case _constants__WEBPACK_IMPORTED_MODULE_0__["RESET"]:
      return _objectSpread(_objectSpread({}, state), {}, {
        counter: 0
      });

    default:
      return state;
  }
};

/***/ }),

/***/ "./src/shared/redux/reducers.js":
/*!**************************************!*\
  !*** ./src/shared/redux/reducers.js ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux-persist */ "redux-persist");
/* harmony import */ var redux_persist__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux_persist__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! redux-persist/lib/storage */ "redux-persist/lib/storage");
/* harmony import */ var redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _modules_Admin_Login_Utils_LoginReducer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ~/modules/Admin/Login/Utils/LoginReducer */ "./src/modules/Admin/Login/Utils/LoginReducer.js");
/* harmony import */ var _modules_CheckYourEligibility_Utils_CheckYourEligibilityReducers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ~/modules/CheckYourEligibility/Utils/CheckYourEligibilityReducers */ "./src/modules/CheckYourEligibility/Utils/CheckYourEligibilityReducers.js");
/* harmony import */ var _modules_ReviewApplication_Utils_ReviewApplicationReducers__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/modules/ReviewApplication/Utils/ReviewApplicationReducers */ "./src/modules/ReviewApplication/Utils/ReviewApplicationReducers.js");
/* harmony import */ var _modules_HouseholdIncome_Utils_HouseholdIncomeReducers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ~/modules/HouseholdIncome/Utils/HouseholdIncomeReducers */ "./src/modules/HouseholdIncome/Utils/HouseholdIncomeReducers.js");
/* harmony import */ var _modules_HouseholdAssets_Utils_HouseholdAssetsReducers__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/modules/HouseholdAssets/Utils/HouseholdAssetsReducers */ "./src/modules/HouseholdAssets/Utils/HouseholdAssetsReducers.js");
/* harmony import */ var _modules_HouseholdSpecialExpenses_Utils_HouseholdSpecialExpensesReducers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesReducers */ "./src/modules/HouseholdSpecialExpenses/Utils/HouseholdSpecialExpensesReducers.js");
/* harmony import */ var _modules_RentAffordability_Utils_RentAffordabilityReducers__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/modules/RentAffordability/Utils/RentAffordabilityReducers */ "./src/modules/RentAffordability/Utils/RentAffordabilityReducers.js");
/* harmony import */ var _modules_YourDocuments_Utils_YourDocumentsReducers__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/modules/YourDocuments/Utils/YourDocumentsReducers */ "./src/modules/YourDocuments/Utils/YourDocumentsReducers.js");
/* harmony import */ var _modules_CreateProfileModule_Utils_CreateProfileReducers__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/modules/CreateProfileModule/Utils/CreateProfileReducers */ "./src/modules/CreateProfileModule/Utils/CreateProfileReducers.js");
/* harmony import */ var _modules_HouseHoldModule_Utils_HouseHoldReducers__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~/modules/HouseHoldModule/Utils/HouseHoldReducers */ "./src/modules/HouseHoldModule/Utils/HouseHoldReducers.js");
/* harmony import */ var _exampleReducer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./exampleReducer */ "./src/shared/redux/exampleReducer.js");













 // COMBINED REDUCERS

const reducers = {
  counter: _exampleReducer__WEBPACK_IMPORTED_MODULE_13__["counterReducer"],
  loginDetails: _modules_Admin_Login_Utils_LoginReducer__WEBPACK_IMPORTED_MODULE_3__["loginReducer"],
  checkEligibility: _modules_CheckYourEligibility_Utils_CheckYourEligibilityReducers__WEBPACK_IMPORTED_MODULE_4__["CheckYourEligibility"],
  reviewApplication: _modules_ReviewApplication_Utils_ReviewApplicationReducers__WEBPACK_IMPORTED_MODULE_5__["ReviewApplication"],
  householdIncome: _modules_HouseholdIncome_Utils_HouseholdIncomeReducers__WEBPACK_IMPORTED_MODULE_6__["HouseholdIncome"],
  householdAssets: _modules_HouseholdAssets_Utils_HouseholdAssetsReducers__WEBPACK_IMPORTED_MODULE_7__["HouseholdAssets"],
  householdSpecialExpenses: _modules_HouseholdSpecialExpenses_Utils_HouseholdSpecialExpensesReducers__WEBPACK_IMPORTED_MODULE_8__["HouseholdSpecialExpenses"],
  rentAffordability: _modules_RentAffordability_Utils_RentAffordabilityReducers__WEBPACK_IMPORTED_MODULE_9__["RentAffordability"],
  yourDocuments: _modules_YourDocuments_Utils_YourDocumentsReducers__WEBPACK_IMPORTED_MODULE_10__["YourDocuments"],
  houseHoldDetails: _modules_HouseHoldModule_Utils_HouseHoldReducers__WEBPACK_IMPORTED_MODULE_12__["HouseHoldReducer"],
  profileSteps: _modules_CreateProfileModule_Utils_CreateProfileReducers__WEBPACK_IMPORTED_MODULE_11__["CreateProfile"]
};
const persistConfig = {
  key: 'primary',
  storage: (redux_persist_lib_storage__WEBPACK_IMPORTED_MODULE_2___default()),
  whitelist: ['counter', 'loginDetails', 'houseHoldDetails'] // place to select which state you want to persist

};
const persistedReducer = Object(redux_persist__WEBPACK_IMPORTED_MODULE_1__["persistReducer"])(persistConfig, Object(redux__WEBPACK_IMPORTED_MODULE_0__["combineReducers"])(reducers));
/* harmony default export */ __webpack_exports__["default"] = (persistedReducer);

/***/ }),

/***/ "./src/shared/redux/store.js":
/*!***********************************!*\
  !*** ./src/shared/redux/store.js ***!
  \***********************************/
/*! exports provided: initializeStore, useStore */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeStore", function() { return initializeStore; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useStore", function() { return useStore; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! redux */ "redux");
/* harmony import */ var redux__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(redux__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! redux-devtools-extension */ "redux-devtools-extension");
/* harmony import */ var redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! redux-thunk */ "redux-thunk");
/* harmony import */ var redux_thunk__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(redux_thunk__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _reducers__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./reducers */ "./src/shared/redux/reducers.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






let store;

function initStore(initialState) {
  return Object(redux__WEBPACK_IMPORTED_MODULE_1__["createStore"])(_reducers__WEBPACK_IMPORTED_MODULE_4__["default"], initialState, Object(redux_devtools_extension__WEBPACK_IMPORTED_MODULE_2__["composeWithDevTools"])(Object(redux__WEBPACK_IMPORTED_MODULE_1__["applyMiddleware"])(redux_thunk__WEBPACK_IMPORTED_MODULE_3___default.a)));
}

const initializeStore = preloadedState => {
  var _store2;

  let _store = (_store2 = store) !== null && _store2 !== void 0 ? _store2 : initStore(preloadedState); // After navigating to a page with an initial Redux state, merge that state
  // with the current state in the store, and create a new store


  if (preloadedState && store) {
    _store = initStore(_objectSpread(_objectSpread({}, store.getState()), preloadedState)); // Reset the current store

    store = undefined;
  } // For SSG and SSR always create a new store


  if (true) {
    return _store;
  } // Create the store once in the client


  if (!store) {
    store = _store;
  }

  return _store;
};
function useStore(initialState) {
  const store = Object(react__WEBPACK_IMPORTED_MODULE_0__["useMemo"])(() => initializeStore(initialState), [initialState]);
  return store;
}

/***/ }),

/***/ "./src/shared/styles/globals.scss":
/*!****************************************!*\
  !*** ./src/shared/styles/globals.scss ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./src/shared/utils/Overide/AlertOveride.js":
/*!**************************************************!*\
  !*** ./src/shared/utils/Overide/AlertOveride.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const AlertOveride = {
  MuiAlert: {
    root: {
      fontSize: '15px',
      padding: "12px 24px"
    },
    icon: {
      display: 'none'
    },
    standardSuccess: {
      color: 'inherit',
      backgroundColor: 'inherit'
    },
    action: {
      alignItems: 'flex-start',
      '& .MuiIconButton-root': {
        padding: '6px 0'
      }
    },
    message: {
      padding: '6px 0',
      width: '100%'
    }
  },
  MuiAlertTitle: {
    root: {
      marginBottom: '4px'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (AlertOveride);

/***/ }),

/***/ "./src/shared/utils/Overide/ButtonOveride.js":
/*!***************************************************!*\
  !*** ./src/shared/utils/Overide/ButtonOveride.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const ButtonOverRide = {
  MuiButton: {
    sizeLarge: {
      minWidth: '192px',
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h5.fontSize,
      padding: '8px 51px'
    },
    sizeSmall: {
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].sm.fontSize,
      minWidth: '90px',
      minHeight: '36px',
      fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.regular
    },
    sizeMedium: {
      minWidth: '160px',
      fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.medium
    },
    containedSecondary: {
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.button.secondaryColor
    },
    colorInherit: {
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.main,
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
    },
    contained: {
      boxShadow: 'none'
    },
    root: {
      borderRadius: '50px',
      textTransform: 'inherit',
      fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.medium,
      '&.semiBorder': {
        borderRadius: '0px 0px 20px 20px',
        padding: '8px 5px'
      },
      '&.linkBtn': {
        minWidth: 'auto !important',
        padding: `0 !important`,
        marginBottom: '0 !important',
        backgroundColor: 'transparent',
        '&:hover': {
          backgroundColor: 'transparent !important'
        },
        '&:focus': {
          backgroundColor: 'transparent !important'
        }
      },
      '&.link-primary': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.success.extraLight,
        fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.regular,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].lg.fontSize
      },
      '&.link-white': {
        color: "#fff",
        fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.regular,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].lg.fontSize
      },
      '&.facebooKBtn': {
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.facebookBlue
      },
      '&.w-269': {
        width: "269px"
      }
    },
    endIcon: {
      marginLeft: '4px'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (ButtonOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/CardOveride.js":
/*!*************************************************!*\
  !*** ./src/shared/utils/Overide/CardOveride.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const CardOverRide = {
  MuiCard: {
    root: {
      boxShadow: '0 4px 4px rgb(0 0 0 / 8%)',
      borderRadius: '21px'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (CardOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/CheckBoxOveride.js":
/*!*****************************************************!*\
  !*** ./src/shared/utils/Overide/CheckBoxOveride.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const CheckBoxOverRide = {
  MuiCheckbox: {
    root: {
      '&.extraLightLabel ~ span': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight
      },
      '& .MuiSvgIcon-root': {
        color: 'transparent',
        border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight}`,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h4.fontSize,
        borderRadius: '8px',
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
      },
      '&.Mui-checked': {
        '& .MuiSvgIcon-root': {
          border: 'none',
          color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.success.main,
          backgroundColor: 'transparent'
        }
      },
      '&.MuiCheckbox-root ~ span': {
        paddingTop: '0px'
      }
    }
  },
  MuiFormControlLabel: {
    root: {
      alignItems: 'flex-start'
    },
    label: {
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h6.fontSize,
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light,
      paddingTop: '4px',
      paddingLeft: '4px'
    }
  },
  PrivateSwitchBase: {
    root: {
      paddingTop: 0
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (CheckBoxOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/DialogOveride.js":
/*!***************************************************!*\
  !*** ./src/shared/utils/Overide/DialogOveride.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const DialogOverRide = {
  MuiDialog: {
    root: {},
    paper: {
      minWidth: '383px',
      borderRadius: '21px',
      boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.08)'
    },
    container: {
      backgroundColor: 'rgba(88, 90, 121, .70)'
    }
  },
  MuiDialogTitle: {
    root: {
      '& .MuiButtonBase-root': {
        position: 'absolute',
        right: '10px',
        top: '10px'
      },
      '& .MuiSvgIcon-root': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.main,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h4xl.fontSize
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (DialogOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/InputOveride.js":
/*!**************************************************!*\
  !*** ./src/shared/utils/Overide/InputOveride.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const InputOverRide = {
  MuiFilledInput: {
    root: {
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light,
      border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight}`,
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h6.fontSize,
      borderRadius: '16px',
      borderTopLeftRadius: '16px',
      borderTopRightRadius: '16px',
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white,
      height: '52px',
      '&:hover': {
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
      },
      MuiInputLabel: {
        width: '95%',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      },
      '& .MuiInputAdornment-filled.MuiInputAdornment-positionStart:not(.MuiInputAdornment-hiddenLabel)': {
        marginTop: 0
      },
      '& .MuiIconButton-root': {
        padding: '0 8px 0 0',
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h5xl.fontSize
      },
      '&.Mui-error': {
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.error.extraLight,
        borderColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.error.main
      },
      '&.Mui-focused': {
        backgroundColor: 'transparent',
        boxShadow: 'none !important'
      }
    },
    input: {
      padding: '25px 16px 5px',
      borderRadius: '16px'
    },
    adornedEnd: {
      paddingRight: 0
    },
    underline: {
      '&:before, &:after': {
        border: 'none'
      },
      '&:hover': {
        '&:before, &:after': {
          border: 'none'
        }
      }
    },
    multiline: {
      height: '120px'
    }
  },
  MuiInputLabel: {
    root: {
      width: '100%',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight,
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h6.fontSize,
      '&.Mui-error': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight
      },
      '&>div': {
        width: '100%',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    },
    filled: {
      transform: 'translate(16px, 17px) scale(1)',
      paddingRight: '45px',
      '&.MuiInputLabel-shrink': {
        transform: 'translate(16px, 10px) scale(0.75)'
      }
    }
  },
  MuiTextField: {
    root: {
      marginBottom: '0px'
    }
  },
  MuiFormControl: {
    root: {
      marginBottom: '24px',
      '&.noMargin': {
        marginBottom: '8px'
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (InputOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/Overide.js":
/*!*********************************************!*\
  !*** ./src/shared/utils/Overide/Overide.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AlertOveride__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AlertOveride */ "./src/shared/utils/Overide/AlertOveride.js");
/* harmony import */ var _ButtonOveride__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ButtonOveride */ "./src/shared/utils/Overide/ButtonOveride.js");
/* harmony import */ var _CardOveride__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CardOveride */ "./src/shared/utils/Overide/CardOveride.js");
/* harmony import */ var _CheckBoxOveride__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CheckBoxOveride */ "./src/shared/utils/Overide/CheckBoxOveride.js");
/* harmony import */ var _DialogOveride__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./DialogOveride */ "./src/shared/utils/Overide/DialogOveride.js");
/* harmony import */ var _InputOveride__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./InputOveride */ "./src/shared/utils/Overide/InputOveride.js");
/* harmony import */ var _ProgressBarOveride__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ProgressBarOveride */ "./src/shared/utils/Overide/ProgressBarOveride.js");
/* harmony import */ var _RadioOveride__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./RadioOveride */ "./src/shared/utils/Overide/RadioOveride.js");
/* harmony import */ var _SelectOveride__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./SelectOveride */ "./src/shared/utils/Overide/SelectOveride.js");
/* harmony import */ var _SwitchOveride__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./SwitchOveride */ "./src/shared/utils/Overide/SwitchOveride.js");
/* harmony import */ var _TabOveride__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./TabOveride */ "./src/shared/utils/Overide/TabOveride.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












const Overide = {
  overrides: _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, _ButtonOveride__WEBPACK_IMPORTED_MODULE_1__["default"]), _InputOveride__WEBPACK_IMPORTED_MODULE_5__["default"]), _RadioOveride__WEBPACK_IMPORTED_MODULE_7__["default"]), _CheckBoxOveride__WEBPACK_IMPORTED_MODULE_3__["default"]), _SwitchOveride__WEBPACK_IMPORTED_MODULE_9__["default"]), _CardOveride__WEBPACK_IMPORTED_MODULE_2__["default"]), _SelectOveride__WEBPACK_IMPORTED_MODULE_8__["default"]), _DialogOveride__WEBPACK_IMPORTED_MODULE_4__["default"]), _ProgressBarOveride__WEBPACK_IMPORTED_MODULE_6__["default"]), _AlertOveride__WEBPACK_IMPORTED_MODULE_0__["default"]), _TabOveride__WEBPACK_IMPORTED_MODULE_10__["default"])
};
/* harmony default export */ __webpack_exports__["default"] = (Overide);

/***/ }),

/***/ "./src/shared/utils/Overide/ProgressBarOveride.js":
/*!********************************************************!*\
  !*** ./src/shared/utils/Overide/ProgressBarOveride.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");

const ProgressBarOveride = {
  MuiLinearProgress: {
    root: {
      height: '12px'
    },
    colorPrimary: {
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
    },
    bar1Determinate: {
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.success.main
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (ProgressBarOveride);

/***/ }),

/***/ "./src/shared/utils/Overide/RadioOveride.js":
/*!**************************************************!*\
  !*** ./src/shared/utils/Overide/RadioOveride.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const RadioOverRide = {
  MuiRadio: {
    root: {
      '&.extraLightLabel ~ span': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight
      },
      '&.size24': {
        '& .MuiSvgIcon-root': {
          fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h4.fontSize
        },
        "&~.MuiFormControlLabel-label": {
          paddingTop: 0
        }
      },
      '& .MuiSvgIcon-root': {
        color: 'transparent',
        border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight}`,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h3xl.fontSize,
        borderRadius: '50%',
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
      },
      '&.Mui-checked': {
        '& .MuiSvgIcon-root': {
          color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.secondary.dark
        }
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (RadioOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/SelectOveride.js":
/*!***************************************************!*\
  !*** ./src/shared/utils/Overide/SelectOveride.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");

const SelectOveride = {
  MuiSelect: {
    icon: {
      background: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.menus.menuBackground,
      height: '50px',
      borderRadius: '0 16px 16px 0',
      minWidth: '44px',
      top: '0px',
      color: 'transparent'
    },
    iconFilled: {
      right: 0
    },
    select: {
      position: 'relative',
      '&:before': {
        content: '"\\e902"',
        position: 'absolute',
        right: '12px',
        zIndex: '9',
        fontFamily: 'icomoon !important',
        top: '17px',
        fontSize: '20px'
      },
      '&:focus': {
        backgroundColor: 'transparent'
      }
    }
  },
  MuiPopover: {
    paper: {
      borderRadius: '16px'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (SelectOveride);

/***/ }),

/***/ "./src/shared/utils/Overide/SwitchOveride.js":
/*!***************************************************!*\
  !*** ./src/shared/utils/Overide/SwitchOveride.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");

const SwitchOverRide = {
  MuiSwitch: {
    root: {
      width: '60px',
      height: '36px',
      padding: '0px'
    },
    thumb: {
      width: '36px',
      border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light}`,
      height: '36px',
      position: 'relative',
      boxShadow: 'none',
      boxSizing: 'border-box',
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white,
      '&:after': {
        content: '""',
        width: '16px',
        height: '16px',
        border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light}`,
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        borderRadius: 50
      }
    },
    switchBase: {
      padding: 0,
      margin: 0,
      transitionDuration: '300ms',
      '&.Mui-checked': {
        transform: 'translateX(24px)',
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white,
        '& + .MuiSwitch-track': {
          backgroundColor: `${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.secondary.dark} !important`,
          opacity: 1
        },
        '&.Mui-disabled + .MuiSwitch-track': {
          opacity: 0.5
        }
      }
    },
    track: {
      border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light}`,
      opacity: '1',
      transition: 'background-color 500ms cubic-bezier(0.4, 0, 0.2, 1) 0ms',
      borderRadius: '50px',
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.gray
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (SwitchOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/TabOveride.js":
/*!************************************************!*\
  !*** ./src/shared/utils/Overide/TabOveride.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");

const TabOveride = {
  MuiTabs: {
    root: {
      minWidth: '400px',
      '&.textColorInherit': {
        opacity: 'unset',
        minWidth: '400px'
      }
    },
    endIcon: {
      marginLeft: '4px'
    },
    vertical: {
      marginTop: '190px'
    }
  },
  MuiTab: {
    root: {
      opacity: 'unset !important',
      minWidth: '400px !important',
      textTransform: 'none',
      margin: '15px 0',
      '&.Mui-selected': {
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.secondary.main,
        borderTopLeftRadius: '21px',
        borderBottomLeftRadius: '21px',
        minHeight: '53px',
        '& .arrow svg': {
          display: 'none'
        }
      }
    },
    wrapper: {
      flexDirection: 'initial',
      justifyContent: 'end'
    }
  },
  PrivateTabIndicator: {
    root: {
      display: 'none'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (TabOveride);

/***/ }),

/***/ "./src/shared/utils/Overide/index.js":
/*!*******************************************!*\
  !*** ./src/shared/utils/Overide/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Overide__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Overide */ "./src/shared/utils/Overide/Overide.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Overide__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/utils/breakpoints.js":
/*!*****************************************!*\
  !*** ./src/shared/utils/breakpoints.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 960,
      lg: 1152,
      ml: 1366,
      xlg: 1440,
      xl: 1920
    }
  }
});

/***/ }),

/***/ "./src/shared/utils/color.js":
/*!***********************************!*\
  !*** ./src/shared/utils/color.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const ColorOveRide = {
  common: {
    white: '#fff',
    black: '#000',
    gray: '#F5F5F9',
    facebookBlue: '#3B5998',
    lightBlue: '#826fac',
    grayText: '#7C7C95',
    defaultBgColor: '#C4C4C4',
    secondaryBgColor: '#D9EEFF',
    lightBlack: '#18191F'
  },
  palette: {
    primary: {
      main: '#2F0B7C',
      light: '#26284E',
      extraLight: '#585A79'
    },
    secondary: {
      dark: '#27CCA5',
      main: '#5EEACF',
      light: '#D0FFF6',
      extraLight: '#F5F5F9'
    },
    error: {
      dark: '#CC2811',
      main: '#FF474E',
      light: '#FF8084',
      extraLight: '#FFDBDC'
    },
    pending: {
      main: '#FECD4F',
      light: '#FFDC83',
      extraLight: '#FFF1CE'
    },
    success: {
      main: '#27CCA5',
      light: '#5EEACF',
      extraLight: '#D0FFF6'
    },
    info: {
      main: '#9797BF'
    },
    default: {
      main: '#848FEE'
    },
    button: {
      secondaryColor: '#270276'
    },
    menus: {
      menuBackground: '#D9EEFF'
    },
    dashboardBg: {
      main: '#575757'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (ColorOveRide);

/***/ }),

/***/ "./src/shared/utils/globalStyles.js":
/*!******************************************!*\
  !*** ./src/shared/utils/globalStyles.js ***!
  \******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["createStyles"])({
  '@global': {
    '*': {
      boxSizing: 'border-box',
      margin: 0,
      padding: 0
    },
    html: {
      '-webkit-font-smoothing': 'antialiased',
      '-moz-osx-font-smoothing': 'grayscale',
      height: '100%',
      width: '100%'
    },
    body: {
      height: '100%',
      width: '100%',
      fontFamily: theme.typography.fontFamily.regular,
      fontSize: theme.typography.fontSize.sm,
      wordBreak: 'break-word',
      lineHeight: '1.5',
      '& + div': {
        height: '100%'
      }
    },
    img: {
      maxWidth: '100%'
    },
    a: {
      textDecoration: 'none'
    },
    '#root': {
      height: '100%',
      width: '100%'
    },
    '.textTransform': {
      textTransform: 'upperCase'
    },
    '.MuiDialog-paper': {
      '@media screen and (max-width:600px)': {
        minWidth: '327px',
        maxWidth: '327px'
      },
      '@media screen and (max-width:350px)': {
        minWidth: '270px',
        maxWidth: '270px'
      }
    },
    '.noPadding': {
      padding: 0
    },
    '.withoutLabel': {
      '& .MuiFilledInput-input': {
        padding: '5px 16px'
      },
      '& .MuiSelect-select': {
        '&:before': {
          top: '4px'
        }
      }
    }
  },
  input: {
    '&:-webkit-autofill': {
      WebkitBoxShadow: '0 0 0 1000px white inset'
    }
  }
}));

const GlobalStyles = () => {
  useStyles();
  return null;
};

/* harmony default export */ __webpack_exports__["default"] = (GlobalStyles);

/***/ }),

/***/ "./src/shared/utils/theme.js":
/*!***********************************!*\
  !*** ./src/shared/utils/theme.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _breakpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./breakpoints */ "./src/shared/utils/breakpoints.js");
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./color */ "./src/shared/utils/color.js");
/* harmony import */ var _Overide__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Overide */ "./src/shared/utils/Overide/index.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./typography */ "./src/shared/utils/typography.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





 // Create a theme instance.

const theme = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["createTheme"])(_objectSpread(_objectSpread(_objectSpread({
  props: {
    // withWidth component ⚛️
    MuiWithWidth: {
      // Initial width property
      initialWidth: 'lg' // Breakpoint being globally set 🌎!

    }
  },
  typography: _typography__WEBPACK_IMPORTED_MODULE_4__["default"]
}, _breakpoints__WEBPACK_IMPORTED_MODULE_1__["default"]), _color__WEBPACK_IMPORTED_MODULE_2__["default"]), _Overide__WEBPACK_IMPORTED_MODULE_3__["default"]));
/* harmony default export */ __webpack_exports__["default"] = (theme);

/***/ }),

/***/ "./src/shared/utils/typography.js":
/*!****************************************!*\
  !*** ./src/shared/utils/typography.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  useNextVariants: true,
  fontSize: 16,
  h1: {
    fontSize: 44
  },
  h2: {
    fontSize: 36
  },
  h3xl: {
    fontSize: 32
  },
  h3: {
    fontSize: 27
  },
  h4xl: {
    fontSize: 25
  },
  h4: {
    fontSize: 24
  },
  h5xl: {
    fontSize: 22
  },
  h5: {
    fontSize: 21
  },
  h6: {
    fontSize: 17
  },
  lg: {
    fontSize: 15
  },
  mdxl: {
    fontSize: 14
  },
  md: {
    fontSize: 13
  },
  sm: {
    fontSize: 12
  },
  xs: {
    fontSize: 11
  },
  fontFamily: {
    regular: 'Poppins-Regular',
    medium: 'Poppins-Medium',
    semiBold: 'Poppins-SemiBold',
    bold: 'Poppins-Bold',
    extraBold: 'Poppins-extraBold'
  },
  textTransform: {
    upperCase: 'uppercase'
  }
});

/***/ }),

/***/ 0:
/*!****************************************!*\
  !*** multi private-next-pages/_app.js ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! private-next-pages/_app.js */"./src/pages/_app.js");


/***/ }),

/***/ "@date-io/date-fns":
/*!************************************!*\
  !*** external "@date-io/date-fns" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@date-io/date-fns");

/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "@material-ui/core/CssBaseline":
/*!************************************************!*\
  !*** external "@material-ui/core/CssBaseline" ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/CssBaseline");

/***/ }),

/***/ "@material-ui/core/styles":
/*!*******************************************!*\
  !*** external "@material-ui/core/styles" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "@material-ui/pickers":
/*!***************************************!*\
  !*** external "@material-ui/pickers" ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/pickers");

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),

/***/ "next/head":
/*!****************************!*\
  !*** external "next/head" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-redux":
/*!******************************!*\
  !*** external "react-redux" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-redux");

/***/ }),

/***/ "react-toast-notifications":
/*!********************************************!*\
  !*** external "react-toast-notifications" ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-toast-notifications");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "redux":
/*!************************!*\
  !*** external "redux" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux");

/***/ }),

/***/ "redux-devtools-extension":
/*!*******************************************!*\
  !*** external "redux-devtools-extension" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-devtools-extension");

/***/ }),

/***/ "redux-persist":
/*!********************************!*\
  !*** external "redux-persist" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-persist");

/***/ }),

/***/ "redux-persist/integration/react":
/*!**************************************************!*\
  !*** external "redux-persist/integration/react" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-persist/integration/react");

/***/ }),

/***/ "redux-persist/lib/storage":
/*!********************************************!*\
  !*** external "redux-persist/lib/storage" ***!
  \********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ "redux-thunk":
/*!******************************!*\
  !*** external "redux-thunk" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("redux-thunk");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvQWRtaW4vTG9naW4vVXRpbHMvTG9naW5Db25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvQWRtaW4vTG9naW4vVXRpbHMvTG9naW5SZWR1Y2VyLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL0NoZWNrWW91ckVsaWdpYmlsaXR5L1V0aWxzL0NoZWNrWW91ckVsaWdpYmlsaXR5Q29uc3RhbnRzLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL0NoZWNrWW91ckVsaWdpYmlsaXR5L1V0aWxzL0NoZWNrWW91ckVsaWdpYmlsaXR5UmVkdWNlcnMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvQ3JlYXRlUHJvZmlsZU1vZHVsZS9VdGlscy9DcmVhdGVQcm9maWxlQ29uc3RhbnRzLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL0NyZWF0ZVByb2ZpbGVNb2R1bGUvVXRpbHMvQ3JlYXRlUHJvZmlsZVJlZHVjZXJzLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL0hvdXNlSG9sZE1vZHVsZS9VdGlscy9Ib3VzZUhvbGRDb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvSG91c2VIb2xkTW9kdWxlL1V0aWxzL0hvdXNlSG9sZFJlZHVjZXJzLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL0hvdXNlaG9sZEFzc2V0cy9VdGlscy9Ib3VzZWhvbGRBc3NldHNDb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvSG91c2Vob2xkQXNzZXRzL1V0aWxzL0hvdXNlaG9sZEFzc2V0c1JlZHVjZXJzLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL0hvdXNlaG9sZEluY29tZS9VdGlscy9Ib3VzZWhvbGRJbmNvbWVDb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvSG91c2Vob2xkSW5jb21lL1V0aWxzL0hvdXNlaG9sZEluY29tZVJlZHVjZXJzLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL0hvdXNlaG9sZFNwZWNpYWxFeHBlbnNlcy9VdGlscy9Ib3VzZWhvbGRTcGVjaWFsRXhwZW5zZXNDb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvSG91c2Vob2xkU3BlY2lhbEV4cGVuc2VzL1V0aWxzL0hvdXNlaG9sZFNwZWNpYWxFeHBlbnNlc1JlZHVjZXJzLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL1JlbnRBZmZvcmRhYmlsaXR5L1V0aWxzL1JlbnRBZmZvcmRhYmlsaXR5Q29uc3RhbnRzLmpzIiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL1JlbnRBZmZvcmRhYmlsaXR5L1V0aWxzL1JlbnRBZmZvcmRhYmlsaXR5UmVkdWNlcnMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvUmV2aWV3QXBwbGljYXRpb24vVXRpbHMvUmV2aWV3QXBwbGljYXRpb25Db25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvUmV2aWV3QXBwbGljYXRpb24vVXRpbHMvUmV2aWV3QXBwbGljYXRpb25SZWR1Y2Vycy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvbW9kdWxlcy9Zb3VyRG9jdW1lbnRzL1V0aWxzL1lvdXJEb2N1bWVudHNDb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvWW91ckRvY3VtZW50cy9VdGlscy9Zb3VyRG9jdW1lbnRzUmVkdWNlcnMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BhZ2VzL19hcHAuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9yZWR1eC9jb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9yZWR1eC9leGFtcGxlUmVkdWNlci5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3JlZHV4L3JlZHVjZXJzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvcmVkdXgvc3RvcmUuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy9PdmVyaWRlL0FsZXJ0T3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvQnV0dG9uT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvQ2FyZE92ZXJpZGUuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy9PdmVyaWRlL0NoZWNrQm94T3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvRGlhbG9nT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvSW5wdXRPdmVyaWRlLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvdXRpbHMvT3ZlcmlkZS9PdmVyaWRlLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvdXRpbHMvT3ZlcmlkZS9Qcm9ncmVzc0Jhck92ZXJpZGUuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy9PdmVyaWRlL1JhZGlvT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvU2VsZWN0T3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvU3dpdGNoT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvVGFiT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy90eXBvZ3JhcGh5LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvdXRpbHMvY29sb3IuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy9nbG9iYWxTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy90aGVtZS5qcyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAZGF0ZS1pby9kYXRlLWZuc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmUvQ3NzQmFzZWxpbmVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvcGlja2Vyc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcImxvZGFzaFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvaGVhZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInByb3AtdHlwZXNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0LXJlZHV4XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QtdG9hc3Qtbm90aWZpY2F0aW9uc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlZHV4XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVkdXgtZGV2dG9vbHMtZXh0ZW5zaW9uXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVkdXgtcGVyc2lzdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlZHV4LXBlcnNpc3QvaW50ZWdyYXRpb24vcmVhY3RcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWR1eC1wZXJzaXN0L2xpYi9zdG9yYWdlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVkdXgtdGh1bmtcIiJdLCJuYW1lcyI6WyJsb2dpbkNvbnN0YW50cyIsIkxPR0lOX1NVQ0NFU1MiLCJMT0dJTl9GQUlMIiwiTE9HSU5fSU5JVCIsImluaXRpYWxTdGF0ZSIsInVzZXJEYXRhIiwibG9hZGluZyIsImRhdGEiLCJsb2dpblJlZHVjZXIiLCJzdGF0ZSIsInR5cGUiLCJwYXlsb2FkIiwiYWN0aXZlU3RlcEluZGV4Iiwid2VsY29tZUNvbnRpbnVlIiwiZWxpZ2liaWxpdHlDaGVjayIsImZhbWlseU1lbWJlciIsIm1vbnRobHlJbmNvbWUiLCJlbGlnaWJpbGl0eVN0YXR1cyIsInNleE9mZmVuZGVyU3RhdHVzIiwibWV0aGFTdGF0dXMiLCJlbGlnaWJpbGl0eUNvbnN0YW50cyIsIkVMSUdJQklMSVRZX0FDVElWRV9JTkRFWCIsIlNBVkVfRkFNSUxZX0lORk8iLCJDT05USU5VRV9XRUxDT01FIiwiRUxJR0lCSUxJVFlfQ0hFQ0siLCJTQVZFX01PTlRITFlfSU5DT01FIiwiUkVTRVRfRk9STSIsIkVMSUdJQklMSVRZX1NUQVRVUyIsIk1FVEhBX1NUQVRVUyIsIlNFWF9PRkZFTkRFUl9TVEFUVVMiLCJTVEVQUyIsIlNURVAxIiwiU1RFUDIiLCJTVEVQMyIsIlNURVA0IiwiU1RFUDUiLCJTVEVQNiIsImVsaWdpYmlsaXR5U3RhdHVzQ29uc3RhbnQiLCJTVUNDRVNTIiwiRkFJTEVEIiwiUEVORElORyIsImVsaWdpYmlsaXR5U3RhdHVzRGF0YSIsImljb25OYW1lIiwic3RhdHVzIiwidGl0bGUiLCJzdWJUaXRsZSIsInN1YlRpdGxlMiIsImJ1dHRvblRleHQiLCJsaW5rVGV4dCIsIkNoZWNrWW91ckVsaWdpYmlsaXR5IiwiYWN0aW9uIiwicHJvZmlsZUNvbnN0YW50cyIsIlBST0ZJTEVfQUNUSVZFX0lOREVYIiwiU0FWRV9QUk9GSUxFIiwiQ3JlYXRlUHJvZmlsZSIsInVzZXJfcHJvZmlsZV9kYXRhIiwiaW5mb0NvbnRpbnVlIiwiYWRkaXRpb25hbE1lbWJlciIsIm1lbWJlckZvcm1TdGVwcyIsImFjdGl2ZU1lbWJlciIsImhvdXNlSG9sZEZvcm1Db3VudCIsImFkZGl0aW9uYWxGb3JtSW5mbyIsInJldmlld0NvbnRpbnVlIiwiYWNjb21tb2RhdGlvbnMiLCJzaGVsdGVySW5mbyIsIm1pbGl0YXJ5SW5mbyIsIm90aGVySW5mbyIsInJldmlld0RldGFpbENvbmZpcm0iLCJwcm9ncmFtcyIsIlNURVA3IiwiU1RFUDgiLCJTVEVQOSIsIlNURVAxMCIsImhvdXNlSG9sZENvbnN0YW50cyIsIkhPVVNFX0hPTERfQUNUSVZFX0lOREVYIiwiSE9VU0VfSE9MRF9JTkZPX0NPTlRJTlVFIiwiSE9VU0VfSE9MRF9TQVZFX0FERElUSU9OQUxfTUVNQkVSIiwiSE9VU0VfSE9MRF9TQVZFX0ZJUlNUX0FERElUSU9OQUxfRk9STSIsIkhPVVNFX0hPTERfU0FWRV9GSU5BTF9BRERJVElPTkFMX0ZPUk0iLCJTRVRfQURESVRJT05BTF9GT1JNX1NURVAiLCJCQUNLX0FERElUSU9OQUxfRk9STV9TVEVQMiIsIkJBQ0tfQURESVRJT05BTF9GT1JNX1NURVAxIiwiUkVTRVRfQURESVRJT05BTF9NRU1CRVIiLCJBRERJVElPTkFMX1JFVklFV19DT05USU5VRSIsIlNBVkVfQUNDT01NT0RBVElPTlMiLCJTQVZFX1NIRUxURVJfSU5GTyIsIlNBVkVfTUlMSVRBUllfSUZPIiwiU0FWRV9PVEhFUl9JTkZPIiwiQUREX01PUkVfTUVNQkVSIiwiUkVNT1ZFX01FTUJFUiIsIkVESVRfTUVNQkVSIiwiUkVOREVSX0VESVRfRk9STVMiLCJDT05GSVJNX1JFVklFV19ERVRBSUwiLCJTQVZFX1BST0dSQU1TIiwiTUVNQkVSX0ZPUk1fRklMRUQiLCJmaXJzdE5hbWUiLCJtaWRkbGVOYW1lIiwibGFzdE5hbWUiLCJtYWlkZW5OYW1lIiwicmVsYXRpb25TaGlwSWQiLCJjaXRpemVuU2hpcElkIiwiZGF0ZU9mQmlydGgiLCJnZW5kZXIiLCJzb2NpYWxTZWN1cml0eU51bWJlciIsInllYXJseUluY29tZSIsInBheUZyZXF1ZW5jeUlkIiwicGF5Y2hlY2tBbW91bnQiLCJpc0Rpc2FibGVkIiwiaXNGdWxsdGltZVN0dWRlbnQiLCJpc1N0dWRlbnROZXh0WWVhciIsImxpZmV0aW1lU2V4T2ZmZW5kZXJSZWciLCJyYWNlRXRobmljcyIsIkhPVVNFX0hPTERfRk9STVNfQ09VTlRTIiwiRk9STTEiLCJGT1JNMiIsIk9USEVSX0ZPUk1TIiwiU0FWRV9BQ0NPTU1PREFUSU9OX0ZPUk1fSU5GTyIsIlNBVkVfU0hFTFRFUl9GT1JNX0lORk8iLCJTQVZFX01JTElUQVJZX0ZPUk1fSU5GTyIsIlNBVkVfT1RIRVJfRk9STV9JTkZPIiwic3RhdHVzQ2FyZERhdGEiLCJzaG93QnV0dG9uIiwiYnV0dG9uVHlwZSIsImljb25TdGF0dXMiLCJjb252ZXJ0Qm9vbGVhblRvU3RyaW5nIiwidmFsdWUiLCJnZXRSYWNlRXRobmljRGF0YSIsInJhY2VFdGhuaWNzQXJyIiwidmFsdWVzIiwiZm9yRWFjaCIsImlkIiwiSG91c2VIb2xkUmVkdWNlciIsInN0ZXBzQXJyIiwiQXJyYXkiLCJmaWxsIiwiaXRlbSIsImluZGV4IiwiT2JqZWN0Iiwia2V5cyIsImxlbmd0aCIsImFkZGl0aW9uYWxGb3JtSW5mb0RhdGEiLCJyZW1vdmVkTWVtYmVyIiwiXyIsIm9taXQiLCJleGlzdE1lbWJlciIsIm1lbWJlckluZm8iLCJpc19kaXNhYmxlZCIsImlzX2Z1bGx0aW1lX3N0dWRlbnQiLCJpc19zdHVkZW50X25leHRfeWVhciIsImxpZmV0aW1lX3NleF9vZmZlbmRlcl9yZWciLCJyYWNlX2V0aGluaWMiLCJob3VzZWhvbGRBc3NldHNDaGVjayIsInJldmlld1N0YXR1cyIsImhvdXNlaG9sZEFzc2V0c0NvbnN0YW50cyIsIkhPVVNFSE9MRF9BU1NFVFNfQUNUSVZFX0lOREVYIiwiSE9VU0VIT0xEX0FTU0VUU19DSEVDSyIsIkhPVVNFSE9MRF9BU1NFVFNfU1RBVFVTIiwiaG91c2Vob2xkQXNzZXRzU3RhdHVzQ29uc3RhbnQiLCJob3VzZWhvbGRBc3NldHNTdGF0dXNEYXRhIiwiSG91c2Vob2xkQXNzZXRzIiwiaG91c2Vob2xkQXNzZXRzU3RhdHVzIiwiaG91c2Vob2xkSW5jb21lQ2hlY2siLCJob3VzZWhvbGRJbmNvbWVDb25zdGFudHMiLCJIT1VTRUhPTERfQUNUSVZFX0lOREVYIiwiSE9VU0VIT0xEX0NIRUNLIiwiSE9VU0VIT0xEX1NUQVRVUyIsImhvdXNlaG9sZEluY29tZVN0YXR1c0NvbnN0YW50IiwiaG91c2Vob2xkSW5jb21lU3RhdHVzRGF0YSIsIkhvdXNlaG9sZEluY29tZSIsImhvdXNlaG9sZEluY29tZVN0YXR1cyIsImhvdXNlaG9sZFNwZWNpYWxFeHBlbnNlc0NoZWNrIiwiaG91c2Vob2xkU3BlY2lhbEV4cGVuc2VzQ29uc3RhbnRzIiwiSE9VU0VIT0xEX1NQRUNJQUxfRVhQRU5TRVNfQUNUSVZFX0lOREVYIiwiSE9VU0VIT0xEX1NQRUNJQUxfRVhQRU5TRVNfQ0hFQ0siLCJIT1VTRUhPTERfU1BFQ0lBTF9FWFBFTlNFU19TVEFUVVMiLCJob3VzZWhvbGRTcGVjaWFsRXhwZW5zZXNTdGF0dXNDb25zdGFudCIsImhvdXNlaG9sZFNwZWNpYWxFeHBlbnNlc1N0YXR1c0RhdGEiLCJIb3VzZWhvbGRTcGVjaWFsRXhwZW5zZXMiLCJob3VzZWhvbGRTcGVjaWFsRXhwZW5zZXNTdGF0dXMiLCJyZW50QWZmb3JkYWJpbGl0eUNoZWNrIiwicmVudEFmZm9yZGFiaWxpdHlDb25zdGFudHMiLCJSRU5UX0FGRk9SREFCSUxJVFlfQUNUSVZFX0lOREVYIiwiUkVOVF9BRkZPUkRBQklMSVRZX0NIRUNLIiwiUkVOVF9BRkZPUkRBQklMSVRZX1NUQVRVUyIsInJlbnRBZmZvcmRhYmlsaXR5U3RhdHVzQ29uc3RhbnQiLCJyZW50QWZmb3JkYWJpbGl0eVN0YXR1c0RhdGEiLCJSZW50QWZmb3JkYWJpbGl0eSIsInJlbnRBZmZvcmRhYmlsaXR5U3RhdHVzIiwicmV2aWV3Q2hlY2siLCJyZXZpZXdDb25zdGFudHMiLCJSRVZJRVdfQUNUSVZFX0lOREVYIiwiUkVWSUVXX0NIRUNLIiwiUkVWSUVXX1NUQVRVUyIsInJldmlld1N0YXR1c0NvbnN0YW50IiwicmV2aWV3U3RhdHVzRGF0YSIsIlJldmlld0FwcGxpY2F0aW9uIiwieW91ckRvY3VtZW50c0NoZWNrIiwieW91ckRvY3VtZW50c0NvbnN0YW50cyIsIllPVVJfRE9DVU1FTlRTX0FDVElWRV9JTkRFWCIsIllPVVJfRE9DVU1FTlRTX0NIRUNLIiwiWU9VUl9ET0NVTUVOVFNfU1RBVFVTIiwieW91ckRvY3VtZW50c1N0YXR1c0NvbnN0YW50IiwieW91ckRvY3VtZW50c1N0YXR1c0RhdGEiLCJZb3VyRG9jdW1lbnRzIiwieW91ckRvY3VtZW50c1N0YXR1cyIsIk15QXBwIiwicHJvcHMiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiLCJzdG9yZSIsInVzZVN0b3JlIiwiaW5pdGlhbFJlZHV4U3RhdGUiLCJwZXJzaXN0b3IiLCJwZXJzaXN0U3RvcmUiLCJwZXJzaXN0IiwidGhlbWUiLCJEYXRlRm5zVXRpbHMiLCJwcm9wVHlwZXMiLCJQcm9wVHlwZXMiLCJlbGVtZW50VHlwZSIsImlzUmVxdWlyZWQiLCJvYmplY3QiLCJUSUNLIiwiSU5DUkVNRU5UIiwiREVDUkVNRU5UIiwiUkVTRVQiLCJjb3VudGVyIiwiY291bnRlclJlZHVjZXIiLCJ0eXBlcyIsInJlZHVjZXJzIiwibG9naW5EZXRhaWxzIiwiY2hlY2tFbGlnaWJpbGl0eSIsInJldmlld0FwcGxpY2F0aW9uIiwiaG91c2Vob2xkSW5jb21lIiwiaG91c2Vob2xkQXNzZXRzIiwiaG91c2Vob2xkU3BlY2lhbEV4cGVuc2VzIiwicmVudEFmZm9yZGFiaWxpdHkiLCJ5b3VyRG9jdW1lbnRzIiwiaG91c2VIb2xkRGV0YWlscyIsInByb2ZpbGVTdGVwcyIsInBlcnNpc3RDb25maWciLCJrZXkiLCJzdG9yYWdlIiwid2hpdGVsaXN0IiwicGVyc2lzdGVkUmVkdWNlciIsInBlcnNpc3RSZWR1Y2VyIiwiY29tYmluZVJlZHVjZXJzIiwiaW5pdFN0b3JlIiwiY3JlYXRlU3RvcmUiLCJjb21wb3NlV2l0aERldlRvb2xzIiwiYXBwbHlNaWRkbGV3YXJlIiwidGh1bmtNaWRkbGV3YXJlIiwiaW5pdGlhbGl6ZVN0b3JlIiwicHJlbG9hZGVkU3RhdGUiLCJfc3RvcmUiLCJnZXRTdGF0ZSIsInVuZGVmaW5lZCIsInVzZU1lbW8iLCJBbGVydE92ZXJpZGUiLCJNdWlBbGVydCIsInJvb3QiLCJmb250U2l6ZSIsInBhZGRpbmciLCJpY29uIiwiZGlzcGxheSIsInN0YW5kYXJkU3VjY2VzcyIsImNvbG9yIiwiYmFja2dyb3VuZENvbG9yIiwiYWxpZ25JdGVtcyIsIm1lc3NhZ2UiLCJ3aWR0aCIsIk11aUFsZXJ0VGl0bGUiLCJtYXJnaW5Cb3R0b20iLCJCdXR0b25PdmVyUmlkZSIsIk11aUJ1dHRvbiIsInNpemVMYXJnZSIsIm1pbldpZHRoIiwiZm9udCIsImg1Iiwic2l6ZVNtYWxsIiwic20iLCJtaW5IZWlnaHQiLCJmb250RmFtaWx5IiwicmVndWxhciIsInNpemVNZWRpdW0iLCJtZWRpdW0iLCJjb250YWluZWRTZWNvbmRhcnkiLCJwYWxldHRlIiwiYnV0dG9uIiwic2Vjb25kYXJ5Q29sb3IiLCJjb2xvckluaGVyaXQiLCJwcmltYXJ5IiwibWFpbiIsImNvbW1vbiIsIndoaXRlIiwiY29udGFpbmVkIiwiYm94U2hhZG93IiwiYm9yZGVyUmFkaXVzIiwidGV4dFRyYW5zZm9ybSIsInN1Y2Nlc3MiLCJleHRyYUxpZ2h0IiwibGciLCJmYWNlYm9va0JsdWUiLCJlbmRJY29uIiwibWFyZ2luTGVmdCIsIkNhcmRPdmVyUmlkZSIsIk11aUNhcmQiLCJDaGVja0JveE92ZXJSaWRlIiwiTXVpQ2hlY2tib3giLCJib3JkZXIiLCJoNCIsInBhZGRpbmdUb3AiLCJNdWlGb3JtQ29udHJvbExhYmVsIiwibGFiZWwiLCJoNiIsImxpZ2h0IiwicGFkZGluZ0xlZnQiLCJQcml2YXRlU3dpdGNoQmFzZSIsIkRpYWxvZ092ZXJSaWRlIiwiTXVpRGlhbG9nIiwicGFwZXIiLCJjb250YWluZXIiLCJNdWlEaWFsb2dUaXRsZSIsInBvc2l0aW9uIiwicmlnaHQiLCJ0b3AiLCJoNHhsIiwiSW5wdXRPdmVyUmlkZSIsIk11aUZpbGxlZElucHV0IiwiYm9yZGVyVG9wTGVmdFJhZGl1cyIsImJvcmRlclRvcFJpZ2h0UmFkaXVzIiwiaGVpZ2h0IiwiTXVpSW5wdXRMYWJlbCIsIm92ZXJmbG93IiwidGV4dE92ZXJmbG93Iiwid2hpdGVTcGFjZSIsIm1hcmdpblRvcCIsImg1eGwiLCJlcnJvciIsImJvcmRlckNvbG9yIiwiaW5wdXQiLCJhZG9ybmVkRW5kIiwicGFkZGluZ1JpZ2h0IiwidW5kZXJsaW5lIiwibXVsdGlsaW5lIiwiZmlsbGVkIiwidHJhbnNmb3JtIiwiTXVpVGV4dEZpZWxkIiwiTXVpRm9ybUNvbnRyb2wiLCJPdmVyaWRlIiwib3ZlcnJpZGVzIiwiQnV0dG9uT3ZlcmlkZSIsIklucHV0T3ZlcmlkZSIsIlJhZGlvT3ZlcmlkZSIsIkNoZWNrQm94T3ZlcmlkZSIsIlN3aXRjaE92ZXJpZGUiLCJDYXJkT3ZlcmlkZSIsIlNlbGVjdE92ZXJpZGUiLCJEaWFsb2dPdmVyaWRlIiwiUHJvZ3Jlc3NCYXJPdmVyaWRlIiwiVGFiT3ZlcmlkZSIsIk11aUxpbmVhclByb2dyZXNzIiwiY29sb3JQcmltYXJ5IiwiYmFyMURldGVybWluYXRlIiwiUmFkaW9PdmVyUmlkZSIsIk11aVJhZGlvIiwiaDN4bCIsInNlY29uZGFyeSIsImRhcmsiLCJNdWlTZWxlY3QiLCJiYWNrZ3JvdW5kIiwibWVudXMiLCJtZW51QmFja2dyb3VuZCIsImljb25GaWxsZWQiLCJzZWxlY3QiLCJjb250ZW50IiwiekluZGV4IiwiTXVpUG9wb3ZlciIsIlN3aXRjaE92ZXJSaWRlIiwiTXVpU3dpdGNoIiwidGh1bWIiLCJib3hTaXppbmciLCJsZWZ0Iiwic3dpdGNoQmFzZSIsIm1hcmdpbiIsInRyYW5zaXRpb25EdXJhdGlvbiIsIm9wYWNpdHkiLCJ0cmFjayIsInRyYW5zaXRpb24iLCJncmF5IiwiTXVpVGFicyIsInZlcnRpY2FsIiwiTXVpVGFiIiwiYm9yZGVyQm90dG9tTGVmdFJhZGl1cyIsIndyYXBwZXIiLCJmbGV4RGlyZWN0aW9uIiwianVzdGlmeUNvbnRlbnQiLCJQcml2YXRlVGFiSW5kaWNhdG9yIiwiYnJlYWtwb2ludHMiLCJ4cyIsIm1kIiwibWwiLCJ4bGciLCJ4bCIsIkNvbG9yT3ZlUmlkZSIsImJsYWNrIiwibGlnaHRCbHVlIiwiZ3JheVRleHQiLCJkZWZhdWx0QmdDb2xvciIsInNlY29uZGFyeUJnQ29sb3IiLCJsaWdodEJsYWNrIiwicGVuZGluZyIsImluZm8iLCJkZWZhdWx0IiwiZGFzaGJvYXJkQmciLCJ1c2VTdHlsZXMiLCJtYWtlU3R5bGVzIiwiY3JlYXRlU3R5bGVzIiwiaHRtbCIsImJvZHkiLCJ0eXBvZ3JhcGh5Iiwid29yZEJyZWFrIiwibGluZUhlaWdodCIsImltZyIsIm1heFdpZHRoIiwiYSIsInRleHREZWNvcmF0aW9uIiwiV2Via2l0Qm94U2hhZG93IiwiR2xvYmFsU3R5bGVzIiwiY3JlYXRlVGhlbWUiLCJNdWlXaXRoV2lkdGgiLCJpbml0aWFsV2lkdGgiLCJPdmVyUmlkZUNzcyIsInVzZU5leHRWYXJpYW50cyIsImgxIiwiaDIiLCJoMyIsIm1keGwiLCJzZW1pQm9sZCIsImJvbGQiLCJleHRyYUJvbGQiLCJ1cHBlckNhc2UiXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJO1FBQ0o7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7Ozs7QUN2RkE7QUFBQTtBQUFBO0FBQU8sTUFBTUEsY0FBYyxHQUFHO0FBQzFCQyxlQUFhLEVBQUUsZUFEVztBQUUxQkMsWUFBVSxFQUFFLFlBRmM7QUFHMUJDLFlBQVUsRUFBRTtBQUhjLENBQXZCO0FBTUEsTUFBTUMsWUFBWSxHQUFHO0FBQ3hCQyxVQUFRLEVBQUU7QUFDTkMsV0FBTyxFQUFFLEtBREg7QUFFTkMsUUFBSSxFQUFFO0FBRkE7QUFEYyxDQUFyQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQUDtBQUVBLE1BQU07QUFDRk4sZUFERTtBQUVGQyxZQUZFO0FBR0ZDO0FBSEUsSUFJRkgsOERBSko7QUFNTyxNQUFNUSxZQUFZLEdBQUcsQ0FBQ0MsS0FBSyxHQUFHTCw0REFBVCxFQUF1QjtBQUFFTSxNQUFGO0FBQVFDO0FBQVIsQ0FBdkIsS0FBNkM7QUFDdkUsVUFBUUQsSUFBUjtBQUNFLFNBQUtQLFVBQUw7QUFDRSw2Q0FBWU0sS0FBWjtBQUFtQkosZ0JBQVEsa0NBQU9JLEtBQUssQ0FBQ0osUUFBYjtBQUF1QkMsaUJBQU8sRUFBRTtBQUFoQztBQUEzQjs7QUFDRixTQUFLTCxhQUFMO0FBQ0UsNkNBQVlRLEtBQVo7QUFBbUJKLGdCQUFRLGtDQUFPSSxLQUFLLENBQUNKLFFBQWI7QUFBdUJDLGlCQUFPLEVBQUUsS0FBaEM7QUFBdUNDLGNBQUksRUFBRUk7QUFBN0M7QUFBM0I7O0FBQ0YsU0FBS1QsVUFBTDtBQUNFLDZDQUFZTyxLQUFaO0FBQW9CSixnQkFBUSxrQ0FBT0ksS0FBSyxDQUFDSixRQUFiO0FBQXVCQyxpQkFBTyxFQUFFO0FBQWhDO0FBQTVCOztBQUNGO0FBQ0UsYUFBT0csS0FBUDtBQVJKO0FBVUQsQ0FYTSxDOzs7Ozs7Ozs7Ozs7QUNSUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTyxNQUFNTCxZQUFZLEdBQUc7QUFDeEJRLGlCQUFlLEVBQUUsQ0FETztBQUV4QkMsaUJBQWUsRUFBRSxLQUZPO0FBR3hCQyxrQkFBZ0IsRUFBRSxLQUhNO0FBSXhCQyxjQUFZLEVBQUUsRUFKVTtBQUt4QkMsZUFBYSxFQUFFLEVBTFM7QUFNeEJDLG1CQUFpQixFQUFFLENBTks7QUFPeEJDLG1CQUFpQixFQUFFLElBUEs7QUFReEJDLGFBQVcsRUFBRTtBQVJXLENBQXJCO0FBVUEsTUFBTUMsb0JBQW9CLEdBQUc7QUFDaENDLDBCQUF3QixFQUFFLDBCQURNO0FBRWhDQyxrQkFBZ0IsRUFBRSxrQkFGYztBQUdoQ0Msa0JBQWdCLEVBQUUsa0JBSGM7QUFJaENDLG1CQUFpQixFQUFFLG1CQUphO0FBS2hDQyxxQkFBbUIsRUFBRSxxQkFMVztBQU1oQ0MsWUFBVSxFQUFFLFlBTm9CO0FBT2hDQyxvQkFBa0IsRUFBRSxvQkFQWTtBQVFoQ0MsY0FBWSxFQUFFLGNBUmtCO0FBU2hDQyxxQkFBbUIsRUFBRTtBQVRXLENBQTdCO0FBWUEsTUFBTUMsS0FBSyxHQUFHO0FBQ2pCQyxPQUFLLEVBQUUsQ0FEVTtBQUVqQkMsT0FBSyxFQUFFLENBRlU7QUFHakJDLE9BQUssRUFBRSxDQUhVO0FBSWpCQyxPQUFLLEVBQUUsQ0FKVTtBQUtqQkMsT0FBSyxFQUFFLENBTFU7QUFNakJDLE9BQUssRUFBRTtBQU5VLENBQWQ7QUFTQSxNQUFNQyx5QkFBeUIsR0FBRztBQUNyQ0MsU0FBTyxFQUFFLENBRDRCO0FBRXJDQyxRQUFNLEVBQUUsQ0FGNkI7QUFHckNDLFNBQU8sRUFBRTtBQUg0QixDQUFsQztBQU1BLE1BQU1DLHFCQUFxQixHQUFHO0FBQ2pDLEdBQUNKLHlCQUF5QixDQUFDQyxPQUEzQixHQUFxQztBQUNqQ0ksWUFBUSxFQUFFLFdBRHVCO0FBRWpDQyxVQUFNLEVBQUUsU0FGeUI7QUFHakNDLFNBQUssRUFBRSx5RUFIMEI7QUFJakNDLFlBQVEsRUFDSiwyS0FMNkI7QUFNakNDLGFBQVMsRUFBRSxFQU5zQjtBQU9qQ0MsY0FBVSxFQUFFLFVBUHFCO0FBUWpDQyxZQUFRLEVBQUU7QUFSdUIsR0FESjtBQVdqQyxHQUFDWCx5QkFBeUIsQ0FBQ0UsTUFBM0IsR0FBb0M7QUFDaENHLFlBQVEsRUFBRSxhQURzQjtBQUVoQ0MsVUFBTSxFQUFFLFFBRndCO0FBR2hDQyxTQUFLLEVBQUUsc0VBSHlCO0FBSWhDQyxZQUFRLEVBQ0osa1BBTDRCO0FBTWhDQyxhQUFTLEVBQUUsRUFOcUI7QUFPaENDLGNBQVUsRUFBRSxNQVBvQjtBQVFoQ0MsWUFBUSxFQUFFO0FBUnNCLEdBWEg7QUFxQmpDLEdBQUNYLHlCQUF5QixDQUFDRyxPQUEzQixHQUFxQztBQUNqQ0UsWUFBUSxFQUFFLGdCQUR1QjtBQUVqQ0MsVUFBTSxFQUFFLFNBRnlCO0FBR2pDQyxTQUFLLEVBQUUseURBSDBCO0FBSWpDQyxZQUFRLEVBQ0osZ0hBTDZCO0FBTWpDQyxhQUFTLEVBQ0wseU1BUDZCO0FBUWpDQyxjQUFVLEVBQUUsTUFScUI7QUFTakNDLFlBQVEsRUFBRTtBQVR1QjtBQXJCSixDQUE5QixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyQ1A7QUFFQSxNQUFNO0FBQ0YzQiwwQkFERTtBQUVGSSxxQkFGRTtBQUdGSCxrQkFIRTtBQUlGQyxrQkFKRTtBQUtGQyxtQkFMRTtBQU1GRSxZQU5FO0FBT0ZDLG9CQVBFO0FBUUZDLGNBUkU7QUFTRkM7QUFURSxJQVVGVCxtRkFWSjtBQVlPLE1BQU02QixvQkFBb0IsR0FBRyxDQUFDeEMsS0FBSyxHQUFHTCwyRUFBVCxFQUF1QjhDLE1BQXZCLEtBQWtDO0FBQ2xFLFVBQVFBLE1BQU0sQ0FBQ3hDLElBQWY7QUFDSSxTQUFLYSxnQkFBTDtBQUF1QjtBQUNuQiwrQ0FDT2QsS0FEUDtBQUVJSSx5QkFBZSxFQUFFcUMsTUFBTSxDQUFDdkMsT0FBUCxDQUFlRTtBQUZwQztBQUlIOztBQUNELFNBQUtXLGlCQUFMO0FBQXdCO0FBQ3BCLCtDQUNPZixLQURQO0FBRUlLLDBCQUFnQixFQUFFb0MsTUFBTSxDQUFDdkMsT0FBUCxDQUFlRztBQUZyQztBQUlIOztBQUNELFNBQUtRLGdCQUFMO0FBQXVCO0FBQ25CLCtDQUNPYixLQURQO0FBRUlNLHNCQUFZLEVBQUVtQyxNQUFNLENBQUN2QyxPQUFQLENBQWVJO0FBRmpDO0FBSUg7O0FBQ0QsU0FBS1UsbUJBQUw7QUFBMEI7QUFDdEIsK0NBQ09oQixLQURQO0FBRUlPLHVCQUFhLEVBQUVrQyxNQUFNLENBQUN2QyxPQUFQLENBQWVLO0FBRmxDO0FBSUg7O0FBQ0QsU0FBS0ssd0JBQUw7QUFBK0I7QUFDM0IsK0NBQ09aLEtBRFA7QUFFSUcseUJBQWUsRUFBRXNDLE1BQU0sQ0FBQ3ZDO0FBRjVCO0FBSUg7O0FBQ0QsU0FBS2UsVUFBTDtBQUFpQjtBQUNiLGlDQUNPdEIsMkVBRFA7QUFHSDs7QUFDRCxTQUFLd0IsWUFBTDtBQUFtQjtBQUNmLCtDQUNPbkIsS0FEUDtBQUVJVSxxQkFBVyxFQUFFK0IsTUFBTSxDQUFDdkM7QUFGeEI7QUFJSDs7QUFDRCxTQUFLa0IsbUJBQUw7QUFBMEI7QUFDdEIsK0NBQ09wQixLQURQO0FBRUlTLDJCQUFpQixFQUFFZ0MsTUFBTSxDQUFDdkM7QUFGOUI7QUFJSDs7QUFDRCxTQUFLZ0Isa0JBQUw7QUFBeUI7QUFDckIsK0NBQ09sQixLQURQO0FBRUlHLHlCQUFlLEVBQUUsQ0FGckI7QUFHSUssMkJBQWlCLEVBQUVpQyxNQUFNLENBQUN2QztBQUg5QjtBQUtIOztBQUNEO0FBQ0ksYUFBT0YsS0FBUDtBQXhEUjtBQTBESCxDQTNETSxDOzs7Ozs7Ozs7Ozs7QUNkUDtBQUFBO0FBQUE7QUFBQTtBQUFPLE1BQU1MLFlBQVksR0FBRztBQUN4QlEsaUJBQWUsRUFBRTtBQURPLENBQXJCO0FBSUEsTUFBTWtCLEtBQUssR0FBRztBQUNqQkMsT0FBSyxFQUFFLENBRFU7QUFFakJDLE9BQUssRUFBRSxDQUZVO0FBR2pCQyxPQUFLLEVBQUUsQ0FIVTtBQUlqQkMsT0FBSyxFQUFFLENBSlU7QUFLakJDLE9BQUssRUFBRTtBQUxVLENBQWQ7QUFRQSxNQUFNZ0IsZ0JBQWdCLEdBQUc7QUFDNUJ6QixZQUFVLEVBQUUsWUFEZ0I7QUFFNUIwQixzQkFBb0IsRUFBRSxzQkFGTTtBQUc1QkMsY0FBWSxFQUFFLGNBSGM7QUFJNUI1QixxQkFBbUIsRUFBRTtBQUpPLENBQXpCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1pQO0FBRUEsTUFBTTtBQUFFQyxZQUFGO0FBQWMwQixzQkFBZDtBQUFvQ0M7QUFBcEMsSUFBcURGLHdFQUEzRDtBQUVPLE1BQU1HLGFBQWEsR0FBRyxDQUFDN0MsS0FBSyxHQUFHTCxvRUFBVCxFQUF1QjhDLE1BQXZCLEtBQWtDO0FBQzNELFVBQVFBLE1BQU0sQ0FBQ3hDLElBQWY7QUFDSSxTQUFLMEMsb0JBQUw7QUFBMkI7QUFDdkIsK0NBQ08zQyxLQURQO0FBRUlHLHlCQUFlLEVBQUVzQyxNQUFNLENBQUN2QztBQUY1QjtBQUlIOztBQUNELFNBQUswQyxZQUFMO0FBQW1CO0FBQ2YsK0NBQ081QyxLQURQO0FBRUk4QywyQkFBaUIsa0NBQU05QyxLQUFOLGFBQU1BLEtBQU4sdUJBQU1BLEtBQUssQ0FBRThDLGlCQUFiLEdBQW1DTCxNQUFNLENBQUN2QyxPQUExQztBQUZyQjtBQUlIOztBQUNELFNBQUtlLFVBQUw7QUFBaUI7QUFDYixpQ0FDT3RCLG9FQURQO0FBR0g7O0FBRUQ7QUFDSSxhQUFPSyxLQUFQO0FBcEJSO0FBc0JILENBdkJNLEM7Ozs7Ozs7Ozs7OztBQ0pQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTyxNQUFNTCxZQUFZLEdBQUc7QUFDeEJRLGlCQUFlLEVBQUUsQ0FETztBQUV4QjRDLGNBQVksRUFBRSxLQUZVO0FBR3hCQyxrQkFBZ0IsRUFBRSxDQUhNO0FBSXhCQyxpQkFBZSxFQUFFLEVBSk87QUFLeEJDLGNBQVksRUFBRSxDQUxVO0FBTXhCQyxvQkFBa0IsRUFBRSxDQU5JO0FBT3hCQyxvQkFBa0IsRUFBRSxFQVBJO0FBUXhCQyxnQkFBYyxFQUFFLEtBUlE7QUFTeEJDLGdCQUFjLEVBQUUsRUFUUTtBQVV4QkMsYUFBVyxFQUFFLEVBVlc7QUFXeEJDLGNBQVksRUFBRSxFQVhVO0FBWXhCQyxXQUFTLEVBQUUsRUFaYTtBQWF4QkMscUJBQW1CLEVBQUUsS0FiRztBQWN4QkMsVUFBUSxFQUFFO0FBZGMsQ0FBckI7QUFpQkEsTUFBTXRDLEtBQUssR0FBRztBQUNqQkMsT0FBSyxFQUFFLENBRFU7QUFFakJDLE9BQUssRUFBRSxDQUZVO0FBR2pCQyxPQUFLLEVBQUUsQ0FIVTtBQUlqQkMsT0FBSyxFQUFFLENBSlU7QUFLakJDLE9BQUssRUFBRSxDQUxVO0FBTWpCQyxPQUFLLEVBQUUsQ0FOVTtBQU9qQmlDLE9BQUssRUFBRSxDQVBVO0FBUWpCQyxPQUFLLEVBQUUsQ0FSVTtBQVNqQkMsT0FBSyxFQUFFLENBVFU7QUFVakJDLFFBQU0sRUFBRTtBQVZTLENBQWQ7QUFZQSxNQUFNQyxrQkFBa0IsR0FBRztBQUM5Qi9DLFlBQVUsRUFBRSxZQURrQjtBQUU5QmdELHlCQUF1QixFQUFFLHlCQUZLO0FBRzlCQywwQkFBd0IsRUFBRSwwQkFISTtBQUk5QkMsbUNBQWlDLEVBQUUsbUNBSkw7QUFLOUJDLHVDQUFxQyxFQUFFLHVDQUxUO0FBTTlCQyx1Q0FBcUMsRUFBRSx1Q0FOVDtBQU85QkMsMEJBQXdCLEVBQUUsMEJBUEk7QUFROUJDLDRCQUEwQixFQUFFLDRCQVJFO0FBUzlCQyw0QkFBMEIsRUFBRSw0QkFURTtBQVU5QkMseUJBQXVCLEVBQUUseUJBVks7QUFXOUJDLDRCQUEwQixFQUFFLDRCQVhFO0FBWTlCQyxxQkFBbUIsRUFBRSxxQkFaUztBQWE5QkMsbUJBQWlCLEVBQUUsbUJBYlc7QUFjOUJDLG1CQUFpQixFQUFFLG1CQWRXO0FBZTlCQyxpQkFBZSxFQUFFLGlCQWZhO0FBZ0I5QkMsaUJBQWUsRUFBRSxpQkFoQmE7QUFpQjlCQyxlQUFhLEVBQUUsZUFqQmU7QUFrQjlCQyxhQUFXLEVBQUUsYUFsQmlCO0FBbUI5QkMsbUJBQWlCLEVBQUUsbUJBbkJXO0FBb0I5QkMsdUJBQXFCLEVBQUUsdUJBcEJPO0FBcUI5QkMsZUFBYSxFQUFFO0FBckJlLENBQTNCO0FBd0JBLE1BQU1DLGlCQUFpQixHQUFHO0FBQzdCQyxXQUFTLEVBQUUsT0FEa0I7QUFFN0JDLFlBQVUsRUFBRSxPQUZpQjtBQUc3QkMsVUFBUSxFQUFFLE9BSG1CO0FBSTdCQyxZQUFVLEVBQUUsYUFKaUI7QUFLN0JDLGdCQUFjLEVBQUUsaUJBTGE7QUFNN0JDLGVBQWEsRUFBRSxnQkFOYztBQU83QkMsYUFBVyxFQUFFLEtBUGdCO0FBUTdCQyxRQUFNLEVBQUUsV0FScUI7QUFTN0JDLHNCQUFvQixFQUFFLHdCQVRPO0FBVTdCQyxjQUFZLEVBQUUsZUFWZTtBQVc3QkMsZ0JBQWMsRUFBRSxrQkFYYTtBQVk3QkMsZ0JBQWMsRUFBRSxpQkFaYTtBQWE3QkMsWUFBVSxFQUFFLGFBYmlCO0FBYzdCQyxtQkFBaUIsRUFBRSxxQkFkVTtBQWU3QkMsbUJBQWlCLEVBQUUsc0JBZlU7QUFnQjdCQyx3QkFBc0IsRUFBRSwyQkFoQks7QUFpQjdCQyxhQUFXLEVBQUU7QUFqQmdCLENBQTFCO0FBb0JBLE1BQU1DLHVCQUF1QixHQUFHO0FBQ25DQyxPQUFLLEVBQUUsQ0FENEI7QUFFbkNDLE9BQUssRUFBRTtBQUY0QixDQUFoQztBQUtBLE1BQU1DLFdBQVcsR0FBRztBQUN2QkMsOEJBQTRCLEVBQUUsbUJBRFA7QUFFdkJDLHdCQUFzQixFQUFFLGlCQUZEO0FBR3ZCQyx5QkFBdUIsRUFBRSxrQkFIRjtBQUl2QkMsc0JBQW9CLEVBQUU7QUFKQyxDQUFwQjtBQU9BLE1BQU1DLGNBQWMsR0FBRztBQUMxQjVFLE9BQUssRUFBRSwyREFEbUI7QUFFMUJDLFVBQVEsRUFDSiw0R0FIc0I7QUFJMUJDLFdBQVMsRUFDTCw4SkFMc0I7QUFNMUIyRSxZQUFVLEVBQUUsSUFOYztBQU8xQjFFLFlBQVUsRUFBRSxtQkFQYztBQVExQjJFLFlBQVUsRUFBRSxPQVJjO0FBUzFCaEYsVUFBUSxFQUFFLGFBVGdCO0FBVTFCaUYsWUFBVSxFQUFFO0FBVmMsQ0FBdkIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyRlA7QUFDQTtBQUNBLE1BQU07QUFDRmpHLFlBREU7QUFFRmdELHlCQUZFO0FBR0ZDLDBCQUhFO0FBSUZDLG1DQUpFO0FBS0ZDLHVDQUxFO0FBTUZDLHVDQU5FO0FBT0ZDLDBCQVBFO0FBUUZDLDRCQVJFO0FBU0ZDLDRCQVRFO0FBVUZDLHlCQVZFO0FBV0ZDLDRCQVhFO0FBWUZDLHFCQVpFO0FBYUZDLG1CQWJFO0FBY0ZDLG1CQWRFO0FBZUZDLGlCQWZFO0FBZ0JGQyxpQkFoQkU7QUFpQkZDLGVBakJFO0FBa0JGQyxhQWxCRTtBQW1CRkMsbUJBbkJFO0FBb0JGQyx1QkFwQkU7QUFxQkZDO0FBckJFLElBc0JGcEIsc0VBdEJKOztBQXdCQSxNQUFNbUQsc0JBQXNCLEdBQUlDLEtBQUQsSUFBVztBQUN0QyxTQUFPQSxLQUFLLEdBQUcsTUFBSCxHQUFZLE9BQXhCO0FBQ0gsQ0FGRDs7QUFHQSxNQUFNQyxpQkFBaUIsR0FBSWYsV0FBRCxJQUFpQjtBQUN2QyxNQUFJZ0IsY0FBYyxHQUFHLEVBQXJCO0FBQ0FoQixhQUFXLFNBQVgsSUFBQUEsV0FBVyxXQUFYLFlBQUFBLFdBQVcsQ0FBRWlCLE1BQWIsQ0FBb0JDLE9BQXBCLENBQTZCSixLQUFELElBQVc7QUFDbkNFLGtCQUFjLEdBQUcsQ0FBQyxHQUFHQSxjQUFKLEVBQW9CRixLQUFwQixhQUFvQkEsS0FBcEIsdUJBQW9CQSxLQUFLLENBQUVLLEVBQTNCLENBQWpCO0FBQ0gsR0FGRDtBQUdBLFNBQU9ILGNBQVA7QUFDSCxDQU5EOztBQU9PLE1BQU1JLGdCQUFnQixHQUFHLENBQUMxSCxLQUFLLEdBQUdMLGdFQUFULEVBQXVCOEMsTUFBdkIsS0FBa0M7QUFDOUQsUUFBTTtBQUFFVztBQUFGLE1BQXlCcEQsS0FBL0I7O0FBQ0EsVUFBUXlDLE1BQU0sQ0FBQ3hDLElBQWY7QUFDSSxTQUFLZ0UsdUJBQUw7QUFBOEI7QUFDMUIsK0NBQ09qRSxLQURQO0FBRUlHLHlCQUFlLEVBQUVzQyxNQUFNLENBQUN2QztBQUY1QjtBQUlIOztBQUNELFNBQUtnRSx3QkFBTDtBQUErQjtBQUMzQiwrQ0FDT2xFLEtBRFA7QUFFSStDLHNCQUFZLEVBQUVOLE1BQU0sQ0FBQ3ZDLE9BQVAsQ0FBZTZDO0FBRmpDO0FBSUg7O0FBQ0QsU0FBS29CLGlDQUFMO0FBQXdDO0FBQ3BDLFlBQUl3RCxRQUFRLEdBQUcsSUFBSUMsS0FBSixDQUFVbkYsTUFBTSxDQUFDdkMsT0FBUCxDQUFlOEMsZ0JBQXpCLEVBQTJDNkUsSUFBM0MsQ0FBZ0QsQ0FBaEQsQ0FBZjtBQUNBRixnQkFBUSxDQUFDSCxPQUFULENBQWlCLENBQUNNLElBQUQsRUFBT0MsS0FBUCxLQUFpQjtBQUM5Qkosa0JBQVEsQ0FBQ0ksS0FBRCxDQUFSLEdBQWtCQSxLQUFLLEdBQUcsQ0FBMUI7QUFDSCxTQUZEO0FBSUEsK0NBQ08vSCxLQURQO0FBRUlnRCwwQkFBZ0IsRUFBRVAsTUFBTSxDQUFDdkMsT0FBUCxDQUFlOEMsZ0JBRnJDO0FBR0lDLHlCQUFlLEVBQUUwRSxRQUhyQjtBQUlJeEUsNEJBQWtCLEVBQUUsQ0FKeEI7QUFLSUQsc0JBQVksRUFBRTtBQUxsQjtBQU9IOztBQUNELFNBQUtrQixxQ0FBTDtBQUE0QztBQUN4QywrQ0FDT3BFLEtBRFA7QUFFSW9ELDRCQUFrQixrQ0FDWEEsa0JBRFc7QUFFZCxhQUFDWCxNQUFNLENBQUN2QyxPQUFQLENBQWVnRCxZQUFoQixtQ0FDT0Usa0JBQWtCLENBQUNYLE1BQU0sQ0FBQ3ZDLE9BQVAsQ0FBZWdELFlBQWhCLENBRHpCLEdBRU9ULE1BQU0sQ0FBQ3ZDLE9BRmQ7QUFGYyxZQUZ0QjtBQVNJaUQsNEJBQWtCLEVBQUU7QUFUeEI7QUFXSDs7QUFDRCxTQUFLa0IscUNBQUw7QUFBNEM7QUFDeEMsK0NBQ09yRSxLQURQO0FBRUlvRCw0QkFBa0Isa0NBQ1hBLGtCQURXO0FBRWQsYUFBQ1gsTUFBTSxDQUFDdkMsT0FBUCxDQUFlZ0QsWUFBaEIsbUNBQ09FLGtCQUFrQixDQUFDWCxNQUFNLENBQUN2QyxPQUFQLENBQWVnRCxZQUFoQixDQUR6QixHQUVPVCxNQUFNLENBQUN2QyxPQUZkO0FBRmMsWUFGdEI7QUFTSWlELDRCQUFrQixFQUFFO0FBVHhCO0FBV0g7O0FBQ0QsU0FBS21CLHdCQUFMO0FBQStCO0FBQzNCLCtDQUNPdEUsS0FEUDtBQUVJa0Qsc0JBQVksRUFBRVQsTUFBTSxDQUFDdkM7QUFGekI7QUFJSDs7QUFDRCxTQUFLcUUsMEJBQUw7QUFBaUM7QUFDN0IsK0NBQ092RSxLQURQO0FBRUltRCw0QkFBa0IsRUFBRTtBQUZ4QjtBQUlIOztBQUNELFNBQUtxQiwwQkFBTDtBQUFpQztBQUM3QiwrQ0FDT3hFLEtBRFA7QUFFSW1ELDRCQUFrQixFQUFFO0FBRnhCO0FBSUg7O0FBQ0QsU0FBS3NCLHVCQUFMO0FBQThCO0FBQzFCLCtDQUNPekUsS0FEUDtBQUVJaUQseUJBQWUsRUFBRSxFQUZyQjtBQUdJQyxzQkFBWSxFQUFFO0FBSGxCO0FBS0g7O0FBQ0QsU0FBS3dCLDBCQUFMO0FBQWlDO0FBQzdCLCtDQUNPMUUsS0FEUDtBQUVJcUQsd0JBQWMsRUFBRVosTUFBTSxDQUFDdkMsT0FBUCxDQUFlbUQ7QUFGbkM7QUFJSDs7QUFDRCxTQUFLc0IsbUJBQUw7QUFBMEI7QUFDdEIsK0NBQ08zRSxLQURQO0FBRUlzRCx3QkFBYyxFQUFFYixNQUFNLENBQUN2QztBQUYzQjtBQUlIOztBQUNELFNBQUswRSxpQkFBTDtBQUF3QjtBQUNwQiwrQ0FDTzVFLEtBRFA7QUFFSXVELHFCQUFXLEVBQUVkLE1BQU0sQ0FBQ3ZDO0FBRnhCO0FBSUg7O0FBQ0QsU0FBSzJFLGlCQUFMO0FBQXdCO0FBQ3BCLCtDQUNPN0UsS0FEUDtBQUVJd0Qsc0JBQVksRUFBRWYsTUFBTSxDQUFDdkM7QUFGekI7QUFJSDs7QUFDRCxTQUFLNEUsZUFBTDtBQUFzQjtBQUNsQiwrQ0FDTzlFLEtBRFA7QUFFSXlELG1CQUFTLEVBQUVoQixNQUFNLENBQUN2QztBQUZ0QjtBQUlIOztBQUNELFNBQUtlLFVBQUw7QUFBaUI7QUFDYixpQ0FDT3RCLGdFQURQO0FBR0g7O0FBQ0QsU0FBS29GLGVBQUw7QUFBc0I7QUFDbEIsWUFBSTRDLFFBQVEsR0FBRyxJQUFJQyxLQUFKLENBQVVJLE1BQU0sQ0FBQ0MsSUFBUCxDQUFZN0Usa0JBQVosRUFBZ0M4RSxNQUFoQyxHQUF5QyxDQUFuRCxFQUFzREwsSUFBdEQsQ0FBMkQsQ0FBM0QsQ0FBZjtBQUNBRixnQkFBUSxDQUFDSCxPQUFULENBQWlCLENBQUNNLElBQUQsRUFBT0MsS0FBUCxLQUFpQjtBQUM5Qkosa0JBQVEsQ0FBQ0ksS0FBRCxDQUFSLEdBQWtCQSxLQUFLLEdBQUcsQ0FBMUI7QUFDSCxTQUZEO0FBSUEsK0NBQ08vSCxLQURQO0FBRUlnRCwwQkFBZ0IsRUFBRTJFLFFBQVEsQ0FBQ08sTUFBVCxJQUFtQixDQUZ6QztBQUdJakYseUJBQWUsRUFBRTBFLFFBSHJCO0FBSUl4RSw0QkFBa0IsRUFBRSxDQUp4QjtBQUtJRCxzQkFBWSxFQUFFeUUsUUFBUSxDQUFDTyxNQUFULElBQW1CLENBTHJDO0FBTUkvSCx5QkFBZSxFQUFFO0FBTnJCO0FBUUg7O0FBQ0QsU0FBSzZFLGFBQUw7QUFBb0I7QUFDaEIsY0FBTW1ELHNCQUFzQixxQkFBUS9FLGtCQUFSLENBQTVCOztBQUNBLGNBQU1nRixhQUFhLEdBQUdDLDZDQUFDLENBQUNDLElBQUYsQ0FBT0gsc0JBQVAsRUFBK0IxRixNQUFNLENBQUN2QyxPQUF0QyxDQUF0Qjs7QUFDQSwrQ0FDT0YsS0FEUDtBQUVJb0QsNEJBQWtCLG9CQUFPZ0YsYUFBUDtBQUZ0QjtBQUlIOztBQUNELFNBQUtuRCxXQUFMO0FBQWtCO0FBQ2QsK0NBQ09qRixLQURQO0FBRUltRCw0QkFBa0IsRUFBRSxDQUZ4QjtBQUdJaEQseUJBQWUsRUFBRSxDQUhyQjtBQUlJK0Msc0JBQVksRUFBRVQsTUFBTSxDQUFDdkMsT0FBUCxDQUFlZ0Q7QUFKakM7QUFNSDs7QUFDRCxTQUFLZ0MsaUJBQUw7QUFBd0I7QUFDcEIsY0FBTXFELFdBQVcsR0FBRyxDQUFDLEdBQUc5RixNQUFNLENBQUN2QyxPQUFYLENBQXBCO0FBQ0EsWUFBSXlILFFBQVEsR0FBRyxJQUFJQyxLQUFKLENBQVVuRixNQUFNLENBQUN2QyxPQUFQLENBQWVnSSxNQUF6QixFQUFpQ0wsSUFBakMsQ0FBc0MsQ0FBdEMsQ0FBZjtBQUNBRixnQkFBUSxDQUFDSCxPQUFULENBQWlCLENBQUNNLElBQUQsRUFBT0MsS0FBUCxLQUFpQjtBQUM5Qkosa0JBQVEsQ0FBQ0ksS0FBRCxDQUFSLEdBQWtCQSxLQUFLLEdBQUcsQ0FBMUI7QUFDSCxTQUZEO0FBR0EsWUFBSVMsVUFBVSxHQUFHLEVBQWpCO0FBQ0FELG1CQUFXLENBQUNmLE9BQVosQ0FBb0IsQ0FBQ00sSUFBRCxFQUFPQyxLQUFQLEtBQWlCO0FBQ2pDUyxvQkFBVSxtQ0FDSEEsVUFERztBQUVOLGFBQUNULEtBQUssR0FBRyxDQUFULG1DQUNPRCxJQURQO0FBRUlXLHlCQUFXLEVBQUV0QixzQkFBc0IsQ0FBQ1csSUFBSSxDQUFDVyxXQUFOLENBRnZDO0FBR0lDLGlDQUFtQixFQUFFdkIsc0JBQXNCLENBQUNXLElBQUksQ0FBQ1ksbUJBQU4sQ0FIL0M7QUFJSUMsa0NBQW9CLEVBQUV4QixzQkFBc0IsQ0FBQ1csSUFBSSxDQUFDYSxvQkFBTixDQUpoRDtBQUtJQyx1Q0FBeUIsRUFBRXpCLHNCQUFzQixDQUM3Q1csSUFBSSxDQUFDYyx5QkFEd0MsQ0FMckQ7QUFRSXRDLHlCQUFXLEVBQUVlLGlCQUFpQixDQUFDUyxJQUFJLENBQUNlLFlBQU47QUFSbEM7QUFGTSxZQUFWO0FBYUgsU0FkRDtBQWVBLCtDQUNPN0ksS0FEUDtBQUVJZ0QsMEJBQWdCLEVBQUVQLE1BQU0sQ0FBQ3ZDLE9BQVAsQ0FBZWdJLE1BRnJDO0FBR0lqRix5QkFBZSxFQUFFMEUsUUFIckI7QUFJSXZFLDRCQUFrQixvQkFBT29GLFVBQVA7QUFKdEI7QUFNSDs7QUFDRCxTQUFLckQscUJBQUw7QUFBNEI7QUFDeEIsK0NBQ09uRixLQURQO0FBRUkwRCw2QkFBbUIsRUFBRWpCLE1BQU0sQ0FBQ3ZDLE9BQVAsQ0FBZXdEO0FBRnhDO0FBSUg7O0FBQ0QsU0FBSzBCLGFBQUw7QUFBb0I7QUFDaEIsK0NBQ09wRixLQURQO0FBRUkyRCxrQkFBUSxFQUFFbEIsTUFBTSxDQUFDdkM7QUFGckI7QUFJSDs7QUFDRDtBQUNJLGFBQU9GLEtBQVA7QUExTFI7QUE0TEgsQ0E5TE0sQzs7Ozs7Ozs7Ozs7O0FDcENQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFPLE1BQU1MLFlBQVksR0FBRztBQUN4QlEsaUJBQWUsRUFBRSxDQURPO0FBRXhCQyxpQkFBZSxFQUFFLEtBRk87QUFHeEIwSSxzQkFBb0IsRUFBRSxLQUhFO0FBSXhCQyxjQUFZLEVBQUU7QUFKVSxDQUFyQjtBQU1BLE1BQU1DLHdCQUF3QixHQUFHO0FBQ3BDQywrQkFBNkIsRUFBRSwrQkFESztBQUVwQ3BJLGtCQUFnQixFQUFFLGtCQUZrQjtBQUdwQ0Msa0JBQWdCLEVBQUUsa0JBSGtCO0FBSXBDb0ksd0JBQXNCLEVBQUUsd0JBSlk7QUFLcENsSSxxQkFBbUIsRUFBRSxxQkFMZTtBQU1wQ0MsWUFBVSxFQUFFLFlBTndCO0FBT3BDa0kseUJBQXVCLEVBQUU7QUFQVyxDQUFqQztBQVVBLE1BQU05SCxLQUFLLEdBQUc7QUFDakJDLE9BQUssRUFBRSxDQURVO0FBRWpCQyxPQUFLLEVBQUUsQ0FGVTtBQUdqQkMsT0FBSyxFQUFFLENBSFU7QUFJakJDLE9BQUssRUFBRSxDQUpVO0FBS2pCQyxPQUFLLEVBQUUsQ0FMVTtBQU1qQkMsT0FBSyxFQUFFO0FBTlUsQ0FBZDtBQVNBLE1BQU15SCw2QkFBNkIsR0FBRztBQUN6Q3ZILFNBQU8sRUFBRSxDQURnQztBQUV6Q0MsUUFBTSxFQUFFLENBRmlDO0FBR3pDQyxTQUFPLEVBQUU7QUFIZ0MsQ0FBdEM7QUFNQSxNQUFNc0gseUJBQXlCLEdBQUcsRUFBbEMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0JQO0FBRUEsTUFBTTtBQUNGSiwrQkFERTtBQUVGbkksa0JBRkU7QUFHRm9JLHdCQUhFO0FBSUZqSSxZQUpFO0FBS0ZrSTtBQUxFLElBTUZILGtGQU5KO0FBUU8sTUFBTU0sZUFBZSxHQUFHLENBQUN0SixLQUFLLEdBQUdMLHNFQUFULEVBQXVCOEMsTUFBdkIsS0FBa0M7QUFDN0QsVUFBUUEsTUFBTSxDQUFDeEMsSUFBZjtBQUNJLFNBQUthLGdCQUFMO0FBQXVCO0FBQ25CLCtDQUNPZCxLQURQO0FBRUlJLHlCQUFlLEVBQUVxQyxNQUFNLENBQUN2QyxPQUFQLENBQWVFO0FBRnBDO0FBSUg7O0FBQ0QsU0FBSzhJLHNCQUFMO0FBQTZCO0FBQ3pCLCtDQUNPbEosS0FEUDtBQUVJOEksOEJBQW9CLEVBQUVyRyxNQUFNLENBQUN2QyxPQUFQLENBQWU0STtBQUZ6QztBQUlIOztBQUNELFNBQUtHLDZCQUFMO0FBQW9DO0FBQ2hDLCtDQUNPakosS0FEUDtBQUVJRyx5QkFBZSxFQUFFc0MsTUFBTSxDQUFDdkM7QUFGNUI7QUFJSDs7QUFDRCxTQUFLZSxVQUFMO0FBQWlCO0FBQ2IsaUNBQ090QixzRUFEUDtBQUdIOztBQUNELFNBQUt3Six1QkFBTDtBQUE4QjtBQUMxQiwrQ0FDT25KLEtBRFA7QUFFSUcseUJBQWUsRUFBRSxDQUZyQjtBQUdJb0osK0JBQXFCLEVBQUU5RyxNQUFNLENBQUN2QztBQUhsQztBQUtIOztBQUNEO0FBQ0ksYUFBT0YsS0FBUDtBQWhDUjtBQWtDSCxDQW5DTSxDOzs7Ozs7Ozs7Ozs7QUNWUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTyxNQUFNTCxZQUFZLEdBQUc7QUFDeEJRLGlCQUFlLEVBQUUsQ0FETztBQUV4QkMsaUJBQWUsRUFBRSxLQUZPO0FBR3hCb0osc0JBQW9CLEVBQUUsS0FIRTtBQUl4QmxKLGNBQVksRUFBRSxFQUpVO0FBS3hCQyxlQUFhLEVBQUUsRUFMUztBQU14QndJLGNBQVksRUFBRTtBQU5VLENBQXJCO0FBUUEsTUFBTVUsd0JBQXdCLEdBQUc7QUFDcENDLHdCQUFzQixFQUFFLHdCQURZO0FBRXBDN0ksa0JBQWdCLEVBQUUsa0JBRmtCO0FBR3BDQyxrQkFBZ0IsRUFBRSxrQkFIa0I7QUFJcEM2SSxpQkFBZSxFQUFFLGlCQUptQjtBQUtwQzNJLHFCQUFtQixFQUFFLHFCQUxlO0FBTXBDQyxZQUFVLEVBQUUsWUFOd0I7QUFPcEMySSxrQkFBZ0IsRUFBRTtBQVBrQixDQUFqQztBQVVBLE1BQU12SSxLQUFLLEdBQUc7QUFDakJDLE9BQUssRUFBRSxDQURVO0FBRWpCQyxPQUFLLEVBQUUsQ0FGVTtBQUdqQkMsT0FBSyxFQUFFLENBSFU7QUFJakJDLE9BQUssRUFBRSxDQUpVO0FBS2pCQyxPQUFLLEVBQUUsQ0FMVTtBQU1qQkMsT0FBSyxFQUFFO0FBTlUsQ0FBZDtBQVNBLE1BQU1rSSw2QkFBNkIsR0FBRztBQUN6Q2hJLFNBQU8sRUFBRSxDQURnQztBQUV6Q0MsUUFBTSxFQUFFLENBRmlDO0FBR3pDQyxTQUFPLEVBQUU7QUFIZ0MsQ0FBdEM7QUFNQSxNQUFNK0gseUJBQXlCLEdBQUcsRUFBbEMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakNQO0FBRUEsTUFBTTtBQUNGSix3QkFERTtBQUVGNUksa0JBRkU7QUFHRjZJLGlCQUhFO0FBSUYxSSxZQUpFO0FBS0YySTtBQUxFLElBTUZILGtGQU5KO0FBUU8sTUFBTU0sZUFBZSxHQUFHLENBQUMvSixLQUFLLEdBQUdMLHNFQUFULEVBQXVCOEMsTUFBdkIsS0FBa0M7QUFDN0QsVUFBUUEsTUFBTSxDQUFDeEMsSUFBZjtBQUNJLFNBQUthLGdCQUFMO0FBQXVCO0FBQ25CLCtDQUNPZCxLQURQO0FBRUlJLHlCQUFlLEVBQUVxQyxNQUFNLENBQUN2QyxPQUFQLENBQWVFO0FBRnBDO0FBSUg7O0FBQ0QsU0FBS3VKLGVBQUw7QUFBc0I7QUFDbEIsK0NBQ08zSixLQURQO0FBRUl3Siw4QkFBb0IsRUFBRS9HLE1BQU0sQ0FBQ3ZDLE9BQVAsQ0FBZXNKO0FBRnpDO0FBSUg7O0FBQ0QsU0FBS0Usc0JBQUw7QUFBNkI7QUFDekIsK0NBQ08xSixLQURQO0FBRUlHLHlCQUFlLEVBQUVzQyxNQUFNLENBQUN2QztBQUY1QjtBQUlIOztBQUNELFNBQUtlLFVBQUw7QUFBaUI7QUFDYixpQ0FDT3RCLHNFQURQO0FBR0g7O0FBQ0QsU0FBS2lLLGdCQUFMO0FBQXVCO0FBQ25CLCtDQUNPNUosS0FEUDtBQUVJRyx5QkFBZSxFQUFFLENBRnJCO0FBR0k2SiwrQkFBcUIsRUFBRXZILE1BQU0sQ0FBQ3ZDO0FBSGxDO0FBS0g7O0FBQ0Q7QUFDSSxhQUFPRixLQUFQO0FBaENSO0FBa0NILENBbkNNLEM7Ozs7Ozs7Ozs7OztBQ1ZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFPLE1BQU1MLFlBQVksR0FBRztBQUN4QlEsaUJBQWUsRUFBRSxDQURPO0FBRXhCQyxpQkFBZSxFQUFFLEtBRk87QUFHeEI2SiwrQkFBNkIsRUFBRSxLQUhQO0FBSXhCbEIsY0FBWSxFQUFFO0FBSlUsQ0FBckI7QUFNQSxNQUFNbUIsaUNBQWlDLEdBQUc7QUFDN0NDLHlDQUF1QyxFQUFFLHlDQURJO0FBRTdDdEosa0JBQWdCLEVBQUUsa0JBRjJCO0FBRzdDQyxrQkFBZ0IsRUFBRSxrQkFIMkI7QUFJN0NzSixrQ0FBZ0MsRUFBRSxrQ0FKVztBQUs3Q3BKLHFCQUFtQixFQUFFLHFCQUx3QjtBQU03Q0MsWUFBVSxFQUFFLFlBTmlDO0FBTzdDb0osbUNBQWlDLEVBQUU7QUFQVSxDQUExQztBQVVBLE1BQU1oSixLQUFLLEdBQUc7QUFDakJDLE9BQUssRUFBRSxDQURVO0FBRWpCQyxPQUFLLEVBQUUsQ0FGVTtBQUdqQkMsT0FBSyxFQUFFLENBSFU7QUFJakJDLE9BQUssRUFBRSxDQUpVO0FBS2pCQyxPQUFLLEVBQUU7QUFMVSxDQUFkO0FBUUEsTUFBTTRJLHNDQUFzQyxHQUFHO0FBQ2xEekksU0FBTyxFQUFFLENBRHlDO0FBRWxEQyxRQUFNLEVBQUUsQ0FGMEM7QUFHbERDLFNBQU8sRUFBRTtBQUh5QyxDQUEvQztBQU1BLE1BQU13SSxrQ0FBa0MsR0FBRyxFQUEzQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5QlA7QUFFQSxNQUFNO0FBQ0ZKLHlDQURFO0FBRUZySixrQkFGRTtBQUdGc0osa0NBSEU7QUFJRm5KLFlBSkU7QUFLRm9KO0FBTEUsSUFNRkgsb0dBTko7QUFRTyxNQUFNTSx3QkFBd0IsR0FBRyxDQUFDeEssS0FBSyxHQUFHTCwrRUFBVCxFQUF1QjhDLE1BQXZCLEtBQWtDO0FBQ3RFLFVBQVFBLE1BQU0sQ0FBQ3hDLElBQWY7QUFDSSxTQUFLYSxnQkFBTDtBQUF1QjtBQUNuQiwrQ0FDT2QsS0FEUDtBQUVJSSx5QkFBZSxFQUFFcUMsTUFBTSxDQUFDdkMsT0FBUCxDQUFlRTtBQUZwQztBQUlIOztBQUNELFNBQUtnSyxnQ0FBTDtBQUF1QztBQUNuQywrQ0FDT3BLLEtBRFA7QUFFSWlLLHVDQUE2QixFQUFFeEgsTUFBTSxDQUFDdkMsT0FBUCxDQUFlK0o7QUFGbEQ7QUFJSDs7QUFDRCxTQUFLRSx1Q0FBTDtBQUE4QztBQUMxQywrQ0FDT25LLEtBRFA7QUFFSUcseUJBQWUsRUFBRXNDLE1BQU0sQ0FBQ3ZDO0FBRjVCO0FBSUg7O0FBQ0QsU0FBS2UsVUFBTDtBQUFpQjtBQUNiLGlDQUNPdEIsK0VBRFA7QUFHSDs7QUFDRCxTQUFLMEssaUNBQUw7QUFBd0M7QUFDcEMsK0NBQ09ySyxLQURQO0FBRUlHLHlCQUFlLEVBQUUsQ0FGckI7QUFHSXNLLHdDQUE4QixFQUFFaEksTUFBTSxDQUFDdkM7QUFIM0M7QUFLSDs7QUFDRDtBQUNJLGFBQU9GLEtBQVA7QUFoQ1I7QUFrQ0gsQ0FuQ00sQzs7Ozs7Ozs7Ozs7O0FDVlA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU8sTUFBTUwsWUFBWSxHQUFHO0FBQ3hCUSxpQkFBZSxFQUFFLENBRE87QUFFeEJDLGlCQUFlLEVBQUUsS0FGTztBQUd4QnNLLHdCQUFzQixFQUFFLEtBSEE7QUFJeEIzQixjQUFZLEVBQUU7QUFKVSxDQUFyQjtBQU1BLE1BQU00QiwwQkFBMEIsR0FBRztBQUN0Q0MsaUNBQStCLEVBQUUsaUNBREs7QUFFdEMvSixrQkFBZ0IsRUFBRSxrQkFGb0I7QUFHdENDLGtCQUFnQixFQUFFLGtCQUhvQjtBQUl0QytKLDBCQUF3QixFQUFFLDBCQUpZO0FBS3RDN0oscUJBQW1CLEVBQUUscUJBTGlCO0FBTXRDQyxZQUFVLEVBQUUsWUFOMEI7QUFPdEM2SiwyQkFBeUIsRUFBRTtBQVBXLENBQW5DO0FBVUEsTUFBTXpKLEtBQUssR0FBRztBQUNqQkMsT0FBSyxFQUFFLENBRFU7QUFFakJDLE9BQUssRUFBRTtBQUZVLENBQWQ7QUFLQSxNQUFNd0osK0JBQStCLEdBQUc7QUFDM0NsSixTQUFPLEVBQUUsQ0FEa0M7QUFFM0NDLFFBQU0sRUFBRSxDQUZtQztBQUczQ0MsU0FBTyxFQUFFO0FBSGtDLENBQXhDO0FBTUEsTUFBTWlKLDJCQUEyQixHQUFHLEVBQXBDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNCUDtBQUVBLE1BQU07QUFDRkosaUNBREU7QUFFRjlKLGtCQUZFO0FBR0YrSiwwQkFIRTtBQUlGNUosWUFKRTtBQUtGNko7QUFMRSxJQU1GSCxzRkFOSjtBQVFPLE1BQU1NLGlCQUFpQixHQUFHLENBQUNqTCxLQUFLLEdBQUdMLHdFQUFULEVBQXVCOEMsTUFBdkIsS0FBa0M7QUFDL0QsVUFBUUEsTUFBTSxDQUFDeEMsSUFBZjtBQUNJLFNBQUthLGdCQUFMO0FBQXVCO0FBQ25CLCtDQUNPZCxLQURQO0FBRUlJLHlCQUFlLEVBQUVxQyxNQUFNLENBQUN2QyxPQUFQLENBQWVFO0FBRnBDO0FBSUg7O0FBQ0QsU0FBS3lLLHdCQUFMO0FBQStCO0FBQzNCLCtDQUNPN0ssS0FEUDtBQUVJMEssZ0NBQXNCLEVBQUVqSSxNQUFNLENBQUN2QyxPQUFQLENBQWV3SztBQUYzQztBQUlIOztBQUNELFNBQUtFLCtCQUFMO0FBQXNDO0FBQ2xDLCtDQUNPNUssS0FEUDtBQUVJRyx5QkFBZSxFQUFFc0MsTUFBTSxDQUFDdkM7QUFGNUI7QUFJSDs7QUFDRCxTQUFLZSxVQUFMO0FBQWlCO0FBQ2IsaUNBQ090Qix3RUFEUDtBQUdIOztBQUNELFNBQUttTCx5QkFBTDtBQUFnQztBQUM1QiwrQ0FDTzlLLEtBRFA7QUFFSUcseUJBQWUsRUFBRSxDQUZyQjtBQUdJK0ssaUNBQXVCLEVBQUV6SSxNQUFNLENBQUN2QztBQUhwQztBQUtIOztBQUNEO0FBQ0ksYUFBT0YsS0FBUDtBQWhDUjtBQWtDSCxDQW5DTSxDOzs7Ozs7Ozs7Ozs7QUNWUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTyxNQUFNTCxZQUFZLEdBQUc7QUFDeEJRLGlCQUFlLEVBQUUsQ0FETztBQUV4QkMsaUJBQWUsRUFBRSxLQUZPO0FBR3hCK0ssYUFBVyxFQUFFLEtBSFc7QUFJeEI3SyxjQUFZLEVBQUUsRUFKVTtBQUt4QkMsZUFBYSxFQUFFLEVBTFM7QUFNeEJ3SSxjQUFZLEVBQUU7QUFOVSxDQUFyQjtBQVFBLE1BQU1xQyxlQUFlLEdBQUc7QUFDM0JDLHFCQUFtQixFQUFFLHFCQURNO0FBRTNCeEssa0JBQWdCLEVBQUUsa0JBRlM7QUFHM0JDLGtCQUFnQixFQUFFLGtCQUhTO0FBSTNCd0ssY0FBWSxFQUFFLGNBSmE7QUFLM0J0SyxxQkFBbUIsRUFBRSxxQkFMTTtBQU0zQkMsWUFBVSxFQUFFLFlBTmU7QUFPM0JzSyxlQUFhLEVBQUU7QUFQWSxDQUF4QjtBQVVBLE1BQU1sSyxLQUFLLEdBQUc7QUFDakJDLE9BQUssRUFBRSxDQURVO0FBRWpCQyxPQUFLLEVBQUUsQ0FGVTtBQUdqQkMsT0FBSyxFQUFFLENBSFU7QUFJakJDLE9BQUssRUFBRSxDQUpVO0FBS2pCQyxPQUFLLEVBQUUsQ0FMVTtBQU1qQkMsT0FBSyxFQUFFLENBTlU7QUFPakJpQyxPQUFLLEVBQUUsQ0FQVTtBQVFqQkMsT0FBSyxFQUFFLENBUlU7QUFTakJDLE9BQUssRUFBRTtBQVRVLENBQWQ7QUFZQSxNQUFNMEgsb0JBQW9CLEdBQUc7QUFDaEMzSixTQUFPLEVBQUUsQ0FEdUI7QUFFaENDLFFBQU0sRUFBRSxDQUZ3QjtBQUdoQ0MsU0FBTyxFQUFFO0FBSHVCLENBQTdCO0FBTUEsTUFBTTBKLGdCQUFnQixHQUFHLEVBQXpCLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BDUDtBQUVBLE1BQU07QUFDRkoscUJBREU7QUFFRnZLLGtCQUZFO0FBR0Z3SyxjQUhFO0FBSUZySyxZQUpFO0FBS0ZzSztBQUxFLElBTUZILDJFQU5KO0FBUU8sTUFBTU0saUJBQWlCLEdBQUcsQ0FBQzFMLEtBQUssR0FBR0wsd0VBQVQsRUFBdUI4QyxNQUF2QixLQUFrQztBQUMvRCxVQUFRQSxNQUFNLENBQUN4QyxJQUFmO0FBQ0ksU0FBS2EsZ0JBQUw7QUFBdUI7QUFDbkIsK0NBQ09kLEtBRFA7QUFFSUkseUJBQWUsRUFBRXFDLE1BQU0sQ0FBQ3ZDLE9BQVAsQ0FBZUU7QUFGcEM7QUFJSDs7QUFDRCxTQUFLa0wsWUFBTDtBQUFtQjtBQUNmLCtDQUNPdEwsS0FEUDtBQUVJbUwscUJBQVcsRUFBRTFJLE1BQU0sQ0FBQ3ZDLE9BQVAsQ0FBZWlMO0FBRmhDO0FBSUg7O0FBQ0QsU0FBS0UsbUJBQUw7QUFBMEI7QUFDdEIsK0NBQ09yTCxLQURQO0FBRUlHLHlCQUFlLEVBQUVzQyxNQUFNLENBQUN2QztBQUY1QjtBQUlIOztBQUNELFNBQUtlLFVBQUw7QUFBaUI7QUFDYixpQ0FDT3RCLHdFQURQO0FBR0g7O0FBQ0QsU0FBSzRMLGFBQUw7QUFBb0I7QUFDaEIsK0NBQ092TCxLQURQO0FBRUlHLHlCQUFlLEVBQUUsQ0FGckI7QUFHSTRJLHNCQUFZLEVBQUV0RyxNQUFNLENBQUN2QztBQUh6QjtBQUtIOztBQUNEO0FBQ0ksYUFBT0YsS0FBUDtBQWhDUjtBQWtDSCxDQW5DTSxDOzs7Ozs7Ozs7Ozs7QUNWUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTyxNQUFNTCxZQUFZLEdBQUc7QUFDeEJRLGlCQUFlLEVBQUUsQ0FETztBQUV4QkMsaUJBQWUsRUFBRSxLQUZPO0FBR3hCdUwsb0JBQWtCLEVBQUUsS0FISTtBQUl4QjVDLGNBQVksRUFBRTtBQUpVLENBQXJCO0FBTUEsTUFBTTZDLHNCQUFzQixHQUFHO0FBQ2xDQyw2QkFBMkIsRUFBRSw2QkFESztBQUVsQ2hMLGtCQUFnQixFQUFFLGtCQUZnQjtBQUdsQ0Msa0JBQWdCLEVBQUUsa0JBSGdCO0FBSWxDZ0wsc0JBQW9CLEVBQUUsc0JBSlk7QUFLbEM5SyxxQkFBbUIsRUFBRSxxQkFMYTtBQU1sQ0MsWUFBVSxFQUFFLFlBTnNCO0FBT2xDOEssdUJBQXFCLEVBQUU7QUFQVyxDQUEvQjtBQVVBLE1BQU0xSyxLQUFLLEdBQUc7QUFDakJDLE9BQUssRUFBRSxDQURVO0FBRWpCQyxPQUFLLEVBQUU7QUFGVSxDQUFkO0FBS0EsTUFBTXlLLDJCQUEyQixHQUFHO0FBQ3ZDbkssU0FBTyxFQUFFLENBRDhCO0FBRXZDQyxRQUFNLEVBQUUsQ0FGK0I7QUFHdkNDLFNBQU8sRUFBRTtBQUg4QixDQUFwQztBQU1BLE1BQU1rSyx1QkFBdUIsR0FBRyxFQUFoQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQlA7QUFFQSxNQUFNO0FBQ0ZKLDZCQURFO0FBRUYvSyxrQkFGRTtBQUdGZ0wsc0JBSEU7QUFJRjdLLFlBSkU7QUFLRjhLO0FBTEUsSUFNRkgsOEVBTko7QUFRTyxNQUFNTSxhQUFhLEdBQUcsQ0FBQ2xNLEtBQUssR0FBR0wsb0VBQVQsRUFBdUI4QyxNQUF2QixLQUFrQztBQUMzRCxVQUFRQSxNQUFNLENBQUN4QyxJQUFmO0FBQ0ksU0FBS2EsZ0JBQUw7QUFBdUI7QUFDbkIsK0NBQ09kLEtBRFA7QUFFSUkseUJBQWUsRUFBRXFDLE1BQU0sQ0FBQ3ZDLE9BQVAsQ0FBZUU7QUFGcEM7QUFJSDs7QUFDRCxTQUFLMEwsb0JBQUw7QUFBMkI7QUFDdkIsK0NBQ085TCxLQURQO0FBRUkyTCw0QkFBa0IsRUFBRWxKLE1BQU0sQ0FBQ3ZDLE9BQVAsQ0FBZXlMO0FBRnZDO0FBSUg7O0FBQ0QsU0FBS0UsMkJBQUw7QUFBa0M7QUFDOUIsK0NBQ083TCxLQURQO0FBRUlHLHlCQUFlLEVBQUVzQyxNQUFNLENBQUN2QztBQUY1QjtBQUlIOztBQUNELFNBQUtlLFVBQUw7QUFBaUI7QUFDYixpQ0FDT3RCLG9FQURQO0FBR0g7O0FBQ0QsU0FBS29NLHFCQUFMO0FBQTRCO0FBQ3hCLCtDQUNPL0wsS0FEUDtBQUVJRyx5QkFBZSxFQUFFLENBRnJCO0FBR0lnTSw2QkFBbUIsRUFBRTFKLE1BQU0sQ0FBQ3ZDO0FBSGhDO0FBS0g7O0FBQ0Q7QUFDSSxhQUFPRixLQUFQO0FBaENSO0FBa0NILENBbkNNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNWUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFZSxTQUFTb00sS0FBVCxDQUFlQyxLQUFmLEVBQXNCO0FBQ2pDLFFBQU07QUFBRUMsYUFBRjtBQUFhQztBQUFiLE1BQTJCRixLQUFqQztBQUNBLFFBQU1HLEtBQUssR0FBR0Msb0VBQVEsQ0FBQ0YsU0FBUyxDQUFDRyxpQkFBWCxDQUF0QjtBQUNBLFFBQU1DLFNBQVMsR0FBR0MsbUVBQVksQ0FBQ0osS0FBRCxFQUFRLEVBQVIsRUFBWSxZQUFZO0FBQ2xERyxhQUFTLENBQUNFLE9BQVY7QUFDSCxHQUY2QixDQUE5QixDQUhpQyxDQU1qQztBQUVBOztBQUVBLHNCQUNJLHFFQUFDLDRDQUFELENBQU8sUUFBUDtBQUFBLDRCQUNJLHFFQUFDLGdEQUFEO0FBQUEsOEJBQ0k7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FESixlQUVJO0FBQU0sV0FBRyxFQUFDLE1BQVY7QUFBaUIsWUFBSSxFQUFDLFdBQXRCO0FBQWtDLGFBQUssRUFBQyxPQUF4QztBQUFnRCxZQUFJLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxjQUZKLGVBR0k7QUFDSSxZQUFJLEVBQUMsVUFEVDtBQUVJLGVBQU8sRUFBQztBQUZaO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FISixlQVFJO0FBQVEsYUFBSyxNQUFiO0FBQWMsV0FBRyxFQUFDO0FBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FSSixlQVNJO0FBQUEsa0JBQ007QUFDdEI7QUFDQTtBQUhnQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVEosZUFjSTtBQUFBLGtCQUNNO0FBRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxjQWRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxZQURKLGVBb0JJLHFFQUFDLHVFQUFEO0FBQWUsaUJBQVcsTUFBMUI7QUFBQSw2QkFDSSxxRUFBQyxzRUFBRDtBQUFlLGFBQUssRUFBRUMsMkRBQXRCO0FBQUEsZ0NBRUkscUVBQUMsbUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFGSixlQUdJLHFFQUFDLG9FQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBSEosZUFJSSxxRUFBQyxvREFBRDtBQUFVLGVBQUssRUFBRU4sS0FBakI7QUFBQSxpQ0FDSSxxRUFBQyw0RUFBRDtBQUFhLG1CQUFPLGVBQUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsb0JBQXRCO0FBQTBDLHFCQUFTLEVBQUVHLFNBQXJEO0FBQUEsbUNBQ0kscUVBQUMsNEVBQUQ7QUFBeUIsbUJBQUssRUFBRUksd0RBQWhDO0FBQUEscUNBQ0kscUVBQUMsU0FBRCxvQkFBZVIsU0FBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGdCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsWUFwQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFVBREo7QUFxQ0g7QUFFREgsS0FBSyxDQUFDWSxTQUFOLEdBQWtCO0FBQ2RWLFdBQVMsRUFBRVcsaURBQVMsQ0FBQ0MsV0FBVixDQUFzQkMsVUFEbkI7QUFFZFosV0FBUyxFQUFFVSxpREFBUyxDQUFDRyxNQUFWLENBQWlCRDtBQUZkLENBQWxCLEM7Ozs7Ozs7Ozs7OztBQ3RFQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDTyxNQUFNRSxJQUFJLEdBQUcsTUFBYjtBQUNBLE1BQU1DLFNBQVMsR0FBRyxXQUFsQjtBQUNBLE1BQU1DLFNBQVMsR0FBRyxXQUFsQjtBQUNBLE1BQU1DLEtBQUssR0FBRyxPQUFkLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztDQ0hQOztBQUNBLE1BQU03TixZQUFZLEdBQUc7QUFDbkI4TixTQUFPLEVBQUU7QUFEVSxDQUFyQixDLENBR0E7O0FBQ08sTUFBTUMsY0FBYyxHQUFHLENBQUMxTixLQUFLLEdBQUdMLFlBQVQsRUFBdUI7QUFBRU07QUFBRixDQUF2QixLQUFvQztBQUNoRSxVQUFRQSxJQUFSO0FBQ0UsU0FBSzBOLG9EQUFMO0FBQ0UsNkNBQVkzTixLQUFaO0FBQW1CeU4sZUFBTyxFQUFFek4sS0FBSyxDQUFDeU4sT0FBTixHQUFnQjtBQUE1Qzs7QUFDRixTQUFLRSxvREFBTDtBQUNFLDZDQUFZM04sS0FBWjtBQUFtQnlOLGVBQU8sRUFBRXpOLEtBQUssQ0FBQ3lOLE9BQU4sR0FBZ0I7QUFBNUM7O0FBQ0YsU0FBS0UsZ0RBQUw7QUFDRSw2Q0FBWTNOLEtBQVo7QUFBbUJ5TixlQUFPLEVBQUU7QUFBNUI7O0FBQ0Y7QUFDRSxhQUFPek4sS0FBUDtBQVJKO0FBVUQsQ0FYTSxDOzs7Ozs7Ozs7Ozs7QUNOUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUdBOztBQUNBLE1BQU00TixRQUFRLEdBQUc7QUFDYkgsU0FBTyxFQUFFQywrREFESTtBQUViRyxjQUFZLEVBQUU5TixvRkFGRDtBQUdiK04sa0JBQWdCLEVBQUV0TCxxSEFITDtBQUlidUwsbUJBQWlCLEVBQUVyQyw0R0FKTjtBQUtic0MsaUJBQWUsRUFBRWpFLHNHQUxKO0FBTWJrRSxpQkFBZSxFQUFFM0Usc0dBTko7QUFPYjRFLDBCQUF3QixFQUFFMUQsaUlBUGI7QUFRYjJELG1CQUFpQixFQUFFbEQsNEdBUk47QUFTYm1ELGVBQWEsRUFBRWxDLGlHQVRGO0FBVWJtQyxrQkFBZ0IsRUFBRTNHLGtHQVZMO0FBV2I0RyxjQUFZLEVBQUV6TCx1R0FBYUE7QUFYZCxDQUFqQjtBQWNBLE1BQU0wTCxhQUFhLEdBQUc7QUFDbEJDLEtBQUcsRUFBRSxTQURhO0FBRWxCQyw2RUFGa0I7QUFHbEJDLFdBQVMsRUFBRSxDQUFDLFNBQUQsRUFBWSxjQUFaLEVBQTRCLGtCQUE1QixDQUhPLENBR3lDOztBQUh6QyxDQUF0QjtBQUtBLE1BQU1DLGdCQUFnQixHQUFHQyxvRUFBYyxDQUFDTCxhQUFELEVBQWdCTSw2REFBZSxDQUFDakIsUUFBRCxDQUEvQixDQUF2QztBQUNlZSwrRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBLElBQUluQyxLQUFKOztBQUVBLFNBQVNzQyxTQUFULENBQW1CblAsWUFBbkIsRUFBaUM7QUFDN0IsU0FBT29QLHlEQUFXLENBQ2RuQixpREFEYyxFQUVkak8sWUFGYyxFQUdkcVAsb0ZBQW1CLENBQUNDLDZEQUFlLENBQUNDLGtEQUFELENBQWhCLENBSEwsQ0FBbEI7QUFLSDs7QUFFTSxNQUFNQyxlQUFlLEdBQUlDLGNBQUQsSUFBb0I7QUFBQTs7QUFDL0MsTUFBSUMsTUFBTSxjQUFHN0MsS0FBSCw2Q0FBWXNDLFNBQVMsQ0FBQ00sY0FBRCxDQUEvQixDQUQrQyxDQUcvQztBQUNBOzs7QUFDQSxNQUFJQSxjQUFjLElBQUk1QyxLQUF0QixFQUE2QjtBQUN6QjZDLFVBQU0sR0FBR1AsU0FBUyxpQ0FDWHRDLEtBQUssQ0FBQzhDLFFBQU4sRUFEVyxHQUVYRixjQUZXLEVBQWxCLENBRHlCLENBS3pCOztBQUNBNUMsU0FBSyxHQUFHK0MsU0FBUjtBQUNILEdBWjhDLENBYy9DOzs7QUFDQSxZQUFtQztBQUMvQixXQUFPRixNQUFQO0FBQ0gsR0FqQjhDLENBa0IvQzs7O0FBQ0EsTUFBSSxDQUFDN0MsS0FBTCxFQUFZO0FBQ1JBLFNBQUssR0FBRzZDLE1BQVI7QUFDSDs7QUFFRCxTQUFPQSxNQUFQO0FBQ0gsQ0F4Qk07QUEwQkEsU0FBUzVDLFFBQVQsQ0FBa0I5TSxZQUFsQixFQUFnQztBQUNuQyxRQUFNNk0sS0FBSyxHQUFHZ0QscURBQU8sQ0FBQyxNQUFNTCxlQUFlLENBQUN4UCxZQUFELENBQXRCLEVBQXNDLENBQUNBLFlBQUQsQ0FBdEMsQ0FBckI7QUFDQSxTQUFPNk0sS0FBUDtBQUNILEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0NEO0FBQUEsTUFBTWlELFlBQVksR0FBRztBQUNqQkMsVUFBUSxFQUFFO0FBQ05DLFFBQUksRUFBQztBQUNEQyxjQUFRLEVBQUMsTUFEUjtBQUVEQyxhQUFPLEVBQUM7QUFGUCxLQURDO0FBS05DLFFBQUksRUFBQztBQUNEQyxhQUFPLEVBQUM7QUFEUCxLQUxDO0FBUU5DLG1CQUFlLEVBQUM7QUFDWkMsV0FBSyxFQUFDLFNBRE07QUFFWkMscUJBQWUsRUFBQztBQUZKLEtBUlY7QUFZTnpOLFVBQU0sRUFBQztBQUNIME4sZ0JBQVUsRUFBQyxZQURSO0FBRUgsK0JBQXdCO0FBQ3BCTixlQUFPLEVBQUM7QUFEWTtBQUZyQixLQVpEO0FBa0JOTyxXQUFPLEVBQUM7QUFDSlAsYUFBTyxFQUFFLE9BREw7QUFFSlEsV0FBSyxFQUFDO0FBRkY7QUFsQkYsR0FETztBQXdCakJDLGVBQWEsRUFBQztBQUNWWCxRQUFJLEVBQUM7QUFDRFksa0JBQVksRUFBQztBQURaO0FBREs7QUF4QkcsQ0FBckI7QUErQmVkLDJFQUFmLEU7Ozs7Ozs7Ozs7OztBQy9CQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUEsTUFBTWUsY0FBYyxHQUFHO0FBQ25CQyxXQUFTLEVBQUU7QUFDUEMsYUFBUyxFQUFFO0FBQ1BDLGNBQVEsRUFBRSxPQURIO0FBRVBmLGNBQVEsRUFBRWdCLG1EQUFJLENBQUNDLEVBQUwsQ0FBUWpCLFFBRlg7QUFHUEMsYUFBTyxFQUFFO0FBSEYsS0FESjtBQU1QaUIsYUFBUyxFQUFFO0FBQ1BsQixjQUFRLEVBQUVnQixtREFBSSxDQUFDRyxFQUFMLENBQVFuQixRQURYO0FBRVBlLGNBQVEsRUFBRSxNQUZIO0FBR1BLLGVBQVMsRUFBRSxNQUhKO0FBSVBDLGdCQUFVLEVBQUVMLG1EQUFJLENBQUNLLFVBQUwsQ0FBZ0JDO0FBSnJCLEtBTko7QUFZUEMsY0FBVSxFQUFFO0FBQ1JSLGNBQVEsRUFBRSxPQURGO0FBRVJNLGdCQUFVLEVBQUVMLG1EQUFJLENBQUNLLFVBQUwsQ0FBZ0JHO0FBRnBCLEtBWkw7QUFnQlBDLHNCQUFrQixFQUFFO0FBQ2hCcEIsV0FBSyxFQUFFQSw4Q0FBSyxDQUFDcUIsT0FBTixDQUFjQyxNQUFkLENBQXFCQztBQURaLEtBaEJiO0FBbUJQQyxnQkFBWSxFQUFFO0FBQ1Z4QixXQUFLLEVBQUVBLDhDQUFLLENBQUNxQixPQUFOLENBQWNJLE9BQWQsQ0FBc0JDLElBRG5CO0FBRVZ6QixxQkFBZSxFQUFFRCw4Q0FBSyxDQUFDMkIsTUFBTixDQUFhQztBQUZwQixLQW5CUDtBQXVCUEMsYUFBUyxFQUFFO0FBQ1BDLGVBQVMsRUFBRTtBQURKLEtBdkJKO0FBMkJQcEMsUUFBSSxFQUFFO0FBQ0ZxQyxrQkFBWSxFQUFFLE1BRFo7QUFFRkMsbUJBQWEsRUFBRSxTQUZiO0FBR0ZoQixnQkFBVSxFQUFFTCxtREFBSSxDQUFDSyxVQUFMLENBQWdCRyxNQUgxQjtBQUlGLHNCQUFnQjtBQUNaWSxvQkFBWSxFQUFFLG1CQURGO0FBRVpuQyxlQUFPLEVBQUM7QUFGSSxPQUpkO0FBUUYsbUJBQWE7QUFDVGMsZ0JBQVEsRUFBRSxpQkFERDtBQUVUZCxlQUFPLEVBQUcsY0FGRDtBQUdUVSxvQkFBWSxFQUFFLGNBSEw7QUFJVEwsdUJBQWUsRUFBRSxhQUpSO0FBS1QsbUJBQVc7QUFDUEEseUJBQWUsRUFBRTtBQURWLFNBTEY7QUFRVCxtQkFBVztBQUNQQSx5QkFBZSxFQUFFO0FBRFY7QUFSRixPQVJYO0FBb0JGLHdCQUFrQjtBQUNkRCxhQUFLLEVBQUVBLDhDQUFLLENBQUNxQixPQUFOLENBQWNZLE9BQWQsQ0FBc0JDLFVBRGY7QUFFZGxCLGtCQUFVLEVBQUVMLG1EQUFJLENBQUNLLFVBQUwsQ0FBZ0JDLE9BRmQ7QUFHZHRCLGdCQUFRLEVBQUVnQixtREFBSSxDQUFDd0IsRUFBTCxDQUFReEM7QUFISixPQXBCaEI7QUF5QkYsc0JBQWdCO0FBQ1pLLGFBQUssRUFBRSxNQURLO0FBRVpnQixrQkFBVSxFQUFFTCxtREFBSSxDQUFDSyxVQUFMLENBQWdCQyxPQUZoQjtBQUdadEIsZ0JBQVEsRUFBRWdCLG1EQUFJLENBQUN3QixFQUFMLENBQVF4QztBQUhOLE9BekJkO0FBOEJGLHVCQUFpQjtBQUNiTSx1QkFBZSxFQUFFRCw4Q0FBSyxDQUFDMkIsTUFBTixDQUFhUztBQURqQixPQTlCZjtBQWlDRixpQkFBVztBQUNQaEMsYUFBSyxFQUFDO0FBREM7QUFqQ1QsS0EzQkM7QUFnRVBpQyxXQUFPLEVBQUM7QUFDSkMsZ0JBQVUsRUFBQztBQURQO0FBaEVEO0FBRFEsQ0FBdkI7QUF1RWUvQiw2RUFBZixFOzs7Ozs7Ozs7Ozs7QUMxRUE7QUFBQSxNQUFNZ0MsWUFBWSxHQUFHO0FBQ2pCQyxTQUFPLEVBQUU7QUFDTDlDLFFBQUksRUFBQztBQUNEb0MsZUFBUyxFQUFFLDJCQURWO0FBRURDLGtCQUFZLEVBQUU7QUFGYjtBQURBO0FBRFEsQ0FBckI7QUFTZVEsMkVBQWYsRTs7Ozs7Ozs7Ozs7O0FDVEE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBLE1BQU1FLGdCQUFnQixHQUFHO0FBQ3JCQyxhQUFXLEVBQUU7QUFDVGhELFFBQUksRUFBRTtBQUNGLGtDQUE0QjtBQUN4Qk0sYUFBSyxFQUFFQSw4Q0FBSyxDQUFDcUIsT0FBTixDQUFjSSxPQUFkLENBQXNCUztBQURMLE9BRDFCO0FBSUYsNEJBQXNCO0FBQ2xCbEMsYUFBSyxFQUFFLGFBRFc7QUFFbEIyQyxjQUFNLEVBQUcsYUFBWTNDLDhDQUFLLENBQUNxQixPQUFOLENBQWNJLE9BQWQsQ0FBc0JTLFVBQVcsRUFGcEM7QUFHbEJ2QyxnQkFBUSxFQUFFZ0IsbURBQUksQ0FBQ2lDLEVBQUwsQ0FBUWpELFFBSEE7QUFJbEJvQyxvQkFBWSxFQUFFLEtBSkk7QUFLbEI5Qix1QkFBZSxFQUFFRCw4Q0FBSyxDQUFDMkIsTUFBTixDQUFhQztBQUxaLE9BSnBCO0FBV0YsdUJBQWlCO0FBQ2IsOEJBQXNCO0FBQ2xCZSxnQkFBTSxFQUFFLE1BRFU7QUFFbEIzQyxlQUFLLEVBQUVBLDhDQUFLLENBQUNxQixPQUFOLENBQWNZLE9BQWQsQ0FBc0JQLElBRlg7QUFHbEJ6Qix5QkFBZSxFQUFFO0FBSEM7QUFEVCxPQVhmO0FBa0JGLG1DQUE2QjtBQUN6QjRDLGtCQUFVLEVBQUU7QUFEYTtBQWxCM0I7QUFERyxHQURRO0FBeUJyQkMscUJBQW1CLEVBQUU7QUFDakJwRCxRQUFJLEVBQUU7QUFDRlEsZ0JBQVUsRUFBRTtBQURWLEtBRFc7QUFJakI2QyxTQUFLLEVBQUU7QUFDSHBELGNBQVEsRUFBRWdCLG1EQUFJLENBQUNxQyxFQUFMLENBQVFyRCxRQURmO0FBRUhLLFdBQUssRUFBRUEsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY0ksT0FBZCxDQUFzQndCLEtBRjFCO0FBR0hKLGdCQUFVLEVBQUUsS0FIVDtBQUlISyxpQkFBVyxFQUFDO0FBSlQ7QUFKVSxHQXpCQTtBQW9DckJDLG1CQUFpQixFQUFFO0FBQ2Z6RCxRQUFJLEVBQUU7QUFDRm1ELGdCQUFVLEVBQUU7QUFEVjtBQURTO0FBcENFLENBQXpCO0FBMkNlSiwrRUFBZixFOzs7Ozs7Ozs7Ozs7QUM5Q0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBLE1BQU1XLGNBQWMsR0FBRztBQUNuQkMsV0FBUyxFQUFFO0FBQ1AzRCxRQUFJLEVBQUUsRUFEQztBQUVQNEQsU0FBSyxFQUFFO0FBQ0g1QyxjQUFRLEVBQUUsT0FEUDtBQUVIcUIsa0JBQVksRUFBRSxNQUZYO0FBR0hELGVBQVMsRUFBRTtBQUhSLEtBRkE7QUFPUHlCLGFBQVMsRUFBQztBQUNOdEQscUJBQWUsRUFBQztBQURWO0FBUEgsR0FEUTtBQVluQnVELGdCQUFjLEVBQUU7QUFDWjlELFFBQUksRUFBRTtBQUNGLCtCQUF5QjtBQUNyQitELGdCQUFRLEVBQUUsVUFEVztBQUVyQkMsYUFBSyxFQUFFLE1BRmM7QUFHckJDLFdBQUcsRUFBRTtBQUhnQixPQUR2QjtBQU1GLDRCQUFzQjtBQUNsQjNELGFBQUssRUFBRUEsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY0ksT0FBZCxDQUFzQkMsSUFEWDtBQUVsQi9CLGdCQUFRLEVBQUVnQixtREFBSSxDQUFDaUQsSUFBTCxDQUFVakU7QUFGRjtBQU5wQjtBQURNO0FBWkcsQ0FBdkI7QUEyQmV5RCw2RUFBZixFOzs7Ozs7Ozs7Ozs7QUM5QkE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBLE1BQU1TLGFBQWEsR0FBRztBQUNsQkMsZ0JBQWMsRUFBRTtBQUNacEUsUUFBSSxFQUFFO0FBQ0ZNLFdBQUssRUFBRUEsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY0ksT0FBZCxDQUFzQndCLEtBRDNCO0FBRUZOLFlBQU0sRUFBRyxhQUFZM0MsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY0ksT0FBZCxDQUFzQlMsVUFBVyxFQUZwRDtBQUdGdkMsY0FBUSxFQUFFZ0IsbURBQUksQ0FBQ3FDLEVBQUwsQ0FBUXJELFFBSGhCO0FBSUZvQyxrQkFBWSxFQUFFLE1BSlo7QUFLRmdDLHlCQUFtQixFQUFFLE1BTG5CO0FBTUZDLDBCQUFvQixFQUFFLE1BTnBCO0FBT0YvRCxxQkFBZSxFQUFFRCw4Q0FBSyxDQUFDMkIsTUFBTixDQUFhQyxLQVA1QjtBQVFGcUMsWUFBTSxFQUFFLE1BUk47QUFTRixpQkFBVztBQUNQaEUsdUJBQWUsRUFBRUQsOENBQUssQ0FBQzJCLE1BQU4sQ0FBYUM7QUFEdkIsT0FUVDtBQVlGc0MsbUJBQWEsRUFBRTtBQUNYOUQsYUFBSyxFQUFFLEtBREk7QUFFWCtELGdCQUFRLEVBQUUsUUFGQztBQUdYQyxvQkFBWSxFQUFFLFVBSEg7QUFJWEMsa0JBQVUsRUFBRTtBQUpELE9BWmI7QUFrQkYseUdBQ0k7QUFDSUMsaUJBQVMsRUFBRTtBQURmLE9BbkJGO0FBc0JGLCtCQUF5QjtBQUNyQjFFLGVBQU8sRUFBRSxXQURZO0FBRXJCRCxnQkFBUSxFQUFFZ0IsbURBQUksQ0FBQzRELElBQUwsQ0FBVTVFO0FBRkMsT0F0QnZCO0FBMEJGLHFCQUFlO0FBQ1hNLHVCQUFlLEVBQUVELDhDQUFLLENBQUNxQixPQUFOLENBQWNtRCxLQUFkLENBQW9CdEMsVUFEMUI7QUFFWHVDLG1CQUFXLEVBQUV6RSw4Q0FBSyxDQUFDcUIsT0FBTixDQUFjbUQsS0FBZCxDQUFvQjlDO0FBRnRCLE9BMUJiO0FBOEJGLHVCQUFpQjtBQUNiekIsdUJBQWUsRUFBRSxhQURKO0FBRWI2QixpQkFBUyxFQUFFO0FBRkU7QUE5QmYsS0FETTtBQW9DWjRDLFNBQUssRUFBRTtBQUNIOUUsYUFBTyxFQUFFLGVBRE47QUFFSG1DLGtCQUFZLEVBQUM7QUFGVixLQXBDSztBQXdDWjRDLGNBQVUsRUFBRTtBQUNSQyxrQkFBWSxFQUFFO0FBRE4sS0F4Q0E7QUEyQ1pDLGFBQVMsRUFBRTtBQUNQLDJCQUFxQjtBQUNqQmxDLGNBQU0sRUFBRTtBQURTLE9BRGQ7QUFJUCxpQkFBVztBQUNQLDZCQUFxQjtBQUNqQkEsZ0JBQU0sRUFBRTtBQURTO0FBRGQ7QUFKSixLQTNDQztBQXFEWm1DLGFBQVMsRUFBQztBQUNOYixZQUFNLEVBQUM7QUFERDtBQXJERSxHQURFO0FBMERsQkMsZUFBYSxFQUFFO0FBQ1h4RSxRQUFJLEVBQUU7QUFDRlUsV0FBSyxFQUFFLE1BREw7QUFFRitELGNBQVEsRUFBRSxRQUZSO0FBR0ZDLGtCQUFZLEVBQUUsVUFIWjtBQUlGQyxnQkFBVSxFQUFFLFFBSlY7QUFLRnJFLFdBQUssRUFBRUEsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY0ksT0FBZCxDQUFzQlMsVUFMM0I7QUFNRnZDLGNBQVEsRUFBRWdCLG1EQUFJLENBQUNxQyxFQUFMLENBQVFyRCxRQU5oQjtBQU9GLHFCQUFlO0FBQ1hLLGFBQUssRUFBRUEsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY0ksT0FBZCxDQUFzQlM7QUFEbEIsT0FQYjtBQVVGLGVBQVE7QUFDSjlCLGFBQUssRUFBRSxNQURIO0FBRUorRCxnQkFBUSxFQUFFLFFBRk47QUFHSkMsb0JBQVksRUFBRSxVQUhWO0FBSUpDLGtCQUFVLEVBQUU7QUFKUjtBQVZOLEtBREs7QUFrQlhVLFVBQU0sRUFBRTtBQUNKQyxlQUFTLEVBQUUsZ0NBRFA7QUFFSkosa0JBQVksRUFBQyxNQUZUO0FBR0osZ0NBQTBCO0FBQ3RCSSxpQkFBUyxFQUFFO0FBRFc7QUFIdEI7QUFsQkcsR0ExREc7QUFvRmxCQyxjQUFZLEVBQUU7QUFDVnZGLFFBQUksRUFBRTtBQUNGWSxrQkFBWSxFQUFFO0FBRFo7QUFESSxHQXBGSTtBQXlGbEI0RSxnQkFBYyxFQUFFO0FBQ1p4RixRQUFJLEVBQUU7QUFDRlksa0JBQVksRUFBRSxNQURaO0FBRUYsb0JBQWM7QUFDVkEsb0JBQVksRUFBRTtBQURKO0FBRlo7QUFETTtBQXpGRSxDQUF0QjtBQW1HZXVELDRFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3RHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUEsTUFBTXNCLE9BQU8sR0FBRztBQUNaQyxXQUFTLGdLQUNGQyxzREFERSxHQUVGQyxxREFGRSxHQUdGQyxxREFIRSxHQUlGQyx3REFKRSxHQUtGQyxzREFMRSxHQU1GQyxvREFORSxHQU9GQyxzREFQRSxHQVFGQyxzREFSRSxHQVNGQywyREFURSxHQVVGckcscURBVkUsR0FXRnNHLG9EQVhFO0FBREcsQ0FBaEI7QUFnQmVYLHNFQUFmLEU7Ozs7Ozs7Ozs7OztBQzNCQTtBQUFBO0FBQUE7QUFFQSxNQUFNVSxrQkFBa0IsR0FBRztBQUN2QkUsbUJBQWlCLEVBQUU7QUFDZnJHLFFBQUksRUFBRTtBQUNGdUUsWUFBTSxFQUFFO0FBRE4sS0FEUztBQUlmK0IsZ0JBQVksRUFBRTtBQUNWL0YscUJBQWUsRUFBRUQsOENBQUssQ0FBQzJCLE1BQU4sQ0FBYUM7QUFEcEIsS0FKQztBQU9mcUUsbUJBQWUsRUFBRTtBQUNiaEcscUJBQWUsRUFBRUQsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY1ksT0FBZCxDQUFzQlA7QUFEMUI7QUFQRjtBQURJLENBQTNCO0FBYWVtRSxpRkFBZixFOzs7Ozs7Ozs7Ozs7QUNoQkE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBLE1BQU1LLGFBQWEsR0FBRztBQUNsQkMsVUFBUSxFQUFFO0FBQ056RyxRQUFJLEVBQUU7QUFDRixrQ0FBNEI7QUFDeEJNLGFBQUssRUFBRUEsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY0ksT0FBZCxDQUFzQlM7QUFETCxPQUQxQjtBQUlGLGtCQUFXO0FBQ1AsOEJBQXNCO0FBQ2xCdkMsa0JBQVEsRUFBRWdCLG1EQUFJLENBQUNpQyxFQUFMLENBQVFqRDtBQURBLFNBRGY7QUFJUCx3Q0FBK0I7QUFDM0JrRCxvQkFBVSxFQUFDO0FBRGdCO0FBSnhCLE9BSlQ7QUFZRiw0QkFBc0I7QUFDbEI3QyxhQUFLLEVBQUUsYUFEVztBQUVsQjJDLGNBQU0sRUFBRyxhQUFZM0MsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY0ksT0FBZCxDQUFzQlMsVUFBVyxFQUZwQztBQUdsQnZDLGdCQUFRLEVBQUVnQixtREFBSSxDQUFDeUYsSUFBTCxDQUFVekcsUUFIRjtBQUlsQm9DLG9CQUFZLEVBQUUsS0FKSTtBQUtsQjlCLHVCQUFlLEVBQUVELDhDQUFLLENBQUMyQixNQUFOLENBQWFDO0FBTFosT0FacEI7QUFtQkYsdUJBQWlCO0FBQ2IsOEJBQXNCO0FBQ2xCNUIsZUFBSyxFQUFFQSw4Q0FBSyxDQUFDcUIsT0FBTixDQUFjZ0YsU0FBZCxDQUF3QkM7QUFEYjtBQURUO0FBbkJmO0FBREE7QUFEUSxDQUF0QjtBQThCZUosNEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDakNBO0FBQUE7QUFBQTtBQUVBLE1BQU1QLGFBQWEsR0FBRztBQUNsQlksV0FBUyxFQUFFO0FBQ1AxRyxRQUFJLEVBQUU7QUFDRjJHLGdCQUFVLEVBQUV4Ryw4Q0FBSyxDQUFDcUIsT0FBTixDQUFjb0YsS0FBZCxDQUFvQkMsY0FEOUI7QUFFRnpDLFlBQU0sRUFBRSxNQUZOO0FBR0ZsQyxrQkFBWSxFQUFFLGVBSFo7QUFJRnJCLGNBQVEsRUFBRSxNQUpSO0FBS0ZpRCxTQUFHLEVBQUUsS0FMSDtBQU1GM0QsV0FBSyxFQUFFO0FBTkwsS0FEQztBQVNQMkcsY0FBVSxFQUFFO0FBQ1JqRCxXQUFLLEVBQUU7QUFEQyxLQVRMO0FBWVBrRCxVQUFNLEVBQUU7QUFDSm5ELGNBQVEsRUFBRSxVQUROO0FBRUosa0JBQVk7QUFDUm9ELGVBQU8sRUFBRSxVQUREO0FBRVJwRCxnQkFBUSxFQUFFLFVBRkY7QUFHUkMsYUFBSyxFQUFFLE1BSEM7QUFJUm9ELGNBQU0sRUFBRSxHQUpBO0FBS1I5RixrQkFBVSxFQUFFLG9CQUxKO0FBTVIyQyxXQUFHLEVBQUUsTUFORztBQU9SaEUsZ0JBQVEsRUFBRTtBQVBGLE9BRlI7QUFXSixpQkFBVztBQUNQTSx1QkFBZSxFQUFFO0FBRFY7QUFYUDtBQVpELEdBRE87QUE2QmxCOEcsWUFBVSxFQUFFO0FBQ1J6RCxTQUFLLEVBQUU7QUFDSHZCLGtCQUFZLEVBQUU7QUFEWDtBQURDO0FBN0JNLENBQXRCO0FBb0NlNEQsNEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDdENBO0FBQUE7QUFBQTtBQUVBLE1BQU1xQixjQUFjLEdBQUc7QUFDbkJDLFdBQVMsRUFBRTtBQUNQdkgsUUFBSSxFQUFFO0FBQ0ZVLFdBQUssRUFBRSxNQURMO0FBRUY2RCxZQUFNLEVBQUUsTUFGTjtBQUdGckUsYUFBTyxFQUFFO0FBSFAsS0FEQztBQU1Qc0gsU0FBSyxFQUFFO0FBQ0g5RyxXQUFLLEVBQUUsTUFESjtBQUVIdUMsWUFBTSxFQUFHLGFBQVkzQyw4Q0FBSyxDQUFDcUIsT0FBTixDQUFjSSxPQUFkLENBQXNCd0IsS0FBTSxFQUY5QztBQUdIZ0IsWUFBTSxFQUFFLE1BSEw7QUFJSFIsY0FBUSxFQUFFLFVBSlA7QUFLSDNCLGVBQVMsRUFBRSxNQUxSO0FBTUhxRixlQUFTLEVBQUUsWUFOUjtBQU9IbEgscUJBQWUsRUFBRUQsOENBQUssQ0FBQzJCLE1BQU4sQ0FBYUMsS0FQM0I7QUFRSCxpQkFBVztBQUNQaUYsZUFBTyxFQUFFLElBREY7QUFFUHpHLGFBQUssRUFBRSxNQUZBO0FBR1A2RCxjQUFNLEVBQUUsTUFIRDtBQUlQdEIsY0FBTSxFQUFHLGFBQVkzQyw4Q0FBSyxDQUFDcUIsT0FBTixDQUFjSSxPQUFkLENBQXNCd0IsS0FBTSxFQUoxQztBQUtQUSxnQkFBUSxFQUFFLFVBTEg7QUFNUDJELFlBQUksRUFBRSxLQU5DO0FBT1B6RCxXQUFHLEVBQUUsS0FQRTtBQVFQcUIsaUJBQVMsRUFBRSx1QkFSSjtBQVNQakQsb0JBQVksRUFBRTtBQVRQO0FBUlIsS0FOQTtBQTBCUHNGLGNBQVUsRUFBRTtBQUNSekgsYUFBTyxFQUFFLENBREQ7QUFFUjBILFlBQU0sRUFBRSxDQUZBO0FBR1JDLHdCQUFrQixFQUFFLE9BSFo7QUFJUix1QkFBaUI7QUFDYnZDLGlCQUFTLEVBQUUsa0JBREU7QUFFYmhGLGFBQUssRUFBRUEsOENBQUssQ0FBQzJCLE1BQU4sQ0FBYUMsS0FGUDtBQUdiLGdDQUF3QjtBQUNwQjNCLHlCQUFlLEVBQUcsR0FBRUQsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY2dGLFNBQWQsQ0FBd0JDLElBQUssYUFEN0I7QUFFcEJrQixpQkFBTyxFQUFFO0FBRlcsU0FIWDtBQU9iLDZDQUFxQztBQUNqQ0EsaUJBQU8sRUFBRTtBQUR3QjtBQVB4QjtBQUpULEtBMUJMO0FBMENQQyxTQUFLLEVBQUU7QUFDSDlFLFlBQU0sRUFBRyxhQUFZM0MsOENBQUssQ0FBQ3FCLE9BQU4sQ0FBY0ksT0FBZCxDQUFzQndCLEtBQU0sRUFEOUM7QUFFSHVFLGFBQU8sRUFBRSxHQUZOO0FBR0hFLGdCQUFVLEVBQUUseURBSFQ7QUFJSDNGLGtCQUFZLEVBQUUsTUFKWDtBQUtIOUIscUJBQWUsRUFBRUQsOENBQUssQ0FBQzJCLE1BQU4sQ0FBYWdHO0FBTDNCO0FBMUNBO0FBRFEsQ0FBdkI7QUFvRGVYLDZFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3REQTtBQUFBO0FBQUE7QUFFQSxNQUFNbEIsVUFBVSxHQUFHO0FBQ2Y4QixTQUFPLEVBQUU7QUFDTGxJLFFBQUksRUFBRTtBQUNGZ0IsY0FBUSxFQUFFLE9BRFI7QUFHRiw0QkFBc0I7QUFDbEI4RyxlQUFPLEVBQUUsT0FEUztBQUVsQjlHLGdCQUFRLEVBQUU7QUFGUTtBQUhwQixLQUREO0FBU0wyQixXQUFPLEVBQUU7QUFDTEMsZ0JBQVUsRUFBRTtBQURQLEtBVEo7QUFZTHVGLFlBQVEsRUFBRTtBQUNOdkQsZUFBUyxFQUFFO0FBREw7QUFaTCxHQURNO0FBaUJmd0QsUUFBTSxFQUFFO0FBQ0pwSSxRQUFJLEVBQUU7QUFDRjhILGFBQU8sRUFBRSxrQkFEUDtBQUVGOUcsY0FBUSxFQUFFLGtCQUZSO0FBR0ZzQixtQkFBYSxFQUFFLE1BSGI7QUFJRnNGLFlBQU0sRUFBRSxRQUpOO0FBS0Ysd0JBQWtCO0FBQ2RySCx1QkFBZSxFQUFFRCw4Q0FBSyxDQUFDcUIsT0FBTixDQUFjZ0YsU0FBZCxDQUF3QjNFLElBRDNCO0FBRWRxQywyQkFBbUIsRUFBRSxNQUZQO0FBR2RnRSw4QkFBc0IsRUFBRSxNQUhWO0FBSWRoSCxpQkFBUyxFQUFFLE1BSkc7QUFLZCx3QkFBZ0I7QUFDWmpCLGlCQUFPLEVBQUU7QUFERztBQUxGO0FBTGhCLEtBREY7QUFnQkprSSxXQUFPLEVBQUU7QUFDTEMsbUJBQWEsRUFBRSxTQURWO0FBRUxDLG9CQUFjLEVBQUU7QUFGWDtBQWhCTCxHQWpCTztBQXNDZkMscUJBQW1CLEVBQUU7QUFDakJ6SSxRQUFJLEVBQUU7QUFDRkksYUFBTyxFQUFFO0FBRFA7QUFEVztBQXRDTixDQUFuQjtBQTZDZWdHLHlFQUFmLEU7Ozs7Ozs7Ozs7OztBQy9DQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQWU7QUFDWHNDLGFBQVcsRUFBRTtBQUNUOVEsVUFBTSxFQUFFO0FBQ0orUSxRQUFFLEVBQUUsQ0FEQTtBQUVKdkgsUUFBRSxFQUFFLEdBRkE7QUFHSndILFFBQUUsRUFBRSxHQUhBO0FBSUpuRyxRQUFFLEVBQUUsSUFKQTtBQUtKb0csUUFBRSxFQUFFLElBTEE7QUFNSkMsU0FBRyxFQUFFLElBTkQ7QUFPSkMsUUFBRSxFQUFFO0FBUEE7QUFEQztBQURGLENBQWYsRTs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQSxNQUFNQyxZQUFZLEdBQUc7QUFDakIvRyxRQUFNLEVBQUU7QUFDSkMsU0FBSyxFQUFFLE1BREg7QUFFSitHLFNBQUssRUFBRSxNQUZIO0FBR0poQixRQUFJLEVBQUUsU0FIRjtBQUlKdkYsZ0JBQVksRUFBRSxTQUpWO0FBS0p3RyxhQUFTLEVBQUUsU0FMUDtBQU1KQyxZQUFRLEVBQUUsU0FOTjtBQU9KQyxrQkFBYyxFQUFFLFNBUFo7QUFRSkMsb0JBQWdCLEVBQUUsU0FSZDtBQVNKQyxjQUFVLEVBQUU7QUFUUixHQURTO0FBYWpCM0gsU0FBTyxFQUFFO0FBQ0xJLFdBQU8sRUFBRTtBQUNMQyxVQUFJLEVBQUUsU0FERDtBQUVMdUIsV0FBSyxFQUFFLFNBRkY7QUFHTGYsZ0JBQVUsRUFBRTtBQUhQLEtBREo7QUFNTG1FLGFBQVMsRUFBRTtBQUNQQyxVQUFJLEVBQUUsU0FEQztBQUVQNUUsVUFBSSxFQUFFLFNBRkM7QUFHUHVCLFdBQUssRUFBRSxTQUhBO0FBSVBmLGdCQUFVLEVBQUU7QUFKTCxLQU5OO0FBWUxzQyxTQUFLLEVBQUU7QUFDSDhCLFVBQUksRUFBRSxTQURIO0FBRUg1RSxVQUFJLEVBQUUsU0FGSDtBQUdIdUIsV0FBSyxFQUFFLFNBSEo7QUFJSGYsZ0JBQVUsRUFBRTtBQUpULEtBWkY7QUFrQkwrRyxXQUFPLEVBQUU7QUFDTHZILFVBQUksRUFBRSxTQUREO0FBRUx1QixXQUFLLEVBQUUsU0FGRjtBQUdMZixnQkFBVSxFQUFFO0FBSFAsS0FsQko7QUF1QkxELFdBQU8sRUFBRTtBQUNMUCxVQUFJLEVBQUUsU0FERDtBQUVMdUIsV0FBSyxFQUFFLFNBRkY7QUFHTGYsZ0JBQVUsRUFBRTtBQUhQLEtBdkJKO0FBNEJMZ0gsUUFBSSxFQUFFO0FBQ0Z4SCxVQUFJLEVBQUU7QUFESixLQTVCRDtBQStCTHlILFdBQU8sRUFBRTtBQUNMekgsVUFBSSxFQUFFO0FBREQsS0EvQko7QUFrQ0xKLFVBQU0sRUFBRTtBQUNKQyxvQkFBYyxFQUFFO0FBRFosS0FsQ0g7QUFxQ0xrRixTQUFLLEVBQUU7QUFDSEMsb0JBQWMsRUFBRTtBQURiLEtBckNGO0FBd0NMMEMsZUFBVyxFQUFFO0FBQ1QxSCxVQUFJLEVBQUU7QUFERztBQXhDUjtBQWJRLENBQXJCO0FBMkRlZ0gsMkVBQWYsRTs7Ozs7Ozs7Ozs7O0FDM0RBO0FBQUE7QUFBQTtBQUFBO0FBRUEsTUFBTVcsU0FBUyxHQUFHQyxvRUFBVSxDQUFFek0sS0FBRCxJQUN6QjBNLHNFQUFZLENBQUM7QUFDVCxhQUFXO0FBQ1AsU0FBSztBQUNEcEMsZUFBUyxFQUFFLFlBRFY7QUFFREcsWUFBTSxFQUFFLENBRlA7QUFHRDFILGFBQU8sRUFBRTtBQUhSLEtBREU7QUFNUDRKLFFBQUksRUFBRTtBQUNGLGdDQUEwQixhQUR4QjtBQUVGLGlDQUEyQixXQUZ6QjtBQUdGdkYsWUFBTSxFQUFFLE1BSE47QUFJRjdELFdBQUssRUFBRTtBQUpMLEtBTkM7QUFZUHFKLFFBQUksRUFBRTtBQUNGeEYsWUFBTSxFQUFFLE1BRE47QUFFRjdELFdBQUssRUFBRSxNQUZMO0FBR0ZZLGdCQUFVLEVBQUVuRSxLQUFLLENBQUM2TSxVQUFOLENBQWlCMUksVUFBakIsQ0FBNEJDLE9BSHRDO0FBSUZ0QixjQUFRLEVBQUU5QyxLQUFLLENBQUM2TSxVQUFOLENBQWlCL0osUUFBakIsQ0FBMEJtQixFQUpsQztBQUtGNkksZUFBUyxFQUFFLFlBTFQ7QUFNRkMsZ0JBQVUsRUFBQyxLQU5UO0FBT0YsaUJBQVc7QUFDUDNGLGNBQU0sRUFBRTtBQUREO0FBUFQsS0FaQztBQXVCUDRGLE9BQUcsRUFBRTtBQUNEQyxjQUFRLEVBQUU7QUFEVCxLQXZCRTtBQTBCUEMsS0FBQyxFQUFFO0FBQ0NDLG9CQUFjLEVBQUU7QUFEakIsS0ExQkk7QUE2QlAsYUFBUztBQUNML0YsWUFBTSxFQUFFLE1BREg7QUFFTDdELFdBQUssRUFBRTtBQUZGLEtBN0JGO0FBaUNQLHNCQUFrQjtBQUNkNEIsbUJBQWEsRUFBRTtBQURELEtBakNYO0FBb0NQLHdCQUFvQjtBQUNoQiw2Q0FBdUM7QUFDbkN0QixnQkFBUSxFQUFFLE9BRHlCO0FBRW5Db0osZ0JBQVEsRUFBRTtBQUZ5QixPQUR2QjtBQUtoQiw2Q0FBdUM7QUFDbkNwSixnQkFBUSxFQUFFLE9BRHlCO0FBRW5Db0osZ0JBQVEsRUFBRTtBQUZ5QjtBQUx2QixLQXBDYjtBQThDUCxrQkFBYztBQUNWbEssYUFBTyxFQUFFO0FBREMsS0E5Q1A7QUFpRFAscUJBQWdCO0FBQ1osaUNBQTRCO0FBQ3hCQSxlQUFPLEVBQUU7QUFEZSxPQURoQjtBQUlaLDZCQUF1QjtBQUNuQixvQkFBWTtBQUNSK0QsYUFBRyxFQUFFO0FBREc7QUFETztBQUpYO0FBakRULEdBREY7QUE2RFRlLE9BQUssRUFBRTtBQUNILDBCQUFzQjtBQUNsQnVGLHFCQUFlLEVBQUU7QUFEQztBQURuQjtBQTdERSxDQUFELENBRFksQ0FBNUI7O0FBc0VBLE1BQU1DLFlBQVksR0FBRyxNQUFNO0FBQ3ZCYixXQUFTO0FBQ1QsU0FBTyxJQUFQO0FBQ0gsQ0FIRDs7QUFLZWEsMkVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdFQTtBQUNBO0FBQ0E7QUFDQTtDQUdBOztBQUNBLE1BQU1yTixLQUFLLEdBQUdzTiw0RUFBVztBQUNyQi9OLE9BQUssRUFBRTtBQUNIO0FBQ0FnTyxnQkFBWSxFQUFFO0FBQ1Y7QUFDQUMsa0JBQVksRUFBRSxJQUZKLENBRVM7O0FBRlQ7QUFGWCxHQURjO0FBUXJCWCxpRUFBVUE7QUFSVyxHQVNsQnRCLG9EQVRrQixHQVVsQnBJLDhDQVZrQixHQVdsQnNLLGdEQVhrQixFQUF6QjtBQWNlek4sb0VBQWYsRTs7Ozs7Ozs7Ozs7O0FIckJBO0FBQWU7QUFDWDBOLGlCQUFlLEVBQUUsSUFETjtBQUVYNUssVUFBUSxFQUFFLEVBRkM7QUFJWDZLLElBQUUsRUFBRTtBQUNBN0ssWUFBUSxFQUFFO0FBRFYsR0FKTztBQU9YOEssSUFBRSxFQUFFO0FBQ0E5SyxZQUFRLEVBQUU7QUFEVixHQVBPO0FBVVh5RyxNQUFJLEVBQUU7QUFDRnpHLFlBQVEsRUFBRTtBQURSLEdBVks7QUFhWCtLLElBQUUsRUFBRTtBQUNBL0ssWUFBUSxFQUFFO0FBRFYsR0FiTztBQWdCWGlFLE1BQUksRUFBRTtBQUNGakUsWUFBUSxFQUFFO0FBRFIsR0FoQks7QUFtQlhpRCxJQUFFLEVBQUU7QUFDQWpELFlBQVEsRUFBRTtBQURWLEdBbkJPO0FBc0JYNEUsTUFBSSxFQUFFO0FBQ0Y1RSxZQUFRLEVBQUU7QUFEUixHQXRCSztBQXlCWGlCLElBQUUsRUFBRTtBQUNBakIsWUFBUSxFQUFFO0FBRFYsR0F6Qk87QUE0QlhxRCxJQUFFLEVBQUU7QUFDQXJELFlBQVEsRUFBRTtBQURWLEdBNUJPO0FBK0JYd0MsSUFBRSxFQUFFO0FBQ0F4QyxZQUFRLEVBQUU7QUFEVixHQS9CTztBQWtDWGdMLE1BQUksRUFBRTtBQUNGaEwsWUFBUSxFQUFFO0FBRFIsR0FsQ0s7QUFxQ1gySSxJQUFFLEVBQUU7QUFDQTNJLFlBQVEsRUFBRTtBQURWLEdBckNPO0FBd0NYbUIsSUFBRSxFQUFFO0FBQ0FuQixZQUFRLEVBQUU7QUFEVixHQXhDTztBQTJDWDBJLElBQUUsRUFBRTtBQUNBMUksWUFBUSxFQUFFO0FBRFYsR0EzQ087QUErQ1hxQixZQUFVLEVBQUU7QUFDUkMsV0FBTyxFQUFFLGlCQUREO0FBRVJFLFVBQU0sRUFBRSxnQkFGQTtBQUdSeUosWUFBUSxFQUFFLGtCQUhGO0FBSVJDLFFBQUksRUFBRSxjQUpFO0FBS1JDLGFBQVMsRUFBRTtBQUxILEdBL0NEO0FBc0RYOUksZUFBYSxFQUFFO0FBQ1grSSxhQUFTLEVBQUU7QUFEQTtBQXRESixDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FJQUEsOEM7Ozs7Ozs7Ozs7O0FDQUEsOEM7Ozs7Ozs7Ozs7O0FDQUEsMEQ7Ozs7Ozs7Ozs7O0FDQUEscUQ7Ozs7Ozs7Ozs7O0FDQUEsaUQ7Ozs7Ozs7Ozs7O0FDQUEsbUM7Ozs7Ozs7Ozs7O0FDQUEsc0M7Ozs7Ozs7Ozs7O0FDQUEsdUM7Ozs7Ozs7Ozs7O0FDQUEsa0M7Ozs7Ozs7Ozs7O0FDQUEsd0M7Ozs7Ozs7Ozs7O0FDQUEsc0Q7Ozs7Ozs7Ozs7O0FDQUEsa0Q7Ozs7Ozs7Ozs7O0FDQUEsa0M7Ozs7Ozs7Ozs7O0FDQUEscUQ7Ozs7Ozs7Ozs7O0FDQUEsMEM7Ozs7Ozs7Ozs7O0FDQUEsNEQ7Ozs7Ozs7Ozs7O0FDQUEsc0Q7Ozs7Ozs7Ozs7O0FDQUEsd0MiLCJmaWxlIjoicGFnZXMvX2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiBcdC8vIFRoZSBtb2R1bGUgY2FjaGVcbiBcdHZhciBpbnN0YWxsZWRNb2R1bGVzID0gcmVxdWlyZSgnLi4vc3NyLW1vZHVsZS1jYWNoZS5qcycpO1xuXG4gXHQvLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuIFx0ZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXG4gXHRcdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuIFx0XHRpZihpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSkge1xuIFx0XHRcdHJldHVybiBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXS5leHBvcnRzO1xuIFx0XHR9XG4gXHRcdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG4gXHRcdHZhciBtb2R1bGUgPSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXSA9IHtcbiBcdFx0XHRpOiBtb2R1bGVJZCxcbiBcdFx0XHRsOiBmYWxzZSxcbiBcdFx0XHRleHBvcnRzOiB7fVxuIFx0XHR9O1xuXG4gXHRcdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuIFx0XHR2YXIgdGhyZXcgPSB0cnVlO1xuIFx0XHR0cnkge1xuIFx0XHRcdG1vZHVsZXNbbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuIFx0XHRcdHRocmV3ID0gZmFsc2U7XG4gXHRcdH0gZmluYWxseSB7XG4gXHRcdFx0aWYodGhyZXcpIGRlbGV0ZSBpbnN0YWxsZWRNb2R1bGVzW21vZHVsZUlkXTtcbiBcdFx0fVxuXG4gXHRcdC8vIEZsYWcgdGhlIG1vZHVsZSBhcyBsb2FkZWRcbiBcdFx0bW9kdWxlLmwgPSB0cnVlO1xuXG4gXHRcdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG4gXHRcdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbiBcdH1cblxuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZXMgb2JqZWN0IChfX3dlYnBhY2tfbW9kdWxlc19fKVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tID0gbW9kdWxlcztcblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGUgY2FjaGVcbiBcdF9fd2VicGFja19yZXF1aXJlX18uYyA9IGluc3RhbGxlZE1vZHVsZXM7XG5cbiBcdC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb24gZm9yIGhhcm1vbnkgZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24oZXhwb3J0cywgbmFtZSwgZ2V0dGVyKSB7XG4gXHRcdGlmKCFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywgbmFtZSkpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgbmFtZSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGdldHRlciB9KTtcbiBcdFx0fVxuIFx0fTtcblxuIFx0Ly8gZGVmaW5lIF9fZXNNb2R1bGUgb24gZXhwb3J0c1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24oZXhwb3J0cykge1xuIFx0XHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiBcdFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiBcdFx0fVxuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuIFx0fTtcblxuIFx0Ly8gY3JlYXRlIGEgZmFrZSBuYW1lc3BhY2Ugb2JqZWN0XG4gXHQvLyBtb2RlICYgMTogdmFsdWUgaXMgYSBtb2R1bGUgaWQsIHJlcXVpcmUgaXRcbiBcdC8vIG1vZGUgJiAyOiBtZXJnZSBhbGwgcHJvcGVydGllcyBvZiB2YWx1ZSBpbnRvIHRoZSBuc1xuIFx0Ly8gbW9kZSAmIDQ6IHJldHVybiB2YWx1ZSB3aGVuIGFscmVhZHkgbnMgb2JqZWN0XG4gXHQvLyBtb2RlICYgOHwxOiBiZWhhdmUgbGlrZSByZXF1aXJlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnQgPSBmdW5jdGlvbih2YWx1ZSwgbW9kZSkge1xuIFx0XHRpZihtb2RlICYgMSkgdmFsdWUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKHZhbHVlKTtcbiBcdFx0aWYobW9kZSAmIDgpIHJldHVybiB2YWx1ZTtcbiBcdFx0aWYoKG1vZGUgJiA0KSAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICYmIHZhbHVlLl9fZXNNb2R1bGUpIHJldHVybiB2YWx1ZTtcbiBcdFx0dmFyIG5zID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5yKG5zKTtcbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KG5zLCAnZGVmYXVsdCcsIHsgZW51bWVyYWJsZTogdHJ1ZSwgdmFsdWU6IHZhbHVlIH0pO1xuIFx0XHRpZihtb2RlICYgMiAmJiB0eXBlb2YgdmFsdWUgIT0gJ3N0cmluZycpIGZvcih2YXIga2V5IGluIHZhbHVlKSBfX3dlYnBhY2tfcmVxdWlyZV9fLmQobnMsIGtleSwgZnVuY3Rpb24oa2V5KSB7IHJldHVybiB2YWx1ZVtrZXldOyB9LmJpbmQobnVsbCwga2V5KSk7XG4gXHRcdHJldHVybiBucztcbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cblxuIFx0Ly8gTG9hZCBlbnRyeSBtb2R1bGUgYW5kIHJldHVybiBleHBvcnRzXG4gXHRyZXR1cm4gX193ZWJwYWNrX3JlcXVpcmVfXyhfX3dlYnBhY2tfcmVxdWlyZV9fLnMgPSAwKTtcbiIsIlxyXG5leHBvcnQgY29uc3QgbG9naW5Db25zdGFudHMgPSB7XHJcbiAgICBMT0dJTl9TVUNDRVNTOiAnTE9HSU5fU1VDQ0VTUycsXHJcbiAgICBMT0dJTl9GQUlMOiAnTE9HSU5fRkFJTCcsXHJcbiAgICBMT0dJTl9JTklUOiAnTE9HSU5fSU5JVCdcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICAgIHVzZXJEYXRhOiB7XHJcbiAgICAgICAgbG9hZGluZzogZmFsc2UsXHJcbiAgICAgICAgZGF0YTogW11cclxuICAgIH0sXHJcbiAgfTsiLCJpbXBvcnQgeyBpbml0aWFsU3RhdGUsIGxvZ2luQ29uc3RhbnRzIH0gZnJvbSBcIi4vTG9naW5Db25zdGFudHNcIjtcclxuXHJcbmNvbnN0IHtcclxuICAgIExPR0lOX1NVQ0NFU1MsXHJcbiAgICBMT0dJTl9GQUlMLFxyXG4gICAgTE9HSU5fSU5JVFxyXG59ID0gbG9naW5Db25zdGFudHNcclxuXHJcbmV4cG9ydCBjb25zdCBsb2dpblJlZHVjZXIgPSAoc3RhdGUgPSBpbml0aWFsU3RhdGUsIHsgdHlwZSwgcGF5bG9hZCB9KSA9PiB7XHJcbiAgc3dpdGNoICh0eXBlKSB7XHJcbiAgICBjYXNlIExPR0lOX0lOSVQ6XHJcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCB1c2VyRGF0YTogeyAuLi5zdGF0ZS51c2VyRGF0YSwgbG9hZGluZzogdHJ1ZSB9IH07XHJcbiAgICBjYXNlIExPR0lOX1NVQ0NFU1M6XHJcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCB1c2VyRGF0YTogeyAuLi5zdGF0ZS51c2VyRGF0YSwgbG9hZGluZzogZmFsc2UsIGRhdGE6IHBheWxvYWQgfSB9O1xyXG4gICAgY2FzZSBMT0dJTl9GQUlMOlxyXG4gICAgICByZXR1cm4geyAuLi5zdGF0ZSwgIHVzZXJEYXRhOiB7IC4uLnN0YXRlLnVzZXJEYXRhLCBsb2FkaW5nOiBmYWxzZSB9IH07XHJcbiAgICBkZWZhdWx0OlxyXG4gICAgICByZXR1cm4gc3RhdGU7XHJcbiAgfVxyXG59O1xyXG4iLCJleHBvcnQgY29uc3QgaW5pdGlhbFN0YXRlID0ge1xyXG4gICAgYWN0aXZlU3RlcEluZGV4OiAxLFxyXG4gICAgd2VsY29tZUNvbnRpbnVlOiBmYWxzZSxcclxuICAgIGVsaWdpYmlsaXR5Q2hlY2s6IGZhbHNlLFxyXG4gICAgZmFtaWx5TWVtYmVyOiAnJyxcclxuICAgIG1vbnRobHlJbmNvbWU6ICcnLFxyXG4gICAgZWxpZ2liaWxpdHlTdGF0dXM6IDAsXHJcbiAgICBzZXhPZmZlbmRlclN0YXR1czogdHJ1ZSxcclxuICAgIG1ldGhhU3RhdHVzOiB0cnVlXHJcbn07XHJcbmV4cG9ydCBjb25zdCBlbGlnaWJpbGl0eUNvbnN0YW50cyA9IHtcclxuICAgIEVMSUdJQklMSVRZX0FDVElWRV9JTkRFWDogJ0VMSUdJQklMSVRZX0FDVElWRV9JTkRFWCcsXHJcbiAgICBTQVZFX0ZBTUlMWV9JTkZPOiAnU0FWRV9GQU1JTFlfSU5GTycsXHJcbiAgICBDT05USU5VRV9XRUxDT01FOiAnQ09OVElOVUVfV0VMQ09NRScsXHJcbiAgICBFTElHSUJJTElUWV9DSEVDSzogJ0VMSUdJQklMSVRZX0NIRUNLJyxcclxuICAgIFNBVkVfTU9OVEhMWV9JTkNPTUU6ICdTQVZFX01PTlRITFlfSU5DT01FJyxcclxuICAgIFJFU0VUX0ZPUk06ICdSRVNFVF9GT1JNJyxcclxuICAgIEVMSUdJQklMSVRZX1NUQVRVUzogJ0VMSUdJQklMSVRZX1NUQVRVUycsXHJcbiAgICBNRVRIQV9TVEFUVVM6ICdNRVRIQV9TVEFUVVMnLFxyXG4gICAgU0VYX09GRkVOREVSX1NUQVRVUzogJ1NFWF9PRkZFTkRFUl9TVEFUVVMnXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgU1RFUFMgPSB7XHJcbiAgICBTVEVQMTogMSxcclxuICAgIFNURVAyOiAyLFxyXG4gICAgU1RFUDM6IDMsXHJcbiAgICBTVEVQNDogNCxcclxuICAgIFNURVA1OiA1LFxyXG4gICAgU1RFUDY6IDZcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBlbGlnaWJpbGl0eVN0YXR1c0NvbnN0YW50ID0ge1xyXG4gICAgU1VDQ0VTUzogMSxcclxuICAgIEZBSUxFRDogMixcclxuICAgIFBFTkRJTkc6IDNcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBlbGlnaWJpbGl0eVN0YXR1c0RhdGEgPSB7XHJcbiAgICBbZWxpZ2liaWxpdHlTdGF0dXNDb25zdGFudC5TVUNDRVNTXToge1xyXG4gICAgICAgIGljb25OYW1lOiAndGh1bWJzLXVwJyxcclxuICAgICAgICBzdGF0dXM6ICdzdWNjZXNzJyxcclxuICAgICAgICB0aXRsZTogJ0dvb2QgbmV3cyEgaXQgbG9va3MgbGlrZSB5b3UgbWF5IGJlIGEgY2FuZGlkYXRlIGZvciBob3VzaW5nIGFzc2lzdGFuY2UuJyxcclxuICAgICAgICBzdWJUaXRsZTpcclxuICAgICAgICAgICAgXCJTb21lIGNvcHkgYWJvdXQgaG93IGlmIHlvdSdkIGxpa2UgdG8gY29udGludWUsIHdlJ2xsIG5lZWQgbW9yZSBpbmZvcm1hdGlvbiBmcm9tIHlvdSwgaW5jbHVkaW5nIHN1Y2ggYW5kIHN1Y2gsIGFuZCB3aWxsIHRha2UgYWJvdXQgMzAgbWludXRlcy4gV291bGQgeW91IGxpa2UgdG8gY29udGludWU/XCIsXHJcbiAgICAgICAgc3ViVGl0bGUyOiAnJyxcclxuICAgICAgICBidXR0b25UZXh0OiAnQ29udGludWUnLFxyXG4gICAgICAgIGxpbmtUZXh0OiAnT3IgTm90IFJpZ2h0IG5vdydcclxuICAgIH0sXHJcbiAgICBbZWxpZ2liaWxpdHlTdGF0dXNDb25zdGFudC5GQUlMRURdOiB7XHJcbiAgICAgICAgaWNvbk5hbWU6ICd0aHVtYnMtZG93bicsXHJcbiAgICAgICAgc3RhdHVzOiAnZmFpbGVkJyxcclxuICAgICAgICB0aXRsZTogXCJJdCBkb2Vzbid0IGxvb2sgbGlrZSB5b3UncmUgYSBjYW5kaWRhdGUgZm9yIGFzc2lzdGFuY2UgYXQgdGhpcyB0aW1lLlwiLFxyXG4gICAgICAgIHN1YlRpdGxlOlxyXG4gICAgICAgICAgICBcIkJhc2VkIG9uIHRoZSBpbmZvcm1hdGlvbiB5b3UgZW50ZXJlZCwgeW91ciBob3VzZWhvbGQgZG9lc24ndCBtZWV0IHRoZSBjcml0ZXJpYSBmb3Igb3VyIGhvdXNpbmcgYXNzaXN0YW5jZSBwcm9ncmFtLiBpZiB5b3UnZCBsaWtlIHRvIHJlYWQgbW9yZSBhYm91dCBlbGlnaWJpbGl0eSByZXF1aXJlbWVudCwgeW91IGNhbiB2aXNpdCBvdXIgaGVscCBTZWN0aW9uLCBvciBjb250YWN0IHVzIGZvciBtb3JlIGluZm9ybWF0aW9uLlwiLFxyXG4gICAgICAgIHN1YlRpdGxlMjogJycsXHJcbiAgICAgICAgYnV0dG9uVGV4dDogJ0V4aXQnLFxyXG4gICAgICAgIGxpbmtUZXh0OiAnT3IgVHJ5IEFnYWluJ1xyXG4gICAgfSxcclxuICAgIFtlbGlnaWJpbGl0eVN0YXR1c0NvbnN0YW50LlBFTkRJTkddOiB7XHJcbiAgICAgICAgaWNvbk5hbWU6ICdhbGVydC10cmlhbmdsZScsXHJcbiAgICAgICAgc3RhdHVzOiAncGVuZGluZycsXHJcbiAgICAgICAgdGl0bGU6ICdZb3UgbWF5IG9yIG1heSBub3QgYmUgYSBjYW5kaWRhdGUgYmFzZWQgb24geW91ciBpbmNvbWUuJyxcclxuICAgICAgICBzdWJUaXRsZTpcclxuICAgICAgICAgICAgJ1lvdXIgbW9udGhseSBpbmNvbWUgbG9va3MgbGlrZSBpdCBtaWdodCBiZSB0b28gaGlnaCB0byBiZSBlbGlnaWJsZSBmb3IgYXNzaXN0YW5jZSwgYnV0IG9ubHkgYnkgYSBzbWFsbCBhbW91bnQuJyxcclxuICAgICAgICBzdWJUaXRsZTI6XHJcbiAgICAgICAgICAgIFwiSW4gc29tZSBzaXR1YXRpb25zLCBpbmRpdmlkdWFscyBtYXkgc3RpbGwgYmUgYWJsZSB0byBxdWFsaXR5LiBpZiB5b3UnZCBsaWtlIHRvIGZpbmQgb3V0IGZvciBzdXJlLCB5b3UgbWF5IGNvbnRpbnVlIGFueXdheSwgb3IgY29udGFjdCBvdXIgb2ZmaWNlIHRvIHNwZWFrIHdpdGggYSByZXByZXNlbnRhdGl2ZSBhYm91dCB5b3VyIGVsaWdpYmlsaXR5LlwiLFxyXG4gICAgICAgIGJ1dHRvblRleHQ6ICdFeGl0JyxcclxuICAgICAgICBsaW5rVGV4dDogJ09yIENvbnRpbnVlIEFueXdheSdcclxuICAgIH1cclxufTtcclxuIiwiaW1wb3J0IHsgZWxpZ2liaWxpdHlDb25zdGFudHMsIGluaXRpYWxTdGF0ZSB9IGZyb20gJy4vQ2hlY2tZb3VyRWxpZ2liaWxpdHlDb25zdGFudHMnO1xyXG5cclxuY29uc3Qge1xyXG4gICAgRUxJR0lCSUxJVFlfQUNUSVZFX0lOREVYLFxyXG4gICAgU0FWRV9NT05USExZX0lOQ09NRSxcclxuICAgIFNBVkVfRkFNSUxZX0lORk8sXHJcbiAgICBDT05USU5VRV9XRUxDT01FLFxyXG4gICAgRUxJR0lCSUxJVFlfQ0hFQ0ssXHJcbiAgICBSRVNFVF9GT1JNLFxyXG4gICAgRUxJR0lCSUxJVFlfU1RBVFVTLFxyXG4gICAgTUVUSEFfU1RBVFVTLFxyXG4gICAgU0VYX09GRkVOREVSX1NUQVRVU1xyXG59ID0gZWxpZ2liaWxpdHlDb25zdGFudHM7XHJcblxyXG5leHBvcnQgY29uc3QgQ2hlY2tZb3VyRWxpZ2liaWxpdHkgPSAoc3RhdGUgPSBpbml0aWFsU3RhdGUsIGFjdGlvbikgPT4ge1xyXG4gICAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgICAgIGNhc2UgQ09OVElOVUVfV0VMQ09NRToge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICB3ZWxjb21lQ29udGludWU6IGFjdGlvbi5wYXlsb2FkLndlbGNvbWVDb250aW51ZVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEVMSUdJQklMSVRZX0NIRUNLOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGVsaWdpYmlsaXR5Q2hlY2s6IGFjdGlvbi5wYXlsb2FkLmVsaWdpYmlsaXR5Q2hlY2tcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBTQVZFX0ZBTUlMWV9JTkZPOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGZhbWlseU1lbWJlcjogYWN0aW9uLnBheWxvYWQuZmFtaWx5TWVtYmVyXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgU0FWRV9NT05USExZX0lOQ09NRToge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBtb250aGx5SW5jb21lOiBhY3Rpb24ucGF5bG9hZC5tb250aGx5SW5jb21lXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgRUxJR0lCSUxJVFlfQUNUSVZFX0lOREVYOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVN0ZXBJbmRleDogYWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBSRVNFVF9GT1JNOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5pbml0aWFsU3RhdGVcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBNRVRIQV9TVEFUVVM6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgbWV0aGFTdGF0dXM6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgU0VYX09GRkVOREVSX1NUQVRVUzoge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBzZXhPZmZlbmRlclN0YXR1czogYWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBFTElHSUJJTElUWV9TVEFUVVM6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgYWN0aXZlU3RlcEluZGV4OiA3LFxyXG4gICAgICAgICAgICAgICAgZWxpZ2liaWxpdHlTdGF0dXM6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiBzdGF0ZTtcclxuICAgIH1cclxufTtcclxuIiwiZXhwb3J0IGNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICAgIGFjdGl2ZVN0ZXBJbmRleDogMVxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IFNURVBTID0ge1xyXG4gICAgU1RFUDE6IDEsXHJcbiAgICBTVEVQMjogMixcclxuICAgIFNURVAzOiAzLFxyXG4gICAgU1RFUDQ6IDQsXHJcbiAgICBTVEVQNTogNVxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHByb2ZpbGVDb25zdGFudHMgPSB7XHJcbiAgICBSRVNFVF9GT1JNOiAnUkVTRVRfRk9STScsXHJcbiAgICBQUk9GSUxFX0FDVElWRV9JTkRFWDogJ1BST0ZJTEVfQUNUSVZFX0lOREVYJyxcclxuICAgIFNBVkVfUFJPRklMRTogJ1NBVkVfUFJPRklMRScsXHJcbiAgICBTQVZFX01PTlRITFlfSU5DT01FOiAnU0FWRV9NT05USExZX0lOQ09NRSdcclxufTtcclxuIiwiaW1wb3J0IHsgaW5pdGlhbFN0YXRlLCBwcm9maWxlQ29uc3RhbnRzIH0gZnJvbSAnLi9DcmVhdGVQcm9maWxlQ29uc3RhbnRzJztcclxuXHJcbmNvbnN0IHsgUkVTRVRfRk9STSwgUFJPRklMRV9BQ1RJVkVfSU5ERVgsIFNBVkVfUFJPRklMRSB9ID0gcHJvZmlsZUNvbnN0YW50cztcclxuXHJcbmV4cG9ydCBjb25zdCBDcmVhdGVQcm9maWxlID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb24pID0+IHtcclxuICAgIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgICAgICBjYXNlIFBST0ZJTEVfQUNUSVZFX0lOREVYOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVN0ZXBJbmRleDogYWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBTQVZFX1BST0ZJTEU6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgdXNlcl9wcm9maWxlX2RhdGE6IHsuLi5zdGF0ZT8udXNlcl9wcm9maWxlX2RhdGEsIC4uLmFjdGlvbi5wYXlsb2FkfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFJFU0VUX0ZPUk06IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLmluaXRpYWxTdGF0ZVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gICAgfVxyXG59O1xyXG4iLCJleHBvcnQgY29uc3QgaW5pdGlhbFN0YXRlID0ge1xyXG4gICAgYWN0aXZlU3RlcEluZGV4OiAxLFxyXG4gICAgaW5mb0NvbnRpbnVlOiBmYWxzZSxcclxuICAgIGFkZGl0aW9uYWxNZW1iZXI6IDAsXHJcbiAgICBtZW1iZXJGb3JtU3RlcHM6IFtdLFxyXG4gICAgYWN0aXZlTWVtYmVyOiAxLFxyXG4gICAgaG91c2VIb2xkRm9ybUNvdW50OiAxLFxyXG4gICAgYWRkaXRpb25hbEZvcm1JbmZvOiB7fSxcclxuICAgIHJldmlld0NvbnRpbnVlOiBmYWxzZSxcclxuICAgIGFjY29tbW9kYXRpb25zOiB7fSxcclxuICAgIHNoZWx0ZXJJbmZvOiB7fSxcclxuICAgIG1pbGl0YXJ5SW5mbzoge30sXHJcbiAgICBvdGhlckluZm86IHt9LFxyXG4gICAgcmV2aWV3RGV0YWlsQ29uZmlybTogZmFsc2UsXHJcbiAgICBwcm9ncmFtczogW11cclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBTVEVQUyA9IHtcclxuICAgIFNURVAxOiAxLFxyXG4gICAgU1RFUDI6IDIsXHJcbiAgICBTVEVQMzogMyxcclxuICAgIFNURVA0OiA0LFxyXG4gICAgU1RFUDU6IDUsXHJcbiAgICBTVEVQNjogNixcclxuICAgIFNURVA3OiA3LFxyXG4gICAgU1RFUDg6IDgsXHJcbiAgICBTVEVQOTogOSxcclxuICAgIFNURVAxMDogMTBcclxufTtcclxuZXhwb3J0IGNvbnN0IGhvdXNlSG9sZENvbnN0YW50cyA9IHtcclxuICAgIFJFU0VUX0ZPUk06ICdSRVNFVF9GT1JNJyxcclxuICAgIEhPVVNFX0hPTERfQUNUSVZFX0lOREVYOiAnSE9VU0VfSE9MRF9BQ1RJVkVfSU5ERVgnLFxyXG4gICAgSE9VU0VfSE9MRF9JTkZPX0NPTlRJTlVFOiAnSE9VU0VfSE9MRF9JTkZPX0NPTlRJTlVFJyxcclxuICAgIEhPVVNFX0hPTERfU0FWRV9BRERJVElPTkFMX01FTUJFUjogJ0hPVVNFX0hPTERfU0FWRV9BRERJVElPTkFMX01FTUJFUicsXHJcbiAgICBIT1VTRV9IT0xEX1NBVkVfRklSU1RfQURESVRJT05BTF9GT1JNOiAnSE9VU0VfSE9MRF9TQVZFX0ZJUlNUX0FERElUSU9OQUxfRk9STScsXHJcbiAgICBIT1VTRV9IT0xEX1NBVkVfRklOQUxfQURESVRJT05BTF9GT1JNOiAnSE9VU0VfSE9MRF9TQVZFX0ZJTkFMX0FERElUSU9OQUxfRk9STScsXHJcbiAgICBTRVRfQURESVRJT05BTF9GT1JNX1NURVA6ICdTRVRfQURESVRJT05BTF9GT1JNX1NURVAnLFxyXG4gICAgQkFDS19BRERJVElPTkFMX0ZPUk1fU1RFUDI6ICdCQUNLX0FERElUSU9OQUxfRk9STV9TVEVQMicsXHJcbiAgICBCQUNLX0FERElUSU9OQUxfRk9STV9TVEVQMTogJ0JBQ0tfQURESVRJT05BTF9GT1JNX1NURVAxJyxcclxuICAgIFJFU0VUX0FERElUSU9OQUxfTUVNQkVSOiAnUkVTRVRfQURESVRJT05BTF9NRU1CRVInLFxyXG4gICAgQURESVRJT05BTF9SRVZJRVdfQ09OVElOVUU6ICdBRERJVElPTkFMX1JFVklFV19DT05USU5VRScsXHJcbiAgICBTQVZFX0FDQ09NTU9EQVRJT05TOiAnU0FWRV9BQ0NPTU1PREFUSU9OUycsXHJcbiAgICBTQVZFX1NIRUxURVJfSU5GTzogJ1NBVkVfU0hFTFRFUl9JTkZPJyxcclxuICAgIFNBVkVfTUlMSVRBUllfSUZPOiAnU0FWRV9NSUxJVEFSWV9JRk8nLFxyXG4gICAgU0FWRV9PVEhFUl9JTkZPOiAnU0FWRV9PVEhFUl9JTkZPJyxcclxuICAgIEFERF9NT1JFX01FTUJFUjogJ0FERF9NT1JFX01FTUJFUicsXHJcbiAgICBSRU1PVkVfTUVNQkVSOiAnUkVNT1ZFX01FTUJFUicsXHJcbiAgICBFRElUX01FTUJFUjogJ0VESVRfTUVNQkVSJyxcclxuICAgIFJFTkRFUl9FRElUX0ZPUk1TOiAnUkVOREVSX0VESVRfRk9STVMnLFxyXG4gICAgQ09ORklSTV9SRVZJRVdfREVUQUlMOiAnQ09ORklSTV9SRVZJRVdfREVUQUlMJyxcclxuICAgIFNBVkVfUFJPR1JBTVM6ICdTQVZFX1BST0dSQU1TJ1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IE1FTUJFUl9GT1JNX0ZJTEVEID0ge1xyXG4gICAgZmlyc3ROYW1lOiAnZm5hbWUnLFxyXG4gICAgbWlkZGxlTmFtZTogJ21uYW1lJyxcclxuICAgIGxhc3ROYW1lOiAnbG5hbWUnLFxyXG4gICAgbWFpZGVuTmFtZTogJ21haWRlbl9uYW1lJyxcclxuICAgIHJlbGF0aW9uU2hpcElkOiAncmVsYXRpb25zaGlwX2lkJyxcclxuICAgIGNpdGl6ZW5TaGlwSWQ6ICdjaXRpemVuc2hpcF9pZCcsXHJcbiAgICBkYXRlT2ZCaXJ0aDogJ2RvYicsXHJcbiAgICBnZW5kZXI6ICdnZW5kZXJfaWQnLFxyXG4gICAgc29jaWFsU2VjdXJpdHlOdW1iZXI6ICdzb2NpYWxfc2VjdXJpdHlfbnVtYmVyJyxcclxuICAgIHllYXJseUluY29tZTogJ3llYXJseV9pbmNvbWUnLFxyXG4gICAgcGF5RnJlcXVlbmN5SWQ6ICdwYXlfZnJlcXVlbmN5X2lkJyxcclxuICAgIHBheWNoZWNrQW1vdW50OiAncGF5Y2hlY2tfYW1vdW50JyxcclxuICAgIGlzRGlzYWJsZWQ6ICdpc19kaXNhYmxlZCcsXHJcbiAgICBpc0Z1bGx0aW1lU3R1ZGVudDogJ2lzX2Z1bGx0aW1lX3N0dWRlbnQnLFxyXG4gICAgaXNTdHVkZW50TmV4dFllYXI6ICdpc19zdHVkZW50X25leHRfeWVhcicsXHJcbiAgICBsaWZldGltZVNleE9mZmVuZGVyUmVnOiAnbGlmZXRpbWVfc2V4X29mZmVuZGVyX3JlZycsXHJcbiAgICByYWNlRXRobmljczogJ3JhY2VFdGhuaWNzJ1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IEhPVVNFX0hPTERfRk9STVNfQ09VTlRTID0ge1xyXG4gICAgRk9STTE6IDEsXHJcbiAgICBGT1JNMjogMlxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IE9USEVSX0ZPUk1TID0ge1xyXG4gICAgU0FWRV9BQ0NPTU1PREFUSU9OX0ZPUk1fSU5GTzogJ3NhdmVBY2NvbW1vZGF0aW9uJyxcclxuICAgIFNBVkVfU0hFTFRFUl9GT1JNX0lORk86ICdzYXZlU2hlbHRlckluZm8nLFxyXG4gICAgU0FWRV9NSUxJVEFSWV9GT1JNX0lORk86ICdzYXZlTWlsaXRhcnlJbmZvJyxcclxuICAgIFNBVkVfT1RIRVJfRk9STV9JTkZPOiAnc2F2ZU90aGVySW5mbydcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBzdGF0dXNDYXJkRGF0YSA9IHtcclxuICAgIHRpdGxlOiBcIkl0IGRvZXNuJ3QgbG9vayBsaWtlIHlvdSdyZSBhIGNhbmRpZGF0ZSBmb3IgYW55IHByb2dyYW1zLlwiLFxyXG4gICAgc3ViVGl0bGU6XHJcbiAgICAgICAgXCJXZSdyZSBzb3JyeS4gYmFzZWQgb24gdGhlIGluZm9ybWF0aW9uIHlvdSd2ZSBwcm92aWRlZCB5b3UgZG9uJ3QgbWVldCB0aGUgY3JpdGVyaWEgZm9yIGFueSBvZiBvdXIgcHJvZ3JhbXMuXCIsXHJcbiAgICBzdWJUaXRsZTI6XHJcbiAgICAgICAgJ1lvdSBjYW4gcmV2aWV3IHRoZSBlbGlnaWJpbGl0eSBjcml0ZXJpYSBhbmQgbGVhcm4gbW9yZSBhYm91dCB0aGUgcHJvZ3JhbXMgaGVyZS4gSWYgeW91IHRoaW5rIHRoZXJlIGlzIGEgbWlzdGFrZSBvbiBlbGlnaWJpbGl0eS4gWW91IGNhbiBjb250YWN0IHVzIGZvciBoZWxwLicsXHJcbiAgICBzaG93QnV0dG9uOiB0cnVlLFxyXG4gICAgYnV0dG9uVGV4dDogJ0V4aXQgdG8gRGFzaGJvYXJkJyxcclxuICAgIGJ1dHRvblR5cGU6ICd3aGl0ZScsXHJcbiAgICBpY29uTmFtZTogJ3RodW1icy1kb3duJyxcclxuICAgIGljb25TdGF0dXM6ICdmYWlsZWQnXHJcbn07XHJcbiIsImltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XHJcbmltcG9ydCB7IGhvdXNlSG9sZENvbnN0YW50cywgaW5pdGlhbFN0YXRlIH0gZnJvbSAnLi9Ib3VzZUhvbGRDb25zdGFudHMnO1xyXG5jb25zdCB7XHJcbiAgICBSRVNFVF9GT1JNLFxyXG4gICAgSE9VU0VfSE9MRF9BQ1RJVkVfSU5ERVgsXHJcbiAgICBIT1VTRV9IT0xEX0lORk9fQ09OVElOVUUsXHJcbiAgICBIT1VTRV9IT0xEX1NBVkVfQURESVRJT05BTF9NRU1CRVIsXHJcbiAgICBIT1VTRV9IT0xEX1NBVkVfRklSU1RfQURESVRJT05BTF9GT1JNLFxyXG4gICAgSE9VU0VfSE9MRF9TQVZFX0ZJTkFMX0FERElUSU9OQUxfRk9STSxcclxuICAgIFNFVF9BRERJVElPTkFMX0ZPUk1fU1RFUCxcclxuICAgIEJBQ0tfQURESVRJT05BTF9GT1JNX1NURVAyLFxyXG4gICAgQkFDS19BRERJVElPTkFMX0ZPUk1fU1RFUDEsXHJcbiAgICBSRVNFVF9BRERJVElPTkFMX01FTUJFUixcclxuICAgIEFERElUSU9OQUxfUkVWSUVXX0NPTlRJTlVFLFxyXG4gICAgU0FWRV9BQ0NPTU1PREFUSU9OUyxcclxuICAgIFNBVkVfU0hFTFRFUl9JTkZPLFxyXG4gICAgU0FWRV9NSUxJVEFSWV9JRk8sXHJcbiAgICBTQVZFX09USEVSX0lORk8sXHJcbiAgICBBRERfTU9SRV9NRU1CRVIsXHJcbiAgICBSRU1PVkVfTUVNQkVSLFxyXG4gICAgRURJVF9NRU1CRVIsXHJcbiAgICBSRU5ERVJfRURJVF9GT1JNUyxcclxuICAgIENPTkZJUk1fUkVWSUVXX0RFVEFJTCxcclxuICAgIFNBVkVfUFJPR1JBTVNcclxufSA9IGhvdXNlSG9sZENvbnN0YW50cztcclxuXHJcbmNvbnN0IGNvbnZlcnRCb29sZWFuVG9TdHJpbmcgPSAodmFsdWUpID0+IHtcclxuICAgIHJldHVybiB2YWx1ZSA/ICd0cnVlJyA6ICdmYWxzZSc7XHJcbn07XHJcbmNvbnN0IGdldFJhY2VFdGhuaWNEYXRhID0gKHJhY2VFdGhuaWNzKSA9PiB7XHJcbiAgICBsZXQgcmFjZUV0aG5pY3NBcnIgPSBbXTtcclxuICAgIHJhY2VFdGhuaWNzPy52YWx1ZXMuZm9yRWFjaCgodmFsdWUpID0+IHtcclxuICAgICAgICByYWNlRXRobmljc0FyciA9IFsuLi5yYWNlRXRobmljc0FyciwgdmFsdWU/LmlkXTtcclxuICAgIH0pO1xyXG4gICAgcmV0dXJuIHJhY2VFdGhuaWNzQXJyO1xyXG59O1xyXG5leHBvcnQgY29uc3QgSG91c2VIb2xkUmVkdWNlciA9IChzdGF0ZSA9IGluaXRpYWxTdGF0ZSwgYWN0aW9uKSA9PiB7XHJcbiAgICBjb25zdCB7IGFkZGl0aW9uYWxGb3JtSW5mbyB9ID0gc3RhdGU7XHJcbiAgICBzd2l0Y2ggKGFjdGlvbi50eXBlKSB7XHJcbiAgICAgICAgY2FzZSBIT1VTRV9IT0xEX0FDVElWRV9JTkRFWDoge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVTdGVwSW5kZXg6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgSE9VU0VfSE9MRF9JTkZPX0NPTlRJTlVFOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGluZm9Db250aW51ZTogYWN0aW9uLnBheWxvYWQuaW5mb0NvbnRpbnVlXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgSE9VU0VfSE9MRF9TQVZFX0FERElUSU9OQUxfTUVNQkVSOiB7XHJcbiAgICAgICAgICAgIGxldCBzdGVwc0FyciA9IG5ldyBBcnJheShhY3Rpb24ucGF5bG9hZC5hZGRpdGlvbmFsTWVtYmVyKS5maWxsKDEpO1xyXG4gICAgICAgICAgICBzdGVwc0Fyci5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc3RlcHNBcnJbaW5kZXhdID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFkZGl0aW9uYWxNZW1iZXI6IGFjdGlvbi5wYXlsb2FkLmFkZGl0aW9uYWxNZW1iZXIsXHJcbiAgICAgICAgICAgICAgICBtZW1iZXJGb3JtU3RlcHM6IHN0ZXBzQXJyLFxyXG4gICAgICAgICAgICAgICAgaG91c2VIb2xkRm9ybUNvdW50OiAxLFxyXG4gICAgICAgICAgICAgICAgYWN0aXZlTWVtYmVyOiAxXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgSE9VU0VfSE9MRF9TQVZFX0ZJUlNUX0FERElUSU9OQUxfRk9STToge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBhZGRpdGlvbmFsRm9ybUluZm86IHtcclxuICAgICAgICAgICAgICAgICAgICAuLi5hZGRpdGlvbmFsRm9ybUluZm8sXHJcbiAgICAgICAgICAgICAgICAgICAgW2FjdGlvbi5wYXlsb2FkLmFjdGl2ZU1lbWJlcl06IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgLi4uYWRkaXRpb25hbEZvcm1JbmZvW2FjdGlvbi5wYXlsb2FkLmFjdGl2ZU1lbWJlcl0sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGhvdXNlSG9sZEZvcm1Db3VudDogMlxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEhPVVNFX0hPTERfU0FWRV9GSU5BTF9BRERJVElPTkFMX0ZPUk06IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgYWRkaXRpb25hbEZvcm1JbmZvOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgLi4uYWRkaXRpb25hbEZvcm1JbmZvLFxyXG4gICAgICAgICAgICAgICAgICAgIFthY3Rpb24ucGF5bG9hZC5hY3RpdmVNZW1iZXJdOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmFkZGl0aW9uYWxGb3JtSW5mb1thY3Rpb24ucGF5bG9hZC5hY3RpdmVNZW1iZXJdLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5hY3Rpb24ucGF5bG9hZFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBob3VzZUhvbGRGb3JtQ291bnQ6IDFcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBTRVRfQURESVRJT05BTF9GT1JNX1NURVA6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgYWN0aXZlTWVtYmVyOiBhY3Rpb24ucGF5bG9hZFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEJBQ0tfQURESVRJT05BTF9GT1JNX1NURVAyOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGhvdXNlSG9sZEZvcm1Db3VudDogMVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEJBQ0tfQURESVRJT05BTF9GT1JNX1NURVAxOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGhvdXNlSG9sZEZvcm1Db3VudDogMlxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFJFU0VUX0FERElUSU9OQUxfTUVNQkVSOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIG1lbWJlckZvcm1TdGVwczogW10sXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVNZW1iZXI6IDBcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBBRERJVElPTkFMX1JFVklFV19DT05USU5VRToge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICByZXZpZXdDb250aW51ZTogYWN0aW9uLnBheWxvYWQucmV2aWV3Q29udGludWVcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBTQVZFX0FDQ09NTU9EQVRJT05TOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFjY29tbW9kYXRpb25zOiBhY3Rpb24ucGF5bG9hZFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFNBVkVfU0hFTFRFUl9JTkZPOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIHNoZWx0ZXJJbmZvOiBhY3Rpb24ucGF5bG9hZFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFNBVkVfTUlMSVRBUllfSUZPOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIG1pbGl0YXJ5SW5mbzogYWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBTQVZFX09USEVSX0lORk86IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgb3RoZXJJbmZvOiBhY3Rpb24ucGF5bG9hZFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFJFU0VUX0ZPUk06IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLmluaXRpYWxTdGF0ZVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEFERF9NT1JFX01FTUJFUjoge1xyXG4gICAgICAgICAgICBsZXQgc3RlcHNBcnIgPSBuZXcgQXJyYXkoT2JqZWN0LmtleXMoYWRkaXRpb25hbEZvcm1JbmZvKS5sZW5ndGggKyAxKS5maWxsKDEpO1xyXG4gICAgICAgICAgICBzdGVwc0Fyci5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc3RlcHNBcnJbaW5kZXhdID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFkZGl0aW9uYWxNZW1iZXI6IHN0ZXBzQXJyLmxlbmd0aCB8fCAxLFxyXG4gICAgICAgICAgICAgICAgbWVtYmVyRm9ybVN0ZXBzOiBzdGVwc0FycixcclxuICAgICAgICAgICAgICAgIGhvdXNlSG9sZEZvcm1Db3VudDogMSxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZU1lbWJlcjogc3RlcHNBcnIubGVuZ3RoIHx8IDEsXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVTdGVwSW5kZXg6IDJcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBSRU1PVkVfTUVNQkVSOiB7XHJcbiAgICAgICAgICAgIGNvbnN0IGFkZGl0aW9uYWxGb3JtSW5mb0RhdGEgPSB7IC4uLmFkZGl0aW9uYWxGb3JtSW5mbyB9O1xyXG4gICAgICAgICAgICBjb25zdCByZW1vdmVkTWVtYmVyID0gXy5vbWl0KGFkZGl0aW9uYWxGb3JtSW5mb0RhdGEsIGFjdGlvbi5wYXlsb2FkKTtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgYWRkaXRpb25hbEZvcm1JbmZvOiB7IC4uLnJlbW92ZWRNZW1iZXIgfVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEVESVRfTUVNQkVSOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGhvdXNlSG9sZEZvcm1Db3VudDogMSxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVN0ZXBJbmRleDogMixcclxuICAgICAgICAgICAgICAgIGFjdGl2ZU1lbWJlcjogYWN0aW9uLnBheWxvYWQuYWN0aXZlTWVtYmVyXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgUkVOREVSX0VESVRfRk9STVM6IHtcclxuICAgICAgICAgICAgY29uc3QgZXhpc3RNZW1iZXIgPSBbLi4uYWN0aW9uLnBheWxvYWRdO1xyXG4gICAgICAgICAgICBsZXQgc3RlcHNBcnIgPSBuZXcgQXJyYXkoYWN0aW9uLnBheWxvYWQubGVuZ3RoKS5maWxsKDEpO1xyXG4gICAgICAgICAgICBzdGVwc0Fyci5mb3JFYWNoKChpdGVtLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgc3RlcHNBcnJbaW5kZXhdID0gaW5kZXggKyAxO1xyXG4gICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgbGV0IG1lbWJlckluZm8gPSB7fTtcclxuICAgICAgICAgICAgZXhpc3RNZW1iZXIuZm9yRWFjaCgoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgIG1lbWJlckluZm8gPSB7XHJcbiAgICAgICAgICAgICAgICAgICAgLi4ubWVtYmVySW5mbyxcclxuICAgICAgICAgICAgICAgICAgICBbaW5kZXggKyAxXToge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5pdGVtLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc19kaXNhYmxlZDogY29udmVydEJvb2xlYW5Ub1N0cmluZyhpdGVtLmlzX2Rpc2FibGVkKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgaXNfZnVsbHRpbWVfc3R1ZGVudDogY29udmVydEJvb2xlYW5Ub1N0cmluZyhpdGVtLmlzX2Z1bGx0aW1lX3N0dWRlbnQpLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc19zdHVkZW50X25leHRfeWVhcjogY29udmVydEJvb2xlYW5Ub1N0cmluZyhpdGVtLmlzX3N0dWRlbnRfbmV4dF95ZWFyKSxcclxuICAgICAgICAgICAgICAgICAgICAgICAgbGlmZXRpbWVfc2V4X29mZmVuZGVyX3JlZzogY29udmVydEJvb2xlYW5Ub1N0cmluZyhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGl0ZW0ubGlmZXRpbWVfc2V4X29mZmVuZGVyX3JlZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICApLFxyXG4gICAgICAgICAgICAgICAgICAgICAgICByYWNlRXRobmljczogZ2V0UmFjZUV0aG5pY0RhdGEoaXRlbS5yYWNlX2V0aGluaWMpXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfTtcclxuICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFkZGl0aW9uYWxNZW1iZXI6IGFjdGlvbi5wYXlsb2FkLmxlbmd0aCxcclxuICAgICAgICAgICAgICAgIG1lbWJlckZvcm1TdGVwczogc3RlcHNBcnIsXHJcbiAgICAgICAgICAgICAgICBhZGRpdGlvbmFsRm9ybUluZm86IHsgLi4ubWVtYmVySW5mbyB9XHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgQ09ORklSTV9SRVZJRVdfREVUQUlMOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIHJldmlld0RldGFpbENvbmZpcm06IGFjdGlvbi5wYXlsb2FkLnJldmlld0RldGFpbENvbmZpcm1cclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBTQVZFX1BST0dSQU1TOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIHByb2dyYW1zOiBhY3Rpb24ucGF5bG9hZFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICByZXR1cm4gc3RhdGU7XHJcbiAgICB9XHJcbn07XHJcbiIsImV4cG9ydCBjb25zdCBpbml0aWFsU3RhdGUgPSB7XHJcbiAgICBhY3RpdmVTdGVwSW5kZXg6IDEsXHJcbiAgICB3ZWxjb21lQ29udGludWU6IGZhbHNlLFxyXG4gICAgaG91c2Vob2xkQXNzZXRzQ2hlY2s6IGZhbHNlLFxyXG4gICAgcmV2aWV3U3RhdHVzOiAwXHJcbn07XHJcbmV4cG9ydCBjb25zdCBob3VzZWhvbGRBc3NldHNDb25zdGFudHMgPSB7XHJcbiAgICBIT1VTRUhPTERfQVNTRVRTX0FDVElWRV9JTkRFWDogJ0hPVVNFSE9MRF9BU1NFVFNfQUNUSVZFX0lOREVYJyxcclxuICAgIFNBVkVfRkFNSUxZX0lORk86ICdTQVZFX0ZBTUlMWV9JTkZPJyxcclxuICAgIENPTlRJTlVFX1dFTENPTUU6ICdDT05USU5VRV9XRUxDT01FJyxcclxuICAgIEhPVVNFSE9MRF9BU1NFVFNfQ0hFQ0s6ICdIT1VTRUhPTERfQVNTRVRTX0NIRUNLJyxcclxuICAgIFNBVkVfTU9OVEhMWV9JTkNPTUU6ICdTQVZFX01PTlRITFlfSU5DT01FJyxcclxuICAgIFJFU0VUX0ZPUk06ICdSRVNFVF9GT1JNJyxcclxuICAgIEhPVVNFSE9MRF9BU1NFVFNfU1RBVFVTOiAnSE9VU0VIT0xEX0FTU0VUU19TVEFUVVMnXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgU1RFUFMgPSB7XHJcbiAgICBTVEVQMTogMSxcclxuICAgIFNURVAyOiAyLFxyXG4gICAgU1RFUDM6IDMsXHJcbiAgICBTVEVQNDogNCxcclxuICAgIFNURVA1OiA1LFxyXG4gICAgU1RFUDY6IDZcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBob3VzZWhvbGRBc3NldHNTdGF0dXNDb25zdGFudCA9IHtcclxuICAgIFNVQ0NFU1M6IDEsXHJcbiAgICBGQUlMRUQ6IDIsXHJcbiAgICBQRU5ESU5HOiAzXHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgaG91c2Vob2xkQXNzZXRzU3RhdHVzRGF0YSA9IHtcclxufTtcclxuIiwiaW1wb3J0IHsgaG91c2Vob2xkQXNzZXRzQ29uc3RhbnRzLCBpbml0aWFsU3RhdGUgfSBmcm9tICcuL0hvdXNlaG9sZEFzc2V0c0NvbnN0YW50cyc7XHJcblxyXG5jb25zdCB7XHJcbiAgICBIT1VTRUhPTERfQVNTRVRTX0FDVElWRV9JTkRFWCxcclxuICAgIENPTlRJTlVFX1dFTENPTUUsXHJcbiAgICBIT1VTRUhPTERfQVNTRVRTX0NIRUNLLFxyXG4gICAgUkVTRVRfRk9STSxcclxuICAgIEhPVVNFSE9MRF9BU1NFVFNfU1RBVFVTXHJcbn0gPSBob3VzZWhvbGRBc3NldHNDb25zdGFudHM7XHJcblxyXG5leHBvcnQgY29uc3QgSG91c2Vob2xkQXNzZXRzID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb24pID0+IHtcclxuICAgIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgICAgICBjYXNlIENPTlRJTlVFX1dFTENPTUU6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgd2VsY29tZUNvbnRpbnVlOiBhY3Rpb24ucGF5bG9hZC53ZWxjb21lQ29udGludWVcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBIT1VTRUhPTERfQVNTRVRTX0NIRUNLOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGhvdXNlaG9sZEFzc2V0c0NoZWNrOiBhY3Rpb24ucGF5bG9hZC5ob3VzZWhvbGRBc3NldHNDaGVja1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEhPVVNFSE9MRF9BU1NFVFNfQUNUSVZFX0lOREVYOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVN0ZXBJbmRleDogYWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBSRVNFVF9GT1JNOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5pbml0aWFsU3RhdGVcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBIT1VTRUhPTERfQVNTRVRTX1NUQVRVUzoge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVTdGVwSW5kZXg6IDUsXHJcbiAgICAgICAgICAgICAgICBob3VzZWhvbGRBc3NldHNTdGF0dXM6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiBzdGF0ZTtcclxuICAgIH1cclxufTtcclxuIiwiZXhwb3J0IGNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICAgIGFjdGl2ZVN0ZXBJbmRleDogMSxcclxuICAgIHdlbGNvbWVDb250aW51ZTogZmFsc2UsXHJcbiAgICBob3VzZWhvbGRJbmNvbWVDaGVjazogZmFsc2UsXHJcbiAgICBmYW1pbHlNZW1iZXI6ICcnLFxyXG4gICAgbW9udGhseUluY29tZTogJycsXHJcbiAgICByZXZpZXdTdGF0dXM6IDBcclxufTtcclxuZXhwb3J0IGNvbnN0IGhvdXNlaG9sZEluY29tZUNvbnN0YW50cyA9IHtcclxuICAgIEhPVVNFSE9MRF9BQ1RJVkVfSU5ERVg6ICdIT1VTRUhPTERfQUNUSVZFX0lOREVYJyxcclxuICAgIFNBVkVfRkFNSUxZX0lORk86ICdTQVZFX0ZBTUlMWV9JTkZPJyxcclxuICAgIENPTlRJTlVFX1dFTENPTUU6ICdDT05USU5VRV9XRUxDT01FJyxcclxuICAgIEhPVVNFSE9MRF9DSEVDSzogJ0hPVVNFSE9MRF9DSEVDSycsXHJcbiAgICBTQVZFX01PTlRITFlfSU5DT01FOiAnU0FWRV9NT05USExZX0lOQ09NRScsXHJcbiAgICBSRVNFVF9GT1JNOiAnUkVTRVRfRk9STScsXHJcbiAgICBIT1VTRUhPTERfU1RBVFVTOiAnSE9VU0VIT0xEX1NUQVRVUydcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBTVEVQUyA9IHtcclxuICAgIFNURVAxOiAxLFxyXG4gICAgU1RFUDI6IDIsXHJcbiAgICBTVEVQMzogMyxcclxuICAgIFNURVA0OiA0LFxyXG4gICAgU1RFUDU6IDUsXHJcbiAgICBTVEVQNjogNlxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGhvdXNlaG9sZEluY29tZVN0YXR1c0NvbnN0YW50ID0ge1xyXG4gICAgU1VDQ0VTUzogMSxcclxuICAgIEZBSUxFRDogMixcclxuICAgIFBFTkRJTkc6IDNcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBob3VzZWhvbGRJbmNvbWVTdGF0dXNEYXRhID0ge1xyXG59O1xyXG4iLCJpbXBvcnQgeyBob3VzZWhvbGRJbmNvbWVDb25zdGFudHMsIGluaXRpYWxTdGF0ZSB9IGZyb20gJy4vSG91c2Vob2xkSW5jb21lQ29uc3RhbnRzJztcclxuXHJcbmNvbnN0IHtcclxuICAgIEhPVVNFSE9MRF9BQ1RJVkVfSU5ERVgsXHJcbiAgICBDT05USU5VRV9XRUxDT01FLFxyXG4gICAgSE9VU0VIT0xEX0NIRUNLLFxyXG4gICAgUkVTRVRfRk9STSxcclxuICAgIEhPVVNFSE9MRF9TVEFUVVNcclxufSA9IGhvdXNlaG9sZEluY29tZUNvbnN0YW50cztcclxuXHJcbmV4cG9ydCBjb25zdCBIb3VzZWhvbGRJbmNvbWUgPSAoc3RhdGUgPSBpbml0aWFsU3RhdGUsIGFjdGlvbikgPT4ge1xyXG4gICAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgICAgIGNhc2UgQ09OVElOVUVfV0VMQ09NRToge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICB3ZWxjb21lQ29udGludWU6IGFjdGlvbi5wYXlsb2FkLndlbGNvbWVDb250aW51ZVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEhPVVNFSE9MRF9DSEVDSzoge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBob3VzZWhvbGRJbmNvbWVDaGVjazogYWN0aW9uLnBheWxvYWQuaG91c2Vob2xkSW5jb21lQ2hlY2tcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBIT1VTRUhPTERfQUNUSVZFX0lOREVYOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVN0ZXBJbmRleDogYWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBSRVNFVF9GT1JNOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5pbml0aWFsU3RhdGVcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBIT1VTRUhPTERfU1RBVFVTOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVN0ZXBJbmRleDogNSxcclxuICAgICAgICAgICAgICAgIGhvdXNlaG9sZEluY29tZVN0YXR1czogYWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gICAgfVxyXG59O1xyXG4iLCJleHBvcnQgY29uc3QgaW5pdGlhbFN0YXRlID0ge1xyXG4gICAgYWN0aXZlU3RlcEluZGV4OiAxLFxyXG4gICAgd2VsY29tZUNvbnRpbnVlOiBmYWxzZSxcclxuICAgIGhvdXNlaG9sZFNwZWNpYWxFeHBlbnNlc0NoZWNrOiBmYWxzZSxcclxuICAgIHJldmlld1N0YXR1czogMFxyXG59O1xyXG5leHBvcnQgY29uc3QgaG91c2Vob2xkU3BlY2lhbEV4cGVuc2VzQ29uc3RhbnRzID0ge1xyXG4gICAgSE9VU0VIT0xEX1NQRUNJQUxfRVhQRU5TRVNfQUNUSVZFX0lOREVYOiAnSE9VU0VIT0xEX1NQRUNJQUxfRVhQRU5TRVNfQUNUSVZFX0lOREVYJyxcclxuICAgIFNBVkVfRkFNSUxZX0lORk86ICdTQVZFX0ZBTUlMWV9JTkZPJyxcclxuICAgIENPTlRJTlVFX1dFTENPTUU6ICdDT05USU5VRV9XRUxDT01FJyxcclxuICAgIEhPVVNFSE9MRF9TUEVDSUFMX0VYUEVOU0VTX0NIRUNLOiAnSE9VU0VIT0xEX1NQRUNJQUxfRVhQRU5TRVNfQ0hFQ0snLFxyXG4gICAgU0FWRV9NT05USExZX0lOQ09NRTogJ1NBVkVfTU9OVEhMWV9JTkNPTUUnLFxyXG4gICAgUkVTRVRfRk9STTogJ1JFU0VUX0ZPUk0nLFxyXG4gICAgSE9VU0VIT0xEX1NQRUNJQUxfRVhQRU5TRVNfU1RBVFVTOiAnSE9VU0VIT0xEX1NQRUNJQUxfRVhQRU5TRVNfU1RBVFVTJ1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IFNURVBTID0ge1xyXG4gICAgU1RFUDE6IDEsXHJcbiAgICBTVEVQMjogMixcclxuICAgIFNURVAzOiAzLFxyXG4gICAgU1RFUDQ6IDQsXHJcbiAgICBTVEVQNTogNVxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IGhvdXNlaG9sZFNwZWNpYWxFeHBlbnNlc1N0YXR1c0NvbnN0YW50ID0ge1xyXG4gICAgU1VDQ0VTUzogMSxcclxuICAgIEZBSUxFRDogMixcclxuICAgIFBFTkRJTkc6IDNcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBob3VzZWhvbGRTcGVjaWFsRXhwZW5zZXNTdGF0dXNEYXRhID0ge1xyXG59O1xyXG4iLCJpbXBvcnQgeyBob3VzZWhvbGRTcGVjaWFsRXhwZW5zZXNDb25zdGFudHMsIGluaXRpYWxTdGF0ZSB9IGZyb20gJy4vSG91c2Vob2xkU3BlY2lhbEV4cGVuc2VzQ29uc3RhbnRzJztcclxuXHJcbmNvbnN0IHtcclxuICAgIEhPVVNFSE9MRF9TUEVDSUFMX0VYUEVOU0VTX0FDVElWRV9JTkRFWCxcclxuICAgIENPTlRJTlVFX1dFTENPTUUsXHJcbiAgICBIT1VTRUhPTERfU1BFQ0lBTF9FWFBFTlNFU19DSEVDSyxcclxuICAgIFJFU0VUX0ZPUk0sXHJcbiAgICBIT1VTRUhPTERfU1BFQ0lBTF9FWFBFTlNFU19TVEFUVVNcclxufSA9IGhvdXNlaG9sZFNwZWNpYWxFeHBlbnNlc0NvbnN0YW50cztcclxuXHJcbmV4cG9ydCBjb25zdCBIb3VzZWhvbGRTcGVjaWFsRXhwZW5zZXMgPSAoc3RhdGUgPSBpbml0aWFsU3RhdGUsIGFjdGlvbikgPT4ge1xyXG4gICAgc3dpdGNoIChhY3Rpb24udHlwZSkge1xyXG4gICAgICAgIGNhc2UgQ09OVElOVUVfV0VMQ09NRToge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICB3ZWxjb21lQ29udGludWU6IGFjdGlvbi5wYXlsb2FkLndlbGNvbWVDb250aW51ZVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEhPVVNFSE9MRF9TUEVDSUFMX0VYUEVOU0VTX0NIRUNLOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGhvdXNlaG9sZFNwZWNpYWxFeHBlbnNlc0NoZWNrOiBhY3Rpb24ucGF5bG9hZC5ob3VzZWhvbGRTcGVjaWFsRXhwZW5zZXNDaGVja1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIEhPVVNFSE9MRF9TUEVDSUFMX0VYUEVOU0VTX0FDVElWRV9JTkRFWDoge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVTdGVwSW5kZXg6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgUkVTRVRfRk9STToge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uaW5pdGlhbFN0YXRlXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgSE9VU0VIT0xEX1NQRUNJQUxfRVhQRU5TRVNfU1RBVFVTOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVN0ZXBJbmRleDogNSxcclxuICAgICAgICAgICAgICAgIGhvdXNlaG9sZFNwZWNpYWxFeHBlbnNlc1N0YXR1czogYWN0aW9uLnBheWxvYWRcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgZGVmYXVsdDpcclxuICAgICAgICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gICAgfVxyXG59O1xyXG4iLCJleHBvcnQgY29uc3QgaW5pdGlhbFN0YXRlID0ge1xyXG4gICAgYWN0aXZlU3RlcEluZGV4OiAxLFxyXG4gICAgd2VsY29tZUNvbnRpbnVlOiBmYWxzZSxcclxuICAgIHJlbnRBZmZvcmRhYmlsaXR5Q2hlY2s6IGZhbHNlLFxyXG4gICAgcmV2aWV3U3RhdHVzOiAwXHJcbn07XHJcbmV4cG9ydCBjb25zdCByZW50QWZmb3JkYWJpbGl0eUNvbnN0YW50cyA9IHtcclxuICAgIFJFTlRfQUZGT1JEQUJJTElUWV9BQ1RJVkVfSU5ERVg6ICdSRU5UX0FGRk9SREFCSUxJVFlfQUNUSVZFX0lOREVYJyxcclxuICAgIFNBVkVfRkFNSUxZX0lORk86ICdTQVZFX0ZBTUlMWV9JTkZPJyxcclxuICAgIENPTlRJTlVFX1dFTENPTUU6ICdDT05USU5VRV9XRUxDT01FJyxcclxuICAgIFJFTlRfQUZGT1JEQUJJTElUWV9DSEVDSzogJ1JFTlRfQUZGT1JEQUJJTElUWV9DSEVDSycsXHJcbiAgICBTQVZFX01PTlRITFlfSU5DT01FOiAnU0FWRV9NT05USExZX0lOQ09NRScsXHJcbiAgICBSRVNFVF9GT1JNOiAnUkVTRVRfRk9STScsXHJcbiAgICBSRU5UX0FGRk9SREFCSUxJVFlfU1RBVFVTOiAnUkVOVF9BRkZPUkRBQklMSVRZX1NUQVRVUydcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBTVEVQUyA9IHtcclxuICAgIFNURVAxOiAxLFxyXG4gICAgU1RFUDI6IDJcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCByZW50QWZmb3JkYWJpbGl0eVN0YXR1c0NvbnN0YW50ID0ge1xyXG4gICAgU1VDQ0VTUzogMSxcclxuICAgIEZBSUxFRDogMixcclxuICAgIFBFTkRJTkc6IDNcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCByZW50QWZmb3JkYWJpbGl0eVN0YXR1c0RhdGEgPSB7XHJcbn07XHJcbiIsImltcG9ydCB7IHJlbnRBZmZvcmRhYmlsaXR5Q29uc3RhbnRzLCBpbml0aWFsU3RhdGUgfSBmcm9tICcuL1JlbnRBZmZvcmRhYmlsaXR5Q29uc3RhbnRzJztcclxuXHJcbmNvbnN0IHtcclxuICAgIFJFTlRfQUZGT1JEQUJJTElUWV9BQ1RJVkVfSU5ERVgsXHJcbiAgICBDT05USU5VRV9XRUxDT01FLFxyXG4gICAgUkVOVF9BRkZPUkRBQklMSVRZX0NIRUNLLFxyXG4gICAgUkVTRVRfRk9STSxcclxuICAgIFJFTlRfQUZGT1JEQUJJTElUWV9TVEFUVVNcclxufSA9IHJlbnRBZmZvcmRhYmlsaXR5Q29uc3RhbnRzO1xyXG5cclxuZXhwb3J0IGNvbnN0IFJlbnRBZmZvcmRhYmlsaXR5ID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb24pID0+IHtcclxuICAgIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgICAgICBjYXNlIENPTlRJTlVFX1dFTENPTUU6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgd2VsY29tZUNvbnRpbnVlOiBhY3Rpb24ucGF5bG9hZC53ZWxjb21lQ29udGludWVcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBSRU5UX0FGRk9SREFCSUxJVFlfQ0hFQ0s6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgcmVudEFmZm9yZGFiaWxpdHlDaGVjazogYWN0aW9uLnBheWxvYWQucmVudEFmZm9yZGFiaWxpdHlDaGVja1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFJFTlRfQUZGT1JEQUJJTElUWV9BQ1RJVkVfSU5ERVg6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgYWN0aXZlU3RlcEluZGV4OiBhY3Rpb24ucGF5bG9hZFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFJFU0VUX0ZPUk06IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLmluaXRpYWxTdGF0ZVxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFJFTlRfQUZGT1JEQUJJTElUWV9TVEFUVVM6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgYWN0aXZlU3RlcEluZGV4OiA1LFxyXG4gICAgICAgICAgICAgICAgcmVudEFmZm9yZGFiaWxpdHlTdGF0dXM6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiBzdGF0ZTtcclxuICAgIH1cclxufTtcclxuIiwiZXhwb3J0IGNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICAgIGFjdGl2ZVN0ZXBJbmRleDogMSxcclxuICAgIHdlbGNvbWVDb250aW51ZTogZmFsc2UsXHJcbiAgICByZXZpZXdDaGVjazogZmFsc2UsXHJcbiAgICBmYW1pbHlNZW1iZXI6ICcnLFxyXG4gICAgbW9udGhseUluY29tZTogJycsXHJcbiAgICByZXZpZXdTdGF0dXM6IDBcclxufTtcclxuZXhwb3J0IGNvbnN0IHJldmlld0NvbnN0YW50cyA9IHtcclxuICAgIFJFVklFV19BQ1RJVkVfSU5ERVg6ICdSRVZJRVdfQUNUSVZFX0lOREVYJyxcclxuICAgIFNBVkVfRkFNSUxZX0lORk86ICdTQVZFX0ZBTUlMWV9JTkZPJyxcclxuICAgIENPTlRJTlVFX1dFTENPTUU6ICdDT05USU5VRV9XRUxDT01FJyxcclxuICAgIFJFVklFV19DSEVDSzogJ1JFVklFV19DSEVDSycsXHJcbiAgICBTQVZFX01PTlRITFlfSU5DT01FOiAnU0FWRV9NT05USExZX0lOQ09NRScsXHJcbiAgICBSRVNFVF9GT1JNOiAnUkVTRVRfRk9STScsXHJcbiAgICBSRVZJRVdfU1RBVFVTOiAnUkVWSUVXX1NUQVRVUydcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBTVEVQUyA9IHtcclxuICAgIFNURVAxOiAxLFxyXG4gICAgU1RFUDI6IDIsXHJcbiAgICBTVEVQMzogMyxcclxuICAgIFNURVA0OiA0LFxyXG4gICAgU1RFUDU6IDUsXHJcbiAgICBTVEVQNjogNixcclxuICAgIFNURVA3OiA3LFxyXG4gICAgU1RFUDg6IDgsXHJcbiAgICBTVEVQOTogOVxyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHJldmlld1N0YXR1c0NvbnN0YW50ID0ge1xyXG4gICAgU1VDQ0VTUzogMSxcclxuICAgIEZBSUxFRDogMixcclxuICAgIFBFTkRJTkc6IDNcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCByZXZpZXdTdGF0dXNEYXRhID0ge1xyXG59O1xyXG4iLCJpbXBvcnQgeyByZXZpZXdDb25zdGFudHMsIGluaXRpYWxTdGF0ZSB9IGZyb20gJy4vUmV2aWV3QXBwbGljYXRpb25Db25zdGFudHMnO1xyXG5cclxuY29uc3Qge1xyXG4gICAgUkVWSUVXX0FDVElWRV9JTkRFWCxcclxuICAgIENPTlRJTlVFX1dFTENPTUUsXHJcbiAgICBSRVZJRVdfQ0hFQ0ssXHJcbiAgICBSRVNFVF9GT1JNLFxyXG4gICAgUkVWSUVXX1NUQVRVU1xyXG59ID0gcmV2aWV3Q29uc3RhbnRzO1xyXG5cclxuZXhwb3J0IGNvbnN0IFJldmlld0FwcGxpY2F0aW9uID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb24pID0+IHtcclxuICAgIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgICAgICBjYXNlIENPTlRJTlVFX1dFTENPTUU6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgd2VsY29tZUNvbnRpbnVlOiBhY3Rpb24ucGF5bG9hZC53ZWxjb21lQ29udGludWVcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBSRVZJRVdfQ0hFQ0s6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgcmV2aWV3Q2hlY2s6IGFjdGlvbi5wYXlsb2FkLnJldmlld0NoZWNrXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgUkVWSUVXX0FDVElWRV9JTkRFWDoge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVTdGVwSW5kZXg6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgUkVTRVRfRk9STToge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uaW5pdGlhbFN0YXRlXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgUkVWSUVXX1NUQVRVUzoge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVTdGVwSW5kZXg6IDUsXHJcbiAgICAgICAgICAgICAgICByZXZpZXdTdGF0dXM6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiBzdGF0ZTtcclxuICAgIH1cclxufTtcclxuIiwiZXhwb3J0IGNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICAgIGFjdGl2ZVN0ZXBJbmRleDogMSxcclxuICAgIHdlbGNvbWVDb250aW51ZTogZmFsc2UsXHJcbiAgICB5b3VyRG9jdW1lbnRzQ2hlY2s6IGZhbHNlLFxyXG4gICAgcmV2aWV3U3RhdHVzOiAwXHJcbn07XHJcbmV4cG9ydCBjb25zdCB5b3VyRG9jdW1lbnRzQ29uc3RhbnRzID0ge1xyXG4gICAgWU9VUl9ET0NVTUVOVFNfQUNUSVZFX0lOREVYOiAnWU9VUl9ET0NVTUVOVFNfQUNUSVZFX0lOREVYJyxcclxuICAgIFNBVkVfRkFNSUxZX0lORk86ICdTQVZFX0ZBTUlMWV9JTkZPJyxcclxuICAgIENPTlRJTlVFX1dFTENPTUU6ICdDT05USU5VRV9XRUxDT01FJyxcclxuICAgIFlPVVJfRE9DVU1FTlRTX0NIRUNLOiAnWU9VUl9ET0NVTUVOVFNfQ0hFQ0snLFxyXG4gICAgU0FWRV9NT05USExZX0lOQ09NRTogJ1NBVkVfTU9OVEhMWV9JTkNPTUUnLFxyXG4gICAgUkVTRVRfRk9STTogJ1JFU0VUX0ZPUk0nLFxyXG4gICAgWU9VUl9ET0NVTUVOVFNfU1RBVFVTOiAnWU9VUl9ET0NVTUVOVFNfU1RBVFVTJ1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IFNURVBTID0ge1xyXG4gICAgU1RFUDE6IDEsXHJcbiAgICBTVEVQMjogMixcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCB5b3VyRG9jdW1lbnRzU3RhdHVzQ29uc3RhbnQgPSB7XHJcbiAgICBTVUNDRVNTOiAxLFxyXG4gICAgRkFJTEVEOiAyLFxyXG4gICAgUEVORElORzogM1xyXG59O1xyXG5cclxuZXhwb3J0IGNvbnN0IHlvdXJEb2N1bWVudHNTdGF0dXNEYXRhID0ge1xyXG59O1xyXG4iLCJpbXBvcnQgeyB5b3VyRG9jdW1lbnRzQ29uc3RhbnRzLCBpbml0aWFsU3RhdGUgfSBmcm9tICcuL1lvdXJEb2N1bWVudHNDb25zdGFudHMnO1xyXG5cclxuY29uc3Qge1xyXG4gICAgWU9VUl9ET0NVTUVOVFNfQUNUSVZFX0lOREVYLFxyXG4gICAgQ09OVElOVUVfV0VMQ09NRSxcclxuICAgIFlPVVJfRE9DVU1FTlRTX0NIRUNLLFxyXG4gICAgUkVTRVRfRk9STSxcclxuICAgIFlPVVJfRE9DVU1FTlRTX1NUQVRVU1xyXG59ID0geW91ckRvY3VtZW50c0NvbnN0YW50cztcclxuXHJcbmV4cG9ydCBjb25zdCBZb3VyRG9jdW1lbnRzID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCBhY3Rpb24pID0+IHtcclxuICAgIHN3aXRjaCAoYWN0aW9uLnR5cGUpIHtcclxuICAgICAgICBjYXNlIENPTlRJTlVFX1dFTENPTUU6IHtcclxuICAgICAgICAgICAgcmV0dXJuIHtcclxuICAgICAgICAgICAgICAgIC4uLnN0YXRlLFxyXG4gICAgICAgICAgICAgICAgd2VsY29tZUNvbnRpbnVlOiBhY3Rpb24ucGF5bG9hZC53ZWxjb21lQ29udGludWVcclxuICAgICAgICAgICAgfTtcclxuICAgICAgICB9XHJcbiAgICAgICAgY2FzZSBZT1VSX0RPQ1VNRU5UU19DSEVDSzoge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICB5b3VyRG9jdW1lbnRzQ2hlY2s6IGFjdGlvbi5wYXlsb2FkLnlvdXJEb2N1bWVudHNDaGVja1xyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgIH1cclxuICAgICAgICBjYXNlIFlPVVJfRE9DVU1FTlRTX0FDVElWRV9JTkRFWDoge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBhY3RpdmVTdGVwSW5kZXg6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgUkVTRVRfRk9STToge1xyXG4gICAgICAgICAgICByZXR1cm4ge1xyXG4gICAgICAgICAgICAgICAgLi4uaW5pdGlhbFN0YXRlXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGNhc2UgWU9VUl9ET0NVTUVOVFNfU1RBVFVTOiB7XHJcbiAgICAgICAgICAgIHJldHVybiB7XHJcbiAgICAgICAgICAgICAgICAuLi5zdGF0ZSxcclxuICAgICAgICAgICAgICAgIGFjdGl2ZVN0ZXBJbmRleDogNSxcclxuICAgICAgICAgICAgICAgIHlvdXJEb2N1bWVudHNTdGF0dXM6IGFjdGlvbi5wYXlsb2FkXHJcbiAgICAgICAgICAgIH07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgICAgIHJldHVybiBzdGF0ZTtcclxuICAgIH1cclxufTtcclxuIiwiaW1wb3J0IERhdGVGbnNVdGlscyBmcm9tICdAZGF0ZS1pby9kYXRlLWZucyc7XHJcbmltcG9ydCBDc3NCYXNlbGluZSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9Dc3NCYXNlbGluZSc7XHJcbmltcG9ydCB7IFRoZW1lUHJvdmlkZXIgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5pbXBvcnQgeyBNdWlQaWNrZXJzVXRpbHNQcm92aWRlciB9IGZyb20gJ0BtYXRlcmlhbC11aS9waWNrZXJzJztcclxuaW1wb3J0IEhlYWQgZnJvbSAnbmV4dC9oZWFkJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgUHJvdmlkZXIgfSBmcm9tICdyZWFjdC1yZWR1eCc7XHJcbmltcG9ydCB7IFRvYXN0UHJvdmlkZXIgfSBmcm9tICdyZWFjdC10b2FzdC1ub3RpZmljYXRpb25zJztcclxuaW1wb3J0IHsgcGVyc2lzdFN0b3JlIH0gZnJvbSAncmVkdXgtcGVyc2lzdCc7XHJcbmltcG9ydCB7IFBlcnNpc3RHYXRlIH0gZnJvbSAncmVkdXgtcGVyc2lzdC9pbnRlZ3JhdGlvbi9yZWFjdCc7XHJcbmltcG9ydCB7IHVzZVN0b3JlIH0gZnJvbSAnc2hhcmVkL3JlZHV4L3N0b3JlJztcclxuaW1wb3J0ICdzaGFyZWQvc3R5bGVzL2dsb2JhbHMuc2Nzcyc7XHJcbmltcG9ydCB0aGVtZSBmcm9tICdzaGFyZWQvdXRpbHMvdGhlbWUnO1xyXG5pbXBvcnQgR2xvYmFsU3R5bGVzIGZyb20gJ34vc2hhcmVkL3V0aWxzL2dsb2JhbFN0eWxlcyc7XHJcblxyXG4vKipcclxuICogTmFtZSA6IEFwcFxyXG4gKiBEZXNjIDogUmVuZGVyIEFwcFxyXG4gKiovXHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNeUFwcChwcm9wcykge1xyXG4gICAgY29uc3QgeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9ID0gcHJvcHM7XHJcbiAgICBjb25zdCBzdG9yZSA9IHVzZVN0b3JlKHBhZ2VQcm9wcy5pbml0aWFsUmVkdXhTdGF0ZSk7XHJcbiAgICBjb25zdCBwZXJzaXN0b3IgPSBwZXJzaXN0U3RvcmUoc3RvcmUsIHt9LCBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgcGVyc2lzdG9yLnBlcnNpc3QoKTtcclxuICAgIH0pO1xyXG4gICAgLy8gdmFyIGhpZGVXaWRnZXQgPSAod2luZG93LmxvY2F0aW9uLmhyZWYuaW5kZXhPZihcIkhvbWVcIikgPiAtMSkgPyB0cnVlIDogZmFsc2U7XHJcblxyXG4gICAgLy8gUmVtb3ZlIHRoZSBzZXJ2ZXItc2lkZSBpbmplY3RlZCBDU1MuXHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8UmVhY3QuRnJhZ21lbnQ+XHJcbiAgICAgICAgICAgIDxIZWFkPlxyXG4gICAgICAgICAgICAgICAgPHRpdGxlPkhhY2VwPC90aXRsZT5cclxuICAgICAgICAgICAgICAgIDxsaW5rIHJlbD1cImljb25cIiB0eXBlPVwiaW1hZ2UvcG5nXCIgc2l6ZXM9XCIzMngzMlwiIGhyZWY9XCIvQ2xpZW50X0xvZ28ucG5nXCIgLz5cclxuICAgICAgICAgICAgICAgIDxtZXRhXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZT1cInZpZXdwb3J0XCJcclxuICAgICAgICAgICAgICAgICAgICBjb250ZW50PVwibWluaW11bS1zY2FsZT0xLCBpbml0aWFsLXNjYWxlPTEsIHdpZHRoPWRldmljZS13aWR0aFwiXHJcbiAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgey8qIExvY2FsaXplSnMgc3RhcnRzKi99XHJcbiAgICAgICAgICAgICAgICA8c2NyaXB0IGFzeW5jIHNyYz1cImh0dHBzOi8vZ2xvYmFsLmxvY2FsaXplY2RuLmNvbS9sb2NhbGl6ZS5qc1wiPjwvc2NyaXB0PlxyXG4gICAgICAgICAgICAgICAgPHNjcmlwdD5cclxuICAgICAgICAgICAgICAgICAgICB7YCFmdW5jdGlvbihhKXtpZighYS5Mb2NhbGl6ZSl7YS5Mb2NhbGl6ZT17fTtcclxuICAgICAgICAgICAgICAgICAgICBmb3IodmFyIGU9W1widHJhbnNsYXRlXCIsXCJ1bnRyYW5zbGF0ZVwiLFwicGhyYXNlXCIsXCJpbml0aWFsaXplXCIsXCJ0cmFuc2xhdGVQYWdlXCIsXCJzZXRMYW5ndWFnZVwiLFwiZ2V0TGFuZ3VhZ2VcIixcImdldFNvdXJjZUxhbmd1YWdlXCIsXCJkZXRlY3RMYW5ndWFnZVwiLFwiZ2V0QXZhaWxhYmxlTGFuZ3VhZ2VzXCIsXCJ1bnRyYW5zbGF0ZVBhZ2VcIixcImJvb3RzdHJhcFwiLFwicHJlZmV0Y2hcIixcIm9uXCIsXCJvZmZcIixcImhpZGVXaWRnZXRcIixcInNob3dXaWRnZXRcIl0sXHJcbiAgICAgICAgICAgICAgICAgICAgdD0wO3Q8ZS5sZW5ndGg7dCsrKWEuTG9jYWxpemVbZVt0XV09ZnVuY3Rpb24oKXt9fX0od2luZG93KTtgfVxyXG4gICAgICAgICAgICAgICAgPC9zY3JpcHQ+XHJcbiAgICAgICAgICAgICAgICA8c2NyaXB0PlxyXG4gICAgICAgICAgICAgICAgICAgIHtgTG9jYWxpemUuaW5pdGlhbGl6ZSh7IGtleTogJzY3NDRlODI3ZTIyNTInLCByZW1lbWJlckxhbmd1YWdlOiB0cnVlLCB9KTtgfVxyXG4gICAgICAgICAgICAgICAgPC9zY3JpcHQ+XHJcbiAgICAgICAgICAgICAgICB7LyogTG9jYWxpemVKcyBlbmQqL31cclxuICAgICAgICAgICAgPC9IZWFkPlxyXG4gICAgICAgICAgICA8VG9hc3RQcm92aWRlciBhdXRvRGlzbWlzcz5cclxuICAgICAgICAgICAgICAgIDxUaGVtZVByb3ZpZGVyIHRoZW1lPXt0aGVtZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgey8qIENzc0Jhc2VsaW5lIGtpY2tzdGFydCBhbiBlbGVnYW50LCBjb25zaXN0ZW50LCBhbmQgc2ltcGxlIGJhc2VsaW5lIHRvIGJ1aWxkIHVwb24uICovfVxyXG4gICAgICAgICAgICAgICAgICAgIDxHbG9iYWxTdHlsZXMgLz5cclxuICAgICAgICAgICAgICAgICAgICA8Q3NzQmFzZWxpbmUgLz5cclxuICAgICAgICAgICAgICAgICAgICA8UHJvdmlkZXIgc3RvcmU9e3N0b3JlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFBlcnNpc3RHYXRlIGxvYWRpbmc9ezxkaXY+bG9hZGluZzwvZGl2Pn0gcGVyc2lzdG9yPXtwZXJzaXN0b3J9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE11aVBpY2tlcnNVdGlsc1Byb3ZpZGVyIHV0aWxzPXtEYXRlRm5zVXRpbHN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTXVpUGlja2Vyc1V0aWxzUHJvdmlkZXI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUGVyc2lzdEdhdGU+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Qcm92aWRlcj5cclxuICAgICAgICAgICAgICAgIDwvVGhlbWVQcm92aWRlcj5cclxuICAgICAgICAgICAgPC9Ub2FzdFByb3ZpZGVyPlxyXG4gICAgICAgIDwvUmVhY3QuRnJhZ21lbnQ+XHJcbiAgICApO1xyXG59XHJcblxyXG5NeUFwcC5wcm9wVHlwZXMgPSB7XHJcbiAgICBDb21wb25lbnQ6IFByb3BUeXBlcy5lbGVtZW50VHlwZS5pc1JlcXVpcmVkLFxyXG4gICAgcGFnZVByb3BzOiBQcm9wVHlwZXMub2JqZWN0LmlzUmVxdWlyZWRcclxufTtcclxuIiwiLy8gUkVEVVggQUNUSU9OIFRZUEVTXHJcbmV4cG9ydCBjb25zdCBUSUNLID0gJ1RJQ0snO1xyXG5leHBvcnQgY29uc3QgSU5DUkVNRU5UID0gJ0lOQ1JFTUVOVCc7XHJcbmV4cG9ydCBjb25zdCBERUNSRU1FTlQgPSAnREVDUkVNRU5UJztcclxuZXhwb3J0IGNvbnN0IFJFU0VUID0gJ1JFU0VUJztcclxuIiwiaW1wb3J0ICogYXMgdHlwZXMgZnJvbSAnLi9jb25zdGFudHMnO1xyXG4vLyBJTklUSUFMIFRJTUVSIFNUQVRFXHJcbmNvbnN0IGluaXRpYWxTdGF0ZSA9IHtcclxuICBjb3VudGVyOiAwLFxyXG59O1xyXG4vLyBDT1VOVEVSIFJFRFVDRVJcclxuZXhwb3J0IGNvbnN0IGNvdW50ZXJSZWR1Y2VyID0gKHN0YXRlID0gaW5pdGlhbFN0YXRlLCB7IHR5cGUgfSkgPT4ge1xyXG4gIHN3aXRjaCAodHlwZSkge1xyXG4gICAgY2FzZSB0eXBlcy5JTkNSRU1FTlQ6XHJcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBjb3VudGVyOiBzdGF0ZS5jb3VudGVyICsgMSB9O1xyXG4gICAgY2FzZSB0eXBlcy5ERUNSRU1FTlQ6XHJcbiAgICAgIHJldHVybiB7IC4uLnN0YXRlLCBjb3VudGVyOiBzdGF0ZS5jb3VudGVyIC0gMSB9O1xyXG4gICAgY2FzZSB0eXBlcy5SRVNFVDpcclxuICAgICAgcmV0dXJuIHsgLi4uc3RhdGUsIGNvdW50ZXI6IDAgfTtcclxuICAgIGRlZmF1bHQ6XHJcbiAgICAgIHJldHVybiBzdGF0ZTtcclxuICB9XHJcbn07XHJcbiIsImltcG9ydCB7IGNvbWJpbmVSZWR1Y2VycyB9IGZyb20gJ3JlZHV4JztcclxuaW1wb3J0IHsgcGVyc2lzdFJlZHVjZXIgfSBmcm9tICdyZWR1eC1wZXJzaXN0JztcclxuaW1wb3J0IHN0b3JhZ2UgZnJvbSAncmVkdXgtcGVyc2lzdC9saWIvc3RvcmFnZSc7XHJcbmltcG9ydCB7IGxvZ2luUmVkdWNlciB9IGZyb20gJ34vbW9kdWxlcy9BZG1pbi9Mb2dpbi9VdGlscy9Mb2dpblJlZHVjZXInO1xyXG5pbXBvcnQgeyBDaGVja1lvdXJFbGlnaWJpbGl0eSB9IGZyb20gJ34vbW9kdWxlcy9DaGVja1lvdXJFbGlnaWJpbGl0eS9VdGlscy9DaGVja1lvdXJFbGlnaWJpbGl0eVJlZHVjZXJzJztcclxuaW1wb3J0IHsgUmV2aWV3QXBwbGljYXRpb24gfSBmcm9tICd+L21vZHVsZXMvUmV2aWV3QXBwbGljYXRpb24vVXRpbHMvUmV2aWV3QXBwbGljYXRpb25SZWR1Y2Vycyc7XHJcbmltcG9ydCB7IEhvdXNlaG9sZEluY29tZSB9IGZyb20gJ34vbW9kdWxlcy9Ib3VzZWhvbGRJbmNvbWUvVXRpbHMvSG91c2Vob2xkSW5jb21lUmVkdWNlcnMnO1xyXG5pbXBvcnQgeyBIb3VzZWhvbGRBc3NldHMgfSBmcm9tICd+L21vZHVsZXMvSG91c2Vob2xkQXNzZXRzL1V0aWxzL0hvdXNlaG9sZEFzc2V0c1JlZHVjZXJzJztcclxuaW1wb3J0IHsgSG91c2Vob2xkU3BlY2lhbEV4cGVuc2VzIH0gZnJvbSAnfi9tb2R1bGVzL0hvdXNlaG9sZFNwZWNpYWxFeHBlbnNlcy9VdGlscy9Ib3VzZWhvbGRTcGVjaWFsRXhwZW5zZXNSZWR1Y2Vycyc7XHJcbmltcG9ydCB7IFJlbnRBZmZvcmRhYmlsaXR5IH0gZnJvbSAnfi9tb2R1bGVzL1JlbnRBZmZvcmRhYmlsaXR5L1V0aWxzL1JlbnRBZmZvcmRhYmlsaXR5UmVkdWNlcnMnO1xyXG5pbXBvcnQgeyBZb3VyRG9jdW1lbnRzIH0gZnJvbSAnfi9tb2R1bGVzL1lvdXJEb2N1bWVudHMvVXRpbHMvWW91ckRvY3VtZW50c1JlZHVjZXJzJztcclxuaW1wb3J0IHsgQ3JlYXRlUHJvZmlsZSB9IGZyb20gJ34vbW9kdWxlcy9DcmVhdGVQcm9maWxlTW9kdWxlL1V0aWxzL0NyZWF0ZVByb2ZpbGVSZWR1Y2Vycyc7XHJcbmltcG9ydCB7IEhvdXNlSG9sZFJlZHVjZXIgfSBmcm9tICd+L21vZHVsZXMvSG91c2VIb2xkTW9kdWxlL1V0aWxzL0hvdXNlSG9sZFJlZHVjZXJzJztcclxuaW1wb3J0IHsgY291bnRlclJlZHVjZXIgfSBmcm9tICcuL2V4YW1wbGVSZWR1Y2VyJztcclxuXHJcbi8vIENPTUJJTkVEIFJFRFVDRVJTXHJcbmNvbnN0IHJlZHVjZXJzID0ge1xyXG4gICAgY291bnRlcjogY291bnRlclJlZHVjZXIsXHJcbiAgICBsb2dpbkRldGFpbHM6IGxvZ2luUmVkdWNlcixcclxuICAgIGNoZWNrRWxpZ2liaWxpdHk6IENoZWNrWW91ckVsaWdpYmlsaXR5LFxyXG4gICAgcmV2aWV3QXBwbGljYXRpb246IFJldmlld0FwcGxpY2F0aW9uLFxyXG4gICAgaG91c2Vob2xkSW5jb21lOiBIb3VzZWhvbGRJbmNvbWUsXHJcbiAgICBob3VzZWhvbGRBc3NldHM6IEhvdXNlaG9sZEFzc2V0cyxcclxuICAgIGhvdXNlaG9sZFNwZWNpYWxFeHBlbnNlczogSG91c2Vob2xkU3BlY2lhbEV4cGVuc2VzLFxyXG4gICAgcmVudEFmZm9yZGFiaWxpdHk6IFJlbnRBZmZvcmRhYmlsaXR5LFxyXG4gICAgeW91ckRvY3VtZW50czogWW91ckRvY3VtZW50cyxcclxuICAgIGhvdXNlSG9sZERldGFpbHM6IEhvdXNlSG9sZFJlZHVjZXIsXHJcbiAgICBwcm9maWxlU3RlcHM6IENyZWF0ZVByb2ZpbGVcclxufTtcclxuXHJcbmNvbnN0IHBlcnNpc3RDb25maWcgPSB7XHJcbiAgICBrZXk6ICdwcmltYXJ5JyxcclxuICAgIHN0b3JhZ2UsXHJcbiAgICB3aGl0ZWxpc3Q6IFsnY291bnRlcicsICdsb2dpbkRldGFpbHMnLCAnaG91c2VIb2xkRGV0YWlscyddIC8vIHBsYWNlIHRvIHNlbGVjdCB3aGljaCBzdGF0ZSB5b3Ugd2FudCB0byBwZXJzaXN0XHJcbn07XHJcbmNvbnN0IHBlcnNpc3RlZFJlZHVjZXIgPSBwZXJzaXN0UmVkdWNlcihwZXJzaXN0Q29uZmlnLCBjb21iaW5lUmVkdWNlcnMocmVkdWNlcnMpKTtcclxuZXhwb3J0IGRlZmF1bHQgcGVyc2lzdGVkUmVkdWNlcjtcclxuIiwiaW1wb3J0IHsgdXNlTWVtbyB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgYXBwbHlNaWRkbGV3YXJlLCBjcmVhdGVTdG9yZSB9IGZyb20gJ3JlZHV4JztcclxuaW1wb3J0IHsgY29tcG9zZVdpdGhEZXZUb29scyB9IGZyb20gJ3JlZHV4LWRldnRvb2xzLWV4dGVuc2lvbic7XHJcbmltcG9ydCB0aHVua01pZGRsZXdhcmUgZnJvbSAncmVkdXgtdGh1bmsnO1xyXG5pbXBvcnQgcmVkdWNlcnMgZnJvbSAnLi9yZWR1Y2Vycyc7XHJcblxyXG5sZXQgc3RvcmU7XHJcblxyXG5mdW5jdGlvbiBpbml0U3RvcmUoaW5pdGlhbFN0YXRlKSB7XHJcbiAgICByZXR1cm4gY3JlYXRlU3RvcmUoXHJcbiAgICAgICAgcmVkdWNlcnMsXHJcbiAgICAgICAgaW5pdGlhbFN0YXRlLFxyXG4gICAgICAgIGNvbXBvc2VXaXRoRGV2VG9vbHMoYXBwbHlNaWRkbGV3YXJlKHRodW5rTWlkZGxld2FyZSkpXHJcbiAgICApO1xyXG59XHJcblxyXG5leHBvcnQgY29uc3QgaW5pdGlhbGl6ZVN0b3JlID0gKHByZWxvYWRlZFN0YXRlKSA9PiB7XHJcbiAgICBsZXQgX3N0b3JlID0gc3RvcmUgPz8gaW5pdFN0b3JlKHByZWxvYWRlZFN0YXRlKTtcclxuXHJcbiAgICAvLyBBZnRlciBuYXZpZ2F0aW5nIHRvIGEgcGFnZSB3aXRoIGFuIGluaXRpYWwgUmVkdXggc3RhdGUsIG1lcmdlIHRoYXQgc3RhdGVcclxuICAgIC8vIHdpdGggdGhlIGN1cnJlbnQgc3RhdGUgaW4gdGhlIHN0b3JlLCBhbmQgY3JlYXRlIGEgbmV3IHN0b3JlXHJcbiAgICBpZiAocHJlbG9hZGVkU3RhdGUgJiYgc3RvcmUpIHtcclxuICAgICAgICBfc3RvcmUgPSBpbml0U3RvcmUoe1xyXG4gICAgICAgICAgICAuLi5zdG9yZS5nZXRTdGF0ZSgpLFxyXG4gICAgICAgICAgICAuLi5wcmVsb2FkZWRTdGF0ZVxyXG4gICAgICAgIH0pO1xyXG4gICAgICAgIC8vIFJlc2V0IHRoZSBjdXJyZW50IHN0b3JlXHJcbiAgICAgICAgc3RvcmUgPSB1bmRlZmluZWQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8gRm9yIFNTRyBhbmQgU1NSIGFsd2F5cyBjcmVhdGUgYSBuZXcgc3RvcmVcclxuICAgIGlmICh0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgIHJldHVybiBfc3RvcmU7XHJcbiAgICB9XHJcbiAgICAvLyBDcmVhdGUgdGhlIHN0b3JlIG9uY2UgaW4gdGhlIGNsaWVudFxyXG4gICAgaWYgKCFzdG9yZSkge1xyXG4gICAgICAgIHN0b3JlID0gX3N0b3JlO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBfc3RvcmU7XHJcbn07XHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXNlU3RvcmUoaW5pdGlhbFN0YXRlKSB7XHJcbiAgICBjb25zdCBzdG9yZSA9IHVzZU1lbW8oKCkgPT4gaW5pdGlhbGl6ZVN0b3JlKGluaXRpYWxTdGF0ZSksIFtpbml0aWFsU3RhdGVdKTtcclxuICAgIHJldHVybiBzdG9yZTtcclxufVxyXG4iLCJjb25zdCBBbGVydE92ZXJpZGUgPSB7XHJcbiAgICBNdWlBbGVydDoge1xyXG4gICAgICAgIHJvb3Q6e1xyXG4gICAgICAgICAgICBmb250U2l6ZTonMTVweCcsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6XCIxMnB4IDI0cHhcIlxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaWNvbjp7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6J25vbmUnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzdGFuZGFyZFN1Y2Nlc3M6e1xyXG4gICAgICAgICAgICBjb2xvcjonaW5oZXJpdCcsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjonaW5oZXJpdCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGFjdGlvbjp7XHJcbiAgICAgICAgICAgIGFsaWduSXRlbXM6J2ZsZXgtc3RhcnQnLFxyXG4gICAgICAgICAgICAnJiAuTXVpSWNvbkJ1dHRvbi1yb290Jzp7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOic2cHggMCcsXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIG1lc3NhZ2U6e1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAnNnB4IDAnLFxyXG4gICAgICAgICAgICB3aWR0aDonMTAwJSdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgTXVpQWxlcnRUaXRsZTp7XHJcbiAgICAgICAgcm9vdDp7XHJcbiAgICAgICAgICAgIG1hcmdpbkJvdHRvbTonNHB4J1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFsZXJ0T3ZlcmlkZTsiLCJpbXBvcnQgY29sb3IgZnJvbSAnLi4vY29sb3InO1xyXG5pbXBvcnQgZm9udCBmcm9tICcuLi90eXBvZ3JhcGh5JztcclxuXHJcbmNvbnN0IEJ1dHRvbk92ZXJSaWRlID0ge1xyXG4gICAgTXVpQnV0dG9uOiB7XHJcbiAgICAgICAgc2l6ZUxhcmdlOiB7XHJcbiAgICAgICAgICAgIG1pbldpZHRoOiAnMTkycHgnLFxyXG4gICAgICAgICAgICBmb250U2l6ZTogZm9udC5oNS5mb250U2l6ZSxcclxuICAgICAgICAgICAgcGFkZGluZzogJzhweCA1MXB4JyxcclxuICAgICAgICB9LFxyXG4gICAgICAgIHNpemVTbWFsbDoge1xyXG4gICAgICAgICAgICBmb250U2l6ZTogZm9udC5zbS5mb250U2l6ZSxcclxuICAgICAgICAgICAgbWluV2lkdGg6ICc5MHB4JyxcclxuICAgICAgICAgICAgbWluSGVpZ2h0OiAnMzZweCcsXHJcbiAgICAgICAgICAgIGZvbnRGYW1pbHk6IGZvbnQuZm9udEZhbWlseS5yZWd1bGFyXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzaXplTWVkaXVtOiB7XHJcbiAgICAgICAgICAgIG1pbldpZHRoOiAnMTYwcHgnLFxyXG4gICAgICAgICAgICBmb250RmFtaWx5OiBmb250LmZvbnRGYW1pbHkubWVkaXVtXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjb250YWluZWRTZWNvbmRhcnk6IHtcclxuICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUuYnV0dG9uLnNlY29uZGFyeUNvbG9yXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjb2xvckluaGVyaXQ6IHtcclxuICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUucHJpbWFyeS5tYWluLFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLmNvbW1vbi53aGl0ZVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY29udGFpbmVkOiB7XHJcbiAgICAgICAgICAgIGJveFNoYWRvdzogJ25vbmUnXHJcbiAgICAgICAgfSxcclxuXHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc1MHB4JyxcclxuICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogJ2luaGVyaXQnLFxyXG4gICAgICAgICAgICBmb250RmFtaWx5OiBmb250LmZvbnRGYW1pbHkubWVkaXVtLFxyXG4gICAgICAgICAgICAnJi5zZW1pQm9yZGVyJzoge1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMHB4IDBweCAyMHB4IDIwcHgnLFxyXG4gICAgICAgICAgICAgICAgcGFkZGluZzonOHB4IDVweCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYubGlua0J0bic6IHtcclxuICAgICAgICAgICAgICAgIG1pbldpZHRoOiAnYXV0byAhaW1wb3J0YW50JyxcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IGAwICFpbXBvcnRhbnRgLFxyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMCAhaW1wb3J0YW50JyxcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50JyxcclxuICAgICAgICAgICAgICAgICcmOmhvdmVyJzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50ICFpbXBvcnRhbnQnXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgJyY6Zm9jdXMnOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQgIWltcG9ydGFudCdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYubGluay1wcmltYXJ5Jzoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUuc3VjY2Vzcy5leHRyYUxpZ2h0LFxyXG4gICAgICAgICAgICAgICAgZm9udEZhbWlseTogZm9udC5mb250RmFtaWx5LnJlZ3VsYXIsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udC5sZy5mb250U2l6ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJi5saW5rLXdoaXRlJzoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IFwiI2ZmZlwiLFxyXG4gICAgICAgICAgICAgICAgZm9udEZhbWlseTogZm9udC5mb250RmFtaWx5LnJlZ3VsYXIsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udC5sZy5mb250U2l6ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJi5mYWNlYm9vS0J0bic6IHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3IuY29tbW9uLmZhY2Vib29rQmx1ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJi53LTI2OSc6IHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOlwiMjY5cHhcIlxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZW5kSWNvbjp7XHJcbiAgICAgICAgICAgIG1hcmdpbkxlZnQ6JzRweCdcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCdXR0b25PdmVyUmlkZTtcclxuIiwiY29uc3QgQ2FyZE92ZXJSaWRlID0ge1xyXG4gICAgTXVpQ2FyZDoge1xyXG4gICAgICAgIHJvb3Q6e1xyXG4gICAgICAgICAgICBib3hTaGFkb3c6ICcwIDRweCA0cHggcmdiKDAgMCAwIC8gOCUpJyxcclxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMjFweCdcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDYXJkT3ZlclJpZGU7XHJcbiIsImltcG9ydCBjb2xvciBmcm9tICcuLi9jb2xvcic7XHJcbmltcG9ydCBmb250IGZyb20gJy4uL3R5cG9ncmFwaHknO1xyXG5cclxuY29uc3QgQ2hlY2tCb3hPdmVyUmlkZSA9IHtcclxuICAgIE11aUNoZWNrYm94OiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAnJi5leHRyYUxpZ2h0TGFiZWwgfiBzcGFuJzoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUucHJpbWFyeS5leHRyYUxpZ2h0XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmIC5NdWlTdmdJY29uLXJvb3QnOiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJ3RyYW5zcGFyZW50JyxcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogYDFweCBzb2xpZCAke2NvbG9yLnBhbGV0dGUucHJpbWFyeS5leHRyYUxpZ2h0fWAsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udC5oNC5mb250U2l6ZSxcclxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzhweCcsXHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLmNvbW1vbi53aGl0ZVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJi5NdWktY2hlY2tlZCc6IHtcclxuICAgICAgICAgICAgICAgICcmIC5NdWlTdmdJY29uLXJvb3QnOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUuc3VjY2Vzcy5tYWluLFxyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50J1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJi5NdWlDaGVja2JveC1yb290IH4gc3Bhbic6IHtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmdUb3A6ICcwcHgnLFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBNdWlGb3JtQ29udHJvbExhYmVsOiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOiAnZmxleC1zdGFydCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGxhYmVsOiB7XHJcbiAgICAgICAgICAgIGZvbnRTaXplOiBmb250Lmg2LmZvbnRTaXplLFxyXG4gICAgICAgICAgICBjb2xvcjogY29sb3IucGFsZXR0ZS5wcmltYXJ5LmxpZ2h0LFxyXG4gICAgICAgICAgICBwYWRkaW5nVG9wOiAnNHB4JyxcclxuICAgICAgICAgICAgcGFkZGluZ0xlZnQ6JzRweCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgUHJpdmF0ZVN3aXRjaEJhc2U6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgIHBhZGRpbmdUb3A6IDBcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDaGVja0JveE92ZXJSaWRlO1xyXG4iLCJpbXBvcnQgY29sb3IgZnJvbSAnLi4vY29sb3InO1xyXG5pbXBvcnQgZm9udCBmcm9tICcuLi90eXBvZ3JhcGh5JztcclxuXHJcbmNvbnN0IERpYWxvZ092ZXJSaWRlID0ge1xyXG4gICAgTXVpRGlhbG9nOiB7XHJcbiAgICAgICAgcm9vdDoge30sXHJcbiAgICAgICAgcGFwZXI6IHtcclxuICAgICAgICAgICAgbWluV2lkdGg6ICczODNweCcsXHJcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzIxcHgnLFxyXG4gICAgICAgICAgICBib3hTaGFkb3c6ICcwcHggNHB4IDRweCByZ2JhKDAsIDAsIDAsIDAuMDgpJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY29udGFpbmVyOntcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOidyZ2JhKDg4LCA5MCwgMTIxLCAuNzApJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBNdWlEaWFsb2dUaXRsZToge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgJyYgLk11aUJ1dHRvbkJhc2Utcm9vdCc6IHtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxyXG4gICAgICAgICAgICAgICAgcmlnaHQ6ICcxMHB4JyxcclxuICAgICAgICAgICAgICAgIHRvcDogJzEwcHgnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmIC5NdWlTdmdJY29uLXJvb3QnOiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogY29sb3IucGFsZXR0ZS5wcmltYXJ5Lm1haW4sXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udC5oNHhsLmZvbnRTaXplXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBEaWFsb2dPdmVyUmlkZTtcclxuIiwiaW1wb3J0IGNvbG9yIGZyb20gJy4uL2NvbG9yJztcclxuaW1wb3J0IGZvbnQgZnJvbSAnLi4vdHlwb2dyYXBoeSc7XHJcblxyXG5jb25zdCBJbnB1dE92ZXJSaWRlID0ge1xyXG4gICAgTXVpRmlsbGVkSW5wdXQ6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgIGNvbG9yOiBjb2xvci5wYWxldHRlLnByaW1hcnkubGlnaHQsXHJcbiAgICAgICAgICAgIGJvcmRlcjogYDFweCBzb2xpZCAke2NvbG9yLnBhbGV0dGUucHJpbWFyeS5leHRyYUxpZ2h0fWAsXHJcbiAgICAgICAgICAgIGZvbnRTaXplOiBmb250Lmg2LmZvbnRTaXplLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcxNnB4JyxcclxuICAgICAgICAgICAgYm9yZGVyVG9wTGVmdFJhZGl1czogJzE2cHgnLFxyXG4gICAgICAgICAgICBib3JkZXJUb3BSaWdodFJhZGl1czogJzE2cHgnLFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLmNvbW1vbi53aGl0ZSxcclxuICAgICAgICAgICAgaGVpZ2h0OiAnNTJweCcsXHJcbiAgICAgICAgICAgICcmOmhvdmVyJzoge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5jb21tb24ud2hpdGVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgTXVpSW5wdXRMYWJlbDoge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6ICc5NSUnLFxyXG4gICAgICAgICAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxyXG4gICAgICAgICAgICAgICAgdGV4dE92ZXJmbG93OiAnZWxsaXBzaXMnLFxyXG4gICAgICAgICAgICAgICAgd2hpdGVTcGFjZTogJ25vd3JhcCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYgLk11aUlucHV0QWRvcm5tZW50LWZpbGxlZC5NdWlJbnB1dEFkb3JubWVudC1wb3NpdGlvblN0YXJ0Om5vdCguTXVpSW5wdXRBZG9ybm1lbnQtaGlkZGVuTGFiZWwpJzpcclxuICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IDBcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmIC5NdWlJY29uQnV0dG9uLXJvb3QnOiB7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAnMCA4cHggMCAwJyxcclxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiBmb250Lmg1eGwuZm9udFNpemVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYuTXVpLWVycm9yJzoge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5wYWxldHRlLmVycm9yLmV4dHJhTGlnaHQsXHJcbiAgICAgICAgICAgICAgICBib3JkZXJDb2xvcjogY29sb3IucGFsZXR0ZS5lcnJvci5tYWluXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmLk11aS1mb2N1c2VkJzoge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxyXG4gICAgICAgICAgICAgICAgYm94U2hhZG93OiAnbm9uZSAhaW1wb3J0YW50J1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBpbnB1dDoge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAnMjVweCAxNnB4IDVweCcsXHJcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czonMTZweCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGFkb3JuZWRFbmQ6IHtcclxuICAgICAgICAgICAgcGFkZGluZ1JpZ2h0OiAwXHJcbiAgICAgICAgfSxcclxuICAgICAgICB1bmRlcmxpbmU6IHtcclxuICAgICAgICAgICAgJyY6YmVmb3JlLCAmOmFmdGVyJzoge1xyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZSdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyY6aG92ZXInOiB7XHJcbiAgICAgICAgICAgICAgICAnJjpiZWZvcmUsICY6YWZ0ZXInOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZSdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbXVsdGlsaW5lOntcclxuICAgICAgICAgICAgaGVpZ2h0OicxMjBweCdcclxuICAgICAgICB9LFxyXG4gICAgfSxcclxuICAgIE11aUlucHV0TGFiZWw6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAnMTAwJScsXHJcbiAgICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcclxuICAgICAgICAgICAgdGV4dE92ZXJmbG93OiAnZWxsaXBzaXMnLFxyXG4gICAgICAgICAgICB3aGl0ZVNwYWNlOiAnbm93cmFwJyxcclxuICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUucHJpbWFyeS5leHRyYUxpZ2h0LFxyXG4gICAgICAgICAgICBmb250U2l6ZTogZm9udC5oNi5mb250U2l6ZSxcclxuICAgICAgICAgICAgJyYuTXVpLWVycm9yJzoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUucHJpbWFyeS5leHRyYUxpZ2h0XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmPmRpdic6e1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6ICcxMDAlJyxcclxuICAgICAgICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcclxuICAgICAgICAgICAgICAgIHRleHRPdmVyZmxvdzogJ2VsbGlwc2lzJyxcclxuICAgICAgICAgICAgICAgIHdoaXRlU3BhY2U6ICdub3dyYXAnLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBmaWxsZWQ6IHtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlKDE2cHgsIDE3cHgpIHNjYWxlKDEpJyxcclxuICAgICAgICAgICAgcGFkZGluZ1JpZ2h0Oic0NXB4JyxcclxuICAgICAgICAgICAgJyYuTXVpSW5wdXRMYWJlbC1zaHJpbmsnOiB7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06ICd0cmFuc2xhdGUoMTZweCwgMTBweCkgc2NhbGUoMC43NSknXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgTXVpVGV4dEZpZWxkOiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcwcHgnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIE11aUZvcm1Db250cm9sOiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206ICcyNHB4JyxcclxuICAgICAgICAgICAgJyYubm9NYXJnaW4nOiB7XHJcbiAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206ICc4cHgnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbnB1dE92ZXJSaWRlO1xyXG4iLCJpbXBvcnQgQWxlcnRPdmVyaWRlIGZyb20gJy4vQWxlcnRPdmVyaWRlJztcclxuaW1wb3J0IEJ1dHRvbk92ZXJpZGUgZnJvbSAnLi9CdXR0b25PdmVyaWRlJztcclxuaW1wb3J0IENhcmRPdmVyaWRlIGZyb20gJy4vQ2FyZE92ZXJpZGUnO1xyXG5pbXBvcnQgQ2hlY2tCb3hPdmVyaWRlIGZyb20gJy4vQ2hlY2tCb3hPdmVyaWRlJztcclxuaW1wb3J0IERpYWxvZ092ZXJpZGUgZnJvbSAnLi9EaWFsb2dPdmVyaWRlJztcclxuaW1wb3J0IElucHV0T3ZlcmlkZSBmcm9tICcuL0lucHV0T3ZlcmlkZSc7XHJcbmltcG9ydCBQcm9ncmVzc0Jhck92ZXJpZGUgZnJvbSAnLi9Qcm9ncmVzc0Jhck92ZXJpZGUnO1xyXG5pbXBvcnQgUmFkaW9PdmVyaWRlIGZyb20gJy4vUmFkaW9PdmVyaWRlJztcclxuaW1wb3J0IFNlbGVjdE92ZXJpZGUgZnJvbSAnLi9TZWxlY3RPdmVyaWRlJztcclxuaW1wb3J0IFN3aXRjaE92ZXJpZGUgZnJvbSAnLi9Td2l0Y2hPdmVyaWRlJztcclxuaW1wb3J0IFRhYk92ZXJpZGUgZnJvbSAnLi9UYWJPdmVyaWRlJztcclxuXHJcbmNvbnN0IE92ZXJpZGUgPSB7XHJcbiAgICBvdmVycmlkZXM6IHtcclxuICAgICAgICAuLi5CdXR0b25PdmVyaWRlLFxyXG4gICAgICAgIC4uLklucHV0T3ZlcmlkZSxcclxuICAgICAgICAuLi5SYWRpb092ZXJpZGUsXHJcbiAgICAgICAgLi4uQ2hlY2tCb3hPdmVyaWRlLFxyXG4gICAgICAgIC4uLlN3aXRjaE92ZXJpZGUsXHJcbiAgICAgICAgLi4uQ2FyZE92ZXJpZGUsXHJcbiAgICAgICAgLi4uU2VsZWN0T3ZlcmlkZSxcclxuICAgICAgICAuLi5EaWFsb2dPdmVyaWRlLFxyXG4gICAgICAgIC4uLlByb2dyZXNzQmFyT3ZlcmlkZSxcclxuICAgICAgICAuLi5BbGVydE92ZXJpZGUsXHJcbiAgICAgICAgLi4uVGFiT3ZlcmlkZVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgT3ZlcmlkZTtcclxuIiwiXHJcbmltcG9ydCBjb2xvciBmcm9tICcuLi9jb2xvcic7XHJcblxyXG5jb25zdCBQcm9ncmVzc0Jhck92ZXJpZGUgPSB7XHJcbiAgICBNdWlMaW5lYXJQcm9ncmVzczoge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgaGVpZ2h0OiAnMTJweCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNvbG9yUHJpbWFyeToge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLmNvbW1vbi53aGl0ZVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYmFyMURldGVybWluYXRlOiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3IucGFsZXR0ZS5zdWNjZXNzLm1haW5cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IFByb2dyZXNzQmFyT3ZlcmlkZTtcclxuIiwiaW1wb3J0IGNvbG9yIGZyb20gJy4uL2NvbG9yJztcclxuaW1wb3J0IGZvbnQgZnJvbSAnLi4vdHlwb2dyYXBoeSc7XHJcblxyXG5jb25zdCBSYWRpb092ZXJSaWRlID0ge1xyXG4gICAgTXVpUmFkaW86IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICcmLmV4dHJhTGlnaHRMYWJlbCB+IHNwYW4nOiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogY29sb3IucGFsZXR0ZS5wcmltYXJ5LmV4dHJhTGlnaHRcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYuc2l6ZTI0Jzp7XHJcbiAgICAgICAgICAgICAgICAnJiAuTXVpU3ZnSWNvbi1yb290Jzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBmb250Lmg0LmZvbnRTaXplLFxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIFwiJn4uTXVpRm9ybUNvbnRyb2xMYWJlbC1sYWJlbFwiOntcclxuICAgICAgICAgICAgICAgICAgICBwYWRkaW5nVG9wOjBcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYgLk11aVN2Z0ljb24tcm9vdCc6IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAndHJhbnNwYXJlbnQnLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7Y29sb3IucGFsZXR0ZS5wcmltYXJ5LmV4dHJhTGlnaHR9YCxcclxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiBmb250LmgzeGwuZm9udFNpemUsXHJcbiAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc1MCUnLFxyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5jb21tb24ud2hpdGVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYuTXVpLWNoZWNrZWQnOiB7XHJcbiAgICAgICAgICAgICAgICAnJiAuTXVpU3ZnSWNvbi1yb290Jzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvci5wYWxldHRlLnNlY29uZGFyeS5kYXJrXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBSYWRpb092ZXJSaWRlO1xyXG4iLCJpbXBvcnQgY29sb3IgZnJvbSAnLi4vY29sb3InO1xyXG5cclxuY29uc3QgU2VsZWN0T3ZlcmlkZSA9IHtcclxuICAgIE11aVNlbGVjdDoge1xyXG4gICAgICAgIGljb246IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogY29sb3IucGFsZXR0ZS5tZW51cy5tZW51QmFja2dyb3VuZCxcclxuICAgICAgICAgICAgaGVpZ2h0OiAnNTBweCcsXHJcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzAgMTZweCAxNnB4IDAnLFxyXG4gICAgICAgICAgICBtaW5XaWR0aDogJzQ0cHgnLFxyXG4gICAgICAgICAgICB0b3A6ICcwcHgnLFxyXG4gICAgICAgICAgICBjb2xvcjogJ3RyYW5zcGFyZW50J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaWNvbkZpbGxlZDoge1xyXG4gICAgICAgICAgICByaWdodDogMFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc2VsZWN0OiB7XHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxyXG4gICAgICAgICAgICAnJjpiZWZvcmUnOiB7XHJcbiAgICAgICAgICAgICAgICBjb250ZW50OiAnXCJcXFxcZTkwMlwiJyxcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxyXG4gICAgICAgICAgICAgICAgcmlnaHQ6ICcxMnB4JyxcclxuICAgICAgICAgICAgICAgIHpJbmRleDogJzknLFxyXG4gICAgICAgICAgICAgICAgZm9udEZhbWlseTogJ2ljb21vb24gIWltcG9ydGFudCcsXHJcbiAgICAgICAgICAgICAgICB0b3A6ICcxN3B4JyxcclxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiAnMjBweCdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyY6Zm9jdXMnOiB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBNdWlQb3BvdmVyOiB7XHJcbiAgICAgICAgcGFwZXI6IHtcclxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTZweCdcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBTZWxlY3RPdmVyaWRlO1xyXG4iLCJpbXBvcnQgY29sb3IgZnJvbSAnLi4vY29sb3InO1xyXG5cclxuY29uc3QgU3dpdGNoT3ZlclJpZGUgPSB7XHJcbiAgICBNdWlTd2l0Y2g6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAnNjBweCcsXHJcbiAgICAgICAgICAgIGhlaWdodDogJzM2cHgnLFxyXG4gICAgICAgICAgICBwYWRkaW5nOiAnMHB4J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdGh1bWI6IHtcclxuICAgICAgICAgICAgd2lkdGg6ICczNnB4JyxcclxuICAgICAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7Y29sb3IucGFsZXR0ZS5wcmltYXJ5LmxpZ2h0fWAsXHJcbiAgICAgICAgICAgIGhlaWdodDogJzM2cHgnLFxyXG4gICAgICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcclxuICAgICAgICAgICAgYm94U2hhZG93OiAnbm9uZScsXHJcbiAgICAgICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLmNvbW1vbi53aGl0ZSxcclxuICAgICAgICAgICAgJyY6YWZ0ZXInOiB7XHJcbiAgICAgICAgICAgICAgICBjb250ZW50OiAnXCJcIicsXHJcbiAgICAgICAgICAgICAgICB3aWR0aDogJzE2cHgnLFxyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAnMTZweCcsXHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IGAxcHggc29saWQgJHtjb2xvci5wYWxldHRlLnByaW1hcnkubGlnaHR9YCxcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiAnYWJzb2x1dGUnLFxyXG4gICAgICAgICAgICAgICAgbGVmdDogJzUwJScsXHJcbiAgICAgICAgICAgICAgICB0b3A6ICc1MCUnLFxyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlKC01MCUsIC01MCUpJyxcclxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogNTBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3dpdGNoQmFzZToge1xyXG4gICAgICAgICAgICBwYWRkaW5nOiAwLFxyXG4gICAgICAgICAgICBtYXJnaW46IDAsXHJcbiAgICAgICAgICAgIHRyYW5zaXRpb25EdXJhdGlvbjogJzMwMG1zJyxcclxuICAgICAgICAgICAgJyYuTXVpLWNoZWNrZWQnOiB7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06ICd0cmFuc2xhdGVYKDI0cHgpJyxcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvci5jb21tb24ud2hpdGUsXHJcbiAgICAgICAgICAgICAgICAnJiArIC5NdWlTd2l0Y2gtdHJhY2snOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBgJHtjb2xvci5wYWxldHRlLnNlY29uZGFyeS5kYXJrfSAhaW1wb3J0YW50YCxcclxuICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAxXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgJyYuTXVpLWRpc2FibGVkICsgLk11aVN3aXRjaC10cmFjayc6IHtcclxuICAgICAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjVcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdHJhY2s6IHtcclxuICAgICAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7Y29sb3IucGFsZXR0ZS5wcmltYXJ5LmxpZ2h0fWAsXHJcbiAgICAgICAgICAgIG9wYWNpdHk6ICcxJyxcclxuICAgICAgICAgICAgdHJhbnNpdGlvbjogJ2JhY2tncm91bmQtY29sb3IgNTAwbXMgY3ViaWMtYmV6aWVyKDAuNCwgMCwgMC4yLCAxKSAwbXMnLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc1MHB4JyxcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5jb21tb24uZ3JheVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufTtcclxuZXhwb3J0IGRlZmF1bHQgU3dpdGNoT3ZlclJpZGU7XHJcbiIsImltcG9ydCBjb2xvciBmcm9tICcuLi9jb2xvcic7XHJcblxyXG5jb25zdCBUYWJPdmVyaWRlID0ge1xyXG4gICAgTXVpVGFiczoge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgbWluV2lkdGg6ICc0MDBweCcsXHJcblxyXG4gICAgICAgICAgICAnJi50ZXh0Q29sb3JJbmhlcml0Jzoge1xyXG4gICAgICAgICAgICAgICAgb3BhY2l0eTogJ3Vuc2V0JyxcclxuICAgICAgICAgICAgICAgIG1pbldpZHRoOiAnNDAwcHgnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGVuZEljb246IHtcclxuICAgICAgICAgICAgbWFyZ2luTGVmdDogJzRweCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHZlcnRpY2FsOiB7XHJcbiAgICAgICAgICAgIG1hcmdpblRvcDogJzE5MHB4J1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBNdWlUYWI6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgIG9wYWNpdHk6ICd1bnNldCAhaW1wb3J0YW50JyxcclxuICAgICAgICAgICAgbWluV2lkdGg6ICc0MDBweCAhaW1wb3J0YW50JyxcclxuICAgICAgICAgICAgdGV4dFRyYW5zZm9ybTogJ25vbmUnLFxyXG4gICAgICAgICAgICBtYXJnaW46ICcxNXB4IDAnLFxyXG4gICAgICAgICAgICAnJi5NdWktc2VsZWN0ZWQnOiB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLnBhbGV0dGUuc2Vjb25kYXJ5Lm1haW4sXHJcbiAgICAgICAgICAgICAgICBib3JkZXJUb3BMZWZ0UmFkaXVzOiAnMjFweCcsXHJcbiAgICAgICAgICAgICAgICBib3JkZXJCb3R0b21MZWZ0UmFkaXVzOiAnMjFweCcsXHJcbiAgICAgICAgICAgICAgICBtaW5IZWlnaHQ6ICc1M3B4JyxcclxuICAgICAgICAgICAgICAgICcmIC5hcnJvdyBzdmcnOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheTogJ25vbmUnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHdyYXBwZXI6IHtcclxuICAgICAgICAgICAgZmxleERpcmVjdGlvbjogJ2luaXRpYWwnLFxyXG4gICAgICAgICAgICBqdXN0aWZ5Q29udGVudDogJ2VuZCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgUHJpdmF0ZVRhYkluZGljYXRvcjoge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ25vbmUnXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgVGFiT3ZlcmlkZTtcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vT3ZlcmlkZSc7XHJcbiIsImV4cG9ydCBkZWZhdWx0IHtcclxuICAgIHVzZU5leHRWYXJpYW50czogdHJ1ZSxcclxuICAgIGZvbnRTaXplOiAxNixcclxuXHJcbiAgICBoMToge1xyXG4gICAgICAgIGZvbnRTaXplOiA0NFxyXG4gICAgfSxcclxuICAgIGgyOiB7XHJcbiAgICAgICAgZm9udFNpemU6IDM2XHJcbiAgICB9LFxyXG4gICAgaDN4bDoge1xyXG4gICAgICAgIGZvbnRTaXplOiAzMlxyXG4gICAgfSxcclxuICAgIGgzOiB7XHJcbiAgICAgICAgZm9udFNpemU6IDI3XHJcbiAgICB9LFxyXG4gICAgaDR4bDoge1xyXG4gICAgICAgIGZvbnRTaXplOiAyNVxyXG4gICAgfSxcclxuICAgIGg0OiB7XHJcbiAgICAgICAgZm9udFNpemU6IDI0XHJcbiAgICB9LFxyXG4gICAgaDV4bDoge1xyXG4gICAgICAgIGZvbnRTaXplOiAyMlxyXG4gICAgfSxcclxuICAgIGg1OiB7XHJcbiAgICAgICAgZm9udFNpemU6IDIxXHJcbiAgICB9LFxyXG4gICAgaDY6IHtcclxuICAgICAgICBmb250U2l6ZTogMTdcclxuICAgIH0sXHJcbiAgICBsZzoge1xyXG4gICAgICAgIGZvbnRTaXplOiAxNVxyXG4gICAgfSxcclxuICAgIG1keGw6IHtcclxuICAgICAgICBmb250U2l6ZTogMTRcclxuICAgIH0sXHJcbiAgICBtZDoge1xyXG4gICAgICAgIGZvbnRTaXplOiAxM1xyXG4gICAgfSxcclxuICAgIHNtOiB7XHJcbiAgICAgICAgZm9udFNpemU6IDEyXHJcbiAgICB9LFxyXG4gICAgeHM6IHtcclxuICAgICAgICBmb250U2l6ZTogMTFcclxuICAgIH0sXHJcblxyXG4gICAgZm9udEZhbWlseToge1xyXG4gICAgICAgIHJlZ3VsYXI6ICdQb3BwaW5zLVJlZ3VsYXInLFxyXG4gICAgICAgIG1lZGl1bTogJ1BvcHBpbnMtTWVkaXVtJyxcclxuICAgICAgICBzZW1pQm9sZDogJ1BvcHBpbnMtU2VtaUJvbGQnLFxyXG4gICAgICAgIGJvbGQ6ICdQb3BwaW5zLUJvbGQnLFxyXG4gICAgICAgIGV4dHJhQm9sZDogJ1BvcHBpbnMtZXh0cmFCb2xkJ1xyXG4gICAgfSxcclxuICAgIHRleHRUcmFuc2Zvcm06IHtcclxuICAgICAgICB1cHBlckNhc2U6ICd1cHBlcmNhc2UnXHJcbiAgICB9XHJcbn07XHJcbiIsImNvbnN0IENvbG9yT3ZlUmlkZSA9IHtcclxuICAgIGNvbW1vbjoge1xyXG4gICAgICAgIHdoaXRlOiAnI2ZmZicsXHJcbiAgICAgICAgYmxhY2s6ICcjMDAwJyxcclxuICAgICAgICBncmF5OiAnI0Y1RjVGOScsXHJcbiAgICAgICAgZmFjZWJvb2tCbHVlOiAnIzNCNTk5OCcsXHJcbiAgICAgICAgbGlnaHRCbHVlOiAnIzgyNmZhYycsXHJcbiAgICAgICAgZ3JheVRleHQ6ICcjN0M3Qzk1JyxcclxuICAgICAgICBkZWZhdWx0QmdDb2xvcjogJyNDNEM0QzQnLFxyXG4gICAgICAgIHNlY29uZGFyeUJnQ29sb3I6ICcjRDlFRUZGJyxcclxuICAgICAgICBsaWdodEJsYWNrOiAnIzE4MTkxRidcclxuICAgIH0sXHJcblxyXG4gICAgcGFsZXR0ZToge1xyXG4gICAgICAgIHByaW1hcnk6IHtcclxuICAgICAgICAgICAgbWFpbjogJyMyRjBCN0MnLFxyXG4gICAgICAgICAgICBsaWdodDogJyMyNjI4NEUnLFxyXG4gICAgICAgICAgICBleHRyYUxpZ2h0OiAnIzU4NUE3OSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHNlY29uZGFyeToge1xyXG4gICAgICAgICAgICBkYXJrOiAnIzI3Q0NBNScsXHJcbiAgICAgICAgICAgIG1haW46ICcjNUVFQUNGJyxcclxuICAgICAgICAgICAgbGlnaHQ6ICcjRDBGRkY2JyxcclxuICAgICAgICAgICAgZXh0cmFMaWdodDogJyNGNUY1RjknXHJcbiAgICAgICAgfSxcclxuICAgICAgICBlcnJvcjoge1xyXG4gICAgICAgICAgICBkYXJrOiAnI0NDMjgxMScsXHJcbiAgICAgICAgICAgIG1haW46ICcjRkY0NzRFJyxcclxuICAgICAgICAgICAgbGlnaHQ6ICcjRkY4MDg0JyxcclxuICAgICAgICAgICAgZXh0cmFMaWdodDogJyNGRkRCREMnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBwZW5kaW5nOiB7XHJcbiAgICAgICAgICAgIG1haW46ICcjRkVDRDRGJyxcclxuICAgICAgICAgICAgbGlnaHQ6ICcjRkZEQzgzJyxcclxuICAgICAgICAgICAgZXh0cmFMaWdodDogJyNGRkYxQ0UnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzdWNjZXNzOiB7XHJcbiAgICAgICAgICAgIG1haW46ICcjMjdDQ0E1JyxcclxuICAgICAgICAgICAgbGlnaHQ6ICcjNUVFQUNGJyxcclxuICAgICAgICAgICAgZXh0cmFMaWdodDogJyNEMEZGRjYnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBpbmZvOiB7XHJcbiAgICAgICAgICAgIG1haW46ICcjOTc5N0JGJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZGVmYXVsdDoge1xyXG4gICAgICAgICAgICBtYWluOiAnIzg0OEZFRSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJ1dHRvbjoge1xyXG4gICAgICAgICAgICBzZWNvbmRhcnlDb2xvcjogJyMyNzAyNzYnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBtZW51czoge1xyXG4gICAgICAgICAgICBtZW51QmFja2dyb3VuZDogJyNEOUVFRkYnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBkYXNoYm9hcmRCZzoge1xyXG4gICAgICAgICAgICBtYWluOiAnIzU3NTc1NydcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBDb2xvck92ZVJpZGU7XHJcbiIsImltcG9ydCB7IGNyZWF0ZVN0eWxlcywgbWFrZVN0eWxlcyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PlxyXG4gICAgY3JlYXRlU3R5bGVzKHtcclxuICAgICAgICAnQGdsb2JhbCc6IHtcclxuICAgICAgICAgICAgJyonOiB7XHJcbiAgICAgICAgICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcclxuICAgICAgICAgICAgICAgIG1hcmdpbjogMCxcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDBcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaHRtbDoge1xyXG4gICAgICAgICAgICAgICAgJy13ZWJraXQtZm9udC1zbW9vdGhpbmcnOiAnYW50aWFsaWFzZWQnLFxyXG4gICAgICAgICAgICAgICAgJy1tb3otb3N4LWZvbnQtc21vb3RoaW5nJzogJ2dyYXlzY2FsZScsXHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6ICcxMDAlJyxcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAnMTAwJSdcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgYm9keToge1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OiAnMTAwJScsXHJcbiAgICAgICAgICAgICAgICB3aWR0aDogJzEwMCUnLFxyXG4gICAgICAgICAgICAgICAgZm9udEZhbWlseTogdGhlbWUudHlwb2dyYXBoeS5mb250RmFtaWx5LnJlZ3VsYXIsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogdGhlbWUudHlwb2dyYXBoeS5mb250U2l6ZS5zbSxcclxuICAgICAgICAgICAgICAgIHdvcmRCcmVhazogJ2JyZWFrLXdvcmQnLFxyXG4gICAgICAgICAgICAgICAgbGluZUhlaWdodDonMS41JyxcclxuICAgICAgICAgICAgICAgICcmICsgZGl2Jzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGhlaWdodDogJzEwMCUnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGltZzoge1xyXG4gICAgICAgICAgICAgICAgbWF4V2lkdGg6ICcxMDAlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBhOiB7XHJcbiAgICAgICAgICAgICAgICB0ZXh0RGVjb3JhdGlvbjogJ25vbmUnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcjcm9vdCc6IHtcclxuICAgICAgICAgICAgICAgIGhlaWdodDogJzEwMCUnLFxyXG4gICAgICAgICAgICAgICAgd2lkdGg6ICcxMDAlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnLnRleHRUcmFuc2Zvcm0nOiB7XHJcbiAgICAgICAgICAgICAgICB0ZXh0VHJhbnNmb3JtOiAndXBwZXJDYXNlJ1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnLk11aURpYWxvZy1wYXBlcic6IHtcclxuICAgICAgICAgICAgICAgICdAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjYwMHB4KSc6IHtcclxuICAgICAgICAgICAgICAgICAgICBtaW5XaWR0aDogJzMyN3B4JyxcclxuICAgICAgICAgICAgICAgICAgICBtYXhXaWR0aDogJzMyN3B4J1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICdAbWVkaWEgc2NyZWVuIGFuZCAobWF4LXdpZHRoOjM1MHB4KSc6IHtcclxuICAgICAgICAgICAgICAgICAgICBtaW5XaWR0aDogJzI3MHB4JyxcclxuICAgICAgICAgICAgICAgICAgICBtYXhXaWR0aDogJzI3MHB4J1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnLm5vUGFkZGluZyc6IHtcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6IDBcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJy53aXRob3V0TGFiZWwnOntcclxuICAgICAgICAgICAgICAgICcmIC5NdWlGaWxsZWRJbnB1dC1pbnB1dCc6ICB7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogJzVweCAxNnB4J1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICcmIC5NdWlTZWxlY3Qtc2VsZWN0Jzoge1xyXG4gICAgICAgICAgICAgICAgICAgICcmOmJlZm9yZSc6IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgdG9wOiAnNHB4J1xyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaW5wdXQ6IHtcclxuICAgICAgICAgICAgJyY6LXdlYmtpdC1hdXRvZmlsbCc6IHtcclxuICAgICAgICAgICAgICAgIFdlYmtpdEJveFNoYWRvdzogJzAgMCAwIDEwMDBweCB3aGl0ZSBpbnNldCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH0pXHJcbik7XHJcblxyXG5jb25zdCBHbG9iYWxTdHlsZXMgPSAoKSA9PiB7XHJcbiAgICB1c2VTdHlsZXMoKTtcclxuICAgIHJldHVybiBudWxsO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgR2xvYmFsU3R5bGVzO1xyXG4iLCJpbXBvcnQgeyBjcmVhdGVUaGVtZSB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XHJcbmltcG9ydCBicmVha3BvaW50cyBmcm9tICcuL2JyZWFrcG9pbnRzJztcclxuaW1wb3J0IGNvbG9yIGZyb20gJy4vY29sb3InO1xyXG5pbXBvcnQgT3ZlclJpZGVDc3MgZnJvbSAnLi9PdmVyaWRlJztcclxuaW1wb3J0IHR5cG9ncmFwaHkgZnJvbSAnLi90eXBvZ3JhcGh5JztcclxuXHJcbi8vIENyZWF0ZSBhIHRoZW1lIGluc3RhbmNlLlxyXG5jb25zdCB0aGVtZSA9IGNyZWF0ZVRoZW1lKHtcclxuICAgIHByb3BzOiB7XHJcbiAgICAgICAgLy8gd2l0aFdpZHRoIGNvbXBvbmVudCDimpvvuI9cclxuICAgICAgICBNdWlXaXRoV2lkdGg6IHtcclxuICAgICAgICAgICAgLy8gSW5pdGlhbCB3aWR0aCBwcm9wZXJ0eVxyXG4gICAgICAgICAgICBpbml0aWFsV2lkdGg6ICdsZycgLy8gQnJlYWtwb2ludCBiZWluZyBnbG9iYWxseSBzZXQg8J+MjiFcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdHlwb2dyYXBoeSxcclxuICAgIC4uLmJyZWFrcG9pbnRzLFxyXG4gICAgLi4uY29sb3IsXHJcbiAgICAuLi5PdmVyUmlkZUNzc1xyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHRoZW1lO1xyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAZGF0ZS1pby9kYXRlLWZuc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9Dc3NCYXNlbGluZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL3BpY2tlcnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibG9kYXNoXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvaGVhZFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJwcm9wLXR5cGVzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXJlZHV4XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0LXRvYXN0LW5vdGlmaWNhdGlvbnNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZHV4XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZHV4LWRldnRvb2xzLWV4dGVuc2lvblwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eC1wZXJzaXN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlZHV4LXBlcnNpc3QvaW50ZWdyYXRpb24vcmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVkdXgtcGVyc2lzdC9saWIvc3RvcmFnZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWR1eC10aHVua1wiKTsiXSwic291cmNlUm9vdCI6IiJ9