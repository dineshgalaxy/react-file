module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 1);
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/constants":
/*!*********************************************************!*\
  !*** external "next/dist/next-server/lib/constants.js" ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/constants.js");

/***/ }),

/***/ "../next-server/lib/document-context":
/*!****************************************************************!*\
  !*** external "next/dist/next-server/lib/document-context.js" ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/document-context.js");

/***/ }),

/***/ "../next-server/lib/utils":
/*!*****************************************************!*\
  !*** external "next/dist/next-server/lib/utils.js" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/utils.js");

/***/ }),

/***/ "../next-server/server/get-page-files":
/*!*****************************************************************!*\
  !*** external "next/dist/next-server/server/get-page-files.js" ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/get-page-files.js");

/***/ }),

/***/ "../next-server/server/utils":
/*!********************************************************!*\
  !*** external "next/dist/next-server/server/utils.js" ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/utils.js");

/***/ }),

/***/ "./node_modules/next/dist/pages/_document.js":
/*!***************************************************!*\
  !*** ./node_modules/next/dist/pages/_document.js ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

exports.__esModule = true;
exports.Html = Html;
exports.Main = Main;
exports.NextScript = exports.Head = exports.default = void 0;

var _propTypes = _interopRequireDefault(__webpack_require__(/*! prop-types */ "prop-types"));

var _react = _interopRequireWildcard(__webpack_require__(/*! react */ "react"));

var _server = _interopRequireDefault(__webpack_require__(/*! styled-jsx/server */ "styled-jsx/server"));

var _constants = __webpack_require__(/*! ../next-server/lib/constants */ "../next-server/lib/constants");

var _documentContext = __webpack_require__(/*! ../next-server/lib/document-context */ "../next-server/lib/document-context");

var _utils = __webpack_require__(/*! ../next-server/lib/utils */ "../next-server/lib/utils");

exports.DocumentContext = _utils.DocumentContext;
exports.DocumentInitialProps = _utils.DocumentInitialProps;
exports.DocumentProps = _utils.DocumentProps;

var _getPageFiles = __webpack_require__(/*! ../next-server/server/get-page-files */ "../next-server/server/get-page-files");

var _utils2 = __webpack_require__(/*! ../next-server/server/utils */ "../next-server/server/utils");

var _htmlescape = __webpack_require__(/*! ../server/htmlescape */ "./node_modules/next/dist/server/htmlescape.js");

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    default: obj
  };
}

function _getRequireWildcardCache() {
  if (typeof WeakMap !== "function") return null;
  var cache = new WeakMap();

  _getRequireWildcardCache = function () {
    return cache;
  };

  return cache;
}

function _interopRequireWildcard(obj) {
  if (obj && obj.__esModule) {
    return obj;
  }

  if (obj === null || typeof obj !== "object" && typeof obj !== "function") {
    return {
      default: obj
    };
  }

  var cache = _getRequireWildcardCache();

  if (cache && cache.has(obj)) {
    return cache.get(obj);
  }

  var newObj = {};
  var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor;

  for (var key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null;

      if (desc && (desc.get || desc.set)) {
        Object.defineProperty(newObj, key, desc);
      } else {
        newObj[key] = obj[key];
      }
    }
  }

  newObj.default = obj;

  if (cache) {
    cache.set(obj, newObj);
  }

  return newObj;
}

function dedupe(bundles) {
  const files = new Set();
  const kept = [];

  for (const bundle of bundles) {
    if (files.has(bundle.file)) continue;
    files.add(bundle.file);
    kept.push(bundle);
  }

  return kept;
}

function getDocumentFiles(buildManifest, pathname, inAmpMode) {
  const sharedFiles = (0, _getPageFiles.getPageFiles)(buildManifest, '/_app');
  const pageFiles = inAmpMode ? [] : (0, _getPageFiles.getPageFiles)(buildManifest, pathname);
  return {
    sharedFiles,
    pageFiles,
    allFiles: [...new Set([...sharedFiles, ...pageFiles])]
  };
}
/**
* `Document` component handles the initial `document` markup and renders only on the server side.
* Commonly used for implementing server side rendering for `css-in-js` libraries.
*/


class Document extends _react.Component {
  /**
  * `getInitialProps` hook returns the context object with the addition of `renderPage`.
  * `renderPage` callback executes `React` rendering logic synchronously to support server-rendering wrappers
  */
  static async getInitialProps(ctx) {
    const enhanceApp = App => {
      return props => /*#__PURE__*/_react.default.createElement(App, props);
    };

    const {
      html,
      head
    } = await ctx.renderPage({
      enhanceApp
    });
    const styles = [...(0, _server.default)()];
    return {
      html,
      head,
      styles
    };
  }

  static renderDocument(DocumentComponent, props) {
    return /*#__PURE__*/_react.default.createElement(_documentContext.DocumentContext.Provider, {
      value: props
    }, /*#__PURE__*/_react.default.createElement(DocumentComponent, props));
  }

  render() {
    return /*#__PURE__*/_react.default.createElement(Html, null, /*#__PURE__*/_react.default.createElement(Head, null), /*#__PURE__*/_react.default.createElement("body", null, /*#__PURE__*/_react.default.createElement(Main, null), /*#__PURE__*/_react.default.createElement(NextScript, null)));
  }

}

exports.default = Document;
Document.headTagsMiddleware =  false ? undefined : () => [];

function Html(props) {
  const {
    inAmpMode,
    docComponentsRendered,
    locale
  } = (0, _react.useContext)(_documentContext.DocumentContext);
  docComponentsRendered.Html = true;
  return /*#__PURE__*/_react.default.createElement("html", Object.assign({}, props, {
    lang: props.lang || locale || undefined,
    amp: inAmpMode ? '' : undefined,
    "data-ampdevmode": inAmpMode && true ? '' : undefined
  }));
}

class Head extends _react.Component {
  constructor(...args) {
    super(...args);
    this.context = void 0;
  }

  getCssLinks(files) {
    const {
      assetPrefix,
      devOnlyCacheBusterQueryString,
      dynamicImports
    } = this.context;
    const cssFiles = files.allFiles.filter(f => f.endsWith('.css'));
    const sharedFiles = new Set(files.sharedFiles); // Unmanaged files are CSS files that will be handled directly by the
    // webpack runtime (`mini-css-extract-plugin`).

    let unmangedFiles = new Set([]);
    let dynamicCssFiles = dedupe(dynamicImports.filter(f => f.file.endsWith('.css'))).map(f => f.file);

    if (dynamicCssFiles.length) {
      const existing = new Set(cssFiles);
      dynamicCssFiles = dynamicCssFiles.filter(f => !(existing.has(f) || sharedFiles.has(f)));
      unmangedFiles = new Set(dynamicCssFiles);
      cssFiles.push(...dynamicCssFiles);
    }

    let cssLinkElements = [];
    cssFiles.forEach(file => {
      const isSharedFile = sharedFiles.has(file);

      if (true) {
        cssLinkElements.push( /*#__PURE__*/_react.default.createElement("link", {
          key: `${file}-preload`,
          nonce: this.props.nonce,
          rel: "preload",
          href: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
          as: "style",
          crossOrigin: this.props.crossOrigin || undefined
        }));
      }

      const isUnmanagedFile = unmangedFiles.has(file);
      cssLinkElements.push( /*#__PURE__*/_react.default.createElement("link", {
        key: file,
        nonce: this.props.nonce,
        rel: "stylesheet",
        href: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
        crossOrigin: this.props.crossOrigin || undefined,
        "data-n-g": isUnmanagedFile ? undefined : isSharedFile ? '' : undefined,
        "data-n-p": isUnmanagedFile ? undefined : isSharedFile ? undefined : ''
      }));
    });

    if (false) {}

    return cssLinkElements.length === 0 ? null : cssLinkElements;
  }

  getPreloadDynamicChunks() {
    const {
      dynamicImports,
      assetPrefix,
      devOnlyCacheBusterQueryString
    } = this.context;
    return dedupe(dynamicImports).map(bundle => {
      if (!bundle.file.endsWith('.js')) {
        return null;
      }

      return /*#__PURE__*/_react.default.createElement("link", {
        rel: "preload",
        key: bundle.file,
        href: `${assetPrefix}/_next/${encodeURI(bundle.file)}${devOnlyCacheBusterQueryString}`,
        as: "script",
        nonce: this.props.nonce,
        crossOrigin: this.props.crossOrigin || undefined
      });
    }) // Filter out nulled scripts
    .filter(Boolean);
  }

  getPreloadMainLinks(files) {
    const {
      assetPrefix,
      devOnlyCacheBusterQueryString,
      scriptLoader
    } = this.context;
    const preloadFiles = files.allFiles.filter(file => {
      return file.endsWith('.js');
    });
    return [...(scriptLoader.eager || []).map(file => /*#__PURE__*/_react.default.createElement("link", {
      key: file.src,
      nonce: this.props.nonce,
      rel: "preload",
      href: file.src,
      as: "script",
      crossOrigin: this.props.crossOrigin || undefined
    })), ...preloadFiles.map(file => /*#__PURE__*/_react.default.createElement("link", {
      key: file,
      nonce: this.props.nonce,
      rel: "preload",
      href: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
      as: "script",
      crossOrigin: this.props.crossOrigin || undefined
    })), ...(scriptLoader.defer || []).map(file => /*#__PURE__*/_react.default.createElement("link", {
      key: file,
      nonce: this.props.nonce,
      rel: "preload",
      href: file,
      as: "script",
      crossOrigin: this.props.crossOrigin || undefined
    }))];
  }

  makeStylesheetInert(node) {
    return _react.default.Children.map(node, c => {
      if (c.type === 'link' && c.props['href'] && _constants.OPTIMIZED_FONT_PROVIDERS.some(url => c.props['href'].startsWith(url))) {
        const newProps = _objectSpread({}, c.props || {});

        newProps['data-href'] = newProps['href'];
        newProps['href'] = undefined;
        return /*#__PURE__*/_react.default.cloneElement(c, newProps);
      } else if (c.props && c.props['children']) {
        c.props['children'] = this.makeStylesheetInert(c.props['children']);
      }

      return c;
    });
  }

  render() {
    var _this$props$nonce, _this$props$nonce2;

    const {
      styles,
      ampPath,
      inAmpMode,
      hybridAmp,
      canonicalBase,
      __NEXT_DATA__,
      dangerousAsPath,
      headTags,
      unstable_runtimeJS,
      unstable_JsPreload
    } = this.context;
    const disableRuntimeJS = unstable_runtimeJS === false;
    const disableJsPreload = unstable_JsPreload === false;
    this.context.docComponentsRendered.Head = true;
    let {
      head
    } = this.context;
    let cssPreloads = [];
    let otherHeadElements = [];

    if (head) {
      head.forEach(c => {
        if (c && c.type === 'link' && c.props['rel'] === 'preload' && c.props['as'] === 'style') {
          cssPreloads.push(c);
        } else {
          c && otherHeadElements.push(c);
        }
      });
      head = cssPreloads.concat(otherHeadElements);
    }

    let children = this.props.children; // show a warning if Head contains <title> (only in development)

    if (true) {
      children = _react.default.Children.map(children, child => {
        var _child$props;

        const isReactHelmet = child == null ? void 0 : (_child$props = child.props) == null ? void 0 : _child$props['data-react-helmet'];

        if (!isReactHelmet) {
          var _child$props2;

          if ((child == null ? void 0 : child.type) === 'title') {
            console.warn("Warning: <title> should not be used in _document.js's <Head>. https://err.sh/next.js/no-document-title");
          } else if ((child == null ? void 0 : child.type) === 'meta' && (child == null ? void 0 : (_child$props2 = child.props) == null ? void 0 : _child$props2.name) === 'viewport') {
            console.warn("Warning: viewport meta tags should not be used in _document.js's <Head>. https://err.sh/next.js/no-document-viewport-meta");
          }
        }

        return child;
      });
      if (this.props.crossOrigin) console.warn('Warning: `Head` attribute `crossOrigin` is deprecated. https://err.sh/next.js/doc-crossorigin-deprecated');
    }

    if (false) {}

    let hasAmphtmlRel = false;
    let hasCanonicalRel = false; // show warning and remove conflicting amp head tags

    head = _react.default.Children.map(head || [], child => {
      if (!child) return child;
      const {
        type,
        props
      } = child;

      if (inAmpMode) {
        let badProp = '';

        if (type === 'meta' && props.name === 'viewport') {
          badProp = 'name="viewport"';
        } else if (type === 'link' && props.rel === 'canonical') {
          hasCanonicalRel = true;
        } else if (type === 'script') {
          // only block if
          // 1. it has a src and isn't pointing to ampproject's CDN
          // 2. it is using dangerouslySetInnerHTML without a type or
          // a type of text/javascript
          if (props.src && props.src.indexOf('ampproject') < -1 || props.dangerouslySetInnerHTML && (!props.type || props.type === 'text/javascript')) {
            badProp = '<script';
            Object.keys(props).forEach(prop => {
              badProp += ` ${prop}="${props[prop]}"`;
            });
            badProp += '/>';
          }
        }

        if (badProp) {
          console.warn(`Found conflicting amp tag "${child.type}" with conflicting prop ${badProp} in ${__NEXT_DATA__.page}. https://err.sh/next.js/conflicting-amp-tag`);
          return null;
        }
      } else {
        // non-amp mode
        if (type === 'link' && props.rel === 'amphtml') {
          hasAmphtmlRel = true;
        }
      }

      return child;
    }); // try to parse styles from fragment for backwards compat

    const curStyles = Array.isArray(styles) ? styles : [];

    if (inAmpMode && styles && // @ts-ignore Property 'props' does not exist on type ReactElement
    styles.props && // @ts-ignore Property 'props' does not exist on type ReactElement
    Array.isArray(styles.props.children)) {
      const hasStyles = el => {
        var _el$props, _el$props$dangerously;

        return el == null ? void 0 : (_el$props = el.props) == null ? void 0 : (_el$props$dangerously = _el$props.dangerouslySetInnerHTML) == null ? void 0 : _el$props$dangerously.__html;
      }; // @ts-ignore Property 'props' does not exist on type ReactElement


      styles.props.children.forEach(child => {
        if (Array.isArray(child)) {
          child.forEach(el => hasStyles(el) && curStyles.push(el));
        } else if (hasStyles(child)) {
          curStyles.push(child);
        }
      });
    }

    const files = getDocumentFiles(this.context.buildManifest, this.context.__NEXT_DATA__.page, inAmpMode);
    return /*#__PURE__*/_react.default.createElement("head", this.props, this.context.isDevelopment && /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("style", {
      "data-next-hide-fouc": true,
      "data-ampdevmode": inAmpMode ? 'true' : undefined,
      dangerouslySetInnerHTML: {
        __html: `body{display:none}`
      }
    }), /*#__PURE__*/_react.default.createElement("noscript", {
      "data-next-hide-fouc": true,
      "data-ampdevmode": inAmpMode ? 'true' : undefined
    }, /*#__PURE__*/_react.default.createElement("style", {
      dangerouslySetInnerHTML: {
        __html: `body{display:block}`
      }
    }))), children, head, /*#__PURE__*/_react.default.createElement("meta", {
      name: "next-head-count",
      content: _react.default.Children.count(head || []).toString()
    }), inAmpMode && /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, /*#__PURE__*/_react.default.createElement("meta", {
      name: "viewport",
      content: "width=device-width,minimum-scale=1,initial-scale=1"
    }), !hasCanonicalRel && /*#__PURE__*/_react.default.createElement("link", {
      rel: "canonical",
      href: canonicalBase + (0, _utils2.cleanAmpPath)(dangerousAsPath)
    }), /*#__PURE__*/_react.default.createElement("link", {
      rel: "preload",
      as: "script",
      href: "https://cdn.ampproject.org/v0.js"
    }), styles && /*#__PURE__*/_react.default.createElement("style", {
      "amp-custom": "",
      dangerouslySetInnerHTML: {
        __html: curStyles.map(style => style.props.dangerouslySetInnerHTML.__html).join('').replace(/\/\*# sourceMappingURL=.*\*\//g, '').replace(/\/\*@ sourceURL=.*?\*\//g, '')
      }
    }), /*#__PURE__*/_react.default.createElement("style", {
      "amp-boilerplate": "",
      dangerouslySetInnerHTML: {
        __html: `body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}`
      }
    }), /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("style", {
      "amp-boilerplate": "",
      dangerouslySetInnerHTML: {
        __html: `body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}`
      }
    })), /*#__PURE__*/_react.default.createElement("script", {
      async: true,
      src: "https://cdn.ampproject.org/v0.js"
    })), !inAmpMode && /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, !hasAmphtmlRel && hybridAmp && /*#__PURE__*/_react.default.createElement("link", {
      rel: "amphtml",
      href: canonicalBase + getAmpPath(ampPath, dangerousAsPath)
    }),  true && this.getCssLinks(files),  true && /*#__PURE__*/_react.default.createElement("noscript", {
      "data-n-css": (_this$props$nonce = this.props.nonce) != null ? _this$props$nonce : ''
    }), !disableRuntimeJS && !disableJsPreload && this.getPreloadDynamicChunks(), !disableRuntimeJS && !disableJsPreload && this.getPreloadMainLinks(files),  false && false,  false && /*#__PURE__*/false, this.context.isDevelopment &&
    /*#__PURE__*/
    // this element is used to mount development styles so the
    // ordering matches production
    // (by default, style-loader injects at the bottom of <head />)
    _react.default.createElement("noscript", {
      id: "__next_css__DO_NOT_USE__"
    }), styles || null), /*#__PURE__*/_react.default.createElement(_react.default.Fragment, {}, ...(headTags || [])));
  }

}

exports.Head = Head;
Head.contextType = _documentContext.DocumentContext;
Head.propTypes = {
  nonce: _propTypes.default.string,
  crossOrigin: _propTypes.default.string
};

function Main() {
  const {
    inAmpMode,
    html,
    docComponentsRendered
  } = (0, _react.useContext)(_documentContext.DocumentContext);
  docComponentsRendered.Main = true;
  if (inAmpMode) return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, _constants.AMP_RENDER_TARGET);
  return /*#__PURE__*/_react.default.createElement("div", {
    id: "__next",
    dangerouslySetInnerHTML: {
      __html: html
    }
  });
}

class NextScript extends _react.Component {
  constructor(...args) {
    super(...args);
    this.context = void 0;
  }

  getDynamicChunks(files) {
    const {
      dynamicImports,
      assetPrefix,
      isDevelopment,
      devOnlyCacheBusterQueryString
    } = this.context;
    return dedupe(dynamicImports).map(bundle => {
      if (!bundle.file.endsWith('.js') || files.allFiles.includes(bundle.file)) return null;
      return /*#__PURE__*/_react.default.createElement("script", {
        async: !isDevelopment,
        key: bundle.file,
        src: `${assetPrefix}/_next/${encodeURI(bundle.file)}${devOnlyCacheBusterQueryString}`,
        nonce: this.props.nonce,
        crossOrigin: this.props.crossOrigin || undefined
      });
    });
  }

  getPreNextScripts() {
    const {
      scriptLoader
    } = this.context;
    return (scriptLoader.eager || []).map(file => {
      return /*#__PURE__*/_react.default.createElement("script", Object.assign({}, file, {
        nonce: this.props.nonce,
        crossOrigin: this.props.crossOrigin || undefined
      }));
    });
  }

  getScripts(files) {
    var _buildManifest$lowPri;

    const {
      assetPrefix,
      buildManifest,
      isDevelopment,
      devOnlyCacheBusterQueryString
    } = this.context;
    const normalScripts = files.allFiles.filter(file => file.endsWith('.js'));
    const lowPriorityScripts = (_buildManifest$lowPri = buildManifest.lowPriorityFiles) == null ? void 0 : _buildManifest$lowPri.filter(file => file.endsWith('.js'));
    return [...normalScripts, ...lowPriorityScripts].map(file => {
      return /*#__PURE__*/_react.default.createElement("script", {
        key: file,
        src: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
        nonce: this.props.nonce,
        async: !isDevelopment,
        crossOrigin: this.props.crossOrigin || undefined
      });
    });
  }

  getPolyfillScripts() {
    // polyfills.js has to be rendered as nomodule without async
    // It also has to be the first script to load
    const {
      assetPrefix,
      buildManifest,
      devOnlyCacheBusterQueryString
    } = this.context;
    return buildManifest.polyfillFiles.filter(polyfill => polyfill.endsWith('.js') && !polyfill.endsWith('.module.js')).map(polyfill => /*#__PURE__*/_react.default.createElement("script", {
      key: polyfill,
      nonce: this.props.nonce,
      crossOrigin: this.props.crossOrigin || undefined,
      noModule: true,
      src: `${assetPrefix}/_next/${polyfill}${devOnlyCacheBusterQueryString}`
    }));
  }

  static getInlineScriptSource(documentProps) {
    const {
      __NEXT_DATA__
    } = documentProps;

    try {
      const data = JSON.stringify(__NEXT_DATA__);
      return (0, _htmlescape.htmlEscapeJsonString)(data);
    } catch (err) {
      if (err.message.indexOf('circular structure')) {
        throw new Error(`Circular structure in "getInitialProps" result of page "${__NEXT_DATA__.page}". https://err.sh/vercel/next.js/circular-structure`);
      }

      throw err;
    }
  }

  render() {
    const {
      assetPrefix,
      inAmpMode,
      buildManifest,
      unstable_runtimeJS,
      docComponentsRendered,
      devOnlyCacheBusterQueryString
    } = this.context;
    const disableRuntimeJS = unstable_runtimeJS === false;
    docComponentsRendered.NextScript = true;

    if (inAmpMode) {
      if (false) {}

      const ampDevFiles = [...buildManifest.devFiles, ...buildManifest.polyfillFiles, ...buildManifest.ampDevFiles];
      return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, disableRuntimeJS ? null : /*#__PURE__*/_react.default.createElement("script", {
        id: "__NEXT_DATA__",
        type: "application/json",
        nonce: this.props.nonce,
        crossOrigin: this.props.crossOrigin || undefined,
        dangerouslySetInnerHTML: {
          __html: NextScript.getInlineScriptSource(this.context)
        },
        "data-ampdevmode": true
      }), ampDevFiles.map(file => /*#__PURE__*/_react.default.createElement("script", {
        key: file,
        src: `${assetPrefix}/_next/${file}${devOnlyCacheBusterQueryString}`,
        nonce: this.props.nonce,
        crossOrigin: this.props.crossOrigin || undefined,
        "data-ampdevmode": true
      })));
    }

    if (true) {
      if (this.props.crossOrigin) console.warn('Warning: `NextScript` attribute `crossOrigin` is deprecated. https://err.sh/next.js/doc-crossorigin-deprecated');
    }

    const files = getDocumentFiles(this.context.buildManifest, this.context.__NEXT_DATA__.page, inAmpMode);
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null, !disableRuntimeJS && buildManifest.devFiles ? buildManifest.devFiles.map(file => /*#__PURE__*/_react.default.createElement("script", {
      key: file,
      src: `${assetPrefix}/_next/${encodeURI(file)}${devOnlyCacheBusterQueryString}`,
      nonce: this.props.nonce,
      crossOrigin: this.props.crossOrigin || undefined
    })) : null, disableRuntimeJS ? null : /*#__PURE__*/_react.default.createElement("script", {
      id: "__NEXT_DATA__",
      type: "application/json",
      nonce: this.props.nonce,
      crossOrigin: this.props.crossOrigin || undefined,
      dangerouslySetInnerHTML: {
        __html: NextScript.getInlineScriptSource(this.context)
      }
    }), !disableRuntimeJS && this.getPolyfillScripts(), !disableRuntimeJS && this.getPreNextScripts(), disableRuntimeJS ? null : this.getDynamicChunks(files), disableRuntimeJS ? null : this.getScripts(files));
  }

}

exports.NextScript = NextScript;
NextScript.contextType = _documentContext.DocumentContext;
NextScript.propTypes = {
  nonce: _propTypes.default.string,
  crossOrigin: _propTypes.default.string
};
NextScript.safariNomoduleFix = '!function(){var e=document,t=e.createElement("script");if(!("noModule"in t)&&"onbeforeload"in t){var n=!1;e.addEventListener("beforeload",function(e){if(e.target===t)n=!0;else if(!e.target.hasAttribute("nomodule")||!n)return;e.preventDefault()},!0),t.type="module",t.src=".",e.head.appendChild(t),t.remove()}}();';

function getAmpPath(ampPath, asPath) {
  return ampPath || `${asPath}${asPath.includes('?') ? '&' : '?'}amp=1`;
}

/***/ }),

/***/ "./node_modules/next/dist/server/htmlescape.js":
/*!*****************************************************!*\
  !*** ./node_modules/next/dist/server/htmlescape.js ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
exports.__esModule=true;exports.htmlEscapeJsonString=htmlEscapeJsonString;// This utility is based on https://github.com/zertosh/htmlescape
// License: https://github.com/zertosh/htmlescape/blob/0527ca7156a524d256101bb310a9f970f63078ad/LICENSE
const ESCAPE_LOOKUP={'&':'\\u0026','>':'\\u003e','<':'\\u003c','\u2028':'\\u2028','\u2029':'\\u2029'};const ESCAPE_REGEX=/[&><\u2028\u2029]/g;function htmlEscapeJsonString(str){return str.replace(ESCAPE_REGEX,match=>ESCAPE_LOOKUP[match]);}
//# sourceMappingURL=htmlescape.js.map

/***/ }),

/***/ "./node_modules/next/document.js":
/*!***************************************!*\
  !*** ./node_modules/next/document.js ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/pages/_document */ "./node_modules/next/dist/pages/_document.js")


/***/ }),

/***/ "./src/pages/_document.js":
/*!********************************!*\
  !*** ./src/pages/_document.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return MyDocument; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/document */ "./node_modules/next/document.js");
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var shared_utils_theme__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! shared/utils/theme */ "./src/shared/utils/theme.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\pages\\_document.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





class MyDocument extends next_document__WEBPACK_IMPORTED_MODULE_2___default.a {
  render() {
    return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_document__WEBPACK_IMPORTED_MODULE_2__["Html"], {
      lang: "en",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_document__WEBPACK_IMPORTED_MODULE_2__["Head"], {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("meta", {
          name: "theme-color",
          content: shared_utils_theme__WEBPACK_IMPORTED_MODULE_4__["default"].palette.primary.main
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("link", {
          rel: "stylesheet",
          href: "https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("body", {
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_document__WEBPACK_IMPORTED_MODULE_2__["Main"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 11
        }, this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_document__WEBPACK_IMPORTED_MODULE_2__["NextScript"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 11
        }, this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, this);
  }

} // `getInitialProps` belongs to `_document` (instead of `_app`),
// it's compatible with server-side generation (SSG).

MyDocument.getInitialProps = async ctx => {
  // Resolution order
  //
  // On the server:
  // 1. app.getInitialProps
  // 2. page.getInitialProps
  // 3. document.getInitialProps
  // 4. app.render
  // 5. page.render
  // 6. document.render
  //
  // On the server with error:
  // 1. document.getInitialProps
  // 2. app.render
  // 3. page.render
  // 4. document.render
  //
  // On the client
  // 1. app.getInitialProps
  // 2. page.getInitialProps
  // 3. app.render
  // 4. page.render
  // Render app and page and get the context of the page with collected side effects.
  const sheets = new _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_1__["ServerStyleSheets"]();
  const originalRenderPage = ctx.renderPage;

  ctx.renderPage = () => originalRenderPage({
    enhanceApp: App => props => sheets.collect( /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(App, _objectSpread({}, props), void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 58,
      columnNumber: 54
    }, undefined))
  });

  const initialProps = await next_document__WEBPACK_IMPORTED_MODULE_2___default.a.getInitialProps(ctx);
  return _objectSpread(_objectSpread({}, initialProps), {}, {
    // Styles fragment is rendered after the app and page rendering finish.
    styles: [...react__WEBPACK_IMPORTED_MODULE_3___default.a.Children.toArray(initialProps.styles), sheets.getStyleElement()]
  });
};

/***/ }),

/***/ "./src/shared/utils/Overide/AlertOveride.js":
/*!**************************************************!*\
  !*** ./src/shared/utils/Overide/AlertOveride.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const AlertOveride = {
  MuiAlert: {
    root: {
      fontSize: '15px',
      padding: "12px 24px"
    },
    icon: {
      display: 'none'
    },
    standardSuccess: {
      color: 'inherit',
      backgroundColor: 'inherit'
    },
    action: {
      alignItems: 'flex-start',
      '& .MuiIconButton-root': {
        padding: '6px 0'
      }
    },
    message: {
      padding: '6px 0',
      width: '100%'
    }
  },
  MuiAlertTitle: {
    root: {
      marginBottom: '4px'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (AlertOveride);

/***/ }),

/***/ "./src/shared/utils/Overide/ButtonOveride.js":
/*!***************************************************!*\
  !*** ./src/shared/utils/Overide/ButtonOveride.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const ButtonOverRide = {
  MuiButton: {
    sizeLarge: {
      minWidth: '192px',
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h5.fontSize,
      padding: '8px 51px'
    },
    sizeSmall: {
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].sm.fontSize,
      minWidth: '90px',
      minHeight: '36px',
      fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.regular
    },
    sizeMedium: {
      minWidth: '160px',
      fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.medium
    },
    containedSecondary: {
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.button.secondaryColor
    },
    colorInherit: {
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.main,
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
    },
    contained: {
      boxShadow: 'none'
    },
    root: {
      borderRadius: '50px',
      textTransform: 'inherit',
      fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.medium,
      '&.semiBorder': {
        borderRadius: '0px 0px 20px 20px',
        padding: '8px 5px'
      },
      '&.linkBtn': {
        minWidth: 'auto !important',
        padding: `0 !important`,
        marginBottom: '0 !important',
        backgroundColor: 'transparent',
        '&:hover': {
          backgroundColor: 'transparent !important'
        },
        '&:focus': {
          backgroundColor: 'transparent !important'
        }
      },
      '&.link-primary': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.success.extraLight,
        fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.regular,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].lg.fontSize
      },
      '&.link-white': {
        color: "#fff",
        fontFamily: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].fontFamily.regular,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].lg.fontSize
      },
      '&.facebooKBtn': {
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.facebookBlue
      },
      '&.w-269': {
        width: "269px"
      }
    },
    endIcon: {
      marginLeft: '4px'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (ButtonOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/CardOveride.js":
/*!*************************************************!*\
  !*** ./src/shared/utils/Overide/CardOveride.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const CardOverRide = {
  MuiCard: {
    root: {
      boxShadow: '0 4px 4px rgb(0 0 0 / 8%)',
      borderRadius: '21px'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (CardOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/CheckBoxOveride.js":
/*!*****************************************************!*\
  !*** ./src/shared/utils/Overide/CheckBoxOveride.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const CheckBoxOverRide = {
  MuiCheckbox: {
    root: {
      '&.extraLightLabel ~ span': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight
      },
      '& .MuiSvgIcon-root': {
        color: 'transparent',
        border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight}`,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h4.fontSize,
        borderRadius: '8px',
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
      },
      '&.Mui-checked': {
        '& .MuiSvgIcon-root': {
          border: 'none',
          color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.success.main,
          backgroundColor: 'transparent'
        }
      },
      '&.MuiCheckbox-root ~ span': {
        paddingTop: '0px'
      }
    }
  },
  MuiFormControlLabel: {
    root: {
      alignItems: 'flex-start'
    },
    label: {
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h6.fontSize,
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light,
      paddingTop: '4px',
      paddingLeft: '4px'
    }
  },
  PrivateSwitchBase: {
    root: {
      paddingTop: 0
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (CheckBoxOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/DialogOveride.js":
/*!***************************************************!*\
  !*** ./src/shared/utils/Overide/DialogOveride.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const DialogOverRide = {
  MuiDialog: {
    root: {},
    paper: {
      minWidth: '383px',
      borderRadius: '21px',
      boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.08)'
    },
    container: {
      backgroundColor: 'rgba(88, 90, 121, .70)'
    }
  },
  MuiDialogTitle: {
    root: {
      '& .MuiButtonBase-root': {
        position: 'absolute',
        right: '10px',
        top: '10px'
      },
      '& .MuiSvgIcon-root': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.main,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h4xl.fontSize
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (DialogOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/InputOveride.js":
/*!**************************************************!*\
  !*** ./src/shared/utils/Overide/InputOveride.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const InputOverRide = {
  MuiFilledInput: {
    root: {
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light,
      border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight}`,
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h6.fontSize,
      borderRadius: '16px',
      borderTopLeftRadius: '16px',
      borderTopRightRadius: '16px',
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white,
      height: '52px',
      '&:hover': {
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
      },
      MuiInputLabel: {
        width: '95%',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      },
      '& .MuiInputAdornment-filled.MuiInputAdornment-positionStart:not(.MuiInputAdornment-hiddenLabel)': {
        marginTop: 0
      },
      '& .MuiIconButton-root': {
        padding: '0 8px 0 0',
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h5xl.fontSize
      },
      '&.Mui-error': {
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.error.extraLight,
        borderColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.error.main
      },
      '&.Mui-focused': {
        backgroundColor: 'transparent',
        boxShadow: 'none !important'
      }
    },
    input: {
      padding: '25px 16px 5px',
      borderRadius: '16px'
    },
    adornedEnd: {
      paddingRight: 0
    },
    underline: {
      '&:before, &:after': {
        border: 'none'
      },
      '&:hover': {
        '&:before, &:after': {
          border: 'none'
        }
      }
    },
    multiline: {
      height: '120px'
    }
  },
  MuiInputLabel: {
    root: {
      width: '100%',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap',
      color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight,
      fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h6.fontSize,
      '&.Mui-error': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight
      },
      '&>div': {
        width: '100%',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    },
    filled: {
      transform: 'translate(16px, 17px) scale(1)',
      paddingRight: '45px',
      '&.MuiInputLabel-shrink': {
        transform: 'translate(16px, 10px) scale(0.75)'
      }
    }
  },
  MuiTextField: {
    root: {
      marginBottom: '0px'
    }
  },
  MuiFormControl: {
    root: {
      marginBottom: '24px',
      '&.noMargin': {
        marginBottom: '8px'
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (InputOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/Overide.js":
/*!*********************************************!*\
  !*** ./src/shared/utils/Overide/Overide.js ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _AlertOveride__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./AlertOveride */ "./src/shared/utils/Overide/AlertOveride.js");
/* harmony import */ var _ButtonOveride__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ButtonOveride */ "./src/shared/utils/Overide/ButtonOveride.js");
/* harmony import */ var _CardOveride__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./CardOveride */ "./src/shared/utils/Overide/CardOveride.js");
/* harmony import */ var _CheckBoxOveride__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./CheckBoxOveride */ "./src/shared/utils/Overide/CheckBoxOveride.js");
/* harmony import */ var _DialogOveride__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./DialogOveride */ "./src/shared/utils/Overide/DialogOveride.js");
/* harmony import */ var _InputOveride__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./InputOveride */ "./src/shared/utils/Overide/InputOveride.js");
/* harmony import */ var _ProgressBarOveride__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./ProgressBarOveride */ "./src/shared/utils/Overide/ProgressBarOveride.js");
/* harmony import */ var _RadioOveride__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./RadioOveride */ "./src/shared/utils/Overide/RadioOveride.js");
/* harmony import */ var _SelectOveride__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./SelectOveride */ "./src/shared/utils/Overide/SelectOveride.js");
/* harmony import */ var _SwitchOveride__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./SwitchOveride */ "./src/shared/utils/Overide/SwitchOveride.js");
/* harmony import */ var _TabOveride__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./TabOveride */ "./src/shared/utils/Overide/TabOveride.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












const Overide = {
  overrides: _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, _ButtonOveride__WEBPACK_IMPORTED_MODULE_1__["default"]), _InputOveride__WEBPACK_IMPORTED_MODULE_5__["default"]), _RadioOveride__WEBPACK_IMPORTED_MODULE_7__["default"]), _CheckBoxOveride__WEBPACK_IMPORTED_MODULE_3__["default"]), _SwitchOveride__WEBPACK_IMPORTED_MODULE_9__["default"]), _CardOveride__WEBPACK_IMPORTED_MODULE_2__["default"]), _SelectOveride__WEBPACK_IMPORTED_MODULE_8__["default"]), _DialogOveride__WEBPACK_IMPORTED_MODULE_4__["default"]), _ProgressBarOveride__WEBPACK_IMPORTED_MODULE_6__["default"]), _AlertOveride__WEBPACK_IMPORTED_MODULE_0__["default"]), _TabOveride__WEBPACK_IMPORTED_MODULE_10__["default"])
};
/* harmony default export */ __webpack_exports__["default"] = (Overide);

/***/ }),

/***/ "./src/shared/utils/Overide/ProgressBarOveride.js":
/*!********************************************************!*\
  !*** ./src/shared/utils/Overide/ProgressBarOveride.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");

const ProgressBarOveride = {
  MuiLinearProgress: {
    root: {
      height: '12px'
    },
    colorPrimary: {
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
    },
    bar1Determinate: {
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.success.main
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (ProgressBarOveride);

/***/ }),

/***/ "./src/shared/utils/Overide/RadioOveride.js":
/*!**************************************************!*\
  !*** ./src/shared/utils/Overide/RadioOveride.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../typography */ "./src/shared/utils/typography.js");


const RadioOverRide = {
  MuiRadio: {
    root: {
      '&.extraLightLabel ~ span': {
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight
      },
      '&.size24': {
        '& .MuiSvgIcon-root': {
          fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h4.fontSize
        },
        "&~.MuiFormControlLabel-label": {
          paddingTop: 0
        }
      },
      '& .MuiSvgIcon-root': {
        color: 'transparent',
        border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.extraLight}`,
        fontSize: _typography__WEBPACK_IMPORTED_MODULE_1__["default"].h3xl.fontSize,
        borderRadius: '50%',
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white
      },
      '&.Mui-checked': {
        '& .MuiSvgIcon-root': {
          color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.secondary.dark
        }
      }
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (RadioOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/SelectOveride.js":
/*!***************************************************!*\
  !*** ./src/shared/utils/Overide/SelectOveride.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");

const SelectOveride = {
  MuiSelect: {
    icon: {
      background: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.menus.menuBackground,
      height: '50px',
      borderRadius: '0 16px 16px 0',
      minWidth: '44px',
      top: '0px',
      color: 'transparent'
    },
    iconFilled: {
      right: 0
    },
    select: {
      position: 'relative',
      '&:before': {
        content: '"\\e902"',
        position: 'absolute',
        right: '12px',
        zIndex: '9',
        fontFamily: 'icomoon !important',
        top: '17px',
        fontSize: '20px'
      },
      '&:focus': {
        backgroundColor: 'transparent'
      }
    }
  },
  MuiPopover: {
    paper: {
      borderRadius: '16px'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (SelectOveride);

/***/ }),

/***/ "./src/shared/utils/Overide/SwitchOveride.js":
/*!***************************************************!*\
  !*** ./src/shared/utils/Overide/SwitchOveride.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");

const SwitchOverRide = {
  MuiSwitch: {
    root: {
      width: '60px',
      height: '36px',
      padding: '0px'
    },
    thumb: {
      width: '36px',
      border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light}`,
      height: '36px',
      position: 'relative',
      boxShadow: 'none',
      boxSizing: 'border-box',
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white,
      '&:after': {
        content: '""',
        width: '16px',
        height: '16px',
        border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light}`,
        position: 'absolute',
        left: '50%',
        top: '50%',
        transform: 'translate(-50%, -50%)',
        borderRadius: 50
      }
    },
    switchBase: {
      padding: 0,
      margin: 0,
      transitionDuration: '300ms',
      '&.Mui-checked': {
        transform: 'translateX(24px)',
        color: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.white,
        '& + .MuiSwitch-track': {
          backgroundColor: `${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.secondary.dark} !important`,
          opacity: 1
        },
        '&.Mui-disabled + .MuiSwitch-track': {
          opacity: 0.5
        }
      }
    },
    track: {
      border: `1px solid ${_color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.primary.light}`,
      opacity: '1',
      transition: 'background-color 500ms cubic-bezier(0.4, 0, 0.2, 1) 0ms',
      borderRadius: '50px',
      backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].common.gray
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (SwitchOverRide);

/***/ }),

/***/ "./src/shared/utils/Overide/TabOveride.js":
/*!************************************************!*\
  !*** ./src/shared/utils/Overide/TabOveride.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../color */ "./src/shared/utils/color.js");

const TabOveride = {
  MuiTabs: {
    root: {
      minWidth: '400px',
      '&.textColorInherit': {
        opacity: 'unset',
        minWidth: '400px'
      }
    },
    endIcon: {
      marginLeft: '4px'
    },
    vertical: {
      marginTop: '190px'
    }
  },
  MuiTab: {
    root: {
      opacity: 'unset !important',
      minWidth: '400px !important',
      textTransform: 'none',
      margin: '15px 0',
      '&.Mui-selected': {
        backgroundColor: _color__WEBPACK_IMPORTED_MODULE_0__["default"].palette.secondary.main,
        borderTopLeftRadius: '21px',
        borderBottomLeftRadius: '21px',
        minHeight: '53px',
        '& .arrow svg': {
          display: 'none'
        }
      }
    },
    wrapper: {
      flexDirection: 'initial',
      justifyContent: 'end'
    }
  },
  PrivateTabIndicator: {
    root: {
      display: 'none'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (TabOveride);

/***/ }),

/***/ "./src/shared/utils/Overide/index.js":
/*!*******************************************!*\
  !*** ./src/shared/utils/Overide/index.js ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Overide__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Overide */ "./src/shared/utils/Overide/Overide.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Overide__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/utils/breakpoints.js":
/*!*****************************************!*\
  !*** ./src/shared/utils/breakpoints.js ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 960,
      lg: 1152,
      ml: 1366,
      xlg: 1440,
      xl: 1920
    }
  }
});

/***/ }),

/***/ "./src/shared/utils/color.js":
/*!***********************************!*\
  !*** ./src/shared/utils/color.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const ColorOveRide = {
  common: {
    white: '#fff',
    black: '#000',
    gray: '#F5F5F9',
    facebookBlue: '#3B5998',
    lightBlue: '#826fac',
    grayText: '#7C7C95',
    defaultBgColor: '#C4C4C4',
    secondaryBgColor: '#D9EEFF',
    lightBlack: '#18191F'
  },
  palette: {
    primary: {
      main: '#2F0B7C',
      light: '#26284E',
      extraLight: '#585A79'
    },
    secondary: {
      dark: '#27CCA5',
      main: '#5EEACF',
      light: '#D0FFF6',
      extraLight: '#F5F5F9'
    },
    error: {
      dark: '#CC2811',
      main: '#FF474E',
      light: '#FF8084',
      extraLight: '#FFDBDC'
    },
    pending: {
      main: '#FECD4F',
      light: '#FFDC83',
      extraLight: '#FFF1CE'
    },
    success: {
      main: '#27CCA5',
      light: '#5EEACF',
      extraLight: '#D0FFF6'
    },
    info: {
      main: '#9797BF'
    },
    default: {
      main: '#848FEE'
    },
    button: {
      secondaryColor: '#270276'
    },
    menus: {
      menuBackground: '#D9EEFF'
    },
    dashboardBg: {
      main: '#575757'
    }
  }
};
/* harmony default export */ __webpack_exports__["default"] = (ColorOveRide);

/***/ }),

/***/ "./src/shared/utils/theme.js":
/*!***********************************!*\
  !*** ./src/shared/utils/theme.js ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _breakpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./breakpoints */ "./src/shared/utils/breakpoints.js");
/* harmony import */ var _color__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./color */ "./src/shared/utils/color.js");
/* harmony import */ var _Overide__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./Overide */ "./src/shared/utils/Overide/index.js");
/* harmony import */ var _typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./typography */ "./src/shared/utils/typography.js");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





 // Create a theme instance.

const theme = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["createTheme"])(_objectSpread(_objectSpread(_objectSpread({
  props: {
    // withWidth component ⚛️
    MuiWithWidth: {
      // Initial width property
      initialWidth: 'lg' // Breakpoint being globally set 🌎!

    }
  },
  typography: _typography__WEBPACK_IMPORTED_MODULE_4__["default"]
}, _breakpoints__WEBPACK_IMPORTED_MODULE_1__["default"]), _color__WEBPACK_IMPORTED_MODULE_2__["default"]), _Overide__WEBPACK_IMPORTED_MODULE_3__["default"]));
/* harmony default export */ __webpack_exports__["default"] = (theme);

/***/ }),

/***/ "./src/shared/utils/typography.js":
/*!****************************************!*\
  !*** ./src/shared/utils/typography.js ***!
  \****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ({
  useNextVariants: true,
  fontSize: 16,
  h1: {
    fontSize: 44
  },
  h2: {
    fontSize: 36
  },
  h3xl: {
    fontSize: 32
  },
  h3: {
    fontSize: 27
  },
  h4xl: {
    fontSize: 25
  },
  h4: {
    fontSize: 24
  },
  h5xl: {
    fontSize: 22
  },
  h5: {
    fontSize: 21
  },
  h6: {
    fontSize: 17
  },
  lg: {
    fontSize: 15
  },
  mdxl: {
    fontSize: 14
  },
  md: {
    fontSize: 13
  },
  sm: {
    fontSize: 12
  },
  xs: {
    fontSize: 11
  },
  fontFamily: {
    regular: 'Poppins-Regular',
    medium: 'Poppins-Medium',
    semiBold: 'Poppins-SemiBold',
    bold: 'Poppins-Bold',
    extraBold: 'Poppins-extraBold'
  },
  textTransform: {
    upperCase: 'uppercase'
  }
});

/***/ }),

/***/ 1:
/*!*********************************************!*\
  !*** multi private-next-pages/_document.js ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! private-next-pages/_document.js */"./src/pages/_document.js");


/***/ }),

/***/ "@material-ui/core/styles":
/*!*******************************************!*\
  !*** external "@material-ui/core/styles" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "styled-jsx/server":
/*!************************************!*\
  !*** external "styled-jsx/server" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("styled-jsx/server");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9jb25zdGFudHMuanNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL2RvY3VtZW50LWNvbnRleHQuanNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL3V0aWxzLmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9nZXQtcGFnZS1maWxlcy5qc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9zZXJ2ZXIvdXRpbHMuanNcIiIsIndlYnBhY2s6Ly8vLi4vLi4vcGFnZXMvX2RvY3VtZW50LnRzeCIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L3NlcnZlci9odG1sZXNjYXBlLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L2RvY3VtZW50LmpzIiwid2VicGFjazovLy8uL3NyYy9wYWdlcy9fZG9jdW1lbnQuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy9PdmVyaWRlL0FsZXJ0T3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvQnV0dG9uT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvQ2FyZE92ZXJpZGUuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy9PdmVyaWRlL0NoZWNrQm94T3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvRGlhbG9nT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvSW5wdXRPdmVyaWRlLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvdXRpbHMvT3ZlcmlkZS9PdmVyaWRlLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvdXRpbHMvT3ZlcmlkZS9Qcm9ncmVzc0Jhck92ZXJpZGUuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy9PdmVyaWRlL1JhZGlvT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvU2VsZWN0T3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvU3dpdGNoT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvVGFiT3ZlcmlkZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL3V0aWxzL092ZXJpZGUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy90eXBvZ3JhcGh5LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvdXRpbHMvY29sb3IuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC91dGlscy90aGVtZS5qcyIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJwcm9wLXR5cGVzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJzdHlsZWQtanN4L3NlcnZlclwiIl0sIm5hbWVzIjpbImZpbGVzIiwia2VwdCIsImJ1bmRsZSIsInNoYXJlZEZpbGVzIiwicGFnZUZpbGVzIiwiaW5BbXBNb2RlIiwiYWxsRmlsZXMiLCJDb21wb25lbnQiLCJlbmhhbmNlQXBwIiwiQXBwIiwicHJvcHMiLCJjdHgiLCJzdHlsZXMiLCJyZW5kZXIiLCJEb2N1bWVudCIsImhlYWRUYWdzTWlkZGxld2FyZSIsInByb2Nlc3MiLCJEb2N1bWVudENvbXBvbmVudENvbnRleHQiLCJkb2NDb21wb25lbnRzUmVuZGVyZWQiLCJnZXRDc3NMaW5rcyIsImNzc0ZpbGVzIiwiZiIsInVubWFuZ2VkRmlsZXMiLCJkeW5hbWljQ3NzRmlsZXMiLCJkZWR1cGUiLCJkeW5hbWljSW1wb3J0cyIsImV4aXN0aW5nIiwiY3NzTGlua0VsZW1lbnRzIiwiZmlsZSIsImlzU2hhcmVkRmlsZSIsImFzc2V0UHJlZml4IiwiZW5jb2RlVVJJIiwiZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmciLCJpc1VubWFuYWdlZEZpbGUiLCJnZXRQcmVsb2FkRHluYW1pY0NodW5rcyIsImdldFByZWxvYWRNYWluTGlua3MiLCJwcmVsb2FkRmlsZXMiLCJzY3JpcHRMb2FkZXIiLCJtYWtlU3R5bGVzaGVldEluZXJ0IiwiUmVhY3QiLCJjIiwiT1BUSU1JWkVEX0ZPTlRfUFJPVklERVJTIiwidXJsIiwibmV3UHJvcHMiLCJkaXNhYmxlUnVudGltZUpTIiwidW5zdGFibGVfcnVudGltZUpTIiwiZGlzYWJsZUpzUHJlbG9hZCIsInVuc3RhYmxlX0pzUHJlbG9hZCIsImNzc1ByZWxvYWRzIiwib3RoZXJIZWFkRWxlbWVudHMiLCJoZWFkIiwiY2hpbGRyZW4iLCJjaGlsZCIsImlzUmVhY3RIZWxtZXQiLCJjb25zb2xlIiwiaGFzQW1waHRtbFJlbCIsImhhc0Nhbm9uaWNhbFJlbCIsImJhZFByb3AiLCJ0eXBlIiwiT2JqZWN0IiwicHJvcCIsIl9fTkVYVF9EQVRBX18iLCJwYWdlIiwiY3VyU3R5bGVzIiwiQXJyYXkiLCJoYXNTdHlsZXMiLCJlbCIsImdldERvY3VtZW50RmlsZXMiLCJfX2h0bWwiLCJjYW5vbmljYWxCYXNlIiwic3R5bGUiLCJnZXRBbXBQYXRoIiwiaGVhZFRhZ3MiLCJIZWFkIiwiY29udGV4dFR5cGUiLCJwcm9wVHlwZXMiLCJub25jZSIsIlByb3BUeXBlcyIsImNyb3NzT3JpZ2luIiwiQU1QX1JFTkRFUl9UQVJHRVQiLCJnZXREeW5hbWljQ2h1bmtzIiwiZ2V0UHJlTmV4dFNjcmlwdHMiLCJnZXRTY3JpcHRzIiwibm9ybWFsU2NyaXB0cyIsImxvd1ByaW9yaXR5U2NyaXB0cyIsImJ1aWxkTWFuaWZlc3QiLCJnZXRQb2x5ZmlsbFNjcmlwdHMiLCJwb2x5ZmlsbCIsImRhdGEiLCJKU09OIiwiZXJyIiwiYW1wRGV2RmlsZXMiLCJOZXh0U2NyaXB0Iiwic2FmYXJpTm9tb2R1bGVGaXgiLCJhbXBQYXRoIiwiYXNQYXRoIiwiTXlEb2N1bWVudCIsInRoZW1lIiwicGFsZXR0ZSIsInByaW1hcnkiLCJtYWluIiwiZ2V0SW5pdGlhbFByb3BzIiwic2hlZXRzIiwiU2VydmVyU3R5bGVTaGVldHMiLCJvcmlnaW5hbFJlbmRlclBhZ2UiLCJyZW5kZXJQYWdlIiwiY29sbGVjdCIsImluaXRpYWxQcm9wcyIsIkNoaWxkcmVuIiwidG9BcnJheSIsImdldFN0eWxlRWxlbWVudCIsIkFsZXJ0T3ZlcmlkZSIsIk11aUFsZXJ0Iiwicm9vdCIsImZvbnRTaXplIiwicGFkZGluZyIsImljb24iLCJkaXNwbGF5Iiwic3RhbmRhcmRTdWNjZXNzIiwiY29sb3IiLCJiYWNrZ3JvdW5kQ29sb3IiLCJhY3Rpb24iLCJhbGlnbkl0ZW1zIiwibWVzc2FnZSIsIndpZHRoIiwiTXVpQWxlcnRUaXRsZSIsIm1hcmdpbkJvdHRvbSIsIkJ1dHRvbk92ZXJSaWRlIiwiTXVpQnV0dG9uIiwic2l6ZUxhcmdlIiwibWluV2lkdGgiLCJmb250IiwiaDUiLCJzaXplU21hbGwiLCJzbSIsIm1pbkhlaWdodCIsImZvbnRGYW1pbHkiLCJyZWd1bGFyIiwic2l6ZU1lZGl1bSIsIm1lZGl1bSIsImNvbnRhaW5lZFNlY29uZGFyeSIsImJ1dHRvbiIsInNlY29uZGFyeUNvbG9yIiwiY29sb3JJbmhlcml0IiwiY29tbW9uIiwid2hpdGUiLCJjb250YWluZWQiLCJib3hTaGFkb3ciLCJib3JkZXJSYWRpdXMiLCJ0ZXh0VHJhbnNmb3JtIiwic3VjY2VzcyIsImV4dHJhTGlnaHQiLCJsZyIsImZhY2Vib29rQmx1ZSIsImVuZEljb24iLCJtYXJnaW5MZWZ0IiwiQ2FyZE92ZXJSaWRlIiwiTXVpQ2FyZCIsIkNoZWNrQm94T3ZlclJpZGUiLCJNdWlDaGVja2JveCIsImJvcmRlciIsImg0IiwicGFkZGluZ1RvcCIsIk11aUZvcm1Db250cm9sTGFiZWwiLCJsYWJlbCIsImg2IiwibGlnaHQiLCJwYWRkaW5nTGVmdCIsIlByaXZhdGVTd2l0Y2hCYXNlIiwiRGlhbG9nT3ZlclJpZGUiLCJNdWlEaWFsb2ciLCJwYXBlciIsImNvbnRhaW5lciIsIk11aURpYWxvZ1RpdGxlIiwicG9zaXRpb24iLCJyaWdodCIsInRvcCIsImg0eGwiLCJJbnB1dE92ZXJSaWRlIiwiTXVpRmlsbGVkSW5wdXQiLCJib3JkZXJUb3BMZWZ0UmFkaXVzIiwiYm9yZGVyVG9wUmlnaHRSYWRpdXMiLCJoZWlnaHQiLCJNdWlJbnB1dExhYmVsIiwib3ZlcmZsb3ciLCJ0ZXh0T3ZlcmZsb3ciLCJ3aGl0ZVNwYWNlIiwibWFyZ2luVG9wIiwiaDV4bCIsImVycm9yIiwiYm9yZGVyQ29sb3IiLCJpbnB1dCIsImFkb3JuZWRFbmQiLCJwYWRkaW5nUmlnaHQiLCJ1bmRlcmxpbmUiLCJtdWx0aWxpbmUiLCJmaWxsZWQiLCJ0cmFuc2Zvcm0iLCJNdWlUZXh0RmllbGQiLCJNdWlGb3JtQ29udHJvbCIsIk92ZXJpZGUiLCJvdmVycmlkZXMiLCJCdXR0b25PdmVyaWRlIiwiSW5wdXRPdmVyaWRlIiwiUmFkaW9PdmVyaWRlIiwiQ2hlY2tCb3hPdmVyaWRlIiwiU3dpdGNoT3ZlcmlkZSIsIkNhcmRPdmVyaWRlIiwiU2VsZWN0T3ZlcmlkZSIsIkRpYWxvZ092ZXJpZGUiLCJQcm9ncmVzc0Jhck92ZXJpZGUiLCJUYWJPdmVyaWRlIiwiTXVpTGluZWFyUHJvZ3Jlc3MiLCJjb2xvclByaW1hcnkiLCJiYXIxRGV0ZXJtaW5hdGUiLCJSYWRpb092ZXJSaWRlIiwiTXVpUmFkaW8iLCJoM3hsIiwic2Vjb25kYXJ5IiwiZGFyayIsIk11aVNlbGVjdCIsImJhY2tncm91bmQiLCJtZW51cyIsIm1lbnVCYWNrZ3JvdW5kIiwiaWNvbkZpbGxlZCIsInNlbGVjdCIsImNvbnRlbnQiLCJ6SW5kZXgiLCJNdWlQb3BvdmVyIiwiU3dpdGNoT3ZlclJpZGUiLCJNdWlTd2l0Y2giLCJ0aHVtYiIsImJveFNpemluZyIsImxlZnQiLCJzd2l0Y2hCYXNlIiwibWFyZ2luIiwidHJhbnNpdGlvbkR1cmF0aW9uIiwib3BhY2l0eSIsInRyYWNrIiwidHJhbnNpdGlvbiIsImdyYXkiLCJNdWlUYWJzIiwidmVydGljYWwiLCJNdWlUYWIiLCJib3JkZXJCb3R0b21MZWZ0UmFkaXVzIiwid3JhcHBlciIsImZsZXhEaXJlY3Rpb24iLCJqdXN0aWZ5Q29udGVudCIsIlByaXZhdGVUYWJJbmRpY2F0b3IiLCJicmVha3BvaW50cyIsInZhbHVlcyIsInhzIiwibWQiLCJtbCIsInhsZyIsInhsIiwiQ29sb3JPdmVSaWRlIiwiYmxhY2siLCJsaWdodEJsdWUiLCJncmF5VGV4dCIsImRlZmF1bHRCZ0NvbG9yIiwic2Vjb25kYXJ5QmdDb2xvciIsImxpZ2h0QmxhY2siLCJwZW5kaW5nIiwiaW5mbyIsImRlZmF1bHQiLCJkYXNoYm9hcmRCZyIsImNyZWF0ZVRoZW1lIiwiTXVpV2l0aFdpZHRoIiwiaW5pdGlhbFdpZHRoIiwidHlwb2dyYXBoeSIsIk92ZXJSaWRlQ3NzIiwidXNlTmV4dFZhcmlhbnRzIiwiaDEiLCJoMiIsImgzIiwibWR4bCIsInNlbWlCb2xkIiwiYm9sZCIsImV4dHJhQm9sZCIsInVwcGVyQ2FzZSJdLCJtYXBwaW5ncyI6Ijs7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUk7UUFDSjtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7O0FDeEZBLG1FOzs7Ozs7Ozs7OztBQ0FBLDBFOzs7Ozs7Ozs7OztBQ0FBLCtEOzs7Ozs7Ozs7OztBQ0FBLDJFOzs7Ozs7Ozs7OztBQ0FBLGtFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7O0FBQ0E7O0FBQ0E7O0FBQ0E7O0FBSUE7O0FBQ0E7Ozs7OztBQUtBOztBQUlBOztBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBU0E7O0FBQUEseUJBQStEO0FBQzdELFFBQU1BLEtBQUssR0FBRyxJQUFkLEdBQWMsRUFBZDtBQUNBLFFBQU1DLElBQVMsR0FBZjs7QUFFQSxPQUFLLE1BQUwsbUJBQThCO0FBQzVCLFFBQUlELEtBQUssQ0FBTEEsSUFBVUUsTUFBTSxDQUFwQixJQUFJRixDQUFKLEVBQTRCO0FBQzVCQSxTQUFLLENBQUxBLElBQVVFLE1BQU0sQ0FBaEJGO0FBQ0FDLFFBQUksQ0FBSkE7QUFFRjs7QUFBQTtBQVNGOztBQUFBLDhEQUlpQjtBQUNmLFFBQU1FLFdBQThCLEdBQUcsK0NBQXZDLE9BQXVDLENBQXZDO0FBQ0EsUUFBTUMsU0FBNEIsR0FBR0MsU0FBUyxRQUUxQywrQ0FGSixRQUVJLENBRko7QUFJQSxTQUFPO0FBQUE7QUFBQTtBQUdMQyxZQUFRLEVBQUUsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxHQUFELGFBQWlCLEdBSHpDLFNBR3dCLENBQVIsQ0FBSjtBQUhMLEdBQVA7QUFPRjtBQUFBO0FBQ0E7QUFDQTtBQUNBOzs7QUFDZSx1QkFBK0JDLGdCQUEvQixDQUE0RDtBQVF6RTtBQUNGO0FBQ0E7QUFDQTtBQUNFLG9DQUVpQztBQUMvQixVQUFNQyxVQUFVLEdBQUlDLEdBQUQsSUFBYztBQUMvQixhQUFRQyxLQUFELGlCQUFnQixrQ0FBdkIsS0FBdUIsQ0FBdkI7QUFERjs7QUFJQSxVQUFNO0FBQUE7QUFBQTtBQUFBLFFBQWlCLE1BQU1DLEdBQUcsQ0FBSEEsV0FBZTtBQUE1QztBQUE0QyxLQUFmQSxDQUE3QjtBQUNBLFVBQU1DLE1BQU0sR0FBRyxDQUFDLEdBQUcsWUFBbkIsT0FBbUIsR0FBSixDQUFmO0FBQ0EsV0FBTztBQUFBO0FBQUE7QUFBUDtBQUFPLEtBQVA7QUFHRjs7QUFBQSxrREFHc0I7QUFDcEIsd0JBQ0UsNkJBQUMsaUJBQUQsZUFBQyxDQUFEO0FBQW1DLFdBQUssRUFBeEM7QUFBQSxvQkFDRSxnREFGSixLQUVJLENBREYsQ0FERjtBQU9GQzs7QUFBQUEsUUFBTSxHQUFHO0FBQ1Asd0JBQ0Usc0RBQ0UsbUNBREYsSUFDRSxDQURGLGVBRUUsd0RBQ0UsbUNBREYsSUFDRSxDQURGLGVBRUUseUNBTE4sSUFLTSxDQUZGLENBRkYsQ0FERjtBQXBDdUU7O0FBQUE7OztBQUF0REMsUSxDQUNaQyxrQkFEWUQsR0FDU0UscUJBS3hCLE1BQU0sRUFOU0Y7O0FBZ0RkLHFCQUtMO0FBQ0EsUUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQStDLHVCQUNuREcsaUJBREYsZUFBcUQsQ0FBckQ7QUFJQUMsdUJBQXFCLENBQXJCQTtBQUVBLHNCQUNFO0FBRUUsUUFBSSxFQUFFUixLQUFLLENBQUxBLGtCQUZSO0FBR0UsT0FBRyxFQUFFTCxTQUFTLFFBSGhCO0FBSUUsdUJBQ0VBLHlCQU5OO0FBQ0UsS0FERjtBQVlLOztBQUFBLG1CQUFtQkUsZ0JBQW5CLENBTUw7QUFBQTtBQUFBO0FBQUE7QUFVQVk7O0FBQUFBLGFBQVcsUUFBNkM7QUFDdEQsVUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSUYsS0FKSjtBQUtBLFVBQU1DLFFBQVEsR0FBR3BCLEtBQUssQ0FBTEEsZ0JBQXVCcUIsQ0FBRCxJQUFPQSxDQUFDLENBQURBLFNBQTlDLE1BQThDQSxDQUE3QnJCLENBQWpCO0FBQ0EsVUFBTUcsV0FBd0IsR0FBRyxRQUFRSCxLQUFLLENBQTlDLFdBQWlDLENBQWpDLENBUHNELENBU3REO0FBQ0E7O0FBQ0EsUUFBSXNCLGFBQTBCLEdBQUcsUUFBakMsRUFBaUMsQ0FBakM7QUFDQSxRQUFJQyxlQUFlLEdBQUdDLE1BQU0sQ0FDMUJDLGNBQWMsQ0FBZEEsT0FBdUJKLENBQUQsSUFBT0EsQ0FBQyxDQUFEQSxjQURURyxNQUNTSCxDQUE3QkksQ0FEMEIsQ0FBTkQsS0FFZkgsQ0FBRCxJQUFPQSxDQUFDLENBRmQsSUFBc0JHLENBQXRCOztBQUdBLFFBQUlELGVBQWUsQ0FBbkIsUUFBNEI7QUFDMUIsWUFBTUcsUUFBUSxHQUFHLFFBQWpCLFFBQWlCLENBQWpCO0FBQ0FILHFCQUFlLEdBQUdBLGVBQWUsQ0FBZkEsT0FDZkYsQ0FBRCxJQUFPLEVBQUVLLFFBQVEsQ0FBUkEsVUFBbUJ2QixXQUFXLENBQVhBLElBRDlCb0IsQ0FDOEJwQixDQUFyQixDQURTb0IsQ0FBbEJBO0FBR0FELG1CQUFhLEdBQUcsUUFBaEJBLGVBQWdCLENBQWhCQTtBQUNBRixjQUFRLENBQVJBLEtBQWMsR0FBZEE7QUFHRjs7QUFBQSxRQUFJTyxlQUE4QixHQUFsQztBQUNBUCxZQUFRLENBQVJBLFFBQWtCUSxJQUFELElBQVU7QUFDekIsWUFBTUMsWUFBWSxHQUFHMUIsV0FBVyxDQUFYQSxJQUFyQixJQUFxQkEsQ0FBckI7O0FBRUEsVUFBSSxJQUFKLEVBQXNDO0FBQ3BDd0IsdUJBQWUsQ0FBZkEsbUJBQ0U7QUFDRSxhQUFHLEVBQUcsR0FBRUMsSUFEVjtBQUVFLGVBQUssRUFBRSxXQUZUO0FBR0UsYUFBRyxFQUhMO0FBSUUsY0FBSSxFQUFHLEdBQUVFLFdBQVksVUFBU0MsU0FBUyxNQUVyQyxHQUFFQyw2QkFOTjtBQU9FLFlBQUUsRUFQSjtBQVFFLHFCQUFXLEVBQ1QsMEJBQTBCaEIsU0FWaENXO0FBQ0UsVUFERkE7QUFnQkY7O0FBQUEsWUFBTU0sZUFBZSxHQUFHWCxhQUFhLENBQWJBLElBQXhCLElBQXdCQSxDQUF4QjtBQUNBSyxxQkFBZSxDQUFmQSxtQkFDRTtBQUNFLFdBQUcsRUFETDtBQUVFLGFBQUssRUFBRSxXQUZUO0FBR0UsV0FBRyxFQUhMO0FBSUUsWUFBSSxFQUFHLEdBQUVHLFdBQVksVUFBU0MsU0FBUyxNQUVyQyxHQUFFQyw2QkFOTjtBQU9FLG1CQUFXLEVBQ1QsMEJBQTBCaEIsU0FSOUI7QUFVRSxvQkFBVWlCLGVBQWUsZUFBZUosWUFBWSxRQVZ0RDtBQVdFLG9CQUFVSSxlQUFlLGVBQWVKLFlBQVksZUFaeERGO0FBQ0UsUUFERkE7QUFyQkZQOztBQXNDQSxRQUNFSixLQURGLEVBR0UsRUFNRjs7QUFBQSxXQUFPVyxlQUFlLENBQWZBLHNCQUFQO0FBR0ZPOztBQUFBQSx5QkFBdUIsR0FBRztBQUN4QixVQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFJRixLQUpKO0FBTUEsV0FDRSxNQUFNLENBQU4sY0FBTSxDQUFOLEtBQ1FoQyxNQUFELElBQVk7QUFDZixVQUFJLENBQUNBLE1BQU0sQ0FBTkEsY0FBTCxLQUFLQSxDQUFMLEVBQWtDO0FBQ2hDO0FBR0Y7O0FBQUEsMEJBQ0U7QUFDRSxXQUFHLEVBREw7QUFFRSxXQUFHLEVBQUVBLE1BQU0sQ0FGYjtBQUdFLFlBQUksRUFBRyxHQUFFNEIsV0FBWSxVQUFTQyxTQUFTLENBQ3JDN0IsTUFBTSxDQUQrQixLQUVyQyxHQUFFOEIsNkJBTE47QUFNRSxVQUFFLEVBTko7QUFPRSxhQUFLLEVBQUUsV0FQVDtBQVFFLG1CQUFXLEVBQ1QsMEJBQTBCaEIsU0FWaEM7QUFDRSxRQURGO0FBTkosT0FxQkU7QUFyQkYsWUFERixPQUNFLENBREY7QUEyQkZtQjs7QUFBQUEscUJBQW1CLFFBQTZDO0FBQzlELFVBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUlGLEtBSko7QUFLQSxVQUFNQyxZQUFZLEdBQUdwQyxLQUFLLENBQUxBLGdCQUF1QjRCLElBQUQsSUFBa0I7QUFDM0QsYUFBT0EsSUFBSSxDQUFKQSxTQUFQLEtBQU9BLENBQVA7QUFERixLQUFxQjVCLENBQXJCO0FBSUEsV0FBTyxDQUNMLEdBQUcsQ0FBQ3FDLFlBQVksQ0FBWkEsU0FBRCxRQUFnQ1QsSUFBRCxpQkFDaEM7QUFDRSxTQUFHLEVBQUVBLElBQUksQ0FEWDtBQUVFLFdBQUssRUFBRSxXQUZUO0FBR0UsU0FBRyxFQUhMO0FBSUUsVUFBSSxFQUFFQSxJQUFJLENBSlo7QUFLRSxRQUFFLEVBTEo7QUFNRSxpQkFBVyxFQUNULDBCQUEwQlosU0FUM0I7QUFFSCxNQURDLENBREUsRUFhTCxHQUFHb0IsWUFBWSxDQUFaQSxJQUFrQlIsSUFBRCxpQkFDbEI7QUFDRSxTQUFHLEVBREw7QUFFRSxXQUFLLEVBQUUsV0FGVDtBQUdFLFNBQUcsRUFITDtBQUlFLFVBQUksRUFBRyxHQUFFRSxXQUFZLFVBQVNDLFNBQVMsTUFFckMsR0FBRUMsNkJBTk47QUFPRSxRQUFFLEVBUEo7QUFRRSxpQkFBVyxFQUNULDBCQUEwQmhCLFNBdkIzQjtBQWNILE1BRENvQixDQWJFLEVBMkJMLEdBQUcsQ0FBQ0MsWUFBWSxDQUFaQSxTQUFELFFBQWdDVCxJQUFELGlCQUNoQztBQUNFLFNBQUcsRUFETDtBQUVFLFdBQUssRUFBRSxXQUZUO0FBR0UsU0FBRyxFQUhMO0FBSUUsVUFBSSxFQUpOO0FBS0UsUUFBRSxFQUxKO0FBTUUsaUJBQVcsRUFDVCwwQkFBMEJaLFNBbkNsQztBQTRCSSxNQURDLENBM0JFLENBQVA7QUEwQ0ZzQjs7QUFBQUEscUJBQW1CLE9BQStCO0FBQ2hELFdBQU9DLGtDQUEwQkMsQ0FBRCxJQUFZO0FBQzFDLFVBQ0VBLENBQUMsQ0FBREEsbUJBQ0FBLENBQUMsQ0FBREEsTUFEQUEsTUFDQUEsQ0FEQUEsSUFFQUMseUNBQStCQyxHQUFELElBQVNGLENBQUMsQ0FBREEseUJBSHpDLEdBR3lDQSxDQUF2Q0MsQ0FIRixFQUlFO0FBQ0EsY0FBTUUsUUFBUSxxQkFBU0gsQ0FBQyxDQUFEQSxTQUF2QixFQUFjLENBQWQ7O0FBQ0FHLGdCQUFRLENBQVJBLFdBQVEsQ0FBUkEsR0FBd0JBLFFBQVEsQ0FBaENBLE1BQWdDLENBQWhDQTtBQUNBQSxnQkFBUSxDQUFSQSxNQUFRLENBQVJBO0FBQ0EsNEJBQU9KLCtCQUFQLFFBQU9BLENBQVA7QUFSRixhQVNPLElBQUlDLENBQUMsQ0FBREEsU0FBV0EsQ0FBQyxDQUFEQSxNQUFmLFVBQWVBLENBQWYsRUFBb0M7QUFDekNBLFNBQUMsQ0FBREEsb0JBQXNCLHlCQUF5QkEsQ0FBQyxDQUFEQSxNQUEvQ0EsVUFBK0NBLENBQXpCLENBQXRCQTtBQUVGOztBQUFBO0FBYkYsS0FBT0QsQ0FBUDtBQWlCRjFCOztBQUFBQSxRQUFNLEdBQUc7QUFBQTs7QUFDUCxVQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQVdGLEtBWEo7QUFZQSxVQUFNK0IsZ0JBQWdCLEdBQUdDLGtCQUFrQixLQUEzQztBQUNBLFVBQU1DLGdCQUFnQixHQUFHQyxrQkFBa0IsS0FBM0M7QUFFQTtBQUVBLFFBQUk7QUFBQTtBQUFBLFFBQVcsS0FBZjtBQUNBLFFBQUlDLFdBQStCLEdBQW5DO0FBQ0EsUUFBSUMsaUJBQXFDLEdBQXpDOztBQUNBLGNBQVU7QUFDUkMsVUFBSSxDQUFKQSxRQUFjVixDQUFELElBQU87QUFDbEIsWUFDRUEsQ0FBQyxJQUNEQSxDQUFDLENBQURBLFNBREFBLFVBRUFBLENBQUMsQ0FBREEsaUJBRkFBLGFBR0FBLENBQUMsQ0FBREEsZ0JBSkYsU0FLRTtBQUNBUSxxQkFBVyxDQUFYQTtBQU5GLGVBT087QUFDTFIsV0FBQyxJQUFJUyxpQkFBaUIsQ0FBakJBLEtBQUxULENBQUtTLENBQUxUO0FBRUg7QUFYRFU7QUFZQUEsVUFBSSxHQUFHRixXQUFXLENBQVhBLE9BQVBFLGlCQUFPRixDQUFQRTtBQUVGOztBQUFBLFFBQUlDLFFBQVEsR0FBRyxXQUFmLFNBcENPLENBcUNQOztBQUNBLGNBQTJDO0FBQ3pDQSxjQUFRLEdBQUdaLHNDQUE4QmEsS0FBRCxJQUFnQjtBQUFBOztBQUN0RCxjQUFNQyxhQUFhLEdBQUdELEtBQUgsUUFBR0EsR0FBSCxNQUFHQSxHQUFILGdCQUFHQSxLQUFLLENBQVIsMEJBQUdBLGFBQXRCLG1CQUFzQkEsQ0FBdEI7O0FBQ0EsWUFBSSxDQUFKLGVBQW9CO0FBQUE7O0FBQ2xCLGNBQUksTUFBSyxJQUFMLHFCQUFLLENBQUwsVUFBSixTQUE2QjtBQUMzQkUsbUJBQU8sQ0FBUEE7QUFERixpQkFJTyxJQUNMLE1BQUssSUFBTCxxQkFBSyxDQUFMLG9CQUNBLE1BQUssSUFBTCxzQ0FBSyxDQUFMLGtEQUZLLFlBR0w7QUFDQUEsbUJBQU8sQ0FBUEE7QUFJSDtBQUNEOztBQUFBO0FBaEJGSCxPQUFXWixDQUFYWTtBQWtCQSxVQUFJLFdBQUosYUFDRUcsT0FBTyxDQUFQQTtBQUtKOztBQUFBLFFBQ0V0QyxLQURGLEVBSUUsRUFJRjs7QUFBQSxRQUFJdUMsYUFBYSxHQUFqQjtBQUNBLFFBQUlDLGVBQWUsR0FBbkIsTUF4RU8sQ0EwRVA7O0FBQ0FOLFFBQUksR0FBR1gsNEJBQW1CVyxJQUFJLElBQXZCWCxJQUFnQ2EsS0FBRCxJQUFXO0FBQy9DLFVBQUksQ0FBSixPQUFZO0FBQ1osWUFBTTtBQUFBO0FBQUE7QUFBQSxVQUFOOztBQUNBLHFCQUFlO0FBQ2IsWUFBSUssT0FBZSxHQUFuQjs7QUFFQSxZQUFJQyxJQUFJLEtBQUpBLFVBQW1CaEQsS0FBSyxDQUFMQSxTQUF2QixZQUFrRDtBQUNoRCtDLGlCQUFPLEdBQVBBO0FBREYsZUFFTyxJQUFJQyxJQUFJLEtBQUpBLFVBQW1CaEQsS0FBSyxDQUFMQSxRQUF2QixhQUFrRDtBQUN2RDhDLHlCQUFlLEdBQWZBO0FBREssZUFFQSxJQUFJRSxJQUFJLEtBQVIsVUFBdUI7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxjQUNHaEQsS0FBSyxDQUFMQSxPQUFhQSxLQUFLLENBQUxBLDRCQUFrQyxDQUFoRCxDQUFDQSxJQUNBQSxLQUFLLENBQUxBLDRCQUNFLENBQUNBLEtBQUssQ0FBTixRQUFlQSxLQUFLLENBQUxBLFNBSHBCLGlCQUVHQSxDQUZILEVBSUU7QUFDQStDLG1CQUFPLEdBQVBBO0FBQ0FFLGtCQUFNLENBQU5BLG9CQUE0QkMsSUFBRCxJQUFVO0FBQ25DSCxxQkFBTyxJQUFLLElBQUdHLElBQUssS0FBSWxELEtBQUssTUFBN0IrQztBQURGRTtBQUdBRixtQkFBTyxJQUFQQTtBQUVIO0FBRUQ7O0FBQUEscUJBQWE7QUFDWEgsaUJBQU8sQ0FBUEEsS0FDRyw4QkFBNkJGLEtBQUssQ0FBQ00sSUFBSywyQkFBMEJELE9BQVEsT0FBTUksYUFBYSxDQUFDQyxJQURqR1I7QUFHQTtBQUVIO0FBL0JELGFBK0JPO0FBQ0w7QUFDQSxZQUFJSSxJQUFJLEtBQUpBLFVBQW1CaEQsS0FBSyxDQUFMQSxRQUF2QixXQUFnRDtBQUM5QzZDLHVCQUFhLEdBQWJBO0FBRUg7QUFDRDs7QUFBQTtBQXhDRkwsS0FBT1gsQ0FBUFcsQ0EzRU8sQ0FzSFA7O0FBQ0EsVUFBTWEsU0FBK0IsR0FBR0MsS0FBSyxDQUFMQSwyQkFBeEM7O0FBR0EsUUFDRSxTQUFTLElBQVQsVUFFQTtBQUNBcEQsVUFBTSxDQUhOLFNBSUE7QUFDQW9ELFNBQUssQ0FBTEEsUUFBY3BELE1BQU0sQ0FBTkEsTUFOaEIsUUFNRW9ELENBTkYsRUFPRTtBQUNBLFlBQU1DLFNBQVMsR0FBSUMsRUFBRDtBQUFBOztBQUFBLGVBQ2hCQSxFQURnQixRQUNoQkEsR0FEZ0IsTUFDaEJBLEdBRGdCLGFBQ2hCQSxFQUFFLENBRGMsbURBQ2hCQSxVQURnQiw0Q0FDaEJBLHNCQURnQjtBQUFsQixRQURBLENBR0E7OztBQUNBdEQsWUFBTSxDQUFOQSx1QkFBK0J3QyxLQUFELElBQStCO0FBQzNELFlBQUlZLEtBQUssQ0FBTEEsUUFBSixLQUFJQSxDQUFKLEVBQTBCO0FBQ3hCWixlQUFLLENBQUxBLFFBQWVjLEVBQUQsSUFBUUQsU0FBUyxDQUFUQSxFQUFTLENBQVRBLElBQWlCRixTQUFTLENBQVRBLEtBQXZDWCxFQUF1Q1csQ0FBdkNYO0FBREYsZUFFTyxJQUFJYSxTQUFTLENBQWIsS0FBYSxDQUFiLEVBQXNCO0FBQzNCRixtQkFBUyxDQUFUQTtBQUVIO0FBTkRuRDtBQVNGOztBQUFBLFVBQU1aLEtBQW9CLEdBQUdtRSxnQkFBZ0IsQ0FDM0MsYUFEMkMsZUFFM0MsMkJBRjJDLE1BQTdDLFNBQTZDLENBQTdDO0FBTUEsd0JBQ0UscUNBQVUsS0FBVixPQUNHLDJDQUNDLHlFQUNFO0FBQ0UsNkJBREY7QUFFRSx5QkFBaUI5RCxTQUFTLFlBRjVCO0FBR0UsNkJBQXVCLEVBQUU7QUFDdkIrRCxjQUFNLEVBTFo7QUFJNkI7QUFIM0IsTUFERixlQVFFO0FBQ0UsNkJBREY7QUFFRSx5QkFBaUIvRCxTQUFTLFlBRjVCO0FBQUEsb0JBSUU7QUFDRSw2QkFBdUIsRUFBRTtBQUN2QitELGNBQU0sRUFoQmxCO0FBZW1DO0FBRDNCLE1BSkYsQ0FSRixDQUZKLCtCQXdCRTtBQUNFLFVBQUksRUFETjtBQUVFLGFBQU8sRUFBRTdCLDhCQUFxQlcsSUFBSSxJQUF6QlgsSUExQmIsUUEwQmFBO0FBRlgsTUF4QkYsRUE0QkdsQyxTQUFTLGlCQUNSLHlFQUNFO0FBQ0UsVUFBSSxFQUROO0FBRUUsYUFBTyxFQUhYO0FBQ0UsTUFERixFQUtHLGlDQUNDO0FBQ0UsU0FBRyxFQURMO0FBRUUsVUFBSSxFQUFFZ0UsYUFBYSxHQUFHLDBCQVI1QixlQVE0QjtBQUZ4QixNQU5KLGVBWUU7QUFDRSxTQUFHLEVBREw7QUFFRSxRQUFFLEVBRko7QUFHRSxVQUFJLEVBZlI7QUFZRSxNQVpGLEVBa0JHekQsTUFBTSxpQkFDTDtBQUNFLG9CQURGO0FBRUUsNkJBQXVCLEVBQUU7QUFDdkJ3RCxjQUFNLEVBQUVMLFNBQVMsQ0FBVEEsSUFDQU8sS0FBRCxJQUFXQSxLQUFLLENBQUxBLDhCQURWUCxtR0F0QmhCLEVBc0JnQkE7QUFEZTtBQUYzQixNQW5CSixlQThCRTtBQUNFLHlCQURGO0FBRUUsNkJBQXVCLEVBQUU7QUFDdkJLLGNBQU0sRUFqQ1o7QUFnQzZCO0FBRjNCLE1BOUJGLGVBb0NFLDREQUNFO0FBQ0UseUJBREY7QUFFRSw2QkFBdUIsRUFBRTtBQUN2QkEsY0FBTSxFQXhDZDtBQXVDK0I7QUFGM0IsTUFERixDQXBDRixlQTRDRTtBQUFRLFdBQUssRUFBYjtBQUFjLFNBQUcsRUF6RXZCO0FBeUVNLE1BNUNGLENBN0JKLEVBNEVHLDJCQUNDLDREQUNHLDRDQUNDO0FBQ0UsU0FBRyxFQURMO0FBRUUsVUFBSSxFQUFFQyxhQUFhLEdBQUdFLFVBQVUsVUFKdEMsZUFJc0M7QUFGbEMsTUFGSixFQU9HLFNBQW9DLGlCQVB2QyxLQU91QyxDQVB2QyxFQVFHLHNCQUNDO0FBQVUseUNBQVksV0FBWixxQ0FUZDtBQVNJLE1BVEosRUFXRyxxQkFDQyxDQURELG9CQUVDLEtBYkosdUJBYUksRUFiSixFQWNHLHFCQUNDLENBREQsb0JBRUMseUJBaEJKLEtBZ0JJLENBaEJKLEVBaUJHdkQsVUFBbUMsS0FqQnRDLEVBa0JHQSx1QkFDQyxLQW5CSixFQXFCRztBQUFBO0FBQ0M7QUFDQTtBQUNBO0FBQ0E7QUFBVSxRQUFFLEVBekJoQjtBQXlCSSxNQXpCSixFQTJCR0osTUFBTSxJQXhHYixJQTZFSSxDQTdFSixlQTJHRzJCLDZCQUFvQkEsZUFBcEJBLGNBQXdDLElBQUlpQyxRQUFRLElBNUd6RCxFQTRHNkMsQ0FBeENqQyxDQTNHSCxDQURGO0FBalZGOztBQUFBOzs7QUFOV2tDLEksQ0FPSkMsV0FQSUQsR0FPVXhELGdDQVBWd0Q7QUFBQUEsSSxDQVNKRSxTQVRJRixHQVNRO0FBQ2pCRyxPQUFLLEVBQUVDLG1CQURVO0FBRWpCQyxhQUFXLEVBQUVELG1CQUZJO0FBQUEsQ0FUUko7O0FBeWNOLGdCQUFnQjtBQUNyQixRQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBNkMsdUJBQ2pEeEQsaUJBREYsZUFBbUQsQ0FBbkQ7QUFJQUMsdUJBQXFCLENBQXJCQTtBQUVBLGlCQUFlLG9CQUFPLDREQUFHNkQsV0FBVixpQkFBTyxDQUFQO0FBQ2Ysc0JBQU87QUFBSyxNQUFFLEVBQVA7QUFBaUIsMkJBQXVCLEVBQUU7QUFBRVgsWUFBTSxFQUF6RDtBQUFpRDtBQUExQyxJQUFQO0FBR0s7O0FBQUEseUJBQXlCN0QsZ0JBQXpCLENBQWdEO0FBQUE7QUFBQTtBQUFBO0FBY3JEeUU7O0FBQUFBLGtCQUFnQixRQUF1QjtBQUNyQyxVQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtGLEtBTEo7QUFPQSxXQUFPeEQsTUFBTSxDQUFOQSxjQUFNLENBQU5BLEtBQTRCdEIsTUFBRCxJQUFZO0FBQzVDLFVBQUksQ0FBQ0EsTUFBTSxDQUFOQSxjQUFELEtBQUNBLENBQUQsSUFBZ0NGLEtBQUssQ0FBTEEsa0JBQXdCRSxNQUFNLENBQWxFLElBQW9DRixDQUFwQyxFQUNFO0FBRUYsMEJBQ0U7QUFDRSxhQUFLLEVBQUUsQ0FEVDtBQUVFLFdBQUcsRUFBRUUsTUFBTSxDQUZiO0FBR0UsV0FBRyxFQUFHLEdBQUU0QixXQUFZLFVBQVNDLFNBQVMsQ0FDcEM3QixNQUFNLENBRDhCLEtBRXBDLEdBQUU4Qiw2QkFMTjtBQU1FLGFBQUssRUFBRSxXQU5UO0FBT0UsbUJBQVcsRUFDVCwwQkFBMEJoQixTQVRoQztBQUNFLFFBREY7QUFKRixLQUFPUSxDQUFQO0FBb0JGeUQ7O0FBQUFBLG1CQUFpQixHQUFHO0FBQ2xCLFVBQU07QUFBQTtBQUFBLFFBQW1CLEtBQXpCO0FBRUEsV0FBTyxDQUFDNUMsWUFBWSxDQUFaQSxTQUFELFFBQWdDVCxJQUFELElBQWtCO0FBQ3RELDBCQUNFO0FBRUUsYUFBSyxFQUFFLFdBRlQ7QUFHRSxtQkFBVyxFQUNULDBCQUEwQlosU0FMaEM7QUFDRSxTQURGO0FBREYsS0FBTyxDQUFQO0FBYUZrRTs7QUFBQUEsWUFBVSxRQUF1QjtBQUFBOztBQUMvQixVQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxRQUtGLEtBTEo7QUFPQSxVQUFNQyxhQUFhLEdBQUduRixLQUFLLENBQUxBLGdCQUF1QjRCLElBQUQsSUFBVUEsSUFBSSxDQUFKQSxTQUF0RCxLQUFzREEsQ0FBaEM1QixDQUF0QjtBQUNBLFVBQU1vRixrQkFBa0IsNEJBQUdDLGFBQWEsQ0FBaEIscUNBQUdBLDZCQUF3Q3pELElBQUQsSUFDaEVBLElBQUksQ0FBSkEsU0FERixLQUNFQSxDQUR5QnlELENBQTNCO0FBSUEsV0FBTyxDQUFDLEdBQUQsZUFBbUIsR0FBbkIsd0JBQStDekQsSUFBRCxJQUFVO0FBQzdELDBCQUNFO0FBQ0UsV0FBRyxFQURMO0FBRUUsV0FBRyxFQUFHLEdBQUVFLFdBQVksVUFBU0MsU0FBUyxNQUVwQyxHQUFFQyw2QkFKTjtBQUtFLGFBQUssRUFBRSxXQUxUO0FBTUUsYUFBSyxFQUFFLENBTlQ7QUFPRSxtQkFBVyxFQUNULDBCQUEwQmhCLFNBVGhDO0FBQ0UsUUFERjtBQURGLEtBQU8sQ0FBUDtBQWlCRnNFOztBQUFBQSxvQkFBa0IsR0FBRztBQUNuQjtBQUNBO0FBQ0EsVUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBSUYsS0FKSjtBQU1BLFdBQU9ELGFBQWEsQ0FBYkEscUJBRUZFLFFBQUQsSUFDRUEsUUFBUSxDQUFSQSxtQkFBNEIsQ0FBQ0EsUUFBUSxDQUFSQSxTQUg1QkYsWUFHNEJFLENBSDVCRixNQUtDRSxRQUFELGlCQUNIO0FBQ0UsU0FBRyxFQURMO0FBRUUsV0FBSyxFQUFFLFdBRlQ7QUFHRSxpQkFBVyxFQUNULDBCQUEwQnZFLFNBSjlCO0FBTUUsY0FBUSxFQU5WO0FBT0UsU0FBRyxFQUFHLEdBQUVjLFdBQVksVUFBU3lELFFBQVMsR0FBRXZELDZCQWI5QztBQU1JLE1BTkdxRCxDQUFQO0FBa0JGOztBQUFBLDhDQUE2RTtBQUMzRSxVQUFNO0FBQUE7QUFBQSxRQUFOOztBQUNBLFFBQUk7QUFDRixZQUFNRyxJQUFJLEdBQUdDLElBQUksQ0FBSkEsVUFBYixhQUFhQSxDQUFiO0FBQ0EsYUFBTyxzQ0FBUCxJQUFPLENBQVA7QUFDQSxLQUhGLENBR0UsWUFBWTtBQUNaLFVBQUlDLEdBQUcsQ0FBSEEsZ0JBQUosb0JBQUlBLENBQUosRUFBK0M7QUFDN0MsY0FBTSxVQUNILDJEQUEwRDdCLGFBQWEsQ0FBQ0MsSUFEM0UscURBQU0sQ0FBTjtBQUlGOztBQUFBO0FBRUg7QUFFRGpEOztBQUFBQSxRQUFNLEdBQUc7QUFDUCxVQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsUUFPRixLQVBKO0FBUUEsVUFBTStCLGdCQUFnQixHQUFHQyxrQkFBa0IsS0FBM0M7QUFFQTNCLHlCQUFxQixDQUFyQkE7O0FBRUEsbUJBQWU7QUFDYixpQkFBMkMsRUFJM0M7O0FBQUEsWUFBTXlFLFdBQVcsR0FBRyxDQUNsQixHQUFHTixhQUFhLENBREUsVUFFbEIsR0FBR0EsYUFBYSxDQUZFLGVBR2xCLEdBQUdBLGFBQWEsQ0FIbEIsV0FBb0IsQ0FBcEI7QUFNQSwwQkFDRSw0REFDR3pDLGdCQUFnQix1QkFDZjtBQUNFLFVBQUUsRUFESjtBQUVFLFlBQUksRUFGTjtBQUdFLGFBQUssRUFBRSxXQUhUO0FBSUUsbUJBQVcsRUFDVCwwQkFBMEI1QixTQUw5QjtBQU9FLCtCQUF1QixFQUFFO0FBQ3ZCb0QsZ0JBQU0sRUFBRXdCLFVBQVUsQ0FBVkEsc0JBQWlDLEtBUjdDLE9BUVlBO0FBRGUsU0FQM0I7QUFVRSwyQkFaTjtBQUVJLFFBRkosRUFlR0QsV0FBVyxDQUFYQSxJQUFpQi9ELElBQUQsaUJBQ2Y7QUFDRSxXQUFHLEVBREw7QUFFRSxXQUFHLEVBQUcsR0FBRUUsV0FBWSxVQUFTRixJQUFLLEdBQUVJLDZCQUZ0QztBQUdFLGFBQUssRUFBRSxXQUhUO0FBSUUsbUJBQVcsRUFDVCwwQkFBMEJoQixTQUw5QjtBQU9FLDJCQXhCUjtBQWlCTSxRQUREMkUsQ0FmSCxDQURGO0FBK0JGOztBQUFBLGNBQTJDO0FBQ3pDLFVBQUksV0FBSixhQUNFckMsT0FBTyxDQUFQQTtBQUtKOztBQUFBLFVBQU10RCxLQUFvQixHQUFHbUUsZ0JBQWdCLENBQzNDLGFBRDJDLGVBRTNDLDJCQUYyQyxNQUE3QyxTQUE2QyxDQUE3QztBQU1BLHdCQUNFLDREQUNHLHFCQUFxQmtCLGFBQWEsQ0FBbEMsV0FDR0EsYUFBYSxDQUFiQSxhQUE0QnpELElBQUQsaUJBQ3pCO0FBQ0UsU0FBRyxFQURMO0FBRUUsU0FBRyxFQUFHLEdBQUVFLFdBQVksVUFBU0MsU0FBUyxNQUVwQyxHQUFFQyw2QkFKTjtBQUtFLFdBQUssRUFBRSxXQUxUO0FBTUUsaUJBQVcsRUFDVCwwQkFBMEJoQixTQVRuQztBQUVLLE1BREZxRSxDQURILEdBREgsTUFlR3pDLGdCQUFnQix1QkFDZjtBQUNFLFFBQUUsRUFESjtBQUVFLFVBQUksRUFGTjtBQUdFLFdBQUssRUFBRSxXQUhUO0FBSUUsaUJBQVcsRUFDVCwwQkFBMEI1QixTQUw5QjtBQU9FLDZCQUF1QixFQUFFO0FBQ3ZCb0QsY0FBTSxFQUFFd0IsVUFBVSxDQUFWQSxzQkFBaUMsS0F4QmpELE9Bd0JnQkE7QUFEZTtBQVAzQixNQWhCSixFQTRCRyxxQkFBcUIsS0E1QnhCLGtCQTRCd0IsRUE1QnhCLEVBNkJHLHFCQUFxQixLQTdCeEIsaUJBNkJ3QixFQTdCeEIsRUE4QkdoRCxnQkFBZ0IsVUFBVSxzQkE5QjdCLEtBOEI2QixDQTlCN0IsRUErQkdBLGdCQUFnQixVQUFVLGdCQWhDL0IsS0FnQytCLENBL0I3QixDQURGO0FBdE1tRDs7QUFBQTs7O0FBQTFDZ0QsVSxDQUNKbEIsV0FESWtCLEdBQ1UzRSxnQ0FEVjJFO0FBQUFBLFUsQ0FHSmpCLFNBSElpQixHQUdRO0FBQ2pCaEIsT0FBSyxFQUFFQyxtQkFEVTtBQUVqQkMsYUFBVyxFQUFFRCxtQkFGSTtBQUFBLENBSFJlO0FBQUFBLFUsQ0FXSkMsaUJBWElELEdBWVQsMFRBWlNBOztBQTRPYixxQ0FBNkQ7QUFDM0QsU0FBT0UsT0FBTyxJQUFLLEdBQUVDLE1BQU8sR0FBRUEsTUFBTSxDQUFOQSxzQkFBNkIsR0FBM0Q7QUFDRCxDOzs7Ozs7Ozs7Ozs7QUM1MEJZLHdCQUF3QixrREFBa0Q7QUFDdkY7QUFDQSxxQkFBcUIsaUZBQWlGLHdDQUF3QyxtQ0FBbUM7QUFDakwsc0M7Ozs7Ozs7Ozs7O0FDSEEsaUJBQWlCLG1CQUFPLENBQUMsMkVBQXdCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBakQ7QUFDQTtBQUNBO0FBQ0E7QUFFZSxNQUFNQyxVQUFOLFNBQXlCbEYsb0RBQXpCLENBQWtDO0FBQy9DRCxRQUFNLEdBQUc7QUFDUCx3QkFDRSxxRUFBQyxrREFBRDtBQUFNLFVBQUksRUFBQyxJQUFYO0FBQUEsOEJBQ0UscUVBQUMsa0RBQUQ7QUFBQSxnQ0FFRTtBQUFNLGNBQUksRUFBQyxhQUFYO0FBQXlCLGlCQUFPLEVBQUVvRiwwREFBSyxDQUFDQyxPQUFOLENBQWNDLE9BQWQsQ0FBc0JDO0FBQXhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkYsZUFHRTtBQUNFLGFBQUcsRUFBQyxZQUROO0FBRUUsY0FBSSxFQUFDO0FBRlA7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsY0FERixlQVNFO0FBQUEsZ0NBQ0UscUVBQUMsa0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxnQkFERixlQUVFLHFFQUFDLHdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZ0JBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGNBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFlBREY7QUFnQkQ7O0FBbEI4QyxDLENBcUJqRDtBQUNBOztBQUNBSixVQUFVLENBQUNLLGVBQVgsR0FBNkIsTUFBTzFGLEdBQVAsSUFBZTtBQUMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBLFFBQU0yRixNQUFNLEdBQUcsSUFBSUMsMEVBQUosRUFBZjtBQUNBLFFBQU1DLGtCQUFrQixHQUFHN0YsR0FBRyxDQUFDOEYsVUFBL0I7O0FBRUE5RixLQUFHLENBQUM4RixVQUFKLEdBQWlCLE1BQ2ZELGtCQUFrQixDQUFDO0FBQ2pCaEcsY0FBVSxFQUFHQyxHQUFELElBQVVDLEtBQUQsSUFBVzRGLE1BQU0sQ0FBQ0ksT0FBUCxlQUFlLHFFQUFDLEdBQUQsb0JBQVNoRyxLQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWY7QUFEZixHQUFELENBRHBCOztBQUtBLFFBQU1pRyxZQUFZLEdBQUcsTUFBTTdGLG9EQUFRLENBQUN1RixlQUFULENBQXlCMUYsR0FBekIsQ0FBM0I7QUFFQSx5Q0FDS2dHLFlBREw7QUFFRTtBQUNBL0YsVUFBTSxFQUFFLENBQ04sR0FBRzJCLDRDQUFLLENBQUNxRSxRQUFOLENBQWVDLE9BQWYsQ0FBdUJGLFlBQVksQ0FBQy9GLE1BQXBDLENBREcsRUFFTjBGLE1BQU0sQ0FBQ1EsZUFBUCxFQUZNO0FBSFY7QUFRRCxDQTFDRCxDOzs7Ozs7Ozs7Ozs7QUM1QkE7QUFBQSxNQUFNQyxZQUFZLEdBQUc7QUFDakJDLFVBQVEsRUFBRTtBQUNOQyxRQUFJLEVBQUM7QUFDREMsY0FBUSxFQUFDLE1BRFI7QUFFREMsYUFBTyxFQUFDO0FBRlAsS0FEQztBQUtOQyxRQUFJLEVBQUM7QUFDREMsYUFBTyxFQUFDO0FBRFAsS0FMQztBQVFOQyxtQkFBZSxFQUFDO0FBQ1pDLFdBQUssRUFBQyxTQURNO0FBRVpDLHFCQUFlLEVBQUM7QUFGSixLQVJWO0FBWU5DLFVBQU0sRUFBQztBQUNIQyxnQkFBVSxFQUFDLFlBRFI7QUFFSCwrQkFBd0I7QUFDcEJQLGVBQU8sRUFBQztBQURZO0FBRnJCLEtBWkQ7QUFrQk5RLFdBQU8sRUFBQztBQUNKUixhQUFPLEVBQUUsT0FETDtBQUVKUyxXQUFLLEVBQUM7QUFGRjtBQWxCRixHQURPO0FBd0JqQkMsZUFBYSxFQUFDO0FBQ1ZaLFFBQUksRUFBQztBQUNEYSxrQkFBWSxFQUFDO0FBRFo7QUFESztBQXhCRyxDQUFyQjtBQStCZWYsMkVBQWYsRTs7Ozs7Ozs7Ozs7O0FDL0JBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFFQSxNQUFNZ0IsY0FBYyxHQUFHO0FBQ25CQyxXQUFTLEVBQUU7QUFDUEMsYUFBUyxFQUFFO0FBQ1BDLGNBQVEsRUFBRSxPQURIO0FBRVBoQixjQUFRLEVBQUVpQixtREFBSSxDQUFDQyxFQUFMLENBQVFsQixRQUZYO0FBR1BDLGFBQU8sRUFBRTtBQUhGLEtBREo7QUFNUGtCLGFBQVMsRUFBRTtBQUNQbkIsY0FBUSxFQUFFaUIsbURBQUksQ0FBQ0csRUFBTCxDQUFRcEIsUUFEWDtBQUVQZ0IsY0FBUSxFQUFFLE1BRkg7QUFHUEssZUFBUyxFQUFFLE1BSEo7QUFJUEMsZ0JBQVUsRUFBRUwsbURBQUksQ0FBQ0ssVUFBTCxDQUFnQkM7QUFKckIsS0FOSjtBQVlQQyxjQUFVLEVBQUU7QUFDUlIsY0FBUSxFQUFFLE9BREY7QUFFUk0sZ0JBQVUsRUFBRUwsbURBQUksQ0FBQ0ssVUFBTCxDQUFnQkc7QUFGcEIsS0FaTDtBQWdCUEMsc0JBQWtCLEVBQUU7QUFDaEJyQixXQUFLLEVBQUVBLDhDQUFLLENBQUNyQixPQUFOLENBQWMyQyxNQUFkLENBQXFCQztBQURaLEtBaEJiO0FBbUJQQyxnQkFBWSxFQUFFO0FBQ1Z4QixXQUFLLEVBQUVBLDhDQUFLLENBQUNyQixPQUFOLENBQWNDLE9BQWQsQ0FBc0JDLElBRG5CO0FBRVZvQixxQkFBZSxFQUFFRCw4Q0FBSyxDQUFDeUIsTUFBTixDQUFhQztBQUZwQixLQW5CUDtBQXVCUEMsYUFBUyxFQUFFO0FBQ1BDLGVBQVMsRUFBRTtBQURKLEtBdkJKO0FBMkJQbEMsUUFBSSxFQUFFO0FBQ0ZtQyxrQkFBWSxFQUFFLE1BRFo7QUFFRkMsbUJBQWEsRUFBRSxTQUZiO0FBR0ZiLGdCQUFVLEVBQUVMLG1EQUFJLENBQUNLLFVBQUwsQ0FBZ0JHLE1BSDFCO0FBSUYsc0JBQWdCO0FBQ1pTLG9CQUFZLEVBQUUsbUJBREY7QUFFWmpDLGVBQU8sRUFBQztBQUZJLE9BSmQ7QUFRRixtQkFBYTtBQUNUZSxnQkFBUSxFQUFFLGlCQUREO0FBRVRmLGVBQU8sRUFBRyxjQUZEO0FBR1RXLG9CQUFZLEVBQUUsY0FITDtBQUlUTix1QkFBZSxFQUFFLGFBSlI7QUFLVCxtQkFBVztBQUNQQSx5QkFBZSxFQUFFO0FBRFYsU0FMRjtBQVFULG1CQUFXO0FBQ1BBLHlCQUFlLEVBQUU7QUFEVjtBQVJGLE9BUlg7QUFvQkYsd0JBQWtCO0FBQ2RELGFBQUssRUFBRUEsOENBQUssQ0FBQ3JCLE9BQU4sQ0FBY29ELE9BQWQsQ0FBc0JDLFVBRGY7QUFFZGYsa0JBQVUsRUFBRUwsbURBQUksQ0FBQ0ssVUFBTCxDQUFnQkMsT0FGZDtBQUdkdkIsZ0JBQVEsRUFBRWlCLG1EQUFJLENBQUNxQixFQUFMLENBQVF0QztBQUhKLE9BcEJoQjtBQXlCRixzQkFBZ0I7QUFDWkssYUFBSyxFQUFFLE1BREs7QUFFWmlCLGtCQUFVLEVBQUVMLG1EQUFJLENBQUNLLFVBQUwsQ0FBZ0JDLE9BRmhCO0FBR1p2QixnQkFBUSxFQUFFaUIsbURBQUksQ0FBQ3FCLEVBQUwsQ0FBUXRDO0FBSE4sT0F6QmQ7QUE4QkYsdUJBQWlCO0FBQ2JNLHVCQUFlLEVBQUVELDhDQUFLLENBQUN5QixNQUFOLENBQWFTO0FBRGpCLE9BOUJmO0FBaUNGLGlCQUFXO0FBQ1A3QixhQUFLLEVBQUM7QUFEQztBQWpDVCxLQTNCQztBQWdFUDhCLFdBQU8sRUFBQztBQUNKQyxnQkFBVSxFQUFDO0FBRFA7QUFoRUQ7QUFEUSxDQUF2QjtBQXVFZTVCLDZFQUFmLEU7Ozs7Ozs7Ozs7OztBQzFFQTtBQUFBLE1BQU02QixZQUFZLEdBQUc7QUFDakJDLFNBQU8sRUFBRTtBQUNMNUMsUUFBSSxFQUFDO0FBQ0RrQyxlQUFTLEVBQUUsMkJBRFY7QUFFREMsa0JBQVksRUFBRTtBQUZiO0FBREE7QUFEUSxDQUFyQjtBQVNlUSwyRUFBZixFOzs7Ozs7Ozs7Ozs7QUNUQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUEsTUFBTUUsZ0JBQWdCLEdBQUc7QUFDckJDLGFBQVcsRUFBRTtBQUNUOUMsUUFBSSxFQUFFO0FBQ0Ysa0NBQTRCO0FBQ3hCTSxhQUFLLEVBQUVBLDhDQUFLLENBQUNyQixPQUFOLENBQWNDLE9BQWQsQ0FBc0JvRDtBQURMLE9BRDFCO0FBSUYsNEJBQXNCO0FBQ2xCaEMsYUFBSyxFQUFFLGFBRFc7QUFFbEJ5QyxjQUFNLEVBQUcsYUFBWXpDLDhDQUFLLENBQUNyQixPQUFOLENBQWNDLE9BQWQsQ0FBc0JvRCxVQUFXLEVBRnBDO0FBR2xCckMsZ0JBQVEsRUFBRWlCLG1EQUFJLENBQUM4QixFQUFMLENBQVEvQyxRQUhBO0FBSWxCa0Msb0JBQVksRUFBRSxLQUpJO0FBS2xCNUIsdUJBQWUsRUFBRUQsOENBQUssQ0FBQ3lCLE1BQU4sQ0FBYUM7QUFMWixPQUpwQjtBQVdGLHVCQUFpQjtBQUNiLDhCQUFzQjtBQUNsQmUsZ0JBQU0sRUFBRSxNQURVO0FBRWxCekMsZUFBSyxFQUFFQSw4Q0FBSyxDQUFDckIsT0FBTixDQUFjb0QsT0FBZCxDQUFzQmxELElBRlg7QUFHbEJvQix5QkFBZSxFQUFFO0FBSEM7QUFEVCxPQVhmO0FBa0JGLG1DQUE2QjtBQUN6QjBDLGtCQUFVLEVBQUU7QUFEYTtBQWxCM0I7QUFERyxHQURRO0FBeUJyQkMscUJBQW1CLEVBQUU7QUFDakJsRCxRQUFJLEVBQUU7QUFDRlMsZ0JBQVUsRUFBRTtBQURWLEtBRFc7QUFJakIwQyxTQUFLLEVBQUU7QUFDSGxELGNBQVEsRUFBRWlCLG1EQUFJLENBQUNrQyxFQUFMLENBQVFuRCxRQURmO0FBRUhLLFdBQUssRUFBRUEsOENBQUssQ0FBQ3JCLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQm1FLEtBRjFCO0FBR0hKLGdCQUFVLEVBQUUsS0FIVDtBQUlISyxpQkFBVyxFQUFDO0FBSlQ7QUFKVSxHQXpCQTtBQW9DckJDLG1CQUFpQixFQUFFO0FBQ2Z2RCxRQUFJLEVBQUU7QUFDRmlELGdCQUFVLEVBQUU7QUFEVjtBQURTO0FBcENFLENBQXpCO0FBMkNlSiwrRUFBZixFOzs7Ozs7Ozs7Ozs7QUM5Q0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUVBLE1BQU1XLGNBQWMsR0FBRztBQUNuQkMsV0FBUyxFQUFFO0FBQ1B6RCxRQUFJLEVBQUUsRUFEQztBQUVQMEQsU0FBSyxFQUFFO0FBQ0h6QyxjQUFRLEVBQUUsT0FEUDtBQUVIa0Isa0JBQVksRUFBRSxNQUZYO0FBR0hELGVBQVMsRUFBRTtBQUhSLEtBRkE7QUFPUHlCLGFBQVMsRUFBQztBQUNOcEQscUJBQWUsRUFBQztBQURWO0FBUEgsR0FEUTtBQVluQnFELGdCQUFjLEVBQUU7QUFDWjVELFFBQUksRUFBRTtBQUNGLCtCQUF5QjtBQUNyQjZELGdCQUFRLEVBQUUsVUFEVztBQUVyQkMsYUFBSyxFQUFFLE1BRmM7QUFHckJDLFdBQUcsRUFBRTtBQUhnQixPQUR2QjtBQU1GLDRCQUFzQjtBQUNsQnpELGFBQUssRUFBRUEsOENBQUssQ0FBQ3JCLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQkMsSUFEWDtBQUVsQmMsZ0JBQVEsRUFBRWlCLG1EQUFJLENBQUM4QyxJQUFMLENBQVUvRDtBQUZGO0FBTnBCO0FBRE07QUFaRyxDQUF2QjtBQTJCZXVELDZFQUFmLEU7Ozs7Ozs7Ozs7OztBQzlCQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBRUEsTUFBTVMsYUFBYSxHQUFHO0FBQ2xCQyxnQkFBYyxFQUFFO0FBQ1psRSxRQUFJLEVBQUU7QUFDRk0sV0FBSyxFQUFFQSw4Q0FBSyxDQUFDckIsT0FBTixDQUFjQyxPQUFkLENBQXNCbUUsS0FEM0I7QUFFRk4sWUFBTSxFQUFHLGFBQVl6Qyw4Q0FBSyxDQUFDckIsT0FBTixDQUFjQyxPQUFkLENBQXNCb0QsVUFBVyxFQUZwRDtBQUdGckMsY0FBUSxFQUFFaUIsbURBQUksQ0FBQ2tDLEVBQUwsQ0FBUW5ELFFBSGhCO0FBSUZrQyxrQkFBWSxFQUFFLE1BSlo7QUFLRmdDLHlCQUFtQixFQUFFLE1BTG5CO0FBTUZDLDBCQUFvQixFQUFFLE1BTnBCO0FBT0Y3RCxxQkFBZSxFQUFFRCw4Q0FBSyxDQUFDeUIsTUFBTixDQUFhQyxLQVA1QjtBQVFGcUMsWUFBTSxFQUFFLE1BUk47QUFTRixpQkFBVztBQUNQOUQsdUJBQWUsRUFBRUQsOENBQUssQ0FBQ3lCLE1BQU4sQ0FBYUM7QUFEdkIsT0FUVDtBQVlGc0MsbUJBQWEsRUFBRTtBQUNYM0QsYUFBSyxFQUFFLEtBREk7QUFFWDRELGdCQUFRLEVBQUUsUUFGQztBQUdYQyxvQkFBWSxFQUFFLFVBSEg7QUFJWEMsa0JBQVUsRUFBRTtBQUpELE9BWmI7QUFrQkYseUdBQ0k7QUFDSUMsaUJBQVMsRUFBRTtBQURmLE9BbkJGO0FBc0JGLCtCQUF5QjtBQUNyQnhFLGVBQU8sRUFBRSxXQURZO0FBRXJCRCxnQkFBUSxFQUFFaUIsbURBQUksQ0FBQ3lELElBQUwsQ0FBVTFFO0FBRkMsT0F0QnZCO0FBMEJGLHFCQUFlO0FBQ1hNLHVCQUFlLEVBQUVELDhDQUFLLENBQUNyQixPQUFOLENBQWMyRixLQUFkLENBQW9CdEMsVUFEMUI7QUFFWHVDLG1CQUFXLEVBQUV2RSw4Q0FBSyxDQUFDckIsT0FBTixDQUFjMkYsS0FBZCxDQUFvQnpGO0FBRnRCLE9BMUJiO0FBOEJGLHVCQUFpQjtBQUNib0IsdUJBQWUsRUFBRSxhQURKO0FBRWIyQixpQkFBUyxFQUFFO0FBRkU7QUE5QmYsS0FETTtBQW9DWjRDLFNBQUssRUFBRTtBQUNINUUsYUFBTyxFQUFFLGVBRE47QUFFSGlDLGtCQUFZLEVBQUM7QUFGVixLQXBDSztBQXdDWjRDLGNBQVUsRUFBRTtBQUNSQyxrQkFBWSxFQUFFO0FBRE4sS0F4Q0E7QUEyQ1pDLGFBQVMsRUFBRTtBQUNQLDJCQUFxQjtBQUNqQmxDLGNBQU0sRUFBRTtBQURTLE9BRGQ7QUFJUCxpQkFBVztBQUNQLDZCQUFxQjtBQUNqQkEsZ0JBQU0sRUFBRTtBQURTO0FBRGQ7QUFKSixLQTNDQztBQXFEWm1DLGFBQVMsRUFBQztBQUNOYixZQUFNLEVBQUM7QUFERDtBQXJERSxHQURFO0FBMERsQkMsZUFBYSxFQUFFO0FBQ1h0RSxRQUFJLEVBQUU7QUFDRlcsV0FBSyxFQUFFLE1BREw7QUFFRjRELGNBQVEsRUFBRSxRQUZSO0FBR0ZDLGtCQUFZLEVBQUUsVUFIWjtBQUlGQyxnQkFBVSxFQUFFLFFBSlY7QUFLRm5FLFdBQUssRUFBRUEsOENBQUssQ0FBQ3JCLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQm9ELFVBTDNCO0FBTUZyQyxjQUFRLEVBQUVpQixtREFBSSxDQUFDa0MsRUFBTCxDQUFRbkQsUUFOaEI7QUFPRixxQkFBZTtBQUNYSyxhQUFLLEVBQUVBLDhDQUFLLENBQUNyQixPQUFOLENBQWNDLE9BQWQsQ0FBc0JvRDtBQURsQixPQVBiO0FBVUYsZUFBUTtBQUNKM0IsYUFBSyxFQUFFLE1BREg7QUFFSjRELGdCQUFRLEVBQUUsUUFGTjtBQUdKQyxvQkFBWSxFQUFFLFVBSFY7QUFJSkMsa0JBQVUsRUFBRTtBQUpSO0FBVk4sS0FESztBQWtCWFUsVUFBTSxFQUFFO0FBQ0pDLGVBQVMsRUFBRSxnQ0FEUDtBQUVKSixrQkFBWSxFQUFDLE1BRlQ7QUFHSixnQ0FBMEI7QUFDdEJJLGlCQUFTLEVBQUU7QUFEVztBQUh0QjtBQWxCRyxHQTFERztBQW9GbEJDLGNBQVksRUFBRTtBQUNWckYsUUFBSSxFQUFFO0FBQ0ZhLGtCQUFZLEVBQUU7QUFEWjtBQURJLEdBcEZJO0FBeUZsQnlFLGdCQUFjLEVBQUU7QUFDWnRGLFFBQUksRUFBRTtBQUNGYSxrQkFBWSxFQUFFLE1BRFo7QUFFRixvQkFBYztBQUNWQSxvQkFBWSxFQUFFO0FBREo7QUFGWjtBQURNO0FBekZFLENBQXRCO0FBbUdlb0QsNEVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxNQUFNc0IsT0FBTyxHQUFHO0FBQ1pDLFdBQVMsZ0tBQ0ZDLHNEQURFLEdBRUZDLHFEQUZFLEdBR0ZDLHFEQUhFLEdBSUZDLHdEQUpFLEdBS0ZDLHNEQUxFLEdBTUZDLG9EQU5FLEdBT0ZDLHNEQVBFLEdBUUZDLHNEQVJFLEdBU0ZDLDJEQVRFLEdBVUZuRyxxREFWRSxHQVdGb0csb0RBWEU7QUFERyxDQUFoQjtBQWdCZVgsc0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDM0JBO0FBQUE7QUFBQTtBQUVBLE1BQU1VLGtCQUFrQixHQUFHO0FBQ3ZCRSxtQkFBaUIsRUFBRTtBQUNmbkcsUUFBSSxFQUFFO0FBQ0ZxRSxZQUFNLEVBQUU7QUFETixLQURTO0FBSWYrQixnQkFBWSxFQUFFO0FBQ1Y3RixxQkFBZSxFQUFFRCw4Q0FBSyxDQUFDeUIsTUFBTixDQUFhQztBQURwQixLQUpDO0FBT2ZxRSxtQkFBZSxFQUFFO0FBQ2I5RixxQkFBZSxFQUFFRCw4Q0FBSyxDQUFDckIsT0FBTixDQUFjb0QsT0FBZCxDQUFzQmxEO0FBRDFCO0FBUEY7QUFESSxDQUEzQjtBQWFlOEcsaUZBQWYsRTs7Ozs7Ozs7Ozs7O0FDaEJBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFFQSxNQUFNSyxhQUFhLEdBQUc7QUFDbEJDLFVBQVEsRUFBRTtBQUNOdkcsUUFBSSxFQUFFO0FBQ0Ysa0NBQTRCO0FBQ3hCTSxhQUFLLEVBQUVBLDhDQUFLLENBQUNyQixPQUFOLENBQWNDLE9BQWQsQ0FBc0JvRDtBQURMLE9BRDFCO0FBSUYsa0JBQVc7QUFDUCw4QkFBc0I7QUFDbEJyQyxrQkFBUSxFQUFFaUIsbURBQUksQ0FBQzhCLEVBQUwsQ0FBUS9DO0FBREEsU0FEZjtBQUlQLHdDQUErQjtBQUMzQmdELG9CQUFVLEVBQUM7QUFEZ0I7QUFKeEIsT0FKVDtBQVlGLDRCQUFzQjtBQUNsQjNDLGFBQUssRUFBRSxhQURXO0FBRWxCeUMsY0FBTSxFQUFHLGFBQVl6Qyw4Q0FBSyxDQUFDckIsT0FBTixDQUFjQyxPQUFkLENBQXNCb0QsVUFBVyxFQUZwQztBQUdsQnJDLGdCQUFRLEVBQUVpQixtREFBSSxDQUFDc0YsSUFBTCxDQUFVdkcsUUFIRjtBQUlsQmtDLG9CQUFZLEVBQUUsS0FKSTtBQUtsQjVCLHVCQUFlLEVBQUVELDhDQUFLLENBQUN5QixNQUFOLENBQWFDO0FBTFosT0FacEI7QUFtQkYsdUJBQWlCO0FBQ2IsOEJBQXNCO0FBQ2xCMUIsZUFBSyxFQUFFQSw4Q0FBSyxDQUFDckIsT0FBTixDQUFjd0gsU0FBZCxDQUF3QkM7QUFEYjtBQURUO0FBbkJmO0FBREE7QUFEUSxDQUF0QjtBQThCZUosNEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDakNBO0FBQUE7QUFBQTtBQUVBLE1BQU1QLGFBQWEsR0FBRztBQUNsQlksV0FBUyxFQUFFO0FBQ1B4RyxRQUFJLEVBQUU7QUFDRnlHLGdCQUFVLEVBQUV0Ryw4Q0FBSyxDQUFDckIsT0FBTixDQUFjNEgsS0FBZCxDQUFvQkMsY0FEOUI7QUFFRnpDLFlBQU0sRUFBRSxNQUZOO0FBR0ZsQyxrQkFBWSxFQUFFLGVBSFo7QUFJRmxCLGNBQVEsRUFBRSxNQUpSO0FBS0Y4QyxTQUFHLEVBQUUsS0FMSDtBQU1GekQsV0FBSyxFQUFFO0FBTkwsS0FEQztBQVNQeUcsY0FBVSxFQUFFO0FBQ1JqRCxXQUFLLEVBQUU7QUFEQyxLQVRMO0FBWVBrRCxVQUFNLEVBQUU7QUFDSm5ELGNBQVEsRUFBRSxVQUROO0FBRUosa0JBQVk7QUFDUm9ELGVBQU8sRUFBRSxVQUREO0FBRVJwRCxnQkFBUSxFQUFFLFVBRkY7QUFHUkMsYUFBSyxFQUFFLE1BSEM7QUFJUm9ELGNBQU0sRUFBRSxHQUpBO0FBS1IzRixrQkFBVSxFQUFFLG9CQUxKO0FBTVJ3QyxXQUFHLEVBQUUsTUFORztBQU9SOUQsZ0JBQVEsRUFBRTtBQVBGLE9BRlI7QUFXSixpQkFBVztBQUNQTSx1QkFBZSxFQUFFO0FBRFY7QUFYUDtBQVpELEdBRE87QUE2QmxCNEcsWUFBVSxFQUFFO0FBQ1J6RCxTQUFLLEVBQUU7QUFDSHZCLGtCQUFZLEVBQUU7QUFEWDtBQURDO0FBN0JNLENBQXRCO0FBb0NlNEQsNEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDdENBO0FBQUE7QUFBQTtBQUVBLE1BQU1xQixjQUFjLEdBQUc7QUFDbkJDLFdBQVMsRUFBRTtBQUNQckgsUUFBSSxFQUFFO0FBQ0ZXLFdBQUssRUFBRSxNQURMO0FBRUYwRCxZQUFNLEVBQUUsTUFGTjtBQUdGbkUsYUFBTyxFQUFFO0FBSFAsS0FEQztBQU1Qb0gsU0FBSyxFQUFFO0FBQ0gzRyxXQUFLLEVBQUUsTUFESjtBQUVIb0MsWUFBTSxFQUFHLGFBQVl6Qyw4Q0FBSyxDQUFDckIsT0FBTixDQUFjQyxPQUFkLENBQXNCbUUsS0FBTSxFQUY5QztBQUdIZ0IsWUFBTSxFQUFFLE1BSEw7QUFJSFIsY0FBUSxFQUFFLFVBSlA7QUFLSDNCLGVBQVMsRUFBRSxNQUxSO0FBTUhxRixlQUFTLEVBQUUsWUFOUjtBQU9IaEgscUJBQWUsRUFBRUQsOENBQUssQ0FBQ3lCLE1BQU4sQ0FBYUMsS0FQM0I7QUFRSCxpQkFBVztBQUNQaUYsZUFBTyxFQUFFLElBREY7QUFFUHRHLGFBQUssRUFBRSxNQUZBO0FBR1AwRCxjQUFNLEVBQUUsTUFIRDtBQUlQdEIsY0FBTSxFQUFHLGFBQVl6Qyw4Q0FBSyxDQUFDckIsT0FBTixDQUFjQyxPQUFkLENBQXNCbUUsS0FBTSxFQUoxQztBQUtQUSxnQkFBUSxFQUFFLFVBTEg7QUFNUDJELFlBQUksRUFBRSxLQU5DO0FBT1B6RCxXQUFHLEVBQUUsS0FQRTtBQVFQcUIsaUJBQVMsRUFBRSx1QkFSSjtBQVNQakQsb0JBQVksRUFBRTtBQVRQO0FBUlIsS0FOQTtBQTBCUHNGLGNBQVUsRUFBRTtBQUNSdkgsYUFBTyxFQUFFLENBREQ7QUFFUndILFlBQU0sRUFBRSxDQUZBO0FBR1JDLHdCQUFrQixFQUFFLE9BSFo7QUFJUix1QkFBaUI7QUFDYnZDLGlCQUFTLEVBQUUsa0JBREU7QUFFYjlFLGFBQUssRUFBRUEsOENBQUssQ0FBQ3lCLE1BQU4sQ0FBYUMsS0FGUDtBQUdiLGdDQUF3QjtBQUNwQnpCLHlCQUFlLEVBQUcsR0FBRUQsOENBQUssQ0FBQ3JCLE9BQU4sQ0FBY3dILFNBQWQsQ0FBd0JDLElBQUssYUFEN0I7QUFFcEJrQixpQkFBTyxFQUFFO0FBRlcsU0FIWDtBQU9iLDZDQUFxQztBQUNqQ0EsaUJBQU8sRUFBRTtBQUR3QjtBQVB4QjtBQUpULEtBMUJMO0FBMENQQyxTQUFLLEVBQUU7QUFDSDlFLFlBQU0sRUFBRyxhQUFZekMsOENBQUssQ0FBQ3JCLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQm1FLEtBQU0sRUFEOUM7QUFFSHVFLGFBQU8sRUFBRSxHQUZOO0FBR0hFLGdCQUFVLEVBQUUseURBSFQ7QUFJSDNGLGtCQUFZLEVBQUUsTUFKWDtBQUtINUIscUJBQWUsRUFBRUQsOENBQUssQ0FBQ3lCLE1BQU4sQ0FBYWdHO0FBTDNCO0FBMUNBO0FBRFEsQ0FBdkI7QUFvRGVYLDZFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3REQTtBQUFBO0FBQUE7QUFFQSxNQUFNbEIsVUFBVSxHQUFHO0FBQ2Y4QixTQUFPLEVBQUU7QUFDTGhJLFFBQUksRUFBRTtBQUNGaUIsY0FBUSxFQUFFLE9BRFI7QUFHRiw0QkFBc0I7QUFDbEIyRyxlQUFPLEVBQUUsT0FEUztBQUVsQjNHLGdCQUFRLEVBQUU7QUFGUTtBQUhwQixLQUREO0FBU0x3QixXQUFPLEVBQUU7QUFDTEMsZ0JBQVUsRUFBRTtBQURQLEtBVEo7QUFZTHVGLFlBQVEsRUFBRTtBQUNOdkQsZUFBUyxFQUFFO0FBREw7QUFaTCxHQURNO0FBaUJmd0QsUUFBTSxFQUFFO0FBQ0psSSxRQUFJLEVBQUU7QUFDRjRILGFBQU8sRUFBRSxrQkFEUDtBQUVGM0csY0FBUSxFQUFFLGtCQUZSO0FBR0ZtQixtQkFBYSxFQUFFLE1BSGI7QUFJRnNGLFlBQU0sRUFBRSxRQUpOO0FBS0Ysd0JBQWtCO0FBQ2RuSCx1QkFBZSxFQUFFRCw4Q0FBSyxDQUFDckIsT0FBTixDQUFjd0gsU0FBZCxDQUF3QnRILElBRDNCO0FBRWRnRiwyQkFBbUIsRUFBRSxNQUZQO0FBR2RnRSw4QkFBc0IsRUFBRSxNQUhWO0FBSWQ3RyxpQkFBUyxFQUFFLE1BSkc7QUFLZCx3QkFBZ0I7QUFDWmxCLGlCQUFPLEVBQUU7QUFERztBQUxGO0FBTGhCLEtBREY7QUFnQkpnSSxXQUFPLEVBQUU7QUFDTEMsbUJBQWEsRUFBRSxTQURWO0FBRUxDLG9CQUFjLEVBQUU7QUFGWDtBQWhCTCxHQWpCTztBQXNDZkMscUJBQW1CLEVBQUU7QUFDakJ2SSxRQUFJLEVBQUU7QUFDRkksYUFBTyxFQUFFO0FBRFA7QUFEVztBQXRDTixDQUFuQjtBQTZDZThGLHlFQUFmLEU7Ozs7Ozs7Ozs7OztBQy9DQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQWU7QUFDWHNDLGFBQVcsRUFBRTtBQUNUQyxVQUFNLEVBQUU7QUFDSkMsUUFBRSxFQUFFLENBREE7QUFFSnJILFFBQUUsRUFBRSxHQUZBO0FBR0pzSCxRQUFFLEVBQUUsR0FIQTtBQUlKcEcsUUFBRSxFQUFFLElBSkE7QUFLSnFHLFFBQUUsRUFBRSxJQUxBO0FBTUpDLFNBQUcsRUFBRSxJQU5EO0FBT0pDLFFBQUUsRUFBRTtBQVBBO0FBREM7QUFERixDQUFmLEU7Ozs7Ozs7Ozs7OztBQ0FBO0FBQUEsTUFBTUMsWUFBWSxHQUFHO0FBQ2pCaEgsUUFBTSxFQUFFO0FBQ0pDLFNBQUssRUFBRSxNQURIO0FBRUpnSCxTQUFLLEVBQUUsTUFGSDtBQUdKakIsUUFBSSxFQUFFLFNBSEY7QUFJSnZGLGdCQUFZLEVBQUUsU0FKVjtBQUtKeUcsYUFBUyxFQUFFLFNBTFA7QUFNSkMsWUFBUSxFQUFFLFNBTk47QUFPSkMsa0JBQWMsRUFBRSxTQVBaO0FBUUpDLG9CQUFnQixFQUFFLFNBUmQ7QUFTSkMsY0FBVSxFQUFFO0FBVFIsR0FEUztBQWFqQnBLLFNBQU8sRUFBRTtBQUNMQyxXQUFPLEVBQUU7QUFDTEMsVUFBSSxFQUFFLFNBREQ7QUFFTGtFLFdBQUssRUFBRSxTQUZGO0FBR0xmLGdCQUFVLEVBQUU7QUFIUCxLQURKO0FBTUxtRSxhQUFTLEVBQUU7QUFDUEMsVUFBSSxFQUFFLFNBREM7QUFFUHZILFVBQUksRUFBRSxTQUZDO0FBR1BrRSxXQUFLLEVBQUUsU0FIQTtBQUlQZixnQkFBVSxFQUFFO0FBSkwsS0FOTjtBQVlMc0MsU0FBSyxFQUFFO0FBQ0g4QixVQUFJLEVBQUUsU0FESDtBQUVIdkgsVUFBSSxFQUFFLFNBRkg7QUFHSGtFLFdBQUssRUFBRSxTQUhKO0FBSUhmLGdCQUFVLEVBQUU7QUFKVCxLQVpGO0FBa0JMZ0gsV0FBTyxFQUFFO0FBQ0xuSyxVQUFJLEVBQUUsU0FERDtBQUVMa0UsV0FBSyxFQUFFLFNBRkY7QUFHTGYsZ0JBQVUsRUFBRTtBQUhQLEtBbEJKO0FBdUJMRCxXQUFPLEVBQUU7QUFDTGxELFVBQUksRUFBRSxTQUREO0FBRUxrRSxXQUFLLEVBQUUsU0FGRjtBQUdMZixnQkFBVSxFQUFFO0FBSFAsS0F2Qko7QUE0QkxpSCxRQUFJLEVBQUU7QUFDRnBLLFVBQUksRUFBRTtBQURKLEtBNUJEO0FBK0JMcUssV0FBTyxFQUFFO0FBQ0xySyxVQUFJLEVBQUU7QUFERCxLQS9CSjtBQWtDTHlDLFVBQU0sRUFBRTtBQUNKQyxvQkFBYyxFQUFFO0FBRFosS0FsQ0g7QUFxQ0xnRixTQUFLLEVBQUU7QUFDSEMsb0JBQWMsRUFBRTtBQURiLEtBckNGO0FBd0NMMkMsZUFBVyxFQUFFO0FBQ1R0SyxVQUFJLEVBQUU7QUFERztBQXhDUjtBQWJRLENBQXJCO0FBMkRlNEosMkVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNEQTtBQUNBO0FBQ0E7QUFDQTtDQUdBOztBQUNBLE1BQU0vSixLQUFLLEdBQUcwSyw0RUFBVztBQUNyQmpRLE9BQUssRUFBRTtBQUNIO0FBQ0FrUSxnQkFBWSxFQUFFO0FBQ1Y7QUFDQUMsa0JBQVksRUFBRSxJQUZKLENBRVM7O0FBRlQ7QUFGWCxHQURjO0FBUXJCQyxpRUFBVUE7QUFSVyxHQVNsQnJCLG9EQVRrQixHQVVsQmxJLDhDQVZrQixHQVdsQndKLGdEQVhrQixFQUF6QjtBQWNlOUssb0VBQWYsRTs7Ozs7Ozs7Ozs7O0FGckJBO0FBQWU7QUFDWCtLLGlCQUFlLEVBQUUsSUFETjtBQUVYOUosVUFBUSxFQUFFLEVBRkM7QUFJWCtKLElBQUUsRUFBRTtBQUNBL0osWUFBUSxFQUFFO0FBRFYsR0FKTztBQU9YZ0ssSUFBRSxFQUFFO0FBQ0FoSyxZQUFRLEVBQUU7QUFEVixHQVBPO0FBVVh1RyxNQUFJLEVBQUU7QUFDRnZHLFlBQVEsRUFBRTtBQURSLEdBVks7QUFhWGlLLElBQUUsRUFBRTtBQUNBakssWUFBUSxFQUFFO0FBRFYsR0FiTztBQWdCWCtELE1BQUksRUFBRTtBQUNGL0QsWUFBUSxFQUFFO0FBRFIsR0FoQks7QUFtQlgrQyxJQUFFLEVBQUU7QUFDQS9DLFlBQVEsRUFBRTtBQURWLEdBbkJPO0FBc0JYMEUsTUFBSSxFQUFFO0FBQ0YxRSxZQUFRLEVBQUU7QUFEUixHQXRCSztBQXlCWGtCLElBQUUsRUFBRTtBQUNBbEIsWUFBUSxFQUFFO0FBRFYsR0F6Qk87QUE0QlhtRCxJQUFFLEVBQUU7QUFDQW5ELFlBQVEsRUFBRTtBQURWLEdBNUJPO0FBK0JYc0MsSUFBRSxFQUFFO0FBQ0F0QyxZQUFRLEVBQUU7QUFEVixHQS9CTztBQWtDWGtLLE1BQUksRUFBRTtBQUNGbEssWUFBUSxFQUFFO0FBRFIsR0FsQ0s7QUFxQ1gwSSxJQUFFLEVBQUU7QUFDQTFJLFlBQVEsRUFBRTtBQURWLEdBckNPO0FBd0NYb0IsSUFBRSxFQUFFO0FBQ0FwQixZQUFRLEVBQUU7QUFEVixHQXhDTztBQTJDWHlJLElBQUUsRUFBRTtBQUNBekksWUFBUSxFQUFFO0FBRFYsR0EzQ087QUErQ1hzQixZQUFVLEVBQUU7QUFDUkMsV0FBTyxFQUFFLGlCQUREO0FBRVJFLFVBQU0sRUFBRSxnQkFGQTtBQUdSMEksWUFBUSxFQUFFLGtCQUhGO0FBSVJDLFFBQUksRUFBRSxjQUpFO0FBS1JDLGFBQVMsRUFBRTtBQUxILEdBL0NEO0FBc0RYbEksZUFBYSxFQUFFO0FBQ1htSSxhQUFTLEVBQUU7QUFEQTtBQXRESixDQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FHQUEscUQ7Ozs7Ozs7Ozs7O0FDQUEsdUM7Ozs7Ozs7Ozs7O0FDQUEsa0M7Ozs7Ozs7Ozs7O0FDQUEsa0Q7Ozs7Ozs7Ozs7O0FDQUEsOEMiLCJmaWxlIjoicGFnZXMvX2RvY3VtZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSByZXF1aXJlKCcuLi9zc3ItbW9kdWxlLWNhY2hlLmpzJyk7XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdHZhciB0aHJldyA9IHRydWU7XG4gXHRcdHRyeSB7XG4gXHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG4gXHRcdFx0dGhyZXcgPSBmYWxzZTtcbiBcdFx0fSBmaW5hbGx5IHtcbiBcdFx0XHRpZih0aHJldykgZGVsZXRlIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHR9XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IDEpO1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9jb25zdGFudHMuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9kb2N1bWVudC1jb250ZXh0LmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvdXRpbHMuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9nZXQtcGFnZS1maWxlcy5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvc2VydmVyL3V0aWxzLmpzXCIpOyIsImltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcydcbmltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQsIFJlYWN0RWxlbWVudCwgUmVhY3ROb2RlLCB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgZmx1c2ggZnJvbSAnc3R5bGVkLWpzeC9zZXJ2ZXInXG5pbXBvcnQge1xuICBBTVBfUkVOREVSX1RBUkdFVCxcbiAgT1BUSU1JWkVEX0ZPTlRfUFJPVklERVJTLFxufSBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvY29uc3RhbnRzJ1xuaW1wb3J0IHsgRG9jdW1lbnRDb250ZXh0IGFzIERvY3VtZW50Q29tcG9uZW50Q29udGV4dCB9IGZyb20gJy4uL25leHQtc2VydmVyL2xpYi9kb2N1bWVudC1jb250ZXh0J1xuaW1wb3J0IHtcbiAgRG9jdW1lbnRDb250ZXh0LFxuICBEb2N1bWVudEluaXRpYWxQcm9wcyxcbiAgRG9jdW1lbnRQcm9wcyxcbn0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3V0aWxzJ1xuaW1wb3J0IHtcbiAgQnVpbGRNYW5pZmVzdCxcbiAgZ2V0UGFnZUZpbGVzLFxufSBmcm9tICcuLi9uZXh0LXNlcnZlci9zZXJ2ZXIvZ2V0LXBhZ2UtZmlsZXMnXG5pbXBvcnQgeyBjbGVhbkFtcFBhdGggfSBmcm9tICcuLi9uZXh0LXNlcnZlci9zZXJ2ZXIvdXRpbHMnXG5pbXBvcnQgeyBodG1sRXNjYXBlSnNvblN0cmluZyB9IGZyb20gJy4uL3NlcnZlci9odG1sZXNjYXBlJ1xuXG5leHBvcnQgeyBEb2N1bWVudENvbnRleHQsIERvY3VtZW50SW5pdGlhbFByb3BzLCBEb2N1bWVudFByb3BzIH1cblxuZXhwb3J0IHR5cGUgT3JpZ2luUHJvcHMgPSB7XG4gIG5vbmNlPzogc3RyaW5nXG4gIGNyb3NzT3JpZ2luPzogc3RyaW5nXG59XG5cbmZ1bmN0aW9uIGRlZHVwZTxUIGV4dGVuZHMgeyBmaWxlOiBzdHJpbmcgfT4oYnVuZGxlczogVFtdKTogVFtdIHtcbiAgY29uc3QgZmlsZXMgPSBuZXcgU2V0PHN0cmluZz4oKVxuICBjb25zdCBrZXB0OiBUW10gPSBbXVxuXG4gIGZvciAoY29uc3QgYnVuZGxlIG9mIGJ1bmRsZXMpIHtcbiAgICBpZiAoZmlsZXMuaGFzKGJ1bmRsZS5maWxlKSkgY29udGludWVcbiAgICBmaWxlcy5hZGQoYnVuZGxlLmZpbGUpXG4gICAga2VwdC5wdXNoKGJ1bmRsZSlcbiAgfVxuICByZXR1cm4ga2VwdFxufVxuXG50eXBlIERvY3VtZW50RmlsZXMgPSB7XG4gIHNoYXJlZEZpbGVzOiByZWFkb25seSBzdHJpbmdbXVxuICBwYWdlRmlsZXM6IHJlYWRvbmx5IHN0cmluZ1tdXG4gIGFsbEZpbGVzOiByZWFkb25seSBzdHJpbmdbXVxufVxuXG5mdW5jdGlvbiBnZXREb2N1bWVudEZpbGVzKFxuICBidWlsZE1hbmlmZXN0OiBCdWlsZE1hbmlmZXN0LFxuICBwYXRobmFtZTogc3RyaW5nLFxuICBpbkFtcE1vZGU6IGJvb2xlYW5cbik6IERvY3VtZW50RmlsZXMge1xuICBjb25zdCBzaGFyZWRGaWxlczogcmVhZG9ubHkgc3RyaW5nW10gPSBnZXRQYWdlRmlsZXMoYnVpbGRNYW5pZmVzdCwgJy9fYXBwJylcbiAgY29uc3QgcGFnZUZpbGVzOiByZWFkb25seSBzdHJpbmdbXSA9IGluQW1wTW9kZVxuICAgID8gW11cbiAgICA6IGdldFBhZ2VGaWxlcyhidWlsZE1hbmlmZXN0LCBwYXRobmFtZSlcblxuICByZXR1cm4ge1xuICAgIHNoYXJlZEZpbGVzLFxuICAgIHBhZ2VGaWxlcyxcbiAgICBhbGxGaWxlczogWy4uLm5ldyBTZXQoWy4uLnNoYXJlZEZpbGVzLCAuLi5wYWdlRmlsZXNdKV0sXG4gIH1cbn1cblxuLyoqXG4gKiBgRG9jdW1lbnRgIGNvbXBvbmVudCBoYW5kbGVzIHRoZSBpbml0aWFsIGBkb2N1bWVudGAgbWFya3VwIGFuZCByZW5kZXJzIG9ubHkgb24gdGhlIHNlcnZlciBzaWRlLlxuICogQ29tbW9ubHkgdXNlZCBmb3IgaW1wbGVtZW50aW5nIHNlcnZlciBzaWRlIHJlbmRlcmluZyBmb3IgYGNzcy1pbi1qc2AgbGlicmFyaWVzLlxuICovXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBEb2N1bWVudDxQID0ge30+IGV4dGVuZHMgQ29tcG9uZW50PERvY3VtZW50UHJvcHMgJiBQPiB7XG4gIHN0YXRpYyBoZWFkVGFnc01pZGRsZXdhcmUgPSBwcm9jZXNzLmVudi5fX05FWFRfUExVR0lOU1xuICAgID8gaW1wb3J0KFxuICAgICAgICAvLyBAdHMtaWdub3JlIGxvYWRlciBzeW50YXhcbiAgICAgICAgJ25leHQtcGx1Z2luLWxvYWRlcj9taWRkbGV3YXJlPWRvY3VtZW50LWhlYWQtdGFncy1zZXJ2ZXIhJ1xuICAgICAgKVxuICAgIDogKCkgPT4gW11cblxuICAvKipcbiAgICogYGdldEluaXRpYWxQcm9wc2AgaG9vayByZXR1cm5zIHRoZSBjb250ZXh0IG9iamVjdCB3aXRoIHRoZSBhZGRpdGlvbiBvZiBgcmVuZGVyUGFnZWAuXG4gICAqIGByZW5kZXJQYWdlYCBjYWxsYmFjayBleGVjdXRlcyBgUmVhY3RgIHJlbmRlcmluZyBsb2dpYyBzeW5jaHJvbm91c2x5IHRvIHN1cHBvcnQgc2VydmVyLXJlbmRlcmluZyB3cmFwcGVyc1xuICAgKi9cbiAgc3RhdGljIGFzeW5jIGdldEluaXRpYWxQcm9wcyhcbiAgICBjdHg6IERvY3VtZW50Q29udGV4dFxuICApOiBQcm9taXNlPERvY3VtZW50SW5pdGlhbFByb3BzPiB7XG4gICAgY29uc3QgZW5oYW5jZUFwcCA9IChBcHA6IGFueSkgPT4ge1xuICAgICAgcmV0dXJuIChwcm9wczogYW55KSA9PiA8QXBwIHsuLi5wcm9wc30gLz5cbiAgICB9XG5cbiAgICBjb25zdCB7IGh0bWwsIGhlYWQgfSA9IGF3YWl0IGN0eC5yZW5kZXJQYWdlKHsgZW5oYW5jZUFwcCB9KVxuICAgIGNvbnN0IHN0eWxlcyA9IFsuLi5mbHVzaCgpXVxuICAgIHJldHVybiB7IGh0bWwsIGhlYWQsIHN0eWxlcyB9XG4gIH1cblxuICBzdGF0aWMgcmVuZGVyRG9jdW1lbnQ8UD4oXG4gICAgRG9jdW1lbnRDb21wb25lbnQ6IG5ldyAoKSA9PiBEb2N1bWVudDxQPixcbiAgICBwcm9wczogRG9jdW1lbnRQcm9wcyAmIFBcbiAgKTogUmVhY3QuUmVhY3RFbGVtZW50IHtcbiAgICByZXR1cm4gKFxuICAgICAgPERvY3VtZW50Q29tcG9uZW50Q29udGV4dC5Qcm92aWRlciB2YWx1ZT17cHJvcHN9PlxuICAgICAgICA8RG9jdW1lbnRDb21wb25lbnQgey4uLnByb3BzfSAvPlxuICAgICAgPC9Eb2N1bWVudENvbXBvbmVudENvbnRleHQuUHJvdmlkZXI+XG4gICAgKVxuICB9XG5cbiAgcmVuZGVyKCkge1xuICAgIHJldHVybiAoXG4gICAgICA8SHRtbD5cbiAgICAgICAgPEhlYWQgLz5cbiAgICAgICAgPGJvZHk+XG4gICAgICAgICAgPE1haW4gLz5cbiAgICAgICAgICA8TmV4dFNjcmlwdCAvPlxuICAgICAgICA8L2JvZHk+XG4gICAgICA8L0h0bWw+XG4gICAgKVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBIdG1sKFxuICBwcm9wczogUmVhY3QuRGV0YWlsZWRIVE1MUHJvcHM8XG4gICAgUmVhY3QuSHRtbEhUTUxBdHRyaWJ1dGVzPEhUTUxIdG1sRWxlbWVudD4sXG4gICAgSFRNTEh0bWxFbGVtZW50XG4gID5cbikge1xuICBjb25zdCB7IGluQW1wTW9kZSwgZG9jQ29tcG9uZW50c1JlbmRlcmVkLCBsb2NhbGUgfSA9IHVzZUNvbnRleHQoXG4gICAgRG9jdW1lbnRDb21wb25lbnRDb250ZXh0XG4gIClcblxuICBkb2NDb21wb25lbnRzUmVuZGVyZWQuSHRtbCA9IHRydWVcblxuICByZXR1cm4gKFxuICAgIDxodG1sXG4gICAgICB7Li4ucHJvcHN9XG4gICAgICBsYW5nPXtwcm9wcy5sYW5nIHx8IGxvY2FsZSB8fCB1bmRlZmluZWR9XG4gICAgICBhbXA9e2luQW1wTW9kZSA/ICcnIDogdW5kZWZpbmVkfVxuICAgICAgZGF0YS1hbXBkZXZtb2RlPXtcbiAgICAgICAgaW5BbXBNb2RlICYmIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicgPyAnJyA6IHVuZGVmaW5lZFxuICAgICAgfVxuICAgIC8+XG4gIClcbn1cblxuZXhwb3J0IGNsYXNzIEhlYWQgZXh0ZW5kcyBDb21wb25lbnQ8XG4gIE9yaWdpblByb3BzICZcbiAgICBSZWFjdC5EZXRhaWxlZEhUTUxQcm9wczxcbiAgICAgIFJlYWN0LkhUTUxBdHRyaWJ1dGVzPEhUTUxIZWFkRWxlbWVudD4sXG4gICAgICBIVE1MSGVhZEVsZW1lbnRcbiAgICA+XG4+IHtcbiAgc3RhdGljIGNvbnRleHRUeXBlID0gRG9jdW1lbnRDb21wb25lbnRDb250ZXh0XG5cbiAgc3RhdGljIHByb3BUeXBlcyA9IHtcbiAgICBub25jZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgICBjcm9zc09yaWdpbjogUHJvcFR5cGVzLnN0cmluZyxcbiAgfVxuXG4gIGNvbnRleHQhOiBSZWFjdC5Db250ZXh0VHlwZTx0eXBlb2YgRG9jdW1lbnRDb21wb25lbnRDb250ZXh0PlxuXG4gIGdldENzc0xpbmtzKGZpbGVzOiBEb2N1bWVudEZpbGVzKTogSlNYLkVsZW1lbnRbXSB8IG51bGwge1xuICAgIGNvbnN0IHtcbiAgICAgIGFzc2V0UHJlZml4LFxuICAgICAgZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmcsXG4gICAgICBkeW5hbWljSW1wb3J0cyxcbiAgICB9ID0gdGhpcy5jb250ZXh0XG4gICAgY29uc3QgY3NzRmlsZXMgPSBmaWxlcy5hbGxGaWxlcy5maWx0ZXIoKGYpID0+IGYuZW5kc1dpdGgoJy5jc3MnKSlcbiAgICBjb25zdCBzaGFyZWRGaWxlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KGZpbGVzLnNoYXJlZEZpbGVzKVxuXG4gICAgLy8gVW5tYW5hZ2VkIGZpbGVzIGFyZSBDU1MgZmlsZXMgdGhhdCB3aWxsIGJlIGhhbmRsZWQgZGlyZWN0bHkgYnkgdGhlXG4gICAgLy8gd2VicGFjayBydW50aW1lIChgbWluaS1jc3MtZXh0cmFjdC1wbHVnaW5gKS5cbiAgICBsZXQgdW5tYW5nZWRGaWxlczogU2V0PHN0cmluZz4gPSBuZXcgU2V0KFtdKVxuICAgIGxldCBkeW5hbWljQ3NzRmlsZXMgPSBkZWR1cGUoXG4gICAgICBkeW5hbWljSW1wb3J0cy5maWx0ZXIoKGYpID0+IGYuZmlsZS5lbmRzV2l0aCgnLmNzcycpKVxuICAgICkubWFwKChmKSA9PiBmLmZpbGUpXG4gICAgaWYgKGR5bmFtaWNDc3NGaWxlcy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IGV4aXN0aW5nID0gbmV3IFNldChjc3NGaWxlcylcbiAgICAgIGR5bmFtaWNDc3NGaWxlcyA9IGR5bmFtaWNDc3NGaWxlcy5maWx0ZXIoXG4gICAgICAgIChmKSA9PiAhKGV4aXN0aW5nLmhhcyhmKSB8fCBzaGFyZWRGaWxlcy5oYXMoZikpXG4gICAgICApXG4gICAgICB1bm1hbmdlZEZpbGVzID0gbmV3IFNldChkeW5hbWljQ3NzRmlsZXMpXG4gICAgICBjc3NGaWxlcy5wdXNoKC4uLmR5bmFtaWNDc3NGaWxlcylcbiAgICB9XG5cbiAgICBsZXQgY3NzTGlua0VsZW1lbnRzOiBKU1guRWxlbWVudFtdID0gW11cbiAgICBjc3NGaWxlcy5mb3JFYWNoKChmaWxlKSA9PiB7XG4gICAgICBjb25zdCBpc1NoYXJlZEZpbGUgPSBzaGFyZWRGaWxlcy5oYXMoZmlsZSlcblxuICAgICAgaWYgKCFwcm9jZXNzLmVudi5fX05FWFRfT1BUSU1JWkVfQ1NTKSB7XG4gICAgICAgIGNzc0xpbmtFbGVtZW50cy5wdXNoKFxuICAgICAgICAgIDxsaW5rXG4gICAgICAgICAgICBrZXk9e2Ake2ZpbGV9LXByZWxvYWRgfVxuICAgICAgICAgICAgbm9uY2U9e3RoaXMucHJvcHMubm9uY2V9XG4gICAgICAgICAgICByZWw9XCJwcmVsb2FkXCJcbiAgICAgICAgICAgIGhyZWY9e2Ake2Fzc2V0UHJlZml4fS9fbmV4dC8ke2VuY29kZVVSSShcbiAgICAgICAgICAgICAgZmlsZVxuICAgICAgICAgICAgKX0ke2Rldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nfWB9XG4gICAgICAgICAgICBhcz1cInN0eWxlXCJcbiAgICAgICAgICAgIGNyb3NzT3JpZ2luPXtcbiAgICAgICAgICAgICAgdGhpcy5wcm9wcy5jcm9zc09yaWdpbiB8fCBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOXG4gICAgICAgICAgICB9XG4gICAgICAgICAgLz5cbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBjb25zdCBpc1VubWFuYWdlZEZpbGUgPSB1bm1hbmdlZEZpbGVzLmhhcyhmaWxlKVxuICAgICAgY3NzTGlua0VsZW1lbnRzLnB1c2goXG4gICAgICAgIDxsaW5rXG4gICAgICAgICAga2V5PXtmaWxlfVxuICAgICAgICAgIG5vbmNlPXt0aGlzLnByb3BzLm5vbmNlfVxuICAgICAgICAgIHJlbD1cInN0eWxlc2hlZXRcIlxuICAgICAgICAgIGhyZWY9e2Ake2Fzc2V0UHJlZml4fS9fbmV4dC8ke2VuY29kZVVSSShcbiAgICAgICAgICAgIGZpbGVcbiAgICAgICAgICApfSR7ZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmd9YH1cbiAgICAgICAgICBjcm9zc09yaWdpbj17XG4gICAgICAgICAgICB0aGlzLnByb3BzLmNyb3NzT3JpZ2luIHx8IHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU5cbiAgICAgICAgICB9XG4gICAgICAgICAgZGF0YS1uLWc9e2lzVW5tYW5hZ2VkRmlsZSA/IHVuZGVmaW5lZCA6IGlzU2hhcmVkRmlsZSA/ICcnIDogdW5kZWZpbmVkfVxuICAgICAgICAgIGRhdGEtbi1wPXtpc1VubWFuYWdlZEZpbGUgPyB1bmRlZmluZWQgOiBpc1NoYXJlZEZpbGUgPyB1bmRlZmluZWQgOiAnJ31cbiAgICAgICAgLz5cbiAgICAgIClcbiAgICB9KVxuXG4gICAgaWYgKFxuICAgICAgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdkZXZlbG9wbWVudCcgJiZcbiAgICAgIHByb2Nlc3MuZW52Ll9fTkVYVF9PUFRJTUlaRV9GT05UU1xuICAgICkge1xuICAgICAgY3NzTGlua0VsZW1lbnRzID0gdGhpcy5tYWtlU3R5bGVzaGVldEluZXJ0KFxuICAgICAgICBjc3NMaW5rRWxlbWVudHNcbiAgICAgICkgYXMgUmVhY3RFbGVtZW50W11cbiAgICB9XG5cbiAgICByZXR1cm4gY3NzTGlua0VsZW1lbnRzLmxlbmd0aCA9PT0gMCA/IG51bGwgOiBjc3NMaW5rRWxlbWVudHNcbiAgfVxuXG4gIGdldFByZWxvYWREeW5hbWljQ2h1bmtzKCkge1xuICAgIGNvbnN0IHtcbiAgICAgIGR5bmFtaWNJbXBvcnRzLFxuICAgICAgYXNzZXRQcmVmaXgsXG4gICAgICBkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZyxcbiAgICB9ID0gdGhpcy5jb250ZXh0XG5cbiAgICByZXR1cm4gKFxuICAgICAgZGVkdXBlKGR5bmFtaWNJbXBvcnRzKVxuICAgICAgICAubWFwKChidW5kbGUpID0+IHtcbiAgICAgICAgICBpZiAoIWJ1bmRsZS5maWxlLmVuZHNXaXRoKCcuanMnKSkge1xuICAgICAgICAgICAgcmV0dXJuIG51bGxcbiAgICAgICAgICB9XG5cbiAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgPGxpbmtcbiAgICAgICAgICAgICAgcmVsPVwicHJlbG9hZFwiXG4gICAgICAgICAgICAgIGtleT17YnVuZGxlLmZpbGV9XG4gICAgICAgICAgICAgIGhyZWY9e2Ake2Fzc2V0UHJlZml4fS9fbmV4dC8ke2VuY29kZVVSSShcbiAgICAgICAgICAgICAgICBidW5kbGUuZmlsZVxuICAgICAgICAgICAgICApfSR7ZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmd9YH1cbiAgICAgICAgICAgICAgYXM9XCJzY3JpcHRcIlxuICAgICAgICAgICAgICBub25jZT17dGhpcy5wcm9wcy5ub25jZX1cbiAgICAgICAgICAgICAgY3Jvc3NPcmlnaW49e1xuICAgICAgICAgICAgICAgIHRoaXMucHJvcHMuY3Jvc3NPcmlnaW4gfHwgcHJvY2Vzcy5lbnYuX19ORVhUX0NST1NTX09SSUdJTlxuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIClcbiAgICAgICAgfSlcbiAgICAgICAgLy8gRmlsdGVyIG91dCBudWxsZWQgc2NyaXB0c1xuICAgICAgICAuZmlsdGVyKEJvb2xlYW4pXG4gICAgKVxuICB9XG5cbiAgZ2V0UHJlbG9hZE1haW5MaW5rcyhmaWxlczogRG9jdW1lbnRGaWxlcyk6IEpTWC5FbGVtZW50W10gfCBudWxsIHtcbiAgICBjb25zdCB7XG4gICAgICBhc3NldFByZWZpeCxcbiAgICAgIGRldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nLFxuICAgICAgc2NyaXB0TG9hZGVyLFxuICAgIH0gPSB0aGlzLmNvbnRleHRcbiAgICBjb25zdCBwcmVsb2FkRmlsZXMgPSBmaWxlcy5hbGxGaWxlcy5maWx0ZXIoKGZpbGU6IHN0cmluZykgPT4ge1xuICAgICAgcmV0dXJuIGZpbGUuZW5kc1dpdGgoJy5qcycpXG4gICAgfSlcblxuICAgIHJldHVybiBbXG4gICAgICAuLi4oc2NyaXB0TG9hZGVyLmVhZ2VyIHx8IFtdKS5tYXAoKGZpbGUpID0+IChcbiAgICAgICAgPGxpbmtcbiAgICAgICAgICBrZXk9e2ZpbGUuc3JjfVxuICAgICAgICAgIG5vbmNlPXt0aGlzLnByb3BzLm5vbmNlfVxuICAgICAgICAgIHJlbD1cInByZWxvYWRcIlxuICAgICAgICAgIGhyZWY9e2ZpbGUuc3JjfVxuICAgICAgICAgIGFzPVwic2NyaXB0XCJcbiAgICAgICAgICBjcm9zc09yaWdpbj17XG4gICAgICAgICAgICB0aGlzLnByb3BzLmNyb3NzT3JpZ2luIHx8IHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU5cbiAgICAgICAgICB9XG4gICAgICAgIC8+XG4gICAgICApKSxcbiAgICAgIC4uLnByZWxvYWRGaWxlcy5tYXAoKGZpbGU6IHN0cmluZykgPT4gKFxuICAgICAgICA8bGlua1xuICAgICAgICAgIGtleT17ZmlsZX1cbiAgICAgICAgICBub25jZT17dGhpcy5wcm9wcy5ub25jZX1cbiAgICAgICAgICByZWw9XCJwcmVsb2FkXCJcbiAgICAgICAgICBocmVmPXtgJHthc3NldFByZWZpeH0vX25leHQvJHtlbmNvZGVVUkkoXG4gICAgICAgICAgICBmaWxlXG4gICAgICAgICAgKX0ke2Rldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nfWB9XG4gICAgICAgICAgYXM9XCJzY3JpcHRcIlxuICAgICAgICAgIGNyb3NzT3JpZ2luPXtcbiAgICAgICAgICAgIHRoaXMucHJvcHMuY3Jvc3NPcmlnaW4gfHwgcHJvY2Vzcy5lbnYuX19ORVhUX0NST1NTX09SSUdJTlxuICAgICAgICAgIH1cbiAgICAgICAgLz5cbiAgICAgICkpLFxuICAgICAgLi4uKHNjcmlwdExvYWRlci5kZWZlciB8fCBbXSkubWFwKChmaWxlOiBzdHJpbmcpID0+IChcbiAgICAgICAgPGxpbmtcbiAgICAgICAgICBrZXk9e2ZpbGV9XG4gICAgICAgICAgbm9uY2U9e3RoaXMucHJvcHMubm9uY2V9XG4gICAgICAgICAgcmVsPVwicHJlbG9hZFwiXG4gICAgICAgICAgaHJlZj17ZmlsZX1cbiAgICAgICAgICBhcz1cInNjcmlwdFwiXG4gICAgICAgICAgY3Jvc3NPcmlnaW49e1xuICAgICAgICAgICAgdGhpcy5wcm9wcy5jcm9zc09yaWdpbiB8fCBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOXG4gICAgICAgICAgfVxuICAgICAgICAvPlxuICAgICAgKSksXG4gICAgXVxuICB9XG5cbiAgbWFrZVN0eWxlc2hlZXRJbmVydChub2RlOiBSZWFjdE5vZGUpOiBSZWFjdE5vZGVbXSB7XG4gICAgcmV0dXJuIFJlYWN0LkNoaWxkcmVuLm1hcChub2RlLCAoYzogYW55KSA9PiB7XG4gICAgICBpZiAoXG4gICAgICAgIGMudHlwZSA9PT0gJ2xpbmsnICYmXG4gICAgICAgIGMucHJvcHNbJ2hyZWYnXSAmJlxuICAgICAgICBPUFRJTUlaRURfRk9OVF9QUk9WSURFUlMuc29tZSgodXJsKSA9PiBjLnByb3BzWydocmVmJ10uc3RhcnRzV2l0aCh1cmwpKVxuICAgICAgKSB7XG4gICAgICAgIGNvbnN0IG5ld1Byb3BzID0geyAuLi4oYy5wcm9wcyB8fCB7fSkgfVxuICAgICAgICBuZXdQcm9wc1snZGF0YS1ocmVmJ10gPSBuZXdQcm9wc1snaHJlZiddXG4gICAgICAgIG5ld1Byb3BzWydocmVmJ10gPSB1bmRlZmluZWRcbiAgICAgICAgcmV0dXJuIFJlYWN0LmNsb25lRWxlbWVudChjLCBuZXdQcm9wcylcbiAgICAgIH0gZWxzZSBpZiAoYy5wcm9wcyAmJiBjLnByb3BzWydjaGlsZHJlbiddKSB7XG4gICAgICAgIGMucHJvcHNbJ2NoaWxkcmVuJ10gPSB0aGlzLm1ha2VTdHlsZXNoZWV0SW5lcnQoYy5wcm9wc1snY2hpbGRyZW4nXSlcbiAgICAgIH1cbiAgICAgIHJldHVybiBjXG4gICAgfSlcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7XG4gICAgICBzdHlsZXMsXG4gICAgICBhbXBQYXRoLFxuICAgICAgaW5BbXBNb2RlLFxuICAgICAgaHlicmlkQW1wLFxuICAgICAgY2Fub25pY2FsQmFzZSxcbiAgICAgIF9fTkVYVF9EQVRBX18sXG4gICAgICBkYW5nZXJvdXNBc1BhdGgsXG4gICAgICBoZWFkVGFncyxcbiAgICAgIHVuc3RhYmxlX3J1bnRpbWVKUyxcbiAgICAgIHVuc3RhYmxlX0pzUHJlbG9hZCxcbiAgICB9ID0gdGhpcy5jb250ZXh0XG4gICAgY29uc3QgZGlzYWJsZVJ1bnRpbWVKUyA9IHVuc3RhYmxlX3J1bnRpbWVKUyA9PT0gZmFsc2VcbiAgICBjb25zdCBkaXNhYmxlSnNQcmVsb2FkID0gdW5zdGFibGVfSnNQcmVsb2FkID09PSBmYWxzZVxuXG4gICAgdGhpcy5jb250ZXh0LmRvY0NvbXBvbmVudHNSZW5kZXJlZC5IZWFkID0gdHJ1ZVxuXG4gICAgbGV0IHsgaGVhZCB9ID0gdGhpcy5jb250ZXh0XG4gICAgbGV0IGNzc1ByZWxvYWRzOiBBcnJheTxKU1guRWxlbWVudD4gPSBbXVxuICAgIGxldCBvdGhlckhlYWRFbGVtZW50czogQXJyYXk8SlNYLkVsZW1lbnQ+ID0gW11cbiAgICBpZiAoaGVhZCkge1xuICAgICAgaGVhZC5mb3JFYWNoKChjKSA9PiB7XG4gICAgICAgIGlmIChcbiAgICAgICAgICBjICYmXG4gICAgICAgICAgYy50eXBlID09PSAnbGluaycgJiZcbiAgICAgICAgICBjLnByb3BzWydyZWwnXSA9PT0gJ3ByZWxvYWQnICYmXG4gICAgICAgICAgYy5wcm9wc1snYXMnXSA9PT0gJ3N0eWxlJ1xuICAgICAgICApIHtcbiAgICAgICAgICBjc3NQcmVsb2Fkcy5wdXNoKGMpXG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgYyAmJiBvdGhlckhlYWRFbGVtZW50cy5wdXNoKGMpXG4gICAgICAgIH1cbiAgICAgIH0pXG4gICAgICBoZWFkID0gY3NzUHJlbG9hZHMuY29uY2F0KG90aGVySGVhZEVsZW1lbnRzKVxuICAgIH1cbiAgICBsZXQgY2hpbGRyZW4gPSB0aGlzLnByb3BzLmNoaWxkcmVuXG4gICAgLy8gc2hvdyBhIHdhcm5pbmcgaWYgSGVhZCBjb250YWlucyA8dGl0bGU+IChvbmx5IGluIGRldmVsb3BtZW50KVxuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICBjaGlsZHJlbiA9IFJlYWN0LkNoaWxkcmVuLm1hcChjaGlsZHJlbiwgKGNoaWxkOiBhbnkpID0+IHtcbiAgICAgICAgY29uc3QgaXNSZWFjdEhlbG1ldCA9IGNoaWxkPy5wcm9wcz8uWydkYXRhLXJlYWN0LWhlbG1ldCddXG4gICAgICAgIGlmICghaXNSZWFjdEhlbG1ldCkge1xuICAgICAgICAgIGlmIChjaGlsZD8udHlwZSA9PT0gJ3RpdGxlJykge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICAgICBcIldhcm5pbmc6IDx0aXRsZT4gc2hvdWxkIG5vdCBiZSB1c2VkIGluIF9kb2N1bWVudC5qcydzIDxIZWFkPi4gaHR0cHM6Ly9lcnIuc2gvbmV4dC5qcy9uby1kb2N1bWVudC10aXRsZVwiXG4gICAgICAgICAgICApXG4gICAgICAgICAgfSBlbHNlIGlmIChcbiAgICAgICAgICAgIGNoaWxkPy50eXBlID09PSAnbWV0YScgJiZcbiAgICAgICAgICAgIGNoaWxkPy5wcm9wcz8ubmFtZSA9PT0gJ3ZpZXdwb3J0J1xuICAgICAgICAgICkge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICAgICBcIldhcm5pbmc6IHZpZXdwb3J0IG1ldGEgdGFncyBzaG91bGQgbm90IGJlIHVzZWQgaW4gX2RvY3VtZW50LmpzJ3MgPEhlYWQ+LiBodHRwczovL2Vyci5zaC9uZXh0LmpzL25vLWRvY3VtZW50LXZpZXdwb3J0LW1ldGFcIlxuICAgICAgICAgICAgKVxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY2hpbGRcbiAgICAgIH0pXG4gICAgICBpZiAodGhpcy5wcm9wcy5jcm9zc09yaWdpbilcbiAgICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICAgICdXYXJuaW5nOiBgSGVhZGAgYXR0cmlidXRlIGBjcm9zc09yaWdpbmAgaXMgZGVwcmVjYXRlZC4gaHR0cHM6Ly9lcnIuc2gvbmV4dC5qcy9kb2MtY3Jvc3NvcmlnaW4tZGVwcmVjYXRlZCdcbiAgICAgICAgKVxuICAgIH1cblxuICAgIGlmIChcbiAgICAgIHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAnZGV2ZWxvcG1lbnQnICYmXG4gICAgICBwcm9jZXNzLmVudi5fX05FWFRfT1BUSU1JWkVfRk9OVFMgJiZcbiAgICAgICFpbkFtcE1vZGVcbiAgICApIHtcbiAgICAgIGNoaWxkcmVuID0gdGhpcy5tYWtlU3R5bGVzaGVldEluZXJ0KGNoaWxkcmVuKVxuICAgIH1cblxuICAgIGxldCBoYXNBbXBodG1sUmVsID0gZmFsc2VcbiAgICBsZXQgaGFzQ2Fub25pY2FsUmVsID0gZmFsc2VcblxuICAgIC8vIHNob3cgd2FybmluZyBhbmQgcmVtb3ZlIGNvbmZsaWN0aW5nIGFtcCBoZWFkIHRhZ3NcbiAgICBoZWFkID0gUmVhY3QuQ2hpbGRyZW4ubWFwKGhlYWQgfHwgW10sIChjaGlsZCkgPT4ge1xuICAgICAgaWYgKCFjaGlsZCkgcmV0dXJuIGNoaWxkXG4gICAgICBjb25zdCB7IHR5cGUsIHByb3BzIH0gPSBjaGlsZFxuICAgICAgaWYgKGluQW1wTW9kZSkge1xuICAgICAgICBsZXQgYmFkUHJvcDogc3RyaW5nID0gJydcblxuICAgICAgICBpZiAodHlwZSA9PT0gJ21ldGEnICYmIHByb3BzLm5hbWUgPT09ICd2aWV3cG9ydCcpIHtcbiAgICAgICAgICBiYWRQcm9wID0gJ25hbWU9XCJ2aWV3cG9ydFwiJ1xuICAgICAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdsaW5rJyAmJiBwcm9wcy5yZWwgPT09ICdjYW5vbmljYWwnKSB7XG4gICAgICAgICAgaGFzQ2Fub25pY2FsUmVsID0gdHJ1ZVxuICAgICAgICB9IGVsc2UgaWYgKHR5cGUgPT09ICdzY3JpcHQnKSB7XG4gICAgICAgICAgLy8gb25seSBibG9jayBpZlxuICAgICAgICAgIC8vIDEuIGl0IGhhcyBhIHNyYyBhbmQgaXNuJ3QgcG9pbnRpbmcgdG8gYW1wcHJvamVjdCdzIENETlxuICAgICAgICAgIC8vIDIuIGl0IGlzIHVzaW5nIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MIHdpdGhvdXQgYSB0eXBlIG9yXG4gICAgICAgICAgLy8gYSB0eXBlIG9mIHRleHQvamF2YXNjcmlwdFxuICAgICAgICAgIGlmIChcbiAgICAgICAgICAgIChwcm9wcy5zcmMgJiYgcHJvcHMuc3JjLmluZGV4T2YoJ2FtcHByb2plY3QnKSA8IC0xKSB8fFxuICAgICAgICAgICAgKHByb3BzLmRhbmdlcm91c2x5U2V0SW5uZXJIVE1MICYmXG4gICAgICAgICAgICAgICghcHJvcHMudHlwZSB8fCBwcm9wcy50eXBlID09PSAndGV4dC9qYXZhc2NyaXB0JykpXG4gICAgICAgICAgKSB7XG4gICAgICAgICAgICBiYWRQcm9wID0gJzxzY3JpcHQnXG4gICAgICAgICAgICBPYmplY3Qua2V5cyhwcm9wcykuZm9yRWFjaCgocHJvcCkgPT4ge1xuICAgICAgICAgICAgICBiYWRQcm9wICs9IGAgJHtwcm9wfT1cIiR7cHJvcHNbcHJvcF19XCJgXG4gICAgICAgICAgICB9KVxuICAgICAgICAgICAgYmFkUHJvcCArPSAnLz4nXG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgaWYgKGJhZFByb3ApIHtcbiAgICAgICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgICAgICBgRm91bmQgY29uZmxpY3RpbmcgYW1wIHRhZyBcIiR7Y2hpbGQudHlwZX1cIiB3aXRoIGNvbmZsaWN0aW5nIHByb3AgJHtiYWRQcm9wfSBpbiAke19fTkVYVF9EQVRBX18ucGFnZX0uIGh0dHBzOi8vZXJyLnNoL25leHQuanMvY29uZmxpY3RpbmctYW1wLXRhZ2BcbiAgICAgICAgICApXG4gICAgICAgICAgcmV0dXJuIG51bGxcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8gbm9uLWFtcCBtb2RlXG4gICAgICAgIGlmICh0eXBlID09PSAnbGluaycgJiYgcHJvcHMucmVsID09PSAnYW1waHRtbCcpIHtcbiAgICAgICAgICBoYXNBbXBodG1sUmVsID0gdHJ1ZVxuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gY2hpbGRcbiAgICB9KVxuXG4gICAgLy8gdHJ5IHRvIHBhcnNlIHN0eWxlcyBmcm9tIGZyYWdtZW50IGZvciBiYWNrd2FyZHMgY29tcGF0XG4gICAgY29uc3QgY3VyU3R5bGVzOiBSZWFjdC5SZWFjdEVsZW1lbnRbXSA9IEFycmF5LmlzQXJyYXkoc3R5bGVzKVxuICAgICAgPyAoc3R5bGVzIGFzIFJlYWN0LlJlYWN0RWxlbWVudFtdKVxuICAgICAgOiBbXVxuICAgIGlmIChcbiAgICAgIGluQW1wTW9kZSAmJlxuICAgICAgc3R5bGVzICYmXG4gICAgICAvLyBAdHMtaWdub3JlIFByb3BlcnR5ICdwcm9wcycgZG9lcyBub3QgZXhpc3Qgb24gdHlwZSBSZWFjdEVsZW1lbnRcbiAgICAgIHN0eWxlcy5wcm9wcyAmJlxuICAgICAgLy8gQHRzLWlnbm9yZSBQcm9wZXJ0eSAncHJvcHMnIGRvZXMgbm90IGV4aXN0IG9uIHR5cGUgUmVhY3RFbGVtZW50XG4gICAgICBBcnJheS5pc0FycmF5KHN0eWxlcy5wcm9wcy5jaGlsZHJlbilcbiAgICApIHtcbiAgICAgIGNvbnN0IGhhc1N0eWxlcyA9IChlbDogUmVhY3QuUmVhY3RFbGVtZW50KSA9PlxuICAgICAgICBlbD8ucHJvcHM/LmRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPy5fX2h0bWxcbiAgICAgIC8vIEB0cy1pZ25vcmUgUHJvcGVydHkgJ3Byb3BzJyBkb2VzIG5vdCBleGlzdCBvbiB0eXBlIFJlYWN0RWxlbWVudFxuICAgICAgc3R5bGVzLnByb3BzLmNoaWxkcmVuLmZvckVhY2goKGNoaWxkOiBSZWFjdC5SZWFjdEVsZW1lbnQpID0+IHtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoY2hpbGQpKSB7XG4gICAgICAgICAgY2hpbGQuZm9yRWFjaCgoZWwpID0+IGhhc1N0eWxlcyhlbCkgJiYgY3VyU3R5bGVzLnB1c2goZWwpKVxuICAgICAgICB9IGVsc2UgaWYgKGhhc1N0eWxlcyhjaGlsZCkpIHtcbiAgICAgICAgICBjdXJTdHlsZXMucHVzaChjaGlsZClcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9XG5cbiAgICBjb25zdCBmaWxlczogRG9jdW1lbnRGaWxlcyA9IGdldERvY3VtZW50RmlsZXMoXG4gICAgICB0aGlzLmNvbnRleHQuYnVpbGRNYW5pZmVzdCxcbiAgICAgIHRoaXMuY29udGV4dC5fX05FWFRfREFUQV9fLnBhZ2UsXG4gICAgICBpbkFtcE1vZGVcbiAgICApXG5cbiAgICByZXR1cm4gKFxuICAgICAgPGhlYWQgey4uLnRoaXMucHJvcHN9PlxuICAgICAgICB7dGhpcy5jb250ZXh0LmlzRGV2ZWxvcG1lbnQgJiYgKFxuICAgICAgICAgIDw+XG4gICAgICAgICAgICA8c3R5bGVcbiAgICAgICAgICAgICAgZGF0YS1uZXh0LWhpZGUtZm91Y1xuICAgICAgICAgICAgICBkYXRhLWFtcGRldm1vZGU9e2luQW1wTW9kZSA/ICd0cnVlJyA6IHVuZGVmaW5lZH1cbiAgICAgICAgICAgICAgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3tcbiAgICAgICAgICAgICAgICBfX2h0bWw6IGBib2R5e2Rpc3BsYXk6bm9uZX1gLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxub3NjcmlwdFxuICAgICAgICAgICAgICBkYXRhLW5leHQtaGlkZS1mb3VjXG4gICAgICAgICAgICAgIGRhdGEtYW1wZGV2bW9kZT17aW5BbXBNb2RlID8gJ3RydWUnIDogdW5kZWZpbmVkfVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICA8c3R5bGVcbiAgICAgICAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17e1xuICAgICAgICAgICAgICAgICAgX19odG1sOiBgYm9keXtkaXNwbGF5OmJsb2NrfWAsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvbm9zY3JpcHQ+XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgICAge2hlYWR9XG4gICAgICAgIDxtZXRhXG4gICAgICAgICAgbmFtZT1cIm5leHQtaGVhZC1jb3VudFwiXG4gICAgICAgICAgY29udGVudD17UmVhY3QuQ2hpbGRyZW4uY291bnQoaGVhZCB8fCBbXSkudG9TdHJpbmcoKX1cbiAgICAgICAgLz5cbiAgICAgICAge2luQW1wTW9kZSAmJiAoXG4gICAgICAgICAgPD5cbiAgICAgICAgICAgIDxtZXRhXG4gICAgICAgICAgICAgIG5hbWU9XCJ2aWV3cG9ydFwiXG4gICAgICAgICAgICAgIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsbWluaW11bS1zY2FsZT0xLGluaXRpYWwtc2NhbGU9MVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgeyFoYXNDYW5vbmljYWxSZWwgJiYgKFxuICAgICAgICAgICAgICA8bGlua1xuICAgICAgICAgICAgICAgIHJlbD1cImNhbm9uaWNhbFwiXG4gICAgICAgICAgICAgICAgaHJlZj17Y2Fub25pY2FsQmFzZSArIGNsZWFuQW1wUGF0aChkYW5nZXJvdXNBc1BhdGgpfVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICAgIHsvKiBodHRwczovL3d3dy5hbXBwcm9qZWN0Lm9yZy9kb2NzL2Z1bmRhbWVudGFscy9vcHRpbWl6ZV9hbXAjb3B0aW1pemUtdGhlLWFtcC1ydW50aW1lLWxvYWRpbmcgKi99XG4gICAgICAgICAgICA8bGlua1xuICAgICAgICAgICAgICByZWw9XCJwcmVsb2FkXCJcbiAgICAgICAgICAgICAgYXM9XCJzY3JpcHRcIlxuICAgICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly9jZG4uYW1wcHJvamVjdC5vcmcvdjAuanNcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHsvKiBBZGQgY3VzdG9tIHN0eWxlcyBiZWZvcmUgQU1QIHN0eWxlcyB0byBwcmV2ZW50IGFjY2lkZW50YWwgb3ZlcnJpZGVzICovfVxuICAgICAgICAgICAge3N0eWxlcyAmJiAoXG4gICAgICAgICAgICAgIDxzdHlsZVxuICAgICAgICAgICAgICAgIGFtcC1jdXN0b209XCJcIlxuICAgICAgICAgICAgICAgIGRhbmdlcm91c2x5U2V0SW5uZXJIVE1MPXt7XG4gICAgICAgICAgICAgICAgICBfX2h0bWw6IGN1clN0eWxlc1xuICAgICAgICAgICAgICAgICAgICAubWFwKChzdHlsZSkgPT4gc3R5bGUucHJvcHMuZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUwuX19odG1sKVxuICAgICAgICAgICAgICAgICAgICAuam9pbignJylcbiAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcL1xcKiMgc291cmNlTWFwcGluZ1VSTD0uKlxcKlxcLy9nLCAnJylcbiAgICAgICAgICAgICAgICAgICAgLnJlcGxhY2UoL1xcL1xcKkAgc291cmNlVVJMPS4qP1xcKlxcLy9nLCAnJyksXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICA8c3R5bGVcbiAgICAgICAgICAgICAgYW1wLWJvaWxlcnBsYXRlPVwiXCJcbiAgICAgICAgICAgICAgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3tcbiAgICAgICAgICAgICAgICBfX2h0bWw6IGBib2R5ey13ZWJraXQtYW5pbWF0aW9uOi1hbXAtc3RhcnQgOHMgc3RlcHMoMSxlbmQpIDBzIDEgbm9ybWFsIGJvdGg7LW1vei1hbmltYXRpb246LWFtcC1zdGFydCA4cyBzdGVwcygxLGVuZCkgMHMgMSBub3JtYWwgYm90aDstbXMtYW5pbWF0aW9uOi1hbXAtc3RhcnQgOHMgc3RlcHMoMSxlbmQpIDBzIDEgbm9ybWFsIGJvdGg7YW5pbWF0aW9uOi1hbXAtc3RhcnQgOHMgc3RlcHMoMSxlbmQpIDBzIDEgbm9ybWFsIGJvdGh9QC13ZWJraXQta2V5ZnJhbWVzIC1hbXAtc3RhcnR7ZnJvbXt2aXNpYmlsaXR5OmhpZGRlbn10b3t2aXNpYmlsaXR5OnZpc2libGV9fUAtbW96LWtleWZyYW1lcyAtYW1wLXN0YXJ0e2Zyb217dmlzaWJpbGl0eTpoaWRkZW59dG97dmlzaWJpbGl0eTp2aXNpYmxlfX1ALW1zLWtleWZyYW1lcyAtYW1wLXN0YXJ0e2Zyb217dmlzaWJpbGl0eTpoaWRkZW59dG97dmlzaWJpbGl0eTp2aXNpYmxlfX1ALW8ta2V5ZnJhbWVzIC1hbXAtc3RhcnR7ZnJvbXt2aXNpYmlsaXR5OmhpZGRlbn10b3t2aXNpYmlsaXR5OnZpc2libGV9fUBrZXlmcmFtZXMgLWFtcC1zdGFydHtmcm9te3Zpc2liaWxpdHk6aGlkZGVufXRve3Zpc2liaWxpdHk6dmlzaWJsZX19YCxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8bm9zY3JpcHQ+XG4gICAgICAgICAgICAgIDxzdHlsZVxuICAgICAgICAgICAgICAgIGFtcC1ib2lsZXJwbGF0ZT1cIlwiXG4gICAgICAgICAgICAgICAgZGFuZ2Vyb3VzbHlTZXRJbm5lckhUTUw9e3tcbiAgICAgICAgICAgICAgICAgIF9faHRtbDogYGJvZHl7LXdlYmtpdC1hbmltYXRpb246bm9uZTstbW96LWFuaW1hdGlvbjpub25lOy1tcy1hbmltYXRpb246bm9uZTthbmltYXRpb246bm9uZX1gLFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8L25vc2NyaXB0PlxuICAgICAgICAgICAgPHNjcmlwdCBhc3luYyBzcmM9XCJodHRwczovL2Nkbi5hbXBwcm9qZWN0Lm9yZy92MC5qc1wiIC8+XG4gICAgICAgICAgPC8+XG4gICAgICAgICl9XG4gICAgICAgIHshaW5BbXBNb2RlICYmIChcbiAgICAgICAgICA8PlxuICAgICAgICAgICAgeyFoYXNBbXBodG1sUmVsICYmIGh5YnJpZEFtcCAmJiAoXG4gICAgICAgICAgICAgIDxsaW5rXG4gICAgICAgICAgICAgICAgcmVsPVwiYW1waHRtbFwiXG4gICAgICAgICAgICAgICAgaHJlZj17Y2Fub25pY2FsQmFzZSArIGdldEFtcFBhdGgoYW1wUGF0aCwgZGFuZ2Vyb3VzQXNQYXRoKX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7IXByb2Nlc3MuZW52Ll9fTkVYVF9PUFRJTUlaRV9DU1MgJiYgdGhpcy5nZXRDc3NMaW5rcyhmaWxlcyl9XG4gICAgICAgICAgICB7IXByb2Nlc3MuZW52Ll9fTkVYVF9PUFRJTUlaRV9DU1MgJiYgKFxuICAgICAgICAgICAgICA8bm9zY3JpcHQgZGF0YS1uLWNzcz17dGhpcy5wcm9wcy5ub25jZSA/PyAnJ30gLz5cbiAgICAgICAgICAgICl9XG4gICAgICAgICAgICB7IWRpc2FibGVSdW50aW1lSlMgJiZcbiAgICAgICAgICAgICAgIWRpc2FibGVKc1ByZWxvYWQgJiZcbiAgICAgICAgICAgICAgdGhpcy5nZXRQcmVsb2FkRHluYW1pY0NodW5rcygpfVxuICAgICAgICAgICAgeyFkaXNhYmxlUnVudGltZUpTICYmXG4gICAgICAgICAgICAgICFkaXNhYmxlSnNQcmVsb2FkICYmXG4gICAgICAgICAgICAgIHRoaXMuZ2V0UHJlbG9hZE1haW5MaW5rcyhmaWxlcyl9XG4gICAgICAgICAgICB7cHJvY2Vzcy5lbnYuX19ORVhUX09QVElNSVpFX0NTUyAmJiB0aGlzLmdldENzc0xpbmtzKGZpbGVzKX1cbiAgICAgICAgICAgIHtwcm9jZXNzLmVudi5fX05FWFRfT1BUSU1JWkVfQ1NTICYmIChcbiAgICAgICAgICAgICAgPG5vc2NyaXB0IGRhdGEtbi1jc3M9e3RoaXMucHJvcHMubm9uY2UgPz8gJyd9IC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge3RoaXMuY29udGV4dC5pc0RldmVsb3BtZW50ICYmIChcbiAgICAgICAgICAgICAgLy8gdGhpcyBlbGVtZW50IGlzIHVzZWQgdG8gbW91bnQgZGV2ZWxvcG1lbnQgc3R5bGVzIHNvIHRoZVxuICAgICAgICAgICAgICAvLyBvcmRlcmluZyBtYXRjaGVzIHByb2R1Y3Rpb25cbiAgICAgICAgICAgICAgLy8gKGJ5IGRlZmF1bHQsIHN0eWxlLWxvYWRlciBpbmplY3RzIGF0IHRoZSBib3R0b20gb2YgPGhlYWQgLz4pXG4gICAgICAgICAgICAgIDxub3NjcmlwdCBpZD1cIl9fbmV4dF9jc3NfX0RPX05PVF9VU0VfX1wiIC8+XG4gICAgICAgICAgICApfVxuICAgICAgICAgICAge3N0eWxlcyB8fCBudWxsfVxuICAgICAgICAgIDwvPlxuICAgICAgICApfVxuICAgICAgICB7UmVhY3QuY3JlYXRlRWxlbWVudChSZWFjdC5GcmFnbWVudCwge30sIC4uLihoZWFkVGFncyB8fCBbXSkpfVxuICAgICAgPC9oZWFkPlxuICAgIClcbiAgfVxufVxuXG5leHBvcnQgZnVuY3Rpb24gTWFpbigpIHtcbiAgY29uc3QgeyBpbkFtcE1vZGUsIGh0bWwsIGRvY0NvbXBvbmVudHNSZW5kZXJlZCB9ID0gdXNlQ29udGV4dChcbiAgICBEb2N1bWVudENvbXBvbmVudENvbnRleHRcbiAgKVxuXG4gIGRvY0NvbXBvbmVudHNSZW5kZXJlZC5NYWluID0gdHJ1ZVxuXG4gIGlmIChpbkFtcE1vZGUpIHJldHVybiA8PntBTVBfUkVOREVSX1RBUkdFVH08Lz5cbiAgcmV0dXJuIDxkaXYgaWQ9XCJfX25leHRcIiBkYW5nZXJvdXNseVNldElubmVySFRNTD17eyBfX2h0bWw6IGh0bWwgfX0gLz5cbn1cblxuZXhwb3J0IGNsYXNzIE5leHRTY3JpcHQgZXh0ZW5kcyBDb21wb25lbnQ8T3JpZ2luUHJvcHM+IHtcbiAgc3RhdGljIGNvbnRleHRUeXBlID0gRG9jdW1lbnRDb21wb25lbnRDb250ZXh0XG5cbiAgc3RhdGljIHByb3BUeXBlcyA9IHtcbiAgICBub25jZTogUHJvcFR5cGVzLnN0cmluZyxcbiAgICBjcm9zc09yaWdpbjogUHJvcFR5cGVzLnN0cmluZyxcbiAgfVxuXG4gIGNvbnRleHQhOiBSZWFjdC5Db250ZXh0VHlwZTx0eXBlb2YgRG9jdW1lbnRDb21wb25lbnRDb250ZXh0PlxuXG4gIC8vIFNvdXJjZTogaHR0cHM6Ly9naXN0LmdpdGh1Yi5jb20vc2FtdGhvci82NGIxMTRlNGE0ZjUzOTkxNWE5NWI5MWZmZDM0MGFjY1xuICBzdGF0aWMgc2FmYXJpTm9tb2R1bGVGaXggPVxuICAgICchZnVuY3Rpb24oKXt2YXIgZT1kb2N1bWVudCx0PWUuY3JlYXRlRWxlbWVudChcInNjcmlwdFwiKTtpZighKFwibm9Nb2R1bGVcImluIHQpJiZcIm9uYmVmb3JlbG9hZFwiaW4gdCl7dmFyIG49ITE7ZS5hZGRFdmVudExpc3RlbmVyKFwiYmVmb3JlbG9hZFwiLGZ1bmN0aW9uKGUpe2lmKGUudGFyZ2V0PT09dCluPSEwO2Vsc2UgaWYoIWUudGFyZ2V0Lmhhc0F0dHJpYnV0ZShcIm5vbW9kdWxlXCIpfHwhbilyZXR1cm47ZS5wcmV2ZW50RGVmYXVsdCgpfSwhMCksdC50eXBlPVwibW9kdWxlXCIsdC5zcmM9XCIuXCIsZS5oZWFkLmFwcGVuZENoaWxkKHQpLHQucmVtb3ZlKCl9fSgpOydcblxuICBnZXREeW5hbWljQ2h1bmtzKGZpbGVzOiBEb2N1bWVudEZpbGVzKSB7XG4gICAgY29uc3Qge1xuICAgICAgZHluYW1pY0ltcG9ydHMsXG4gICAgICBhc3NldFByZWZpeCxcbiAgICAgIGlzRGV2ZWxvcG1lbnQsXG4gICAgICBkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZyxcbiAgICB9ID0gdGhpcy5jb250ZXh0XG5cbiAgICByZXR1cm4gZGVkdXBlKGR5bmFtaWNJbXBvcnRzKS5tYXAoKGJ1bmRsZSkgPT4ge1xuICAgICAgaWYgKCFidW5kbGUuZmlsZS5lbmRzV2l0aCgnLmpzJykgfHwgZmlsZXMuYWxsRmlsZXMuaW5jbHVkZXMoYnVuZGxlLmZpbGUpKVxuICAgICAgICByZXR1cm4gbnVsbFxuXG4gICAgICByZXR1cm4gKFxuICAgICAgICA8c2NyaXB0XG4gICAgICAgICAgYXN5bmM9eyFpc0RldmVsb3BtZW50fVxuICAgICAgICAgIGtleT17YnVuZGxlLmZpbGV9XG4gICAgICAgICAgc3JjPXtgJHthc3NldFByZWZpeH0vX25leHQvJHtlbmNvZGVVUkkoXG4gICAgICAgICAgICBidW5kbGUuZmlsZVxuICAgICAgICAgICl9JHtkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZ31gfVxuICAgICAgICAgIG5vbmNlPXt0aGlzLnByb3BzLm5vbmNlfVxuICAgICAgICAgIGNyb3NzT3JpZ2luPXtcbiAgICAgICAgICAgIHRoaXMucHJvcHMuY3Jvc3NPcmlnaW4gfHwgcHJvY2Vzcy5lbnYuX19ORVhUX0NST1NTX09SSUdJTlxuICAgICAgICAgIH1cbiAgICAgICAgLz5cbiAgICAgIClcbiAgICB9KVxuICB9XG5cbiAgZ2V0UHJlTmV4dFNjcmlwdHMoKSB7XG4gICAgY29uc3QgeyBzY3JpcHRMb2FkZXIgfSA9IHRoaXMuY29udGV4dFxuXG4gICAgcmV0dXJuIChzY3JpcHRMb2FkZXIuZWFnZXIgfHwgW10pLm1hcCgoZmlsZTogc3RyaW5nKSA9PiB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8c2NyaXB0XG4gICAgICAgICAgey4uLmZpbGV9XG4gICAgICAgICAgbm9uY2U9e3RoaXMucHJvcHMubm9uY2V9XG4gICAgICAgICAgY3Jvc3NPcmlnaW49e1xuICAgICAgICAgICAgdGhpcy5wcm9wcy5jcm9zc09yaWdpbiB8fCBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOXG4gICAgICAgICAgfVxuICAgICAgICAvPlxuICAgICAgKVxuICAgIH0pXG4gIH1cblxuICBnZXRTY3JpcHRzKGZpbGVzOiBEb2N1bWVudEZpbGVzKSB7XG4gICAgY29uc3Qge1xuICAgICAgYXNzZXRQcmVmaXgsXG4gICAgICBidWlsZE1hbmlmZXN0LFxuICAgICAgaXNEZXZlbG9wbWVudCxcbiAgICAgIGRldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nLFxuICAgIH0gPSB0aGlzLmNvbnRleHRcblxuICAgIGNvbnN0IG5vcm1hbFNjcmlwdHMgPSBmaWxlcy5hbGxGaWxlcy5maWx0ZXIoKGZpbGUpID0+IGZpbGUuZW5kc1dpdGgoJy5qcycpKVxuICAgIGNvbnN0IGxvd1ByaW9yaXR5U2NyaXB0cyA9IGJ1aWxkTWFuaWZlc3QubG93UHJpb3JpdHlGaWxlcz8uZmlsdGVyKChmaWxlKSA9PlxuICAgICAgZmlsZS5lbmRzV2l0aCgnLmpzJylcbiAgICApXG5cbiAgICByZXR1cm4gWy4uLm5vcm1hbFNjcmlwdHMsIC4uLmxvd1ByaW9yaXR5U2NyaXB0c10ubWFwKChmaWxlKSA9PiB7XG4gICAgICByZXR1cm4gKFxuICAgICAgICA8c2NyaXB0XG4gICAgICAgICAga2V5PXtmaWxlfVxuICAgICAgICAgIHNyYz17YCR7YXNzZXRQcmVmaXh9L19uZXh0LyR7ZW5jb2RlVVJJKFxuICAgICAgICAgICAgZmlsZVxuICAgICAgICAgICl9JHtkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZ31gfVxuICAgICAgICAgIG5vbmNlPXt0aGlzLnByb3BzLm5vbmNlfVxuICAgICAgICAgIGFzeW5jPXshaXNEZXZlbG9wbWVudH1cbiAgICAgICAgICBjcm9zc09yaWdpbj17XG4gICAgICAgICAgICB0aGlzLnByb3BzLmNyb3NzT3JpZ2luIHx8IHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU5cbiAgICAgICAgICB9XG4gICAgICAgIC8+XG4gICAgICApXG4gICAgfSlcbiAgfVxuXG4gIGdldFBvbHlmaWxsU2NyaXB0cygpIHtcbiAgICAvLyBwb2x5ZmlsbHMuanMgaGFzIHRvIGJlIHJlbmRlcmVkIGFzIG5vbW9kdWxlIHdpdGhvdXQgYXN5bmNcbiAgICAvLyBJdCBhbHNvIGhhcyB0byBiZSB0aGUgZmlyc3Qgc2NyaXB0IHRvIGxvYWRcbiAgICBjb25zdCB7XG4gICAgICBhc3NldFByZWZpeCxcbiAgICAgIGJ1aWxkTWFuaWZlc3QsXG4gICAgICBkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZyxcbiAgICB9ID0gdGhpcy5jb250ZXh0XG5cbiAgICByZXR1cm4gYnVpbGRNYW5pZmVzdC5wb2x5ZmlsbEZpbGVzXG4gICAgICAuZmlsdGVyKFxuICAgICAgICAocG9seWZpbGwpID0+XG4gICAgICAgICAgcG9seWZpbGwuZW5kc1dpdGgoJy5qcycpICYmICFwb2x5ZmlsbC5lbmRzV2l0aCgnLm1vZHVsZS5qcycpXG4gICAgICApXG4gICAgICAubWFwKChwb2x5ZmlsbCkgPT4gKFxuICAgICAgICA8c2NyaXB0XG4gICAgICAgICAga2V5PXtwb2x5ZmlsbH1cbiAgICAgICAgICBub25jZT17dGhpcy5wcm9wcy5ub25jZX1cbiAgICAgICAgICBjcm9zc09yaWdpbj17XG4gICAgICAgICAgICB0aGlzLnByb3BzLmNyb3NzT3JpZ2luIHx8IHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU5cbiAgICAgICAgICB9XG4gICAgICAgICAgbm9Nb2R1bGU9e3RydWV9XG4gICAgICAgICAgc3JjPXtgJHthc3NldFByZWZpeH0vX25leHQvJHtwb2x5ZmlsbH0ke2Rldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nfWB9XG4gICAgICAgIC8+XG4gICAgICApKVxuICB9XG5cbiAgc3RhdGljIGdldElubGluZVNjcmlwdFNvdXJjZShkb2N1bWVudFByb3BzOiBSZWFkb25seTxEb2N1bWVudFByb3BzPik6IHN0cmluZyB7XG4gICAgY29uc3QgeyBfX05FWFRfREFUQV9fIH0gPSBkb2N1bWVudFByb3BzXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBKU09OLnN0cmluZ2lmeShfX05FWFRfREFUQV9fKVxuICAgICAgcmV0dXJuIGh0bWxFc2NhcGVKc29uU3RyaW5nKGRhdGEpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICBpZiAoZXJyLm1lc3NhZ2UuaW5kZXhPZignY2lyY3VsYXIgc3RydWN0dXJlJykpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGBDaXJjdWxhciBzdHJ1Y3R1cmUgaW4gXCJnZXRJbml0aWFsUHJvcHNcIiByZXN1bHQgb2YgcGFnZSBcIiR7X19ORVhUX0RBVEFfXy5wYWdlfVwiLiBodHRwczovL2Vyci5zaC92ZXJjZWwvbmV4dC5qcy9jaXJjdWxhci1zdHJ1Y3R1cmVgXG4gICAgICAgIClcbiAgICAgIH1cbiAgICAgIHRocm93IGVyclxuICAgIH1cbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7XG4gICAgICBhc3NldFByZWZpeCxcbiAgICAgIGluQW1wTW9kZSxcbiAgICAgIGJ1aWxkTWFuaWZlc3QsXG4gICAgICB1bnN0YWJsZV9ydW50aW1lSlMsXG4gICAgICBkb2NDb21wb25lbnRzUmVuZGVyZWQsXG4gICAgICBkZXZPbmx5Q2FjaGVCdXN0ZXJRdWVyeVN0cmluZyxcbiAgICB9ID0gdGhpcy5jb250ZXh0XG4gICAgY29uc3QgZGlzYWJsZVJ1bnRpbWVKUyA9IHVuc3RhYmxlX3J1bnRpbWVKUyA9PT0gZmFsc2VcblxuICAgIGRvY0NvbXBvbmVudHNSZW5kZXJlZC5OZXh0U2NyaXB0ID0gdHJ1ZVxuXG4gICAgaWYgKGluQW1wTW9kZSkge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSAncHJvZHVjdGlvbicpIHtcbiAgICAgICAgcmV0dXJuIG51bGxcbiAgICAgIH1cblxuICAgICAgY29uc3QgYW1wRGV2RmlsZXMgPSBbXG4gICAgICAgIC4uLmJ1aWxkTWFuaWZlc3QuZGV2RmlsZXMsXG4gICAgICAgIC4uLmJ1aWxkTWFuaWZlc3QucG9seWZpbGxGaWxlcyxcbiAgICAgICAgLi4uYnVpbGRNYW5pZmVzdC5hbXBEZXZGaWxlcyxcbiAgICAgIF1cblxuICAgICAgcmV0dXJuIChcbiAgICAgICAgPD5cbiAgICAgICAgICB7ZGlzYWJsZVJ1bnRpbWVKUyA/IG51bGwgOiAoXG4gICAgICAgICAgICA8c2NyaXB0XG4gICAgICAgICAgICAgIGlkPVwiX19ORVhUX0RBVEFfX1wiXG4gICAgICAgICAgICAgIHR5cGU9XCJhcHBsaWNhdGlvbi9qc29uXCJcbiAgICAgICAgICAgICAgbm9uY2U9e3RoaXMucHJvcHMubm9uY2V9XG4gICAgICAgICAgICAgIGNyb3NzT3JpZ2luPXtcbiAgICAgICAgICAgICAgICB0aGlzLnByb3BzLmNyb3NzT3JpZ2luIHx8IHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU5cbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17e1xuICAgICAgICAgICAgICAgIF9faHRtbDogTmV4dFNjcmlwdC5nZXRJbmxpbmVTY3JpcHRTb3VyY2UodGhpcy5jb250ZXh0KSxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgZGF0YS1hbXBkZXZtb2RlXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICl9XG4gICAgICAgICAge2FtcERldkZpbGVzLm1hcCgoZmlsZSkgPT4gKFxuICAgICAgICAgICAgPHNjcmlwdFxuICAgICAgICAgICAgICBrZXk9e2ZpbGV9XG4gICAgICAgICAgICAgIHNyYz17YCR7YXNzZXRQcmVmaXh9L19uZXh0LyR7ZmlsZX0ke2Rldk9ubHlDYWNoZUJ1c3RlclF1ZXJ5U3RyaW5nfWB9XG4gICAgICAgICAgICAgIG5vbmNlPXt0aGlzLnByb3BzLm5vbmNlfVxuICAgICAgICAgICAgICBjcm9zc09yaWdpbj17XG4gICAgICAgICAgICAgICAgdGhpcy5wcm9wcy5jcm9zc09yaWdpbiB8fCBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgZGF0YS1hbXBkZXZtb2RlXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICkpfVxuICAgICAgICA8Lz5cbiAgICAgIClcbiAgICB9XG5cbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgICAgaWYgKHRoaXMucHJvcHMuY3Jvc3NPcmlnaW4pXG4gICAgICAgIGNvbnNvbGUud2FybihcbiAgICAgICAgICAnV2FybmluZzogYE5leHRTY3JpcHRgIGF0dHJpYnV0ZSBgY3Jvc3NPcmlnaW5gIGlzIGRlcHJlY2F0ZWQuIGh0dHBzOi8vZXJyLnNoL25leHQuanMvZG9jLWNyb3Nzb3JpZ2luLWRlcHJlY2F0ZWQnXG4gICAgICAgIClcbiAgICB9XG5cbiAgICBjb25zdCBmaWxlczogRG9jdW1lbnRGaWxlcyA9IGdldERvY3VtZW50RmlsZXMoXG4gICAgICB0aGlzLmNvbnRleHQuYnVpbGRNYW5pZmVzdCxcbiAgICAgIHRoaXMuY29udGV4dC5fX05FWFRfREFUQV9fLnBhZ2UsXG4gICAgICBpbkFtcE1vZGVcbiAgICApXG5cbiAgICByZXR1cm4gKFxuICAgICAgPD5cbiAgICAgICAgeyFkaXNhYmxlUnVudGltZUpTICYmIGJ1aWxkTWFuaWZlc3QuZGV2RmlsZXNcbiAgICAgICAgICA/IGJ1aWxkTWFuaWZlc3QuZGV2RmlsZXMubWFwKChmaWxlOiBzdHJpbmcpID0+IChcbiAgICAgICAgICAgICAgPHNjcmlwdFxuICAgICAgICAgICAgICAgIGtleT17ZmlsZX1cbiAgICAgICAgICAgICAgICBzcmM9e2Ake2Fzc2V0UHJlZml4fS9fbmV4dC8ke2VuY29kZVVSSShcbiAgICAgICAgICAgICAgICAgIGZpbGVcbiAgICAgICAgICAgICAgICApfSR7ZGV2T25seUNhY2hlQnVzdGVyUXVlcnlTdHJpbmd9YH1cbiAgICAgICAgICAgICAgICBub25jZT17dGhpcy5wcm9wcy5ub25jZX1cbiAgICAgICAgICAgICAgICBjcm9zc09yaWdpbj17XG4gICAgICAgICAgICAgICAgICB0aGlzLnByb3BzLmNyb3NzT3JpZ2luIHx8IHByb2Nlc3MuZW52Ll9fTkVYVF9DUk9TU19PUklHSU5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICApKVxuICAgICAgICAgIDogbnVsbH1cbiAgICAgICAge2Rpc2FibGVSdW50aW1lSlMgPyBudWxsIDogKFxuICAgICAgICAgIDxzY3JpcHRcbiAgICAgICAgICAgIGlkPVwiX19ORVhUX0RBVEFfX1wiXG4gICAgICAgICAgICB0eXBlPVwiYXBwbGljYXRpb24vanNvblwiXG4gICAgICAgICAgICBub25jZT17dGhpcy5wcm9wcy5ub25jZX1cbiAgICAgICAgICAgIGNyb3NzT3JpZ2luPXtcbiAgICAgICAgICAgICAgdGhpcy5wcm9wcy5jcm9zc09yaWdpbiB8fCBwcm9jZXNzLmVudi5fX05FWFRfQ1JPU1NfT1JJR0lOXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBkYW5nZXJvdXNseVNldElubmVySFRNTD17e1xuICAgICAgICAgICAgICBfX2h0bWw6IE5leHRTY3JpcHQuZ2V0SW5saW5lU2NyaXB0U291cmNlKHRoaXMuY29udGV4dCksXG4gICAgICAgICAgICB9fVxuICAgICAgICAgIC8+XG4gICAgICAgICl9XG4gICAgICAgIHshZGlzYWJsZVJ1bnRpbWVKUyAmJiB0aGlzLmdldFBvbHlmaWxsU2NyaXB0cygpfVxuICAgICAgICB7IWRpc2FibGVSdW50aW1lSlMgJiYgdGhpcy5nZXRQcmVOZXh0U2NyaXB0cygpfVxuICAgICAgICB7ZGlzYWJsZVJ1bnRpbWVKUyA/IG51bGwgOiB0aGlzLmdldER5bmFtaWNDaHVua3MoZmlsZXMpfVxuICAgICAgICB7ZGlzYWJsZVJ1bnRpbWVKUyA/IG51bGwgOiB0aGlzLmdldFNjcmlwdHMoZmlsZXMpfVxuICAgICAgPC8+XG4gICAgKVxuICB9XG59XG5cbmZ1bmN0aW9uIGdldEFtcFBhdGgoYW1wUGF0aDogc3RyaW5nLCBhc1BhdGg6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBhbXBQYXRoIHx8IGAke2FzUGF0aH0ke2FzUGF0aC5pbmNsdWRlcygnPycpID8gJyYnIDogJz8nfWFtcD0xYFxufVxuIiwiXCJ1c2Ugc3RyaWN0XCI7ZXhwb3J0cy5fX2VzTW9kdWxlPXRydWU7ZXhwb3J0cy5odG1sRXNjYXBlSnNvblN0cmluZz1odG1sRXNjYXBlSnNvblN0cmluZzsvLyBUaGlzIHV0aWxpdHkgaXMgYmFzZWQgb24gaHR0cHM6Ly9naXRodWIuY29tL3plcnRvc2gvaHRtbGVzY2FwZVxuLy8gTGljZW5zZTogaHR0cHM6Ly9naXRodWIuY29tL3plcnRvc2gvaHRtbGVzY2FwZS9ibG9iLzA1MjdjYTcxNTZhNTI0ZDI1NjEwMWJiMzEwYTlmOTcwZjYzMDc4YWQvTElDRU5TRVxuY29uc3QgRVNDQVBFX0xPT0tVUD17JyYnOidcXFxcdTAwMjYnLCc+JzonXFxcXHUwMDNlJywnPCc6J1xcXFx1MDAzYycsJ1xcdTIwMjgnOidcXFxcdTIwMjgnLCdcXHUyMDI5JzonXFxcXHUyMDI5J307Y29uc3QgRVNDQVBFX1JFR0VYPS9bJj48XFx1MjAyOFxcdTIwMjldL2c7ZnVuY3Rpb24gaHRtbEVzY2FwZUpzb25TdHJpbmcoc3RyKXtyZXR1cm4gc3RyLnJlcGxhY2UoRVNDQVBFX1JFR0VYLG1hdGNoPT5FU0NBUEVfTE9PS1VQW21hdGNoXSk7fVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aHRtbGVzY2FwZS5qcy5tYXAiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vZGlzdC9wYWdlcy9fZG9jdW1lbnQnKVxuIiwiaW1wb3J0IHsgU2VydmVyU3R5bGVTaGVldHMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5pbXBvcnQgRG9jdW1lbnQsIHsgSGVhZCwgSHRtbCwgTWFpbiwgTmV4dFNjcmlwdCB9IGZyb20gJ25leHQvZG9jdW1lbnQnO1xyXG5pbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgdGhlbWUgZnJvbSAnc2hhcmVkL3V0aWxzL3RoZW1lJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE15RG9jdW1lbnQgZXh0ZW5kcyBEb2N1bWVudCB7XHJcbiAgcmVuZGVyKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgPEh0bWwgbGFuZz1cImVuXCI+XHJcbiAgICAgICAgPEhlYWQ+XHJcbiAgICAgICAgICB7LyogUFdBIHByaW1hcnkgY29sb3IgKi99XHJcbiAgICAgICAgICA8bWV0YSBuYW1lPVwidGhlbWUtY29sb3JcIiBjb250ZW50PXt0aGVtZS5wYWxldHRlLnByaW1hcnkubWFpbn0gLz5cclxuICAgICAgICAgIDxsaW5rXHJcbiAgICAgICAgICAgIHJlbD1cInN0eWxlc2hlZXRcIlxyXG4gICAgICAgICAgICBocmVmPVwiaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3M/ZmFtaWx5PVJvYm90bzozMDAsNDAwLDUwMCw3MDAmZGlzcGxheT1zd2FwXCJcclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9IZWFkPlxyXG4gICAgICAgIDxib2R5PlxyXG4gICAgICAgICAgPE1haW4gLz5cclxuICAgICAgICAgIDxOZXh0U2NyaXB0IC8+XHJcbiAgICAgICAgPC9ib2R5PlxyXG4gICAgICA8L0h0bWw+XHJcbiAgICApO1xyXG4gIH1cclxufVxyXG5cclxuLy8gYGdldEluaXRpYWxQcm9wc2AgYmVsb25ncyB0byBgX2RvY3VtZW50YCAoaW5zdGVhZCBvZiBgX2FwcGApLFxyXG4vLyBpdCdzIGNvbXBhdGlibGUgd2l0aCBzZXJ2ZXItc2lkZSBnZW5lcmF0aW9uIChTU0cpLlxyXG5NeURvY3VtZW50LmdldEluaXRpYWxQcm9wcyA9IGFzeW5jIChjdHgpID0+IHtcclxuICAvLyBSZXNvbHV0aW9uIG9yZGVyXHJcbiAgLy9cclxuICAvLyBPbiB0aGUgc2VydmVyOlxyXG4gIC8vIDEuIGFwcC5nZXRJbml0aWFsUHJvcHNcclxuICAvLyAyLiBwYWdlLmdldEluaXRpYWxQcm9wc1xyXG4gIC8vIDMuIGRvY3VtZW50LmdldEluaXRpYWxQcm9wc1xyXG4gIC8vIDQuIGFwcC5yZW5kZXJcclxuICAvLyA1LiBwYWdlLnJlbmRlclxyXG4gIC8vIDYuIGRvY3VtZW50LnJlbmRlclxyXG4gIC8vXHJcbiAgLy8gT24gdGhlIHNlcnZlciB3aXRoIGVycm9yOlxyXG4gIC8vIDEuIGRvY3VtZW50LmdldEluaXRpYWxQcm9wc1xyXG4gIC8vIDIuIGFwcC5yZW5kZXJcclxuICAvLyAzLiBwYWdlLnJlbmRlclxyXG4gIC8vIDQuIGRvY3VtZW50LnJlbmRlclxyXG4gIC8vXHJcbiAgLy8gT24gdGhlIGNsaWVudFxyXG4gIC8vIDEuIGFwcC5nZXRJbml0aWFsUHJvcHNcclxuICAvLyAyLiBwYWdlLmdldEluaXRpYWxQcm9wc1xyXG4gIC8vIDMuIGFwcC5yZW5kZXJcclxuICAvLyA0LiBwYWdlLnJlbmRlclxyXG5cclxuICAvLyBSZW5kZXIgYXBwIGFuZCBwYWdlIGFuZCBnZXQgdGhlIGNvbnRleHQgb2YgdGhlIHBhZ2Ugd2l0aCBjb2xsZWN0ZWQgc2lkZSBlZmZlY3RzLlxyXG4gIGNvbnN0IHNoZWV0cyA9IG5ldyBTZXJ2ZXJTdHlsZVNoZWV0cygpO1xyXG4gIGNvbnN0IG9yaWdpbmFsUmVuZGVyUGFnZSA9IGN0eC5yZW5kZXJQYWdlO1xyXG5cclxuICBjdHgucmVuZGVyUGFnZSA9ICgpID0+XHJcbiAgICBvcmlnaW5hbFJlbmRlclBhZ2Uoe1xyXG4gICAgICBlbmhhbmNlQXBwOiAoQXBwKSA9PiAocHJvcHMpID0+IHNoZWV0cy5jb2xsZWN0KDxBcHAgey4uLnByb3BzfSAvPiksXHJcbiAgICB9KTtcclxuXHJcbiAgY29uc3QgaW5pdGlhbFByb3BzID0gYXdhaXQgRG9jdW1lbnQuZ2V0SW5pdGlhbFByb3BzKGN0eCk7XHJcblxyXG4gIHJldHVybiB7XHJcbiAgICAuLi5pbml0aWFsUHJvcHMsXHJcbiAgICAvLyBTdHlsZXMgZnJhZ21lbnQgaXMgcmVuZGVyZWQgYWZ0ZXIgdGhlIGFwcCBhbmQgcGFnZSByZW5kZXJpbmcgZmluaXNoLlxyXG4gICAgc3R5bGVzOiBbXHJcbiAgICAgIC4uLlJlYWN0LkNoaWxkcmVuLnRvQXJyYXkoaW5pdGlhbFByb3BzLnN0eWxlcyksXHJcbiAgICAgIHNoZWV0cy5nZXRTdHlsZUVsZW1lbnQoKSxcclxuICAgIF0sXHJcbiAgfTtcclxufTtcclxuIiwiY29uc3QgQWxlcnRPdmVyaWRlID0ge1xyXG4gICAgTXVpQWxlcnQ6IHtcclxuICAgICAgICByb290OntcclxuICAgICAgICAgICAgZm9udFNpemU6JzE1cHgnLFxyXG4gICAgICAgICAgICBwYWRkaW5nOlwiMTJweCAyNHB4XCJcclxuICAgICAgICB9LFxyXG4gICAgICAgIGljb246e1xyXG4gICAgICAgICAgICBkaXNwbGF5Oidub25lJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3RhbmRhcmRTdWNjZXNzOntcclxuICAgICAgICAgICAgY29sb3I6J2luaGVyaXQnLFxyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6J2luaGVyaXQnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhY3Rpb246e1xyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zOidmbGV4LXN0YXJ0JyxcclxuICAgICAgICAgICAgJyYgLk11aUljb25CdXR0b24tcm9vdCc6e1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzonNnB4IDAnLFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBtZXNzYWdlOntcclxuICAgICAgICAgICAgcGFkZGluZzogJzZweCAwJyxcclxuICAgICAgICAgICAgd2lkdGg6JzEwMCUnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIE11aUFsZXJ0VGl0bGU6e1xyXG4gICAgICAgIHJvb3Q6e1xyXG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206JzRweCdcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBBbGVydE92ZXJpZGU7IiwiaW1wb3J0IGNvbG9yIGZyb20gJy4uL2NvbG9yJztcclxuaW1wb3J0IGZvbnQgZnJvbSAnLi4vdHlwb2dyYXBoeSc7XHJcblxyXG5jb25zdCBCdXR0b25PdmVyUmlkZSA9IHtcclxuICAgIE11aUJ1dHRvbjoge1xyXG4gICAgICAgIHNpemVMYXJnZToge1xyXG4gICAgICAgICAgICBtaW5XaWR0aDogJzE5MnB4JyxcclxuICAgICAgICAgICAgZm9udFNpemU6IGZvbnQuaDUuZm9udFNpemUsXHJcbiAgICAgICAgICAgIHBhZGRpbmc6ICc4cHggNTFweCcsXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzaXplU21hbGw6IHtcclxuICAgICAgICAgICAgZm9udFNpemU6IGZvbnQuc20uZm9udFNpemUsXHJcbiAgICAgICAgICAgIG1pbldpZHRoOiAnOTBweCcsXHJcbiAgICAgICAgICAgIG1pbkhlaWdodDogJzM2cHgnLFxyXG4gICAgICAgICAgICBmb250RmFtaWx5OiBmb250LmZvbnRGYW1pbHkucmVndWxhclxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc2l6ZU1lZGl1bToge1xyXG4gICAgICAgICAgICBtaW5XaWR0aDogJzE2MHB4JyxcclxuICAgICAgICAgICAgZm9udEZhbWlseTogZm9udC5mb250RmFtaWx5Lm1lZGl1bVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY29udGFpbmVkU2Vjb25kYXJ5OiB7XHJcbiAgICAgICAgICAgIGNvbG9yOiBjb2xvci5wYWxldHRlLmJ1dHRvbi5zZWNvbmRhcnlDb2xvclxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgY29sb3JJbmhlcml0OiB7XHJcbiAgICAgICAgICAgIGNvbG9yOiBjb2xvci5wYWxldHRlLnByaW1hcnkubWFpbixcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5jb21tb24ud2hpdGVcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNvbnRhaW5lZDoge1xyXG4gICAgICAgICAgICBib3hTaGFkb3c6ICdub25lJ1xyXG4gICAgICAgIH0sXHJcblxyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnNTBweCcsXHJcbiAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06ICdpbmhlcml0JyxcclxuICAgICAgICAgICAgZm9udEZhbWlseTogZm9udC5mb250RmFtaWx5Lm1lZGl1bSxcclxuICAgICAgICAgICAgJyYuc2VtaUJvcmRlcic6IHtcclxuICAgICAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzBweCAwcHggMjBweCAyMHB4JyxcclxuICAgICAgICAgICAgICAgIHBhZGRpbmc6JzhweCA1cHgnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmLmxpbmtCdG4nOiB7XHJcbiAgICAgICAgICAgICAgICBtaW5XaWR0aDogJ2F1dG8gIWltcG9ydGFudCcsXHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiBgMCAhaW1wb3J0YW50YCxcclxuICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogJzAgIWltcG9ydGFudCcsXHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCcsXHJcbiAgICAgICAgICAgICAgICAnJjpob3Zlcic6IHtcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCAhaW1wb3J0YW50J1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICcmOmZvY3VzJzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50ICFpbXBvcnRhbnQnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmLmxpbmstcHJpbWFyeSc6IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvci5wYWxldHRlLnN1Y2Nlc3MuZXh0cmFMaWdodCxcclxuICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6IGZvbnQuZm9udEZhbWlseS5yZWd1bGFyLFxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IGZvbnQubGcuZm9udFNpemVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYubGluay13aGl0ZSc6IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBcIiNmZmZcIixcclxuICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6IGZvbnQuZm9udEZhbWlseS5yZWd1bGFyLFxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IGZvbnQubGcuZm9udFNpemVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYuZmFjZWJvb0tCdG4nOiB7XHJcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLmNvbW1vbi5mYWNlYm9va0JsdWVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYudy0yNjknOiB7XHJcbiAgICAgICAgICAgICAgICB3aWR0aDpcIjI2OXB4XCJcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9LFxyXG4gICAgICAgIGVuZEljb246e1xyXG4gICAgICAgICAgICBtYXJnaW5MZWZ0Oic0cHgnXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQnV0dG9uT3ZlclJpZGU7XHJcbiIsImNvbnN0IENhcmRPdmVyUmlkZSA9IHtcclxuICAgIE11aUNhcmQ6IHtcclxuICAgICAgICByb290OntcclxuICAgICAgICAgICAgYm94U2hhZG93OiAnMCA0cHggNHB4IHJnYigwIDAgMCAvIDglKScsXHJcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzIxcHgnXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2FyZE92ZXJSaWRlO1xyXG4iLCJpbXBvcnQgY29sb3IgZnJvbSAnLi4vY29sb3InO1xyXG5pbXBvcnQgZm9udCBmcm9tICcuLi90eXBvZ3JhcGh5JztcclxuXHJcbmNvbnN0IENoZWNrQm94T3ZlclJpZGUgPSB7XHJcbiAgICBNdWlDaGVja2JveDoge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgJyYuZXh0cmFMaWdodExhYmVsIH4gc3Bhbic6IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvci5wYWxldHRlLnByaW1hcnkuZXh0cmFMaWdodFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJiAuTXVpU3ZnSWNvbi1yb290Jzoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6ICd0cmFuc3BhcmVudCcsXHJcbiAgICAgICAgICAgICAgICBib3JkZXI6IGAxcHggc29saWQgJHtjb2xvci5wYWxldHRlLnByaW1hcnkuZXh0cmFMaWdodH1gLFxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IGZvbnQuaDQuZm9udFNpemUsXHJcbiAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6ICc4cHgnLFxyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5jb21tb24ud2hpdGVcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYuTXVpLWNoZWNrZWQnOiB7XHJcbiAgICAgICAgICAgICAgICAnJiAuTXVpU3ZnSWNvbi1yb290Jzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvci5wYWxldHRlLnN1Y2Nlc3MubWFpbixcclxuICAgICAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6ICd0cmFuc3BhcmVudCdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgJyYuTXVpQ2hlY2tib3gtcm9vdCB+IHNwYW4nOiB7XHJcbiAgICAgICAgICAgICAgICBwYWRkaW5nVG9wOiAnMHB4JyxcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgTXVpRm9ybUNvbnRyb2xMYWJlbDoge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgYWxpZ25JdGVtczogJ2ZsZXgtc3RhcnQnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBsYWJlbDoge1xyXG4gICAgICAgICAgICBmb250U2l6ZTogZm9udC5oNi5mb250U2l6ZSxcclxuICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUucHJpbWFyeS5saWdodCxcclxuICAgICAgICAgICAgcGFkZGluZ1RvcDogJzRweCcsXHJcbiAgICAgICAgICAgIHBhZGRpbmdMZWZ0Oic0cHgnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIFByaXZhdGVTd2l0Y2hCYXNlOiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICBwYWRkaW5nVG9wOiAwXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hlY2tCb3hPdmVyUmlkZTtcclxuIiwiaW1wb3J0IGNvbG9yIGZyb20gJy4uL2NvbG9yJztcclxuaW1wb3J0IGZvbnQgZnJvbSAnLi4vdHlwb2dyYXBoeSc7XHJcblxyXG5jb25zdCBEaWFsb2dPdmVyUmlkZSA9IHtcclxuICAgIE11aURpYWxvZzoge1xyXG4gICAgICAgIHJvb3Q6IHt9LFxyXG4gICAgICAgIHBhcGVyOiB7XHJcbiAgICAgICAgICAgIG1pbldpZHRoOiAnMzgzcHgnLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcyMXB4JyxcclxuICAgICAgICAgICAgYm94U2hhZG93OiAnMHB4IDRweCA0cHggcmdiYSgwLCAwLCAwLCAwLjA4KSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGNvbnRhaW5lcjp7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjoncmdiYSg4OCwgOTAsIDEyMSwgLjcwKSdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgTXVpRGlhbG9nVGl0bGU6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgICcmIC5NdWlCdXR0b25CYXNlLXJvb3QnOiB7XHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcclxuICAgICAgICAgICAgICAgIHJpZ2h0OiAnMTBweCcsXHJcbiAgICAgICAgICAgICAgICB0b3A6ICcxMHB4J1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJiAuTXVpU3ZnSWNvbi1yb290Jzoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUucHJpbWFyeS5tYWluLFxyXG4gICAgICAgICAgICAgICAgZm9udFNpemU6IGZvbnQuaDR4bC5mb250U2l6ZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgRGlhbG9nT3ZlclJpZGU7XHJcbiIsImltcG9ydCBjb2xvciBmcm9tICcuLi9jb2xvcic7XHJcbmltcG9ydCBmb250IGZyb20gJy4uL3R5cG9ncmFwaHknO1xyXG5cclxuY29uc3QgSW5wdXRPdmVyUmlkZSA9IHtcclxuICAgIE11aUZpbGxlZElucHV0OiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICBjb2xvcjogY29sb3IucGFsZXR0ZS5wcmltYXJ5LmxpZ2h0LFxyXG4gICAgICAgICAgICBib3JkZXI6IGAxcHggc29saWQgJHtjb2xvci5wYWxldHRlLnByaW1hcnkuZXh0cmFMaWdodH1gLFxyXG4gICAgICAgICAgICBmb250U2l6ZTogZm9udC5oNi5mb250U2l6ZSxcclxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnMTZweCcsXHJcbiAgICAgICAgICAgIGJvcmRlclRvcExlZnRSYWRpdXM6ICcxNnB4JyxcclxuICAgICAgICAgICAgYm9yZGVyVG9wUmlnaHRSYWRpdXM6ICcxNnB4JyxcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5jb21tb24ud2hpdGUsXHJcbiAgICAgICAgICAgIGhlaWdodDogJzUycHgnLFxyXG4gICAgICAgICAgICAnJjpob3Zlcic6IHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3IuY29tbW9uLndoaXRlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIE11aUlucHV0TGFiZWw6IHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAnOTUlJyxcclxuICAgICAgICAgICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcclxuICAgICAgICAgICAgICAgIHRleHRPdmVyZmxvdzogJ2VsbGlwc2lzJyxcclxuICAgICAgICAgICAgICAgIHdoaXRlU3BhY2U6ICdub3dyYXAnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmIC5NdWlJbnB1dEFkb3JubWVudC1maWxsZWQuTXVpSW5wdXRBZG9ybm1lbnQtcG9zaXRpb25TdGFydDpub3QoLk11aUlucHV0QWRvcm5tZW50LWhpZGRlbkxhYmVsKSc6XHJcbiAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWFyZ2luVG9wOiAwXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJiAuTXVpSWNvbkJ1dHRvbi1yb290Jzoge1xyXG4gICAgICAgICAgICAgICAgcGFkZGluZzogJzAgOHB4IDAgMCcsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udC5oNXhsLmZvbnRTaXplXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmLk11aS1lcnJvcic6IHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3IucGFsZXR0ZS5lcnJvci5leHRyYUxpZ2h0LFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyQ29sb3I6IGNvbG9yLnBhbGV0dGUuZXJyb3IubWFpblxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJi5NdWktZm9jdXNlZCc6IHtcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogJ3RyYW5zcGFyZW50JyxcclxuICAgICAgICAgICAgICAgIGJveFNoYWRvdzogJ25vbmUgIWltcG9ydGFudCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaW5wdXQ6IHtcclxuICAgICAgICAgICAgcGFkZGluZzogJzI1cHggMTZweCA1cHgnLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6JzE2cHgnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBhZG9ybmVkRW5kOiB7XHJcbiAgICAgICAgICAgIHBhZGRpbmdSaWdodDogMFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgdW5kZXJsaW5lOiB7XHJcbiAgICAgICAgICAgICcmOmJlZm9yZSwgJjphZnRlcic6IHtcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmOmhvdmVyJzoge1xyXG4gICAgICAgICAgICAgICAgJyY6YmVmb3JlLCAmOmFmdGVyJzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGJvcmRlcjogJ25vbmUnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIG11bHRpbGluZTp7XHJcbiAgICAgICAgICAgIGhlaWdodDonMTIwcHgnXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcbiAgICBNdWlJbnB1dExhYmVsOiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICB3aWR0aDogJzEwMCUnLFxyXG4gICAgICAgICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXHJcbiAgICAgICAgICAgIHRleHRPdmVyZmxvdzogJ2VsbGlwc2lzJyxcclxuICAgICAgICAgICAgd2hpdGVTcGFjZTogJ25vd3JhcCcsXHJcbiAgICAgICAgICAgIGNvbG9yOiBjb2xvci5wYWxldHRlLnByaW1hcnkuZXh0cmFMaWdodCxcclxuICAgICAgICAgICAgZm9udFNpemU6IGZvbnQuaDYuZm9udFNpemUsXHJcbiAgICAgICAgICAgICcmLk11aS1lcnJvcic6IHtcclxuICAgICAgICAgICAgICAgIGNvbG9yOiBjb2xvci5wYWxldHRlLnByaW1hcnkuZXh0cmFMaWdodFxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAnJj5kaXYnOntcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAnMTAwJScsXHJcbiAgICAgICAgICAgICAgICBvdmVyZmxvdzogJ2hpZGRlbicsXHJcbiAgICAgICAgICAgICAgICB0ZXh0T3ZlcmZsb3c6ICdlbGxpcHNpcycsXHJcbiAgICAgICAgICAgICAgICB3aGl0ZVNwYWNlOiAnbm93cmFwJyxcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZmlsbGVkOiB7XHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZSgxNnB4LCAxN3B4KSBzY2FsZSgxKScsXHJcbiAgICAgICAgICAgIHBhZGRpbmdSaWdodDonNDVweCcsXHJcbiAgICAgICAgICAgICcmLk11aUlucHV0TGFiZWwtc2hyaW5rJzoge1xyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlKDE2cHgsIDEwcHgpIHNjYWxlKDAuNzUpJ1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIE11aVRleHRGaWVsZDoge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMHB4J1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBNdWlGb3JtQ29udHJvbDoge1xyXG4gICAgICAgIHJvb3Q6IHtcclxuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnMjRweCcsXHJcbiAgICAgICAgICAgICcmLm5vTWFyZ2luJzoge1xyXG4gICAgICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAnOHB4J1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSW5wdXRPdmVyUmlkZTtcclxuIiwiaW1wb3J0IEFsZXJ0T3ZlcmlkZSBmcm9tICcuL0FsZXJ0T3ZlcmlkZSc7XHJcbmltcG9ydCBCdXR0b25PdmVyaWRlIGZyb20gJy4vQnV0dG9uT3ZlcmlkZSc7XHJcbmltcG9ydCBDYXJkT3ZlcmlkZSBmcm9tICcuL0NhcmRPdmVyaWRlJztcclxuaW1wb3J0IENoZWNrQm94T3ZlcmlkZSBmcm9tICcuL0NoZWNrQm94T3ZlcmlkZSc7XHJcbmltcG9ydCBEaWFsb2dPdmVyaWRlIGZyb20gJy4vRGlhbG9nT3ZlcmlkZSc7XHJcbmltcG9ydCBJbnB1dE92ZXJpZGUgZnJvbSAnLi9JbnB1dE92ZXJpZGUnO1xyXG5pbXBvcnQgUHJvZ3Jlc3NCYXJPdmVyaWRlIGZyb20gJy4vUHJvZ3Jlc3NCYXJPdmVyaWRlJztcclxuaW1wb3J0IFJhZGlvT3ZlcmlkZSBmcm9tICcuL1JhZGlvT3ZlcmlkZSc7XHJcbmltcG9ydCBTZWxlY3RPdmVyaWRlIGZyb20gJy4vU2VsZWN0T3ZlcmlkZSc7XHJcbmltcG9ydCBTd2l0Y2hPdmVyaWRlIGZyb20gJy4vU3dpdGNoT3ZlcmlkZSc7XHJcbmltcG9ydCBUYWJPdmVyaWRlIGZyb20gJy4vVGFiT3ZlcmlkZSc7XHJcblxyXG5jb25zdCBPdmVyaWRlID0ge1xyXG4gICAgb3ZlcnJpZGVzOiB7XHJcbiAgICAgICAgLi4uQnV0dG9uT3ZlcmlkZSxcclxuICAgICAgICAuLi5JbnB1dE92ZXJpZGUsXHJcbiAgICAgICAgLi4uUmFkaW9PdmVyaWRlLFxyXG4gICAgICAgIC4uLkNoZWNrQm94T3ZlcmlkZSxcclxuICAgICAgICAuLi5Td2l0Y2hPdmVyaWRlLFxyXG4gICAgICAgIC4uLkNhcmRPdmVyaWRlLFxyXG4gICAgICAgIC4uLlNlbGVjdE92ZXJpZGUsXHJcbiAgICAgICAgLi4uRGlhbG9nT3ZlcmlkZSxcclxuICAgICAgICAuLi5Qcm9ncmVzc0Jhck92ZXJpZGUsXHJcbiAgICAgICAgLi4uQWxlcnRPdmVyaWRlLFxyXG4gICAgICAgIC4uLlRhYk92ZXJpZGVcclxuICAgIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IE92ZXJpZGU7XHJcbiIsIlxyXG5pbXBvcnQgY29sb3IgZnJvbSAnLi4vY29sb3InO1xyXG5cclxuY29uc3QgUHJvZ3Jlc3NCYXJPdmVyaWRlID0ge1xyXG4gICAgTXVpTGluZWFyUHJvZ3Jlc3M6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgIGhlaWdodDogJzEycHgnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBjb2xvclByaW1hcnk6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5jb21tb24ud2hpdGVcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJhcjFEZXRlcm1pbmF0ZToge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IGNvbG9yLnBhbGV0dGUuc3VjY2Vzcy5tYWluXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5leHBvcnQgZGVmYXVsdCBQcm9ncmVzc0Jhck92ZXJpZGU7XHJcbiIsImltcG9ydCBjb2xvciBmcm9tICcuLi9jb2xvcic7XHJcbmltcG9ydCBmb250IGZyb20gJy4uL3R5cG9ncmFwaHknO1xyXG5cclxuY29uc3QgUmFkaW9PdmVyUmlkZSA9IHtcclxuICAgIE11aVJhZGlvOiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICAnJi5leHRyYUxpZ2h0TGFiZWwgfiBzcGFuJzoge1xyXG4gICAgICAgICAgICAgICAgY29sb3I6IGNvbG9yLnBhbGV0dGUucHJpbWFyeS5leHRyYUxpZ2h0XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmLnNpemUyNCc6e1xyXG4gICAgICAgICAgICAgICAgJyYgLk11aVN2Z0ljb24tcm9vdCc6IHtcclxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udC5oNC5mb250U2l6ZSxcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBcIiZ+Lk11aUZvcm1Db250cm9sTGFiZWwtbGFiZWxcIjp7XHJcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZ1RvcDowXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmIC5NdWlTdmdJY29uLXJvb3QnOiB7XHJcbiAgICAgICAgICAgICAgICBjb2xvcjogJ3RyYW5zcGFyZW50JyxcclxuICAgICAgICAgICAgICAgIGJvcmRlcjogYDFweCBzb2xpZCAke2NvbG9yLnBhbGV0dGUucHJpbWFyeS5leHRyYUxpZ2h0fWAsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogZm9udC5oM3hsLmZvbnRTaXplLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnNTAlJyxcclxuICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3IuY29tbW9uLndoaXRlXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmLk11aS1jaGVja2VkJzoge1xyXG4gICAgICAgICAgICAgICAgJyYgLk11aVN2Z0ljb24tcm9vdCc6IHtcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcjogY29sb3IucGFsZXR0ZS5zZWNvbmRhcnkuZGFya1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgUmFkaW9PdmVyUmlkZTtcclxuIiwiaW1wb3J0IGNvbG9yIGZyb20gJy4uL2NvbG9yJztcclxuXHJcbmNvbnN0IFNlbGVjdE92ZXJpZGUgPSB7XHJcbiAgICBNdWlTZWxlY3Q6IHtcclxuICAgICAgICBpY29uOiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGNvbG9yLnBhbGV0dGUubWVudXMubWVudUJhY2tncm91bmQsXHJcbiAgICAgICAgICAgIGhlaWdodDogJzUwcHgnLFxyXG4gICAgICAgICAgICBib3JkZXJSYWRpdXM6ICcwIDE2cHggMTZweCAwJyxcclxuICAgICAgICAgICAgbWluV2lkdGg6ICc0NHB4JyxcclxuICAgICAgICAgICAgdG9wOiAnMHB4JyxcclxuICAgICAgICAgICAgY29sb3I6ICd0cmFuc3BhcmVudCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGljb25GaWxsZWQ6IHtcclxuICAgICAgICAgICAgcmlnaHQ6IDBcclxuICAgICAgICB9LFxyXG4gICAgICAgIHNlbGVjdDoge1xyXG4gICAgICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcclxuICAgICAgICAgICAgJyY6YmVmb3JlJzoge1xyXG4gICAgICAgICAgICAgICAgY29udGVudDogJ1wiXFxcXGU5MDJcIicsXHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcclxuICAgICAgICAgICAgICAgIHJpZ2h0OiAnMTJweCcsXHJcbiAgICAgICAgICAgICAgICB6SW5kZXg6ICc5JyxcclxuICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk6ICdpY29tb29uICFpbXBvcnRhbnQnLFxyXG4gICAgICAgICAgICAgICAgdG9wOiAnMTdweCcsXHJcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogJzIwcHgnXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICcmOmZvY3VzJzoge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgTXVpUG9wb3Zlcjoge1xyXG4gICAgICAgIHBhcGVyOiB7XHJcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogJzE2cHgnXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgU2VsZWN0T3ZlcmlkZTtcclxuIiwiaW1wb3J0IGNvbG9yIGZyb20gJy4uL2NvbG9yJztcclxuXHJcbmNvbnN0IFN3aXRjaE92ZXJSaWRlID0ge1xyXG4gICAgTXVpU3dpdGNoOiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICB3aWR0aDogJzYwcHgnLFxyXG4gICAgICAgICAgICBoZWlnaHQ6ICczNnB4JyxcclxuICAgICAgICAgICAgcGFkZGluZzogJzBweCdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHRodW1iOiB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAnMzZweCcsXHJcbiAgICAgICAgICAgIGJvcmRlcjogYDFweCBzb2xpZCAke2NvbG9yLnBhbGV0dGUucHJpbWFyeS5saWdodH1gLFxyXG4gICAgICAgICAgICBoZWlnaHQ6ICczNnB4JyxcclxuICAgICAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXHJcbiAgICAgICAgICAgIGJveFNoYWRvdzogJ25vbmUnLFxyXG4gICAgICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5jb21tb24ud2hpdGUsXHJcbiAgICAgICAgICAgICcmOmFmdGVyJzoge1xyXG4gICAgICAgICAgICAgICAgY29udGVudDogJ1wiXCInLFxyXG4gICAgICAgICAgICAgICAgd2lkdGg6ICcxNnB4JyxcclxuICAgICAgICAgICAgICAgIGhlaWdodDogJzE2cHgnLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyOiBgMXB4IHNvbGlkICR7Y29sb3IucGFsZXR0ZS5wcmltYXJ5LmxpZ2h0fWAsXHJcbiAgICAgICAgICAgICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcclxuICAgICAgICAgICAgICAgIGxlZnQ6ICc1MCUnLFxyXG4gICAgICAgICAgICAgICAgdG9wOiAnNTAlJyxcclxuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogJ3RyYW5zbGF0ZSgtNTAlLCAtNTAlKScsXHJcbiAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM6IDUwXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHN3aXRjaEJhc2U6IHtcclxuICAgICAgICAgICAgcGFkZGluZzogMCxcclxuICAgICAgICAgICAgbWFyZ2luOiAwLFxyXG4gICAgICAgICAgICB0cmFuc2l0aW9uRHVyYXRpb246ICczMDBtcycsXHJcbiAgICAgICAgICAgICcmLk11aS1jaGVja2VkJzoge1xyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiAndHJhbnNsYXRlWCgyNHB4KScsXHJcbiAgICAgICAgICAgICAgICBjb2xvcjogY29sb3IuY29tbW9uLndoaXRlLFxyXG4gICAgICAgICAgICAgICAgJyYgKyAuTXVpU3dpdGNoLXRyYWNrJzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogYCR7Y29sb3IucGFsZXR0ZS5zZWNvbmRhcnkuZGFya30gIWltcG9ydGFudGAsXHJcbiAgICAgICAgICAgICAgICAgICAgb3BhY2l0eTogMVxyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICcmLk11aS1kaXNhYmxlZCArIC5NdWlTd2l0Y2gtdHJhY2snOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgb3BhY2l0eTogMC41XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHRyYWNrOiB7XHJcbiAgICAgICAgICAgIGJvcmRlcjogYDFweCBzb2xpZCAke2NvbG9yLnBhbGV0dGUucHJpbWFyeS5saWdodH1gLFxyXG4gICAgICAgICAgICBvcGFjaXR5OiAnMScsXHJcbiAgICAgICAgICAgIHRyYW5zaXRpb246ICdiYWNrZ3JvdW5kLWNvbG9yIDUwMG1zIGN1YmljLWJlemllcigwLjQsIDAsIDAuMiwgMSkgMG1zJyxcclxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAnNTBweCcsXHJcbiAgICAgICAgICAgIGJhY2tncm91bmRDb2xvcjogY29sb3IuY29tbW9uLmdyYXlcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IFN3aXRjaE92ZXJSaWRlO1xyXG4iLCJpbXBvcnQgY29sb3IgZnJvbSAnLi4vY29sb3InO1xyXG5cclxuY29uc3QgVGFiT3ZlcmlkZSA9IHtcclxuICAgIE11aVRhYnM6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgIG1pbldpZHRoOiAnNDAwcHgnLFxyXG5cclxuICAgICAgICAgICAgJyYudGV4dENvbG9ySW5oZXJpdCc6IHtcclxuICAgICAgICAgICAgICAgIG9wYWNpdHk6ICd1bnNldCcsXHJcbiAgICAgICAgICAgICAgICBtaW5XaWR0aDogJzQwMHB4J1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBlbmRJY29uOiB7XHJcbiAgICAgICAgICAgIG1hcmdpbkxlZnQ6ICc0cHgnXHJcbiAgICAgICAgfSxcclxuICAgICAgICB2ZXJ0aWNhbDoge1xyXG4gICAgICAgICAgICBtYXJnaW5Ub3A6ICcxOTBweCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgTXVpVGFiOiB7XHJcbiAgICAgICAgcm9vdDoge1xyXG4gICAgICAgICAgICBvcGFjaXR5OiAndW5zZXQgIWltcG9ydGFudCcsXHJcbiAgICAgICAgICAgIG1pbldpZHRoOiAnNDAwcHggIWltcG9ydGFudCcsXHJcbiAgICAgICAgICAgIHRleHRUcmFuc2Zvcm06ICdub25lJyxcclxuICAgICAgICAgICAgbWFyZ2luOiAnMTVweCAwJyxcclxuICAgICAgICAgICAgJyYuTXVpLXNlbGVjdGVkJzoge1xyXG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBjb2xvci5wYWxldHRlLnNlY29uZGFyeS5tYWluLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyVG9wTGVmdFJhZGl1czogJzIxcHgnLFxyXG4gICAgICAgICAgICAgICAgYm9yZGVyQm90dG9tTGVmdFJhZGl1czogJzIxcHgnLFxyXG4gICAgICAgICAgICAgICAgbWluSGVpZ2h0OiAnNTNweCcsXHJcbiAgICAgICAgICAgICAgICAnJiAuYXJyb3cgc3ZnJzoge1xyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk6ICdub25lJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICB3cmFwcGVyOiB7XHJcbiAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246ICdpbml0aWFsJyxcclxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ6ICdlbmQnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIFByaXZhdGVUYWJJbmRpY2F0b3I6IHtcclxuICAgICAgICByb290OiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdub25lJ1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFRhYk92ZXJpZGU7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL092ZXJpZGUnO1xyXG4iLCJleHBvcnQgZGVmYXVsdCB7XHJcbiAgICB1c2VOZXh0VmFyaWFudHM6IHRydWUsXHJcbiAgICBmb250U2l6ZTogMTYsXHJcblxyXG4gICAgaDE6IHtcclxuICAgICAgICBmb250U2l6ZTogNDRcclxuICAgIH0sXHJcbiAgICBoMjoge1xyXG4gICAgICAgIGZvbnRTaXplOiAzNlxyXG4gICAgfSxcclxuICAgIGgzeGw6IHtcclxuICAgICAgICBmb250U2l6ZTogMzJcclxuICAgIH0sXHJcbiAgICBoMzoge1xyXG4gICAgICAgIGZvbnRTaXplOiAyN1xyXG4gICAgfSxcclxuICAgIGg0eGw6IHtcclxuICAgICAgICBmb250U2l6ZTogMjVcclxuICAgIH0sXHJcbiAgICBoNDoge1xyXG4gICAgICAgIGZvbnRTaXplOiAyNFxyXG4gICAgfSxcclxuICAgIGg1eGw6IHtcclxuICAgICAgICBmb250U2l6ZTogMjJcclxuICAgIH0sXHJcbiAgICBoNToge1xyXG4gICAgICAgIGZvbnRTaXplOiAyMVxyXG4gICAgfSxcclxuICAgIGg2OiB7XHJcbiAgICAgICAgZm9udFNpemU6IDE3XHJcbiAgICB9LFxyXG4gICAgbGc6IHtcclxuICAgICAgICBmb250U2l6ZTogMTVcclxuICAgIH0sXHJcbiAgICBtZHhsOiB7XHJcbiAgICAgICAgZm9udFNpemU6IDE0XHJcbiAgICB9LFxyXG4gICAgbWQ6IHtcclxuICAgICAgICBmb250U2l6ZTogMTNcclxuICAgIH0sXHJcbiAgICBzbToge1xyXG4gICAgICAgIGZvbnRTaXplOiAxMlxyXG4gICAgfSxcclxuICAgIHhzOiB7XHJcbiAgICAgICAgZm9udFNpemU6IDExXHJcbiAgICB9LFxyXG5cclxuICAgIGZvbnRGYW1pbHk6IHtcclxuICAgICAgICByZWd1bGFyOiAnUG9wcGlucy1SZWd1bGFyJyxcclxuICAgICAgICBtZWRpdW06ICdQb3BwaW5zLU1lZGl1bScsXHJcbiAgICAgICAgc2VtaUJvbGQ6ICdQb3BwaW5zLVNlbWlCb2xkJyxcclxuICAgICAgICBib2xkOiAnUG9wcGlucy1Cb2xkJyxcclxuICAgICAgICBleHRyYUJvbGQ6ICdQb3BwaW5zLWV4dHJhQm9sZCdcclxuICAgIH0sXHJcbiAgICB0ZXh0VHJhbnNmb3JtOiB7XHJcbiAgICAgICAgdXBwZXJDYXNlOiAndXBwZXJjYXNlJ1xyXG4gICAgfVxyXG59O1xyXG4iLCJjb25zdCBDb2xvck92ZVJpZGUgPSB7XHJcbiAgICBjb21tb246IHtcclxuICAgICAgICB3aGl0ZTogJyNmZmYnLFxyXG4gICAgICAgIGJsYWNrOiAnIzAwMCcsXHJcbiAgICAgICAgZ3JheTogJyNGNUY1RjknLFxyXG4gICAgICAgIGZhY2Vib29rQmx1ZTogJyMzQjU5OTgnLFxyXG4gICAgICAgIGxpZ2h0Qmx1ZTogJyM4MjZmYWMnLFxyXG4gICAgICAgIGdyYXlUZXh0OiAnIzdDN0M5NScsXHJcbiAgICAgICAgZGVmYXVsdEJnQ29sb3I6ICcjQzRDNEM0JyxcclxuICAgICAgICBzZWNvbmRhcnlCZ0NvbG9yOiAnI0Q5RUVGRicsXHJcbiAgICAgICAgbGlnaHRCbGFjazogJyMxODE5MUYnXHJcbiAgICB9LFxyXG5cclxuICAgIHBhbGV0dGU6IHtcclxuICAgICAgICBwcmltYXJ5OiB7XHJcbiAgICAgICAgICAgIG1haW46ICcjMkYwQjdDJyxcclxuICAgICAgICAgICAgbGlnaHQ6ICcjMjYyODRFJyxcclxuICAgICAgICAgICAgZXh0cmFMaWdodDogJyM1ODVBNzknXHJcbiAgICAgICAgfSxcclxuICAgICAgICBzZWNvbmRhcnk6IHtcclxuICAgICAgICAgICAgZGFyazogJyMyN0NDQTUnLFxyXG4gICAgICAgICAgICBtYWluOiAnIzVFRUFDRicsXHJcbiAgICAgICAgICAgIGxpZ2h0OiAnI0QwRkZGNicsXHJcbiAgICAgICAgICAgIGV4dHJhTGlnaHQ6ICcjRjVGNUY5J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZXJyb3I6IHtcclxuICAgICAgICAgICAgZGFyazogJyNDQzI4MTEnLFxyXG4gICAgICAgICAgICBtYWluOiAnI0ZGNDc0RScsXHJcbiAgICAgICAgICAgIGxpZ2h0OiAnI0ZGODA4NCcsXHJcbiAgICAgICAgICAgIGV4dHJhTGlnaHQ6ICcjRkZEQkRDJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcGVuZGluZzoge1xyXG4gICAgICAgICAgICBtYWluOiAnI0ZFQ0Q0RicsXHJcbiAgICAgICAgICAgIGxpZ2h0OiAnI0ZGREM4MycsXHJcbiAgICAgICAgICAgIGV4dHJhTGlnaHQ6ICcjRkZGMUNFJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgc3VjY2Vzczoge1xyXG4gICAgICAgICAgICBtYWluOiAnIzI3Q0NBNScsXHJcbiAgICAgICAgICAgIGxpZ2h0OiAnIzVFRUFDRicsXHJcbiAgICAgICAgICAgIGV4dHJhTGlnaHQ6ICcjRDBGRkY2J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgaW5mbzoge1xyXG4gICAgICAgICAgICBtYWluOiAnIzk3OTdCRidcclxuICAgICAgICB9LFxyXG4gICAgICAgIGRlZmF1bHQ6IHtcclxuICAgICAgICAgICAgbWFpbjogJyM4NDhGRUUnXHJcbiAgICAgICAgfSxcclxuICAgICAgICBidXR0b246IHtcclxuICAgICAgICAgICAgc2Vjb25kYXJ5Q29sb3I6ICcjMjcwMjc2J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgbWVudXM6IHtcclxuICAgICAgICAgICAgbWVudUJhY2tncm91bmQ6ICcjRDlFRUZGJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgZGFzaGJvYXJkQmc6IHtcclxuICAgICAgICAgICAgbWFpbjogJyM1NzU3NTcnXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ29sb3JPdmVSaWRlO1xyXG4iLCJpbXBvcnQgeyBjcmVhdGVUaGVtZSB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XHJcbmltcG9ydCBicmVha3BvaW50cyBmcm9tICcuL2JyZWFrcG9pbnRzJztcclxuaW1wb3J0IGNvbG9yIGZyb20gJy4vY29sb3InO1xyXG5pbXBvcnQgT3ZlclJpZGVDc3MgZnJvbSAnLi9PdmVyaWRlJztcclxuaW1wb3J0IHR5cG9ncmFwaHkgZnJvbSAnLi90eXBvZ3JhcGh5JztcclxuXHJcbi8vIENyZWF0ZSBhIHRoZW1lIGluc3RhbmNlLlxyXG5jb25zdCB0aGVtZSA9IGNyZWF0ZVRoZW1lKHtcclxuICAgIHByb3BzOiB7XHJcbiAgICAgICAgLy8gd2l0aFdpZHRoIGNvbXBvbmVudCDimpvvuI9cclxuICAgICAgICBNdWlXaXRoV2lkdGg6IHtcclxuICAgICAgICAgICAgLy8gSW5pdGlhbCB3aWR0aCBwcm9wZXJ0eVxyXG4gICAgICAgICAgICBpbml0aWFsV2lkdGg6ICdsZycgLy8gQnJlYWtwb2ludCBiZWluZyBnbG9iYWxseSBzZXQg8J+MjiFcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdHlwb2dyYXBoeSxcclxuICAgIC4uLmJyZWFrcG9pbnRzLFxyXG4gICAgLi4uY29sb3IsXHJcbiAgICAuLi5PdmVyUmlkZUNzc1xyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHRoZW1lO1xyXG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicHJvcC10eXBlc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwic3R5bGVkLWpzeC9zZXJ2ZXJcIik7Il0sInNvdXJjZVJvb3QiOiIifQ==