module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./src/pages/commoncomponentstyle/index.js");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/head":
/*!****************************************************!*\
  !*** external "next/dist/next-server/lib/head.js" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/head.js");

/***/ }),

/***/ "../next-server/lib/to-base-64":
/*!**********************************************************!*\
  !*** external "next/dist/next-server/lib/to-base-64.js" ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/to-base-64.js");

/***/ }),

/***/ "../next-server/server/image-config":
/*!***************************************************************!*\
  !*** external "next/dist/next-server/server/image-config.js" ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/image-config.js");

/***/ }),

/***/ "./node_modules/next/dist/client/image.js":
/*!************************************************!*\
  !*** ./node_modules/next/dist/client/image.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = Image;

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/objectWithoutPropertiesLoose */ "./node_modules/next/node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js"));

var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/next/node_modules/@babel/runtime/helpers/extends.js"));

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _head = _interopRequireDefault(__webpack_require__(/*! ../next-server/lib/head */ "../next-server/lib/head"));

var _toBase = __webpack_require__(/*! ../next-server/lib/to-base-64 */ "../next-server/lib/to-base-64");

var _imageConfig = __webpack_require__(/*! ../next-server/server/image-config */ "../next-server/server/image-config");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

if (true) {
  ;
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['default', defaultLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];
const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","domains":[]} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout) {
  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout);
  const last = widths.length - 1;
  return {
    src: loader({
      src,
      quality,
      width: widths[last]
    }),
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', ')
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load((0, _extends2.default)({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
}

function Image(_ref) {
  let {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    loader = defaultImageLoader
  } = _ref,
      all = (0, _objectWithoutPropertiesLoose2.default)(_ref, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "objectFit", "objectPosition", "loader"]);
  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';
  let unsized = false;

  if ('unsized' in rest) {
    unsized = Boolean(rest.unsized); // Remove property so it's not spread into image:

    delete rest['unsized'];
  } else if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  if (true) {
    if (!src) {
      throw new Error(`Image is missing required "src" property. Make sure you pass "src" in props to the \`next/image\` component. Received: ${JSON.stringify({
        width,
        height,
        quality
      })}`);
    }

    if (!VALID_LAYOUT_VALUES.includes(layout)) {
      throw new Error(`Image with src "${src}" has invalid "layout" property. Provided "${layout}" should be one of ${VALID_LAYOUT_VALUES.map(String).join(',')}.`);
    }

    if (!VALID_LOADING_VALUES.includes(loading)) {
      throw new Error(`Image with src "${src}" has invalid "loading" property. Provided "${loading}" should be one of ${VALID_LOADING_VALUES.map(String).join(',')}.`);
    }

    if (priority && loading === 'lazy') {
      throw new Error(`Image with src "${src}" has both "priority" and "loading='lazy'" properties. Only one should be used.`);
    }

    if (unsized) {
      throw new Error(`Image with src "${src}" has deprecated "unsized" property, which was removed in favor of the "layout='fill'" property`);
    }
  }

  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src && src.startsWith('data:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  const [setRef, isIntersected] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px',
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = {
    visibility: isVisible ? 'inherit' : 'hidden',
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  };

  if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined' && layout !== 'fill') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else if (typeof widthInt === 'undefined' && typeof heightInt === 'undefined' && layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else {
    // <Image src="i.png" />
    if (true) {
      throw new Error(`Image with src "${src}" must use "width" and "height" properties or "layout='fill'" property.`);
    }
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  if (unsized) {
    wrapperStyle = undefined;
    sizerStyle = undefined;
    imgStyle = undefined;
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    role: "presentation",
    src: `data:image/svg+xml;base64,${(0, _toBase.toBase64)(sizerSvg)}`
  }) : null) : null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    className: className,
    ref: setRef,
    style: imgStyle
  })), priority ?
  /*#__PURE__*/
  // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src // @ts-ignore: imagesrcset is not yet in the link element type
    ,
    imagesrcset: imgAttributes.srcSet // @ts-ignore: imagesizes is not yet in the link element type
    ,
    imagesizes: imgAttributes.sizes
  })) : null);
} //BUILT IN LOADERS


function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?format=auto&fit=max&w=300
  const params = ['auto=format', 'fit=max', 'w=' + width];
  let paramsString = '';

  if (quality) {
    params.push('q=' + quality);
  }

  if (params.length) {
    paramsString = '?' + params.join('&');
  }

  return `${root}${normalizeSrc(src)}${paramsString}`;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (true) {
    const missingValues = []; // these should always be provided but make sure they are

    if (!src) missingValues.push('src');
    if (!width) missingValues.push('width');

    if (missingValues.length > 0) {
      throw new Error(`Next Image Optimization requires ${missingValues.join(', ')} to be provided. Make sure you pass them as props to the \`next/image\` component. Received: ${JSON.stringify({
        src,
        width,
        quality
      })}`);
    }

    if (src.startsWith('//')) {
      throw new Error(`Failed to parse src "${src}" on \`next/image\`, protocol-relative URL (//) must be changed to an absolute URL (http:// or https://)`);
    }

    if (!src.startsWith('/') && configDomains) {
      let parsedSrc;

      try {
        parsedSrc = new URL(src);
      } catch (err) {
        console.error(err);
        throw new Error(`Failed to parse src "${src}" on \`next/image\`, if using relative image it must start with a leading slash "/" or be an absolute URL (http:// or https://)`);
      }

      if (!configDomains.includes(parsedSrc.hostname)) {
        throw new Error(`Invalid src prop (${src}) on \`next/image\`, hostname "${parsedSrc.hostname}" is not configured under images in your \`next.config.js\`\n` + `See more info: https://err.sh/next.js/next-image-unconfigured-host`);
      }
    }
  }

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/image.js":
/*!************************************!*\
  !*** ./node_modules/next/image.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/image */ "./node_modules/next/dist/client/image.js")


/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/extends.js":
/*!**************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/extends.js ***!
  \**************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!****************************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \****************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/next/node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js":
/*!***********************************************************************************************!*\
  !*** ./node_modules/next/node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js ***!
  \***********************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ "./src/modules/StyledComponentModule/StyledComponentModule.js":
/*!********************************************************************!*\
  !*** ./src/modules/StyledComponentModule/StyledComponentModule.js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/icons/Close */ "@material-ui/icons/Close");
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons_ExpandMoreOutlined__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/ExpandMoreOutlined */ "@material-ui/icons/ExpandMoreOutlined");
/* harmony import */ var _material_ui_icons_ExpandMoreOutlined__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_ExpandMoreOutlined__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! shared/components/Header/MainHeader */ "./src/shared/components/Header/MainHeader/index.js");
/* harmony import */ var _shared_components_Alert_Alerts__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/shared/components/Alert/Alerts */ "./src/shared/components/Alert/Alerts.js");
/* harmony import */ var _shared_components_Annotations__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ~/shared/components/Annotations */ "./src/shared/components/Annotations/index.js");
/* harmony import */ var _shared_components_Chips__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ~/shared/components/Chips */ "./src/shared/components/Chips/index.js");
/* harmony import */ var _shared_components_FormErrorMessage__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ~/shared/components/FormErrorMessage */ "./src/shared/components/FormErrorMessage/index.js");
/* harmony import */ var _shared_components_Header_TopHeader__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/shared/components/Header/TopHeader */ "./src/shared/components/Header/TopHeader/index.js");
/* harmony import */ var _shared_components_Indicators__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~/shared/components/Indicators */ "./src/shared/components/Indicators/index.js");
/* harmony import */ var _shared_components_LogoHeading__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ~/shared/components/LogoHeading */ "./src/shared/components/LogoHeading/index.js");
/* harmony import */ var _shared_components_ObjectCard__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ~/shared/components/ObjectCard */ "./src/shared/components/ObjectCard/index.js");
/* harmony import */ var _shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ~/shared/components/PageHeading */ "./src/shared/components/PageHeading/index.js");
/* harmony import */ var _shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ~/shared/components/ProgramCard */ "./src/shared/components/ProgramCard/index.js");
/* harmony import */ var _shared_components_Tooltip__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ~/shared/components/Tooltip */ "./src/shared/components/Tooltip/index.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\modules\\StyledComponentModule\\StyledComponentModule.js";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










 // import MobileMenu from 'shared/components/Header/MobileMenu';







 // import EligiblePrograms from '../HouseHoldModule/HouseholdMembers/EligiblePrograms';

/**
 * Name: StyledComponent
 * Desc: Render StyledComponent
 */

const handleDelete = () => {
  // eslint-disable-next-line no-console
  console.info('You clicked the delete icon.');
};

const StyledComponentModule = () => {
  const {
    0: value,
    1: setValue
  } = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])('female');
  const {
    0: checked,
    1: setChecked
  } = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(true);
  const {
    0: showDetails,
    1: setShowDetails
  } = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false);
  const {
    0: state,
    1: setState
  } = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])({
    checkedA: true,
    checkedB: true
  });
  const [select, setselect] = react__WEBPACK_IMPORTED_MODULE_4___default.a.useState('');

  const handleChangeSelectBox = event => {
    setselect(event.target.value);
  };

  const {
    0: openDialog,
    1: setOpenDialog
  } = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false);

  const handleClickOpenDialog = () => {
    setOpenDialog(true);
  };

  const handleClose = () => {
    setOpenDialog(false);
  };

  const handleChange = event => {
    setValue(event.target.value);
  };

  const handleChangeCheckBox = event => {
    setChecked(event.target.checked);
  };

  const handleChangeSwitchBox = event => {
    setState(_objectSpread(_objectSpread({}, state), {}, {
      [event.target.name]: event.target.checked
    }));
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    bgcolor: "secondary.light",
    py: 2,
    px: 2,
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
      container: true,
      spacing: 3,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "App name"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 100,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_LogoHeading__WEBPACK_IMPORTED_MODULE_13__["default"], {
          title: "AppName"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 101,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 99,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "Client Logo"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 104,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Avatar"], {
            alt: "logo",
            src: "/logo.svg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 106,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 105,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 103,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "Buttons"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 111,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          flexWrap: "wrap",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            pb: 8,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
              mb: 3,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "large",
                color: "primary",
                variant: "contained",
                children: "smaller"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 119,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                color: "primary",
                variant: "contained",
                children: "Smallest"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 122,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "small",
                color: "primary",
                variant: "contained",
                children: "I\u2019m tiny"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 125,
                columnNumber: 33
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 114,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
              mb: 3,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "large",
                color: "secondary",
                variant: "contained",
                children: "smaller"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 134,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "medium",
                color: "secondary",
                variant: "contained",
                children: "Smallest"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 137,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "small",
                color: "secondary",
                variant: "contained",
                children: "I\u2019m tiny"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 140,
                columnNumber: 33
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 129,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
              mb: 3,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "large",
                color: "inherit",
                variant: "contained",
                children: "smaller"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 149,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "medium",
                color: "inherit",
                variant: "contained",
                children: "Smallest"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 152,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "small",
                color: "inherit",
                variant: "contained",
                children: "I\u2019m tiny"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 155,
                columnNumber: 33
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 144,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 113,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            mb: 8,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              mb: 3,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                fullWidth: true,
                size: "large",
                color: "primary",
                className: "semiBorder",
                variant: "contained",
                children: "Get Started"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 162,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 161,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              mb: 3,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                fullWidth: true,
                size: "large",
                color: "secondary",
                className: "semiBorder",
                variant: "contained",
                children: "Get Started"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 172,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 171,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              mb: 3,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                size: "large",
                className: "semiBorder",
                variant: "contained",
                children: "Get Started"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 182,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 181,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 160,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 112,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 110,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "INDICATORS"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 191,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          justifyContent: "space-between",
          children: ['pending', 'success', 'failed', 'default', 'complete'].map((item, index) => {
            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Indicators__WEBPACK_IMPORTED_MODULE_12__["default"], {
              status: item
            }, index, false, {
              fileName: _jsxFileName,
              lineNumber: 195,
              columnNumber: 40
            }, undefined);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 192,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 190,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "Controls"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 201,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "Tooltip"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 206,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Tooltip__WEBPACK_IMPORTED_MODULE_17__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 208,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 207,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 200,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "info.main",
          fontFamily: "fontFamily.bold",
          pb: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
            variant: "h3",
            children: "Input Box"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 214,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 213,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 2.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormControl"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["TextField"], {
              id: "standard-basic",
              label: "Standard",
              variant: "filled",
              error: true,
              helperText: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_FormErrorMessage__WEBPACK_IMPORTED_MODULE_10__["default"], {
                title: "Please enter your telephone number",
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["AlertTriangle"], {
                  size: 9
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 225,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 224,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 218,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 217,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 216,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 2.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormControl"], {
            fullWidth: true,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["TextField"], {
              variant: "filled",
              label: "Field Input Label",
              value: "text",
              InputProps: {
                endAdornment: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["InputAdornment"], {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
                    className: "icon-search"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 240,
                    columnNumber: 45
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 239,
                  columnNumber: 41
                }, undefined)
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 233,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 232,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 231,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 2.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormControl"], {
            variant: "filled",
            fullWidth: true,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Select"], {
              labelId: "demo-simple-select-label",
              id: "demo-simple-select",
              value: select,
              onChange: handleChangeSelectBox,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                value: 10,
                children: "Ten"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 254,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                value: 20,
                children: "Twenty"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 255,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                value: 30,
                children: "Thirty"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 256,
                columnNumber: 33
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 249,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 248,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 247,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 212,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "Annotations"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 263,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Annotations__WEBPACK_IMPORTED_MODULE_8__["default"], {
            bgColor: "primary.main",
            color: "common.white",
            minHeights: 147,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              fontSize: "h6.fontSize",
              fontFamily: "fontFamily.medium",
              children: "Design To Do: Design error messages for screens."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 266,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 265,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 264,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Annotations__WEBPACK_IMPORTED_MODULE_8__["default"], {
            bgColor: "error.dark",
            color: "common.white",
            minHeights: 147,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              fontSize: "h6.fontSize",
              fontFamily: "fontFamily.medium",
              children: "Here\u2019s a discussion note for this screen."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 273,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 272,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 271,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Annotations__WEBPACK_IMPORTED_MODULE_8__["default"], {
            bgColor: "pending.main",
            color: "common.darkBlack",
            minHeights: 147,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              fontSize: "h6.fontSize",
              fontFamily: "fontFamily.medium",
              children: "Here\u2019s a note for this screen."
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 283,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 279,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 278,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 262,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "Program Card"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 290,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_16__["default"], {
            variant: "waiting",
            showDeleteBox: true,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.main",
              fontSize: "h6.fontSize",
              fontFamily: "fontFamily.medium",
              children: "Program Title on Card (1BR)"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 293,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              component: "body1",
              color: "primary.light",
              fontSize: "lg.fontSize",
              fontFamily: "fontFamily.regular",
              children: "Waitlist or on-track status"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 299,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 292,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 291,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_16__["default"], {
            variant: "success",
            showLeftArrow: true,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.main",
              fontSize: "h6.fontSize",
              fontFamily: "fontFamily.medium",
              children: "Small Card Title"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 311,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              component: "body1",
              color: "primary.light",
              fontSize: "lg.fontSize",
              fontFamily: "fontFamily.regular",
              children: "Small card status indicator line"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 317,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 310,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 309,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_16__["default"], {
            variant: "failed",
            showImage: true,
            showLeftArrow: true,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.main",
              fontSize: "h6.fontSize",
              fontFamily: "fontFamily.medium",
              children: "Small Card Title"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 329,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              component: "body1",
              color: "primary.light",
              fontSize: "lg.fontSize",
              fontFamily: "fontFamily.regular",
              children: "Waitlist or on-track status"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 335,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 328,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 327,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ProgramCard__WEBPACK_IMPORTED_MODULE_16__["default"], {
            variant: "success",
            showImage: true,
            showLeftBorder: false,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.main",
              fontSize: "h6.fontSize",
              fontFamily: "fontFamily.medium",
              children: "Program Title on Card (1BR)"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 347,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              component: "body1",
              color: "primary.light",
              fontSize: "lg.fontSize",
              fontFamily: "fontFamily.regular",
              children: "Waitlist or on-track status"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 353,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 346,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 345,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 289,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "Object Card"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 365,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ObjectCard__WEBPACK_IMPORTED_MODULE_14__["default"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.dark",
              fontSize: "h6.fontSize",
              fontFamily: "fontFamily.medium",
              children: "Erika Alexander"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 369,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.light",
              fontSize: "lg.fontSize",
              fontFamily: "fontFamily.regular",
              children: "Applicant"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 375,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 368,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 367,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ObjectCard__WEBPACK_IMPORTED_MODULE_14__["default"], {
            cardType: "actionCard",
            iconName: "plus",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              color: "primary.dark",
              fontSize: "h6.fontSize",
              fontFamily: "fontFamily.medium",
              children: "Add Another Person"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 394,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 393,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 392,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 6.25,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "flex-start",
              p: 2.5,
              minHeight: 96,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                display: "flex",
                justifyContent: "flex-end",
                minWidth: 38,
                flex: "0 0 38px",
                mt: 1.25,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], {
                  checked: checked,
                  onChange: handleChange
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 412,
                  columnNumber: 37
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 406,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                ml: 0.5,
                flexGrow: 2,
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.dark",
                  fontSize: "h6.fontSize",
                  fontFamily: "fontFamily.medium",
                  children: "Housing Choice Voucher"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 420,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.light",
                  fontSize: "md.fontSize",
                  fontFamily: "fontFamily.regular",
                  children: "Find your own unit"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 426,
                  columnNumber: 37
                }, undefined), showDetails && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "common.lightBlue",
                  fontSize: "md.fontSize",
                  fontFamily: "fontFamily.regular",
                  mb: 1,
                  mt: 1,
                  children: "The Eisenhower is a waitlisted multi-unit housing option in Northeast El Paso with 2, 3, and 4 bedroom units made available through HACEP\u2019s Program-Based Voucher system."
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 434,
                  columnNumber: 41
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  color: "primary.mian",
                  fontSize: "md.fontSize",
                  fontFamily: "fontFamily.regular",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
                    component: "button",
                    color: "primary",
                    underline: "none",
                    onClick: () => setShowDetails(!showDetails),
                    children: !showDetails ? ' Show Details' : 'Hide Details'
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 450,
                    columnNumber: 41
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 446,
                  columnNumber: 37
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 414,
                columnNumber: 33
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 405,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 404,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 403,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 364,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "Alerts"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 464,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Alert_Alerts__WEBPACK_IMPORTED_MODULE_7__["default"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 465,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 463,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.light",
          fontFamily: "fontFamily.bold",
          pb: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
            variant: "h3",
            children: "Radio Button"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 469,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 468,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 2.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormControl"], {
            component: "fieldset",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormLabel"], {
              component: "legend",
              children: "Gender"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 474,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["RadioGroup"], {
              "aria-label": "gender",
              name: "gender1",
              value: value,
              onChange: handleChange,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormControlLabel"], {
                value: "female",
                control: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Radio"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 482,
                  columnNumber: 46
                }, undefined),
                label: "Female"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 480,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormControlLabel"], {
                value: "male",
                control: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Radio"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 485,
                  columnNumber: 73
                }, undefined),
                label: "Male"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 485,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormControlLabel"], {
                value: "other",
                control: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Radio"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 486,
                  columnNumber: 74
                }, undefined),
                label: "Other"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 486,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormControlLabel"], {
                value: "disabled",
                disabled: true,
                control: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Radio"], {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 490,
                  columnNumber: 46
                }, undefined),
                label: "(Disabled option)"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 487,
                columnNumber: 33
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 475,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 473,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 471,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.light",
          fontFamily: "fontFamily.bold",
          pb: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
            variant: "h3",
            children: "Check Box"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 497,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 496,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 2.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Checkbox"], {
            checked: checked,
            onChange: handleChangeCheckBox,
            inputProps: {
              'aria-label': 'primary checkbox'
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 500,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 499,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.light",
          fontFamily: "fontFamily.bold",
          pb: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
            variant: "h3",
            children: "Toggle Switch"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 507,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 506,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 2.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Switch"], {
            checked: state.checkedB,
            onChange: handleChangeSwitchBox,
            name: "checkedB",
            inputProps: {
              'aria-label': 'primary checkbox'
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 510,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 509,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 467,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "info.main",
          fontFamily: "fontFamily.bold",
          pb: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Typography"], {
            variant: "h3",
            children: "Tags"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 520,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 519,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Chips__WEBPACK_IMPORTED_MODULE_9__["default"], {
            label: "Tag Name",
            color: "primary"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 523,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 522,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 2,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Chips__WEBPACK_IMPORTED_MODULE_9__["default"], {
            label: "Active Tag",
            color: "secondary",
            onDelete: handleDelete
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 526,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 525,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 518,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "Cards"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 531,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 4,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              minHeight: 96,
              width: "100%"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 534,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 533,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 532,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              minHeight: 604,
              width: "100%"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 539,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 538,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 537,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 530,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          fontSize: "xlg.fontSize",
          fontFamily: "fontFamily.bold",
          bgcolor: "primary.main",
          color: "white",
          children: "change font Size and Family using box"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 544,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 543,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_6__["default"], {}, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 554,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 553,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Header_TopHeader__WEBPACK_IMPORTED_MODULE_11__["default"], {
          isWizard: true
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 556,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_Header_MainHeader__WEBPACK_IMPORTED_MODULE_6__["default"], {
          isLoggedIn: true
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 557,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 552,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Grid"], {
        item: true,
        xs: 12,
        md: 12,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_PageHeading__WEBPACK_IMPORTED_MODULE_15__["default"], {
          title: "DialogBox"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 561,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
            variant: "outlined",
            color: "primary",
            onClick: handleClickOpenDialog,
            children: "Open simple dialog"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 563,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Dialog"], {
            onClose: handleClose,
            "aria-labelledby": "simple-dialog-title",
            open: openDialog,
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["DialogTitle"], {
              id: "simple-dialog-title",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
                "aria-label": "close",
                onClick: handleClose,
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2___default.a, {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 573,
                  columnNumber: 37
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 572,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 571,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["DialogContent"], {
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                textAlign: "center",
                pt: 2.5,
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  fontSize: "h3.fontSize",
                  fontFamily: "fontFamily.bold",
                  color: "primary.light",
                  pb: 1,
                  children: "Select your language"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 578,
                  columnNumber: 37
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  fontSize: "lg.fontSize",
                  fontStyle: "italic",
                  color: "primary.extraLight",
                  children: "Elige tu idioma"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 585,
                  columnNumber: 37
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 577,
                columnNumber: 33
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                  maxWidth: 256,
                  mx: "auto",
                  py: 3,
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["FormControl"], {
                    variant: "filled",
                    fullWidth: true,
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Select"], {
                      labelId: "demo-simple-select-label",
                      id: "demo-simple-select",
                      iconcomponent: _material_ui_icons_ExpandMoreOutlined__WEBPACK_IMPORTED_MODULE_3___default.a,
                      value: select,
                      onChange: handleChangeSelectBox,
                      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                        value: 1,
                        children: "English"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 601,
                        columnNumber: 49
                      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                        value: 2,
                        children: "German"
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 602,
                        columnNumber: 49
                      }, undefined)]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 595,
                      columnNumber: 45
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 594,
                    columnNumber: 41
                  }, undefined)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 593,
                  columnNumber: 37
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 592,
                columnNumber: 33
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 576,
              columnNumber: 29
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
                fullWidth: true,
                size: "large",
                color: "secondary",
                className: "semiBorder",
                variant: "contained",
                children: "Continue"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 609,
                columnNumber: 33
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 608,
              columnNumber: 29
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 567,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 562,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 560,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 94,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (StyledComponentModule);

/***/ }),

/***/ "./src/modules/StyledComponentModule/index.js":
/*!****************************************************!*\
  !*** ./src/modules/StyledComponentModule/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _StyledComponentModule__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./StyledComponentModule */ "./src/modules/StyledComponentModule/StyledComponentModule.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _StyledComponentModule__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/pages/commoncomponentstyle/index.js":
/*!*************************************************!*\
  !*** ./src/pages/commoncomponentstyle/index.js ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _modules_StyledComponentModule__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ~/modules/StyledComponentModule */ "./src/modules/StyledComponentModule/index.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\pages\\commoncomponentstyle\\index.js";


/** 
 * Name : CommonComponentStyle 
 * desc : Render CommonComponentStyle
**/

function CommonComponentStyle() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_modules_StyledComponentModule__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 13
    }, this)
  }, void 0, false);
}

/* harmony default export */ __webpack_exports__["default"] = (CommonComponentStyle);

/***/ }),

/***/ "./src/shared/components/Alert/Alerts.js":
/*!***********************************************!*\
  !*** ./src/shared/components/Alert/Alerts.js ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_lab__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/lab */ "@material-ui/lab");
/* harmony import */ var _material_ui_lab__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_lab__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _AlertsStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./AlertsStyles */ "./src/shared/components/Alert/AlertsStyles.js");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_6__);


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Alert\\Alerts.js";






/**
 * Name: Alerts
 * Desc: Render Alerts
 */

const Alerts = ({
  variant,
  iconColor,
  children,
  showCloseBtn
}) => {
  const classes = Object(_AlertsStyles__WEBPACK_IMPORTED_MODULE_5__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
      className: classes[variant],
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_lab__WEBPACK_IMPORTED_MODULE_2__["Alert"], {
        action: showCloseBtn && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_3__["X"], {
            strokeWidth: "3",
            color: iconColor
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 33
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 29
        }, undefined),
        children: children && children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

Alerts.defaultProps = {
  showCloseBtn: false
};
Alerts.propTypes = {
  variant: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.oneOf(["primaryAlert", "secondaryAlert"]),
  iconColor: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.oneOf(["white", "indigo"]),
  children: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.node,
  showCloseBtn: prop_types__WEBPACK_IMPORTED_MODULE_6___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (Alerts);

/***/ }),

/***/ "./src/shared/components/Alert/AlertsStyles.js":
/*!*****************************************************!*\
  !*** ./src/shared/components/Alert/AlertsStyles.js ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  primaryAlert: {
    backgroundColor: theme.palette.primary.main,
    color: theme.common.white,
    boxShadow: "none",
    borderRadius: "0"
  },
  secondaryAlert: {
    backgroundColor: theme.palette.menus.menuBackground,
    color: theme.palette.primary.light,
    boxShadow: "none",
    borderRadius: "0"
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Annotations/Annotations.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/Annotations/Annotations.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Annotations\\Annotations.js";



/**
 * Name : Annotations
 * Desc : Render Annotations
 * @param { string } bgColor
 * @param { string } color
 * @param { number } minHeights
 * @param { node } children
 **/

const Annotations = ({
  bgColor,
  color,
  children,
  minHeights
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      bgcolor: bgColor,
      color: color,
      padding: 3.5,
      minHeight: minHeights,
      children: children && children
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 13
    }, undefined)
  }, void 0, false);
};

Annotations.propTypes = {
  bgColor: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  color: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  children: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.node,
  minHeights: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.number
};
/* harmony default export */ __webpack_exports__["default"] = (Annotations);

/***/ }),

/***/ "./src/shared/components/Annotations/index.js":
/*!****************************************************!*\
  !*** ./src/shared/components/Annotations/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Annotations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Annotations */ "./src/shared/components/Annotations/Annotations.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Annotations__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Chips/Chips.js":
/*!**********************************************!*\
  !*** ./src/shared/components/Chips/Chips.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _ChipsStyles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ChipsStyles */ "./src/shared/components/Chips/ChipsStyles.js");
/* harmony import */ var _material_ui_icons_CloseOutlined__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/icons/CloseOutlined */ "@material-ui/icons/CloseOutlined");
/* harmony import */ var _material_ui_icons_CloseOutlined__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_CloseOutlined__WEBPACK_IMPORTED_MODULE_5__);

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Chips\\Chips.js";





/**
 * Name: Chips
 * Desc: Render Chips
 * @param { string } label
 * @param { string } color
 * @param { func } onDelete
 */

const Chips = ({
  label,
  color,
  onDelete
}) => {
  const classes = Object(_ChipsStyles__WEBPACK_IMPORTED_MODULE_4__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Chip"], {
      label: label,
      color: color,
      onDelete: onDelete,
      className: classes.root,
      deleteIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_CloseOutlined__WEBPACK_IMPORTED_MODULE_5___default.a, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 24,
        columnNumber: 29
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 9
  }, undefined);
};

Chips.propTypes = {
  label: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string,
  color: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string,
  onDelete: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func
};
/* harmony default export */ __webpack_exports__["default"] = (Chips);

/***/ }),

/***/ "./src/shared/components/Chips/ChipsStyles.js":
/*!****************************************************!*\
  !*** ./src/shared/components/Chips/ChipsStyles.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  root: {
    '&.MuiChip-root': {
      fontSize: theme.typography.fontSize.sm,
      fontFamily: theme.typography.fontFamily.extraBold,
      border: `1px solid ${theme.palette.primary.light}`,
      height: theme.spacing(4.5),
      borderRadius: 50
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Chips/index.js":
/*!**********************************************!*\
  !*** ./src/shared/components/Chips/index.js ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Chips__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Chips */ "./src/shared/components/Chips/Chips.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Chips__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/ExitDialogBox/ExitDialogBox.js":
/*!**************************************************************!*\
  !*** ./src/shared/components/ExitDialogBox/ExitDialogBox.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/icons/Close */ "@material-ui/icons/Close");
/* harmony import */ var _material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\ExitDialogBox\\ExitDialogBox.js";




/**
 * Name: ExitDialogBox
 * Desc: Render ExitDialogBox
 */

const ExitDialogBox = ({
  onConfirm,
  onClose
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["DialogTitle"], {
      id: "simple-dialog-title",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
        "aria-label": "close",
        onClick: onClose,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_Close__WEBPACK_IMPORTED_MODULE_2___default.a, {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["DialogContent"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        textAlign: "center",
        pt: 2.5,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          fontSize: "h3.fontSize",
          fontFamily: "fontFamily.bold",
          color: "primary.light",
          pb: 1,
          children: "Are you sure you want to exit before finishing?"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          fontSize: "lg.fontSize",
          color: "primary.extraLight",
          mb: 3,
          children: "Any progress you\u2019ve made won\u2019t be saved yet."
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 20,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 19,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
        fullWidth: true,
        size: "large",
        color: "secondary",
        className: "semiBorder",
        variant: "contained",
        style: {
          borderRadius: 0
        },
        onClick: onConfirm,
        children: "Yes, Exit Now"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
        fullWidth: true,
        size: "large",
        color: "primary",
        className: "semiBorder",
        variant: "contained",
        onClick: onClose,
        children: "No, Keep Going"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 13
    }, undefined)]
  }, void 0, true);
};

ExitDialogBox.propTypes = {
  onConfirm: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  onClose: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func
};
/* harmony default export */ __webpack_exports__["default"] = (ExitDialogBox);

/***/ }),

/***/ "./src/shared/components/ExitDialogBox/index.js":
/*!******************************************************!*\
  !*** ./src/shared/components/ExitDialogBox/index.js ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ExitDialogBox__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ExitDialogBox */ "./src/shared/components/ExitDialogBox/ExitDialogBox.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _ExitDialogBox__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/FormErrorMessage/FormErrorMessage.js":
/*!********************************************************************!*\
  !*** ./src/shared/components/FormErrorMessage/FormErrorMessage.js ***!
  \********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_4__);

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\FormErrorMessage\\FormErrorMessage.js";




/**
 * Name : FormErrorMessage
 * Desc : Render FormErrorMessage
 * @param { srting } title
 * @param { node } children
 */

const FormErrorMessage = ({
  title,
  children
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    display: "flex",
    mx: -1.75,
    pt: 0.5,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      flex: "0 0 16px",
      bgcolor: "error.main",
      justifyContent: "center",
      alignItems: "center",
      width: 16,
      height: 16,
      borderRadius: "50%",
      color: "common.white",
      mr: 0.5,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_4__["AlertTriangle"], {
        size: 9
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 17
      }, undefined), children && children]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 16,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      fontSize: "md.fontSize",
      lineHeight: "1",
      color: "error.dark",
      pt: 0.25,
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 9
  }, undefined);
};

FormErrorMessage.propTypes = {
  title: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  children: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.node
};
/* harmony default export */ __webpack_exports__["default"] = (FormErrorMessage);

/***/ }),

/***/ "./src/shared/components/FormErrorMessage/index.js":
/*!*********************************************************!*\
  !*** ./src/shared/components/FormErrorMessage/index.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _FormErrorMessage__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./FormErrorMessage */ "./src/shared/components/FormErrorMessage/FormErrorMessage.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _FormErrorMessage__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Header/MainHeader/MainHeader.js":
/*!***************************************************************!*\
  !*** ./src/shared/components/Header/MainHeader/MainHeader.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Badge */ "@material-ui/core/Badge");
/* harmony import */ var _material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/useMediaQuery */ "@material-ui/core/useMediaQuery");
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var shared_components_LogoHeading__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! shared/components/LogoHeading */ "./src/shared/components/LogoHeading/index.js");
/* harmony import */ var _shared_components_Header_MobileMenu__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ~/shared/components/Header/MobileMenu */ "./src/shared/components/Header/MobileMenu/index.js");
/* harmony import */ var _shared_constants_routesConstants__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ~/shared/constants/routesConstants */ "./src/shared/constants/routesConstants.js");
/* harmony import */ var _MainHeaderStyles__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./MainHeaderStyles */ "./src/shared/components/Header/MainHeader/MainHeaderStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Header\\MainHeader\\MainHeader.js";













/**
 * Name: MainHeader
 * Desc: Render MainHeader
 * @param  {bool}  isLoggedIn
 */

const MainHeader = ({
  isLoggedIn,
  userName,
  headerSubtitle,
  showBackBtn,
  mobileTitle,
  title,
  labelName,
  showMobileMenu
}) => {
  const {
    0: menuType,
    1: setMenuType
  } = Object(react__WEBPACK_IMPORTED_MODULE_8__["useState"])(false);

  const showMenuBar = () => {
    setMenuType(true);
  };

  const classes = Object(_MainHeaderStyles__WEBPACK_IMPORTED_MODULE_13__["default"])();
  const breakPoint = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_3___default()('(min-width:1152px)');
  const color = isLoggedIn ? 'common.white' : 'primary.light';
  const buttonColor = isLoggedIn ? 'secondary' : 'primary';
  const buttonTitle = isLoggedIn ? 'Help Center' : 'Log In';
  const linkNameArray = [{
    linkName: 'Programs'
  }, {
    linkName: 'Help Center'
  }, {
    linkName: 'Get Started'
  }];

  const continueToLogin = () => {
    const {
      USER_LOGIN
    } = _shared_constants_routesConstants__WEBPACK_IMPORTED_MODULE_12__["ROUTES"];
    next_router__WEBPACK_IMPORTED_MODULE_6___default.a.push(USER_LOGIN.ROUTE);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    padding: 3,
    bgcolor: "common.white",
    boxShadow: 2,
    className: clsx__WEBPACK_IMPORTED_MODULE_4___default()(isLoggedIn && classes.mainHeaderWrapper),
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      className: showBackBtn || showMobileMenu ? classes.displayNoneXs : '',
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          alignItems: "center",
          mr: breakPoint ? 2 : 0,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            display: "none",
            className: classes.logoImage,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_5___default.a, {
              src: "/logo.svg",
              width: 66,
              height: 63
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 29
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 25
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            display: breakPoint ? 'none' : 'flex',
            children: !showBackBtn ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
              className: classes.menuButton,
              onClick: showMenuBar,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["Menu"], {
                strokeWidth: "2",
                color: "Indigo",
                size: 30
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 76,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 75,
              columnNumber: 33
            }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
              className: classes.menuButton,
              onClick: showMenuBar,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["Menu"], {
                strokeWidth: "2",
                color: "Indigo",
                size: 24
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 79,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 25
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 21
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(shared_components_LogoHeading__WEBPACK_IMPORTED_MODULE_10__["default"], {
          title: title,
          labelName: labelName,
          isLoggedIn: isLoggedIn,
          breakPoint: breakPoint
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 85,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 68,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        pl: breakPoint ? 3 : 0,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "none",
          alignItems: "center",
          mr: isLoggedIn ? 5 : 9.5,
          className: classes.linkWrapper,
          children: linkNameArray.map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            mr: index !== linkNameArray.length - 1 && 8,
            flexWrap: "wrap",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "h6.fontSize",
                fontFamily: "fontFamily.medium",
                color: color,
                className: classes.linkName,
                children: item.linkName
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 104,
                columnNumber: 37
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 103,
              columnNumber: 33
            }, undefined)
          }, item.linkName, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 29
          }, undefined))
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 93,
          columnNumber: 21
        }, undefined), !isLoggedIn || breakPoint ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          onClick: () => continueToLogin(),
          size: breakPoint ? 'large' : 'small',
          color: buttonColor,
          variant: "contained",
          children: buttonTitle
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 117,
          columnNumber: 25
        }, undefined) : null, isLoggedIn ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          ml: 3,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core_Badge__WEBPACK_IMPORTED_MODULE_2___default.a, {
            badgeContent: 4,
            color: "error",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["Bell"], {
              strokeWidth: "3",
              color: "white",
              size: 26,
              fill: "white"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 128,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 127,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 126,
          columnNumber: 25
        }, undefined) : null]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 92,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 13
    }, undefined), userName && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      flexDirection: "column",
      textAlign: "center",
      pt: breakPoint ? 5 : 1,
      pb: breakPoint ? 5 : 10,
      color: "common.white",
      className: showBackBtn ? classes.displayNoneXs : '',
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        fontWeight: "700",
        fontSize: breakPoint ? 'h1.fontSize' : 'h3.fontSize',
        fontFamily: "fontFamily.bold",
        pb: 2,
        children: userName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 143,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        fontSize: breakPoint ? 'h5.fontSize' : 'h6.fontSize',
        lineHeight: breakPoint ? '35px' : '26px',
        color: "common.white",
        maxWidth: "560px",
        margin: "0 auto",
        children: headerSubtitle
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 150,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 135,
      columnNumber: 17
    }, undefined), (showBackBtn || showMobileMenu) && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      alignItems: "center",
      className: showBackBtn || showMobileMenu ? classes.displayBlockXs : '',
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
        className: classes.menuButton,
        onClick: showMenuBar,
        children: showBackBtn ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["ChevronLeft"], {
          strokeWidth: "2",
          color: "Indigo",
          size: 24
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 168,
          columnNumber: 29
        }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_9__["Menu"], {
          strokeWidth: "2",
          color: "Indigo",
          size: 24
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 170,
          columnNumber: 29
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 166,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        fontSize: "h4.fontSize",
        fontFamily: "fontFamily.extraBold",
        color: color,
        overflow: "hidden",
        whiteSpace: "nowrap",
        maxWidth: "350px",
        textOverflow: "ellipsis",
        paddingLeft: 2.4,
        className: classes.title,
        children: mobileTitle
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 173,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 162,
      columnNumber: 17
    }, undefined), menuType && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_Header_MobileMenu__WEBPACK_IMPORTED_MODULE_11__["default"], {
      beforeLogin: false,
      setMenuType: setMenuType
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 187,
      columnNumber: 26
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 58,
    columnNumber: 9
  }, undefined);
};

MainHeader.defaultProps = {
  showBackBtn: false,
  mobileTitle: ' ',
  title: 'AppName',
  labelName: 'EL PASO'
};
MainHeader.propTypes = {
  isLoggedIn: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool,
  userName: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  headerSubtitle: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  showBackBtn: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool,
  mobileTitle: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  title: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  labelName: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.string,
  showMobileMenu: prop_types__WEBPACK_IMPORTED_MODULE_7___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (MainHeader);

/***/ }),

/***/ "./src/shared/components/Header/MainHeader/MainHeaderStyles.js":
/*!*********************************************************************!*\
  !*** ./src/shared/components/Header/MainHeader/MainHeaderStyles.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  mainHeaderWrapper: {
    backgroundImage: 'url(/headerBg.svg)',
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'center',
    backgroundSize: 'cover',
    borderBottomLeftRadius: theme.spacing(2.63),
    borderBottomRightRadius: theme.spacing(2.63)
  },
  logoImage: {
    [theme.breakpoints.up('lg')]: {
      display: 'block'
    }
  },
  linkWrapper: {
    [theme.breakpoints.up('lg')]: {
      display: 'flex'
    }
  },
  menuButton: {
    backgroundColor: theme.common.white,
    '&:hover': {
      backgroundColor: theme.common.white
    }
  },
  linkName: {
    '&:hover': {
      color: theme.palette.success.light
    }
  },
  labelName: {
    [theme.breakpoints.up('lg')]: {
      display: 'block'
    }
  },
  title: {
    [theme.breakpoints.up('lg')]: {
      fontSize: theme.typography.h2.fontSize
    }
  },
  displayBlockXs: {
    [theme.breakpoints.up('lg')]: {
      display: 'none'
    },
    display: 'flex'
  },
  displayNoneXs: {
    [theme.breakpoints.down('md')]: {
      display: 'none'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Header/MainHeader/index.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/Header/MainHeader/index.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _MainHeader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MainHeader */ "./src/shared/components/Header/MainHeader/MainHeader.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _MainHeader__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Header/MobileMenu/MobileMenu.js":
/*!***************************************************************!*\
  !*** ./src/shared/components/Header/MobileMenu/MobileMenu.js ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./MobileMenuConstant */ "./src/shared/components/Header/MobileMenu/MobileMenuConstant.js");
/* harmony import */ var _MobileMenuStyles__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./MobileMenuStyles */ "./src/shared/components/Header/MobileMenu/MobileMenuStyles.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Header\\MobileMenu\\MobileMenu.js";








/**
 * Name: MobileMenu
 * Desc: Render MobileMenu
 */

const MobileMenu = ({
  beforeLogin,
  setMenuType
}) => {
  const {
    0: openMobileMenu,
    1: setOpenMobileMenu
  } = Object(react__WEBPACK_IMPORTED_MODULE_5__["useState"])(true);
  const classes = Object(_MobileMenuStyles__WEBPACK_IMPORTED_MODULE_8__["default"])();
  const links = beforeLogin ? _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__["beforeLoginLinkArray"] : _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__["linkArray"];
  const actionLinks = beforeLogin ? _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__["beforeLoginPagesLinkArray"] : _MobileMenuConstant__WEBPACK_IMPORTED_MODULE_7__["afterLoginPagesLinkArray"];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: openMobileMenu && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      className: clsx__WEBPACK_IMPORTED_MODULE_2___default()(classes.loginWrapper, beforeLogin && classes.beforeLoginWrapper),
      p: 3,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        mb: 11,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
          className: classes.menuButton,
          onClick: () => {
            setOpenMobileMenu(false);
            setMenuType(false);
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["X"], {
            strokeWidth: "3",
            color: "Indigo",
            size: 24
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 37,
          columnNumber: 25
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 36,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        children: actionLinks.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mb: 3.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
            href: "#",
            underline: "none",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(item.icon, {
                strokeWidth: "2",
                color: "Indigo",
                size: 24
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 51,
                columnNumber: 41
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "h3.fontSize",
                color: "primary.main",
                fontFamily: "fontFamily.bold",
                ml: 1.5,
                children: item.text
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 52,
                columnNumber: 41
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 50,
              columnNumber: 37
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 33
          }, undefined)
        }, item.text, false, {
          fileName: _jsxFileName,
          lineNumber: 48,
          columnNumber: 29
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 21
      }, undefined), beforeLogin && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        mt: 1.5,
        mb: 6,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          size: "large",
          color: "primary",
          variant: "contained",
          children: "Log In"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 29
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 25
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        children: links.map((item, index) => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          display: "flex",
          mb: 0.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
            className: clsx__WEBPACK_IMPORTED_MODULE_2___default()('linkBtn', classes.customButton),
            size: "medium",
            endIcon: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_6__["ChevronRight"], {
              color: "Indigo",
              size: 17
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 77,
              columnNumber: 46
            }, undefined),
            children: item.linkName
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 74,
            columnNumber: 33
          }, undefined)
        }, index, false, {
          fileName: _jsxFileName,
          lineNumber: 73,
          columnNumber: 29
        }, undefined))
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 71,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        position: "fixed",
        right: "-10px",
        zIndex: "-1",
        className: beforeLogin ? classes.topImagePosition : classes.bottomImagePosition,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_3___default.a, {
          src: "/clientLogo.svg",
          width: 160,
          height: 160,
          className: classes.image
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 90,
          columnNumber: 25
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 83,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 17
    }, undefined)
  }, void 0, false);
};

MobileMenu.propTypes = {
  beforeLogin: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.bool,
  setMenuType: prop_types__WEBPACK_IMPORTED_MODULE_4___default.a.func
};
/* harmony default export */ __webpack_exports__["default"] = (MobileMenu);

/***/ }),

/***/ "./src/shared/components/Header/MobileMenu/MobileMenuConstant.js":
/*!***********************************************************************!*\
  !*** ./src/shared/components/Header/MobileMenu/MobileMenuConstant.js ***!
  \***********************************************************************/
/*! exports provided: beforeLoginLinkArray, linkArray, afterLoginPagesLinkArray, beforeLoginPagesLinkArray */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "beforeLoginLinkArray", function() { return beforeLoginLinkArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "linkArray", function() { return linkArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "afterLoginPagesLinkArray", function() { return afterLoginPagesLinkArray; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "beforeLoginPagesLinkArray", function() { return beforeLoginPagesLinkArray; });
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_0__);

const beforeLoginLinkArray = [{
  linkName: 'About HACEP'
}, {
  linkName: 'Landlord Portal'
}, {
  linkName: 'Log Out'
}];
const linkArray = [{
  linkName: 'Español'
}, {
  linkName: 'Log Out'
}];
const afterLoginPagesLinkArray = [{
  text: 'Your Dashboard',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["Home"]
}, {
  text: 'Your Applications',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["FileText"]
}, {
  text: 'Your Account',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["User"]
}, {
  text: 'Help Center',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["HelpCircle"]
}];
const beforeLoginPagesLinkArray = [{
  text: 'Home',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["Home"]
}, {
  text: 'Get Started',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["Send"]
}, {
  text: 'Our Programs',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["FileText"]
}, {
  text: 'Help Center',
  icon: react_feather__WEBPACK_IMPORTED_MODULE_0__["HelpCircle"]
}];

/***/ }),

/***/ "./src/shared/components/Header/MobileMenu/MobileMenuStyles.js":
/*!*********************************************************************!*\
  !*** ./src/shared/components/Header/MobileMenu/MobileMenuStyles.js ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  loginWrapper: {
    position: 'fixed',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    width: '100%',
    height: '100vh',
    zIndex: '99999',
    backgroundColor: theme.palette.menus.menuBackground
  },
  beforeLoginWrapper: {
    backgroundColor: theme.palette.common.white
  },
  menuButton: {
    backgroundColor: theme.common.white
  },
  topImagePosition: {
    top: '40px'
  },
  bottomImagePosition: {
    bottom: '30px'
  },
  customButton: {
    fontSize: theme.typography.h6.fontSize,
    color: theme.palette.primary.main
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Header/MobileMenu/index.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/Header/MobileMenu/index.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _MobileMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./MobileMenu */ "./src/shared/components/Header/MobileMenu/MobileMenu.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _MobileMenu__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Header/TopHeader/TopHeader.js":
/*!*************************************************************!*\
  !*** ./src/shared/components/Header/TopHeader/TopHeader.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/useMediaQuery */ "@material-ui/core/useMediaQuery");
/* harmony import */ var _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _TopHeaderStyles__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./TopHeaderStyles */ "./src/shared/components/Header/TopHeader/TopHeaderStyles.js");
/* harmony import */ var _shared_components_ExitDialogBox__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ~/shared/components/ExitDialogBox */ "./src/shared/components/ExitDialogBox/index.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Header\\TopHeader\\TopHeader.js";







/**
 * Name: TopHeader
 * Desc: Render TopHeader
 * @param  {bool}  isWizard
 */

const TopHeader = ({
  isWizard,
  onClickBack,
  onExitClick,
  title = ''
}) => {
  const classes = Object(_TopHeaderStyles__WEBPACK_IMPORTED_MODULE_6__["default"])();
  const breakPoint = _material_ui_core_useMediaQuery__WEBPACK_IMPORTED_MODULE_2___default()('(min-width:1152px)');
  const linkNameArray = [{
    linkName: 'Español'
  }, {
    linkName: 'About'
  }, {
    linkName: 'Landlord Portal'
  }];
  const {
    0: openDialog,
    1: setOpenDialog
  } = Object(react__WEBPACK_IMPORTED_MODULE_4__["useState"])(false);

  const handleClose = () => {
    setOpenDialog(false);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    pt: 1,
    pr: breakPoint ? 6 : 1,
    pb: 1,
    pl: breakPoint ? 6 : 3,
    bgcolor: "menus.menuBackground",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        maxWidth: 750,
        children: [isWizard && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          mr: 0.5,
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
            onClick: onClickBack,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["ChevronLeft"], {
              strokeWidth: "2",
              color: "Indigo",
              size: 22
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 48,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 25
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          color: "primary.light",
          fontSize: 15,
          lineHeight: "21px",
          children: title ? title : 'Housing Assistance Eligiblity and PreApplication'
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 21
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        color: "primary.light",
        fontSize: "lg.fontSize",
        position: "relative",
        top: "-10px",
        display: !breakPoint ? 'flex' : 'none',
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_5__["X"], {
            strokeWidth: "3",
            color: "Black",
            size: 15
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 66,
            columnNumber: 25
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 21
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 59,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        alignItems: "center",
        display: breakPoint ? 'flex' : 'none',
        children: isWizard ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            className: classes.link,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "/",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "body5.fontSize",
                color: "button.secondaryColor",
                children: "CANCEL APPLICATION"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 75,
                columnNumber: 41
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 37
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 73,
            columnNumber: 33
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            className: classes.link,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              onClick: () => {
                setOpenDialog(true);
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "body5.fontSize",
                color: "button.secondaryColor",
                children: "SAVE AND EXIT"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 84,
                columnNumber: 41
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 81,
              columnNumber: 37
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 33
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Dialog"], {
            onClose: handleClose,
            "aria-labelledby": "simple-dialog-title",
            open: openDialog,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_shared_components_ExitDialogBox__WEBPACK_IMPORTED_MODULE_7__["default"], {
              onClose: handleClose,
              onConfirm: onExitClick
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 93,
              columnNumber: 37
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 33
          }, undefined)]
        }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
          children: linkNameArray.map(item => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Link"], {
              href: "#",
              underline: "none",
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                fontSize: "body5.fontSize",
                color: "button.secondaryColor",
                children: item.linkName
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 101,
                columnNumber: 45
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 100,
              columnNumber: 41
            }, undefined)
          }, item.linkName, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 37
          }, undefined))
        }, void 0, false)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 69,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 37,
    columnNumber: 9
  }, undefined);
};

TopHeader.defaultProps = {
  isWizard: false,
  title: null,
  onClickBack: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func
};
TopHeader.propTypes = {
  isWizard: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  onClickBack: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  onExitClick: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  title: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (TopHeader);

/***/ }),

/***/ "./src/shared/components/Header/TopHeader/TopHeaderStyles.js":
/*!*******************************************************************!*\
  !*** ./src/shared/components/Header/TopHeader/TopHeaderStyles.js ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  link: {
    '&:not(:last-child)': {
      marginRight: theme.spacing(6),
      position: 'relative',
      '&::after': {
        content: "'|'",
        position: 'absolute',
        right: '-26px',
        top: 0,
        bottom: 0,
        color: 'inherit'
      }
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Header/TopHeader/index.js":
/*!*********************************************************!*\
  !*** ./src/shared/components/Header/TopHeader/index.js ***!
  \*********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TopHeader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TopHeader */ "./src/shared/components/Header/TopHeader/TopHeader.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _TopHeader__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Indicators/Indicators.js":
/*!********************************************************!*\
  !*** ./src/shared/components/Indicators/Indicators.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! feather-icons-react */ "feather-icons-react");
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _IndicatorsStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./IndicatorsStyles */ "./src/shared/components/Indicators/IndicatorsStyles.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Indicators\\Indicators.js";





/**
 * Name: Indicators
 * Desc: Render Indicators
 * @param { string } classNames
 */

const Indicators = ({
  status,
  size,
  iconName,
  iconSize,
  borderWidth,
  iconColor
}) => {
  const classes = Object(_IndicatorsStyles__WEBPACK_IMPORTED_MODULE_5__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    width: size,
    height: size,
    borderRadius: "50%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    margin: "0 auto",
    border: borderWidth,
    className: classes[status],
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default.a, {
      icon: iconName,
      size: iconSize,
      color: iconColor
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 9
  }, undefined);
};

Indicators.defaultProps = {
  size: 80,
  status: 'default',
  iconName: 'thumbs-up',
  iconSize: 36,
  borderWidth: 8
};
Indicators.propTypes = {
  status: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['success', 'failed', 'pending', 'default', 'complete']),
  size: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number,
  iconSize: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number,
  borderWidth: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.number,
  iconName: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string,
  iconColor: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (Indicators);

/***/ }),

/***/ "./src/shared/components/Indicators/IndicatorsStyles.js":
/*!**************************************************************!*\
  !*** ./src/shared/components/Indicators/IndicatorsStyles.js ***!
  \**************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  failed: {
    backgroundColor: theme.palette.error.light,
    borderColor: `${theme.palette.error.main} !important`
  },
  pending: {
    backgroundColor: theme.palette.pending.light,
    borderColor: `${theme.palette.pending.main} !important`
  },
  success: {
    backgroundColor: theme.palette.success.light,
    borderColor: `${theme.palette.success.main} !important`
  },
  default: {
    backgroundColor: 'transparent',
    borderColor: `${theme.palette.default.main} !important`
  },
  complete: {
    backgroundColor: theme.common.white,
    border: '8px solid rgba(255, 255, 255, .5)',
    '-webkit-background-clip': 'padding-box',
    backgroundClip: 'padding-box'
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/Indicators/index.js":
/*!***************************************************!*\
  !*** ./src/shared/components/Indicators/index.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Indicators__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Indicators */ "./src/shared/components/Indicators/Indicators.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Indicators__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/LogoHeading/LogoHeading.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/LogoHeading/LogoHeading.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _LogoHeadingStyles__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./LogoHeadingStyles */ "./src/shared/components/LogoHeading/LogoHeadingStyles.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\LogoHeading\\LogoHeading.js";




/**
 * Name : LogoHeading
 * Desc : Render LogoHeading
 * @param  {string}  labelName
 * @param  {string}  title
 * @param  {boolean}  isLoggedIn
 * @param  {string}  breakPoint
 */

const LogoHeading = ({
  title,
  labelName,
  isLoggedIn,
  breakPoint
}) => {
  const classes = Object(_LogoHeadingStyles__WEBPACK_IMPORTED_MODULE_4__["default"])();
  const color = isLoggedIn ? 'common.white' : 'primary.light';
  const subTextColor = isLoggedIn ? 'common.white' : 'primary.light';
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    display: "flex",
    flexDirection: "column",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        fontSize: "h4.fontSize",
        fontFamily: "fontFamily.extraBold",
        color: color,
        overflow: "hidden",
        whiteSpace: "nowrap",
        maxWidth: "350px",
        textOverflow: "ellipsis",
        className: classes.title,
        children: !isLoggedIn || breakPoint ? title : ''
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "none",
        fontSize: "body5.fontSize",
        letterSpacing: "4px",
        color: subTextColor,
        className: classes.labelName,
        children: labelName
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 33,
        columnNumber: 17
      }, undefined)]
    }, void 0, true)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 20,
    columnNumber: 9
  }, undefined);
};

LogoHeading.defaultProps = {};
LogoHeading.propTypes = {
  title: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  labelName: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.string,
  isLoggedIn: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool,
  breakPoint: prop_types__WEBPACK_IMPORTED_MODULE_2___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (LogoHeading);

/***/ }),

/***/ "./src/shared/components/LogoHeading/LogoHeadingStyles.js":
/*!****************************************************************!*\
  !*** ./src/shared/components/LogoHeading/LogoHeadingStyles.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  labelName: {
    [theme.breakpoints.up('lg')]: {
      display: 'block'
    }
  },
  title: {
    [theme.breakpoints.up('lg')]: {
      fontSize: theme.typography.h2.fontSize
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/LogoHeading/index.js":
/*!****************************************************!*\
  !*** ./src/shared/components/LogoHeading/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _LogoHeading__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./LogoHeading */ "./src/shared/components/LogoHeading/LogoHeading.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _LogoHeading__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/ObjectCard/ObjectCard.js":
/*!********************************************************!*\
  !*** ./src/shared/components/ObjectCard/ObjectCard.js ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! feather-icons-react */ "feather-icons-react");
/* harmony import */ var feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(feather_icons_react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _shared_utils_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ~/shared/utils/utils */ "./src/shared/utils/utils.js");
/* harmony import */ var _Indicators__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../Indicators */ "./src/shared/components/Indicators/index.js");
/* harmony import */ var _ObjectCardStyle__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./ObjectCardStyle */ "./src/shared/components/ObjectCard/ObjectCardStyle.js");


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\ObjectCard\\ObjectCard.js";







/**
 * Name : ObjectCard
 * Desc : Render ObjectCard
 **/

const ObjectCard = props => {
  const {
    children,
    variant,
    iconName,
    cardType,
    onClick,
    onDelete,
    isMember,
    onEditClick,
    showOptionMenu
  } = props;
  const classes = Object(_ObjectCardStyle__WEBPACK_IMPORTED_MODULE_7__["default"])();
  const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_4___default.a.useState(null);
  const open = Boolean(anchorEl);

  const handleClick = event => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  const handleEdit = () => {
    onEditClick();
    handleClose();
  };

  const handleDelete = () => {
    onDelete();
    handleClose();
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: cardType === 'objectCard' ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
      onClick: onClick,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        alignItems: "center",
        px: 2,
        py: 2.5,
        minHeight: 96,
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Indicators__WEBPACK_IMPORTED_MODULE_6__["default"], {
            size: 37,
            status: variant,
            iconName: iconName,
            borderWidth: 3.7,
            iconSize: 18
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 25
        }, undefined), children && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          flexGrow: 2,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          pl: 1.5,
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 29
        }, undefined), showOptionMenu && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          p: 0.25,
          mr: -1.5,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          children: isMember ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
              color: "primary",
              onClick: handleClick,
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default.a, {
                icon: "more-vertical",
                size: "24"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 72,
                columnNumber: 45
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 71,
              columnNumber: 41
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Menu"], {
              id: "long-menu",
              anchorEl: anchorEl,
              keepMounted: true,
              open: open,
              onClose: handleClose,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                onClick: handleEdit,
                children: "Edit"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 80,
                columnNumber: 45
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["MenuItem"], {
                onClick: handleDelete,
                children: "Delete"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 81,
                columnNumber: 45
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 41
            }, undefined)]
          }, void 0, true) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
            color: "primary",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(feather_icons_react__WEBPACK_IMPORTED_MODULE_2___default.a, {
              icon: "more-vertical",
              size: "24"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 86,
              columnNumber: 41
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 85,
            columnNumber: 37
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 63,
          columnNumber: 29
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 21
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 41,
      columnNumber: 17
    }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
      className: classes.rootUpload,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
        accept: "image/*",
        className: classes.input,
        id: "contained-button-file",
        multiple: true,
        type: "file"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 96,
        columnNumber: 21
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
        htmlFor: "contained-button-file",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Button"], {
          variant: "contained",
          component: "span",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
              display: "flex",
              alignItems: "center",
              px: 2,
              py: 1.5,
              minHeight: 96,
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_Indicators__WEBPACK_IMPORTED_MODULE_6__["default"], {
                  size: 37,
                  status: variant,
                  iconName: iconName,
                  borderWidth: 3.7,
                  iconSize: 18
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 113,
                  columnNumber: 41
                }, undefined)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 112,
                columnNumber: 37
              }, undefined), children && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
                flexGrow: 2,
                display: "flex",
                flexDirection: "column",
                justifyContent: "center",
                pl: 2,
                children: children
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 122,
                columnNumber: 41
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 106,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 105,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 104,
          columnNumber: 25
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 103,
        columnNumber: 21
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 95,
      columnNumber: 17
    }, undefined)
  }, void 0, false);
};

ObjectCard.defaultProps = {
  variant: 'success',
  children: '',
  iconName: 'user',
  cardType: 'objectCard',
  onClick: _shared_utils_utils__WEBPACK_IMPORTED_MODULE_5__["noop"],
  isMember: false,
  onEditClick: _shared_utils_utils__WEBPACK_IMPORTED_MODULE_5__["noop"],
  onDelete: _shared_utils_utils__WEBPACK_IMPORTED_MODULE_5__["noop"],
  showOptionMenu: true
};
ObjectCard.propTypes = {
  variant: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['success', 'failed', 'pending']),
  cardType: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.oneOf(['objectCard', 'actionCard']),
  children: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.node,
  iconName: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string,
  onClick: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  isMember: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool,
  onEditClick: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  onDelete: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.func,
  showOptionMenu: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.bool
};
/* harmony default export */ __webpack_exports__["default"] = (ObjectCard);

/***/ }),

/***/ "./src/shared/components/ObjectCard/ObjectCardStyle.js":
/*!*************************************************************!*\
  !*** ./src/shared/components/ObjectCard/ObjectCardStyle.js ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(() => ({
  rootUpload: {
    '& > *': {
      margin: 0
    },
    '& .MuiButton-root': {
      width: '100%',
      padding: '0'
    },
    '& .MuiCard-root': {
      width: '100%'
    }
  },
  input: {
    display: 'none'
  },
  '.MuiButtonBase-root': {
    padding: 0
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/ObjectCard/index.js":
/*!***************************************************!*\
  !*** ./src/shared/components/ObjectCard/index.js ***!
  \***************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ObjectCard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ObjectCard */ "./src/shared/components/ObjectCard/ObjectCard.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _ObjectCard__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/PageHeading/PageHeading.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/PageHeading/PageHeading.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_3__);


var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\PageHeading\\PageHeading.js";



/** 
 * Name : PageHeading
 * Desc : Render PageHeading
 * @param {string} title 
 **/

const PageHeading = ({
  title
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      color: "primary.main",
      fontFamily: "fontFamily.bold",
      letterSpacing: 8,
      pb: 3,
      className: "textTransform",
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Typography"], {
        variant: "h2",
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 12
    }, undefined)
  }, void 0, false);
};

PageHeading.defaultProps = {};
PageHeading.propTypes = {
  title: prop_types__WEBPACK_IMPORTED_MODULE_3___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (PageHeading);

/***/ }),

/***/ "./src/shared/components/PageHeading/index.js":
/*!****************************************************!*\
  !*** ./src/shared/components/PageHeading/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _PageHeading__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./PageHeading */ "./src/shared/components/PageHeading/PageHeading.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _PageHeading__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/ProgramCard/ProgramCard.js":
/*!**********************************************************!*\
  !*** ./src/shared/components/ProgramCard/ProgramCard.js ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/withWidth */ "@material-ui/core/withWidth");
/* harmony import */ var _material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! clsx */ "clsx");
/* harmony import */ var clsx__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(clsx__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! prop-types */ "prop-types");
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react-feather */ "react-feather");
/* harmony import */ var react_feather__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_feather__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _ProgramCardsStyle__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./ProgramCardsStyle */ "./src/shared/components/ProgramCard/ProgramCardsStyle.js");

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\ProgramCard\\ProgramCard.js";








/**
 * Name : ProgramCard
 * Desc : Render ProgramCard
 **/

const ProgramCard = props => {
  const {
    children,
    showLeftArrow,
    variant,
    showDeleteBox,
    showImage,
    showLeftBorder,
    imgUrl,
    width
  } = props;
  const classes = Object(_ProgramCardsStyle__WEBPACK_IMPORTED_MODULE_8__["default"])();
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
    position: "relative",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Card"], {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
        display: "flex",
        children: [showLeftBorder && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          minWidth: 16,
          minHeight: 96,
          borderRadius: "50px 0 0 50px",
          position: width === 'xs' ? 'static' : 'absolute',
          left: "0",
          zIndex: 1,
          className: classes[variant]
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 32,
          columnNumber: 25
        }, undefined), showImage && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          className: clsx__WEBPACK_IMPORTED_MODULE_3___default()(classes.overlay, classes[variant]),
          mr: 2.5,
          display: width === 'xs' ? 'none' : 'inherit',
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_4___default.a, {
            src: imgUrl,
            width: 133,
            height: 96
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 44,
          columnNumber: 25
        }, undefined), children && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          flexGrow: 2,
          px: 1.5,
          py: 2,
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          children: children
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 53,
          columnNumber: 25
        }, undefined), showLeftArrow && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          p: 0.25,
          pr: 1.25,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["IconButton"], {
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_7__["ChevronRight"], {
              "stroke-width": "3",
              color: "Indigo",
              size: 24
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 72,
              columnNumber: 33
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 71,
            columnNumber: 29
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 25
        }, undefined), showDeleteBox && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
          component: "button",
          p: 1.5,
          bgcolor: "error.dark",
          color: "common.white",
          minHeight: 96,
          minWidth: 96,
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          flexDirection: "column",
          border: 0,
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_feather__WEBPACK_IMPORTED_MODULE_7__["Trash2"], {
            "stroke-width": "1.5",
            color: "white",
            size: 20
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 89,
            columnNumber: 29
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__["Box"], {
            component: "body1",
            fontSize: "lg.fontSize",
            fontFamily: "fontFamily.regular",
            pt: 0.75,
            children: "DELETE"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 90,
            columnNumber: 29
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 77,
          columnNumber: 25
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 17
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 28,
    columnNumber: 9
  }, undefined);
};

ProgramCard.defaultProps = {
  children: '',
  showLeftArrow: false,
  showDeleteBox: false,
  showImage: false,
  showLeftBorder: true,
  imgUrl: '/view.jpg'
};
ProgramCard.propTypes = {
  variant: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.oneOf(['success', 'failed', 'waiting']),
  children: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.node,
  showLeftArrow: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  showDeleteBox: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  showImage: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  showLeftBorder: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.bool,
  imgUrl: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string,
  width: prop_types__WEBPACK_IMPORTED_MODULE_5___default.a.string
};
/* harmony default export */ __webpack_exports__["default"] = (_material_ui_core_withWidth__WEBPACK_IMPORTED_MODULE_2___default()()(ProgramCard));

/***/ }),

/***/ "./src/shared/components/ProgramCard/ProgramCardsStyle.js":
/*!****************************************************************!*\
  !*** ./src/shared/components/ProgramCard/ProgramCardsStyle.js ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @material-ui/core/styles */ "@material-ui/core/styles");
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__);

const useStyles = Object(_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_0__["makeStyles"])(theme => ({
  failed: {
    backgroundColor: theme.palette.error.main,
    '&:before': {
      background: 'rgba(245, 66, 15, 0.5) !important'
    }
  },
  waiting: {
    backgroundColor: theme.palette.pending.main,
    '&:before': {
      background: 'rgba(249, 191, 2, 0.5) !important'
    }
  },
  // pending: {
  //     backgroundColor: theme.palette.pending.main
  // },
  success: {
    backgroundColor: theme.palette.success.light,
    '&:before': {
      background: 'rgba(79, 240, 188, 0.5) !important'
    }
  },
  info: {
    backgroundColor: theme.palette.info.main
  },
  overlay: {
    position: 'relative',
    '&:before': {
      content: '""',
      width: '100%',
      height: '100%',
      position: 'absolute',
      top: '0',
      bottom: '0',
      left: '0',
      right: '0',
      zIndex: '1'
    }
  }
}));
/* harmony default export */ __webpack_exports__["default"] = (useStyles);

/***/ }),

/***/ "./src/shared/components/ProgramCard/index.js":
/*!****************************************************!*\
  !*** ./src/shared/components/ProgramCard/index.js ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ProgramCard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ProgramCard */ "./src/shared/components/ProgramCard/ProgramCard.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _ProgramCard__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/components/Tooltip/Tooltip.js":
/*!**************************************************!*\
  !*** ./src/shared/components/Tooltip/Tooltip.js ***!
  \**************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core */ "@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_icons_HelpOutlineOutlined__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/icons/HelpOutlineOutlined */ "@material-ui/icons/HelpOutlineOutlined");
/* harmony import */ var _material_ui_icons_HelpOutlineOutlined__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_material_ui_icons_HelpOutlineOutlined__WEBPACK_IMPORTED_MODULE_3__);

var _jsxFileName = "D:\\hacep\\hacep\\frontend\\src\\shared\\components\\Tooltip\\Tooltip.js";




const Tooltips = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Tooltip"], {
    TransitionComponent: _material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Zoom"],
    title: "Add",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
      display: "flex",
      alignItems: "center",
      fontSize: "subtitle2.fontSize",
      fontFamily: "Poppins-Medium",
      color: "#2F0B7C",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_icons_HelpOutlineOutlined__WEBPACK_IMPORTED_MODULE_3___default.a, {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 18
      }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_material_ui_core__WEBPACK_IMPORTED_MODULE_2__["Box"], {
        pl: 1,
        children: " What is this ? "
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 45
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 13
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 9
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Tooltips);

/***/ }),

/***/ "./src/shared/components/Tooltip/index.js":
/*!************************************************!*\
  !*** ./src/shared/components/Tooltip/index.js ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Tooltip__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Tooltip */ "./src/shared/components/Tooltip/Tooltip.js");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "default", function() { return _Tooltip__WEBPACK_IMPORTED_MODULE_0__["default"]; });



/***/ }),

/***/ "./src/shared/constants/routesConstants.js":
/*!*************************************************!*\
  !*** ./src/shared/constants/routesConstants.js ***!
  \*************************************************/
/*! exports provided: ROUTES */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ROUTES", function() { return ROUTES; });
const ROUTES = {
  HOME: {
    ROUTE: '/',
    //Should be unique
    TITLE: 'Home',
    NAME: 'Home',
    PARENT_ROUTE: ''
  },
  EXAMPLES: {
    ROUTE: '/examples',
    //For learning purpose
    TITLE: 'Examples',
    NAME: 'Examples',
    PARENT_ROUTE: ''
  },
  USER_LOGIN: {
    ROUTE: '/login',
    //Should be unique
    TITLE: 'Login',
    NAME: 'Login'
  },
  LOGIN: {
    ROUTE: '/admin',
    //Should be unique
    TITLE: 'Admin',
    NAME: 'Login',
    PARENT_ROUTE: ''
  },
  PROFILE: {
    //need to add query params
    ROUTE: '/profile',
    //Should be unique
    TITLE: 'Profile',
    NAME: 'Profile',
    PARENT_ROUTE: ''
  },
  VOUCHER: {
    //need to add query params
    ROUTE: '/voucher',
    //Should be unique
    TITLE: 'Voucher',
    NAME: 'Voucher',
    PARENT_ROUTE: ''
  },
  ACCOUNT: {
    //need to add query params
    ROUTE: '/account',
    //Should be unique
    TITLE: 'Account',
    NAME: 'Account',
    PARENT_ROUTE: ''
  },
  ACCOUNT_DETAIL: {
    //need to add query params
    ROUTE: '/accountdetail',
    //Should be unique
    TITLE: 'Account Detail',
    NAME: 'Account Detail',
    PARENT_ROUTE: ''
  },
  GET_STARTED: {
    //need to add query params
    ROUTE: '/getstarted',
    //Should be unique
    TITLE: 'Get Started',
    NAME: 'Get Started',
    PARENT_ROUTE: ''
  },
  HELP: {
    //need to add query params
    ROUTE: '/help',
    //Should be unique
    TITLE: 'Help',
    NAME: 'Help',
    PARENT_ROUTE: ''
  },
  HELP_TOPICS: {
    //need to add query params
    ROUTE: '/helptopics',
    //Should be unique
    TITLE: 'Help Topics',
    NAME: 'Help Topics',
    PARENT_ROUTE: ''
  },
  CHANGE_PASSWORD: {
    //need to add query params
    ROUTE: '/changepassword',
    //Should be unique
    TITLE: 'Change Password',
    NAME: 'Change Password',
    PARENT_ROUTE: ''
  },
  FORGOT_PASSWORD: {
    ROUTE: '/forgotpassword',
    //Should be unique
    TITLE: 'Forgot Password',
    NAME: 'Forgot Password',
    PARENT_ROUTE: ''
  },
  COMMON_COMPONENT_STYLE: {
    ROUTE: '/commoncomponentstyle',
    //Should be unique
    TITLE: 'Common Component Style',
    NAME: 'Common Component Style',
    PARENT_ROUTE: ''
  },
  COMMON_FULLFLOWPAGE_STYLE: {
    ROUTE: '/commonfullpageflowstyle',
    //Should be unique
    TITLE: 'Common fullpageflow Style',
    NAME: 'Common fullpageflow Style',
    PARENT_ROUTE: ''
  },
  VOUCHER_RECEIVED: {
    ROUTE: '/voucherreceivedfullpagestyle',
    //Should be unique
    TITLE: 'Voucher Received Style',
    NAME: 'Voucher Received Style',
    PARENT_ROUTE: ''
  },
  DASHBOARD_PAGE_STYLE: {
    ROUTE: '/dashboardpagestyle',
    //Should be unique
    TITLE: 'Dashboard Page Style',
    NAME: 'Dashboard Page Style',
    PARENT_ROUTE: ''
  },
  LANDLORD_PAGE_STYLE: {
    ROUTE: '/landlordpagestyle',
    //Should be unique
    TITLE: 'Landlord Page Style',
    NAME: 'Landlord Page Style',
    PARENT_ROUTE: ''
  },
  SUPERVISOR_LOGIN: {
    ROUTE: '/admin/login',
    //Should be unique
    TITLE: 'Admin LOGIN',
    NAME: 'Admin LOGIN'
  },
  CHECK_ELIGIBILITY: {
    ROUTE: '/check-your-eligibility',
    //Should be unique
    TITLE: 'Check Your Eligibility',
    NAME: 'Check Your Eligibility',
    PARENT_ROUTE: ''
  },
  SUPERVISOR_DASHBOARD: {
    ROUTE: '/admin/dashboard',
    //Should be unique
    TITLE: 'Admin Dashboard',
    NAME: 'Admin Dashboard',
    PARENT_ROUTE: ''
  },
  CREATE_PROFILE: {
    ROUTE: '/create-profile',
    //Should be unique
    TITLE: 'Profile',
    NAME: 'Profile',
    PARENT_ROUTE: ''
  },
  ELIGIBILITY_CALCULATOR: {
    ROUTE: '/admin/calculator',
    //Should be unique
    TITLE: 'Eligibility Calculator',
    NAME: 'Eligibility Calculator',
    PARENT_ROUTE: ''
  },
  MANAGE_PROGRAMS: {
    ROUTE: '/admin/manage-programs',
    //Should be unique
    TITLE: 'Manage Programs',
    NAME: 'Manage Programs',
    PARENT_ROUTE: ''
  },
  MANAGE_SMTP: {
    ROUTE: '/admin/manage-smtp',
    //Should be unique
    TITLE: 'Manage Smtp',
    NAME: 'Manage Smtp',
    PARENT_ROUTE: ''
  },
  MANAGE_PREAPPLICATION: {
    ROUTE: '/admin/manage-preapplications',
    //Should be unique
    TITLE: 'Manage Preapplication',
    NAME: 'Manage Preapplication',
    PARENT_ROUTE: ''
  },
  HOUSE_HOLD_DETAIL: {
    ROUTE: '/house-hold-detail',
    //Should be unique
    TITLE: 'House Hold Detail',
    NAME: 'House Hold Detail',
    PARENT_ROUTE: ''
  },
  REVIEW_APPLICATION: {
    ROUTE: '/review-application',
    //Should be unique
    TITLE: 'Review Application',
    NAME: 'Review Application',
    PARENT_ROUTE: ''
  },
  HOUSEHOLD_INCOME: {
    ROUTE: '/household-income',
    //Should be unique
    TITLE: 'Household Income',
    NAME: 'Household Income',
    PARENT_ROUTE: ''
  },
  HOUSEHOLD_ASSETS: {
    ROUTE: '/household-assets',
    //Should be unique
    TITLE: 'Household Assets',
    NAME: 'Household Assets',
    PARENT_ROUTE: ''
  },
  HOUSEHOLD_SPECIAL_EXPENSES: {
    ROUTE: '/household-special-expenses',
    //Should be unique
    TITLE: 'Household Special Expenses',
    NAME: 'Household Special Expenses',
    PARENT_ROUTE: ''
  },
  RENT_AFFORDABILITY: {
    ROUTE: '/rent-affordability',
    //Should be unique
    TITLE: 'Rent Affordability',
    NAME: 'Rent Affordability',
    PARENT_ROUTE: ''
  },
  YOUR_DOCUMENTS: {
    ROUTE: '/your-documents',
    //Should be unique
    TITLE: 'Rour Documents',
    NAME: 'Rour Documents',
    PARENT_ROUTE: ''
  },
  REVIEW_AND_SIGN: {
    ROUTE: '/review-and-sign',
    //Should be unique
    TITLE: 'Review And Sign',
    NAME: 'Review And Sign',
    PARENT_ROUTE: ''
  }
};

/***/ }),

/***/ "./src/shared/utils/storeManager.js":
/*!******************************************!*\
  !*** ./src/shared/utils/storeManager.js ***!
  \******************************************/
/*! exports provided: setLocalStorage, getLocalStorage, removeLocalStorage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setLocalStorage", function() { return setLocalStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLocalStorage", function() { return getLocalStorage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "removeLocalStorage", function() { return removeLocalStorage; });
/**
 * set LocalStorage for given key and value
 * @param {*} key
 * @param {*} value
 */
const setLocalStorage = (key, value) => {
  let storageValue = value;

  if (typeof value === 'object') {
    storageValue = JSON.stringify(value);
  }

  window.localStorage.setItem(key, storageValue);
};
/**
 * Return the LocalStorage for given key
 * @param {*} key
 */

const getLocalStorage = key => {
  const value = window.localStorage.getItem(key);
  return value && JSON.parse(value);
};
/**
 * Return removed item
 */

const removeLocalStorage = key => {
  const value = getLocalStorage(key);
  window.localStorage.removeItem(key);
  return value;
};

/***/ }),

/***/ "./src/shared/utils/utils.js":
/*!***********************************!*\
  !*** ./src/shared/utils/utils.js ***!
  \***********************************/
/*! exports provided: getBaseUrl, noop, getLocalizeKey, getUserId, getAccessToken */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getBaseUrl", function() { return getBaseUrl; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "noop", function() { return noop; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getLocalizeKey", function() { return getLocalizeKey; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getUserId", function() { return getUserId; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "getAccessToken", function() { return getAccessToken; });
/* harmony import */ var _storeManager__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./storeManager */ "./src/shared/utils/storeManager.js");
 //utility functions here

const getBaseUrl = () => {
  return "http://localhost:8000/";
}; // eslint-disable-next-line no-empty-function

const noop = () => {};
const getLocalizeKey = () => {
  return "6744e827e2252";
};
const getUserId = () => {
  const userDetail = Object(_storeManager__WEBPACK_IMPORTED_MODULE_0__["getLocalStorage"])('user_details') || {};
  return userDetail === null || userDetail === void 0 ? void 0 : userDetail.user_id;
};
const getAccessToken = () => {
  const userDetail = Object(_storeManager__WEBPACK_IMPORTED_MODULE_0__["getLocalStorage"])('user_details') || {};
  return userDetail === null || userDetail === void 0 ? void 0 : userDetail.access_token;
};

/***/ }),

/***/ "@material-ui/core":
/*!************************************!*\
  !*** external "@material-ui/core" ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core");

/***/ }),

/***/ "@material-ui/core/Badge":
/*!******************************************!*\
  !*** external "@material-ui/core/Badge" ***!
  \******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/Badge");

/***/ }),

/***/ "@material-ui/core/styles":
/*!*******************************************!*\
  !*** external "@material-ui/core/styles" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/styles");

/***/ }),

/***/ "@material-ui/core/useMediaQuery":
/*!**************************************************!*\
  !*** external "@material-ui/core/useMediaQuery" ***!
  \**************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/useMediaQuery");

/***/ }),

/***/ "@material-ui/core/withWidth":
/*!**********************************************!*\
  !*** external "@material-ui/core/withWidth" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/core/withWidth");

/***/ }),

/***/ "@material-ui/icons/Close":
/*!*******************************************!*\
  !*** external "@material-ui/icons/Close" ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/Close");

/***/ }),

/***/ "@material-ui/icons/CloseOutlined":
/*!***************************************************!*\
  !*** external "@material-ui/icons/CloseOutlined" ***!
  \***************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/CloseOutlined");

/***/ }),

/***/ "@material-ui/icons/ExpandMoreOutlined":
/*!********************************************************!*\
  !*** external "@material-ui/icons/ExpandMoreOutlined" ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/ExpandMoreOutlined");

/***/ }),

/***/ "@material-ui/icons/HelpOutlineOutlined":
/*!*********************************************************!*\
  !*** external "@material-ui/icons/HelpOutlineOutlined" ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/icons/HelpOutlineOutlined");

/***/ }),

/***/ "@material-ui/lab":
/*!***********************************!*\
  !*** external "@material-ui/lab" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@material-ui/lab");

/***/ }),

/***/ "clsx":
/*!***********************!*\
  !*** external "clsx" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("clsx");

/***/ }),

/***/ "feather-icons-react":
/*!**************************************!*\
  !*** external "feather-icons-react" ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("feather-icons-react");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "prop-types":
/*!*****************************!*\
  !*** external "prop-types" ***!
  \*****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("prop-types");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-feather":
/*!********************************!*\
  !*** external "react-feather" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-feather");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0LmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9pbWFnZS1jb25maWcuanNcIiIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L2ltYWdlLnRzeCIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3JlcXVlc3QtaWRsZS1jYWxsYmFjay50cyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3VzZS1pbnRlcnNlY3Rpb24udHN4Iiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L2ltYWdlLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2V4dGVuZHMuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL25leHQvbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvU3R5bGVkQ29tcG9uZW50TW9kdWxlL1N0eWxlZENvbXBvbmVudE1vZHVsZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvbW9kdWxlcy9TdHlsZWRDb21wb25lbnRNb2R1bGUvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3BhZ2VzL2NvbW1vbmNvbXBvbmVudHN0eWxlL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9BbGVydC9BbGVydHMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0FsZXJ0L0FsZXJ0c1N0eWxlcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvQW5ub3RhdGlvbnMvQW5ub3RhdGlvbnMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0Fubm90YXRpb25zL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9DaGlwcy9DaGlwcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvQ2hpcHMvQ2hpcHNTdHlsZXMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0NoaXBzL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9FeGl0RGlhbG9nQm94L0V4aXREaWFsb2dCb3guanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvQ2hlY2tZb3VyRWxpZ2liaWxpdHkvRXhpdERpYWxvZ0JveC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvRm9ybUVycm9yTWVzc2FnZS9Gb3JtRXJyb3JNZXNzYWdlLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Gb3JtRXJyb3JNZXNzYWdlL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9IZWFkZXIvTWFpbkhlYWRlci9NYWluSGVhZGVyLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9IZWFkZXIvTWFpbkhlYWRlci9NYWluSGVhZGVyU3R5bGVzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9IZWFkZXIvTWFpbkhlYWRlci9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL01vYmlsZU1lbnUvTW9iaWxlTWVudS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL01vYmlsZU1lbnUvTW9iaWxlTWVudUNvbnN0YW50LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9IZWFkZXIvTW9iaWxlTWVudS9Nb2JpbGVNZW51U3R5bGVzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9IZWFkZXIvTW9iaWxlTWVudS9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL1RvcEhlYWRlci9Ub3BIZWFkZXIuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0hlYWRlci9Ub3BIZWFkZXIvVG9wSGVhZGVyU3R5bGVzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9IZWFkZXIvVG9wSGVhZGVyL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9JbmRpY2F0b3JzL0luZGljYXRvcnMuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0luZGljYXRvcnMvSW5kaWNhdG9yc1N0eWxlcy5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvSW5kaWNhdG9ycy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvTG9nb0hlYWRpbmcvTG9nb0hlYWRpbmcuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL0xvZ29IZWFkaW5nL0xvZ29IZWFkaW5nU3R5bGVzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Mb2dvSGVhZGluZy9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvT2JqZWN0Q2FyZC9PYmplY3RDYXJkLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9PYmplY3RDYXJkL09iamVjdENhcmRTdHlsZS5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvT2JqZWN0Q2FyZC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvUGFnZUhlYWRpbmcvUGFnZUhlYWRpbmcuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL1BhZ2VIZWFkaW5nL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Qcm9ncmFtQ2FyZC9Qcm9ncmFtQ2FyZC5qcyIsIndlYnBhY2s6Ly8vLi9zcmMvc2hhcmVkL2NvbXBvbmVudHMvUHJvZ3JhbUNhcmQvUHJvZ3JhbUNhcmRzU3R5bGUuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL1Byb2dyYW1DYXJkL2luZGV4LmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvY29tcG9uZW50cy9Ub29sdGlwL1Rvb2x0aXAuanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb21wb25lbnRzL1Rvb2x0aXAvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vc3JjL3NoYXJlZC9jb25zdGFudHMvcm91dGVzQ29uc3RhbnRzLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvdXRpbHMvc3RvcmVNYW5hZ2VyLmpzIiwid2VicGFjazovLy8uL3NyYy9zaGFyZWQvdXRpbHMvdXRpbHMuanMiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQG1hdGVyaWFsLXVpL2NvcmVcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS9CYWRnZVwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL3N0eWxlc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9jb3JlL3VzZU1lZGlhUXVlcnlcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvY29yZS93aXRoV2lkdGhcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvQ2xvc2VcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvQ2xvc2VPdXRsaW5lZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9pY29ucy9FeHBhbmRNb3JlT3V0bGluZWRcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJAbWF0ZXJpYWwtdWkvaWNvbnMvSGVscE91dGxpbmVPdXRsaW5lZFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBtYXRlcmlhbC11aS9sYWJcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJjbHN4XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiZmVhdGhlci1pY29ucy1yZWFjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvcm91dGVyXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicHJvcC10eXBlc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3QtZmVhdGhlclwiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIl0sIm5hbWVzIjpbImdsb2JhbCIsIlZBTElEX0xPQURJTkdfVkFMVUVTIiwibG9hZGVycyIsIlZBTElEX0xBWU9VVF9WQUxVRVMiLCJkZXZpY2VTaXplcyIsImltYWdlU2l6ZXMiLCJsb2FkZXIiLCJwYXRoIiwiZG9tYWlucyIsInByb2Nlc3MiLCJpbWFnZUNvbmZpZ0RlZmF1bHQiLCJhbGxTaXplcyIsImNvbmZpZ0RldmljZVNpemVzIiwiYSIsImxheW91dCIsIndpZHRocyIsImtpbmQiLCJ3aWR0aCIsInciLCJwIiwic3JjU2V0Iiwic2l6ZXMiLCJnZXRXaWR0aHMiLCJsYXN0Iiwic3JjIiwiaSIsInBhcnNlSW50IiwibG9hZCIsInJvb3QiLCJWQUxJRF9MT0FERVJTIiwiY29uZmlnTG9hZGVyIiwidW5vcHRpbWl6ZWQiLCJwcmlvcml0eSIsImFsbCIsInJlc3QiLCJ1bnNpemVkIiwiQm9vbGVhbiIsIkpTT04iLCJsb2FkaW5nIiwiaXNMYXp5Iiwicm9vdE1hcmdpbiIsImRpc2FibGVkIiwiaXNWaXNpYmxlIiwid2lkdGhJbnQiLCJnZXRJbnQiLCJoZWlnaHRJbnQiLCJxdWFsaXR5SW50IiwiaW1nU3R5bGUiLCJ2aXNpYmlsaXR5IiwicG9zaXRpb24iLCJ0b3AiLCJsZWZ0IiwiYm90dG9tIiwicmlnaHQiLCJib3hTaXppbmciLCJwYWRkaW5nIiwiYm9yZGVyIiwibWFyZ2luIiwiZGlzcGxheSIsImhlaWdodCIsIm1pbldpZHRoIiwibWF4V2lkdGgiLCJtaW5IZWlnaHQiLCJtYXhIZWlnaHQiLCJxdW90aWVudCIsInBhZGRpbmdUb3AiLCJpc05hTiIsIndyYXBwZXJTdHlsZSIsIm92ZXJmbG93Iiwic2l6ZXJTdHlsZSIsInNpemVyU3ZnIiwiaW1nQXR0cmlidXRlcyIsImdlbmVyYXRlSW1nQXR0cnMiLCJxdWFsaXR5IiwicGFyYW1zIiwicGFyYW1zU3RyaW5nIiwibm9ybWFsaXplU3JjIiwibWlzc2luZ1ZhbHVlcyIsInBhcnNlZFNyYyIsImNvbnNvbGUiLCJjb25maWdEb21haW5zIiwiaG9zdG5hbWUiLCJlbmNvZGVVUklDb21wb25lbnQiLCJyZXF1ZXN0SWRsZUNhbGxiYWNrIiwic2VsZiIsInN0YXJ0IiwiRGF0ZSIsInNldFRpbWVvdXQiLCJjYiIsImRpZFRpbWVvdXQiLCJ0aW1lUmVtYWluaW5nIiwiTWF0aCIsImNhbmNlbElkbGVDYWxsYmFjayIsImNsZWFyVGltZW91dCIsImhhc0ludGVyc2VjdGlvbk9ic2VydmVyIiwiaXNEaXNhYmxlZCIsInVub2JzZXJ2ZSIsInNldFJlZiIsImVsIiwib2JzZXJ2ZSIsInNldFZpc2libGUiLCJpZGxlQ2FsbGJhY2siLCJjcmVhdGVPYnNlcnZlciIsImVsZW1lbnRzIiwib2JzZXJ2ZXIiLCJvYnNlcnZlcnMiLCJpZCIsIm9wdGlvbnMiLCJpbnN0YW5jZSIsImVudHJpZXMiLCJlbnRyeSIsImNhbGxiYWNrIiwiaGFuZGxlRGVsZXRlIiwiaW5mbyIsIlN0eWxlZENvbXBvbmVudE1vZHVsZSIsInZhbHVlIiwic2V0VmFsdWUiLCJ1c2VTdGF0ZSIsImNoZWNrZWQiLCJzZXRDaGVja2VkIiwic2hvd0RldGFpbHMiLCJzZXRTaG93RGV0YWlscyIsInN0YXRlIiwic2V0U3RhdGUiLCJjaGVja2VkQSIsImNoZWNrZWRCIiwic2VsZWN0Iiwic2V0c2VsZWN0IiwiUmVhY3QiLCJoYW5kbGVDaGFuZ2VTZWxlY3RCb3giLCJldmVudCIsInRhcmdldCIsIm9wZW5EaWFsb2ciLCJzZXRPcGVuRGlhbG9nIiwiaGFuZGxlQ2xpY2tPcGVuRGlhbG9nIiwiaGFuZGxlQ2xvc2UiLCJoYW5kbGVDaGFuZ2UiLCJoYW5kbGVDaGFuZ2VDaGVja0JveCIsImhhbmRsZUNoYW5nZVN3aXRjaEJveCIsIm5hbWUiLCJtYXAiLCJpdGVtIiwiaW5kZXgiLCJlbmRBZG9ybm1lbnQiLCJFeHBhbmRNb3JlT3V0bGluZWRJY29uIiwiQ29tbW9uQ29tcG9uZW50U3R5bGUiLCJBbGVydHMiLCJ2YXJpYW50IiwiaWNvbkNvbG9yIiwiY2hpbGRyZW4iLCJzaG93Q2xvc2VCdG4iLCJjbGFzc2VzIiwidXNlU3R5bGVzIiwiZGVmYXVsdFByb3BzIiwicHJvcFR5cGVzIiwiUHJvcFR5cGVzIiwib25lT2YiLCJub2RlIiwiYm9vbCIsIm1ha2VTdHlsZXMiLCJ0aGVtZSIsInByaW1hcnlBbGVydCIsImJhY2tncm91bmRDb2xvciIsInBhbGV0dGUiLCJwcmltYXJ5IiwibWFpbiIsImNvbG9yIiwiY29tbW9uIiwid2hpdGUiLCJib3hTaGFkb3ciLCJib3JkZXJSYWRpdXMiLCJzZWNvbmRhcnlBbGVydCIsIm1lbnVzIiwibWVudUJhY2tncm91bmQiLCJsaWdodCIsIkFubm90YXRpb25zIiwiYmdDb2xvciIsIm1pbkhlaWdodHMiLCJzdHJpbmciLCJudW1iZXIiLCJDaGlwcyIsImxhYmVsIiwib25EZWxldGUiLCJmdW5jIiwiZm9udFNpemUiLCJ0eXBvZ3JhcGh5Iiwic20iLCJmb250RmFtaWx5IiwiZXh0cmFCb2xkIiwic3BhY2luZyIsIkV4aXREaWFsb2dCb3giLCJvbkNvbmZpcm0iLCJvbkNsb3NlIiwiRm9ybUVycm9yTWVzc2FnZSIsInRpdGxlIiwiTWFpbkhlYWRlciIsImlzTG9nZ2VkSW4iLCJ1c2VyTmFtZSIsImhlYWRlclN1YnRpdGxlIiwic2hvd0JhY2tCdG4iLCJtb2JpbGVUaXRsZSIsImxhYmVsTmFtZSIsInNob3dNb2JpbGVNZW51IiwibWVudVR5cGUiLCJzZXRNZW51VHlwZSIsInNob3dNZW51QmFyIiwiYnJlYWtQb2ludCIsInVzZU1lZGlhUXVlcnkiLCJidXR0b25Db2xvciIsImJ1dHRvblRpdGxlIiwibGlua05hbWVBcnJheSIsImxpbmtOYW1lIiwiY29udGludWVUb0xvZ2luIiwiVVNFUl9MT0dJTiIsIlJPVVRFUyIsIlJvdXRlciIsInB1c2giLCJST1VURSIsImNsc3giLCJtYWluSGVhZGVyV3JhcHBlciIsImRpc3BsYXlOb25lWHMiLCJsb2dvSW1hZ2UiLCJtZW51QnV0dG9uIiwibGlua1dyYXBwZXIiLCJsZW5ndGgiLCJkaXNwbGF5QmxvY2tYcyIsImJhY2tncm91bmRJbWFnZSIsImJhY2tncm91bmRSZXBlYXQiLCJiYWNrZ3JvdW5kUG9zaXRpb24iLCJiYWNrZ3JvdW5kU2l6ZSIsImJvcmRlckJvdHRvbUxlZnRSYWRpdXMiLCJib3JkZXJCb3R0b21SaWdodFJhZGl1cyIsImJyZWFrcG9pbnRzIiwidXAiLCJzdWNjZXNzIiwiaDIiLCJkb3duIiwiTW9iaWxlTWVudSIsImJlZm9yZUxvZ2luIiwib3Blbk1vYmlsZU1lbnUiLCJzZXRPcGVuTW9iaWxlTWVudSIsImxpbmtzIiwiYmVmb3JlTG9naW5MaW5rQXJyYXkiLCJsaW5rQXJyYXkiLCJhY3Rpb25MaW5rcyIsImJlZm9yZUxvZ2luUGFnZXNMaW5rQXJyYXkiLCJhZnRlckxvZ2luUGFnZXNMaW5rQXJyYXkiLCJsb2dpbldyYXBwZXIiLCJiZWZvcmVMb2dpbldyYXBwZXIiLCJ0ZXh0IiwiY3VzdG9tQnV0dG9uIiwidG9wSW1hZ2VQb3NpdGlvbiIsImJvdHRvbUltYWdlUG9zaXRpb24iLCJpbWFnZSIsImljb24iLCJIb21lIiwiRmlsZVRleHQiLCJVc2VyIiwiSGVscENpcmNsZSIsIlNlbmQiLCJ6SW5kZXgiLCJoNiIsIlRvcEhlYWRlciIsImlzV2l6YXJkIiwib25DbGlja0JhY2siLCJvbkV4aXRDbGljayIsImxpbmsiLCJtYXJnaW5SaWdodCIsImNvbnRlbnQiLCJJbmRpY2F0b3JzIiwic3RhdHVzIiwic2l6ZSIsImljb25OYW1lIiwiaWNvblNpemUiLCJib3JkZXJXaWR0aCIsImZhaWxlZCIsImVycm9yIiwiYm9yZGVyQ29sb3IiLCJwZW5kaW5nIiwiZGVmYXVsdCIsImNvbXBsZXRlIiwiYmFja2dyb3VuZENsaXAiLCJMb2dvSGVhZGluZyIsInN1YlRleHRDb2xvciIsIk9iamVjdENhcmQiLCJwcm9wcyIsImNhcmRUeXBlIiwib25DbGljayIsImlzTWVtYmVyIiwib25FZGl0Q2xpY2siLCJzaG93T3B0aW9uTWVudSIsImFuY2hvckVsIiwic2V0QW5jaG9yRWwiLCJvcGVuIiwiaGFuZGxlQ2xpY2siLCJjdXJyZW50VGFyZ2V0IiwiaGFuZGxlRWRpdCIsInJvb3RVcGxvYWQiLCJpbnB1dCIsIm5vb3AiLCJQYWdlSGVhZGluZyIsIlByb2dyYW1DYXJkIiwic2hvd0xlZnRBcnJvdyIsInNob3dEZWxldGVCb3giLCJzaG93SW1hZ2UiLCJzaG93TGVmdEJvcmRlciIsImltZ1VybCIsIm92ZXJsYXkiLCJ3aXRoV2lkdGgiLCJiYWNrZ3JvdW5kIiwid2FpdGluZyIsIlRvb2x0aXBzIiwiWm9vbSIsIkhPTUUiLCJUSVRMRSIsIk5BTUUiLCJQQVJFTlRfUk9VVEUiLCJFWEFNUExFUyIsIkxPR0lOIiwiUFJPRklMRSIsIlZPVUNIRVIiLCJBQ0NPVU5UIiwiQUNDT1VOVF9ERVRBSUwiLCJHRVRfU1RBUlRFRCIsIkhFTFAiLCJIRUxQX1RPUElDUyIsIkNIQU5HRV9QQVNTV09SRCIsIkZPUkdPVF9QQVNTV09SRCIsIkNPTU1PTl9DT01QT05FTlRfU1RZTEUiLCJDT01NT05fRlVMTEZMT1dQQUdFX1NUWUxFIiwiVk9VQ0hFUl9SRUNFSVZFRCIsIkRBU0hCT0FSRF9QQUdFX1NUWUxFIiwiTEFORExPUkRfUEFHRV9TVFlMRSIsIlNVUEVSVklTT1JfTE9HSU4iLCJDSEVDS19FTElHSUJJTElUWSIsIlNVUEVSVklTT1JfREFTSEJPQVJEIiwiQ1JFQVRFX1BST0ZJTEUiLCJFTElHSUJJTElUWV9DQUxDVUxBVE9SIiwiTUFOQUdFX1BST0dSQU1TIiwiTUFOQUdFX1NNVFAiLCJNQU5BR0VfUFJFQVBQTElDQVRJT04iLCJIT1VTRV9IT0xEX0RFVEFJTCIsIlJFVklFV19BUFBMSUNBVElPTiIsIkhPVVNFSE9MRF9JTkNPTUUiLCJIT1VTRUhPTERfQVNTRVRTIiwiSE9VU0VIT0xEX1NQRUNJQUxfRVhQRU5TRVMiLCJSRU5UX0FGRk9SREFCSUxJVFkiLCJZT1VSX0RPQ1VNRU5UUyIsIlJFVklFV19BTkRfU0lHTiIsInNldExvY2FsU3RvcmFnZSIsImtleSIsInN0b3JhZ2VWYWx1ZSIsInN0cmluZ2lmeSIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsInNldEl0ZW0iLCJnZXRMb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwicGFyc2UiLCJyZW1vdmVMb2NhbFN0b3JhZ2UiLCJyZW1vdmVJdGVtIiwiZ2V0QmFzZVVybCIsImdldExvY2FsaXplS2V5IiwiZ2V0VXNlcklkIiwidXNlckRldGFpbCIsInVzZXJfaWQiLCJnZXRBY2Nlc3NUb2tlbiIsImFjY2Vzc190b2tlbiJdLCJtYXBwaW5ncyI6Ijs7UUFBQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLElBQUk7UUFDSjtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBOzs7UUFHQTtRQUNBOztRQUVBO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMENBQTBDLGdDQUFnQztRQUMxRTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLHdEQUF3RCxrQkFBa0I7UUFDMUU7UUFDQSxpREFBaUQsY0FBYztRQUMvRDs7UUFFQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0EseUNBQXlDLGlDQUFpQztRQUMxRSxnSEFBZ0gsbUJBQW1CLEVBQUU7UUFDckk7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSwyQkFBMkIsMEJBQTBCLEVBQUU7UUFDdkQsaUNBQWlDLGVBQWU7UUFDaEQ7UUFDQTtRQUNBOztRQUVBO1FBQ0Esc0RBQXNELCtEQUErRDs7UUFFckg7UUFDQTs7O1FBR0E7UUFDQTs7Ozs7Ozs7Ozs7O0FDeEZBLDhEOzs7Ozs7Ozs7OztBQ0FBLG9FOzs7Ozs7Ozs7OztBQ0FBLHlFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBOztBQUNBOztBQUNBOztBQUNBOztBQU1BOztBQUVBLFVBQW1DO0FBQ2pDO0FBQUVBLFFBQUQsc0JBQUNBLEdBQUQsSUFBQ0E7QUFHSjs7QUFBQSxNQUFNQyxvQkFBb0IsR0FBRyxrQkFBN0IsU0FBNkIsQ0FBN0I7QUFhQSxNQUFNQyxPQUFPLEdBQUcsUUFHZCxDQUNBLFVBREEsV0FDQSxDQURBLEVBRUEsZUFGQSxnQkFFQSxDQUZBLEVBR0EsV0FIQSxZQUdBLENBSEEsRUFJQSxZQVBGLGFBT0UsQ0FKQSxDQUhjLENBQWhCO0FBVUEsTUFBTUMsbUJBQW1CLEdBQUcsNkNBQTVCLFNBQTRCLENBQTVCO0FBc0NBLE1BQU07QUFDSkMsYUFBVyxFQURQO0FBRUpDLFlBQVUsRUFGTjtBQUdKQyxRQUFNLEVBSEY7QUFJSkMsTUFBSSxFQUpBO0FBS0pDLFNBQU8sRUFMSDtBQUFBLElBT0ZDLDBKQUF5REMsYUFQN0QsbUIsQ0FRQTs7QUFDQSxNQUFNQyxRQUFRLEdBQUcsQ0FBQyxHQUFELG1CQUF1QixHQUF4QyxnQkFBaUIsQ0FBakI7QUFDQUMsaUJBQWlCLENBQWpCQSxLQUF1QixVQUFVQyxDQUFDLEdBQWxDRDtBQUNBRCxRQUFRLENBQVJBLEtBQWMsVUFBVUUsQ0FBQyxHQUF6QkY7O0FBRUEsa0NBR3lDO0FBQ3ZDLE1BQ0UsNkJBQ0FHLE1BQU0sS0FETixVQUVBQSxNQUFNLEtBSFIsY0FJRTtBQUNBLFdBQU87QUFBRUMsWUFBTSxFQUFSO0FBQTZCQyxVQUFJLEVBQXhDO0FBQU8sS0FBUDtBQUdGOztBQUFBLFFBQU1ELE1BQU0sR0FBRyxDQUNiLEdBQUcsU0FDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBUUUsS0FBSyxHQUFHO0FBQWhCO0FBQUEsUUFDR0MsQ0FBRCxJQUFPUCxRQUFRLENBQVJBLEtBQWVRLENBQUQsSUFBT0EsQ0FBQyxJQUF0QlIsTUFBZ0NBLFFBQVEsQ0FBQ0EsUUFBUSxDQUFSQSxTQVh0RCxDQVdxRCxDQURqRCxDQVRDLENBRFUsQ0FBZjtBQWVBLFNBQU87QUFBQTtBQUFVSyxRQUFJLEVBQXJCO0FBQU8sR0FBUDtBQW1CRjs7QUFBQSwwQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBMUI7QUFBMEIsQ0FBMUIsRUFRdUM7QUFDckMsbUJBQWlCO0FBQ2YsV0FBTztBQUFBO0FBQU9JLFlBQU0sRUFBYjtBQUEwQkMsV0FBSyxFQUF0QztBQUFPLEtBQVA7QUFHRjs7QUFBQSxRQUFNO0FBQUE7QUFBQTtBQUFBLE1BQW1CQyxTQUFTLFFBQWxDLE1BQWtDLENBQWxDO0FBQ0EsUUFBTUMsSUFBSSxHQUFHUixNQUFNLENBQU5BLFNBQWI7QUFFQSxTQUFPO0FBQ0xTLE9BQUcsRUFBRWxCLE1BQU0sQ0FBQztBQUFBO0FBQUE7QUFBZ0JXLFdBQUssRUFBRUYsTUFBTSxDQURwQyxJQUNvQztBQUE3QixLQUFELENBRE47QUFFTE0sU0FBSyxFQUFFLFVBQVVMLElBQUksS0FBZCxnQkFGRjtBQUdMSSxVQUFNLEVBQUVMLE1BQU0sQ0FBTkEsSUFFSixVQUNHLEdBQUVULE1BQU0sQ0FBQztBQUFBO0FBQUE7QUFBZ0JXLFdBQUssRUFBdEI7QUFBQyxLQUFELENBQTZCLElBQ3BDRCxJQUFJLEtBQUpBLFVBQW1CUyxDQUFDLEdBQUcsQ0FDeEIsR0FBRVQsSUFMREQsU0FIVixJQUdVQTtBQUhILEdBQVA7QUFjRjs7QUFBQSxtQkFBZ0Q7QUFDOUMsTUFBSSxhQUFKLFVBQTJCO0FBQ3pCO0FBRUY7O0FBQUEsTUFBSSxhQUFKLFVBQTJCO0FBQ3pCLFdBQU9XLFFBQVEsSUFBZixFQUFlLENBQWY7QUFFRjs7QUFBQTtBQUdGOztBQUFBLHlDQUEyRDtBQUN6RCxRQUFNQyxJQUFJLEdBQUd6QixPQUFPLENBQVBBLElBQWIsWUFBYUEsQ0FBYjs7QUFDQSxZQUFVO0FBQ1IsV0FBT3lCLElBQUk7QUFBR0MsVUFBSSxFQUFQO0FBQUEsT0FBWCxXQUFXLEVBQVg7QUFFRjs7QUFBQSxRQUFNLFVBQ0gseURBQXdEQyxxQ0FFdkQsZUFBY0MsWUFIbEIsRUFBTSxDQUFOO0FBT2E7O0FBQUEscUJBY0E7QUFBQSxNQWRlO0FBQUE7QUFBQTtBQUc1QkMsZUFBVyxHQUhpQjtBQUk1QkMsWUFBUSxHQUpvQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBWTVCMUIsVUFBTSxHQVpzQjtBQUFBLE1BY2Y7QUFBQSxNQURWMkIsR0FDVTtBQUNiLE1BQUlDLElBQXlCLEdBQTdCO0FBQ0EsTUFBSXBCLE1BQWdDLEdBQUdPLEtBQUssa0JBQTVDO0FBQ0EsTUFBSWMsT0FBTyxHQUFYOztBQUNBLE1BQUksYUFBSixNQUF1QjtBQUNyQkEsV0FBTyxHQUFHQyxPQUFPLENBQUNGLElBQUksQ0FBdEJDLE9BQWlCLENBQWpCQSxDQURxQixDQUVyQjs7QUFDQSxXQUFPRCxJQUFJLENBQVgsU0FBVyxDQUFYO0FBSEYsU0FJTyxJQUFJLFlBQUosTUFBc0I7QUFDM0I7QUFDQSxRQUFJQSxJQUFJLENBQVIsUUFBaUJwQixNQUFNLEdBQUdvQixJQUFJLENBQWJwQixPQUZVLENBSTNCOztBQUNBLFdBQU9vQixJQUFJLENBQVgsUUFBVyxDQUFYO0FBR0Y7O0FBQUEsWUFBMkM7QUFDekMsUUFBSSxDQUFKLEtBQVU7QUFDUixZQUFNLFVBQ0gsMEhBQXlIRyxJQUFJLENBQUpBLFVBQ3hIO0FBQUE7QUFBQTtBQUR3SEE7QUFDeEgsT0FEd0hBLENBRDVILEVBQU0sQ0FBTjtBQU1GOztBQUFBLFFBQUksQ0FBQ2xDLG1CQUFtQixDQUFuQkEsU0FBTCxNQUFLQSxDQUFMLEVBQTJDO0FBQ3pDLFlBQU0sVUFDSCxtQkFBa0JxQixHQUFJLDhDQUE2Q1YsTUFBTyxzQkFBcUJYLG1CQUFtQixDQUFuQkEscUJBRGxHLEdBQU0sQ0FBTjtBQU1GOztBQUFBLFFBQUksQ0FBQ0Ysb0JBQW9CLENBQXBCQSxTQUFMLE9BQUtBLENBQUwsRUFBNkM7QUFDM0MsWUFBTSxVQUNILG1CQUFrQnVCLEdBQUksK0NBQThDYyxPQUFRLHNCQUFxQnJDLG9CQUFvQixDQUFwQkEscUJBRHBHLEdBQU0sQ0FBTjtBQU1GOztBQUFBLFFBQUkrQixRQUFRLElBQUlNLE9BQU8sS0FBdkIsUUFBb0M7QUFDbEMsWUFBTSxVQUNILG1CQUFrQmQsR0FEckIsaUZBQU0sQ0FBTjtBQUlGOztBQUFBLGlCQUFhO0FBQ1gsWUFBTSxVQUNILG1CQUFrQkEsR0FEckIsaUdBQU0sQ0FBTjtBQUlIO0FBRUQ7O0FBQUEsTUFBSWUsTUFBTSxHQUNSLGNBQWNELE9BQU8sS0FBUEEsVUFBc0IsbUJBRHRDLFdBQ0UsQ0FERjs7QUFFQSxNQUFJZCxHQUFHLElBQUlBLEdBQUcsQ0FBSEEsV0FBWCxPQUFXQSxDQUFYLEVBQW9DO0FBQ2xDO0FBQ0FPLGVBQVcsR0FBWEE7QUFDQVEsVUFBTSxHQUFOQTtBQUdGOztBQUFBLFFBQU0sMEJBQTBCLHNDQUFrQztBQUNoRUMsY0FBVSxFQURzRDtBQUVoRUMsWUFBUSxFQUFFLENBRlo7QUFBa0UsR0FBbEMsQ0FBaEM7QUFJQSxRQUFNQyxTQUFTLEdBQUcsV0FBbEI7QUFFQSxRQUFNQyxRQUFRLEdBQUdDLE1BQU0sQ0FBdkIsS0FBdUIsQ0FBdkI7QUFDQSxRQUFNQyxTQUFTLEdBQUdELE1BQU0sQ0FBeEIsTUFBd0IsQ0FBeEI7QUFDQSxRQUFNRSxVQUFVLEdBQUdGLE1BQU0sQ0FBekIsT0FBeUIsQ0FBekI7QUFFQTtBQUNBO0FBQ0E7QUFDQSxNQUFJRyxRQUFxQyxHQUFHO0FBQzFDQyxjQUFVLEVBQUVOLFNBQVMsZUFEcUI7QUFHMUNPLFlBQVEsRUFIa0M7QUFJMUNDLE9BQUcsRUFKdUM7QUFLMUNDLFFBQUksRUFMc0M7QUFNMUNDLFVBQU0sRUFOb0M7QUFPMUNDLFNBQUssRUFQcUM7QUFTMUNDLGFBQVMsRUFUaUM7QUFVMUNDLFdBQU8sRUFWbUM7QUFXMUNDLFVBQU0sRUFYb0M7QUFZMUNDLFVBQU0sRUFab0M7QUFjMUNDLFdBQU8sRUFkbUM7QUFlMUN6QyxTQUFLLEVBZnFDO0FBZ0IxQzBDLFVBQU0sRUFoQm9DO0FBaUIxQ0MsWUFBUSxFQWpCa0M7QUFrQjFDQyxZQUFRLEVBbEJrQztBQW1CMUNDLGFBQVMsRUFuQmlDO0FBb0IxQ0MsYUFBUyxFQXBCaUM7QUFBQTtBQUE1QztBQUE0QyxHQUE1Qzs7QUF5QkEsTUFDRSxtQ0FDQSxxQkFEQSxlQUVBakQsTUFBTSxLQUhSLFFBSUU7QUFDQTtBQUNBLFVBQU1rRCxRQUFRLEdBQUduQixTQUFTLEdBQTFCO0FBQ0EsVUFBTW9CLFVBQVUsR0FBR0MsS0FBSyxDQUFMQSxRQUFLLENBQUxBLFlBQTRCLEdBQUVGLFFBQVEsR0FBRyxHQUE1RDs7QUFDQSxRQUFJbEQsTUFBTSxLQUFWLGNBQTZCO0FBQzNCO0FBQ0FxRCxrQkFBWSxHQUFHO0FBQ2JULGVBQU8sRUFETTtBQUViVSxnQkFBUSxFQUZLO0FBR2JuQixnQkFBUSxFQUhLO0FBS2JLLGlCQUFTLEVBTEk7QUFNYkcsY0FBTSxFQU5SVTtBQUFlLE9BQWZBO0FBUUFFLGdCQUFVLEdBQUc7QUFBRVgsZUFBTyxFQUFUO0FBQW9CSixpQkFBUyxFQUE3QjtBQUFiZTtBQUFhLE9BQWJBO0FBVkYsV0FXTyxJQUFJdkQsTUFBTSxLQUFWLGFBQTRCO0FBQ2pDO0FBQ0FxRCxrQkFBWSxHQUFHO0FBQ2JULGVBQU8sRUFETTtBQUViRyxnQkFBUSxFQUZLO0FBR2JPLGdCQUFRLEVBSEs7QUFJYm5CLGdCQUFRLEVBSks7QUFLYkssaUJBQVMsRUFMSTtBQU1iRyxjQUFNLEVBTlJVO0FBQWUsT0FBZkE7QUFRQUUsZ0JBQVUsR0FBRztBQUNYZixpQkFBUyxFQURFO0FBRVhJLGVBQU8sRUFGSTtBQUdYRyxnQkFBUSxFQUhWUTtBQUFhLE9BQWJBO0FBS0FDLGNBQVEsR0FBSSxlQUFjM0IsUUFBUyxhQUFZRSxTQUEvQ3lCO0FBZkssV0FnQkEsSUFBSXhELE1BQU0sS0FBVixTQUF3QjtBQUM3QjtBQUNBcUQsa0JBQVksR0FBRztBQUNiQyxnQkFBUSxFQURLO0FBRWJkLGlCQUFTLEVBRkk7QUFHYkksZUFBTyxFQUhNO0FBSWJULGdCQUFRLEVBSks7QUFLYmhDLGFBQUssRUFMUTtBQU1iMEMsY0FBTSxFQU5SUTtBQUFlLE9BQWZBO0FBU0g7QUE5Q0QsU0E4Q08sSUFDTCxtQ0FDQSxxQkFEQSxlQUVBckQsTUFBTSxLQUhELFFBSUw7QUFDQTtBQUNBcUQsZ0JBQVksR0FBRztBQUNiVCxhQUFPLEVBRE07QUFFYlUsY0FBUSxFQUZLO0FBSWJuQixjQUFRLEVBSks7QUFLYkMsU0FBRyxFQUxVO0FBTWJDLFVBQUksRUFOUztBQU9iQyxZQUFNLEVBUE87QUFRYkMsV0FBSyxFQVJRO0FBVWJDLGVBQVMsRUFWSTtBQVdiRyxZQUFNLEVBWFJVO0FBQWUsS0FBZkE7QUFOSyxTQW1CQTtBQUNMO0FBQ0EsY0FBMkM7QUFDekMsWUFBTSxVQUNILG1CQUFrQjNDLEdBRHJCLHlFQUFNLENBQU47QUFJSDtBQUVEOztBQUFBLE1BQUkrQyxhQUFnQyxHQUFHO0FBQ3JDL0MsT0FBRyxFQURrQztBQUdyQ0osVUFBTSxFQUgrQjtBQUlyQ0MsU0FBSyxFQUpQO0FBQXVDLEdBQXZDOztBQU9BLGlCQUFlO0FBQ2JrRCxpQkFBYSxHQUFHQyxnQkFBZ0IsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUkvQnZELFdBQUssRUFKMEI7QUFLL0J3RCxhQUFPLEVBTHdCO0FBQUE7QUFBakNGO0FBQWlDLEtBQUQsQ0FBaENBO0FBV0Y7O0FBQUEsZUFBYTtBQUNYSixnQkFBWSxHQUFaQTtBQUNBRSxjQUFVLEdBQVZBO0FBQ0F0QixZQUFRLEdBQVJBO0FBRUY7O0FBQUEsc0JBQ0U7QUFBSyxTQUFLLEVBQVY7QUFBQSxLQUNHc0IsVUFBVSxnQkFDVDtBQUFLLFNBQUssRUFBVjtBQUFBLEtBQ0dDLFFBQVEsZ0JBQ1A7QUFDRSxTQUFLLEVBQUU7QUFDTFQsY0FBUSxFQURIO0FBRUxILGFBQU8sRUFGRjtBQUdMRCxZQUFNLEVBSEQ7QUFJTEQsWUFBTSxFQUpEO0FBS0xELGFBQU8sRUFOWDtBQUNTLEtBRFQ7QUFRRSxPQUFHLEVBUkw7QUFTRSxtQkFURjtBQVVFLFFBQUksRUFWTjtBQVdFLE9BQUcsRUFBRyw2QkFBNEIsK0JBWjdCO0FBQ1AsSUFETyxHQUZGLElBQ1QsQ0FEUyxHQURiLG1CQW9CRTtBQUdFLFlBQVEsRUFIVjtBQUlFLGFBQVMsRUFKWDtBQUtFLE9BQUcsRUFMTDtBQU1FLFNBQUssRUExQlQ7QUFvQkUsS0FwQkYsRUE0Qkd2QixRQUFRO0FBQUE7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQUMsTUFBRCw0QkFDRTtBQUNFLE9BQUcsRUFDRCxZQUNBdUMsYUFBYSxDQURiLE1BRUFBLGFBQWEsQ0FGYixTQUdBQSxhQUFhLENBTGpCO0FBT0UsT0FBRyxFQVBMO0FBUUUsTUFBRSxFQVJKO0FBU0UsUUFBSSxFQUFFQSxhQUFhLENBQWJBLHFCQUFtQ0EsYUFBYSxDQUFDL0MsR0FUekQsQ0FVRTtBQVZGO0FBV0UsZUFBVyxFQUFFK0MsYUFBYSxDQUFDbkQsTUFYN0IsQ0FZRTtBQVpGO0FBYUUsY0FBVSxFQUFFbUQsYUFBYSxDQXBCdEI7QUFPTCxJQURGLENBTk8sR0E3QmIsSUFDRSxDQURGO0FBeURGLEMsQ0FBQTs7O0FBRUEsMkJBQTJDO0FBQ3pDLFNBQU8vQyxHQUFHLENBQUhBLENBQUcsQ0FBSEEsV0FBaUJBLEdBQUcsQ0FBSEEsTUFBakJBLENBQWlCQSxDQUFqQkEsR0FBUDtBQUdGOztBQUFBLHFCQUFxQjtBQUFBO0FBQUE7QUFBQTtBQUFyQjtBQUFxQixDQUFyQixFQUtvQztBQUNsQztBQUNBLFFBQU1rRCxNQUFNLEdBQUcsMkJBQTJCLE9BQTFDLEtBQWUsQ0FBZjtBQUNBLE1BQUlDLFlBQVksR0FBaEI7O0FBQ0EsZUFBYTtBQUNYRCxVQUFNLENBQU5BLEtBQVksT0FBWkE7QUFHRjs7QUFBQSxNQUFJQSxNQUFNLENBQVYsUUFBbUI7QUFDakJDLGdCQUFZLEdBQUcsTUFBTUQsTUFBTSxDQUFOQSxLQUFyQkMsR0FBcUJELENBQXJCQztBQUVGOztBQUFBLFNBQVEsR0FBRS9DLElBQUssR0FBRWdELFlBQVksS0FBTSxHQUFFRCxZQUFyQztBQUdGOztBQUFBLHNCQUFzQjtBQUFBO0FBQUE7QUFBdEI7QUFBc0IsQ0FBdEIsRUFBNkU7QUFDM0UsU0FBUSxHQUFFL0MsSUFBSyxHQUFFZ0QsWUFBWSxLQUFNLFlBQVczRCxLQUE5QztBQUdGOztBQUFBLDBCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUExQjtBQUEwQixDQUExQixFQUtvQztBQUNsQztBQUNBLFFBQU15RCxNQUFNLEdBQUcsc0JBQXNCLE9BQXRCLE9BQW9DLFFBQVFELE9BQU8sSUFBbEUsTUFBbUQsQ0FBcEMsQ0FBZjtBQUNBLE1BQUlFLFlBQVksR0FBR0QsTUFBTSxDQUFOQSxZQUFuQjtBQUNBLFNBQVEsR0FBRTlDLElBQUssR0FBRStDLFlBQWEsR0FBRUMsWUFBWSxLQUE1QztBQUdGOztBQUFBLHVCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUF2QjtBQUF1QixDQUF2QixFQUtvQztBQUNsQyxZQUEyQztBQUN6QyxVQUFNQyxhQUFhLEdBQW5CLEdBRHlDLENBR3pDOztBQUNBLFFBQUksQ0FBSixLQUFVQSxhQUFhLENBQWJBO0FBQ1YsUUFBSSxDQUFKLE9BQVlBLGFBQWEsQ0FBYkE7O0FBRVosUUFBSUEsYUFBYSxDQUFiQSxTQUFKLEdBQThCO0FBQzVCLFlBQU0sVUFDSCxvQ0FBbUNBLGFBQWEsQ0FBYkEsVUFFbEMsZ0dBQStGeEMsSUFBSSxDQUFKQSxVQUMvRjtBQUFBO0FBQUE7QUFEK0ZBO0FBQy9GLE9BRCtGQSxDQUhuRyxFQUFNLENBQU47QUFTRjs7QUFBQSxRQUFJYixHQUFHLENBQUhBLFdBQUosSUFBSUEsQ0FBSixFQUEwQjtBQUN4QixZQUFNLFVBQ0gsd0JBQXVCQSxHQUQxQiwwR0FBTSxDQUFOO0FBS0Y7O0FBQUEsUUFBSSxDQUFDQSxHQUFHLENBQUhBLFdBQUQsR0FBQ0EsQ0FBRCxJQUFKLGVBQTJDO0FBQ3pDOztBQUNBLFVBQUk7QUFDRnNELGlCQUFTLEdBQUcsUUFBWkEsR0FBWSxDQUFaQTtBQUNBLE9BRkYsQ0FFRSxZQUFZO0FBQ1pDLGVBQU8sQ0FBUEE7QUFDQSxjQUFNLFVBQ0gsd0JBQXVCdkQsR0FEMUIsaUlBQU0sQ0FBTjtBQUtGOztBQUFBLFVBQUksQ0FBQ3dELGFBQWEsQ0FBYkEsU0FBdUJGLFNBQVMsQ0FBckMsUUFBS0UsQ0FBTCxFQUFpRDtBQUMvQyxjQUFNLFVBQ0gscUJBQW9CeEQsR0FBSSxrQ0FBaUNzRCxTQUFTLENBQUNHLFFBQXBFLCtEQUFDLEdBREgsb0VBQU0sQ0FBTjtBQUtIO0FBQ0Y7QUFFRDs7QUFBQSxTQUFRLEdBQUVyRCxJQUFLLFFBQU9zRCxrQkFBa0IsS0FBTSxNQUFLakUsS0FBTSxNQUFLd0QsT0FBTyxJQUFJLEVBQXpFO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1Z0JNLE1BQU1VLG1CQUFtQixHQUM3QiwrQkFBK0JDLElBQUksQ0FBcEMsbUJBQUMsSUFDRCxjQUVrQjtBQUNoQixNQUFJQyxLQUFLLEdBQUdDLElBQUksQ0FBaEIsR0FBWUEsRUFBWjtBQUNBLFNBQU9DLFVBQVUsQ0FBQyxZQUFZO0FBQzVCQyxNQUFFLENBQUM7QUFDREMsZ0JBQVUsRUFEVDtBQUVEQyxtQkFBYSxFQUFFLFlBQVk7QUFDekIsZUFBT0MsSUFBSSxDQUFKQSxPQUFZLE1BQU1MLElBQUksQ0FBSkEsUUFBekIsS0FBbUIsQ0FBWkssQ0FBUDtBQUhKSDtBQUFHLEtBQUQsQ0FBRkE7QUFEZSxLQUFqQixDQUFpQixDQUFqQjtBQU5HOzs7O0FBZ0JBLE1BQU1JLGtCQUFrQixHQUM1QiwrQkFBK0JSLElBQUksQ0FBcEMsa0JBQUMsSUFDRCxjQUF5QztBQUN2QyxTQUFPUyxZQUFZLENBQW5CLEVBQW1CLENBQW5CO0FBSEc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQ1A7O0FBQ0E7O0FBY0EsTUFBTUMsdUJBQXVCLEdBQUcsZ0NBQWhDOztBQUVPLHlCQUE0QztBQUFBO0FBQTVDO0FBQTRDLENBQTVDLEVBR3FEO0FBQzFELFFBQU1DLFVBQW1CLEdBQUd0RCxRQUFRLElBQUksQ0FBeEM7QUFFQSxRQUFNdUQsU0FBUyxHQUFHLFdBQWxCLE1BQWtCLEdBQWxCO0FBQ0EsUUFBTSx3QkFBd0IscUJBQTlCLEtBQThCLENBQTlCO0FBRUEsUUFBTUMsTUFBTSxHQUFHLHdCQUNaQyxFQUFELElBQWtCO0FBQ2hCLFFBQUlGLFNBQVMsQ0FBYixTQUF1QjtBQUNyQkEsZUFBUyxDQUFUQTtBQUNBQSxlQUFTLENBQVRBO0FBR0Y7O0FBQUEsUUFBSUQsVUFBVSxJQUFkLFNBQTJCOztBQUUzQixRQUFJRyxFQUFFLElBQUlBLEVBQUUsQ0FBWixTQUFzQjtBQUNwQkYsZUFBUyxDQUFUQSxVQUFvQkcsT0FBTyxLQUV4QnpELFNBQUQsSUFBZUEsU0FBUyxJQUFJMEQsVUFBVSxDQUZiLFNBRWEsQ0FGYixFQUd6QjtBQUhGSjtBQUdFLE9BSHlCLENBQTNCQTtBQU1IO0FBaEJZLEtBaUJiLHlCQWpCRixPQWlCRSxDQWpCYSxDQUFmO0FBb0JBLHdCQUFVLE1BQU07QUFDZCxRQUFJLENBQUoseUJBQThCO0FBQzVCLFVBQUksQ0FBSixTQUFjO0FBQ1osY0FBTUssWUFBWSxHQUFHLDhDQUFvQixNQUFNRCxVQUFVLENBQXpELElBQXlELENBQXBDLENBQXJCO0FBQ0EsZUFBTyxNQUFNLDZDQUFiLFlBQWEsQ0FBYjtBQUVIO0FBQ0Y7QUFQRCxLQU9HLENBUEgsT0FPRyxDQVBIO0FBU0EsU0FBTyxTQUFQLE9BQU8sQ0FBUDtBQUdGOztBQUFBLDZDQUljO0FBQ1osUUFBTTtBQUFBO0FBQUE7QUFBQTtBQUFBLE1BQTZCRSxjQUFjLENBQWpELE9BQWlELENBQWpEO0FBQ0FDLFVBQVEsQ0FBUkE7QUFFQUMsVUFBUSxDQUFSQTtBQUNBLFNBQU8scUJBQTJCO0FBQ2hDRCxZQUFRLENBQVJBO0FBQ0FDLFlBQVEsQ0FBUkEsbUJBRmdDLENBSWhDOztBQUNBLFFBQUlELFFBQVEsQ0FBUkEsU0FBSixHQUF5QjtBQUN2QkMsY0FBUSxDQUFSQTtBQUNBQyxlQUFTLENBQVRBO0FBRUg7QUFURDtBQVlGOztBQUFBLE1BQU1BLFNBQVMsR0FBRyxJQUFsQixHQUFrQixFQUFsQjs7QUFDQSxpQ0FBd0U7QUFDdEUsUUFBTUMsRUFBRSxHQUFHQyxPQUFPLENBQVBBLGNBQVg7QUFDQSxNQUFJQyxRQUFRLEdBQUdILFNBQVMsQ0FBVEEsSUFBZixFQUFlQSxDQUFmOztBQUNBLGdCQUFjO0FBQ1o7QUFHRjs7QUFBQSxRQUFNRixRQUFRLEdBQUcsSUFBakIsR0FBaUIsRUFBakI7QUFDQSxRQUFNQyxRQUFRLEdBQUcseUJBQTBCSyxPQUFELElBQWE7QUFDckRBLFdBQU8sQ0FBUEEsUUFBaUJDLEtBQUQsSUFBVztBQUN6QixZQUFNQyxRQUFRLEdBQUdSLFFBQVEsQ0FBUkEsSUFBYU8sS0FBSyxDQUFuQyxNQUFpQlAsQ0FBakI7QUFDQSxZQUFNN0QsU0FBUyxHQUFHb0UsS0FBSyxDQUFMQSxrQkFBd0JBLEtBQUssQ0FBTEEsb0JBQTFDOztBQUNBLFVBQUlDLFFBQVEsSUFBWixXQUEyQjtBQUN6QkEsZ0JBQVEsQ0FBUkEsU0FBUSxDQUFSQTtBQUVIO0FBTkRGO0FBRGUsS0FBakIsT0FBaUIsQ0FBakI7QUFVQUosV0FBUyxDQUFUQSxRQUVHRyxRQUFRLEdBQUc7QUFBQTtBQUFBO0FBRmRIO0FBRWMsR0FGZEE7QUFRQTtBQUNELEM7Ozs7Ozs7Ozs7O0FDM0dELGlCQUFpQixtQkFBTyxDQUFDLHFFQUFxQjs7Ozs7Ozs7Ozs7O0FDQTlDO0FBQ0E7QUFDQSxtQkFBbUIsc0JBQXNCO0FBQ3pDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsMEI7Ozs7Ozs7Ozs7O0FDbEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsd0M7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxhQUFhLHVCQUF1QjtBQUNwQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBLCtDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZkE7QUF3QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUVBOztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtDQUVBOztBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1PLFlBQVksR0FBRyxNQUFNO0FBQ3ZCO0FBQ0FqQyxTQUFPLENBQUNrQyxJQUFSLENBQWEsOEJBQWI7QUFDSCxDQUhEOztBQUtBLE1BQU1DLHFCQUFxQixHQUFHLE1BQU07QUFDaEMsUUFBTTtBQUFBLE9BQUNDLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CQyxzREFBUSxDQUFDLFFBQUQsQ0FBbEM7QUFDQSxRQUFNO0FBQUEsT0FBQ0MsT0FBRDtBQUFBLE9BQVVDO0FBQVYsTUFBd0JGLHNEQUFRLENBQUMsSUFBRCxDQUF0QztBQUVBLFFBQU07QUFBQSxPQUFDRyxXQUFEO0FBQUEsT0FBY0M7QUFBZCxNQUFnQ0osc0RBQVEsQ0FBQyxLQUFELENBQTlDO0FBRUEsUUFBTTtBQUFBLE9BQUNLLEtBQUQ7QUFBQSxPQUFRQztBQUFSLE1BQW9CTixzREFBUSxDQUFDO0FBQy9CTyxZQUFRLEVBQUUsSUFEcUI7QUFFL0JDLFlBQVEsRUFBRTtBQUZxQixHQUFELENBQWxDO0FBS0EsUUFBTSxDQUFDQyxNQUFELEVBQVNDLFNBQVQsSUFBc0JDLDRDQUFLLENBQUNYLFFBQU4sQ0FBZSxFQUFmLENBQTVCOztBQUVBLFFBQU1ZLHFCQUFxQixHQUFJQyxLQUFELElBQVc7QUFDckNILGFBQVMsQ0FBQ0csS0FBSyxDQUFDQyxNQUFOLENBQWFoQixLQUFkLENBQVQ7QUFDSCxHQUZEOztBQUlBLFFBQU07QUFBQSxPQUFDaUIsVUFBRDtBQUFBLE9BQWFDO0FBQWIsTUFBOEJoQixzREFBUSxDQUFDLEtBQUQsQ0FBNUM7O0FBRUEsUUFBTWlCLHFCQUFxQixHQUFHLE1BQU07QUFDaENELGlCQUFhLENBQUMsSUFBRCxDQUFiO0FBQ0gsR0FGRDs7QUFJQSxRQUFNRSxXQUFXLEdBQUcsTUFBTTtBQUN0QkYsaUJBQWEsQ0FBQyxLQUFELENBQWI7QUFDSCxHQUZEOztBQUlBLFFBQU1HLFlBQVksR0FBSU4sS0FBRCxJQUFXO0FBQzVCZCxZQUFRLENBQUNjLEtBQUssQ0FBQ0MsTUFBTixDQUFhaEIsS0FBZCxDQUFSO0FBQ0gsR0FGRDs7QUFJQSxRQUFNc0Isb0JBQW9CLEdBQUlQLEtBQUQsSUFBVztBQUNwQ1gsY0FBVSxDQUFDVyxLQUFLLENBQUNDLE1BQU4sQ0FBYWIsT0FBZCxDQUFWO0FBQ0gsR0FGRDs7QUFJQSxRQUFNb0IscUJBQXFCLEdBQUlSLEtBQUQsSUFBVztBQUNyQ1AsWUFBUSxpQ0FBTUQsS0FBTjtBQUFhLE9BQUNRLEtBQUssQ0FBQ0MsTUFBTixDQUFhUSxJQUFkLEdBQXFCVCxLQUFLLENBQUNDLE1BQU4sQ0FBYWI7QUFBL0MsT0FBUjtBQUNILEdBRkQ7O0FBSUEsc0JBQ0kscUVBQUMscURBQUQ7QUFBSyxXQUFPLEVBQUMsaUJBQWI7QUFBK0IsTUFBRSxFQUFFLENBQW5DO0FBQXNDLE1BQUUsRUFBRSxDQUExQztBQUFBLDJCQUNJLHFFQUFDLHNEQUFEO0FBQU0sZUFBUyxNQUFmO0FBQWdCLGFBQU8sRUFBRSxDQUF6QjtBQUFBLDhCQUNJLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLEVBQWY7QUFBbUIsVUFBRSxFQUFFO0FBQXZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFJSSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLGdDQUNJLHFFQUFDLHVFQUFEO0FBQWEsZUFBSyxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFFSSxxRUFBQyx1RUFBRDtBQUFhLGVBQUssRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKSixlQVFJLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLEVBQWY7QUFBbUIsVUFBRSxFQUFFLEVBQXZCO0FBQUEsZ0NBQ0kscUVBQUMsdUVBQUQ7QUFBYSxlQUFLLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQUVJLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0kscUVBQUMsd0RBQUQ7QUFBUSxlQUFHLEVBQUMsTUFBWjtBQUFtQixlQUFHLEVBQUM7QUFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJKLGVBZUkscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyx1RUFBRDtBQUFhLGVBQUssRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBRUkscUVBQUMscURBQUQ7QUFBSyxpQkFBTyxFQUFDLE1BQWI7QUFBb0Isa0JBQVEsRUFBQyxNQUE3QjtBQUFBLGtDQUNJLHFFQUFDLHFEQUFEO0FBQUssY0FBRSxFQUFFLENBQVQ7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUNJLHFCQUFPLEVBQUMsTUFEWjtBQUVJLDRCQUFjLEVBQUMsZUFGbkI7QUFHSSx3QkFBVSxFQUFDLFlBSGY7QUFJSSxnQkFBRSxFQUFFLENBSlI7QUFBQSxzQ0FLSSxxRUFBQyx3REFBRDtBQUFRLG9CQUFJLEVBQUMsT0FBYjtBQUFxQixxQkFBSyxFQUFDLFNBQTNCO0FBQXFDLHVCQUFPLEVBQUMsV0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEosZUFRSSxxRUFBQyx3REFBRDtBQUFRLHFCQUFLLEVBQUMsU0FBZDtBQUF3Qix1QkFBTyxFQUFDLFdBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVJKLGVBV0kscUVBQUMsd0RBQUQ7QUFBUSxvQkFBSSxFQUFDLE9BQWI7QUFBcUIscUJBQUssRUFBQyxTQUEzQjtBQUFxQyx1QkFBTyxFQUFDLFdBQTdDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVhKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQWdCSSxxRUFBQyxxREFBRDtBQUNJLHFCQUFPLEVBQUMsTUFEWjtBQUVJLDRCQUFjLEVBQUMsZUFGbkI7QUFHSSx3QkFBVSxFQUFDLFlBSGY7QUFJSSxnQkFBRSxFQUFFLENBSlI7QUFBQSxzQ0FLSSxxRUFBQyx3REFBRDtBQUFRLG9CQUFJLEVBQUMsT0FBYjtBQUFxQixxQkFBSyxFQUFDLFdBQTNCO0FBQXVDLHVCQUFPLEVBQUMsV0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEosZUFRSSxxRUFBQyx3REFBRDtBQUFRLG9CQUFJLEVBQUMsUUFBYjtBQUFzQixxQkFBSyxFQUFDLFdBQTVCO0FBQXdDLHVCQUFPLEVBQUMsV0FBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUkosZUFXSSxxRUFBQyx3REFBRDtBQUFRLG9CQUFJLEVBQUMsT0FBYjtBQUFxQixxQkFBSyxFQUFDLFdBQTNCO0FBQXVDLHVCQUFPLEVBQUMsV0FBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWhCSixlQStCSSxxRUFBQyxxREFBRDtBQUNJLHFCQUFPLEVBQUMsTUFEWjtBQUVJLDRCQUFjLEVBQUMsZUFGbkI7QUFHSSx3QkFBVSxFQUFDLFlBSGY7QUFJSSxnQkFBRSxFQUFFLENBSlI7QUFBQSxzQ0FLSSxxRUFBQyx3REFBRDtBQUFRLG9CQUFJLEVBQUMsT0FBYjtBQUFxQixxQkFBSyxFQUFDLFNBQTNCO0FBQXFDLHVCQUFPLEVBQUMsV0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEosZUFRSSxxRUFBQyx3REFBRDtBQUFRLG9CQUFJLEVBQUMsUUFBYjtBQUFzQixxQkFBSyxFQUFDLFNBQTVCO0FBQXNDLHVCQUFPLEVBQUMsV0FBOUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUkosZUFXSSxxRUFBQyx3REFBRDtBQUFRLG9CQUFJLEVBQUMsT0FBYjtBQUFxQixxQkFBSyxFQUFDLFNBQTNCO0FBQXFDLHVCQUFPLEVBQUMsV0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQS9CSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosZUFnREkscUVBQUMscURBQUQ7QUFBSyxjQUFFLEVBQUUsQ0FBVDtBQUFBLG9DQUNJLHFFQUFDLHFEQUFEO0FBQUssZ0JBQUUsRUFBRSxDQUFUO0FBQUEscUNBQ0kscUVBQUMsd0RBQUQ7QUFDSSx5QkFBUyxNQURiO0FBRUksb0JBQUksRUFBQyxPQUZUO0FBR0kscUJBQUssRUFBQyxTQUhWO0FBSUkseUJBQVMsRUFBQyxZQUpkO0FBS0ksdUJBQU8sRUFBQyxXQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFESixlQVdJLHFFQUFDLHFEQUFEO0FBQUssZ0JBQUUsRUFBRSxDQUFUO0FBQUEscUNBQ0kscUVBQUMsd0RBQUQ7QUFDSSx5QkFBUyxNQURiO0FBRUksb0JBQUksRUFBQyxPQUZUO0FBR0kscUJBQUssRUFBQyxXQUhWO0FBSUkseUJBQVMsRUFBQyxZQUpkO0FBS0ksdUJBQU8sRUFBQyxXQUxaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFYSixlQXFCSSxxRUFBQyxxREFBRDtBQUFLLGdCQUFFLEVBQUUsQ0FBVDtBQUFBLHFDQUNJLHFFQUFDLHdEQUFEO0FBQVEsb0JBQUksRUFBQyxPQUFiO0FBQXFCLHlCQUFTLEVBQUMsWUFBL0I7QUFBNEMsdUJBQU8sRUFBQyxXQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBckJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFoREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFmSixlQStGSSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLGdDQUNJLHFFQUFDLHVFQUFEO0FBQWEsZUFBSyxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFFSSxxRUFBQyxxREFBRDtBQUFLLGlCQUFPLEVBQUMsTUFBYjtBQUFvQix3QkFBYyxFQUFDLGVBQW5DO0FBQUEsb0JBQ0ssQ0FBQyxTQUFELEVBQVksU0FBWixFQUF1QixRQUF2QixFQUFpQyxTQUFqQyxFQUE0QyxVQUE1QyxFQUF3RHNCLEdBQXhELENBQ0csQ0FBQ0MsSUFBRCxFQUFPQyxLQUFQLEtBQWlCO0FBQ2IsZ0NBQU8scUVBQUMsc0VBQUQ7QUFBWSxvQkFBTSxFQUFFRDtBQUFwQixlQUErQkMsS0FBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBUDtBQUNILFdBSEo7QUFETDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkEvRkosZUF5R0kscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyx1RUFBRDtBQUFhLGVBQUssRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBTUkscUVBQUMsdUVBQUQ7QUFBYSxlQUFLLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFOSixlQU9JLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0kscUVBQUMsbUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXpHSixlQXFISSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQUssZUFBSyxFQUFDLFdBQVg7QUFBdUIsb0JBQVUsRUFBQyxpQkFBbEM7QUFBb0QsWUFBRSxFQUFFLENBQXhEO0FBQUEsaUNBQ0kscUVBQUMsNERBQUQ7QUFBWSxtQkFBTyxFQUFDLElBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQUlJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLEdBQVQ7QUFBQSxpQ0FDSSxxRUFBQyw2REFBRDtBQUFBLG1DQUNJLHFFQUFDLDJEQUFEO0FBQ0ksZ0JBQUUsRUFBQyxnQkFEUDtBQUVJLG1CQUFLLEVBQUMsVUFGVjtBQUdJLHFCQUFPLEVBQUMsUUFIWjtBQUlJLG1CQUFLLE1BSlQ7QUFLSSx3QkFBVSxlQUNOLHFFQUFDLDRFQUFEO0FBQWtCLHFCQUFLLEVBQUMsb0NBQXhCO0FBQUEsdUNBQ0kscUVBQUMsMkRBQUQ7QUFBZSxzQkFBSSxFQUFFO0FBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpKLGVBbUJJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLEdBQVQ7QUFBQSxpQ0FDSSxxRUFBQyw2REFBRDtBQUFhLHFCQUFTLE1BQXRCO0FBQUEsbUNBQ0kscUVBQUMsMkRBQUQ7QUFDSSxxQkFBTyxFQUFDLFFBRFo7QUFFSSxtQkFBSyxFQUFDLG1CQUZWO0FBR0ksbUJBQUssRUFBQyxNQUhWO0FBSUksd0JBQVUsRUFBRTtBQUNSQyw0QkFBWSxlQUNSLHFFQUFDLGdFQUFEO0FBQUEseUNBQ0kscUVBQUMsNERBQUQ7QUFBWSw2QkFBUyxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkk7QUFKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQW5CSixlQW1DSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxHQUFUO0FBQUEsaUNBQ0kscUVBQUMsNkRBQUQ7QUFBYSxtQkFBTyxFQUFDLFFBQXJCO0FBQThCLHFCQUFTLE1BQXZDO0FBQUEsbUNBQ0kscUVBQUMsd0RBQUQ7QUFDSSxxQkFBTyxFQUFDLDBCQURaO0FBRUksZ0JBQUUsRUFBQyxvQkFGUDtBQUdJLG1CQUFLLEVBQUVqQixNQUhYO0FBSUksc0JBQVEsRUFBRUcscUJBSmQ7QUFBQSxzQ0FLSSxxRUFBQywwREFBRDtBQUFVLHFCQUFLLEVBQUUsRUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTEosZUFNSSxxRUFBQywwREFBRDtBQUFVLHFCQUFLLEVBQUUsRUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBTkosZUFPSSxxRUFBQywwREFBRDtBQUFVLHFCQUFLLEVBQUUsRUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBbkNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFySEosZUF1S0kscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyx1RUFBRDtBQUFhLGVBQUssRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBRUkscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsSUFBVDtBQUFBLGlDQUNJLHFFQUFDLHNFQUFEO0FBQWEsbUJBQU8sRUFBQyxjQUFyQjtBQUFvQyxpQkFBSyxFQUFDLGNBQTFDO0FBQXlELHNCQUFVLEVBQUUsR0FBckU7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHNCQUFRLEVBQUMsYUFBZDtBQUE0Qix3QkFBVSxFQUFDLG1CQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKLGVBU0kscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsSUFBVDtBQUFBLGlDQUNJLHFFQUFDLHNFQUFEO0FBQWEsbUJBQU8sRUFBQyxZQUFyQjtBQUFrQyxpQkFBSyxFQUFDLGNBQXhDO0FBQXVELHNCQUFVLEVBQUUsR0FBbkU7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHNCQUFRLEVBQUMsYUFBZDtBQUE0Qix3QkFBVSxFQUFDLG1CQUF2QztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVRKLGVBZ0JJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLElBQVQ7QUFBQSxpQ0FDSSxxRUFBQyxzRUFBRDtBQUNJLG1CQUFPLEVBQUMsY0FEWjtBQUVJLGlCQUFLLEVBQUMsa0JBRlY7QUFHSSxzQkFBVSxFQUFFLEdBSGhCO0FBQUEsbUNBSUkscUVBQUMscURBQUQ7QUFBSyxzQkFBUSxFQUFDLGFBQWQ7QUFBNEIsd0JBQVUsRUFBQyxtQkFBdkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFoQko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZLSixlQWtNSSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLGdDQUNJLHFFQUFDLHVFQUFEO0FBQWEsZUFBSyxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFFSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxJQUFUO0FBQUEsaUNBQ0kscUVBQUMsdUVBQUQ7QUFBYSxtQkFBTyxFQUFDLFNBQXJCO0FBQStCLHlCQUFhLEVBQUUsSUFBOUM7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsY0FEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsbUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFPSSxxRUFBQyxxREFBRDtBQUNJLHVCQUFTLEVBQUMsT0FEZDtBQUVJLG1CQUFLLEVBQUMsZUFGVjtBQUdJLHNCQUFRLEVBQUMsYUFIYjtBQUlJLHdCQUFVLEVBQUMsb0JBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGSixlQW9CSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxJQUFUO0FBQUEsaUNBQ0kscUVBQUMsdUVBQUQ7QUFBYSxtQkFBTyxFQUFDLFNBQXJCO0FBQStCLHlCQUFhLEVBQUUsSUFBOUM7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsY0FEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsbUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFPSSxxRUFBQyxxREFBRDtBQUNJLHVCQUFTLEVBQUMsT0FEZDtBQUVJLG1CQUFLLEVBQUMsZUFGVjtBQUdJLHNCQUFRLEVBQUMsYUFIYjtBQUlJLHdCQUFVLEVBQUMsb0JBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFwQkosZUFzQ0kscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsSUFBVDtBQUFBLGlDQUNJLHFFQUFDLHVFQUFEO0FBQWEsbUJBQU8sRUFBQyxRQUFyQjtBQUE4QixxQkFBUyxFQUFFLElBQXpDO0FBQStDLHlCQUFhLEVBQUUsSUFBOUQ7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsY0FEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsbUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFPSSxxRUFBQyxxREFBRDtBQUNJLHVCQUFTLEVBQUMsT0FEZDtBQUVJLG1CQUFLLEVBQUMsZUFGVjtBQUdJLHNCQUFRLEVBQUMsYUFIYjtBQUlJLHdCQUFVLEVBQUMsb0JBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF0Q0osZUF3REkscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsSUFBVDtBQUFBLGlDQUNJLHFFQUFDLHVFQUFEO0FBQWEsbUJBQU8sRUFBQyxTQUFyQjtBQUErQixxQkFBUyxFQUFFLElBQTFDO0FBQWdELDBCQUFjLEVBQUUsS0FBaEU7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsY0FEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsbUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFPSSxxRUFBQyxxREFBRDtBQUNJLHVCQUFTLEVBQUMsT0FEZDtBQUVJLG1CQUFLLEVBQUMsZUFGVjtBQUdJLHNCQUFRLEVBQUMsYUFIYjtBQUlJLHdCQUFVLEVBQUMsb0JBSmY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF4REo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWxNSixlQTZRSSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLGdDQUNJLHFFQUFDLHVFQUFEO0FBQWEsZUFBSyxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFHSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxJQUFUO0FBQUEsaUNBQ0kscUVBQUMsc0VBQUQ7QUFBQSxvQ0FDSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsY0FEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsbUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREosZUFPSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsZUFEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsb0JBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFISixlQTRCSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxJQUFUO0FBQUEsaUNBQ0kscUVBQUMsc0VBQUQ7QUFBWSxvQkFBUSxFQUFDLFlBQXJCO0FBQWtDLG9CQUFRLEVBQUMsTUFBM0M7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUNJLG1CQUFLLEVBQUMsY0FEVjtBQUVJLHNCQUFRLEVBQUMsYUFGYjtBQUdJLHdCQUFVLEVBQUMsbUJBSGY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkE1QkosZUF1Q0kscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsSUFBVDtBQUFBLGlDQUNJLHFFQUFDLHNEQUFEO0FBQUEsbUNBQ0kscUVBQUMscURBQUQ7QUFBSyxxQkFBTyxFQUFDLE1BQWI7QUFBb0Isd0JBQVUsRUFBQyxZQUEvQjtBQUE0QyxlQUFDLEVBQUUsR0FBL0M7QUFBb0QsdUJBQVMsRUFBRSxFQUEvRDtBQUFBLHNDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksdUJBQU8sRUFBQyxNQURaO0FBRUksOEJBQWMsRUFBQyxVQUZuQjtBQUdJLHdCQUFRLEVBQUUsRUFIZDtBQUlJLG9CQUFJLEVBQUMsVUFKVDtBQUtJLGtCQUFFLEVBQUUsSUFMUjtBQUFBLHVDQU1JLHFFQUFDLDBEQUFEO0FBQVUseUJBQU8sRUFBRVgsT0FBbkI7QUFBNEIsMEJBQVEsRUFBRWtCO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFOSjtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURKLGVBU0kscUVBQUMscURBQUQ7QUFDSSxrQkFBRSxFQUFFLEdBRFI7QUFFSSx3QkFBUSxFQUFFLENBRmQ7QUFHSSx1QkFBTyxFQUFDLE1BSFo7QUFJSSw2QkFBYSxFQUFDLFFBSmxCO0FBS0ksOEJBQWMsRUFBQyxRQUxuQjtBQUFBLHdDQU1JLHFFQUFDLHFEQUFEO0FBQ0ksdUJBQUssRUFBQyxjQURWO0FBRUksMEJBQVEsRUFBQyxhQUZiO0FBR0ksNEJBQVUsRUFBQyxtQkFIZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFOSixlQVlJLHFFQUFDLHFEQUFEO0FBQ0ksdUJBQUssRUFBQyxlQURWO0FBRUksMEJBQVEsRUFBQyxhQUZiO0FBR0ksNEJBQVUsRUFBQyxvQkFIZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFaSixFQW1CS2hCLFdBQVcsaUJBQ1IscUVBQUMscURBQUQ7QUFDSSx1QkFBSyxFQUFDLGtCQURWO0FBRUksMEJBQVEsRUFBQyxhQUZiO0FBR0ksNEJBQVUsRUFBQyxvQkFIZjtBQUlJLG9CQUFFLEVBQUUsQ0FKUjtBQUtJLG9CQUFFLEVBQUUsQ0FMUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFwQlIsZUFnQ0kscUVBQUMscURBQUQ7QUFDSSx1QkFBSyxFQUFDLGNBRFY7QUFFSSwwQkFBUSxFQUFDLGFBRmI7QUFHSSw0QkFBVSxFQUFDLG9CQUhmO0FBQUEseUNBSUkscUVBQUMsc0RBQUQ7QUFDSSw2QkFBUyxFQUFDLFFBRGQ7QUFFSSx5QkFBSyxFQUFDLFNBRlY7QUFHSSw2QkFBUyxFQUFDLE1BSGQ7QUFJSSwyQkFBTyxFQUFFLE1BQU1DLGNBQWMsQ0FBQyxDQUFDRCxXQUFGLENBSmpDO0FBQUEsOEJBS0ssQ0FBQ0EsV0FBRCxHQUFlLGVBQWYsR0FBaUM7QUFMdEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFUSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF2Q0o7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTdRSixlQWdYSSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLGdDQUNJLHFFQUFDLHVFQUFEO0FBQWEsZUFBSyxFQUFDO0FBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFFSSxxRUFBQyx1RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoWEosZUFvWEkscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUFLLGVBQUssRUFBQyxlQUFYO0FBQTJCLG9CQUFVLEVBQUMsaUJBQXRDO0FBQXdELFlBQUUsRUFBRSxDQUE1RDtBQUFBLGlDQUNJLHFFQUFDLDREQUFEO0FBQVksbUJBQU8sRUFBQyxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFJSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxHQUFUO0FBQUEsaUNBRUkscUVBQUMsNkRBQUQ7QUFBYSxxQkFBUyxFQUFDLFVBQXZCO0FBQUEsb0NBQ0kscUVBQUMsMkRBQUQ7QUFBVyx1QkFBUyxFQUFDLFFBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBRUkscUVBQUMsNERBQUQ7QUFDSSw0QkFBVyxRQURmO0FBRUksa0JBQUksRUFBQyxTQUZUO0FBR0ksbUJBQUssRUFBRUwsS0FIWDtBQUlJLHNCQUFRLEVBQUVxQixZQUpkO0FBQUEsc0NBS0kscUVBQUMsa0VBQUQ7QUFDSSxxQkFBSyxFQUFDLFFBRFY7QUFFSSx1QkFBTyxlQUFFLHFFQUFDLHVEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRmI7QUFHSSxxQkFBSyxFQUFDO0FBSFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFMSixlQVVJLHFFQUFDLGtFQUFEO0FBQWtCLHFCQUFLLEVBQUMsTUFBeEI7QUFBK0IsdUJBQU8sZUFBRSxxRUFBQyx1REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUF4QztBQUFtRCxxQkFBSyxFQUFDO0FBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBVkosZUFXSSxxRUFBQyxrRUFBRDtBQUFrQixxQkFBSyxFQUFDLE9BQXhCO0FBQWdDLHVCQUFPLGVBQUUscUVBQUMsdURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFBekM7QUFBb0QscUJBQUssRUFBQztBQUExRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQVhKLGVBWUkscUVBQUMsa0VBQUQ7QUFDSSxxQkFBSyxFQUFDLFVBRFY7QUFFSSx3QkFBUSxNQUZaO0FBR0ksdUJBQU8sZUFBRSxxRUFBQyx1REFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUhiO0FBSUkscUJBQUssRUFBQztBQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBWko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkosZUE2QkkscUVBQUMscURBQUQ7QUFBSyxlQUFLLEVBQUMsZUFBWDtBQUEyQixvQkFBVSxFQUFDLGlCQUF0QztBQUF3RCxZQUFFLEVBQUUsQ0FBNUQ7QUFBQSxpQ0FDSSxxRUFBQyw0REFBRDtBQUFZLG1CQUFPLEVBQUMsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQTdCSixlQWdDSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxHQUFUO0FBQUEsaUNBQ0kscUVBQUMsMERBQUQ7QUFDSSxtQkFBTyxFQUFFbEIsT0FEYjtBQUVJLG9CQUFRLEVBQUVtQixvQkFGZDtBQUdJLHNCQUFVLEVBQUU7QUFBRSw0QkFBYztBQUFoQjtBQUhoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFoQ0osZUF1Q0kscUVBQUMscURBQUQ7QUFBSyxlQUFLLEVBQUMsZUFBWDtBQUEyQixvQkFBVSxFQUFDLGlCQUF0QztBQUF3RCxZQUFFLEVBQUUsQ0FBNUQ7QUFBQSxpQ0FDSSxxRUFBQyw0REFBRDtBQUFZLG1CQUFPLEVBQUMsSUFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXZDSixlQTBDSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxHQUFUO0FBQUEsaUNBQ0kscUVBQUMsd0RBQUQ7QUFDSSxtQkFBTyxFQUFFZixLQUFLLENBQUNHLFFBRG5CO0FBRUksb0JBQVEsRUFBRWEscUJBRmQ7QUFHSSxnQkFBSSxFQUFDLFVBSFQ7QUFJSSxzQkFBVSxFQUFFO0FBQUUsNEJBQWM7QUFBaEI7QUFKaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBMUNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFwWEosZUF1YUkscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUFLLGVBQUssRUFBQyxXQUFYO0FBQXVCLG9CQUFVLEVBQUMsaUJBQWxDO0FBQW9ELFlBQUUsRUFBRSxDQUF4RDtBQUFBLGlDQUNJLHFFQUFDLDREQUFEO0FBQVksbUJBQU8sRUFBQyxJQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFJSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxDQUFUO0FBQUEsaUNBQ0kscUVBQUMsZ0VBQUQ7QUFBTyxpQkFBSyxFQUFDLFVBQWI7QUFBd0IsaUJBQUssRUFBQztBQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKSixlQU9JLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBQSxpQ0FDSSxxRUFBQyxnRUFBRDtBQUFPLGlCQUFLLEVBQUMsWUFBYjtBQUEwQixpQkFBSyxFQUFDLFdBQWhDO0FBQTRDLG9CQUFRLEVBQUUxQjtBQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdmFKLGVBbWJJLHFFQUFDLHNEQUFEO0FBQU0sWUFBSSxNQUFWO0FBQVcsVUFBRSxFQUFFLEVBQWY7QUFBbUIsVUFBRSxFQUFFLEVBQXZCO0FBQUEsZ0NBQ0kscUVBQUMsdUVBQUQ7QUFBYSxlQUFLLEVBQUM7QUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQUVJLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLENBQVQ7QUFBQSxpQ0FDSSxxRUFBQyxzREFBRDtBQUFBLG1DQUNJLHFFQUFDLHFEQUFEO0FBQUssdUJBQVMsRUFBRSxFQUFoQjtBQUFvQixtQkFBSyxFQUFDO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGSixlQU9JLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0kscUVBQUMsc0RBQUQ7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHVCQUFTLEVBQUUsR0FBaEI7QUFBcUIsbUJBQUssRUFBQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5iSixlQWdjSSxxRUFBQyxzREFBRDtBQUFNLFlBQUksTUFBVjtBQUFXLFVBQUUsRUFBRSxFQUFmO0FBQW1CLFVBQUUsRUFBRSxFQUF2QjtBQUFBLCtCQUNJLHFFQUFDLHFEQUFEO0FBQ0ksa0JBQVEsRUFBQyxjQURiO0FBRUksb0JBQVUsRUFBQyxpQkFGZjtBQUdJLGlCQUFPLEVBQUMsY0FIWjtBQUlJLGVBQUssRUFBQyxPQUpWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoY0osZUF5Y0kscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUFLLFlBQUUsRUFBRSxDQUFUO0FBQUEsaUNBQ0kscUVBQUMsMkVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREosZUFJSSxxRUFBQyw0RUFBRDtBQUFXLGtCQUFRLEVBQUU7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKSixlQUtJLHFFQUFDLDJFQUFEO0FBQVksb0JBQVUsRUFBRTtBQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUxKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF6Y0osZUFpZEkscUVBQUMsc0RBQUQ7QUFBTSxZQUFJLE1BQVY7QUFBVyxVQUFFLEVBQUUsRUFBZjtBQUFtQixVQUFFLEVBQUUsRUFBdkI7QUFBQSxnQ0FDSSxxRUFBQyx1RUFBRDtBQUFhLGVBQUssRUFBQztBQUFuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBRUkscUVBQUMscURBQUQ7QUFBQSxrQ0FDSSxxRUFBQyx3REFBRDtBQUFRLG1CQUFPLEVBQUMsVUFBaEI7QUFBMkIsaUJBQUssRUFBQyxTQUFqQztBQUEyQyxtQkFBTyxFQUFFc0IscUJBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBS0kscUVBQUMsd0RBQUQ7QUFDSSxtQkFBTyxFQUFFQyxXQURiO0FBRUksK0JBQWdCLHFCQUZwQjtBQUdJLGdCQUFJLEVBQUVILFVBSFY7QUFBQSxvQ0FJSSxxRUFBQyw2REFBRDtBQUFhLGdCQUFFLEVBQUMscUJBQWhCO0FBQUEscUNBQ0kscUVBQUMsNERBQUQ7QUFBWSw4QkFBVyxPQUF2QjtBQUErQix1QkFBTyxFQUFFRyxXQUF4QztBQUFBLHVDQUNJLHFFQUFDLCtEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKSixlQVNJLHFFQUFDLCtEQUFEO0FBQUEsc0NBQ0kscUVBQUMscURBQUQ7QUFBSyx5QkFBUyxFQUFDLFFBQWY7QUFBd0Isa0JBQUUsRUFBRSxHQUE1QjtBQUFBLHdDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksMEJBQVEsRUFBQyxhQURiO0FBRUksNEJBQVUsRUFBQyxpQkFGZjtBQUdJLHVCQUFLLEVBQUMsZUFIVjtBQUlJLG9CQUFFLEVBQUUsQ0FKUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFESixlQVFJLHFFQUFDLHFEQUFEO0FBQ0ksMEJBQVEsRUFBQyxhQURiO0FBRUksMkJBQVMsRUFBQyxRQUZkO0FBR0ksdUJBQUssRUFBQyxvQkFIVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFSSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREosZUFnQkkscUVBQUMscURBQUQ7QUFBQSx1Q0FDSSxxRUFBQyxxREFBRDtBQUFLLDBCQUFRLEVBQUUsR0FBZjtBQUFvQixvQkFBRSxFQUFDLE1BQXZCO0FBQThCLG9CQUFFLEVBQUUsQ0FBbEM7QUFBQSx5Q0FDSSxxRUFBQyw2REFBRDtBQUFhLDJCQUFPLEVBQUMsUUFBckI7QUFBOEIsNkJBQVMsTUFBdkM7QUFBQSwyQ0FDSSxxRUFBQyx3REFBRDtBQUNJLDZCQUFPLEVBQUMsMEJBRFo7QUFFSSx3QkFBRSxFQUFDLG9CQUZQO0FBR0ksbUNBQWEsRUFBRVMsNEVBSG5CO0FBSUksMkJBQUssRUFBRWxCLE1BSlg7QUFLSSw4QkFBUSxFQUFFRyxxQkFMZDtBQUFBLDhDQU1JLHFFQUFDLDBEQUFEO0FBQVUsNkJBQUssRUFBRSxDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FOSixlQU9JLHFFQUFDLDBEQUFEO0FBQVUsNkJBQUssRUFBRSxDQUFqQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQ0FQSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBaEJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFUSixlQXlDSSxxRUFBQyxxREFBRDtBQUFBLHFDQUNJLHFFQUFDLHdEQUFEO0FBQ0kseUJBQVMsTUFEYjtBQUVJLG9CQUFJLEVBQUMsT0FGVDtBQUdJLHFCQUFLLEVBQUMsV0FIVjtBQUlJLHlCQUFTLEVBQUMsWUFKZDtBQUtJLHVCQUFPLEVBQUMsV0FMWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBekNKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpkSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFtaEJILENBMWpCRDs7QUEyakJlZixvRkFBZixFOzs7Ozs7Ozs7Ozs7QUNobkJBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUdBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLFNBQVMrQixvQkFBVCxHQUFnQztBQUM1QixzQkFDSTtBQUFBLDJCQUNJLHFFQUFDLHNFQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESixtQkFESjtBQUtIOztBQUVjQSxtRkFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNQyxNQUFNLEdBQUcsQ0FBQztBQUFFQyxTQUFGO0FBQVdDLFdBQVg7QUFBc0JDLFVBQXRCO0FBQWdDQztBQUFoQyxDQUFELEtBQW9EO0FBQy9ELFFBQU1DLE9BQU8sR0FBR0MsNkRBQVMsRUFBekI7QUFDQSxzQkFDSTtBQUFBLDJCQUNJLHFFQUFDLHNEQUFEO0FBQU0sZUFBUyxFQUFFRCxPQUFPLENBQUNKLE9BQUQsQ0FBeEI7QUFBQSw2QkFDSSxxRUFBQyxzREFBRDtBQUNJLGNBQU0sRUFDRkcsWUFBWSxpQkFDUixxRUFBQyw0REFBRDtBQUFBLGlDQUNJLHFFQUFDLCtDQUFEO0FBQUcsdUJBQVcsRUFBQyxHQUFmO0FBQW1CLGlCQUFLLEVBQUVGO0FBQTFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUhaO0FBQUEsa0JBUUVDLFFBQVEsSUFBSUE7QUFSZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLG1CQURKO0FBZ0JILENBbEJEOztBQW9CQUgsTUFBTSxDQUFDTyxZQUFQLEdBQXFCO0FBQ2pCSCxjQUFZLEVBQUU7QUFERyxDQUFyQjtBQUlBSixNQUFNLENBQUNRLFNBQVAsR0FBbUI7QUFDZlAsU0FBTyxFQUFFUSxpREFBUyxDQUFDQyxLQUFWLENBQWdCLENBQUMsY0FBRCxFQUFpQixnQkFBakIsQ0FBaEIsQ0FETTtBQUVmUixXQUFTLEVBQUVPLGlEQUFTLENBQUNDLEtBQVYsQ0FBZ0IsQ0FBQyxPQUFELEVBQVUsUUFBVixDQUFoQixDQUZJO0FBR2ZQLFVBQVEsRUFBRU0saURBQVMsQ0FBQ0UsSUFITDtBQUlmUCxjQUFZLEVBQUVLLGlEQUFTLENBQUNHO0FBSlQsQ0FBbkI7QUFNZVoscUVBQWYsRTs7Ozs7Ozs7Ozs7O0FDMUNBO0FBQUE7QUFBQTtBQUFBO0FBQ0EsTUFBTU0sU0FBUyxHQUFHTyxvRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckNDLGNBQVksRUFBQztBQUNUQyxtQkFBZSxFQUFDRixLQUFLLENBQUNHLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQkMsSUFEN0I7QUFFVEMsU0FBSyxFQUFDTixLQUFLLENBQUNPLE1BQU4sQ0FBYUMsS0FGVjtBQUdUQyxhQUFTLEVBQUMsTUFIRDtBQUlUQyxnQkFBWSxFQUFDO0FBSkosR0FEd0I7QUFPckNDLGdCQUFjLEVBQUM7QUFDWFQsbUJBQWUsRUFBQ0YsS0FBSyxDQUFDRyxPQUFOLENBQWNTLEtBQWQsQ0FBb0JDLGNBRHpCO0FBRVhQLFNBQUssRUFBQ04sS0FBSyxDQUFDRyxPQUFOLENBQWNDLE9BQWQsQ0FBc0JVLEtBRmpCO0FBR1hMLGFBQVMsRUFBQyxNQUhDO0FBSVhDLGdCQUFZLEVBQUM7QUFKRjtBQVBzQixDQUFaLENBQUQsQ0FBNUI7QUFjZWxCLHdFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTXVCLFdBQVcsR0FBRyxDQUFDO0FBQUVDLFNBQUY7QUFBV1YsT0FBWDtBQUFrQmpCLFVBQWxCO0FBQTRCNEI7QUFBNUIsQ0FBRCxLQUE4QztBQUM5RCxzQkFDSTtBQUFBLDJCQUNJLHFFQUFDLHFEQUFEO0FBQUssYUFBTyxFQUFFRCxPQUFkO0FBQXVCLFdBQUssRUFBRVYsS0FBOUI7QUFBcUMsYUFBTyxFQUFFLEdBQTlDO0FBQW1ELGVBQVMsRUFBRVcsVUFBOUQ7QUFBQSxnQkFDSzVCLFFBQVEsSUFBSUE7QUFEakI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLG1CQURKO0FBT0gsQ0FSRDs7QUFVQTBCLFdBQVcsQ0FBQ3JCLFNBQVosR0FBd0I7QUFDcEJzQixTQUFPLEVBQUVyQixpREFBUyxDQUFDdUIsTUFEQztBQUVwQlosT0FBSyxFQUFFWCxpREFBUyxDQUFDdUIsTUFGRztBQUdwQjdCLFVBQVEsRUFBRU0saURBQVMsQ0FBQ0UsSUFIQTtBQUlwQm9CLFlBQVUsRUFBRXRCLGlEQUFTLENBQUN3QjtBQUpGLENBQXhCO0FBT2VKLDBFQUFmLEU7Ozs7Ozs7Ozs7OztBQzlCQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1LLEtBQUssR0FBRyxDQUFDO0FBQUVDLE9BQUY7QUFBU2YsT0FBVDtBQUFnQmdCO0FBQWhCLENBQUQsS0FBZ0M7QUFDMUMsUUFBTS9CLE9BQU8sR0FBR0MsNERBQVMsRUFBekI7QUFDQSxzQkFDSSxxRUFBQyxxREFBRDtBQUFBLDJCQUNJLHFFQUFDLHNEQUFEO0FBQ0ksV0FBSyxFQUFFNkIsS0FEWDtBQUVJLFdBQUssRUFBRWYsS0FGWDtBQUdJLGNBQVEsRUFBRWdCLFFBSGQ7QUFJSSxlQUFTLEVBQUUvQixPQUFPLENBQUMzSCxJQUp2QjtBQUtJLGdCQUFVLGVBQUUscUVBQUMsdUVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUxoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBV0gsQ0FiRDs7QUFlQXdKLEtBQUssQ0FBQzFCLFNBQU4sR0FBa0I7QUFDZDJCLE9BQUssRUFBRTFCLGlEQUFTLENBQUN1QixNQURIO0FBRWRaLE9BQUssRUFBRVgsaURBQVMsQ0FBQ3VCLE1BRkg7QUFHZEksVUFBUSxFQUFFM0IsaURBQVMsQ0FBQzRCO0FBSE4sQ0FBbEI7QUFNZUgsb0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDbkNBO0FBQUE7QUFBQTtBQUFBO0FBRUEsTUFBTTVCLFNBQVMsR0FBR08sMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3JDcEksTUFBSSxFQUFFO0FBQ0Ysc0JBQWtCO0FBQ2Q0SixjQUFRLEVBQUV4QixLQUFLLENBQUN5QixVQUFOLENBQWlCRCxRQUFqQixDQUEwQkUsRUFEdEI7QUFFZEMsZ0JBQVUsRUFBRTNCLEtBQUssQ0FBQ3lCLFVBQU4sQ0FBaUJFLFVBQWpCLENBQTRCQyxTQUYxQjtBQUdkcEksWUFBTSxFQUFHLGFBQVl3RyxLQUFLLENBQUNHLE9BQU4sQ0FBY0MsT0FBZCxDQUFzQlUsS0FBTSxFQUhuQztBQUlkbkgsWUFBTSxFQUFFcUcsS0FBSyxDQUFDNkIsT0FBTixDQUFjLEdBQWQsQ0FKTTtBQUtkbkIsa0JBQVksRUFBRTtBQUxBO0FBRGhCO0FBRCtCLENBQVosQ0FBRCxDQUE1QjtBQVllbEIsd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDZEE7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTXNDLGFBQWEsR0FBRyxDQUFDO0FBQUVDLFdBQUY7QUFBYUM7QUFBYixDQUFELEtBQTRCO0FBQzlDLHNCQUNJO0FBQUEsNEJBQ0kscUVBQUMsNkRBQUQ7QUFBYSxRQUFFLEVBQUMscUJBQWhCO0FBQUEsNkJBQ0kscUVBQUMsNERBQUQ7QUFBWSxzQkFBVyxPQUF2QjtBQUErQixlQUFPLEVBQUVBLE9BQXhDO0FBQUEsK0JBQ0kscUVBQUMsK0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBTUkscUVBQUMsK0RBQUQ7QUFBQSw2QkFDSSxxRUFBQyxxREFBRDtBQUFLLGlCQUFTLEVBQUMsUUFBZjtBQUF3QixVQUFFLEVBQUUsR0FBNUI7QUFBQSxnQ0FDSSxxRUFBQyxxREFBRDtBQUNJLGtCQUFRLEVBQUMsYUFEYjtBQUVJLG9CQUFVLEVBQUMsaUJBRmY7QUFHSSxlQUFLLEVBQUMsZUFIVjtBQUlJLFlBQUUsRUFBRSxDQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBUUkscUVBQUMscURBQUQ7QUFBSyxrQkFBUSxFQUFDLGFBQWQ7QUFBNEIsZUFBSyxFQUFDLG9CQUFsQztBQUF1RCxZQUFFLEVBQUUsQ0FBM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFOSixlQW9CSSxxRUFBQyxxREFBRDtBQUFBLDhCQUNJLHFFQUFDLHdEQUFEO0FBQ0ksaUJBQVMsTUFEYjtBQUVJLFlBQUksRUFBQyxPQUZUO0FBR0ksYUFBSyxFQUFDLFdBSFY7QUFJSSxpQkFBUyxFQUFDLFlBSmQ7QUFLSSxlQUFPLEVBQUMsV0FMWjtBQU1JLGFBQUssRUFBRTtBQUNIdEIsc0JBQVksRUFBRTtBQURYLFNBTlg7QUFTSSxlQUFPLEVBQUVxQixTQVRiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBYUkscUVBQUMsd0RBQUQ7QUFDSSxpQkFBUyxNQURiO0FBRUksWUFBSSxFQUFDLE9BRlQ7QUFHSSxhQUFLLEVBQUMsU0FIVjtBQUlJLGlCQUFTLEVBQUMsWUFKZDtBQUtJLGVBQU8sRUFBQyxXQUxaO0FBTUksZUFBTyxFQUFFQyxPQU5iO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFwQko7QUFBQSxrQkFESjtBQThDSCxDQS9DRDs7QUFnREFGLGFBQWEsQ0FBQ3BDLFNBQWQsR0FBMEI7QUFDdEJxQyxXQUFTLEVBQUVwQyxpREFBUyxDQUFDNEIsSUFEQztBQUV0QlMsU0FBTyxFQUFFckMsaURBQVMsQ0FBQzRCO0FBRkcsQ0FBMUI7QUFJZU8sNEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDOURBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1HLGdCQUFnQixHQUFHLENBQUM7QUFBRUMsT0FBRjtBQUFTN0M7QUFBVCxDQUFELEtBQXlCO0FBQzlDLHNCQUNJLHFFQUFDLHFEQUFEO0FBQUssV0FBTyxFQUFDLE1BQWI7QUFBb0IsTUFBRSxFQUFFLENBQUMsSUFBekI7QUFBK0IsTUFBRSxFQUFFLEdBQW5DO0FBQUEsNEJBQ0kscUVBQUMscURBQUQ7QUFDSSxhQUFPLEVBQUMsTUFEWjtBQUVJLFVBQUksRUFBQyxVQUZUO0FBR0ksYUFBTyxFQUFDLFlBSFo7QUFJSSxvQkFBYyxFQUFDLFFBSm5CO0FBS0ksZ0JBQVUsRUFBQyxRQUxmO0FBTUksV0FBSyxFQUFFLEVBTlg7QUFPSSxZQUFNLEVBQUUsRUFQWjtBQVFJLGtCQUFZLEVBQUMsS0FSakI7QUFTSSxXQUFLLEVBQUMsY0FUVjtBQVVJLFFBQUUsRUFBRSxHQVZSO0FBQUEsOEJBV0kscUVBQUMsMkRBQUQ7QUFBZSxZQUFJLEVBQUU7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFYSixFQVlLQSxRQUFRLElBQUlBLFFBWmpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQWVJLHFFQUFDLHFEQUFEO0FBQUssY0FBUSxFQUFDLGFBQWQ7QUFBNEIsZ0JBQVUsRUFBQyxHQUF2QztBQUEyQyxXQUFLLEVBQUMsWUFBakQ7QUFBOEQsUUFBRSxFQUFFLElBQWxFO0FBQUEsZ0JBQ0s2QztBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFxQkgsQ0F0QkQ7O0FBd0JBRCxnQkFBZ0IsQ0FBQ3ZDLFNBQWpCLEdBQTZCO0FBQ3pCd0MsT0FBSyxFQUFFdkMsaURBQVMsQ0FBQ3VCLE1BRFE7QUFFekI3QixVQUFRLEVBQUVNLGlEQUFTLENBQUNFO0FBRkssQ0FBN0I7QUFLZW9DLCtFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3pDQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNRSxVQUFVLEdBQUcsQ0FBQztBQUNoQkMsWUFEZ0I7QUFFaEJDLFVBRmdCO0FBR2hCQyxnQkFIZ0I7QUFJaEJDLGFBSmdCO0FBS2hCQyxhQUxnQjtBQU1oQk4sT0FOZ0I7QUFPaEJPLFdBUGdCO0FBUWhCQztBQVJnQixDQUFELEtBU2I7QUFDRixRQUFNO0FBQUEsT0FBQ0MsUUFBRDtBQUFBLE9BQVdDO0FBQVgsTUFBMEJ2RixzREFBUSxDQUFDLEtBQUQsQ0FBeEM7O0FBQ0EsUUFBTXdGLFdBQVcsR0FBRyxNQUFNO0FBQ3RCRCxlQUFXLENBQUMsSUFBRCxDQUFYO0FBQ0gsR0FGRDs7QUFHQSxRQUFNckQsT0FBTyxHQUFHQyxrRUFBUyxFQUF6QjtBQUNBLFFBQU1zRCxVQUFVLEdBQUdDLHNFQUFhLENBQUMsb0JBQUQsQ0FBaEM7QUFDQSxRQUFNekMsS0FBSyxHQUFHOEIsVUFBVSxHQUFHLGNBQUgsR0FBb0IsZUFBNUM7QUFDQSxRQUFNWSxXQUFXLEdBQUdaLFVBQVUsR0FBRyxXQUFILEdBQWlCLFNBQS9DO0FBQ0EsUUFBTWEsV0FBVyxHQUFHYixVQUFVLEdBQUcsYUFBSCxHQUFtQixRQUFqRDtBQUNBLFFBQU1jLGFBQWEsR0FBRyxDQUNsQjtBQUNJQyxZQUFRLEVBQUU7QUFEZCxHQURrQixFQUlsQjtBQUNJQSxZQUFRLEVBQUU7QUFEZCxHQUprQixFQU9sQjtBQUNJQSxZQUFRLEVBQUU7QUFEZCxHQVBrQixDQUF0Qjs7QUFZQSxRQUFNQyxlQUFlLEdBQUcsTUFBTTtBQUMxQixVQUFNO0FBQUVDO0FBQUYsUUFBaUJDLHlFQUF2QjtBQUNBQyxzREFBTSxDQUFDQyxJQUFQLENBQVlILFVBQVUsQ0FBQ0ksS0FBdkI7QUFDSCxHQUhEOztBQUtBLHNCQUNJLHFFQUFDLHFEQUFEO0FBQ0ksV0FBTyxFQUFFLENBRGI7QUFFSSxXQUFPLEVBQUMsY0FGWjtBQUdJLGFBQVMsRUFBRSxDQUhmO0FBSUksYUFBUyxFQUFFQywyQ0FBSSxDQUFDdEIsVUFBVSxJQUFJN0MsT0FBTyxDQUFDb0UsaUJBQXZCLENBSm5CO0FBQUEsNEJBS0kscUVBQUMscURBQUQ7QUFDSSxhQUFPLEVBQUMsTUFEWjtBQUVJLGdCQUFVLEVBQUMsUUFGZjtBQUdJLG9CQUFjLEVBQUMsZUFIbkI7QUFJSSxlQUFTLEVBQUVwQixXQUFXLElBQUlHLGNBQWYsR0FBZ0NuRCxPQUFPLENBQUNxRSxhQUF4QyxHQUF3RCxFQUp2RTtBQUFBLDhCQUtJLHFFQUFDLHFEQUFEO0FBQUssZUFBTyxFQUFDLE1BQWI7QUFBb0Isa0JBQVUsRUFBQyxRQUEvQjtBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQUssaUJBQU8sRUFBQyxNQUFiO0FBQW9CLG9CQUFVLEVBQUMsUUFBL0I7QUFBd0MsWUFBRSxFQUFFZCxVQUFVLEdBQUcsQ0FBSCxHQUFPLENBQTdEO0FBQUEsa0NBQ0kscUVBQUMscURBQUQ7QUFBSyxtQkFBTyxFQUFDLE1BQWI7QUFBb0IscUJBQVMsRUFBRXZELE9BQU8sQ0FBQ3NFLFNBQXZDO0FBQUEsbUNBQ0kscUVBQUMsaURBQUQ7QUFBTyxpQkFBRyxFQUFDLFdBQVg7QUFBdUIsbUJBQUssRUFBRSxFQUE5QjtBQUFrQyxvQkFBTSxFQUFFO0FBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURKLGVBSUkscUVBQUMscURBQUQ7QUFBSyxtQkFBTyxFQUFFZixVQUFVLEdBQUcsTUFBSCxHQUFZLE1BQXBDO0FBQUEsc0JBQ0ssQ0FBQ1AsV0FBRCxnQkFDRyxxRUFBQyw0REFBRDtBQUFZLHVCQUFTLEVBQUVoRCxPQUFPLENBQUN1RSxVQUEvQjtBQUEyQyxxQkFBTyxFQUFFakIsV0FBcEQ7QUFBQSxxQ0FDSSxxRUFBQyxrREFBRDtBQUFNLDJCQUFXLEVBQUMsR0FBbEI7QUFBc0IscUJBQUssRUFBQyxRQUE1QjtBQUFxQyxvQkFBSSxFQUFFO0FBQTNDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURILGdCQUtHLHFFQUFDLDREQUFEO0FBQVksdUJBQVMsRUFBRXRELE9BQU8sQ0FBQ3VFLFVBQS9CO0FBQTJDLHFCQUFPLEVBQUVqQixXQUFwRDtBQUFBLHFDQUNJLHFFQUFDLGtEQUFEO0FBQU0sMkJBQVcsRUFBQyxHQUFsQjtBQUFzQixxQkFBSyxFQUFDLFFBQTVCO0FBQXFDLG9CQUFJLEVBQUU7QUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFOUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixlQWlCSSxxRUFBQyxzRUFBRDtBQUNJLGVBQUssRUFBRVgsS0FEWDtBQUVJLG1CQUFTLEVBQUVPLFNBRmY7QUFHSSxvQkFBVSxFQUFFTCxVQUhoQjtBQUlJLG9CQUFVLEVBQUVVO0FBSmhCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBakJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMSixlQTZCSSxxRUFBQyxxREFBRDtBQUFLLGVBQU8sRUFBQyxNQUFiO0FBQW9CLGtCQUFVLEVBQUMsUUFBL0I7QUFBd0MsVUFBRSxFQUFFQSxVQUFVLEdBQUcsQ0FBSCxHQUFPLENBQTdEO0FBQUEsZ0NBQ0kscUVBQUMscURBQUQ7QUFDSSxpQkFBTyxFQUFDLE1BRFo7QUFFSSxvQkFBVSxFQUFDLFFBRmY7QUFHSSxZQUFFLEVBQUVWLFVBQVUsR0FBRyxDQUFILEdBQU8sR0FIekI7QUFJSSxtQkFBUyxFQUFFN0MsT0FBTyxDQUFDd0UsV0FKdkI7QUFBQSxvQkFLS2IsYUFBYSxDQUFDdEUsR0FBZCxDQUFrQixDQUFDQyxJQUFELEVBQU9DLEtBQVAsa0JBQ2YscUVBQUMscURBQUQ7QUFFSSxjQUFFLEVBQUVBLEtBQUssS0FBS29FLGFBQWEsQ0FBQ2MsTUFBZCxHQUF1QixDQUFqQyxJQUFzQyxDQUY5QztBQUdJLG9CQUFRLEVBQUMsTUFIYjtBQUFBLG1DQUlJLHFFQUFDLHNEQUFEO0FBQU0sa0JBQUksRUFBQyxHQUFYO0FBQWUsdUJBQVMsRUFBQyxNQUF6QjtBQUFBLHFDQUNJLHFFQUFDLHFEQUFEO0FBQ0ksd0JBQVEsRUFBQyxhQURiO0FBRUksMEJBQVUsRUFBQyxtQkFGZjtBQUdJLHFCQUFLLEVBQUUxRCxLQUhYO0FBSUkseUJBQVMsRUFBRWYsT0FBTyxDQUFDNEQsUUFKdkI7QUFBQSwwQkFLS3RFLElBQUksQ0FBQ3NFO0FBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKSixhQUNTdEUsSUFBSSxDQUFDc0UsUUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURIO0FBTEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixFQXdCSyxDQUFDZixVQUFELElBQWVVLFVBQWYsZ0JBQ0cscUVBQUMsd0RBQUQ7QUFDSSxpQkFBTyxFQUFFLE1BQU1NLGVBQWUsRUFEbEM7QUFFSSxjQUFJLEVBQUVOLFVBQVUsR0FBRyxPQUFILEdBQWEsT0FGakM7QUFHSSxlQUFLLEVBQUVFLFdBSFg7QUFJSSxpQkFBTyxFQUFDLFdBSlo7QUFBQSxvQkFLS0M7QUFMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURILEdBUUcsSUFoQ1IsRUFpQ0tiLFVBQVUsZ0JBQ1AscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsQ0FBVDtBQUFBLGlDQUNJLHFFQUFDLDhEQUFEO0FBQU8sd0JBQVksRUFBRSxDQUFyQjtBQUF3QixpQkFBSyxFQUFDLE9BQTlCO0FBQUEsbUNBQ0kscUVBQUMsa0RBQUQ7QUFBTSx5QkFBVyxFQUFDLEdBQWxCO0FBQXNCLG1CQUFLLEVBQUMsT0FBNUI7QUFBb0Msa0JBQUksRUFBRSxFQUExQztBQUE4QyxrQkFBSSxFQUFDO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFETyxHQU1QLElBdkNSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkE3Qko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUxKLEVBNEVLQyxRQUFRLGlCQUNMLHFFQUFDLHFEQUFEO0FBQ0ksYUFBTyxFQUFDLE1BRFo7QUFFSSxtQkFBYSxFQUFDLFFBRmxCO0FBR0ksZUFBUyxFQUFDLFFBSGQ7QUFJSSxRQUFFLEVBQUVTLFVBQVUsR0FBRyxDQUFILEdBQU8sQ0FKekI7QUFLSSxRQUFFLEVBQUVBLFVBQVUsR0FBRyxDQUFILEdBQU8sRUFMekI7QUFNSSxXQUFLLEVBQUMsY0FOVjtBQU9JLGVBQVMsRUFBRVAsV0FBVyxHQUFHaEQsT0FBTyxDQUFDcUUsYUFBWCxHQUEyQixFQVByRDtBQUFBLDhCQVFJLHFFQUFDLHFEQUFEO0FBQ0ksa0JBQVUsRUFBQyxLQURmO0FBRUksZ0JBQVEsRUFBRWQsVUFBVSxHQUFHLGFBQUgsR0FBbUIsYUFGM0M7QUFHSSxrQkFBVSxFQUFDLGlCQUhmO0FBSUksVUFBRSxFQUFFLENBSlI7QUFBQSxrQkFLS1Q7QUFMTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJKLGVBZUkscUVBQUMscURBQUQ7QUFDSSxnQkFBUSxFQUFFUyxVQUFVLEdBQUcsYUFBSCxHQUFtQixhQUQzQztBQUVJLGtCQUFVLEVBQUVBLFVBQVUsR0FBRyxNQUFILEdBQVksTUFGdEM7QUFHSSxhQUFLLEVBQUMsY0FIVjtBQUlJLGdCQUFRLEVBQUMsT0FKYjtBQUtJLGNBQU0sRUFBQyxRQUxYO0FBQUEsa0JBTUtSO0FBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFmSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBN0VSLEVBdUdLLENBQUNDLFdBQVcsSUFBSUcsY0FBaEIsa0JBQ0cscUVBQUMscURBQUQ7QUFDSSxhQUFPLEVBQUMsTUFEWjtBQUVJLGdCQUFVLEVBQUMsUUFGZjtBQUdJLGVBQVMsRUFBRUgsV0FBVyxJQUFJRyxjQUFmLEdBQWdDbkQsT0FBTyxDQUFDMEUsY0FBeEMsR0FBeUQsRUFIeEU7QUFBQSw4QkFJSSxxRUFBQyw0REFBRDtBQUFZLGlCQUFTLEVBQUUxRSxPQUFPLENBQUN1RSxVQUEvQjtBQUEyQyxlQUFPLEVBQUVqQixXQUFwRDtBQUFBLGtCQUNLTixXQUFXLGdCQUNSLHFFQUFDLHlEQUFEO0FBQWEscUJBQVcsRUFBQyxHQUF6QjtBQUE2QixlQUFLLEVBQUMsUUFBbkM7QUFBNEMsY0FBSSxFQUFFO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRFEsZ0JBR1IscUVBQUMsa0RBQUQ7QUFBTSxxQkFBVyxFQUFDLEdBQWxCO0FBQXNCLGVBQUssRUFBQyxRQUE1QjtBQUFxQyxjQUFJLEVBQUU7QUFBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpSO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkosZUFXSSxxRUFBQyxxREFBRDtBQUNJLGdCQUFRLEVBQUMsYUFEYjtBQUVJLGtCQUFVLEVBQUMsc0JBRmY7QUFHSSxhQUFLLEVBQUVqQyxLQUhYO0FBSUksZ0JBQVEsRUFBQyxRQUpiO0FBS0ksa0JBQVUsRUFBQyxRQUxmO0FBTUksZ0JBQVEsRUFBQyxPQU5iO0FBT0ksb0JBQVksRUFBQyxVQVBqQjtBQVFJLG1CQUFXLEVBQUUsR0FSakI7QUFTSSxpQkFBUyxFQUFFZixPQUFPLENBQUMyQyxLQVR2QjtBQUFBLGtCQVVLTTtBQVZMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBWEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXhHUixFQWlJS0csUUFBUSxpQkFBSSxxRUFBQyw2RUFBRDtBQUFZLGlCQUFXLEVBQUUsS0FBekI7QUFBZ0MsaUJBQVcsRUFBRUM7QUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFqSWpCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBcUlILENBektEOztBQTJLQVQsVUFBVSxDQUFDMUMsWUFBWCxHQUEwQjtBQUN0QjhDLGFBQVcsRUFBRSxLQURTO0FBRXRCQyxhQUFXLEVBQUUsR0FGUztBQUd0Qk4sT0FBSyxFQUFFLFNBSGU7QUFJdEJPLFdBQVMsRUFBRTtBQUpXLENBQTFCO0FBTUFOLFVBQVUsQ0FBQ3pDLFNBQVgsR0FBdUI7QUFDbkIwQyxZQUFVLEVBQUV6QyxpREFBUyxDQUFDRyxJQURIO0FBRW5CdUMsVUFBUSxFQUFFMUMsaURBQVMsQ0FBQ3VCLE1BRkQ7QUFHbkJvQixnQkFBYyxFQUFFM0MsaURBQVMsQ0FBQ3VCLE1BSFA7QUFJbkJxQixhQUFXLEVBQUU1QyxpREFBUyxDQUFDRyxJQUpKO0FBS25CMEMsYUFBVyxFQUFFN0MsaURBQVMsQ0FBQ3VCLE1BTEo7QUFNbkJnQixPQUFLLEVBQUV2QyxpREFBUyxDQUFDdUIsTUFORTtBQU9uQnVCLFdBQVMsRUFBRTlDLGlEQUFTLENBQUN1QixNQVBGO0FBUW5Cd0IsZ0JBQWMsRUFBRS9DLGlEQUFTLENBQUNHO0FBUlAsQ0FBdkI7QUFXZXFDLHlFQUFmLEU7Ozs7Ozs7Ozs7OztBQ2hOQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU0zQyxTQUFTLEdBQUdPLDJFQUFVLENBQUVDLEtBQUQsS0FBWTtBQUNyQzJELG1CQUFpQixFQUFFO0FBQ2ZPLG1CQUFlLEVBQUUsb0JBREY7QUFFZkMsb0JBQWdCLEVBQUUsV0FGSDtBQUdmQyxzQkFBa0IsRUFBRSxRQUhMO0FBSWZDLGtCQUFjLEVBQUUsT0FKRDtBQUtmQywwQkFBc0IsRUFBRXRFLEtBQUssQ0FBQzZCLE9BQU4sQ0FBYyxJQUFkLENBTFQ7QUFNZjBDLDJCQUF1QixFQUFFdkUsS0FBSyxDQUFDNkIsT0FBTixDQUFjLElBQWQ7QUFOVixHQURrQjtBQVNyQ2dDLFdBQVMsRUFBRTtBQUNQLEtBQUM3RCxLQUFLLENBQUN3RSxXQUFOLENBQWtCQyxFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCL0ssYUFBTyxFQUFFO0FBRGlCO0FBRHZCLEdBVDBCO0FBY3JDcUssYUFBVyxFQUFFO0FBQ1QsS0FBQy9ELEtBQUssQ0FBQ3dFLFdBQU4sQ0FBa0JDLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUIvSyxhQUFPLEVBQUU7QUFEaUI7QUFEckIsR0Fkd0I7QUFtQnJDb0ssWUFBVSxFQUFFO0FBQ1I1RCxtQkFBZSxFQUFFRixLQUFLLENBQUNPLE1BQU4sQ0FBYUMsS0FEdEI7QUFFUixlQUFXO0FBQ1BOLHFCQUFlLEVBQUVGLEtBQUssQ0FBQ08sTUFBTixDQUFhQztBQUR2QjtBQUZILEdBbkJ5QjtBQXlCckMyQyxVQUFRLEVBQUU7QUFDTixlQUFXO0FBQ1A3QyxXQUFLLEVBQUVOLEtBQUssQ0FBQ0csT0FBTixDQUFjdUUsT0FBZCxDQUFzQjVEO0FBRHRCO0FBREwsR0F6QjJCO0FBOEJyQzJCLFdBQVMsRUFBRTtBQUNQLEtBQUN6QyxLQUFLLENBQUN3RSxXQUFOLENBQWtCQyxFQUFsQixDQUFxQixJQUFyQixDQUFELEdBQThCO0FBQzFCL0ssYUFBTyxFQUFFO0FBRGlCO0FBRHZCLEdBOUIwQjtBQW1DckN3SSxPQUFLLEVBQUU7QUFDSCxLQUFDbEMsS0FBSyxDQUFDd0UsV0FBTixDQUFrQkMsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQmpELGNBQVEsRUFBRXhCLEtBQUssQ0FBQ3lCLFVBQU4sQ0FBaUJrRCxFQUFqQixDQUFvQm5EO0FBREo7QUFEM0IsR0FuQzhCO0FBd0NyQ3lDLGdCQUFjLEVBQUU7QUFDWixLQUFDakUsS0FBSyxDQUFDd0UsV0FBTixDQUFrQkMsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQi9LLGFBQU8sRUFBRTtBQURpQixLQURsQjtBQUlaQSxXQUFPLEVBQUU7QUFKRyxHQXhDcUI7QUE4Q3JDa0ssZUFBYSxFQUFFO0FBQ1gsS0FBQzVELEtBQUssQ0FBQ3dFLFdBQU4sQ0FBa0JJLElBQWxCLENBQXVCLElBQXZCLENBQUQsR0FBZ0M7QUFDNUJsTCxhQUFPLEVBQUU7QUFEbUI7QUFEckI7QUE5Q3NCLENBQVosQ0FBRCxDQUE1QjtBQXFEZThGLHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3ZEQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFNQTtBQUVBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1xRixVQUFVLEdBQUcsQ0FBQztBQUFFQyxhQUFGO0FBQWVsQztBQUFmLENBQUQsS0FBa0M7QUFDakQsUUFBTTtBQUFBLE9BQUNtQyxjQUFEO0FBQUEsT0FBaUJDO0FBQWpCLE1BQXNDM0gsc0RBQVEsQ0FBQyxJQUFELENBQXBEO0FBQ0EsUUFBTWtDLE9BQU8sR0FBR0MsaUVBQVMsRUFBekI7QUFFQSxRQUFNeUYsS0FBSyxHQUFHSCxXQUFXLEdBQUdJLHdFQUFILEdBQTBCQyw2REFBbkQ7QUFDQSxRQUFNQyxXQUFXLEdBQUdOLFdBQVcsR0FBR08sNkVBQUgsR0FBK0JDLDRFQUE5RDtBQUVBLHNCQUNJO0FBQUEsY0FDS1AsY0FBYyxpQkFDWCxxRUFBQyxxREFBRDtBQUNJLGVBQVMsRUFBRXJCLDJDQUFJLENBQ1huRSxPQUFPLENBQUNnRyxZQURHLEVBRVhULFdBQVcsSUFBSXZGLE9BQU8sQ0FBQ2lHLGtCQUZaLENBRG5CO0FBS0ksT0FBQyxFQUFFLENBTFA7QUFBQSw4QkFNSSxxRUFBQyxxREFBRDtBQUFLLGVBQU8sRUFBQyxNQUFiO0FBQW9CLFVBQUUsRUFBRSxFQUF4QjtBQUFBLCtCQUNJLHFFQUFDLDREQUFEO0FBQ0ksbUJBQVMsRUFBRWpHLE9BQU8sQ0FBQ3VFLFVBRHZCO0FBRUksaUJBQU8sRUFBRSxNQUFNO0FBQ1hrQiw2QkFBaUIsQ0FBQyxLQUFELENBQWpCO0FBQ0FwQyx1QkFBVyxDQUFDLEtBQUQsQ0FBWDtBQUNILFdBTEw7QUFBQSxpQ0FNSSxxRUFBQywrQ0FBRDtBQUFHLHVCQUFXLEVBQUMsR0FBZjtBQUFtQixpQkFBSyxFQUFDLFFBQXpCO0FBQWtDLGdCQUFJLEVBQUU7QUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5KLGVBZ0JJLHFFQUFDLHFEQUFEO0FBQUEsa0JBQ0t3QyxXQUFXLENBQUN4RyxHQUFaLENBQWlCQyxJQUFELGlCQUNiLHFFQUFDLHFEQUFEO0FBQUssWUFBRSxFQUFFLEdBQVQ7QUFBQSxpQ0FDSSxxRUFBQyxzREFBRDtBQUFNLGdCQUFJLEVBQUMsR0FBWDtBQUFlLHFCQUFTLEVBQUMsTUFBekI7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUFLLHFCQUFPLEVBQUMsTUFBYjtBQUFvQix3QkFBVSxFQUFDLFFBQS9CO0FBQUEsc0NBQ0kscUVBQUMsSUFBRCxDQUFNLElBQU47QUFBVywyQkFBVyxFQUFDLEdBQXZCO0FBQTJCLHFCQUFLLEVBQUMsUUFBakM7QUFBMEMsb0JBQUksRUFBRTtBQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURKLGVBRUkscUVBQUMscURBQUQ7QUFDSSx3QkFBUSxFQUFDLGFBRGI7QUFFSSxxQkFBSyxFQUFDLGNBRlY7QUFHSSwwQkFBVSxFQUFDLGlCQUhmO0FBSUksa0JBQUUsRUFBRSxHQUpSO0FBQUEsMEJBS0tBLElBQUksQ0FBQzRHO0FBTFY7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosV0FBbUI1RyxJQUFJLENBQUM0RyxJQUF4QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURIO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoQkosRUFrQ0tYLFdBQVcsaUJBQ1IscUVBQUMscURBQUQ7QUFBSyxVQUFFLEVBQUUsR0FBVDtBQUFjLFVBQUUsRUFBRSxDQUFsQjtBQUFBLCtCQUNJLHFFQUFDLHdEQUFEO0FBQVEsY0FBSSxFQUFDLE9BQWI7QUFBcUIsZUFBSyxFQUFDLFNBQTNCO0FBQXFDLGlCQUFPLEVBQUMsV0FBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQW5DUixlQXlDSSxxRUFBQyxxREFBRDtBQUFBLGtCQUNLRyxLQUFLLENBQUNyRyxHQUFOLENBQVUsQ0FBQ0MsSUFBRCxFQUFPQyxLQUFQLGtCQUNQLHFFQUFDLHFEQUFEO0FBQUssaUJBQU8sRUFBQyxNQUFiO0FBQWdDLFlBQUUsRUFBRSxHQUFwQztBQUFBLGlDQUNJLHFFQUFDLHdEQUFEO0FBQ0kscUJBQVMsRUFBRTRFLDJDQUFJLENBQUMsU0FBRCxFQUFZbkUsT0FBTyxDQUFDbUcsWUFBcEIsQ0FEbkI7QUFFSSxnQkFBSSxFQUFDLFFBRlQ7QUFHSSxtQkFBTyxlQUFFLHFFQUFDLDBEQUFEO0FBQWMsbUJBQUssRUFBQyxRQUFwQjtBQUE2QixrQkFBSSxFQUFFO0FBQW5DO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSGI7QUFBQSxzQkFJSzdHLElBQUksQ0FBQ3NFO0FBSlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKLFdBQXlCckUsS0FBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESDtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBekNKLGVBcURJLHFFQUFDLHFEQUFEO0FBQ0ksZ0JBQVEsRUFBQyxPQURiO0FBRUksYUFBSyxFQUFDLE9BRlY7QUFHSSxjQUFNLEVBQUMsSUFIWDtBQUlJLGlCQUFTLEVBQ0xnRyxXQUFXLEdBQUd2RixPQUFPLENBQUNvRyxnQkFBWCxHQUE4QnBHLE9BQU8sQ0FBQ3FHLG1CQUx6RDtBQUFBLCtCQU9JLHFFQUFDLGlEQUFEO0FBQ0ksYUFBRyxFQUFDLGlCQURSO0FBRUksZUFBSyxFQUFFLEdBRlg7QUFHSSxnQkFBTSxFQUFFLEdBSFo7QUFJSSxtQkFBUyxFQUFFckcsT0FBTyxDQUFDc0c7QUFKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBckRKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUZSLG1CQURKO0FBMEVILENBakZEOztBQWtGQWhCLFVBQVUsQ0FBQ25GLFNBQVgsR0FBdUI7QUFDbkJvRixhQUFXLEVBQUVuRixpREFBUyxDQUFDRyxJQURKO0FBRW5COEMsYUFBVyxFQUFFakQsaURBQVMsQ0FBQzRCO0FBRkosQ0FBdkI7QUFJZXNELHlFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3pHQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ08sTUFBTUssb0JBQW9CLEdBQUcsQ0FDaEM7QUFDSS9CLFVBQVEsRUFBRTtBQURkLENBRGdDLEVBSWhDO0FBQ0lBLFVBQVEsRUFBRTtBQURkLENBSmdDLEVBT2hDO0FBQ0lBLFVBQVEsRUFBRTtBQURkLENBUGdDLENBQTdCO0FBWUEsTUFBTWdDLFNBQVMsR0FBRyxDQUNyQjtBQUNJaEMsVUFBUSxFQUFFO0FBRGQsQ0FEcUIsRUFJckI7QUFDSUEsVUFBUSxFQUFFO0FBRGQsQ0FKcUIsQ0FBbEI7QUFRQSxNQUFNbUMsd0JBQXdCLEdBQUcsQ0FDcEM7QUFBRUcsTUFBSSxFQUFFLGdCQUFSO0FBQTBCSyxNQUFJLEVBQUVDLGtEQUFJQTtBQUFwQyxDQURvQyxFQUVwQztBQUFFTixNQUFJLEVBQUUsbUJBQVI7QUFBNkJLLE1BQUksRUFBRUUsc0RBQVFBO0FBQTNDLENBRm9DLEVBR3BDO0FBQUVQLE1BQUksRUFBRSxjQUFSO0FBQXdCSyxNQUFJLEVBQUVHLGtEQUFJQTtBQUFsQyxDQUhvQyxFQUlwQztBQUFFUixNQUFJLEVBQUUsYUFBUjtBQUF1QkssTUFBSSxFQUFFSSx3REFBVUE7QUFBdkMsQ0FKb0MsQ0FBakM7QUFNQSxNQUFNYix5QkFBeUIsR0FBRyxDQUNyQztBQUFFSSxNQUFJLEVBQUUsTUFBUjtBQUFnQkssTUFBSSxFQUFFQyxrREFBSUE7QUFBMUIsQ0FEcUMsRUFFckM7QUFBRU4sTUFBSSxFQUFFLGFBQVI7QUFBdUJLLE1BQUksRUFBRUssa0RBQUlBO0FBQWpDLENBRnFDLEVBR3JDO0FBQUVWLE1BQUksRUFBRSxjQUFSO0FBQXdCSyxNQUFJLEVBQUVFLHNEQUFRQTtBQUF0QyxDQUhxQyxFQUlyQztBQUFFUCxNQUFJLEVBQUUsYUFBUjtBQUF1QkssTUFBSSxFQUFFSSx3REFBVUE7QUFBdkMsQ0FKcUMsQ0FBbEMsQzs7Ozs7Ozs7Ozs7O0FDM0JQO0FBQUE7QUFBQTtBQUFBO0FBRUEsTUFBTTFHLFNBQVMsR0FBR08sMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3JDdUYsY0FBWSxFQUFFO0FBQ1Z0TSxZQUFRLEVBQUUsT0FEQTtBQUVWRSxRQUFJLEVBQUUsQ0FGSTtBQUdWRSxTQUFLLEVBQUUsQ0FIRztBQUlWSCxPQUFHLEVBQUUsQ0FKSztBQUtWRSxVQUFNLEVBQUUsQ0FMRTtBQU1WbkMsU0FBSyxFQUFFLE1BTkc7QUFPVjBDLFVBQU0sRUFBRSxPQVBFO0FBUVZ5TSxVQUFNLEVBQUUsT0FSRTtBQVNWbEcsbUJBQWUsRUFBRUYsS0FBSyxDQUFDRyxPQUFOLENBQWNTLEtBQWQsQ0FBb0JDO0FBVDNCLEdBRHVCO0FBWXJDMkUsb0JBQWtCLEVBQUU7QUFDaEJ0RixtQkFBZSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY0ksTUFBZCxDQUFxQkM7QUFEdEIsR0FaaUI7QUFlckNzRCxZQUFVLEVBQUU7QUFDUjVELG1CQUFlLEVBQUVGLEtBQUssQ0FBQ08sTUFBTixDQUFhQztBQUR0QixHQWZ5QjtBQWtCckNtRixrQkFBZ0IsRUFBRTtBQUNkek0sT0FBRyxFQUFFO0FBRFMsR0FsQm1CO0FBcUJyQzBNLHFCQUFtQixFQUFFO0FBQ2pCeE0sVUFBTSxFQUFFO0FBRFMsR0FyQmdCO0FBd0JyQ3NNLGNBQVksRUFBRTtBQUNWbEUsWUFBUSxFQUFFeEIsS0FBSyxDQUFDeUIsVUFBTixDQUFpQjRFLEVBQWpCLENBQW9CN0UsUUFEcEI7QUFFVmxCLFNBQUssRUFBRU4sS0FBSyxDQUFDRyxPQUFOLENBQWNDLE9BQWQsQ0FBc0JDO0FBRm5CO0FBeEJ1QixDQUFaLENBQUQsQ0FBNUI7QUE4QmViLHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ2hDQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFHQSxNQUFNOEcsU0FBUyxHQUFHLENBQUM7QUFBRUMsVUFBRjtBQUFZQyxhQUFaO0FBQXlCQyxhQUF6QjtBQUFzQ3ZFLE9BQUssR0FBQztBQUE1QyxDQUFELEtBQXFEO0FBQ25FLFFBQU0zQyxPQUFPLEdBQUdDLGdFQUFTLEVBQXpCO0FBQ0EsUUFBTXNELFVBQVUsR0FBR0Msc0VBQWEsQ0FBQyxvQkFBRCxDQUFoQztBQUNBLFFBQU1HLGFBQWEsR0FBRyxDQUNsQjtBQUNJQyxZQUFRLEVBQUU7QUFEZCxHQURrQixFQUlsQjtBQUNJQSxZQUFRLEVBQUU7QUFEZCxHQUprQixFQU9sQjtBQUNJQSxZQUFRLEVBQUU7QUFEZCxHQVBrQixDQUF0QjtBQVlBLFFBQU07QUFBQSxPQUFDL0UsVUFBRDtBQUFBLE9BQWFDO0FBQWIsTUFBOEJoQixzREFBUSxDQUFDLEtBQUQsQ0FBNUM7O0FBQ0EsUUFBTWtCLFdBQVcsR0FBRyxNQUFNO0FBQ3RCRixpQkFBYSxDQUFDLEtBQUQsQ0FBYjtBQUNILEdBRkQ7O0FBSUEsc0JBQ0kscUVBQUMscURBQUQ7QUFDSSxNQUFFLEVBQUUsQ0FEUjtBQUVJLE1BQUUsRUFBRXlFLFVBQVUsR0FBRyxDQUFILEdBQU8sQ0FGekI7QUFHSSxNQUFFLEVBQUUsQ0FIUjtBQUlJLE1BQUUsRUFBRUEsVUFBVSxHQUFHLENBQUgsR0FBTyxDQUp6QjtBQUtJLFdBQU8sRUFBQyxzQkFMWjtBQUFBLDJCQU1JLHFFQUFDLHFEQUFEO0FBQUssYUFBTyxFQUFDLE1BQWI7QUFBb0IsZ0JBQVUsRUFBQyxRQUEvQjtBQUF3QyxvQkFBYyxFQUFDLGVBQXZEO0FBQUEsOEJBQ0kscUVBQUMscURBQUQ7QUFBSyxlQUFPLEVBQUMsTUFBYjtBQUFvQixrQkFBVSxFQUFDLFFBQS9CO0FBQXdDLGdCQUFRLEVBQUUsR0FBbEQ7QUFBQSxtQkFDS3lELFFBQVEsaUJBQ0wscUVBQUMscURBQUQ7QUFBSyxZQUFFLEVBQUUsR0FBVDtBQUFBLGlDQUNJLHFFQUFDLDREQUFEO0FBQVksbUJBQU8sRUFBRUMsV0FBckI7QUFBQSxtQ0FDSSxxRUFBQyx5REFBRDtBQUFhLHlCQUFXLEVBQUMsR0FBekI7QUFBNkIsbUJBQUssRUFBQyxRQUFuQztBQUE0QyxrQkFBSSxFQUFFO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGUixlQVFJLHFFQUFDLHFEQUFEO0FBQ0ksZUFBSyxFQUFDLGVBRFY7QUFFSSxrQkFBUSxFQUFFLEVBRmQ7QUFHSSxvQkFBVSxFQUFDLE1BSGY7QUFBQSxvQkFJTXRFLEtBQUssR0FBR0EsS0FBSCxHQUFXO0FBSnRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURKLGVBZ0JJLHFFQUFDLHFEQUFEO0FBQ0ksYUFBSyxFQUFDLGVBRFY7QUFFSSxnQkFBUSxFQUFDLGFBRmI7QUFHSSxnQkFBUSxFQUFDLFVBSGI7QUFJSSxXQUFHLEVBQUMsT0FKUjtBQUtJLGVBQU8sRUFBRSxDQUFDWSxVQUFELEdBQWMsTUFBZCxHQUF1QixNQUxwQztBQUFBLCtCQU1JLHFFQUFDLDREQUFEO0FBQUEsaUNBQ0kscUVBQUMsK0NBQUQ7QUFBRyx1QkFBVyxFQUFDLEdBQWY7QUFBbUIsaUJBQUssRUFBQyxPQUF6QjtBQUFpQyxnQkFBSSxFQUFFO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFoQkosZUEwQkkscUVBQUMscURBQUQ7QUFBSyxrQkFBVSxFQUFDLFFBQWhCO0FBQXlCLGVBQU8sRUFBRUEsVUFBVSxHQUFHLE1BQUgsR0FBWSxNQUF4RDtBQUFBLGtCQUVReUQsUUFBUSxnQkFDSjtBQUFBLGtDQUNJLHFFQUFDLHFEQUFEO0FBQUsscUJBQVMsRUFBRWhILE9BQU8sQ0FBQ21ILElBQXhCO0FBQUEsbUNBQ0kscUVBQUMsc0RBQUQ7QUFBTSxrQkFBSSxFQUFDLEdBQVg7QUFBZSx1QkFBUyxFQUFDLE1BQXpCO0FBQUEscUNBQ0kscUVBQUMscURBQUQ7QUFBSyx3QkFBUSxFQUFDLGdCQUFkO0FBQStCLHFCQUFLLEVBQUMsdUJBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREosZUFRSSxxRUFBQyxxREFBRDtBQUFLLHFCQUFTLEVBQUVuSCxPQUFPLENBQUNtSCxJQUF4QjtBQUFBLG1DQUNJLHFFQUFDLHNEQUFEO0FBQU0sa0JBQUksRUFBQyxHQUFYO0FBQWUsdUJBQVMsRUFBQyxNQUF6QjtBQUFnQyxxQkFBTyxFQUFFLE1BQU07QUFDM0NySSw2QkFBYSxDQUFDLElBQUQsQ0FBYjtBQUNILGVBRkQ7QUFBQSxxQ0FHSSxxRUFBQyxxREFBRDtBQUFLLHdCQUFRLEVBQUMsZ0JBQWQ7QUFBK0IscUJBQUssRUFBQyx1QkFBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFISjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFSSixlQWlCSSxxRUFBQyx3REFBRDtBQUNJLG1CQUFPLEVBQUVFLFdBRGI7QUFFSSwrQkFBZ0IscUJBRnBCO0FBR0ksZ0JBQUksRUFBRUgsVUFIVjtBQUFBLG1DQUlJLHFFQUFDLHdFQUFEO0FBQWUscUJBQU8sRUFBRUcsV0FBeEI7QUFBcUMsdUJBQVMsRUFBRWtJO0FBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKSjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWpCSjtBQUFBLHdCQURJLGdCQTBCSjtBQUFBLG9CQUNLdkQsYUFBYSxDQUFDdEUsR0FBZCxDQUFtQkMsSUFBRCxpQkFDZixxRUFBQyxxREFBRDtBQUFBLG1DQUNJLHFFQUFDLHNEQUFEO0FBQU0sa0JBQUksRUFBQyxHQUFYO0FBQWUsdUJBQVMsRUFBQyxNQUF6QjtBQUFBLHFDQUNJLHFFQUFDLHFEQUFEO0FBQUssd0JBQVEsRUFBQyxnQkFBZDtBQUErQixxQkFBSyxFQUFDLHVCQUFyQztBQUFBLDBCQUNLQSxJQUFJLENBQUNzRTtBQURWO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREosYUFBVXRFLElBQUksQ0FBQ3NFLFFBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFESDtBQURMO0FBNUJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBMUJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQThFSCxDQWxHRDs7QUFtR0FtRCxTQUFTLENBQUM3RyxZQUFWLEdBQXlCO0FBQ3JCOEcsVUFBUSxFQUFFLEtBRFc7QUFFckJyRSxPQUFLLEVBQUUsSUFGYztBQUdyQnNFLGFBQVcsRUFBRTdHLGlEQUFTLENBQUM0QjtBQUhGLENBQXpCO0FBS0ErRSxTQUFTLENBQUM1RyxTQUFWLEdBQXNCO0FBQ2xCNkcsVUFBUSxFQUFFNUcsaURBQVMsQ0FBQ0csSUFERjtBQUVsQjBHLGFBQVcsRUFBRTdHLGlEQUFTLENBQUM0QixJQUZMO0FBR2xCa0YsYUFBVyxFQUFFOUcsaURBQVMsQ0FBQzRCLElBSEw7QUFJbEJXLE9BQUssRUFBRXZDLGlEQUFTLENBQUN1QjtBQUpDLENBQXRCO0FBTWVvRix3RUFBZixFOzs7Ozs7Ozs7Ozs7QUM3SEE7QUFBQTtBQUFBO0FBQUE7QUFFQSxNQUFNOUcsU0FBUyxHQUFHTywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckMwRyxNQUFJLEVBQUU7QUFDRiwwQkFBc0I7QUFDbEJDLGlCQUFXLEVBQUMzRyxLQUFLLENBQUM2QixPQUFOLENBQWMsQ0FBZCxDQURNO0FBRWxCNUksY0FBUSxFQUFFLFVBRlE7QUFHbEIsa0JBQVk7QUFDUjJOLGVBQU8sRUFBRSxLQUREO0FBRVIzTixnQkFBUSxFQUFFLFVBRkY7QUFHUkksYUFBSyxFQUFFLE9BSEM7QUFJUkgsV0FBRyxFQUFFLENBSkc7QUFLUkUsY0FBTSxFQUFFLENBTEE7QUFNUmtILGFBQUssRUFBRTtBQU5DO0FBSE07QUFEcEI7QUFEK0IsQ0FBWixDQUFELENBQTVCO0FBaUJlZCx3RUFBZixFOzs7Ozs7Ozs7Ozs7QUNuQkE7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLE1BQU1xSCxVQUFVLEdBQUcsQ0FBQztBQUFFQyxRQUFGO0FBQVVDLE1BQVY7QUFBZ0JDLFVBQWhCO0FBQTBCQyxVQUExQjtBQUFvQ0MsYUFBcEM7QUFBaUQ5SDtBQUFqRCxDQUFELEtBQWtFO0FBQ2pGLFFBQU1HLE9BQU8sR0FBR0MsaUVBQVMsRUFBekI7QUFDQSxzQkFDSSxxRUFBQyxxREFBRDtBQUNJLFNBQUssRUFBRXVILElBRFg7QUFFSSxVQUFNLEVBQUVBLElBRlo7QUFHSSxnQkFBWSxFQUFDLEtBSGpCO0FBSUksV0FBTyxFQUFDLE1BSlo7QUFLSSxjQUFVLEVBQUMsUUFMZjtBQU1JLGtCQUFjLEVBQUMsUUFObkI7QUFPSSxVQUFNLEVBQUMsUUFQWDtBQVFJLFVBQU0sRUFBRUcsV0FSWjtBQVNJLGFBQVMsRUFBRTNILE9BQU8sQ0FBQ3VILE1BQUQsQ0FUdEI7QUFBQSwyQkFVSSxxRUFBQywwREFBRDtBQUFhLFVBQUksRUFBRUUsUUFBbkI7QUFBNkIsVUFBSSxFQUFFQyxRQUFuQztBQUE2QyxXQUFLLEVBQUU3SDtBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVko7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBY0gsQ0FoQkQ7O0FBa0JBeUgsVUFBVSxDQUFDcEgsWUFBWCxHQUEwQjtBQUN0QnNILE1BQUksRUFBRSxFQURnQjtBQUV0QkQsUUFBTSxFQUFFLFNBRmM7QUFHdEJFLFVBQVEsRUFBRSxXQUhZO0FBSXRCQyxVQUFRLEVBQUUsRUFKWTtBQUt0QkMsYUFBVyxFQUFFO0FBTFMsQ0FBMUI7QUFRQUwsVUFBVSxDQUFDbkgsU0FBWCxHQUF1QjtBQUNuQm9ILFFBQU0sRUFBRW5ILGlEQUFTLENBQUNDLEtBQVYsQ0FBZ0IsQ0FBQyxTQUFELEVBQVksUUFBWixFQUFzQixTQUF0QixFQUFpQyxTQUFqQyxFQUE0QyxVQUE1QyxDQUFoQixDQURXO0FBRW5CbUgsTUFBSSxFQUFFcEgsaURBQVMsQ0FBQ3dCLE1BRkc7QUFHbkI4RixVQUFRLEVBQUV0SCxpREFBUyxDQUFDd0IsTUFIRDtBQUluQitGLGFBQVcsRUFBRXZILGlEQUFTLENBQUN3QixNQUpKO0FBS25CNkYsVUFBUSxFQUFFckgsaURBQVMsQ0FBQ3VCLE1BTEQ7QUFNbkI5QixXQUFTLEVBQUVPLGlEQUFTLENBQUN1QjtBQU5GLENBQXZCO0FBU2UyRix5RUFBZixFOzs7Ozs7Ozs7Ozs7QUMvQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQSxNQUFNckgsU0FBUyxHQUFHTyxvRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckNtSCxRQUFNLEVBQUU7QUFDSmpILG1CQUFlLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjaUgsS0FBZCxDQUFvQnRHLEtBRGpDO0FBRUp1RyxlQUFXLEVBQUcsR0FBRXJILEtBQUssQ0FBQ0csT0FBTixDQUFjaUgsS0FBZCxDQUFvQi9HLElBQUs7QUFGckMsR0FENkI7QUFLckNpSCxTQUFPLEVBQUU7QUFDTHBILG1CQUFlLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjbUgsT0FBZCxDQUFzQnhHLEtBRGxDO0FBRUx1RyxlQUFXLEVBQUcsR0FBRXJILEtBQUssQ0FBQ0csT0FBTixDQUFjbUgsT0FBZCxDQUFzQmpILElBQUs7QUFGdEMsR0FMNEI7QUFTckNxRSxTQUFPLEVBQUU7QUFDTHhFLG1CQUFlLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjdUUsT0FBZCxDQUFzQjVELEtBRGxDO0FBRUx1RyxlQUFXLEVBQUcsR0FBRXJILEtBQUssQ0FBQ0csT0FBTixDQUFjdUUsT0FBZCxDQUFzQnJFLElBQUs7QUFGdEMsR0FUNEI7QUFhckNrSCxTQUFPLEVBQUU7QUFDTHJILG1CQUFlLEVBQUUsYUFEWjtBQUVMbUgsZUFBVyxFQUFHLEdBQUVySCxLQUFLLENBQUNHLE9BQU4sQ0FBY29ILE9BQWQsQ0FBc0JsSCxJQUFLO0FBRnRDLEdBYjRCO0FBaUJyQ21ILFVBQVEsRUFBRTtBQUNOdEgsbUJBQWUsRUFBRUYsS0FBSyxDQUFDTyxNQUFOLENBQWFDLEtBRHhCO0FBRU5oSCxVQUFNLEVBQUUsbUNBRkY7QUFHTiwrQkFBMkIsYUFIckI7QUFJTmlPLGtCQUFjLEVBQUU7QUFKVjtBQWpCMkIsQ0FBWixDQUFELENBQTVCO0FBd0Jlakksd0VBQWYsRTs7Ozs7Ozs7Ozs7O0FDekJBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNa0ksV0FBVyxHQUFHLENBQUM7QUFBRXhGLE9BQUY7QUFBU08sV0FBVDtBQUFvQkwsWUFBcEI7QUFBZ0NVO0FBQWhDLENBQUQsS0FBa0Q7QUFDbEUsUUFBTXZELE9BQU8sR0FBR0Msa0VBQVMsRUFBekI7QUFDQSxRQUFNYyxLQUFLLEdBQUc4QixVQUFVLEdBQUcsY0FBSCxHQUFvQixlQUE1QztBQUNBLFFBQU11RixZQUFZLEdBQUd2RixVQUFVLEdBQUcsY0FBSCxHQUFvQixlQUFuRDtBQUNBLHNCQUNJLHFFQUFDLHFEQUFEO0FBQUssV0FBTyxFQUFDLE1BQWI7QUFBb0IsaUJBQWEsRUFBQyxRQUFsQztBQUFBLDJCQUNJO0FBQUEsOEJBQ0kscUVBQUMscURBQUQ7QUFDSSxnQkFBUSxFQUFDLGFBRGI7QUFFSSxrQkFBVSxFQUFDLHNCQUZmO0FBR0ksYUFBSyxFQUFFOUIsS0FIWDtBQUlJLGdCQUFRLEVBQUMsUUFKYjtBQUtJLGtCQUFVLEVBQUMsUUFMZjtBQU1JLGdCQUFRLEVBQUMsT0FOYjtBQU9JLG9CQUFZLEVBQUMsVUFQakI7QUFRSSxpQkFBUyxFQUFFZixPQUFPLENBQUMyQyxLQVJ2QjtBQUFBLGtCQVNLLENBQUNFLFVBQUQsSUFBZVUsVUFBZixHQUE0QlosS0FBNUIsR0FBb0M7QUFUekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQVlJLHFFQUFDLHFEQUFEO0FBQ0ksZUFBTyxFQUFDLE1BRFo7QUFFSSxnQkFBUSxFQUFDLGdCQUZiO0FBR0kscUJBQWEsRUFBQyxLQUhsQjtBQUlJLGFBQUssRUFBRXlGLFlBSlg7QUFLSSxpQkFBUyxFQUFFcEksT0FBTyxDQUFDa0QsU0FMdkI7QUFBQSxrQkFNS0E7QUFOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpKO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUF5QkgsQ0E3QkQ7O0FBK0JBaUYsV0FBVyxDQUFDakksWUFBWixHQUEyQixFQUEzQjtBQUNBaUksV0FBVyxDQUFDaEksU0FBWixHQUF3QjtBQUNwQndDLE9BQUssRUFBRXZDLGlEQUFTLENBQUN1QixNQURHO0FBRXBCdUIsV0FBUyxFQUFFOUMsaURBQVMsQ0FBQ3VCLE1BRkQ7QUFHcEJrQixZQUFVLEVBQUV6QyxpREFBUyxDQUFDRyxJQUhGO0FBSXBCZ0QsWUFBVSxFQUFFbkQsaURBQVMsQ0FBQ0c7QUFKRixDQUF4QjtBQU9lNEgsMEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDckRBO0FBQUE7QUFBQTtBQUFBO0FBRUEsTUFBTWxJLFNBQVMsR0FBR08sMkVBQVUsQ0FBRUMsS0FBRCxLQUFZO0FBQ3JDeUMsV0FBUyxFQUFFO0FBQ1AsS0FBQ3pDLEtBQUssQ0FBQ3dFLFdBQU4sQ0FBa0JDLEVBQWxCLENBQXFCLElBQXJCLENBQUQsR0FBOEI7QUFDMUIvSyxhQUFPLEVBQUU7QUFEaUI7QUFEdkIsR0FEMEI7QUFNckN3SSxPQUFLLEVBQUU7QUFDSCxLQUFDbEMsS0FBSyxDQUFDd0UsV0FBTixDQUFrQkMsRUFBbEIsQ0FBcUIsSUFBckIsQ0FBRCxHQUE4QjtBQUMxQmpELGNBQVEsRUFBRXhCLEtBQUssQ0FBQ3lCLFVBQU4sQ0FBaUJrRCxFQUFqQixDQUFvQm5EO0FBREo7QUFEM0I7QUFOOEIsQ0FBWixDQUFELENBQTVCO0FBYWVoQyx3RUFBZixFOzs7Ozs7Ozs7Ozs7QUNmQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNb0ksVUFBVSxHQUFJQyxLQUFELElBQVc7QUFDMUIsUUFBTTtBQUFFeEksWUFBRjtBQUFZRixXQUFaO0FBQXFCNkgsWUFBckI7QUFBK0JjLFlBQS9CO0FBQXlDQyxXQUF6QztBQUFrRHpHLFlBQWxEO0FBQTREMEcsWUFBNUQ7QUFBc0VDLGVBQXRFO0FBQW1GQztBQUFuRixNQUNGTCxLQURKO0FBRUEsUUFBTXRJLE9BQU8sR0FBR0MsZ0VBQVMsRUFBekI7QUFDQSxRQUFNLENBQUMySSxRQUFELEVBQVdDLFdBQVgsSUFBMEJwSyw0Q0FBSyxDQUFDWCxRQUFOLENBQWUsSUFBZixDQUFoQztBQUNBLFFBQU1nTCxJQUFJLEdBQUdqUSxPQUFPLENBQUMrUCxRQUFELENBQXBCOztBQUVBLFFBQU1HLFdBQVcsR0FBSXBLLEtBQUQsSUFBVztBQUMzQmtLLGVBQVcsQ0FBQ2xLLEtBQUssQ0FBQ3FLLGFBQVAsQ0FBWDtBQUNILEdBRkQ7O0FBSUEsUUFBTWhLLFdBQVcsR0FBRyxNQUFNO0FBQ3RCNkosZUFBVyxDQUFDLElBQUQsQ0FBWDtBQUNILEdBRkQ7O0FBSUEsUUFBTUksVUFBVSxHQUFHLE1BQU07QUFDckJQLGVBQVc7QUFDWDFKLGVBQVc7QUFDZCxHQUhEOztBQUlBLFFBQU12QixZQUFZLEdBQUcsTUFBTTtBQUN2QnNFLFlBQVE7QUFDUi9DLGVBQVc7QUFDZCxHQUhEOztBQUtBLHNCQUNJO0FBQUEsY0FDS3VKLFFBQVEsS0FBSyxZQUFiLGdCQUNHLHFFQUFDLHNEQUFEO0FBQU0sYUFBTyxFQUFFQyxPQUFmO0FBQUEsNkJBQ0kscUVBQUMscURBQUQ7QUFBSyxlQUFPLEVBQUMsTUFBYjtBQUFvQixrQkFBVSxFQUFDLFFBQS9CO0FBQXdDLFVBQUUsRUFBRSxDQUE1QztBQUErQyxVQUFFLEVBQUUsR0FBbkQ7QUFBd0QsaUJBQVMsRUFBRSxFQUFuRTtBQUFBLGdDQUNJLHFFQUFDLHFEQUFEO0FBQUEsaUNBQ0kscUVBQUMsbURBQUQ7QUFDSSxnQkFBSSxFQUFFLEVBRFY7QUFFSSxrQkFBTSxFQUFFNUksT0FGWjtBQUdJLG9CQUFRLEVBQUU2SCxRQUhkO0FBSUksdUJBQVcsRUFBRSxHQUpqQjtBQUtJLG9CQUFRLEVBQUU7QUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFESixFQVVLM0gsUUFBUSxpQkFDTCxxRUFBQyxxREFBRDtBQUNJLGtCQUFRLEVBQUUsQ0FEZDtBQUVJLGlCQUFPLEVBQUMsTUFGWjtBQUdJLHVCQUFhLEVBQUMsUUFIbEI7QUFJSSx3QkFBYyxFQUFDLFFBSm5CO0FBS0ksWUFBRSxFQUFFLEdBTFI7QUFBQSxvQkFNS0E7QUFOTDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVhSLEVBb0JLNkksY0FBYyxpQkFDWCxxRUFBQyxxREFBRDtBQUNJLFdBQUMsRUFBRSxJQURQO0FBRUksWUFBRSxFQUFFLENBQUMsR0FGVDtBQUdJLGlCQUFPLEVBQUMsTUFIWjtBQUlJLHdCQUFjLEVBQUMsUUFKbkI7QUFLSSxvQkFBVSxFQUFDLFFBTGY7QUFBQSxvQkFNS0YsUUFBUSxnQkFDTDtBQUFBLG9DQUNJLHFFQUFDLDREQUFEO0FBQVksbUJBQUssRUFBQyxTQUFsQjtBQUE0QixxQkFBTyxFQUFFTSxXQUFyQztBQUFBLHFDQUNJLHFFQUFDLDBEQUFEO0FBQWEsb0JBQUksRUFBQyxlQUFsQjtBQUFrQyxvQkFBSSxFQUFDO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURKLGVBSUkscUVBQUMsc0RBQUQ7QUFDSSxnQkFBRSxFQUFDLFdBRFA7QUFFSSxzQkFBUSxFQUFFSCxRQUZkO0FBR0kseUJBQVcsTUFIZjtBQUlJLGtCQUFJLEVBQUVFLElBSlY7QUFLSSxxQkFBTyxFQUFFOUosV0FMYjtBQUFBLHNDQU1JLHFFQUFDLDBEQUFEO0FBQVUsdUJBQU8sRUFBRWlLLFVBQW5CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQU5KLGVBT0kscUVBQUMsMERBQUQ7QUFBVSx1QkFBTyxFQUFFeEwsWUFBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBUEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUpKO0FBQUEsMEJBREssZ0JBZ0JMLHFFQUFDLDREQUFEO0FBQVksaUJBQUssRUFBQyxTQUFsQjtBQUFBLG1DQUNJLHFFQUFDLDBEQUFEO0FBQWEsa0JBQUksRUFBQyxlQUFsQjtBQUFrQyxrQkFBSSxFQUFDO0FBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBdEJSO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBckJSO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREgsZ0JBdURHLHFFQUFDLHFEQUFEO0FBQUssZUFBUyxFQUFFdUMsT0FBTyxDQUFDa0osVUFBeEI7QUFBQSw4QkFDSTtBQUNJLGNBQU0sRUFBQyxTQURYO0FBRUksaUJBQVMsRUFBRWxKLE9BQU8sQ0FBQ21KLEtBRnZCO0FBR0ksVUFBRSxFQUFDLHVCQUhQO0FBSUksZ0JBQVEsTUFKWjtBQUtJLFlBQUksRUFBQztBQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFRSTtBQUFPLGVBQU8sRUFBQyx1QkFBZjtBQUFBLCtCQUNJLHFFQUFDLHdEQUFEO0FBQVEsaUJBQU8sRUFBQyxXQUFoQjtBQUE0QixtQkFBUyxFQUFDLE1BQXRDO0FBQUEsaUNBQ0kscUVBQUMsc0RBQUQ7QUFBQSxtQ0FDSSxxRUFBQyxxREFBRDtBQUNJLHFCQUFPLEVBQUMsTUFEWjtBQUVJLHdCQUFVLEVBQUMsUUFGZjtBQUdJLGdCQUFFLEVBQUUsQ0FIUjtBQUlJLGdCQUFFLEVBQUUsR0FKUjtBQUtJLHVCQUFTLEVBQUUsRUFMZjtBQUFBLHNDQU1JLHFFQUFDLHFEQUFEO0FBQUEsdUNBQ0kscUVBQUMsbURBQUQ7QUFDSSxzQkFBSSxFQUFFLEVBRFY7QUFFSSx3QkFBTSxFQUFFdkosT0FGWjtBQUdJLDBCQUFRLEVBQUU2SCxRQUhkO0FBSUksNkJBQVcsRUFBRSxHQUpqQjtBQUtJLDBCQUFRLEVBQUU7QUFMZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFOSixFQWVLM0gsUUFBUSxpQkFDTCxxRUFBQyxxREFBRDtBQUNJLHdCQUFRLEVBQUUsQ0FEZDtBQUVJLHVCQUFPLEVBQUMsTUFGWjtBQUdJLDZCQUFhLEVBQUMsUUFIbEI7QUFJSSw4QkFBYyxFQUFDLFFBSm5CO0FBS0ksa0JBQUUsRUFBRSxDQUxSO0FBQUEsMEJBTUtBO0FBTkw7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFoQlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQXhEUixtQkFESjtBQXFHSCxDQTdIRDs7QUErSEF1SSxVQUFVLENBQUNuSSxZQUFYLEdBQTBCO0FBQ3RCTixTQUFPLEVBQUUsU0FEYTtBQUV0QkUsVUFBUSxFQUFFLEVBRlk7QUFHdEIySCxVQUFRLEVBQUUsTUFIWTtBQUl0QmMsVUFBUSxFQUFFLFlBSlk7QUFLdEJDLFNBQU8sRUFBRVksd0RBTGE7QUFNdEJYLFVBQVEsRUFBRSxLQU5ZO0FBT3RCQyxhQUFXLEVBQUVVLHdEQVBTO0FBUXRCckgsVUFBUSxFQUFFcUgsd0RBUlk7QUFTdEJULGdCQUFjLEVBQUc7QUFUSyxDQUExQjtBQVlBTixVQUFVLENBQUNsSSxTQUFYLEdBQXVCO0FBQ25CUCxTQUFPLEVBQUVRLGlEQUFTLENBQUNDLEtBQVYsQ0FBZ0IsQ0FBQyxTQUFELEVBQVksUUFBWixFQUFzQixTQUF0QixDQUFoQixDQURVO0FBRW5Ca0ksVUFBUSxFQUFFbkksaURBQVMsQ0FBQ0MsS0FBVixDQUFnQixDQUFDLFlBQUQsRUFBZSxZQUFmLENBQWhCLENBRlM7QUFHbkJQLFVBQVEsRUFBRU0saURBQVMsQ0FBQ0UsSUFIRDtBQUluQm1ILFVBQVEsRUFBRXJILGlEQUFTLENBQUN1QixNQUpEO0FBS25CNkcsU0FBTyxFQUFFcEksaURBQVMsQ0FBQzRCLElBTEE7QUFNbkJ5RyxVQUFRLEVBQUVySSxpREFBUyxDQUFDRyxJQU5EO0FBT25CbUksYUFBVyxFQUFFdEksaURBQVMsQ0FBQzRCLElBUEo7QUFRbkJELFVBQVEsRUFBRTNCLGlEQUFTLENBQUM0QixJQVJEO0FBU25CMkcsZ0JBQWMsRUFBR3ZJLGlEQUFTLENBQUNHO0FBVFIsQ0FBdkI7QUFZZThILHlFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3BLQTtBQUFBO0FBQUE7QUFBQTtBQUVBLE1BQU1wSSxTQUFTLEdBQUdPLDJFQUFVLENBQUMsT0FBTztBQUNoQzBJLFlBQVUsRUFBRTtBQUNSLGFBQVM7QUFDTGhQLFlBQU0sRUFBRTtBQURILEtBREQ7QUFJUix5QkFBcUI7QUFDakJ4QyxXQUFLLEVBQUUsTUFEVTtBQUVqQnNDLGFBQU8sRUFBRTtBQUZRLEtBSmI7QUFRUix1QkFBbUI7QUFDZnRDLFdBQUssRUFBRTtBQURRO0FBUlgsR0FEb0I7QUFhaEN5UixPQUFLLEVBQUU7QUFDSGhQLFdBQU8sRUFBRTtBQUROLEdBYnlCO0FBZ0JoQyx5QkFBdUI7QUFDbkJILFdBQU8sRUFBRTtBQURVO0FBaEJTLENBQVAsQ0FBRCxDQUE1QjtBQXFCZWlHLHdFQUFmLEU7Ozs7Ozs7Ozs7OztBQ3ZCQTtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTtBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTW9KLFdBQVcsR0FBRyxDQUFDO0FBQUUxRztBQUFGLENBQUQsS0FBZTtBQUMvQixzQkFDSTtBQUFBLDJCQUNHLHFFQUFDLHFEQUFEO0FBQUssV0FBSyxFQUFDLGNBQVg7QUFBMEIsZ0JBQVUsRUFBQyxpQkFBckM7QUFBdUQsbUJBQWEsRUFBRSxDQUF0RTtBQUF5RSxRQUFFLEVBQUUsQ0FBN0U7QUFBZ0YsZUFBUyxFQUFDLGVBQTFGO0FBQUEsNkJBQ0sscUVBQUMsNERBQUQ7QUFBWSxlQUFPLEVBQUMsSUFBcEI7QUFBQSxrQkFDSUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURILG1CQURKO0FBU0gsQ0FWRDs7QUFXQTBHLFdBQVcsQ0FBQ25KLFlBQVosR0FBMkIsRUFBM0I7QUFDQW1KLFdBQVcsQ0FBQ2xKLFNBQVosR0FBd0I7QUFDcEJ3QyxPQUFLLEVBQUV2QyxpREFBUyxDQUFDdUI7QUFERyxDQUF4QjtBQUllMEgsMEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDMUJBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsTUFBTUMsV0FBVyxHQUFJaEIsS0FBRCxJQUFXO0FBQzNCLFFBQU07QUFDRnhJLFlBREU7QUFFRnlKLGlCQUZFO0FBR0YzSixXQUhFO0FBSUY0SixpQkFKRTtBQUtGQyxhQUxFO0FBTUZDLGtCQU5FO0FBT0ZDLFVBUEU7QUFRRmpTO0FBUkUsTUFTRjRRLEtBVEo7QUFVQSxRQUFNdEksT0FBTyxHQUFHQyxrRUFBUyxFQUF6QjtBQUNBLHNCQUNJLHFFQUFDLHFEQUFEO0FBQUssWUFBUSxFQUFDLFVBQWQ7QUFBQSwyQkFDSSxxRUFBQyxzREFBRDtBQUFBLDZCQUNJLHFFQUFDLHFEQUFEO0FBQUssZUFBTyxFQUFDLE1BQWI7QUFBQSxtQkFDS3lKLGNBQWMsaUJBQ1gscUVBQUMscURBQUQ7QUFDSSxrQkFBUSxFQUFFLEVBRGQ7QUFFSSxtQkFBUyxFQUFFLEVBRmY7QUFHSSxzQkFBWSxFQUFDLGVBSGpCO0FBSUksa0JBQVEsRUFBRWhTLEtBQUssS0FBSyxJQUFWLEdBQWlCLFFBQWpCLEdBQTRCLFVBSjFDO0FBS0ksY0FBSSxFQUFDLEdBTFQ7QUFNSSxnQkFBTSxFQUFFLENBTlo7QUFPSSxtQkFBUyxFQUFFc0ksT0FBTyxDQUFDSixPQUFEO0FBUHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRlIsRUFhSzZKLFNBQVMsaUJBQ04scUVBQUMscURBQUQ7QUFDSSxtQkFBUyxFQUFFdEYsMkNBQUksQ0FBQ25FLE9BQU8sQ0FBQzRKLE9BQVQsRUFBa0I1SixPQUFPLENBQUNKLE9BQUQsQ0FBekIsQ0FEbkI7QUFFSSxZQUFFLEVBQUUsR0FGUjtBQUdJLGlCQUFPLEVBQUVsSSxLQUFLLEtBQUssSUFBVixHQUFpQixNQUFqQixHQUEwQixTQUh2QztBQUFBLGlDQUlJLHFFQUFDLGlEQUFEO0FBQU8sZUFBRyxFQUFFaVMsTUFBWjtBQUFvQixpQkFBSyxFQUFFLEdBQTNCO0FBQWdDLGtCQUFNLEVBQUU7QUFBeEM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpKO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZFIsRUFzQks3SixRQUFRLGlCQUNMLHFFQUFDLHFEQUFEO0FBQ0ksa0JBQVEsRUFBRSxDQURkO0FBRUksWUFBRSxFQUFFLEdBRlI7QUFHSSxZQUFFLEVBQUUsQ0FIUjtBQUlJLGlCQUFPLEVBQUMsTUFKWjtBQUtJLHVCQUFhLEVBQUMsUUFMbEI7QUFNSSx3QkFBYyxFQUFDLFFBTm5CO0FBQUEsb0JBT0tBO0FBUEw7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkF2QlIsRUFrQ0t5SixhQUFhLGlCQUNWLHFFQUFDLHFEQUFEO0FBQ0ksV0FBQyxFQUFFLElBRFA7QUFFSSxZQUFFLEVBQUUsSUFGUjtBQUdJLGlCQUFPLEVBQUMsTUFIWjtBQUlJLHdCQUFjLEVBQUMsUUFKbkI7QUFLSSxvQkFBVSxFQUFDLFFBTGY7QUFBQSxpQ0FNSSxxRUFBQyw0REFBRDtBQUFBLG1DQUNJLHFFQUFDLDBEQUFEO0FBQWMsOEJBQWEsR0FBM0I7QUFBK0IsbUJBQUssRUFBQyxRQUFyQztBQUE4QyxrQkFBSSxFQUFFO0FBQXBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBTko7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFuQ1IsRUE4Q0tDLGFBQWEsaUJBQ1YscUVBQUMscURBQUQ7QUFDSSxtQkFBUyxFQUFDLFFBRGQ7QUFFSSxXQUFDLEVBQUUsR0FGUDtBQUdJLGlCQUFPLEVBQUMsWUFIWjtBQUlJLGVBQUssRUFBQyxjQUpWO0FBS0ksbUJBQVMsRUFBRSxFQUxmO0FBTUksa0JBQVEsRUFBRSxFQU5kO0FBT0ksaUJBQU8sRUFBQyxNQVBaO0FBUUksd0JBQWMsRUFBQyxRQVJuQjtBQVNJLG9CQUFVLEVBQUMsUUFUZjtBQVVJLHVCQUFhLEVBQUMsUUFWbEI7QUFXSSxnQkFBTSxFQUFFLENBWFo7QUFBQSxrQ0FZSSxxRUFBQyxvREFBRDtBQUFRLDRCQUFhLEtBQXJCO0FBQTJCLGlCQUFLLEVBQUMsT0FBakM7QUFBeUMsZ0JBQUksRUFBRTtBQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVpKLGVBYUkscUVBQUMscURBQUQ7QUFDSSxxQkFBUyxFQUFDLE9BRGQ7QUFFSSxvQkFBUSxFQUFDLGFBRmI7QUFHSSxzQkFBVSxFQUFDLG9CQUhmO0FBSUksY0FBRSxFQUFFLElBSlI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBYko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQS9DUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURKO0FBNEVILENBeEZEOztBQTBGQUYsV0FBVyxDQUFDcEosWUFBWixHQUEyQjtBQUN2QkosVUFBUSxFQUFFLEVBRGE7QUFFdkJ5SixlQUFhLEVBQUUsS0FGUTtBQUd2QkMsZUFBYSxFQUFFLEtBSFE7QUFJdkJDLFdBQVMsRUFBRSxLQUpZO0FBS3ZCQyxnQkFBYyxFQUFFLElBTE87QUFNdkJDLFFBQU0sRUFBRTtBQU5lLENBQTNCO0FBU0FMLFdBQVcsQ0FBQ25KLFNBQVosR0FBd0I7QUFDcEJQLFNBQU8sRUFBRVEsaURBQVMsQ0FBQ0MsS0FBVixDQUFnQixDQUFDLFNBQUQsRUFBWSxRQUFaLEVBQXNCLFNBQXRCLENBQWhCLENBRFc7QUFFcEJQLFVBQVEsRUFBRU0saURBQVMsQ0FBQ0UsSUFGQTtBQUdwQmlKLGVBQWEsRUFBRW5KLGlEQUFTLENBQUNHLElBSEw7QUFJcEJpSixlQUFhLEVBQUVwSixpREFBUyxDQUFDRyxJQUpMO0FBS3BCa0osV0FBUyxFQUFFckosaURBQVMsQ0FBQ0csSUFMRDtBQU1wQm1KLGdCQUFjLEVBQUV0SixpREFBUyxDQUFDRyxJQU5OO0FBT3BCb0osUUFBTSxFQUFFdkosaURBQVMsQ0FBQ3VCLE1BUEU7QUFRcEJqSyxPQUFLLEVBQUUwSSxpREFBUyxDQUFDdUI7QUFSRyxDQUF4QjtBQVdla0ksaUlBQVMsR0FBR1AsV0FBSCxDQUF4QixFOzs7Ozs7Ozs7Ozs7QUM1SEE7QUFBQTtBQUFBO0FBQUE7QUFFQSxNQUFNckosU0FBUyxHQUFHTywyRUFBVSxDQUFFQyxLQUFELEtBQVk7QUFDckNtSCxRQUFNLEVBQUU7QUFDSmpILG1CQUFlLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjaUgsS0FBZCxDQUFvQi9HLElBRGpDO0FBRUosZ0JBQVk7QUFDUmdKLGdCQUFVLEVBQUU7QUFESjtBQUZSLEdBRDZCO0FBT3JDQyxTQUFPLEVBQUU7QUFDTHBKLG1CQUFlLEVBQUVGLEtBQUssQ0FBQ0csT0FBTixDQUFjbUgsT0FBZCxDQUFzQmpILElBRGxDO0FBRUwsZ0JBQVk7QUFDUmdKLGdCQUFVLEVBQUU7QUFESjtBQUZQLEdBUDRCO0FBYXJDO0FBQ0E7QUFDQTtBQUNBM0UsU0FBTyxFQUFFO0FBQ0x4RSxtQkFBZSxFQUFFRixLQUFLLENBQUNHLE9BQU4sQ0FBY3VFLE9BQWQsQ0FBc0I1RCxLQURsQztBQUVMLGdCQUFZO0FBQ1J1SSxnQkFBVSxFQUFFO0FBREo7QUFGUCxHQWhCNEI7QUFzQnJDcE0sTUFBSSxFQUFDO0FBQ0RpRCxtQkFBZSxFQUFDRixLQUFLLENBQUNHLE9BQU4sQ0FBY2xELElBQWQsQ0FBbUJvRDtBQURsQyxHQXRCZ0M7QUF5QnJDOEksU0FBTyxFQUFFO0FBQ0xsUSxZQUFRLEVBQUUsVUFETDtBQUVMLGdCQUFZO0FBQ1IyTixhQUFPLEVBQUUsSUFERDtBQUVSM1AsV0FBSyxFQUFFLE1BRkM7QUFHUjBDLFlBQU0sRUFBRSxNQUhBO0FBSVJWLGNBQVEsRUFBRSxVQUpGO0FBS1JDLFNBQUcsRUFBRSxHQUxHO0FBTVJFLFlBQU0sRUFBRSxHQU5BO0FBT1JELFVBQUksRUFBRSxHQVBFO0FBUVJFLFdBQUssRUFBRSxHQVJDO0FBU1IrTSxZQUFNLEVBQUU7QUFUQTtBQUZQO0FBekI0QixDQUFaLENBQUQsQ0FBNUI7QUF5Q2U1Ryx3RUFBZixFOzs7Ozs7Ozs7Ozs7QUMzQ0E7QUFBQTtBQUFBO0FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNK0osUUFBUSxHQUFHLE1BQU07QUFDbkIsc0JBQ0kscUVBQUMseURBQUQ7QUFBUyx1QkFBbUIsRUFBRUMsc0RBQTlCO0FBQW9DLFNBQUssRUFBQyxLQUExQztBQUFBLDJCQUNJLHFFQUFDLHFEQUFEO0FBQ0MsYUFBTyxFQUFDLE1BRFQ7QUFFQyxnQkFBVSxFQUFDLFFBRlo7QUFHQyxjQUFRLEVBQUMsb0JBSFY7QUFJQyxnQkFBVSxFQUFDLGdCQUpaO0FBS0MsV0FBSyxFQUFDLFNBTFA7QUFBQSw4QkFRSyxxRUFBQyw2RUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJMLG9CQVFnQyxxRUFBQyxxREFBRDtBQUFLLFVBQUUsRUFBRSxDQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJoQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFESjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFhSCxDQWREOztBQWdCZUQsdUVBQWYsRTs7Ozs7Ozs7Ozs7O0FDcEJBO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQTtBQUFPLE1BQU1qRyxNQUFNLEdBQUc7QUFDbEJtRyxNQUFJLEVBQUU7QUFDRmhHLFNBQUssRUFBRSxHQURMO0FBQ1U7QUFDWmlHLFNBQUssRUFBRSxNQUZMO0FBR0ZDLFFBQUksRUFBRSxNQUhKO0FBSUZDLGdCQUFZLEVBQUU7QUFKWixHQURZO0FBT2xCQyxVQUFRLEVBQUU7QUFDTnBHLFNBQUssRUFBRSxXQUREO0FBQ2M7QUFDcEJpRyxTQUFLLEVBQUUsVUFGRDtBQUdOQyxRQUFJLEVBQUUsVUFIQTtBQUlOQyxnQkFBWSxFQUFFO0FBSlIsR0FQUTtBQWFsQnZHLFlBQVUsRUFBRTtBQUNSSSxTQUFLLEVBQUUsUUFEQztBQUNTO0FBQ2pCaUcsU0FBSyxFQUFFLE9BRkM7QUFHUkMsUUFBSSxFQUFFO0FBSEUsR0FiTTtBQWtCbEJHLE9BQUssRUFBRTtBQUNIckcsU0FBSyxFQUFFLFFBREo7QUFDYztBQUNqQmlHLFNBQUssRUFBRSxPQUZKO0FBR0hDLFFBQUksRUFBRSxPQUhIO0FBSUhDLGdCQUFZLEVBQUU7QUFKWCxHQWxCVztBQXlCbEJHLFNBQU8sRUFBRTtBQUNMO0FBQ0F0RyxTQUFLLEVBQUUsVUFGRjtBQUVjO0FBQ25CaUcsU0FBSyxFQUFFLFNBSEY7QUFJTEMsUUFBSSxFQUFFLFNBSkQ7QUFLTEMsZ0JBQVksRUFBRTtBQUxULEdBekJTO0FBZ0NsQkksU0FBTyxFQUFFO0FBQ0w7QUFDQXZHLFNBQUssRUFBRSxVQUZGO0FBRWM7QUFDbkJpRyxTQUFLLEVBQUUsU0FIRjtBQUlMQyxRQUFJLEVBQUUsU0FKRDtBQUtMQyxnQkFBWSxFQUFFO0FBTFQsR0FoQ1M7QUF3Q2xCSyxTQUFPLEVBQUU7QUFDTDtBQUNBeEcsU0FBSyxFQUFFLFVBRkY7QUFFYztBQUNuQmlHLFNBQUssRUFBRSxTQUhGO0FBSUxDLFFBQUksRUFBRSxTQUpEO0FBS0xDLGdCQUFZLEVBQUU7QUFMVCxHQXhDUztBQWdEbEJNLGdCQUFjLEVBQUU7QUFDWjtBQUNBekcsU0FBSyxFQUFFLGdCQUZLO0FBRWE7QUFDekJpRyxTQUFLLEVBQUUsZ0JBSEs7QUFJWkMsUUFBSSxFQUFFLGdCQUpNO0FBS1pDLGdCQUFZLEVBQUU7QUFMRixHQWhERTtBQXdEbEJPLGFBQVcsRUFBRTtBQUNUO0FBQ0ExRyxTQUFLLEVBQUUsYUFGRTtBQUVhO0FBQ3RCaUcsU0FBSyxFQUFFLGFBSEU7QUFJVEMsUUFBSSxFQUFFLGFBSkc7QUFLVEMsZ0JBQVksRUFBRTtBQUxMLEdBeERLO0FBZ0VsQlEsTUFBSSxFQUFFO0FBQ0Y7QUFDQTNHLFNBQUssRUFBRSxPQUZMO0FBRWM7QUFDaEJpRyxTQUFLLEVBQUUsTUFITDtBQUlGQyxRQUFJLEVBQUUsTUFKSjtBQUtGQyxnQkFBWSxFQUFFO0FBTFosR0FoRVk7QUF3RWxCUyxhQUFXLEVBQUU7QUFDVDtBQUNBNUcsU0FBSyxFQUFFLGFBRkU7QUFFYTtBQUN0QmlHLFNBQUssRUFBRSxhQUhFO0FBSVRDLFFBQUksRUFBRSxhQUpHO0FBS1RDLGdCQUFZLEVBQUU7QUFMTCxHQXhFSztBQWdGbEJVLGlCQUFlLEVBQUU7QUFDYjtBQUNBN0csU0FBSyxFQUFFLGlCQUZNO0FBRWE7QUFDMUJpRyxTQUFLLEVBQUUsaUJBSE07QUFJYkMsUUFBSSxFQUFFLGlCQUpPO0FBS2JDLGdCQUFZLEVBQUU7QUFMRCxHQWhGQztBQXdGbEJXLGlCQUFlLEVBQUU7QUFDYjlHLFNBQUssRUFBRSxpQkFETTtBQUNhO0FBQzFCaUcsU0FBSyxFQUFFLGlCQUZNO0FBR2JDLFFBQUksRUFBRSxpQkFITztBQUliQyxnQkFBWSxFQUFFO0FBSkQsR0F4RkM7QUE4RmxCWSx3QkFBc0IsRUFBRTtBQUNwQi9HLFNBQUssRUFBRSx1QkFEYTtBQUNZO0FBQ2hDaUcsU0FBSyxFQUFFLHdCQUZhO0FBR3BCQyxRQUFJLEVBQUUsd0JBSGM7QUFJcEJDLGdCQUFZLEVBQUU7QUFKTSxHQTlGTjtBQW9HbEJhLDJCQUF5QixFQUFFO0FBQ3ZCaEgsU0FBSyxFQUFFLDBCQURnQjtBQUNZO0FBQ25DaUcsU0FBSyxFQUFFLDJCQUZnQjtBQUd2QkMsUUFBSSxFQUFFLDJCQUhpQjtBQUl2QkMsZ0JBQVksRUFBRTtBQUpTLEdBcEdUO0FBMEdsQmMsa0JBQWdCLEVBQUU7QUFDZGpILFNBQUssRUFBRSwrQkFETztBQUMwQjtBQUN4Q2lHLFNBQUssRUFBRSx3QkFGTztBQUdkQyxRQUFJLEVBQUUsd0JBSFE7QUFJZEMsZ0JBQVksRUFBRTtBQUpBLEdBMUdBO0FBZ0hsQmUsc0JBQW9CLEVBQUU7QUFDbEJsSCxTQUFLLEVBQUUscUJBRFc7QUFDWTtBQUM5QmlHLFNBQUssRUFBRSxzQkFGVztBQUdsQkMsUUFBSSxFQUFFLHNCQUhZO0FBSWxCQyxnQkFBWSxFQUFFO0FBSkksR0FoSEo7QUFzSGxCZ0IscUJBQW1CLEVBQUU7QUFDakJuSCxTQUFLLEVBQUUsb0JBRFU7QUFDWTtBQUM3QmlHLFNBQUssRUFBRSxxQkFGVTtBQUdqQkMsUUFBSSxFQUFFLHFCQUhXO0FBSWpCQyxnQkFBWSxFQUFFO0FBSkcsR0F0SEg7QUE0SGxCaUIsa0JBQWdCLEVBQUU7QUFDZHBILFNBQUssRUFBRSxjQURPO0FBQ1M7QUFDdkJpRyxTQUFLLEVBQUUsYUFGTztBQUdkQyxRQUFJLEVBQUU7QUFIUSxHQTVIQTtBQWlJbEJtQixtQkFBaUIsRUFBRTtBQUNmckgsU0FBSyxFQUFFLHlCQURRO0FBQ21CO0FBQ2xDaUcsU0FBSyxFQUFFLHdCQUZRO0FBR2ZDLFFBQUksRUFBRSx3QkFIUztBQUlmQyxnQkFBWSxFQUFFO0FBSkMsR0FqSUQ7QUF1SWxCbUIsc0JBQW9CLEVBQUU7QUFDbEJ0SCxTQUFLLEVBQUUsa0JBRFc7QUFDUztBQUMzQmlHLFNBQUssRUFBRSxpQkFGVztBQUdsQkMsUUFBSSxFQUFFLGlCQUhZO0FBSWxCQyxnQkFBWSxFQUFFO0FBSkksR0F2SUo7QUE2SWxCb0IsZ0JBQWMsRUFBRTtBQUNadkgsU0FBSyxFQUFFLGlCQURLO0FBQ2M7QUFDMUJpRyxTQUFLLEVBQUUsU0FGSztBQUdaQyxRQUFJLEVBQUUsU0FITTtBQUlaQyxnQkFBWSxFQUFFO0FBSkYsR0E3SUU7QUFtSmxCcUIsd0JBQXNCLEVBQUU7QUFDcEJ4SCxTQUFLLEVBQUUsbUJBRGE7QUFDUTtBQUM1QmlHLFNBQUssRUFBRSx3QkFGYTtBQUdwQkMsUUFBSSxFQUFFLHdCQUhjO0FBSXBCQyxnQkFBWSxFQUFFO0FBSk0sR0FuSk47QUF5SmxCc0IsaUJBQWUsRUFBRTtBQUNiekgsU0FBSyxFQUFFLHdCQURNO0FBQ29CO0FBQ2pDaUcsU0FBSyxFQUFFLGlCQUZNO0FBR2JDLFFBQUksRUFBRSxpQkFITztBQUliQyxnQkFBWSxFQUFFO0FBSkQsR0F6SkM7QUErSmxCdUIsYUFBVyxFQUFFO0FBQ1QxSCxTQUFLLEVBQUUsb0JBREU7QUFDb0I7QUFDN0JpRyxTQUFLLEVBQUUsYUFGRTtBQUdUQyxRQUFJLEVBQUUsYUFIRztBQUlUQyxnQkFBWSxFQUFFO0FBSkwsR0EvSks7QUFxS2xCd0IsdUJBQXFCLEVBQUU7QUFDbkIzSCxTQUFLLEVBQUUsK0JBRFk7QUFDcUI7QUFDeENpRyxTQUFLLEVBQUUsdUJBRlk7QUFHbkJDLFFBQUksRUFBRSx1QkFIYTtBQUluQkMsZ0JBQVksRUFBRTtBQUpLLEdBcktMO0FBMktsQnlCLG1CQUFpQixFQUFFO0FBQ2Y1SCxTQUFLLEVBQUUsb0JBRFE7QUFDYztBQUM3QmlHLFNBQUssRUFBRSxtQkFGUTtBQUdmQyxRQUFJLEVBQUUsbUJBSFM7QUFJZkMsZ0JBQVksRUFBRTtBQUpDLEdBM0tEO0FBaUxsQjBCLG9CQUFrQixFQUFFO0FBQ2hCN0gsU0FBSyxFQUFFLHFCQURTO0FBQ2M7QUFDOUJpRyxTQUFLLEVBQUUsb0JBRlM7QUFHaEJDLFFBQUksRUFBRSxvQkFIVTtBQUloQkMsZ0JBQVksRUFBRTtBQUpFLEdBakxGO0FBdUxsQjJCLGtCQUFnQixFQUFFO0FBQ2Q5SCxTQUFLLEVBQUUsbUJBRE87QUFDYztBQUM1QmlHLFNBQUssRUFBRSxrQkFGTztBQUdkQyxRQUFJLEVBQUUsa0JBSFE7QUFJZEMsZ0JBQVksRUFBRTtBQUpBLEdBdkxBO0FBNkxsQjRCLGtCQUFnQixFQUFFO0FBQ2QvSCxTQUFLLEVBQUUsbUJBRE87QUFDYztBQUM1QmlHLFNBQUssRUFBRSxrQkFGTztBQUdkQyxRQUFJLEVBQUUsa0JBSFE7QUFJZEMsZ0JBQVksRUFBRTtBQUpBLEdBN0xBO0FBbU1sQjZCLDRCQUEwQixFQUFFO0FBQ3hCaEksU0FBSyxFQUFFLDZCQURpQjtBQUNjO0FBQ3RDaUcsU0FBSyxFQUFFLDRCQUZpQjtBQUd4QkMsUUFBSSxFQUFFLDRCQUhrQjtBQUl4QkMsZ0JBQVksRUFBRTtBQUpVLEdBbk1WO0FBeU1sQjhCLG9CQUFrQixFQUFFO0FBQ2hCakksU0FBSyxFQUFFLHFCQURTO0FBQ2M7QUFDOUJpRyxTQUFLLEVBQUUsb0JBRlM7QUFHaEJDLFFBQUksRUFBRSxvQkFIVTtBQUloQkMsZ0JBQVksRUFBRTtBQUpFLEdBek1GO0FBK01sQitCLGdCQUFjLEVBQUU7QUFDWmxJLFNBQUssRUFBRSxpQkFESztBQUNjO0FBQzFCaUcsU0FBSyxFQUFFLGdCQUZLO0FBR1pDLFFBQUksRUFBRSxnQkFITTtBQUlaQyxnQkFBWSxFQUFFO0FBSkYsR0EvTUU7QUFxTmxCZ0MsaUJBQWUsRUFBRTtBQUNibkksU0FBSyxFQUFFLGtCQURNO0FBQ2M7QUFDM0JpRyxTQUFLLEVBQUUsaUJBRk07QUFHYkMsUUFBSSxFQUFFLGlCQUhPO0FBSWJDLGdCQUFZLEVBQUU7QUFKRDtBQXJOQyxDQUFmLEM7Ozs7Ozs7Ozs7OztBQ0FQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLE1BQU1pQyxlQUFlLEdBQUcsQ0FBQ0MsR0FBRCxFQUFNM08sS0FBTixLQUFnQjtBQUMzQyxNQUFJNE8sWUFBWSxHQUFHNU8sS0FBbkI7O0FBQ0EsTUFBSSxPQUFPQSxLQUFQLEtBQWlCLFFBQXJCLEVBQStCO0FBQzNCNE8sZ0JBQVksR0FBRzFULElBQUksQ0FBQzJULFNBQUwsQ0FBZTdPLEtBQWYsQ0FBZjtBQUNIOztBQUNEOE8sUUFBTSxDQUFDQyxZQUFQLENBQW9CQyxPQUFwQixDQUE0QkwsR0FBNUIsRUFBaUNDLFlBQWpDO0FBQ0gsQ0FOTTtBQVFQO0FBQ0E7QUFDQTtBQUNBOztBQUNPLE1BQU1LLGVBQWUsR0FBSU4sR0FBRCxJQUFTO0FBQ3BDLFFBQU0zTyxLQUFLLEdBQUc4TyxNQUFNLENBQUNDLFlBQVAsQ0FBb0JHLE9BQXBCLENBQTRCUCxHQUE1QixDQUFkO0FBQ0EsU0FBTzNPLEtBQUssSUFBSTlFLElBQUksQ0FBQ2lVLEtBQUwsQ0FBV25QLEtBQVgsQ0FBaEI7QUFDSCxDQUhNO0FBS1A7QUFDQTtBQUNBOztBQUNPLE1BQU1vUCxrQkFBa0IsR0FBSVQsR0FBRCxJQUFTO0FBQ3ZDLFFBQU0zTyxLQUFLLEdBQUdpUCxlQUFlLENBQUNOLEdBQUQsQ0FBN0I7QUFDQUcsUUFBTSxDQUFDQyxZQUFQLENBQW9CTSxVQUFwQixDQUErQlYsR0FBL0I7QUFDQSxTQUFPM08sS0FBUDtBQUNILENBSk0sQzs7Ozs7Ozs7Ozs7O0FDekJQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0NBRUE7O0FBQ08sTUFBTXNQLFVBQVUsR0FBRyxNQUFNO0FBQzVCLFNBQU9oVyx3QkFBUDtBQUNILENBRk0sQyxDQUdQOztBQUNPLE1BQU1rUyxJQUFJLEdBQUcsTUFBTSxDQUFFLENBQXJCO0FBRUEsTUFBTStELGNBQWMsR0FBRyxNQUFNO0FBQ2hDLFNBQU9qVyxlQUFQO0FBQ0gsQ0FGTTtBQUlBLE1BQU1rVyxTQUFTLEdBQUcsTUFBTTtBQUMzQixRQUFNQyxVQUFVLEdBQUdSLHFFQUFlLENBQUMsY0FBRCxDQUFmLElBQW1DLEVBQXREO0FBQ0EsU0FBT1EsVUFBUCxhQUFPQSxVQUFQLHVCQUFPQSxVQUFVLENBQUVDLE9BQW5CO0FBQ0gsQ0FITTtBQUtBLE1BQU1DLGNBQWMsR0FBRyxNQUFNO0FBQ2hDLFFBQU1GLFVBQVUsR0FBR1IscUVBQWUsQ0FBQyxjQUFELENBQWYsSUFBbUMsRUFBdEQ7QUFDQSxTQUFPUSxVQUFQLGFBQU9BLFVBQVAsdUJBQU9BLFVBQVUsQ0FBRUcsWUFBbkI7QUFDSCxDQUhNLEM7Ozs7Ozs7Ozs7O0FDbEJQLDhDOzs7Ozs7Ozs7OztBQ0FBLG9EOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLDREOzs7Ozs7Ozs7OztBQ0FBLHdEOzs7Ozs7Ozs7OztBQ0FBLHFEOzs7Ozs7Ozs7OztBQ0FBLDZEOzs7Ozs7Ozs7OztBQ0FBLGtFOzs7Ozs7Ozs7OztBQ0FBLG1FOzs7Ozs7Ozs7OztBQ0FBLDZDOzs7Ozs7Ozs7OztBQ0FBLGlDOzs7Ozs7Ozs7OztBQ0FBLGdEOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLHVDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLDBDOzs7Ozs7Ozs7OztBQ0FBLGtEIiwiZmlsZSI6InBhZ2VzL2NvbW1vbmNvbXBvbmVudHN0eWxlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSByZXF1aXJlKCcuLi9zc3ItbW9kdWxlLWNhY2hlLmpzJyk7XG5cbiBcdC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gXHRmdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cbiBcdFx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG4gXHRcdGlmKGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdKSB7XG4gXHRcdFx0cmV0dXJuIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdLmV4cG9ydHM7XG4gXHRcdH1cbiBcdFx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcbiBcdFx0dmFyIG1vZHVsZSA9IGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdID0ge1xuIFx0XHRcdGk6IG1vZHVsZUlkLFxuIFx0XHRcdGw6IGZhbHNlLFxuIFx0XHRcdGV4cG9ydHM6IHt9XG4gXHRcdH07XG5cbiBcdFx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG4gXHRcdHZhciB0aHJldyA9IHRydWU7XG4gXHRcdHRyeSB7XG4gXHRcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG4gXHRcdFx0dGhyZXcgPSBmYWxzZTtcbiBcdFx0fSBmaW5hbGx5IHtcbiBcdFx0XHRpZih0aHJldykgZGVsZXRlIGluc3RhbGxlZE1vZHVsZXNbbW9kdWxlSWRdO1xuIFx0XHR9XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZ2V0dGVyIH0pO1xuIFx0XHR9XG4gXHR9O1xuXG4gXHQvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSBmdW5jdGlvbihleHBvcnRzKSB7XG4gXHRcdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuIFx0XHR9XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG4gXHR9O1xuXG4gXHQvLyBjcmVhdGUgYSBmYWtlIG5hbWVzcGFjZSBvYmplY3RcbiBcdC8vIG1vZGUgJiAxOiB2YWx1ZSBpcyBhIG1vZHVsZSBpZCwgcmVxdWlyZSBpdFxuIFx0Ly8gbW9kZSAmIDI6IG1lcmdlIGFsbCBwcm9wZXJ0aWVzIG9mIHZhbHVlIGludG8gdGhlIG5zXG4gXHQvLyBtb2RlICYgNDogcmV0dXJuIHZhbHVlIHdoZW4gYWxyZWFkeSBucyBvYmplY3RcbiBcdC8vIG1vZGUgJiA4fDE6IGJlaGF2ZSBsaWtlIHJlcXVpcmVcbiBcdF9fd2VicGFja19yZXF1aXJlX18udCA9IGZ1bmN0aW9uKHZhbHVlLCBtb2RlKSB7XG4gXHRcdGlmKG1vZGUgJiAxKSB2YWx1ZSA9IF9fd2VicGFja19yZXF1aXJlX18odmFsdWUpO1xuIFx0XHRpZihtb2RlICYgOCkgcmV0dXJuIHZhbHVlO1xuIFx0XHRpZigobW9kZSAmIDQpICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdmFsdWUgJiYgdmFsdWUuX19lc01vZHVsZSkgcmV0dXJuIHZhbHVlO1xuIFx0XHR2YXIgbnMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLnIobnMpO1xuIFx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkobnMsICdkZWZhdWx0JywgeyBlbnVtZXJhYmxlOiB0cnVlLCB2YWx1ZTogdmFsdWUgfSk7XG4gXHRcdGlmKG1vZGUgJiAyICYmIHR5cGVvZiB2YWx1ZSAhPSAnc3RyaW5nJykgZm9yKHZhciBrZXkgaW4gdmFsdWUpIF9fd2VicGFja19yZXF1aXJlX18uZChucywga2V5LCBmdW5jdGlvbihrZXkpIHsgcmV0dXJuIHZhbHVlW2tleV07IH0uYmluZChudWxsLCBrZXkpKTtcbiBcdFx0cmV0dXJuIG5zO1xuIFx0fTtcblxuIFx0Ly8gZ2V0RGVmYXVsdEV4cG9ydCBmdW5jdGlvbiBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIG5vbi1oYXJtb255IG1vZHVsZXNcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubiA9IGZ1bmN0aW9uKG1vZHVsZSkge1xuIFx0XHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cbiBcdFx0XHRmdW5jdGlvbiBnZXREZWZhdWx0KCkgeyByZXR1cm4gbW9kdWxlWydkZWZhdWx0J107IH0gOlxuIFx0XHRcdGZ1bmN0aW9uIGdldE1vZHVsZUV4cG9ydHMoKSB7IHJldHVybiBtb2R1bGU7IH07XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18uZChnZXR0ZXIsICdhJywgZ2V0dGVyKTtcbiBcdFx0cmV0dXJuIGdldHRlcjtcbiBcdH07XG5cbiBcdC8vIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbFxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5vID0gZnVuY3Rpb24ob2JqZWN0LCBwcm9wZXJ0eSkgeyByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iamVjdCwgcHJvcGVydHkpOyB9O1xuXG4gXHQvLyBfX3dlYnBhY2tfcHVibGljX3BhdGhfX1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5wID0gXCJcIjtcblxuXG4gXHQvLyBMb2FkIGVudHJ5IG1vZHVsZSBhbmQgcmV0dXJuIGV4cG9ydHNcbiBcdHJldHVybiBfX3dlYnBhY2tfcmVxdWlyZV9fKF9fd2VicGFja19yZXF1aXJlX18ucyA9IFwiLi9zcmMvcGFnZXMvY29tbW9uY29tcG9uZW50c3R5bGUvaW5kZXguanNcIik7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL2hlYWQuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0LmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9zZXJ2ZXIvaW1hZ2UtY29uZmlnLmpzXCIpOyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcbmltcG9ydCBIZWFkIGZyb20gJy4uL25leHQtc2VydmVyL2xpYi9oZWFkJ1xuaW1wb3J0IHsgdG9CYXNlNjQgfSBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvdG8tYmFzZS02NCdcbmltcG9ydCB7XG4gIEltYWdlQ29uZmlnLFxuICBpbWFnZUNvbmZpZ0RlZmF1bHQsXG4gIExvYWRlclZhbHVlLFxuICBWQUxJRF9MT0FERVJTLFxufSBmcm9tICcuLi9uZXh0LXNlcnZlci9zZXJ2ZXIvaW1hZ2UtY29uZmlnJ1xuaW1wb3J0IHsgdXNlSW50ZXJzZWN0aW9uIH0gZnJvbSAnLi91c2UtaW50ZXJzZWN0aW9uJ1xuXG5pZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgOyhnbG9iYWwgYXMgYW55KS5fX05FWFRfSU1BR0VfSU1QT1JURUQgPSB0cnVlXG59XG5cbmNvbnN0IFZBTElEX0xPQURJTkdfVkFMVUVTID0gWydsYXp5JywgJ2VhZ2VyJywgdW5kZWZpbmVkXSBhcyBjb25zdFxudHlwZSBMb2FkaW5nVmFsdWUgPSB0eXBlb2YgVkFMSURfTE9BRElOR19WQUxVRVNbbnVtYmVyXVxuXG5leHBvcnQgdHlwZSBJbWFnZUxvYWRlciA9IChyZXNvbHZlclByb3BzOiBJbWFnZUxvYWRlclByb3BzKSA9PiBzdHJpbmdcblxuZXhwb3J0IHR5cGUgSW1hZ2VMb2FkZXJQcm9wcyA9IHtcbiAgc3JjOiBzdHJpbmdcbiAgd2lkdGg6IG51bWJlclxuICBxdWFsaXR5PzogbnVtYmVyXG59XG5cbnR5cGUgRGVmYXVsdEltYWdlTG9hZGVyUHJvcHMgPSBJbWFnZUxvYWRlclByb3BzICYgeyByb290OiBzdHJpbmcgfVxuXG5jb25zdCBsb2FkZXJzID0gbmV3IE1hcDxcbiAgTG9hZGVyVmFsdWUsXG4gIChwcm9wczogRGVmYXVsdEltYWdlTG9hZGVyUHJvcHMpID0+IHN0cmluZ1xuPihbXG4gIFsnaW1naXgnLCBpbWdpeExvYWRlcl0sXG4gIFsnY2xvdWRpbmFyeScsIGNsb3VkaW5hcnlMb2FkZXJdLFxuICBbJ2FrYW1haScsIGFrYW1haUxvYWRlcl0sXG4gIFsnZGVmYXVsdCcsIGRlZmF1bHRMb2FkZXJdLFxuXSlcblxuY29uc3QgVkFMSURfTEFZT1VUX1ZBTFVFUyA9IFtcbiAgJ2ZpbGwnLFxuICAnZml4ZWQnLFxuICAnaW50cmluc2ljJyxcbiAgJ3Jlc3BvbnNpdmUnLFxuICB1bmRlZmluZWQsXG5dIGFzIGNvbnN0XG50eXBlIExheW91dFZhbHVlID0gdHlwZW9mIFZBTElEX0xBWU9VVF9WQUxVRVNbbnVtYmVyXVxuXG50eXBlIEltZ0VsZW1lbnRTdHlsZSA9IE5vbk51bGxhYmxlPEpTWC5JbnRyaW5zaWNFbGVtZW50c1snaW1nJ11bJ3N0eWxlJ10+XG5cbmV4cG9ydCB0eXBlIEltYWdlUHJvcHMgPSBPbWl0PFxuICBKU1guSW50cmluc2ljRWxlbWVudHNbJ2ltZyddLFxuICAnc3JjJyB8ICdzcmNTZXQnIHwgJ3JlZicgfCAnd2lkdGgnIHwgJ2hlaWdodCcgfCAnbG9hZGluZycgfCAnc3R5bGUnXG4+ICYge1xuICBzcmM6IHN0cmluZ1xuICBsb2FkZXI/OiBJbWFnZUxvYWRlclxuICBxdWFsaXR5PzogbnVtYmVyIHwgc3RyaW5nXG4gIHByaW9yaXR5PzogYm9vbGVhblxuICBsb2FkaW5nPzogTG9hZGluZ1ZhbHVlXG4gIHVub3B0aW1pemVkPzogYm9vbGVhblxuICBvYmplY3RGaXQ/OiBJbWdFbGVtZW50U3R5bGVbJ29iamVjdEZpdCddXG4gIG9iamVjdFBvc2l0aW9uPzogSW1nRWxlbWVudFN0eWxlWydvYmplY3RQb3NpdGlvbiddXG59ICYgKFxuICAgIHwge1xuICAgICAgICB3aWR0aD86IG5ldmVyXG4gICAgICAgIGhlaWdodD86IG5ldmVyXG4gICAgICAgIC8qKiBAZGVwcmVjYXRlZCBVc2UgYGxheW91dD1cImZpbGxcImAgaW5zdGVhZCAqL1xuICAgICAgICB1bnNpemVkOiB0cnVlXG4gICAgICB9XG4gICAgfCB7IHdpZHRoPzogbmV2ZXI7IGhlaWdodD86IG5ldmVyOyBsYXlvdXQ6ICdmaWxsJyB9XG4gICAgfCB7XG4gICAgICAgIHdpZHRoOiBudW1iZXIgfCBzdHJpbmdcbiAgICAgICAgaGVpZ2h0OiBudW1iZXIgfCBzdHJpbmdcbiAgICAgICAgbGF5b3V0PzogRXhjbHVkZTxMYXlvdXRWYWx1ZSwgJ2ZpbGwnPlxuICAgICAgfVxuICApXG5cbmNvbnN0IHtcbiAgZGV2aWNlU2l6ZXM6IGNvbmZpZ0RldmljZVNpemVzLFxuICBpbWFnZVNpemVzOiBjb25maWdJbWFnZVNpemVzLFxuICBsb2FkZXI6IGNvbmZpZ0xvYWRlcixcbiAgcGF0aDogY29uZmlnUGF0aCxcbiAgZG9tYWluczogY29uZmlnRG9tYWlucyxcbn0gPVxuICAoKHByb2Nlc3MuZW52Ll9fTkVYVF9JTUFHRV9PUFRTIGFzIGFueSkgYXMgSW1hZ2VDb25maWcpIHx8IGltYWdlQ29uZmlnRGVmYXVsdFxuLy8gc29ydCBzbWFsbGVzdCB0byBsYXJnZXN0XG5jb25zdCBhbGxTaXplcyA9IFsuLi5jb25maWdEZXZpY2VTaXplcywgLi4uY29uZmlnSW1hZ2VTaXplc11cbmNvbmZpZ0RldmljZVNpemVzLnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuYWxsU2l6ZXMuc29ydCgoYSwgYikgPT4gYSAtIGIpXG5cbmZ1bmN0aW9uIGdldFdpZHRocyhcbiAgd2lkdGg6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgbGF5b3V0OiBMYXlvdXRWYWx1ZVxuKTogeyB3aWR0aHM6IG51bWJlcltdOyBraW5kOiAndycgfCAneCcgfSB7XG4gIGlmIChcbiAgICB0eXBlb2Ygd2lkdGggIT09ICdudW1iZXInIHx8XG4gICAgbGF5b3V0ID09PSAnZmlsbCcgfHxcbiAgICBsYXlvdXQgPT09ICdyZXNwb25zaXZlJ1xuICApIHtcbiAgICByZXR1cm4geyB3aWR0aHM6IGNvbmZpZ0RldmljZVNpemVzLCBraW5kOiAndycgfVxuICB9XG5cbiAgY29uc3Qgd2lkdGhzID0gW1xuICAgIC4uLm5ldyBTZXQoXG4gICAgICAvLyA+IFRoaXMgbWVhbnMgdGhhdCBtb3N0IE9MRUQgc2NyZWVucyB0aGF0IHNheSB0aGV5IGFyZSAzeCByZXNvbHV0aW9uLFxuICAgICAgLy8gPiBhcmUgYWN0dWFsbHkgM3ggaW4gdGhlIGdyZWVuIGNvbG9yLCBidXQgb25seSAxLjV4IGluIHRoZSByZWQgYW5kXG4gICAgICAvLyA+IGJsdWUgY29sb3JzLiBTaG93aW5nIGEgM3ggcmVzb2x1dGlvbiBpbWFnZSBpbiB0aGUgYXBwIHZzIGEgMnhcbiAgICAgIC8vID4gcmVzb2x1dGlvbiBpbWFnZSB3aWxsIGJlIHZpc3VhbGx5IHRoZSBzYW1lLCB0aG91Z2ggdGhlIDN4IGltYWdlXG4gICAgICAvLyA+IHRha2VzIHNpZ25pZmljYW50bHkgbW9yZSBkYXRhLiBFdmVuIHRydWUgM3ggcmVzb2x1dGlvbiBzY3JlZW5zIGFyZVxuICAgICAgLy8gPiB3YXN0ZWZ1bCBhcyB0aGUgaHVtYW4gZXllIGNhbm5vdCBzZWUgdGhhdCBsZXZlbCBvZiBkZXRhaWwgd2l0aG91dFxuICAgICAgLy8gPiBzb21ldGhpbmcgbGlrZSBhIG1hZ25pZnlpbmcgZ2xhc3MuXG4gICAgICAvLyBodHRwczovL2Jsb2cudHdpdHRlci5jb20vZW5naW5lZXJpbmcvZW5fdXMvdG9waWNzL2luZnJhc3RydWN0dXJlLzIwMTkvY2FwcGluZy1pbWFnZS1maWRlbGl0eS1vbi11bHRyYS1oaWdoLXJlc29sdXRpb24tZGV2aWNlcy5odG1sXG4gICAgICBbd2lkdGgsIHdpZHRoICogMiAvKiwgd2lkdGggKiAzKi9dLm1hcChcbiAgICAgICAgKHcpID0+IGFsbFNpemVzLmZpbmQoKHApID0+IHAgPj0gdykgfHwgYWxsU2l6ZXNbYWxsU2l6ZXMubGVuZ3RoIC0gMV1cbiAgICAgIClcbiAgICApLFxuICBdXG4gIHJldHVybiB7IHdpZHRocywga2luZDogJ3gnIH1cbn1cblxudHlwZSBHZW5JbWdBdHRyc0RhdGEgPSB7XG4gIHNyYzogc3RyaW5nXG4gIHVub3B0aW1pemVkOiBib29sZWFuXG4gIGxheW91dDogTGF5b3V0VmFsdWVcbiAgbG9hZGVyOiBJbWFnZUxvYWRlclxuICB3aWR0aD86IG51bWJlclxuICBxdWFsaXR5PzogbnVtYmVyXG4gIHNpemVzPzogc3RyaW5nXG59XG5cbnR5cGUgR2VuSW1nQXR0cnNSZXN1bHQgPSB7XG4gIHNyYzogc3RyaW5nXG4gIHNyY1NldDogc3RyaW5nIHwgdW5kZWZpbmVkXG4gIHNpemVzOiBzdHJpbmcgfCB1bmRlZmluZWRcbn1cblxuZnVuY3Rpb24gZ2VuZXJhdGVJbWdBdHRycyh7XG4gIHNyYyxcbiAgdW5vcHRpbWl6ZWQsXG4gIGxheW91dCxcbiAgd2lkdGgsXG4gIHF1YWxpdHksXG4gIHNpemVzLFxuICBsb2FkZXIsXG59OiBHZW5JbWdBdHRyc0RhdGEpOiBHZW5JbWdBdHRyc1Jlc3VsdCB7XG4gIGlmICh1bm9wdGltaXplZCkge1xuICAgIHJldHVybiB7IHNyYywgc3JjU2V0OiB1bmRlZmluZWQsIHNpemVzOiB1bmRlZmluZWQgfVxuICB9XG5cbiAgY29uc3QgeyB3aWR0aHMsIGtpbmQgfSA9IGdldFdpZHRocyh3aWR0aCwgbGF5b3V0KVxuICBjb25zdCBsYXN0ID0gd2lkdGhzLmxlbmd0aCAtIDFcblxuICByZXR1cm4ge1xuICAgIHNyYzogbG9hZGVyKHsgc3JjLCBxdWFsaXR5LCB3aWR0aDogd2lkdGhzW2xhc3RdIH0pLFxuICAgIHNpemVzOiAhc2l6ZXMgJiYga2luZCA9PT0gJ3cnID8gJzEwMHZ3JyA6IHNpemVzLFxuICAgIHNyY1NldDogd2lkdGhzXG4gICAgICAubWFwKFxuICAgICAgICAodywgaSkgPT5cbiAgICAgICAgICBgJHtsb2FkZXIoeyBzcmMsIHF1YWxpdHksIHdpZHRoOiB3IH0pfSAke1xuICAgICAgICAgICAga2luZCA9PT0gJ3cnID8gdyA6IGkgKyAxXG4gICAgICAgICAgfSR7a2luZH1gXG4gICAgICApXG4gICAgICAuam9pbignLCAnKSxcbiAgfVxufVxuXG5mdW5jdGlvbiBnZXRJbnQoeDogdW5rbm93bik6IG51bWJlciB8IHVuZGVmaW5lZCB7XG4gIGlmICh0eXBlb2YgeCA9PT0gJ251bWJlcicpIHtcbiAgICByZXR1cm4geFxuICB9XG4gIGlmICh0eXBlb2YgeCA9PT0gJ3N0cmluZycpIHtcbiAgICByZXR1cm4gcGFyc2VJbnQoeCwgMTApXG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZFxufVxuXG5mdW5jdGlvbiBkZWZhdWx0SW1hZ2VMb2FkZXIobG9hZGVyUHJvcHM6IEltYWdlTG9hZGVyUHJvcHMpIHtcbiAgY29uc3QgbG9hZCA9IGxvYWRlcnMuZ2V0KGNvbmZpZ0xvYWRlcilcbiAgaWYgKGxvYWQpIHtcbiAgICByZXR1cm4gbG9hZCh7IHJvb3Q6IGNvbmZpZ1BhdGgsIC4uLmxvYWRlclByb3BzIH0pXG4gIH1cbiAgdGhyb3cgbmV3IEVycm9yKFxuICAgIGBVbmtub3duIFwibG9hZGVyXCIgZm91bmQgaW4gXCJuZXh0LmNvbmZpZy5qc1wiLiBFeHBlY3RlZDogJHtWQUxJRF9MT0FERVJTLmpvaW4oXG4gICAgICAnLCAnXG4gICAgKX0uIFJlY2VpdmVkOiAke2NvbmZpZ0xvYWRlcn1gXG4gIClcbn1cblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSW1hZ2Uoe1xuICBzcmMsXG4gIHNpemVzLFxuICB1bm9wdGltaXplZCA9IGZhbHNlLFxuICBwcmlvcml0eSA9IGZhbHNlLFxuICBsb2FkaW5nLFxuICBjbGFzc05hbWUsXG4gIHF1YWxpdHksXG4gIHdpZHRoLFxuICBoZWlnaHQsXG4gIG9iamVjdEZpdCxcbiAgb2JqZWN0UG9zaXRpb24sXG4gIGxvYWRlciA9IGRlZmF1bHRJbWFnZUxvYWRlcixcbiAgLi4uYWxsXG59OiBJbWFnZVByb3BzKSB7XG4gIGxldCByZXN0OiBQYXJ0aWFsPEltYWdlUHJvcHM+ID0gYWxsXG4gIGxldCBsYXlvdXQ6IE5vbk51bGxhYmxlPExheW91dFZhbHVlPiA9IHNpemVzID8gJ3Jlc3BvbnNpdmUnIDogJ2ludHJpbnNpYydcbiAgbGV0IHVuc2l6ZWQgPSBmYWxzZVxuICBpZiAoJ3Vuc2l6ZWQnIGluIHJlc3QpIHtcbiAgICB1bnNpemVkID0gQm9vbGVhbihyZXN0LnVuc2l6ZWQpXG4gICAgLy8gUmVtb3ZlIHByb3BlcnR5IHNvIGl0J3Mgbm90IHNwcmVhZCBpbnRvIGltYWdlOlxuICAgIGRlbGV0ZSByZXN0Wyd1bnNpemVkJ11cbiAgfSBlbHNlIGlmICgnbGF5b3V0JyBpbiByZXN0KSB7XG4gICAgLy8gT3ZlcnJpZGUgZGVmYXVsdCBsYXlvdXQgaWYgdGhlIHVzZXIgc3BlY2lmaWVkIG9uZTpcbiAgICBpZiAocmVzdC5sYXlvdXQpIGxheW91dCA9IHJlc3QubGF5b3V0XG5cbiAgICAvLyBSZW1vdmUgcHJvcGVydHkgc28gaXQncyBub3Qgc3ByZWFkIGludG8gaW1hZ2U6XG4gICAgZGVsZXRlIHJlc3RbJ2xheW91dCddXG4gIH1cblxuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGlmICghc3JjKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBJbWFnZSBpcyBtaXNzaW5nIHJlcXVpcmVkIFwic3JjXCIgcHJvcGVydHkuIE1ha2Ugc3VyZSB5b3UgcGFzcyBcInNyY1wiIGluIHByb3BzIHRvIHRoZSBcXGBuZXh0L2ltYWdlXFxgIGNvbXBvbmVudC4gUmVjZWl2ZWQ6ICR7SlNPTi5zdHJpbmdpZnkoXG4gICAgICAgICAgeyB3aWR0aCwgaGVpZ2h0LCBxdWFsaXR5IH1cbiAgICAgICAgKX1gXG4gICAgICApXG4gICAgfVxuICAgIGlmICghVkFMSURfTEFZT1VUX1ZBTFVFUy5pbmNsdWRlcyhsYXlvdXQpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBpbnZhbGlkIFwibGF5b3V0XCIgcHJvcGVydHkuIFByb3ZpZGVkIFwiJHtsYXlvdXR9XCIgc2hvdWxkIGJlIG9uZSBvZiAke1ZBTElEX0xBWU9VVF9WQUxVRVMubWFwKFxuICAgICAgICAgIFN0cmluZ1xuICAgICAgICApLmpvaW4oJywnKX0uYFxuICAgICAgKVxuICAgIH1cbiAgICBpZiAoIVZBTElEX0xPQURJTkdfVkFMVUVTLmluY2x1ZGVzKGxvYWRpbmcpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBpbnZhbGlkIFwibG9hZGluZ1wiIHByb3BlcnR5LiBQcm92aWRlZCBcIiR7bG9hZGluZ31cIiBzaG91bGQgYmUgb25lIG9mICR7VkFMSURfTE9BRElOR19WQUxVRVMubWFwKFxuICAgICAgICAgIFN0cmluZ1xuICAgICAgICApLmpvaW4oJywnKX0uYFxuICAgICAgKVxuICAgIH1cbiAgICBpZiAocHJpb3JpdHkgJiYgbG9hZGluZyA9PT0gJ2xhenknKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBib3RoIFwicHJpb3JpdHlcIiBhbmQgXCJsb2FkaW5nPSdsYXp5J1wiIHByb3BlcnRpZXMuIE9ubHkgb25lIHNob3VsZCBiZSB1c2VkLmBcbiAgICAgIClcbiAgICB9XG4gICAgaWYgKHVuc2l6ZWQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgaGFzIGRlcHJlY2F0ZWQgXCJ1bnNpemVkXCIgcHJvcGVydHksIHdoaWNoIHdhcyByZW1vdmVkIGluIGZhdm9yIG9mIHRoZSBcImxheW91dD0nZmlsbCdcIiBwcm9wZXJ0eWBcbiAgICAgIClcbiAgICB9XG4gIH1cblxuICBsZXQgaXNMYXp5ID1cbiAgICAhcHJpb3JpdHkgJiYgKGxvYWRpbmcgPT09ICdsYXp5JyB8fCB0eXBlb2YgbG9hZGluZyA9PT0gJ3VuZGVmaW5lZCcpXG4gIGlmIChzcmMgJiYgc3JjLnN0YXJ0c1dpdGgoJ2RhdGE6JykpIHtcbiAgICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9IVFRQL0Jhc2ljc19vZl9IVFRQL0RhdGFfVVJJc1xuICAgIHVub3B0aW1pemVkID0gdHJ1ZVxuICAgIGlzTGF6eSA9IGZhbHNlXG4gIH1cblxuICBjb25zdCBbc2V0UmVmLCBpc0ludGVyc2VjdGVkXSA9IHVzZUludGVyc2VjdGlvbjxIVE1MSW1hZ2VFbGVtZW50Pih7XG4gICAgcm9vdE1hcmdpbjogJzIwMHB4JyxcbiAgICBkaXNhYmxlZDogIWlzTGF6eSxcbiAgfSlcbiAgY29uc3QgaXNWaXNpYmxlID0gIWlzTGF6eSB8fCBpc0ludGVyc2VjdGVkXG5cbiAgY29uc3Qgd2lkdGhJbnQgPSBnZXRJbnQod2lkdGgpXG4gIGNvbnN0IGhlaWdodEludCA9IGdldEludChoZWlnaHQpXG4gIGNvbnN0IHF1YWxpdHlJbnQgPSBnZXRJbnQocXVhbGl0eSlcblxuICBsZXQgd3JhcHBlclN0eWxlOiBKU1guSW50cmluc2ljRWxlbWVudHNbJ2RpdiddWydzdHlsZSddIHwgdW5kZWZpbmVkXG4gIGxldCBzaXplclN0eWxlOiBKU1guSW50cmluc2ljRWxlbWVudHNbJ2RpdiddWydzdHlsZSddIHwgdW5kZWZpbmVkXG4gIGxldCBzaXplclN2Zzogc3RyaW5nIHwgdW5kZWZpbmVkXG4gIGxldCBpbWdTdHlsZTogSW1nRWxlbWVudFN0eWxlIHwgdW5kZWZpbmVkID0ge1xuICAgIHZpc2liaWxpdHk6IGlzVmlzaWJsZSA/ICdpbmhlcml0JyA6ICdoaWRkZW4nLFxuXG4gICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgdG9wOiAwLFxuICAgIGxlZnQ6IDAsXG4gICAgYm90dG9tOiAwLFxuICAgIHJpZ2h0OiAwLFxuXG4gICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgcGFkZGluZzogMCxcbiAgICBib3JkZXI6ICdub25lJyxcbiAgICBtYXJnaW46ICdhdXRvJyxcblxuICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgd2lkdGg6IDAsXG4gICAgaGVpZ2h0OiAwLFxuICAgIG1pbldpZHRoOiAnMTAwJScsXG4gICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICBtaW5IZWlnaHQ6ICcxMDAlJyxcbiAgICBtYXhIZWlnaHQ6ICcxMDAlJyxcblxuICAgIG9iamVjdEZpdCxcbiAgICBvYmplY3RQb3NpdGlvbixcbiAgfVxuICBpZiAoXG4gICAgdHlwZW9mIHdpZHRoSW50ICE9PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiBoZWlnaHRJbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgbGF5b3V0ICE9PSAnZmlsbCdcbiAgKSB7XG4gICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiAvPlxuICAgIGNvbnN0IHF1b3RpZW50ID0gaGVpZ2h0SW50IC8gd2lkdGhJbnRcbiAgICBjb25zdCBwYWRkaW5nVG9wID0gaXNOYU4ocXVvdGllbnQpID8gJzEwMCUnIDogYCR7cXVvdGllbnQgKiAxMDB9JWBcbiAgICBpZiAobGF5b3V0ID09PSAncmVzcG9uc2l2ZScpIHtcbiAgICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgbGF5b3V0PVwicmVzcG9uc2l2ZVwiIC8+XG4gICAgICB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICAgIGRpc3BsYXk6ICdibG9jaycsXG4gICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG5cbiAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgIG1hcmdpbjogMCxcbiAgICAgIH1cbiAgICAgIHNpemVyU3R5bGUgPSB7IGRpc3BsYXk6ICdibG9jaycsIGJveFNpemluZzogJ2JvcmRlci1ib3gnLCBwYWRkaW5nVG9wIH1cbiAgICB9IGVsc2UgaWYgKGxheW91dCA9PT0gJ2ludHJpbnNpYycpIHtcbiAgICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIHdpZHRoPVwiMTAwXCIgaGVpZ2h0PVwiMTAwXCIgbGF5b3V0PVwiaW50cmluc2ljXCIgLz5cbiAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgZGlzcGxheTogJ2lubGluZS1ibG9jaycsXG4gICAgICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgcG9zaXRpb246ICdyZWxhdGl2ZScsXG4gICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICBtYXJnaW46IDAsXG4gICAgICB9XG4gICAgICBzaXplclN0eWxlID0ge1xuICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgIH1cbiAgICAgIHNpemVyU3ZnID0gYDxzdmcgd2lkdGg9XCIke3dpZHRoSW50fVwiIGhlaWdodD1cIiR7aGVpZ2h0SW50fVwiIHhtbG5zPVwiaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmdcIiB2ZXJzaW9uPVwiMS4xXCIvPmBcbiAgICB9IGVsc2UgaWYgKGxheW91dCA9PT0gJ2ZpeGVkJykge1xuICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJmaXhlZFwiIC8+XG4gICAgICB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcbiAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgIGRpc3BsYXk6ICdpbmxpbmUtYmxvY2snLFxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgICAgd2lkdGg6IHdpZHRoSW50LFxuICAgICAgICBoZWlnaHQ6IGhlaWdodEludCxcbiAgICAgIH1cbiAgICB9XG4gIH0gZWxzZSBpZiAoXG4gICAgdHlwZW9mIHdpZHRoSW50ID09PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiBoZWlnaHRJbnQgPT09ICd1bmRlZmluZWQnICYmXG4gICAgbGF5b3V0ID09PSAnZmlsbCdcbiAgKSB7XG4gICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgbGF5b3V0PVwiZmlsbFwiIC8+XG4gICAgd3JhcHBlclN0eWxlID0ge1xuICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgIG92ZXJmbG93OiAnaGlkZGVuJyxcblxuICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXG4gICAgICB0b3A6IDAsXG4gICAgICBsZWZ0OiAwLFxuICAgICAgYm90dG9tOiAwLFxuICAgICAgcmlnaHQ6IDAsXG5cbiAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgbWFyZ2luOiAwLFxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiAvPlxuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIG11c3QgdXNlIFwid2lkdGhcIiBhbmQgXCJoZWlnaHRcIiBwcm9wZXJ0aWVzIG9yIFwibGF5b3V0PSdmaWxsJ1wiIHByb3BlcnR5LmBcbiAgICAgIClcbiAgICB9XG4gIH1cblxuICBsZXQgaW1nQXR0cmlidXRlczogR2VuSW1nQXR0cnNSZXN1bHQgPSB7XG4gICAgc3JjOlxuICAgICAgJ2RhdGE6aW1hZ2UvZ2lmO2Jhc2U2NCxSMGxHT0RsaEFRQUJBSUFBQUFBQUFQLy8veUg1QkFFQUFBQUFMQUFBQUFBQkFBRUFBQUlCUkFBNycsXG4gICAgc3JjU2V0OiB1bmRlZmluZWQsXG4gICAgc2l6ZXM6IHVuZGVmaW5lZCxcbiAgfVxuXG4gIGlmIChpc1Zpc2libGUpIHtcbiAgICBpbWdBdHRyaWJ1dGVzID0gZ2VuZXJhdGVJbWdBdHRycyh7XG4gICAgICBzcmMsXG4gICAgICB1bm9wdGltaXplZCxcbiAgICAgIGxheW91dCxcbiAgICAgIHdpZHRoOiB3aWR0aEludCxcbiAgICAgIHF1YWxpdHk6IHF1YWxpdHlJbnQsXG4gICAgICBzaXplcyxcbiAgICAgIGxvYWRlcixcbiAgICB9KVxuICB9XG5cbiAgaWYgKHVuc2l6ZWQpIHtcbiAgICB3cmFwcGVyU3R5bGUgPSB1bmRlZmluZWRcbiAgICBzaXplclN0eWxlID0gdW5kZWZpbmVkXG4gICAgaW1nU3R5bGUgPSB1bmRlZmluZWRcbiAgfVxuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3dyYXBwZXJTdHlsZX0+XG4gICAgICB7c2l6ZXJTdHlsZSA/IChcbiAgICAgICAgPGRpdiBzdHlsZT17c2l6ZXJTdHlsZX0+XG4gICAgICAgICAge3NpemVyU3ZnID8gKFxuICAgICAgICAgICAgPGltZ1xuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIG1heFdpZHRoOiAnMTAwJScsXG4gICAgICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgICAgICAgICBtYXJnaW46IDAsXG4gICAgICAgICAgICAgICAgYm9yZGVyOiAnbm9uZScsXG4gICAgICAgICAgICAgICAgcGFkZGluZzogMCxcbiAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgYWx0PVwiXCJcbiAgICAgICAgICAgICAgYXJpYS1oaWRkZW49e3RydWV9XG4gICAgICAgICAgICAgIHJvbGU9XCJwcmVzZW50YXRpb25cIlxuICAgICAgICAgICAgICBzcmM9e2BkYXRhOmltYWdlL3N2Zyt4bWw7YmFzZTY0LCR7dG9CYXNlNjQoc2l6ZXJTdmcpfWB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICkgOiBudWxsfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICkgOiBudWxsfVxuICAgICAgPGltZ1xuICAgICAgICB7Li4ucmVzdH1cbiAgICAgICAgey4uLmltZ0F0dHJpYnV0ZXN9XG4gICAgICAgIGRlY29kaW5nPVwiYXN5bmNcIlxuICAgICAgICBjbGFzc05hbWU9e2NsYXNzTmFtZX1cbiAgICAgICAgcmVmPXtzZXRSZWZ9XG4gICAgICAgIHN0eWxlPXtpbWdTdHlsZX1cbiAgICAgIC8+XG4gICAgICB7cHJpb3JpdHkgPyAoXG4gICAgICAgIC8vIE5vdGUgaG93IHdlIG9taXQgdGhlIGBocmVmYCBhdHRyaWJ1dGUsIGFzIGl0IHdvdWxkIG9ubHkgYmUgcmVsZXZhbnRcbiAgICAgICAgLy8gZm9yIGJyb3dzZXJzIHRoYXQgZG8gbm90IHN1cHBvcnQgYGltYWdlc3Jjc2V0YCwgYW5kIGluIHRob3NlIGNhc2VzXG4gICAgICAgIC8vIGl0IHdvdWxkIGxpa2VseSBjYXVzZSB0aGUgaW5jb3JyZWN0IGltYWdlIHRvIGJlIHByZWxvYWRlZC5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gaHR0cHM6Ly9odG1sLnNwZWMud2hhdHdnLm9yZy9tdWx0aXBhZ2Uvc2VtYW50aWNzLmh0bWwjYXR0ci1saW5rLWltYWdlc3Jjc2V0XG4gICAgICAgIDxIZWFkPlxuICAgICAgICAgIDxsaW5rXG4gICAgICAgICAgICBrZXk9e1xuICAgICAgICAgICAgICAnX19uaW1nLScgK1xuICAgICAgICAgICAgICBpbWdBdHRyaWJ1dGVzLnNyYyArXG4gICAgICAgICAgICAgIGltZ0F0dHJpYnV0ZXMuc3JjU2V0ICtcbiAgICAgICAgICAgICAgaW1nQXR0cmlidXRlcy5zaXplc1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVsPVwicHJlbG9hZFwiXG4gICAgICAgICAgICBhcz1cImltYWdlXCJcbiAgICAgICAgICAgIGhyZWY9e2ltZ0F0dHJpYnV0ZXMuc3JjU2V0ID8gdW5kZWZpbmVkIDogaW1nQXR0cmlidXRlcy5zcmN9XG4gICAgICAgICAgICAvLyBAdHMtaWdub3JlOiBpbWFnZXNyY3NldCBpcyBub3QgeWV0IGluIHRoZSBsaW5rIGVsZW1lbnQgdHlwZVxuICAgICAgICAgICAgaW1hZ2VzcmNzZXQ9e2ltZ0F0dHJpYnV0ZXMuc3JjU2V0fVxuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZTogaW1hZ2VzaXplcyBpcyBub3QgeWV0IGluIHRoZSBsaW5rIGVsZW1lbnQgdHlwZVxuICAgICAgICAgICAgaW1hZ2VzaXplcz17aW1nQXR0cmlidXRlcy5zaXplc31cbiAgICAgICAgICA+PC9saW5rPlxuICAgICAgICA8L0hlYWQ+XG4gICAgICApIDogbnVsbH1cbiAgICA8L2Rpdj5cbiAgKVxufVxuXG4vL0JVSUxUIElOIExPQURFUlNcblxuZnVuY3Rpb24gbm9ybWFsaXplU3JjKHNyYzogc3RyaW5nKTogc3RyaW5nIHtcbiAgcmV0dXJuIHNyY1swXSA9PT0gJy8nID8gc3JjLnNsaWNlKDEpIDogc3JjXG59XG5cbmZ1bmN0aW9uIGltZ2l4TG9hZGVyKHtcbiAgcm9vdCxcbiAgc3JjLFxuICB3aWR0aCxcbiAgcXVhbGl0eSxcbn06IERlZmF1bHRJbWFnZUxvYWRlclByb3BzKTogc3RyaW5nIHtcbiAgLy8gRGVtbzogaHR0cHM6Ly9zdGF0aWMuaW1naXgubmV0L2RhaXN5LnBuZz9mb3JtYXQ9YXV0byZmaXQ9bWF4Jnc9MzAwXG4gIGNvbnN0IHBhcmFtcyA9IFsnYXV0bz1mb3JtYXQnLCAnZml0PW1heCcsICd3PScgKyB3aWR0aF1cbiAgbGV0IHBhcmFtc1N0cmluZyA9ICcnXG4gIGlmIChxdWFsaXR5KSB7XG4gICAgcGFyYW1zLnB1c2goJ3E9JyArIHF1YWxpdHkpXG4gIH1cblxuICBpZiAocGFyYW1zLmxlbmd0aCkge1xuICAgIHBhcmFtc1N0cmluZyA9ICc/JyArIHBhcmFtcy5qb2luKCcmJylcbiAgfVxuICByZXR1cm4gYCR7cm9vdH0ke25vcm1hbGl6ZVNyYyhzcmMpfSR7cGFyYW1zU3RyaW5nfWBcbn1cblxuZnVuY3Rpb24gYWthbWFpTG9hZGVyKHsgcm9vdCwgc3JjLCB3aWR0aCB9OiBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcyk6IHN0cmluZyB7XG4gIHJldHVybiBgJHtyb290fSR7bm9ybWFsaXplU3JjKHNyYyl9P2ltd2lkdGg9JHt3aWR0aH1gXG59XG5cbmZ1bmN0aW9uIGNsb3VkaW5hcnlMb2FkZXIoe1xuICByb290LFxuICBzcmMsXG4gIHdpZHRoLFxuICBxdWFsaXR5LFxufTogRGVmYXVsdEltYWdlTG9hZGVyUHJvcHMpOiBzdHJpbmcge1xuICAvLyBEZW1vOiBodHRwczovL3Jlcy5jbG91ZGluYXJ5LmNvbS9kZW1vL2ltYWdlL3VwbG9hZC93XzMwMCxjX2xpbWl0LHFfYXV0by90dXJ0bGVzLmpwZ1xuICBjb25zdCBwYXJhbXMgPSBbJ2ZfYXV0bycsICdjX2xpbWl0JywgJ3dfJyArIHdpZHRoLCAncV8nICsgKHF1YWxpdHkgfHwgJ2F1dG8nKV1cbiAgbGV0IHBhcmFtc1N0cmluZyA9IHBhcmFtcy5qb2luKCcsJykgKyAnLydcbiAgcmV0dXJuIGAke3Jvb3R9JHtwYXJhbXNTdHJpbmd9JHtub3JtYWxpemVTcmMoc3JjKX1gXG59XG5cbmZ1bmN0aW9uIGRlZmF1bHRMb2FkZXIoe1xuICByb290LFxuICBzcmMsXG4gIHdpZHRoLFxuICBxdWFsaXR5LFxufTogRGVmYXVsdEltYWdlTG9hZGVyUHJvcHMpOiBzdHJpbmcge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykge1xuICAgIGNvbnN0IG1pc3NpbmdWYWx1ZXMgPSBbXVxuXG4gICAgLy8gdGhlc2Ugc2hvdWxkIGFsd2F5cyBiZSBwcm92aWRlZCBidXQgbWFrZSBzdXJlIHRoZXkgYXJlXG4gICAgaWYgKCFzcmMpIG1pc3NpbmdWYWx1ZXMucHVzaCgnc3JjJylcbiAgICBpZiAoIXdpZHRoKSBtaXNzaW5nVmFsdWVzLnB1c2goJ3dpZHRoJylcblxuICAgIGlmIChtaXNzaW5nVmFsdWVzLmxlbmd0aCA+IDApIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYE5leHQgSW1hZ2UgT3B0aW1pemF0aW9uIHJlcXVpcmVzICR7bWlzc2luZ1ZhbHVlcy5qb2luKFxuICAgICAgICAgICcsICdcbiAgICAgICAgKX0gdG8gYmUgcHJvdmlkZWQuIE1ha2Ugc3VyZSB5b3UgcGFzcyB0aGVtIGFzIHByb3BzIHRvIHRoZSBcXGBuZXh0L2ltYWdlXFxgIGNvbXBvbmVudC4gUmVjZWl2ZWQ6ICR7SlNPTi5zdHJpbmdpZnkoXG4gICAgICAgICAgeyBzcmMsIHdpZHRoLCBxdWFsaXR5IH1cbiAgICAgICAgKX1gXG4gICAgICApXG4gICAgfVxuXG4gICAgaWYgKHNyYy5zdGFydHNXaXRoKCcvLycpKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBGYWlsZWQgdG8gcGFyc2Ugc3JjIFwiJHtzcmN9XCIgb24gXFxgbmV4dC9pbWFnZVxcYCwgcHJvdG9jb2wtcmVsYXRpdmUgVVJMICgvLykgbXVzdCBiZSBjaGFuZ2VkIHRvIGFuIGFic29sdXRlIFVSTCAoaHR0cDovLyBvciBodHRwczovLylgXG4gICAgICApXG4gICAgfVxuXG4gICAgaWYgKCFzcmMuc3RhcnRzV2l0aCgnLycpICYmIGNvbmZpZ0RvbWFpbnMpIHtcbiAgICAgIGxldCBwYXJzZWRTcmM6IFVSTFxuICAgICAgdHJ5IHtcbiAgICAgICAgcGFyc2VkU3JjID0gbmV3IFVSTChzcmMpXG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihlcnIpXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICBgRmFpbGVkIHRvIHBhcnNlIHNyYyBcIiR7c3JjfVwiIG9uIFxcYG5leHQvaW1hZ2VcXGAsIGlmIHVzaW5nIHJlbGF0aXZlIGltYWdlIGl0IG11c3Qgc3RhcnQgd2l0aCBhIGxlYWRpbmcgc2xhc2ggXCIvXCIgb3IgYmUgYW4gYWJzb2x1dGUgVVJMIChodHRwOi8vIG9yIGh0dHBzOi8vKWBcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBpZiAoIWNvbmZpZ0RvbWFpbnMuaW5jbHVkZXMocGFyc2VkU3JjLmhvc3RuYW1lKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEludmFsaWQgc3JjIHByb3AgKCR7c3JjfSkgb24gXFxgbmV4dC9pbWFnZVxcYCwgaG9zdG5hbWUgXCIke3BhcnNlZFNyYy5ob3N0bmFtZX1cIiBpcyBub3QgY29uZmlndXJlZCB1bmRlciBpbWFnZXMgaW4geW91ciBcXGBuZXh0LmNvbmZpZy5qc1xcYFxcbmAgK1xuICAgICAgICAgICAgYFNlZSBtb3JlIGluZm86IGh0dHBzOi8vZXJyLnNoL25leHQuanMvbmV4dC1pbWFnZS11bmNvbmZpZ3VyZWQtaG9zdGBcbiAgICAgICAgKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBgJHtyb290fT91cmw9JHtlbmNvZGVVUklDb21wb25lbnQoc3JjKX0mdz0ke3dpZHRofSZxPSR7cXVhbGl0eSB8fCA3NX1gXG59XG4iLCJ0eXBlIFJlcXVlc3RJZGxlQ2FsbGJhY2tIYW5kbGUgPSBhbnlcbnR5cGUgUmVxdWVzdElkbGVDYWxsYmFja09wdGlvbnMgPSB7XG4gIHRpbWVvdXQ6IG51bWJlclxufVxudHlwZSBSZXF1ZXN0SWRsZUNhbGxiYWNrRGVhZGxpbmUgPSB7XG4gIHJlYWRvbmx5IGRpZFRpbWVvdXQ6IGJvb2xlYW5cbiAgdGltZVJlbWFpbmluZzogKCkgPT4gbnVtYmVyXG59XG5cbmRlY2xhcmUgZ2xvYmFsIHtcbiAgaW50ZXJmYWNlIFdpbmRvdyB7XG4gICAgcmVxdWVzdElkbGVDYWxsYmFjazogKFxuICAgICAgY2FsbGJhY2s6IChkZWFkbGluZTogUmVxdWVzdElkbGVDYWxsYmFja0RlYWRsaW5lKSA9PiB2b2lkLFxuICAgICAgb3B0cz86IFJlcXVlc3RJZGxlQ2FsbGJhY2tPcHRpb25zXG4gICAgKSA9PiBSZXF1ZXN0SWRsZUNhbGxiYWNrSGFuZGxlXG4gICAgY2FuY2VsSWRsZUNhbGxiYWNrOiAoaWQ6IFJlcXVlc3RJZGxlQ2FsbGJhY2tIYW5kbGUpID0+IHZvaWRcbiAgfVxufVxuXG5leHBvcnQgY29uc3QgcmVxdWVzdElkbGVDYWxsYmFjayA9XG4gICh0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcgJiYgc2VsZi5yZXF1ZXN0SWRsZUNhbGxiYWNrKSB8fFxuICBmdW5jdGlvbiAoXG4gICAgY2I6IChkZWFkbGluZTogUmVxdWVzdElkbGVDYWxsYmFja0RlYWRsaW5lKSA9PiB2b2lkXG4gICk6IE5vZGVKUy5UaW1lb3V0IHtcbiAgICBsZXQgc3RhcnQgPSBEYXRlLm5vdygpXG4gICAgcmV0dXJuIHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgY2Ioe1xuICAgICAgICBkaWRUaW1lb3V0OiBmYWxzZSxcbiAgICAgICAgdGltZVJlbWFpbmluZzogZnVuY3Rpb24gKCkge1xuICAgICAgICAgIHJldHVybiBNYXRoLm1heCgwLCA1MCAtIChEYXRlLm5vdygpIC0gc3RhcnQpKVxuICAgICAgICB9LFxuICAgICAgfSlcbiAgICB9LCAxKVxuICB9XG5cbmV4cG9ydCBjb25zdCBjYW5jZWxJZGxlQ2FsbGJhY2sgPVxuICAodHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnICYmIHNlbGYuY2FuY2VsSWRsZUNhbGxiYWNrKSB8fFxuICBmdW5jdGlvbiAoaWQ6IFJlcXVlc3RJZGxlQ2FsbGJhY2tIYW5kbGUpIHtcbiAgICByZXR1cm4gY2xlYXJUaW1lb3V0KGlkKVxuICB9XG4iLCJpbXBvcnQgeyB1c2VDYWxsYmFjaywgdXNlRWZmZWN0LCB1c2VSZWYsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnXG5pbXBvcnQge1xuICByZXF1ZXN0SWRsZUNhbGxiYWNrLFxuICBjYW5jZWxJZGxlQ2FsbGJhY2ssXG59IGZyb20gJy4vcmVxdWVzdC1pZGxlLWNhbGxiYWNrJ1xuXG50eXBlIFVzZUludGVyc2VjdGlvbk9ic2VydmVySW5pdCA9IFBpY2s8SW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0LCAncm9vdE1hcmdpbic+XG50eXBlIFVzZUludGVyc2VjdGlvbiA9IHsgZGlzYWJsZWQ/OiBib29sZWFuIH0gJiBVc2VJbnRlcnNlY3Rpb25PYnNlcnZlckluaXRcbnR5cGUgT2JzZXJ2ZUNhbGxiYWNrID0gKGlzVmlzaWJsZTogYm9vbGVhbikgPT4gdm9pZFxudHlwZSBPYnNlcnZlciA9IHtcbiAgaWQ6IHN0cmluZ1xuICBvYnNlcnZlcjogSW50ZXJzZWN0aW9uT2JzZXJ2ZXJcbiAgZWxlbWVudHM6IE1hcDxFbGVtZW50LCBPYnNlcnZlQ2FsbGJhY2s+XG59XG5cbmNvbnN0IGhhc0ludGVyc2VjdGlvbk9ic2VydmVyID0gdHlwZW9mIEludGVyc2VjdGlvbk9ic2VydmVyICE9PSAndW5kZWZpbmVkJ1xuXG5leHBvcnQgZnVuY3Rpb24gdXNlSW50ZXJzZWN0aW9uPFQgZXh0ZW5kcyBFbGVtZW50Pih7XG4gIHJvb3RNYXJnaW4sXG4gIGRpc2FibGVkLFxufTogVXNlSW50ZXJzZWN0aW9uKTogWyhlbGVtZW50OiBUIHwgbnVsbCkgPT4gdm9pZCwgYm9vbGVhbl0ge1xuICBjb25zdCBpc0Rpc2FibGVkOiBib29sZWFuID0gZGlzYWJsZWQgfHwgIWhhc0ludGVyc2VjdGlvbk9ic2VydmVyXG5cbiAgY29uc3QgdW5vYnNlcnZlID0gdXNlUmVmPEZ1bmN0aW9uPigpXG4gIGNvbnN0IFt2aXNpYmxlLCBzZXRWaXNpYmxlXSA9IHVzZVN0YXRlKGZhbHNlKVxuXG4gIGNvbnN0IHNldFJlZiA9IHVzZUNhbGxiYWNrKFxuICAgIChlbDogVCB8IG51bGwpID0+IHtcbiAgICAgIGlmICh1bm9ic2VydmUuY3VycmVudCkge1xuICAgICAgICB1bm9ic2VydmUuY3VycmVudCgpXG4gICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gdW5kZWZpbmVkXG4gICAgICB9XG5cbiAgICAgIGlmIChpc0Rpc2FibGVkIHx8IHZpc2libGUpIHJldHVyblxuXG4gICAgICBpZiAoZWwgJiYgZWwudGFnTmFtZSkge1xuICAgICAgICB1bm9ic2VydmUuY3VycmVudCA9IG9ic2VydmUoXG4gICAgICAgICAgZWwsXG4gICAgICAgICAgKGlzVmlzaWJsZSkgPT4gaXNWaXNpYmxlICYmIHNldFZpc2libGUoaXNWaXNpYmxlKSxcbiAgICAgICAgICB7IHJvb3RNYXJnaW4gfVxuICAgICAgICApXG4gICAgICB9XG4gICAgfSxcbiAgICBbaXNEaXNhYmxlZCwgcm9vdE1hcmdpbiwgdmlzaWJsZV1cbiAgKVxuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgaWYgKCFoYXNJbnRlcnNlY3Rpb25PYnNlcnZlcikge1xuICAgICAgaWYgKCF2aXNpYmxlKSB7XG4gICAgICAgIGNvbnN0IGlkbGVDYWxsYmFjayA9IHJlcXVlc3RJZGxlQ2FsbGJhY2soKCkgPT4gc2V0VmlzaWJsZSh0cnVlKSlcbiAgICAgICAgcmV0dXJuICgpID0+IGNhbmNlbElkbGVDYWxsYmFjayhpZGxlQ2FsbGJhY2spXG4gICAgICB9XG4gICAgfVxuICB9LCBbdmlzaWJsZV0pXG5cbiAgcmV0dXJuIFtzZXRSZWYsIHZpc2libGVdXG59XG5cbmZ1bmN0aW9uIG9ic2VydmUoXG4gIGVsZW1lbnQ6IEVsZW1lbnQsXG4gIGNhbGxiYWNrOiBPYnNlcnZlQ2FsbGJhY2ssXG4gIG9wdGlvbnM6IFVzZUludGVyc2VjdGlvbk9ic2VydmVySW5pdFxuKTogKCkgPT4gdm9pZCB7XG4gIGNvbnN0IHsgaWQsIG9ic2VydmVyLCBlbGVtZW50cyB9ID0gY3JlYXRlT2JzZXJ2ZXIob3B0aW9ucylcbiAgZWxlbWVudHMuc2V0KGVsZW1lbnQsIGNhbGxiYWNrKVxuXG4gIG9ic2VydmVyLm9ic2VydmUoZWxlbWVudClcbiAgcmV0dXJuIGZ1bmN0aW9uIHVub2JzZXJ2ZSgpOiB2b2lkIHtcbiAgICBlbGVtZW50cy5kZWxldGUoZWxlbWVudClcbiAgICBvYnNlcnZlci51bm9ic2VydmUoZWxlbWVudClcblxuICAgIC8vIERlc3Ryb3kgb2JzZXJ2ZXIgd2hlbiB0aGVyZSdzIG5vdGhpbmcgbGVmdCB0byB3YXRjaDpcbiAgICBpZiAoZWxlbWVudHMuc2l6ZSA9PT0gMCkge1xuICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpXG4gICAgICBvYnNlcnZlcnMuZGVsZXRlKGlkKVxuICAgIH1cbiAgfVxufVxuXG5jb25zdCBvYnNlcnZlcnMgPSBuZXcgTWFwPHN0cmluZywgT2JzZXJ2ZXI+KClcbmZ1bmN0aW9uIGNyZWF0ZU9ic2VydmVyKG9wdGlvbnM6IFVzZUludGVyc2VjdGlvbk9ic2VydmVySW5pdCk6IE9ic2VydmVyIHtcbiAgY29uc3QgaWQgPSBvcHRpb25zLnJvb3RNYXJnaW4gfHwgJydcbiAgbGV0IGluc3RhbmNlID0gb2JzZXJ2ZXJzLmdldChpZClcbiAgaWYgKGluc3RhbmNlKSB7XG4gICAgcmV0dXJuIGluc3RhbmNlXG4gIH1cblxuICBjb25zdCBlbGVtZW50cyA9IG5ldyBNYXA8RWxlbWVudCwgT2JzZXJ2ZUNhbGxiYWNrPigpXG4gIGNvbnN0IG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKChlbnRyaWVzKSA9PiB7XG4gICAgZW50cmllcy5mb3JFYWNoKChlbnRyeSkgPT4ge1xuICAgICAgY29uc3QgY2FsbGJhY2sgPSBlbGVtZW50cy5nZXQoZW50cnkudGFyZ2V0KVxuICAgICAgY29uc3QgaXNWaXNpYmxlID0gZW50cnkuaXNJbnRlcnNlY3RpbmcgfHwgZW50cnkuaW50ZXJzZWN0aW9uUmF0aW8gPiAwXG4gICAgICBpZiAoY2FsbGJhY2sgJiYgaXNWaXNpYmxlKSB7XG4gICAgICAgIGNhbGxiYWNrKGlzVmlzaWJsZSlcbiAgICAgIH1cbiAgICB9KVxuICB9LCBvcHRpb25zKVxuXG4gIG9ic2VydmVycy5zZXQoXG4gICAgaWQsXG4gICAgKGluc3RhbmNlID0ge1xuICAgICAgaWQsXG4gICAgICBvYnNlcnZlcixcbiAgICAgIGVsZW1lbnRzLFxuICAgIH0pXG4gIClcbiAgcmV0dXJuIGluc3RhbmNlXG59XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoJy4vZGlzdC9jbGllbnQvaW1hZ2UnKVxuIiwiZnVuY3Rpb24gX2V4dGVuZHMoKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uICh0YXJnZXQpIHtcbiAgICBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXTtcblxuICAgICAgZm9yICh2YXIga2V5IGluIHNvdXJjZSkge1xuICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHNvdXJjZSwga2V5KSkge1xuICAgICAgICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9O1xuXG4gIHJldHVybiBfZXh0ZW5kcy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9leHRlbmRzOyIsImZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgXCJkZWZhdWx0XCI6IG9ialxuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQ7IiwiZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkge1xuICBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTtcbiAgdmFyIHRhcmdldCA9IHt9O1xuICB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7XG4gIHZhciBrZXksIGk7XG5cbiAgZm9yIChpID0gMDsgaSA8IHNvdXJjZUtleXMubGVuZ3RoOyBpKyspIHtcbiAgICBrZXkgPSBzb3VyY2VLZXlzW2ldO1xuICAgIGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7XG4gICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgfVxuXG4gIHJldHVybiB0YXJnZXQ7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2U7IiwiaW1wb3J0IHtcclxuICAgIEF2YXRhcixcclxuICAgIEJveCxcclxuICAgIEJ1dHRvbixcclxuICAgIENhcmQsXHJcbiAgICBDaGVja2JveCxcclxuICAgIERpYWxvZyxcclxuICAgIERpYWxvZ0NvbnRlbnQsXHJcbiAgICBEaWFsb2dUaXRsZSxcclxuICAgIEZvcm1Db250cm9sLFxyXG4gICAgRm9ybUNvbnRyb2xMYWJlbCxcclxuICAgIEZvcm1MYWJlbCxcclxuICAgIEdyaWQsXHJcbiAgICBJY29uQnV0dG9uLFxyXG4gICAgSW5wdXRBZG9ybm1lbnQsXHJcbiAgICBMaW5rLFxyXG4gICAgTWVudUl0ZW0sXHJcbiAgICBSYWRpbyxcclxuICAgIFJhZGlvR3JvdXAsXHJcbiAgICBTZWxlY3QsXHJcbiAgICBTd2l0Y2gsXHJcbiAgICBUZXh0RmllbGQsXHJcbiAgICBUeXBvZ3JhcGh5XHJcbn0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5pbXBvcnQgQ2xvc2VJY29uIGZyb20gJ0BtYXRlcmlhbC11aS9pY29ucy9DbG9zZSc7XHJcbmltcG9ydCBFeHBhbmRNb3JlT3V0bGluZWRJY29uIGZyb20gJ0BtYXRlcmlhbC11aS9pY29ucy9FeHBhbmRNb3JlT3V0bGluZWQnO1xyXG5pbXBvcnQgUmVhY3QsIHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IEFsZXJ0VHJpYW5nbGUgfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IE1haW5IZWFkZXIgZnJvbSAnc2hhcmVkL2NvbXBvbmVudHMvSGVhZGVyL01haW5IZWFkZXInO1xyXG5pbXBvcnQgQWxlcnRzIGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvQWxlcnQvQWxlcnRzJztcclxuaW1wb3J0IEFubm90YXRpb25zIGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvQW5ub3RhdGlvbnMnO1xyXG5pbXBvcnQgQ2hpcHMgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9DaGlwcyc7XHJcbmltcG9ydCBGb3JtRXJyb3JNZXNzYWdlIGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvRm9ybUVycm9yTWVzc2FnZSc7XHJcbi8vIGltcG9ydCBNb2JpbGVNZW51IGZyb20gJ3NoYXJlZC9jb21wb25lbnRzL0hlYWRlci9Nb2JpbGVNZW51JztcclxuaW1wb3J0IFRvcEhlYWRlciBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0hlYWRlci9Ub3BIZWFkZXInO1xyXG5pbXBvcnQgSW5kaWNhdG9ycyBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0luZGljYXRvcnMnO1xyXG5pbXBvcnQgTG9nb0hlYWRpbmcgZnJvbSAnfi9zaGFyZWQvY29tcG9uZW50cy9Mb2dvSGVhZGluZyc7XHJcbmltcG9ydCBPYmplY3RDYXJkIGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvT2JqZWN0Q2FyZCc7XHJcbmltcG9ydCBQYWdlSGVhZGluZyBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL1BhZ2VIZWFkaW5nJztcclxuaW1wb3J0IFByb2dyYW1DYXJkIGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvUHJvZ3JhbUNhcmQnO1xyXG5pbXBvcnQgVG9vbHRpcCBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL1Rvb2x0aXAnO1xyXG4vLyBpbXBvcnQgRWxpZ2libGVQcm9ncmFtcyBmcm9tICcuLi9Ib3VzZUhvbGRNb2R1bGUvSG91c2Vob2xkTWVtYmVycy9FbGlnaWJsZVByb2dyYW1zJztcclxuXHJcbi8qKlxyXG4gKiBOYW1lOiBTdHlsZWRDb21wb25lbnRcclxuICogRGVzYzogUmVuZGVyIFN0eWxlZENvbXBvbmVudFxyXG4gKi9cclxuXHJcbmNvbnN0IGhhbmRsZURlbGV0ZSA9ICgpID0+IHtcclxuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXHJcbiAgICBjb25zb2xlLmluZm8oJ1lvdSBjbGlja2VkIHRoZSBkZWxldGUgaWNvbi4nKTtcclxufTtcclxuXHJcbmNvbnN0IFN0eWxlZENvbXBvbmVudE1vZHVsZSA9ICgpID0+IHtcclxuICAgIGNvbnN0IFt2YWx1ZSwgc2V0VmFsdWVdID0gdXNlU3RhdGUoJ2ZlbWFsZScpO1xyXG4gICAgY29uc3QgW2NoZWNrZWQsIHNldENoZWNrZWRdID0gdXNlU3RhdGUodHJ1ZSk7XHJcblxyXG4gICAgY29uc3QgW3Nob3dEZXRhaWxzLCBzZXRTaG93RGV0YWlsc10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gICAgY29uc3QgW3N0YXRlLCBzZXRTdGF0ZV0gPSB1c2VTdGF0ZSh7XHJcbiAgICAgICAgY2hlY2tlZEE6IHRydWUsXHJcbiAgICAgICAgY2hlY2tlZEI6IHRydWVcclxuICAgIH0pO1xyXG5cclxuICAgIGNvbnN0IFtzZWxlY3QsIHNldHNlbGVjdF0gPSBSZWFjdC51c2VTdGF0ZSgnJyk7XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2hhbmdlU2VsZWN0Qm94ID0gKGV2ZW50KSA9PiB7XHJcbiAgICAgICAgc2V0c2VsZWN0KGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IFtvcGVuRGlhbG9nLCBzZXRPcGVuRGlhbG9nXSA9IHVzZVN0YXRlKGZhbHNlKTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDbGlja09wZW5EaWFsb2cgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0T3BlbkRpYWxvZyh0cnVlKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlQ2xvc2UgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0T3BlbkRpYWxvZyhmYWxzZSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZSA9IChldmVudCkgPT4ge1xyXG4gICAgICAgIHNldFZhbHVlKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZUNoZWNrQm94ID0gKGV2ZW50KSA9PiB7XHJcbiAgICAgICAgc2V0Q2hlY2tlZChldmVudC50YXJnZXQuY2hlY2tlZCk7XHJcbiAgICB9O1xyXG5cclxuICAgIGNvbnN0IGhhbmRsZUNoYW5nZVN3aXRjaEJveCA9IChldmVudCkgPT4ge1xyXG4gICAgICAgIHNldFN0YXRlKHsgLi4uc3RhdGUsIFtldmVudC50YXJnZXQubmFtZV06IGV2ZW50LnRhcmdldC5jaGVja2VkIH0pO1xyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3ggYmdjb2xvcj1cInNlY29uZGFyeS5saWdodFwiIHB5PXsyfSBweD17Mn0+XHJcbiAgICAgICAgICAgIDxHcmlkIGNvbnRhaW5lciBzcGFjaW5nPXszfT5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIHsvKiA8RWxpZ2libGVQcm9ncmFtcyAvPiAqL31cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIkFwcCBuYW1lXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8TG9nb0hlYWRpbmcgdGl0bGU9XCJBcHBOYW1lXCIgLz5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIkNsaWVudCBMb2dvXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QXZhdGFyIGFsdD1cImxvZ29cIiBzcmM9XCIvbG9nby5zdmdcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIkJ1dHRvbnNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBmbGV4V3JhcD1cIndyYXBcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBwYj17OH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImZsZXgtc3RhcnRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1iPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJsYXJnZVwiIGNvbG9yPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc21hbGxlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gY29sb3I9XCJwcmltYXJ5XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTbWFsbGVzdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtYWxsXCIgY29sb3I9XCJwcmltYXJ5XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJ4oCZbSB0aW55XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiZmxleC1zdGFydFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWI9ezN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cImxhcmdlXCIgY29sb3I9XCJzZWNvbmRhcnlcIiB2YXJpYW50PVwiY29udGFpbmVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNtYWxsZXJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJtZWRpdW1cIiBjb2xvcj1cInNlY29uZGFyeVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU21hbGxlc3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJzbWFsbFwiIGNvbG9yPVwic2Vjb25kYXJ5XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJ4oCZbSB0aW55XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiZmxleC1zdGFydFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWI9ezN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cImxhcmdlXCIgY29sb3I9XCJpbmhlcml0XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzbWFsbGVyXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiBzaXplPVwibWVkaXVtXCIgY29sb3I9XCJpbmhlcml0XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTbWFsbGVzdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gc2l6ZT1cInNtYWxsXCIgY29sb3I9XCJpbmhlcml0XCIgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBJ4oCZbSB0aW55XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezh9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17M30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2VtaUJvcmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgR2V0IFN0YXJ0ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17M30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmdWxsV2lkdGhcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJzZWNvbmRhcnlcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZW1pQm9yZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBHZXQgU3RhcnRlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXszfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJsYXJnZVwiIGNsYXNzTmFtZT1cInNlbWlCb3JkZXJcIiB2YXJpYW50PVwiY29udGFpbmVkXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEdldCBTdGFydGVkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcblxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBhZ2VIZWFkaW5nIHRpdGxlPVwiSU5ESUNBVE9SU1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7WydwZW5kaW5nJywgJ3N1Y2Nlc3MnLCAnZmFpbGVkJywgJ2RlZmF1bHQnLCAnY29tcGxldGUnXS5tYXAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAoaXRlbSwgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gPEluZGljYXRvcnMgc3RhdHVzPXtpdGVtfSBrZXk9e2luZGV4fSAvPjtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIkNvbnRyb2xzXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPEJveCBkaXNwbGF5PVwiZmxleFwiIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiIG1iPXs1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVPdXRsaW5lZEljb24gZm9udFNpemU9XCIyNXB4XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD4gKi99XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIlRvb2x0aXBcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUb29sdGlwIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcblxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cImluZm8ubWFpblwiIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIiBwYj17Mn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoM1wiPklucHV0IEJveDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsyLjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUNvbnRyb2w+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8VGV4dEZpZWxkXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJzdGFuZGFyZC1iYXNpY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJTdGFuZGFyZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImZpbGxlZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZXJyb3JcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWxwZXJUZXh0PXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1FcnJvck1lc3NhZ2UgdGl0bGU9XCJQbGVhc2UgZW50ZXIgeW91ciB0ZWxlcGhvbmUgbnVtYmVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBzaXplPXs5fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1FcnJvck1lc3NhZ2U+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtQ29udHJvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsyLjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUNvbnRyb2wgZnVsbFdpZHRoPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPFRleHRGaWVsZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJmaWxsZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiRmllbGQgSW5wdXQgTGFiZWxcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSW5wdXRQcm9wcz17e1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmRBZG9ybm1lbnQ6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJbnB1dEFkb3JubWVudD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBjbGFzc05hbWU9XCJpY29uLXNlYXJjaFwiPjwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSW5wdXRBZG9ybm1lbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtQ29udHJvbD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsyLjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUNvbnRyb2wgdmFyaWFudD1cImZpbGxlZFwiIGZ1bGxXaWR0aD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxTZWxlY3RcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbElkPVwiZGVtby1zaW1wbGUtc2VsZWN0LWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZD1cImRlbW8tc2ltcGxlLXNlbGVjdFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU9e3NlbGVjdH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlU2VsZWN0Qm94fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVudUl0ZW0gdmFsdWU9ezEwfT5UZW48L01lbnVJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51SXRlbSB2YWx1ZT17MjB9PlR3ZW50eTwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPXszMH0+VGhpcnR5PC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Zvcm1Db250cm9sPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIkFubm90YXRpb25zXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs2LjI1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEFubm90YXRpb25zIGJnQ29sb3I9XCJwcmltYXJ5Lm1haW5cIiBjb2xvcj1cImNvbW1vbi53aGl0ZVwiIG1pbkhlaWdodHM9ezE0N30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGZvbnRTaXplPVwiaDYuZm9udFNpemVcIiBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBEZXNpZ24gVG8gRG86IERlc2lnbiBlcnJvciBtZXNzYWdlcyBmb3Igc2NyZWVucy5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Fubm90YXRpb25zPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezYuMjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8QW5ub3RhdGlvbnMgYmdDb2xvcj1cImVycm9yLmRhcmtcIiBjb2xvcj1cImNvbW1vbi53aGl0ZVwiIG1pbkhlaWdodHM9ezE0N30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGZvbnRTaXplPVwiaDYuZm9udFNpemVcIiBmb250RmFtaWx5PVwiZm9udEZhbWlseS5tZWRpdW1cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBIZXJl4oCZcyBhIGRpc2N1c3Npb24gbm90ZSBmb3IgdGhpcyBzY3JlZW4uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Bbm5vdGF0aW9ucz5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs2LjI1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEFubm90YXRpb25zXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBiZ0NvbG9yPVwicGVuZGluZy5tYWluXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiY29tbW9uLmRhcmtCbGFja1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5IZWlnaHRzPXsxNDd9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cImg2LmZvbnRTaXplXCIgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSGVyZeKAmXMgYSBub3RlIGZvciB0aGlzIHNjcmVlbi5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0Fubm90YXRpb25zPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBhZ2VIZWFkaW5nIHRpdGxlPVwiUHJvZ3JhbSBDYXJkXCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs2LjI1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFByb2dyYW1DYXJkIHZhcmlhbnQ9XCJ3YWl0aW5nXCIgc2hvd0RlbGV0ZUJveD17dHJ1ZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2dyYW0gVGl0bGUgb24gQ2FyZCAoMUJSKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiYm9keTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFdhaXRsaXN0IG9yIG9uLXRyYWNrIHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUHJvZ3JhbUNhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezYuMjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UHJvZ3JhbUNhcmQgdmFyaWFudD1cInN1Y2Nlc3NcIiBzaG93TGVmdEFycm93PXt0cnVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU21hbGwgQ2FyZCBUaXRsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiYm9keTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNtYWxsIGNhcmQgc3RhdHVzIGluZGljYXRvciBsaW5lXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Qcm9ncmFtQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17Ni4yNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxQcm9ncmFtQ2FyZCB2YXJpYW50PVwiZmFpbGVkXCIgc2hvd0ltYWdlPXt0cnVlfSBzaG93TGVmdEFycm93PXt0cnVlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNi5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkubWVkaXVtXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgU21hbGwgQ2FyZCBUaXRsZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiYm9keTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFdhaXRsaXN0IG9yIG9uLXRyYWNrIHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUHJvZ3JhbUNhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezYuMjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8UHJvZ3JhbUNhcmQgdmFyaWFudD1cInN1Y2Nlc3NcIiBzaG93SW1hZ2U9e3RydWV9IHNob3dMZWZ0Qm9yZGVyPXtmYWxzZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5Lm1haW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFByb2dyYW0gVGl0bGUgb24gQ2FyZCAoMUJSKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiYm9keTFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFdhaXRsaXN0IG9yIG9uLXRyYWNrIHN0YXR1c1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvUHJvZ3JhbUNhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcblxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPFBhZ2VIZWFkaW5nIHRpdGxlPVwiT2JqZWN0IENhcmRcIiAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs2LjI1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE9iamVjdENhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmRhcmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEVyaWthIEFsZXhhbmRlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5yZWd1bGFyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQXBwbGljYW50XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9PYmplY3RDYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7LyogPEJveCBtYj17Ni4yNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxVcGxvYWRDYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cInByaW1hcnkuZGFya1wiIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBBZGQgQW5vdGhlciBQZXJzb25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L1VwbG9hZENhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+ICovfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXs2LjI1fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPE9iamVjdENhcmQgY2FyZFR5cGU9XCJhY3Rpb25DYXJkXCIgaWNvbk5hbWU9XCJwbHVzXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmRhcmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDYuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIEFkZCBBbm90aGVyIFBlcnNvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvT2JqZWN0Q2FyZD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17Ni4yNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJmbGV4LXN0YXJ0XCIgcD17Mi41fSBtaW5IZWlnaHQ9ezk2fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJmbGV4LWVuZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbldpZHRoPXszOH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmxleD1cIjAgMCAzOHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXQ9ezEuMjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hlY2tib3ggY2hlY2tlZD17Y2hlY2tlZH0gb25DaGFuZ2U9e2hhbmRsZUNoYW5nZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1sPXswLjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhHcm93PXsyfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb249XCJjb2x1bW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkuZGFya1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg2LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgSG91c2luZyBDaG9pY2UgVm91Y2hlclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwibWQuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRmluZCB5b3VyIG93biB1bml0XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge3Nob3dEZXRhaWxzICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImNvbW1vbi5saWdodEJsdWVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwibWQuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LnJlZ3VsYXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1iPXsxfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG10PXsxfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBUaGUgRWlzZW5ob3dlciBpcyBhIHdhaXRsaXN0ZWQgbXVsdGktdW5pdCBob3VzaW5nIG9wdGlvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGluIE5vcnRoZWFzdCBFbCBQYXNvIHdpdGggMiwgMywgYW5kIDQgYmVkcm9vbSB1bml0cyBtYWRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlIHRocm91Z2ggSEFDRVDigJlzIFByb2dyYW0tQmFzZWQgVm91Y2hlciBzeXN0ZW0uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5taWFuXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwibWQuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkucmVndWxhclwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPExpbmtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb21wb25lbnQ9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdW5kZXJsaW5lPVwibm9uZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gc2V0U2hvd0RldGFpbHMoIXNob3dEZXRhaWxzKX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgeyFzaG93RGV0YWlscyA/ICcgU2hvdyBEZXRhaWxzJyA6ICdIaWRlIERldGFpbHMnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0dyaWQ+XHJcbiAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gbWQ9ezEyfT5cclxuICAgICAgICAgICAgICAgICAgICA8UGFnZUhlYWRpbmcgdGl0bGU9XCJBbGVydHNcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxBbGVydHMgLz5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCIgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiIHBiPXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImgzXCI+UmFkaW8gQnV0dG9uPC9UeXBvZ3JhcGh5PlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggbWI9ezIuNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsvKiA8UmFkaW8gLz4gKi99XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtQ29udHJvbCBjb21wb25lbnQ9XCJmaWVsZHNldFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1MYWJlbCBjb21wb25lbnQ9XCJsZWdlbmRcIj5HZW5kZXI8L0Zvcm1MYWJlbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxSYWRpb0dyb3VwXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cImdlbmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbmFtZT1cImdlbmRlcjFcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPXt2YWx1ZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Rm9ybUNvbnRyb2xMYWJlbFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT1cImZlbWFsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRyb2w9ezxSYWRpbyAvPn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWw9XCJGZW1hbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Db250cm9sTGFiZWwgdmFsdWU9XCJtYWxlXCIgY29udHJvbD17PFJhZGlvIC8+fSBsYWJlbD1cIk1hbGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtQ29udHJvbExhYmVsIHZhbHVlPVwib3RoZXJcIiBjb250cm9sPXs8UmFkaW8gLz59IGxhYmVsPVwiT3RoZXJcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGb3JtQ29udHJvbExhYmVsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlPVwiZGlzYWJsZWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNhYmxlZFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250cm9sPXs8UmFkaW8gLz59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxhYmVsPVwiKERpc2FibGVkIG9wdGlvbilcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1JhZGlvR3JvdXA+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvRm9ybUNvbnRyb2w+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cInByaW1hcnkubGlnaHRcIiBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCIgcGI9ezJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8VHlwb2dyYXBoeSB2YXJpYW50PVwiaDNcIj5DaGVjayBCb3g8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17Mi41fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENoZWNrYm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtjaGVja2VkfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9e2hhbmRsZUNoYW5nZUNoZWNrQm94fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRQcm9wcz17eyAnYXJpYS1sYWJlbCc6ICdwcmltYXJ5IGNoZWNrYm94JyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCIgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiIHBiPXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImgzXCI+VG9nZ2xlIFN3aXRjaDwvVHlwb2dyYXBoeT5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsyLjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8U3dpdGNoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjaGVja2VkPXtzdGF0ZS5jaGVja2VkQn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXtoYW5kbGVDaGFuZ2VTd2l0Y2hCb3h9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBuYW1lPVwiY2hlY2tlZEJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW5wdXRQcm9wcz17eyAnYXJpYS1sYWJlbCc6ICdwcmltYXJ5IGNoZWNrYm94JyB9fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBjb2xvcj1cImluZm8ubWFpblwiIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIiBwYj17Mn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxUeXBvZ3JhcGh5IHZhcmlhbnQ9XCJoM1wiPlRhZ3M8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17Mn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDaGlwcyBsYWJlbD1cIlRhZyBOYW1lXCIgY29sb3I9XCJwcmltYXJ5XCIgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPENoaXBzIGxhYmVsPVwiQWN0aXZlIFRhZ1wiIGNvbG9yPVwic2Vjb25kYXJ5XCIgb25EZWxldGU9e2hhbmRsZURlbGV0ZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuXHJcbiAgICAgICAgICAgICAgICA8R3JpZCBpdGVtIHhzPXsxMn0gbWQ9ezEyfT5cclxuICAgICAgICAgICAgICAgICAgICA8UGFnZUhlYWRpbmcgdGl0bGU9XCJDYXJkc1wiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17NH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtaW5IZWlnaHQ9ezk2fSB3aWR0aD1cIjEwMCVcIj48L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9DYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtaW5IZWlnaHQ9ezYwNH0gd2lkdGg9XCIxMDAlXCI+PC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJ4bGcuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYmdjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwid2hpdGVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2hhbmdlIGZvbnQgU2l6ZSBhbmQgRmFtaWx5IHVzaW5nIGJveFxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgICAgICAgICAgPEdyaWQgaXRlbSB4cz17MTJ9IG1kPXsxMn0+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveCBtYj17M30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxNYWluSGVhZGVyIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPFRvcEhlYWRlciBpc1dpemFyZD17dHJ1ZX0gLz5cclxuICAgICAgICAgICAgICAgICAgICA8TWFpbkhlYWRlciBpc0xvZ2dlZEluPXt0cnVlfSAvPlxyXG4gICAgICAgICAgICAgICAgPC9HcmlkPlxyXG5cclxuICAgICAgICAgICAgICAgIDxHcmlkIGl0ZW0geHM9ezEyfSBtZD17MTJ9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxQYWdlSGVhZGluZyB0aXRsZT1cIkRpYWxvZ0JveFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvbiB2YXJpYW50PVwib3V0bGluZWRcIiBjb2xvcj1cInByaW1hcnlcIiBvbkNsaWNrPXtoYW5kbGVDbGlja09wZW5EaWFsb2d9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgT3BlbiBzaW1wbGUgZGlhbG9nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPERpYWxvZ1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsbGVkYnk9XCJzaW1wbGUtZGlhbG9nLXRpdGxlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9wZW49e29wZW5EaWFsb2d9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPERpYWxvZ1RpdGxlIGlkPVwic2ltcGxlLWRpYWxvZy10aXRsZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGFyaWEtbGFiZWw9XCJjbG9zZVwiIG9uQ2xpY2s9e2hhbmRsZUNsb3NlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENsb3NlSWNvbiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvRGlhbG9nVGl0bGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RGlhbG9nQ29udGVudD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IHRleHRBbGlnbj1cImNlbnRlclwiIHB0PXsyLjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImgzLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5LmJvbGRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBiPXsxfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIFNlbGVjdCB5b3VyIGxhbmd1YWdlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTdHlsZT1cIml0YWxpY1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkuZXh0cmFMaWdodFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgRWxpZ2UgdHUgaWRpb21hXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbWF4V2lkdGg9ezI1Nn0gbXg9XCJhdXRvXCIgcHk9ezN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEZvcm1Db250cm9sIHZhcmlhbnQ9XCJmaWxsZWRcIiBmdWxsV2lkdGg+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPFNlbGVjdFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsYWJlbElkPVwiZGVtby1zaW1wbGUtc2VsZWN0LWxhYmVsXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgaWQ9XCJkZW1vLXNpbXBsZS1zZWxlY3RcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uY29tcG9uZW50PXtFeHBhbmRNb3JlT3V0bGluZWRJY29ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZT17c2VsZWN0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNoYW5nZT17aGFuZGxlQ2hhbmdlU2VsZWN0Qm94fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPXsxfT5FbmdsaXNoPC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIHZhbHVlPXsyfT5HZXJtYW48L01lbnVJdGVtPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvU2VsZWN0PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Gb3JtQ29udHJvbD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0RpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwic2Vjb25kYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2VtaUJvcmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ9XCJjb250YWluZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgQ29udGludWVcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0RpYWxvZz5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvR3JpZD5cclxuICAgICAgICAgICAgPC9HcmlkPlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgKTtcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgU3R5bGVkQ29tcG9uZW50TW9kdWxlO1xyXG4iLCJleHBvcnQge2RlZmF1bHR9IGZyb20gJy4vU3R5bGVkQ29tcG9uZW50TW9kdWxlJyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCBTdHlsZWRDb21wb25lbnRNb2R1bGUgZnJvbSAnfi9tb2R1bGVzL1N0eWxlZENvbXBvbmVudE1vZHVsZSc7XHJcblxyXG5cclxuLyoqIFxyXG4gKiBOYW1lIDogQ29tbW9uQ29tcG9uZW50U3R5bGUgXHJcbiAqIGRlc2MgOiBSZW5kZXIgQ29tbW9uQ29tcG9uZW50U3R5bGVcclxuKiovXHJcbmZ1bmN0aW9uIENvbW1vbkNvbXBvbmVudFN0eWxlKCkge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8U3R5bGVkQ29tcG9uZW50TW9kdWxlLz5cclxuICAgICAgICA8Lz5cclxuICAgICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IENvbW1vbkNvbXBvbmVudFN0eWxlOyIsImltcG9ydCB7IENhcmQsIEljb25CdXR0b24gfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCB7IEFsZXJ0IH0gZnJvbSAnQG1hdGVyaWFsLXVpL2xhYic7XHJcbmltcG9ydCB7IFggfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL0FsZXJ0c1N0eWxlcyc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcblxyXG4vKipcclxuICogTmFtZTogQWxlcnRzXHJcbiAqIERlc2M6IFJlbmRlciBBbGVydHNcclxuICovXHJcblxyXG5jb25zdCBBbGVydHMgPSAoeyB2YXJpYW50LCBpY29uQ29sb3IsIGNoaWxkcmVuLCBzaG93Q2xvc2VCdG4gfSkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8Q2FyZCBjbGFzc05hbWU9e2NsYXNzZXNbdmFyaWFudF19PlxyXG4gICAgICAgICAgICAgICAgPEFsZXJ0XHJcbiAgICAgICAgICAgICAgICAgICAgYWN0aW9uPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgc2hvd0Nsb3NlQnRuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHN0cm9rZVdpZHRoPVwiM1wiIGNvbG9yPXtpY29uQ29sb3J9Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICB7IGNoaWxkcmVuICYmIGNoaWxkcmVuIH1cclxuICAgICAgICAgICAgICAgIDwvQWxlcnQ+XHJcbiAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICA8Lz5cclxuICAgIClcclxufVxyXG5cclxuQWxlcnRzLmRlZmF1bHRQcm9wcyA9e1xyXG4gICAgc2hvd0Nsb3NlQnRuOiBmYWxzZVxyXG59O1xyXG5cclxuQWxlcnRzLnByb3BUeXBlcyA9IHtcclxuICAgIHZhcmlhbnQ6IFByb3BUeXBlcy5vbmVPZihbXCJwcmltYXJ5QWxlcnRcIiwgXCJzZWNvbmRhcnlBbGVydFwiXSksXHJcbiAgICBpY29uQ29sb3I6IFByb3BUeXBlcy5vbmVPZihbXCJ3aGl0ZVwiLCBcImluZGlnb1wiXSksXHJcbiAgICBjaGlsZHJlbjogUHJvcFR5cGVzLm5vZGUsXHJcbiAgICBzaG93Q2xvc2VCdG46IFByb3BUeXBlcy5ib29sXHJcbn07XHJcbmV4cG9ydCBkZWZhdWx0IEFsZXJ0c1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICAgIHByaW1hcnlBbGVydDp7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOnRoZW1lLnBhbGV0dGUucHJpbWFyeS5tYWluLFxyXG4gICAgICAgIGNvbG9yOnRoZW1lLmNvbW1vbi53aGl0ZSxcclxuICAgICAgICBib3hTaGFkb3c6XCJub25lXCIsXHJcbiAgICAgICAgYm9yZGVyUmFkaXVzOlwiMFwiXHJcbiAgICB9LFxyXG4gICAgc2Vjb25kYXJ5QWxlcnQ6e1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjp0aGVtZS5wYWxldHRlLm1lbnVzLm1lbnVCYWNrZ3JvdW5kLFxyXG4gICAgICAgIGNvbG9yOnRoZW1lLnBhbGV0dGUucHJpbWFyeS5saWdodCxcclxuICAgICAgICBib3hTaGFkb3c6XCJub25lXCIsXHJcbiAgICAgICAgYm9yZGVyUmFkaXVzOlwiMFwiXHJcbiAgICB9XHJcbn0pKTtcclxuZXhwb3J0IGRlZmF1bHQgdXNlU3R5bGVzOyIsImltcG9ydCB7IEJveCB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuXHJcbi8qKlxyXG4gKiBOYW1lIDogQW5ub3RhdGlvbnNcclxuICogRGVzYyA6IFJlbmRlciBBbm5vdGF0aW9uc1xyXG4gKiBAcGFyYW0geyBzdHJpbmcgfSBiZ0NvbG9yXHJcbiAqIEBwYXJhbSB7IHN0cmluZyB9IGNvbG9yXHJcbiAqIEBwYXJhbSB7IG51bWJlciB9IG1pbkhlaWdodHNcclxuICogQHBhcmFtIHsgbm9kZSB9IGNoaWxkcmVuXHJcbiAqKi9cclxuXHJcbmNvbnN0IEFubm90YXRpb25zID0gKHsgYmdDb2xvciwgY29sb3IsIGNoaWxkcmVuLCBtaW5IZWlnaHRzIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPD5cclxuICAgICAgICAgICAgPEJveCBiZ2NvbG9yPXtiZ0NvbG9yfSBjb2xvcj17Y29sb3J9IHBhZGRpbmc9ezMuNX0gbWluSGVpZ2h0PXttaW5IZWlnaHRzfT5cclxuICAgICAgICAgICAgICAgIHtjaGlsZHJlbiAmJiBjaGlsZHJlbn1cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59O1xyXG5cclxuQW5ub3RhdGlvbnMucHJvcFR5cGVzID0ge1xyXG4gICAgYmdDb2xvcjogUHJvcFR5cGVzLnN0cmluZyxcclxuICAgIGNvbG9yOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgY2hpbGRyZW46IFByb3BUeXBlcy5ub2RlLFxyXG4gICAgbWluSGVpZ2h0czogUHJvcFR5cGVzLm51bWJlclxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgQW5ub3RhdGlvbnM7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL0Fubm90YXRpb25zJyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCdcclxuaW1wb3J0IHsgQ2hpcCwgQm94IH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5pbXBvcnQgUHJvcFR5cGVzIGZyb20gJ3Byb3AtdHlwZXMnO1xyXG5pbXBvcnQgdXNlU3R5bGVzIGZyb20gJy4vQ2hpcHNTdHlsZXMnO1xyXG5pbXBvcnQgQ2xvc2VPdXRsaW5lZEljb24gZnJvbSAnQG1hdGVyaWFsLXVpL2ljb25zL0Nsb3NlT3V0bGluZWQnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWU6IENoaXBzXHJcbiAqIERlc2M6IFJlbmRlciBDaGlwc1xyXG4gKiBAcGFyYW0geyBzdHJpbmcgfSBsYWJlbFxyXG4gKiBAcGFyYW0geyBzdHJpbmcgfSBjb2xvclxyXG4gKiBAcGFyYW0geyBmdW5jIH0gb25EZWxldGVcclxuICovXHJcblxyXG5jb25zdCBDaGlwcyA9ICh7IGxhYmVsLCBjb2xvciwgb25EZWxldGUgfSkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICA8Q2hpcFxyXG4gICAgICAgICAgICAgICAgbGFiZWw9e2xhYmVsfVxyXG4gICAgICAgICAgICAgICAgY29sb3I9e2NvbG9yfVxyXG4gICAgICAgICAgICAgICAgb25EZWxldGU9e29uRGVsZXRlfVxyXG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLnJvb3R9XHJcbiAgICAgICAgICAgICAgICBkZWxldGVJY29uPXs8Q2xvc2VPdXRsaW5lZEljb24gLz59XHJcbiAgICAgICAgICAgIC8+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApXHJcbn1cclxuXHJcbkNoaXBzLnByb3BUeXBlcyA9IHtcclxuICAgIGxhYmVsOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgY29sb3I6IFByb3BUeXBlcy5zdHJpbmcsXHJcbiAgICBvbkRlbGV0ZTogUHJvcFR5cGVzLmZ1bmNcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQ2hpcHNcclxuIiwiaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICAgIHJvb3Q6IHtcclxuICAgICAgICAnJi5NdWlDaGlwLXJvb3QnOiB7XHJcbiAgICAgICAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5LmZvbnRTaXplLnNtLFxyXG4gICAgICAgICAgICBmb250RmFtaWx5OiB0aGVtZS50eXBvZ3JhcGh5LmZvbnRGYW1pbHkuZXh0cmFCb2xkLFxyXG4gICAgICAgICAgICBib3JkZXI6IGAxcHggc29saWQgJHt0aGVtZS5wYWxldHRlLnByaW1hcnkubGlnaHR9YCxcclxuICAgICAgICAgICAgaGVpZ2h0OiB0aGVtZS5zcGFjaW5nKDQuNSksXHJcbiAgICAgICAgICAgIGJvcmRlclJhZGl1czogNTBcclxuICAgICAgICB9XHJcbiAgICB9XHJcbn0pKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IHVzZVN0eWxlcztcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vQ2hpcHMnIiwiaW1wb3J0IHsgQm94LCBCdXR0b24sIERpYWxvZ0NvbnRlbnQsIERpYWxvZ1RpdGxlLCBJY29uQnV0dG9uIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5pbXBvcnQgQ2xvc2VJY29uIGZyb20gJ0BtYXRlcmlhbC11aS9pY29ucy9DbG9zZSc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcblxyXG4vKipcclxuICogTmFtZTogRXhpdERpYWxvZ0JveFxyXG4gKiBEZXNjOiBSZW5kZXIgRXhpdERpYWxvZ0JveFxyXG4gKi9cclxuXHJcbmNvbnN0IEV4aXREaWFsb2dCb3ggPSAoeyBvbkNvbmZpcm0sIG9uQ2xvc2UgfSkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8RGlhbG9nVGl0bGUgaWQ9XCJzaW1wbGUtZGlhbG9nLXRpdGxlXCI+XHJcbiAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBhcmlhLWxhYmVsPVwiY2xvc2VcIiBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgICAgICAgICAgICA8Q2xvc2VJY29uIC8+XHJcbiAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgIDwvRGlhbG9nVGl0bGU+XHJcbiAgICAgICAgICAgIDxEaWFsb2dDb250ZW50PlxyXG4gICAgICAgICAgICAgICAgPEJveCB0ZXh0QWxpZ249XCJjZW50ZXJcIiBwdD17Mi41fT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRTaXplPVwiaDMuZm9udFNpemVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5LmxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezF9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBcmUgeW91IHN1cmUgeW91IHdhbnQgdG8gZXhpdCBiZWZvcmUgZmluaXNoaW5nP1xyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggZm9udFNpemU9XCJsZy5mb250U2l6ZVwiIGNvbG9yPVwicHJpbWFyeS5leHRyYUxpZ2h0XCIgbWI9ezN9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBBbnkgcHJvZ3Jlc3MgeW914oCZdmUgbWFkZSB3b27igJl0IGJlIHNhdmVkIHlldC5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICA8L0RpYWxvZ0NvbnRlbnQ+XHJcbiAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICA8QnV0dG9uXHJcbiAgICAgICAgICAgICAgICAgICAgZnVsbFdpZHRoXHJcbiAgICAgICAgICAgICAgICAgICAgc2l6ZT1cImxhcmdlXCJcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInNlY29uZGFyeVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwic2VtaUJvcmRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3tcclxuICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyUmFkaXVzOiAwXHJcbiAgICAgICAgICAgICAgICAgICAgfX1cclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNvbmZpcm19PlxyXG4gICAgICAgICAgICAgICAgICAgIFllcywgRXhpdCBOb3dcclxuICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgIGZ1bGxXaWR0aFxyXG4gICAgICAgICAgICAgICAgICAgIHNpemU9XCJsYXJnZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY29sb3I9XCJwcmltYXJ5XCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJzZW1pQm9yZGVyXCJcclxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50PVwiY29udGFpbmVkXCJcclxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXtvbkNsb3NlfT5cclxuICAgICAgICAgICAgICAgICAgICBObywgS2VlcCBHb2luZ1xyXG4gICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufTtcclxuRXhpdERpYWxvZ0JveC5wcm9wVHlwZXMgPSB7XHJcbiAgICBvbkNvbmZpcm06IFByb3BUeXBlcy5mdW5jLFxyXG4gICAgb25DbG9zZTogUHJvcFR5cGVzLmZ1bmNcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgRXhpdERpYWxvZ0JveDtcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vRXhpdERpYWxvZ0JveCc7XHJcbiIsImltcG9ydCB7IEJveCB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQWxlcnRUcmlhbmdsZSB9IGZyb20gJ3JlYWN0LWZlYXRoZXInO1xyXG5cclxuLyoqXHJcbiAqIE5hbWUgOiBGb3JtRXJyb3JNZXNzYWdlXHJcbiAqIERlc2MgOiBSZW5kZXIgRm9ybUVycm9yTWVzc2FnZVxyXG4gKiBAcGFyYW0geyBzcnRpbmcgfSB0aXRsZVxyXG4gKiBAcGFyYW0geyBub2RlIH0gY2hpbGRyZW5cclxuICovXHJcblxyXG5jb25zdCBGb3JtRXJyb3JNZXNzYWdlID0gKHsgdGl0bGUsIGNoaWxkcmVuIH0pID0+IHtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIG14PXstMS43NX0gcHQ9ezAuNX0+XHJcbiAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgIGZsZXg9XCIwIDAgMTZweFwiXHJcbiAgICAgICAgICAgICAgICBiZ2NvbG9yPVwiZXJyb3IubWFpblwiXHJcbiAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgIHdpZHRoPXsxNn1cclxuICAgICAgICAgICAgICAgIGhlaWdodD17MTZ9XHJcbiAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM9XCI1MCVcIlxyXG4gICAgICAgICAgICAgICAgY29sb3I9XCJjb21tb24ud2hpdGVcIlxyXG4gICAgICAgICAgICAgICAgbXI9ezAuNX0+XHJcbiAgICAgICAgICAgICAgICA8QWxlcnRUcmlhbmdsZSBzaXplPXs5fSAvPlxyXG4gICAgICAgICAgICAgICAge2NoaWxkcmVuICYmIGNoaWxkcmVufVxyXG4gICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cIm1kLmZvbnRTaXplXCIgbGluZUhlaWdodD1cIjFcIiBjb2xvcj1cImVycm9yLmRhcmtcIiBwdD17MC4yNX0+XHJcbiAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgKTtcclxufTtcclxuXHJcbkZvcm1FcnJvck1lc3NhZ2UucHJvcFR5cGVzID0ge1xyXG4gICAgdGl0bGU6IFByb3BUeXBlcy5zdHJpbmcsXHJcbiAgICBjaGlsZHJlbjogUHJvcFR5cGVzLm5vZGVcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEZvcm1FcnJvck1lc3NhZ2U7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL0Zvcm1FcnJvck1lc3NhZ2UnIiwiaW1wb3J0IHsgQm94LCBCdXR0b24sIEljb25CdXR0b24sIExpbmsgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBCYWRnZSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9CYWRnZSc7XHJcbmltcG9ydCB1c2VNZWRpYVF1ZXJ5IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3VzZU1lZGlhUXVlcnknO1xyXG5pbXBvcnQgY2xzeCBmcm9tICdjbHN4JztcclxuaW1wb3J0IEltYWdlIGZyb20gJ25leHQvaW1hZ2UnO1xyXG5pbXBvcnQgUm91dGVyIGZyb20gJ25leHQvcm91dGVyJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBCZWxsLCBDaGV2cm9uTGVmdCwgTWVudSB9IGZyb20gJ3JlYWN0LWZlYXRoZXInO1xyXG5pbXBvcnQgTG9nb0hlYWRpbmcgZnJvbSAnc2hhcmVkL2NvbXBvbmVudHMvTG9nb0hlYWRpbmcnO1xyXG5pbXBvcnQgTW9iaWxlTWVudSBmcm9tICd+L3NoYXJlZC9jb21wb25lbnRzL0hlYWRlci9Nb2JpbGVNZW51JztcclxuaW1wb3J0IHsgUk9VVEVTIH0gZnJvbSAnfi9zaGFyZWQvY29uc3RhbnRzL3JvdXRlc0NvbnN0YW50cyc7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi9NYWluSGVhZGVyU3R5bGVzJztcclxuXHJcbi8qKlxyXG4gKiBOYW1lOiBNYWluSGVhZGVyXHJcbiAqIERlc2M6IFJlbmRlciBNYWluSGVhZGVyXHJcbiAqIEBwYXJhbSAge2Jvb2x9ICBpc0xvZ2dlZEluXHJcbiAqL1xyXG5cclxuY29uc3QgTWFpbkhlYWRlciA9ICh7XHJcbiAgICBpc0xvZ2dlZEluLFxyXG4gICAgdXNlck5hbWUsXHJcbiAgICBoZWFkZXJTdWJ0aXRsZSxcclxuICAgIHNob3dCYWNrQnRuLFxyXG4gICAgbW9iaWxlVGl0bGUsXHJcbiAgICB0aXRsZSxcclxuICAgIGxhYmVsTmFtZSxcclxuICAgIHNob3dNb2JpbGVNZW51XHJcbn0pID0+IHtcclxuICAgIGNvbnN0IFttZW51VHlwZSwgc2V0TWVudVR5cGVdID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3Qgc2hvd01lbnVCYXIgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0TWVudVR5cGUodHJ1ZSk7XHJcbiAgICB9O1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgYnJlYWtQb2ludCA9IHVzZU1lZGlhUXVlcnkoJyhtaW4td2lkdGg6MTE1MnB4KScpO1xyXG4gICAgY29uc3QgY29sb3IgPSBpc0xvZ2dlZEluID8gJ2NvbW1vbi53aGl0ZScgOiAncHJpbWFyeS5saWdodCc7XHJcbiAgICBjb25zdCBidXR0b25Db2xvciA9IGlzTG9nZ2VkSW4gPyAnc2Vjb25kYXJ5JyA6ICdwcmltYXJ5JztcclxuICAgIGNvbnN0IGJ1dHRvblRpdGxlID0gaXNMb2dnZWRJbiA/ICdIZWxwIENlbnRlcicgOiAnTG9nIEluJztcclxuICAgIGNvbnN0IGxpbmtOYW1lQXJyYXkgPSBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBsaW5rTmFtZTogJ1Byb2dyYW1zJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBsaW5rTmFtZTogJ0hlbHAgQ2VudGVyJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgICBsaW5rTmFtZTogJ0dldCBTdGFydGVkJ1xyXG4gICAgICAgIH1cclxuICAgIF07XHJcblxyXG4gICAgY29uc3QgY29udGludWVUb0xvZ2luID0gKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHsgVVNFUl9MT0dJTiB9ID0gUk9VVEVTO1xyXG4gICAgICAgIFJvdXRlci5wdXNoKFVTRVJfTE9HSU4uUk9VVEUpO1xyXG4gICAgfTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3hcclxuICAgICAgICAgICAgcGFkZGluZz17M31cclxuICAgICAgICAgICAgYmdjb2xvcj1cImNvbW1vbi53aGl0ZVwiXHJcbiAgICAgICAgICAgIGJveFNoYWRvdz17Mn1cclxuICAgICAgICAgICAgY2xhc3NOYW1lPXtjbHN4KGlzTG9nZ2VkSW4gJiYgY2xhc3Nlcy5tYWluSGVhZGVyV3JhcHBlcil9PlxyXG4gICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwic3BhY2UtYmV0d2VlblwiXHJcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9e3Nob3dCYWNrQnRuIHx8IHNob3dNb2JpbGVNZW51ID8gY2xhc3Nlcy5kaXNwbGF5Tm9uZVhzIDogJyd9PlxyXG4gICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIG1yPXticmVha1BvaW50ID8gMiA6IDB9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJub25lXCIgY2xhc3NOYW1lPXtjbGFzc2VzLmxvZ29JbWFnZX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2xvZ28uc3ZnXCIgd2lkdGg9ezY2fSBoZWlnaHQ9ezYzfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PXticmVha1BvaW50ID8gJ25vbmUnIDogJ2ZsZXgnfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHshc2hvd0JhY2tCdG4gPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b24gY2xhc3NOYW1lPXtjbGFzc2VzLm1lbnVCdXR0b259IG9uQ2xpY2s9e3Nob3dNZW51QmFyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnUgc3Ryb2tlV2lkdGg9XCIyXCIgY29sb3I9XCJJbmRpZ29cIiBzaXplPXszMH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGNsYXNzTmFtZT17Y2xhc3Nlcy5tZW51QnV0dG9ufSBvbkNsaWNrPXtzaG93TWVudUJhcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxNZW51IHN0cm9rZVdpZHRoPVwiMlwiIGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPExvZ29IZWFkaW5nXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXt0aXRsZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgbGFiZWxOYW1lPXtsYWJlbE5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGlzTG9nZ2VkSW49e2lzTG9nZ2VkSW59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrUG9pbnQ9e2JyZWFrUG9pbnR9XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIiBwbD17YnJlYWtQb2ludCA/IDMgOiAwfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgYWxpZ25JdGVtcz1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1yPXtpc0xvZ2dlZEluID8gNSA6IDkuNX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmxpbmtXcmFwcGVyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2xpbmtOYW1lQXJyYXkubWFwKChpdGVtLCBpbmRleCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGtleT17aXRlbS5saW5rTmFtZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17aW5kZXggIT09IGxpbmtOYW1lQXJyYXkubGVuZ3RoIC0gMSAmJiA4fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhXcmFwPVwid3JhcFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg2LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRGYW1pbHk9XCJmb250RmFtaWx5Lm1lZGl1bVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj17Y29sb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMubGlua05hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubGlua05hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgeyFpc0xvZ2dlZEluIHx8IGJyZWFrUG9pbnQgPyAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbnRpbnVlVG9Mb2dpbigpfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc2l6ZT17YnJlYWtQb2ludCA/ICdsYXJnZScgOiAnc21hbGwnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e2J1dHRvbkNvbG9yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyaWFudD1cImNvbnRhaW5lZFwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge2J1dHRvblRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0J1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICApIDogbnVsbH1cclxuICAgICAgICAgICAgICAgICAgICB7aXNMb2dnZWRJbiA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtbD17M30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QmFkZ2UgYmFkZ2VDb250ZW50PXs0fSBjb2xvcj1cImVycm9yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJlbGwgc3Ryb2tlV2lkdGg9XCIzXCIgY29sb3I9XCJ3aGl0ZVwiIHNpemU9ezI2fSBmaWxsPVwid2hpdGVcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CYWRnZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgKSA6IG51bGx9XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIHt1c2VyTmFtZSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb249XCJjb2x1bW5cIlxyXG4gICAgICAgICAgICAgICAgICAgIHRleHRBbGlnbj1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgcHQ9e2JyZWFrUG9pbnQgPyA1IDogMX1cclxuICAgICAgICAgICAgICAgICAgICBwYj17YnJlYWtQb2ludCA/IDUgOiAxMH1cclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImNvbW1vbi53aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtzaG93QmFja0J0biA/IGNsYXNzZXMuZGlzcGxheU5vbmVYcyA6ICcnfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ9XCI3MDBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT17YnJlYWtQb2ludCA/ICdoMS5mb250U2l6ZScgOiAnaDMuZm9udFNpemUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5ib2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGI9ezJ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dXNlck5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT17YnJlYWtQb2ludCA/ICdoNS5mb250U2l6ZScgOiAnaDYuZm9udFNpemUnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0PXticmVha1BvaW50ID8gJzM1cHgnIDogJzI2cHgnfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cImNvbW1vbi53aGl0ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG1heFdpZHRoPVwiNTYwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXJnaW49XCIwIGF1dG9cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2hlYWRlclN1YnRpdGxlfVxyXG4gICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICB7KHNob3dCYWNrQnRuIHx8IHNob3dNb2JpbGVNZW51KSAmJiAoXHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGFsaWduSXRlbXM9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17c2hvd0JhY2tCdG4gfHwgc2hvd01vYmlsZU1lbnUgPyBjbGFzc2VzLmRpc3BsYXlCbG9ja1hzIDogJyd9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxJY29uQnV0dG9uIGNsYXNzTmFtZT17Y2xhc3Nlcy5tZW51QnV0dG9ufSBvbkNsaWNrPXtzaG93TWVudUJhcn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtzaG93QmFja0J0biA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDaGV2cm9uTGVmdCBzdHJva2VXaWR0aD1cIjJcIiBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApIDogKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnUgc3Ryb2tlV2lkdGg9XCIyXCIgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImg0LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuZXh0cmFCb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY29sb3I9e2NvbG9yfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBvdmVyZmxvdz1cImhpZGRlblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHdoaXRlU3BhY2U9XCJub3dyYXBcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBtYXhXaWR0aD1cIjM1MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgdGV4dE92ZXJmbG93PVwiZWxsaXBzaXNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYWRkaW5nTGVmdD17Mi40fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7bW9iaWxlVGl0bGV9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAge21lbnVUeXBlICYmIDxNb2JpbGVNZW51IGJlZm9yZUxvZ2luPXtmYWxzZX0gc2V0TWVudVR5cGU9e3NldE1lbnVUeXBlfSAvPn1cclxuICAgICAgICA8L0JveD5cclxuICAgICk7XHJcbn07XHJcblxyXG5NYWluSGVhZGVyLmRlZmF1bHRQcm9wcyA9IHtcclxuICAgIHNob3dCYWNrQnRuOiBmYWxzZSxcclxuICAgIG1vYmlsZVRpdGxlOiAnICcsXHJcbiAgICB0aXRsZTogJ0FwcE5hbWUnLFxyXG4gICAgbGFiZWxOYW1lOiAnRUwgUEFTTydcclxufTtcclxuTWFpbkhlYWRlci5wcm9wVHlwZXMgPSB7XHJcbiAgICBpc0xvZ2dlZEluOiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIHVzZXJOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgaGVhZGVyU3VidGl0bGU6IFByb3BUeXBlcy5zdHJpbmcsXHJcbiAgICBzaG93QmFja0J0bjogUHJvcFR5cGVzLmJvb2wsXHJcbiAgICBtb2JpbGVUaXRsZTogUHJvcFR5cGVzLnN0cmluZyxcclxuICAgIHRpdGxlOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgbGFiZWxOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgc2hvd01vYmlsZU1lbnU6IFByb3BUeXBlcy5ib29sXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBNYWluSGVhZGVyO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgbWFpbkhlYWRlcldyYXBwZXI6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6ICd1cmwoL2hlYWRlckJnLnN2ZyknLFxyXG4gICAgICAgIGJhY2tncm91bmRSZXBlYXQ6ICduby1yZXBlYXQnLFxyXG4gICAgICAgIGJhY2tncm91bmRQb3NpdGlvbjogJ2NlbnRlcicsXHJcbiAgICAgICAgYmFja2dyb3VuZFNpemU6ICdjb3ZlcicsXHJcbiAgICAgICAgYm9yZGVyQm90dG9tTGVmdFJhZGl1czogdGhlbWUuc3BhY2luZygyLjYzKSxcclxuICAgICAgICBib3JkZXJCb3R0b21SaWdodFJhZGl1czogdGhlbWUuc3BhY2luZygyLjYzKVxyXG4gICAgfSxcclxuICAgIGxvZ29JbWFnZToge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnbGcnKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ2Jsb2NrJ1xyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBsaW5rV3JhcHBlcjoge1xyXG4gICAgICAgIFt0aGVtZS5icmVha3BvaW50cy51cCgnbGcnKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ2ZsZXgnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIG1lbnVCdXR0b246IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbW1vbi53aGl0ZSxcclxuICAgICAgICAnJjpob3Zlcic6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5jb21tb24ud2hpdGVcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgbGlua05hbWU6IHtcclxuICAgICAgICAnJjpob3Zlcic6IHtcclxuICAgICAgICAgICAgY29sb3I6IHRoZW1lLnBhbGV0dGUuc3VjY2Vzcy5saWdodFxyXG4gICAgICAgIH1cclxuICAgIH0sXHJcbiAgICBsYWJlbE5hbWU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ2xnJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaydcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdGl0bGU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ2xnJyldOiB7XHJcbiAgICAgICAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5LmgyLmZvbnRTaXplXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGRpc3BsYXlCbG9ja1hzOiB7XHJcbiAgICAgICAgW3RoZW1lLmJyZWFrcG9pbnRzLnVwKCdsZycpXToge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiAnbm9uZSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIGRpc3BsYXk6ICdmbGV4J1xyXG4gICAgfSxcclxuICAgIGRpc3BsYXlOb25lWHM6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMuZG93bignbWQnKV06IHtcclxuICAgICAgICAgICAgZGlzcGxheTogJ25vbmUnXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL01haW5IZWFkZXInO1xyXG4iLCJpbXBvcnQgeyBCb3gsIEJ1dHRvbiwgSWNvbkJ1dHRvbiwgTGluayB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IGNsc3ggZnJvbSAnY2xzeCc7XHJcbmltcG9ydCBJbWFnZSBmcm9tICduZXh0L2ltYWdlJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBDaGV2cm9uUmlnaHQsIFggfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IHtcclxuICAgIGFmdGVyTG9naW5QYWdlc0xpbmtBcnJheSxcclxuICAgIGJlZm9yZUxvZ2luTGlua0FycmF5LFxyXG4gICAgYmVmb3JlTG9naW5QYWdlc0xpbmtBcnJheSxcclxuICAgIGxpbmtBcnJheVxyXG59IGZyb20gJy4vTW9iaWxlTWVudUNvbnN0YW50JztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL01vYmlsZU1lbnVTdHlsZXMnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWU6IE1vYmlsZU1lbnVcclxuICogRGVzYzogUmVuZGVyIE1vYmlsZU1lbnVcclxuICovXHJcblxyXG5jb25zdCBNb2JpbGVNZW51ID0gKHsgYmVmb3JlTG9naW4sIHNldE1lbnVUeXBlIH0pID0+IHtcclxuICAgIGNvbnN0IFtvcGVuTW9iaWxlTWVudSwgc2V0T3Blbk1vYmlsZU1lbnVdID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcblxyXG4gICAgY29uc3QgbGlua3MgPSBiZWZvcmVMb2dpbiA/IGJlZm9yZUxvZ2luTGlua0FycmF5IDogbGlua0FycmF5O1xyXG4gICAgY29uc3QgYWN0aW9uTGlua3MgPSBiZWZvcmVMb2dpbiA/IGJlZm9yZUxvZ2luUGFnZXNMaW5rQXJyYXkgOiBhZnRlckxvZ2luUGFnZXNMaW5rQXJyYXk7XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICB7b3Blbk1vYmlsZU1lbnUgJiYgKFxyXG4gICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xzeChcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3Nlcy5sb2dpbldyYXBwZXIsXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGJlZm9yZUxvZ2luICYmIGNsYXNzZXMuYmVmb3JlTG9naW5XcmFwcGVyXHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICBwPXszfT5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgbWI9ezExfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b25cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5tZW51QnV0dG9ufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE9wZW5Nb2JpbGVNZW51KGZhbHNlKTtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRNZW51VHlwZShmYWxzZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxYIHN0cm9rZVdpZHRoPVwiM1wiIGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MjR9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7YWN0aW9uTGlua3MubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IG1iPXszLjV9IGtleT17aXRlbS50ZXh0fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TGluayBocmVmPVwiI1wiIHVuZGVybGluZT1cIm5vbmVcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiIGFsaWduSXRlbXM9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxpdGVtLmljb24gc3Ryb2tlV2lkdGg9XCIyXCIgY29sb3I9XCJJbmRpZ29cIiBzaXplPXsyNH0gLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImgzLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubWFpblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuYm9sZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbWw9ezEuNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0udGV4dH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAge2JlZm9yZUxvZ2luICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBtdD17MS41fSBtYj17Nn0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8QnV0dG9uIHNpemU9XCJsYXJnZVwiIGNvbG9yPVwicHJpbWFyeVwiIHZhcmlhbnQ9XCJjb250YWluZWRcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBMb2cgSW5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHtsaW5rcy5tYXAoKGl0ZW0sIGluZGV4KSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIga2V5PXtpbmRleH0gbWI9ezAuNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJ1dHRvblxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2Nsc3goJ2xpbmtCdG4nLCBjbGFzc2VzLmN1c3RvbUJ1dHRvbil9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9XCJtZWRpdW1cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbmRJY29uPXs8Q2hldnJvblJpZ2h0IGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MTd9IC8+fT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2l0ZW0ubGlua05hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSl9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbj1cImZpeGVkXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgcmlnaHQ9XCItMTBweFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleD1cIi0xXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJlZm9yZUxvZ2luID8gY2xhc3Nlcy50b3BJbWFnZVBvc2l0aW9uIDogY2xhc3Nlcy5ib3R0b21JbWFnZVBvc2l0aW9uXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxJbWFnZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3JjPVwiL2NsaWVudExvZ28uc3ZnXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHdpZHRoPXsxNjB9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBoZWlnaHQ9ezE2MH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5pbWFnZX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufTtcclxuTW9iaWxlTWVudS5wcm9wVHlwZXMgPSB7XHJcbiAgICBiZWZvcmVMb2dpbjogUHJvcFR5cGVzLmJvb2wsXHJcbiAgICBzZXRNZW51VHlwZTogUHJvcFR5cGVzLmZ1bmNcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgTW9iaWxlTWVudTtcclxuIiwiaW1wb3J0IHsgRmlsZVRleHQsIEhlbHBDaXJjbGUsIEhvbWUsIFNlbmQsIFVzZXIgfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuZXhwb3J0IGNvbnN0IGJlZm9yZUxvZ2luTGlua0FycmF5ID0gW1xyXG4gICAge1xyXG4gICAgICAgIGxpbmtOYW1lOiAnQWJvdXQgSEFDRVAnXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIGxpbmtOYW1lOiAnTGFuZGxvcmQgUG9ydGFsJ1xyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgICBsaW5rTmFtZTogJ0xvZyBPdXQnXHJcbiAgICB9XHJcbl07XHJcblxyXG5leHBvcnQgY29uc3QgbGlua0FycmF5ID0gW1xyXG4gICAge1xyXG4gICAgICAgIGxpbmtOYW1lOiAnRXNwYcOxb2wnXHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICAgIGxpbmtOYW1lOiAnTG9nIE91dCdcclxuICAgIH1cclxuXTtcclxuZXhwb3J0IGNvbnN0IGFmdGVyTG9naW5QYWdlc0xpbmtBcnJheSA9IFtcclxuICAgIHsgdGV4dDogJ1lvdXIgRGFzaGJvYXJkJywgaWNvbjogSG9tZSB9LFxyXG4gICAgeyB0ZXh0OiAnWW91ciBBcHBsaWNhdGlvbnMnLCBpY29uOiBGaWxlVGV4dCB9LFxyXG4gICAgeyB0ZXh0OiAnWW91ciBBY2NvdW50JywgaWNvbjogVXNlciB9LFxyXG4gICAgeyB0ZXh0OiAnSGVscCBDZW50ZXInLCBpY29uOiBIZWxwQ2lyY2xlIH1cclxuXTtcclxuZXhwb3J0IGNvbnN0IGJlZm9yZUxvZ2luUGFnZXNMaW5rQXJyYXkgPSBbXHJcbiAgICB7IHRleHQ6ICdIb21lJywgaWNvbjogSG9tZSB9LFxyXG4gICAgeyB0ZXh0OiAnR2V0IFN0YXJ0ZWQnLCBpY29uOiBTZW5kIH0sXHJcbiAgICB7IHRleHQ6ICdPdXIgUHJvZ3JhbXMnLCBpY29uOiBGaWxlVGV4dCB9LFxyXG4gICAgeyB0ZXh0OiAnSGVscCBDZW50ZXInLCBpY29uOiBIZWxwQ2lyY2xlIH1cclxuXTtcclxuIiwiaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICAgIGxvZ2luV3JhcHBlcjoge1xyXG4gICAgICAgIHBvc2l0aW9uOiAnZml4ZWQnLFxyXG4gICAgICAgIGxlZnQ6IDAsXHJcbiAgICAgICAgcmlnaHQ6IDAsXHJcbiAgICAgICAgdG9wOiAwLFxyXG4gICAgICAgIGJvdHRvbTogMCxcclxuICAgICAgICB3aWR0aDogJzEwMCUnLFxyXG4gICAgICAgIGhlaWdodDogJzEwMHZoJyxcclxuICAgICAgICB6SW5kZXg6ICc5OTk5OScsXHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLm1lbnVzLm1lbnVCYWNrZ3JvdW5kXHJcbiAgICB9LFxyXG4gICAgYmVmb3JlTG9naW5XcmFwcGVyOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLmNvbW1vbi53aGl0ZVxyXG4gICAgfSxcclxuICAgIG1lbnVCdXR0b246IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLmNvbW1vbi53aGl0ZVxyXG4gICAgfSxcclxuICAgIHRvcEltYWdlUG9zaXRpb246IHtcclxuICAgICAgICB0b3A6ICc0MHB4J1xyXG4gICAgfSxcclxuICAgIGJvdHRvbUltYWdlUG9zaXRpb246IHtcclxuICAgICAgICBib3R0b206ICczMHB4J1xyXG4gICAgfSxcclxuICAgIGN1c3RvbUJ1dHRvbjoge1xyXG4gICAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5Lmg2LmZvbnRTaXplLFxyXG4gICAgICAgIGNvbG9yOiB0aGVtZS5wYWxldHRlLnByaW1hcnkubWFpblxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL01vYmlsZU1lbnUnO1xyXG4iLCJpbXBvcnQgeyBCb3gsIEljb25CdXR0b24sIExpbmssIERpYWxvZyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IHVzZU1lZGlhUXVlcnkgZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvdXNlTWVkaWFRdWVyeSc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcbmltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2hldnJvbkxlZnQsIFggfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL1RvcEhlYWRlclN0eWxlcyc7XHJcbmltcG9ydCBFeGl0RGlhbG9nQm94IGZyb20gJ34vc2hhcmVkL2NvbXBvbmVudHMvRXhpdERpYWxvZ0JveCc7XHJcblxyXG4vKipcclxuICogTmFtZTogVG9wSGVhZGVyXHJcbiAqIERlc2M6IFJlbmRlciBUb3BIZWFkZXJcclxuICogQHBhcmFtICB7Ym9vbH0gIGlzV2l6YXJkXHJcbiAqL1xyXG5cclxuXHJcbmNvbnN0IFRvcEhlYWRlciA9ICh7IGlzV2l6YXJkLCBvbkNsaWNrQmFjaywgb25FeGl0Q2xpY2ssIHRpdGxlPScnfSkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgYnJlYWtQb2ludCA9IHVzZU1lZGlhUXVlcnkoJyhtaW4td2lkdGg6MTE1MnB4KScpO1xyXG4gICAgY29uc3QgbGlua05hbWVBcnJheSA9IFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGxpbmtOYW1lOiAnRXNwYcOxb2wnXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGxpbmtOYW1lOiAnQWJvdXQnXHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAgIGxpbmtOYW1lOiAnTGFuZGxvcmQgUG9ydGFsJ1xyXG4gICAgICAgIH1cclxuICAgIF07XHJcblxyXG4gICAgY29uc3QgW29wZW5EaWFsb2csIHNldE9wZW5EaWFsb2ddID0gdXNlU3RhdGUoZmFsc2UpO1xyXG4gICAgY29uc3QgaGFuZGxlQ2xvc2UgPSAoKSA9PiB7XHJcbiAgICAgICAgc2V0T3BlbkRpYWxvZyhmYWxzZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgIHB0PXsxfVxyXG4gICAgICAgICAgICBwcj17YnJlYWtQb2ludCA/IDYgOiAxfVxyXG4gICAgICAgICAgICBwYj17MX1cclxuICAgICAgICAgICAgcGw9e2JyZWFrUG9pbnQgPyA2IDogM31cclxuICAgICAgICAgICAgYmdjb2xvcj1cIm1lbnVzLm1lbnVCYWNrZ3JvdW5kXCI+XHJcbiAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIganVzdGlmeUNvbnRlbnQ9XCJzcGFjZS1iZXR3ZWVuXCI+XHJcbiAgICAgICAgICAgICAgICA8Qm94IGRpc3BsYXk9XCJmbGV4XCIgYWxpZ25JdGVtcz1cImNlbnRlclwiIG1heFdpZHRoPXs3NTB9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtpc1dpemFyZCAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggbXI9ezAuNX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbiBvbkNsaWNrPXtvbkNsaWNrQmFja30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPENoZXZyb25MZWZ0IHN0cm9rZVdpZHRoPVwiMlwiIGNvbG9yPVwiSW5kaWdvXCIgc2l6ZT17MjJ9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICl9XHJcbiAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBjb2xvcj1cInByaW1hcnkubGlnaHRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT17MTV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ9XCIyMXB4XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHsgdGl0bGUgPyB0aXRsZSA6ICdIb3VzaW5nIEFzc2lzdGFuY2UgRWxpZ2libGl0eSBhbmQgUHJlQXBwbGljYXRpb24nIH1cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbG9yPVwicHJpbWFyeS5saWdodFwiXHJcbiAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJsZy5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgcG9zaXRpb249XCJyZWxhdGl2ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgdG9wPVwiLTEwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9eyFicmVha1BvaW50ID8gJ2ZsZXgnIDogJ25vbmUnfT5cclxuICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPFggc3Ryb2tlV2lkdGg9XCIzXCIgY29sb3I9XCJCbGFja1wiIHNpemU9ezE1fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDwvSWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveCBhbGlnbkl0ZW1zPVwiY2VudGVyXCIgZGlzcGxheT17YnJlYWtQb2ludCA/ICdmbGV4JyA6ICdub25lJ30+XHJcbiAgICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICAgICBpc1dpemFyZCA/IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBjbGFzc05hbWU9e2NsYXNzZXMubGlua30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIvXCIgdW5kZXJsaW5lPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cImJvZHk1LmZvbnRTaXplXCIgY29sb3I9XCJidXR0b24uc2Vjb25kYXJ5Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBDQU5DRUwgQVBQTElDQVRJT05cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBjbGFzc05hbWU9e2NsYXNzZXMubGlua30+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiIG9uQ2xpY2s9eygpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldE9wZW5EaWFsb2codHJ1ZSk7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH19PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveCBmb250U2l6ZT1cImJvZHk1LmZvbnRTaXplXCIgY29sb3I9XCJidXR0b24uc2Vjb25kYXJ5Q29sb3JcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBTQVZFIEFORCBFWElUXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEaWFsb2dcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbG9zZT17aGFuZGxlQ2xvc2V9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWxsZWRieT1cInNpbXBsZS1kaWFsb2ctdGl0bGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGVuPXtvcGVuRGlhbG9nfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEV4aXREaWFsb2dCb3ggb25DbG9zZT17aGFuZGxlQ2xvc2V9IG9uQ29uZmlybT17b25FeGl0Q2xpY2t9IC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9EaWFsb2c+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Lz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2xpbmtOYW1lQXJyYXkubWFwKChpdGVtKSA9PiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3gga2V5PXtpdGVtLmxpbmtOYW1lfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxMaW5rIGhyZWY9XCIjXCIgdW5kZXJsaW5lPVwibm9uZVwiPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3ggZm9udFNpemU9XCJib2R5NS5mb250U2l6ZVwiIGNvbG9yPVwiYnV0dG9uLnNlY29uZGFyeUNvbG9yXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtpdGVtLmxpbmtOYW1lfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgIDwvQm94PlxyXG4gICAgKTtcclxufTtcclxuVG9wSGVhZGVyLmRlZmF1bHRQcm9wcyA9IHtcclxuICAgIGlzV2l6YXJkOiBmYWxzZSxcclxuICAgIHRpdGxlOiBudWxsLFxyXG4gICAgb25DbGlja0JhY2s6IFByb3BUeXBlcy5mdW5jLFxyXG59O1xyXG5Ub3BIZWFkZXIucHJvcFR5cGVzID0ge1xyXG4gICAgaXNXaXphcmQ6IFByb3BUeXBlcy5ib29sLFxyXG4gICAgb25DbGlja0JhY2s6IFByb3BUeXBlcy5mdW5jLFxyXG4gICAgb25FeGl0Q2xpY2s6IFByb3BUeXBlcy5mdW5jLFxyXG4gICAgdGl0bGU6IFByb3BUeXBlcy5zdHJpbmdcclxufTtcclxuZXhwb3J0IGRlZmF1bHQgVG9wSGVhZGVyO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvc3R5bGVzJztcclxuXHJcbmNvbnN0IHVzZVN0eWxlcyA9IG1ha2VTdHlsZXMoKHRoZW1lKSA9PiAoe1xyXG4gICAgbGluazoge1xyXG4gICAgICAgICcmOm5vdCg6bGFzdC1jaGlsZCknOiB7XHJcbiAgICAgICAgICAgIG1hcmdpblJpZ2h0OnRoZW1lLnNwYWNpbmcoNiksXHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxyXG4gICAgICAgICAgICAnJjo6YWZ0ZXInOiB7XHJcbiAgICAgICAgICAgICAgICBjb250ZW50OiBcIid8J1wiLFxyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgICAgICAgICAgICByaWdodDogJy0yNnB4JyxcclxuICAgICAgICAgICAgICAgIHRvcDogMCxcclxuICAgICAgICAgICAgICAgIGJvdHRvbTogMCxcclxuICAgICAgICAgICAgICAgIGNvbG9yOiAnaW5oZXJpdCdcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgIH1cclxufSkpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXNlU3R5bGVzO1xyXG4iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9Ub3BIZWFkZXInO1xyXG4iLCJpbXBvcnQgeyBCb3ggfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBGZWF0aGVySWNvbiBmcm9tICdmZWF0aGVyLWljb25zLXJlYWN0JztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL0luZGljYXRvcnNTdHlsZXMnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWU6IEluZGljYXRvcnNcclxuICogRGVzYzogUmVuZGVyIEluZGljYXRvcnNcclxuICogQHBhcmFtIHsgc3RyaW5nIH0gY2xhc3NOYW1lc1xyXG4gKi9cclxuXHJcbmNvbnN0IEluZGljYXRvcnMgPSAoeyBzdGF0dXMsIHNpemUsIGljb25OYW1lLCBpY29uU2l6ZSwgYm9yZGVyV2lkdGgsIGljb25Db2xvciB9KSA9PiB7XHJcbiAgICBjb25zdCBjbGFzc2VzID0gdXNlU3R5bGVzKCk7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3hcclxuICAgICAgICAgICAgd2lkdGg9e3NpemV9XHJcbiAgICAgICAgICAgIGhlaWdodD17c2l6ZX1cclxuICAgICAgICAgICAgYm9yZGVyUmFkaXVzPVwiNTAlXCJcclxuICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICBtYXJnaW49XCIwIGF1dG9cIlxyXG4gICAgICAgICAgICBib3JkZXI9e2JvcmRlcldpZHRofVxyXG4gICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXNbc3RhdHVzXX0+XHJcbiAgICAgICAgICAgIDxGZWF0aGVySWNvbiBpY29uPXtpY29uTmFtZX0gc2l6ZT17aWNvblNpemV9IGNvbG9yPXtpY29uQ29sb3J9IC8+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5cclxuSW5kaWNhdG9ycy5kZWZhdWx0UHJvcHMgPSB7XHJcbiAgICBzaXplOiA4MCxcclxuICAgIHN0YXR1czogJ2RlZmF1bHQnLFxyXG4gICAgaWNvbk5hbWU6ICd0aHVtYnMtdXAnLFxyXG4gICAgaWNvblNpemU6IDM2LFxyXG4gICAgYm9yZGVyV2lkdGg6IDhcclxufTtcclxuXHJcbkluZGljYXRvcnMucHJvcFR5cGVzID0ge1xyXG4gICAgc3RhdHVzOiBQcm9wVHlwZXMub25lT2YoWydzdWNjZXNzJywgJ2ZhaWxlZCcsICdwZW5kaW5nJywgJ2RlZmF1bHQnLCAnY29tcGxldGUnXSksXHJcbiAgICBzaXplOiBQcm9wVHlwZXMubnVtYmVyLFxyXG4gICAgaWNvblNpemU6IFByb3BUeXBlcy5udW1iZXIsXHJcbiAgICBib3JkZXJXaWR0aDogUHJvcFR5cGVzLm51bWJlcixcclxuICAgIGljb25OYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgaWNvbkNvbG9yOiBQcm9wVHlwZXMuc3RyaW5nXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBJbmRpY2F0b3JzO1xyXG4iLCJpbXBvcnQgeyBtYWtlU3R5bGVzIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCh0aGVtZSkgPT4gKHtcclxuICAgIGZhaWxlZDoge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5lcnJvci5saWdodCxcclxuICAgICAgICBib3JkZXJDb2xvcjogYCR7dGhlbWUucGFsZXR0ZS5lcnJvci5tYWlufSAhaW1wb3J0YW50YFxyXG4gICAgfSxcclxuICAgIHBlbmRpbmc6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUucGVuZGluZy5saWdodCxcclxuICAgICAgICBib3JkZXJDb2xvcjogYCR7dGhlbWUucGFsZXR0ZS5wZW5kaW5nLm1haW59ICFpbXBvcnRhbnRgXHJcbiAgICB9LFxyXG4gICAgc3VjY2Vzczoge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5zdWNjZXNzLmxpZ2h0LFxyXG4gICAgICAgIGJvcmRlckNvbG9yOiBgJHt0aGVtZS5wYWxldHRlLnN1Y2Nlc3MubWFpbn0gIWltcG9ydGFudGBcclxuICAgIH0sXHJcbiAgICBkZWZhdWx0OiB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiAndHJhbnNwYXJlbnQnLFxyXG4gICAgICAgIGJvcmRlckNvbG9yOiBgJHt0aGVtZS5wYWxldHRlLmRlZmF1bHQubWFpbn0gIWltcG9ydGFudGBcclxuICAgIH0sXHJcbiAgICBjb21wbGV0ZToge1xyXG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUuY29tbW9uLndoaXRlLFxyXG4gICAgICAgIGJvcmRlcjogJzhweCBzb2xpZCByZ2JhKDI1NSwgMjU1LCAyNTUsIC41KScsXHJcbiAgICAgICAgJy13ZWJraXQtYmFja2dyb3VuZC1jbGlwJzogJ3BhZGRpbmctYm94JyxcclxuICAgICAgICBiYWNrZ3JvdW5kQ2xpcDogJ3BhZGRpbmctYm94J1xyXG4gICAgfVxyXG59KSk7XHJcbmV4cG9ydCBkZWZhdWx0IHVzZVN0eWxlcztcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vSW5kaWNhdG9ycyciLCJpbXBvcnQgeyBCb3ggfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi9Mb2dvSGVhZGluZ1N0eWxlcyc7XHJcblxyXG4vKipcclxuICogTmFtZSA6IExvZ29IZWFkaW5nXHJcbiAqIERlc2MgOiBSZW5kZXIgTG9nb0hlYWRpbmdcclxuICogQHBhcmFtICB7c3RyaW5nfSAgbGFiZWxOYW1lXHJcbiAqIEBwYXJhbSAge3N0cmluZ30gIHRpdGxlXHJcbiAqIEBwYXJhbSAge2Jvb2xlYW59ICBpc0xvZ2dlZEluXHJcbiAqIEBwYXJhbSAge3N0cmluZ30gIGJyZWFrUG9pbnRcclxuICovXHJcblxyXG5jb25zdCBMb2dvSGVhZGluZyA9ICh7IHRpdGxlLCBsYWJlbE5hbWUsIGlzTG9nZ2VkSW4sIGJyZWFrUG9pbnQgfSkgPT4ge1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgY29sb3IgPSBpc0xvZ2dlZEluID8gJ2NvbW1vbi53aGl0ZScgOiAncHJpbWFyeS5saWdodCc7XHJcbiAgICBjb25zdCBzdWJUZXh0Q29sb3IgPSBpc0xvZ2dlZEluID8gJ2NvbW1vbi53aGl0ZScgOiAncHJpbWFyeS5saWdodCc7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBmbGV4RGlyZWN0aW9uPVwiY29sdW1uXCI+XHJcbiAgICAgICAgICAgIDw+XHJcbiAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgZm9udFNpemU9XCJoNC5mb250U2l6ZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgZm9udEZhbWlseT1cImZvbnRGYW1pbHkuZXh0cmFCb2xkXCJcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj17Y29sb3J9XHJcbiAgICAgICAgICAgICAgICAgICAgb3ZlcmZsb3c9XCJoaWRkZW5cIlxyXG4gICAgICAgICAgICAgICAgICAgIHdoaXRlU3BhY2U9XCJub3dyYXBcIlxyXG4gICAgICAgICAgICAgICAgICAgIG1heFdpZHRoPVwiMzUwcHhcIlxyXG4gICAgICAgICAgICAgICAgICAgIHRleHRPdmVyZmxvdz1cImVsbGlwc2lzXCJcclxuICAgICAgICAgICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzZXMudGl0bGV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHshaXNMb2dnZWRJbiB8fCBicmVha1BvaW50ID8gdGl0bGUgOiAnJ31cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJub25lXCJcclxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImJvZHk1LmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nPVwiNHB4XCJcclxuICAgICAgICAgICAgICAgICAgICBjb2xvcj17c3ViVGV4dENvbG9yfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlcy5sYWJlbE5hbWV9PlxyXG4gICAgICAgICAgICAgICAgICAgIHtsYWJlbE5hbWV9XHJcbiAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5cclxuTG9nb0hlYWRpbmcuZGVmYXVsdFByb3BzID0ge307XHJcbkxvZ29IZWFkaW5nLnByb3BUeXBlcyA9IHtcclxuICAgIHRpdGxlOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgbGFiZWxOYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgaXNMb2dnZWRJbjogUHJvcFR5cGVzLmJvb2wsXHJcbiAgICBicmVha1BvaW50OiBQcm9wVHlwZXMuYm9vbFxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTG9nb0hlYWRpbmc7XHJcbiIsImltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgICBsYWJlbE5hbWU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ2xnJyldOiB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6ICdibG9jaydcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgdGl0bGU6IHtcclxuICAgICAgICBbdGhlbWUuYnJlYWtwb2ludHMudXAoJ2xnJyldOiB7XHJcbiAgICAgICAgICAgIGZvbnRTaXplOiB0aGVtZS50eXBvZ3JhcGh5LmgyLmZvbnRTaXplXHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7ZGVmYXVsdH0gZnJvbSAnLi9Mb2dvSGVhZGluZyc7IiwiaW1wb3J0IHsgQm94LCBCdXR0b24sIENhcmQsIEljb25CdXR0b24sIE1lbnUsIE1lbnVJdGVtIH0gZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUnO1xyXG5pbXBvcnQgRmVhdGhlckljb24gZnJvbSAnZmVhdGhlci1pY29ucy1yZWFjdCc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcbmltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IG5vb3AgfSBmcm9tICd+L3NoYXJlZC91dGlscy91dGlscyc7XHJcbmltcG9ydCBJbmRpY2F0b3IgZnJvbSAnLi4vSW5kaWNhdG9ycyc7XHJcbmltcG9ydCB1c2VTdHlsZXMgZnJvbSAnLi9PYmplY3RDYXJkU3R5bGUnO1xyXG5cclxuLyoqXHJcbiAqIE5hbWUgOiBPYmplY3RDYXJkXHJcbiAqIERlc2MgOiBSZW5kZXIgT2JqZWN0Q2FyZFxyXG4gKiovXHJcblxyXG5jb25zdCBPYmplY3RDYXJkID0gKHByb3BzKSA9PiB7XHJcbiAgICBjb25zdCB7IGNoaWxkcmVuLCB2YXJpYW50LCBpY29uTmFtZSwgY2FyZFR5cGUsIG9uQ2xpY2ssIG9uRGVsZXRlLCBpc01lbWJlciwgb25FZGl0Q2xpY2ssIHNob3dPcHRpb25NZW51IH0gPVxyXG4gICAgICAgIHByb3BzO1xyXG4gICAgY29uc3QgY2xhc3NlcyA9IHVzZVN0eWxlcygpO1xyXG4gICAgY29uc3QgW2FuY2hvckVsLCBzZXRBbmNob3JFbF0gPSBSZWFjdC51c2VTdGF0ZShudWxsKTtcclxuICAgIGNvbnN0IG9wZW4gPSBCb29sZWFuKGFuY2hvckVsKTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDbGljayA9IChldmVudCkgPT4ge1xyXG4gICAgICAgIHNldEFuY2hvckVsKGV2ZW50LmN1cnJlbnRUYXJnZXQpO1xyXG4gICAgfTtcclxuXHJcbiAgICBjb25zdCBoYW5kbGVDbG9zZSA9ICgpID0+IHtcclxuICAgICAgICBzZXRBbmNob3JFbChudWxsKTtcclxuICAgIH07XHJcblxyXG4gICAgY29uc3QgaGFuZGxlRWRpdCA9ICgpID0+IHtcclxuICAgICAgICBvbkVkaXRDbGljaygpO1xyXG4gICAgICAgIGhhbmRsZUNsb3NlKCk7XHJcbiAgICB9O1xyXG4gICAgY29uc3QgaGFuZGxlRGVsZXRlID0gKCkgPT4ge1xyXG4gICAgICAgIG9uRGVsZXRlKCk7XHJcbiAgICAgICAgaGFuZGxlQ2xvc2UoKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICB7Y2FyZFR5cGUgPT09ICdvYmplY3RDYXJkJyA/IChcclxuICAgICAgICAgICAgICAgIDxDYXJkIG9uQ2xpY2s9e29uQ2xpY2t9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxCb3ggZGlzcGxheT1cImZsZXhcIiBhbGlnbkl0ZW1zPVwiY2VudGVyXCIgcHg9ezJ9IHB5PXsyLjV9IG1pbkhlaWdodD17OTZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEluZGljYXRvclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezM3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1cz17dmFyaWFudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uTmFtZT17aWNvbk5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyV2lkdGg9ezMuN31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uU2l6ZT17MTh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAge2NoaWxkcmVuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmbGV4R3Jvdz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbj1cImNvbHVtblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsPXsxLjV9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7c2hvd09wdGlvbk1lbnUgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHA9ezAuMjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgbXI9ey0xLjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGp1c3RpZnlDb250ZW50PVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2lzTWVtYmVyID8gKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b24gY29sb3I9XCJwcmltYXJ5XCIgb25DbGljaz17aGFuZGxlQ2xpY2t9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxGZWF0aGVySWNvbiBpY29uPVwibW9yZS12ZXJ0aWNhbFwiIHNpemU9XCIyNFwiIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVudVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlkPVwibG9uZy1tZW51XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbmNob3JFbD17YW5jaG9yRWx9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAga2VlcE1vdW50ZWRcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBvcGVuPXtvcGVufVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xvc2U9e2hhbmRsZUNsb3NlfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8TWVudUl0ZW0gb25DbGljaz17aGFuZGxlRWRpdH0+RWRpdDwvTWVudUl0ZW0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPE1lbnVJdGVtIG9uQ2xpY2s9e2hhbmRsZURlbGV0ZX0+RGVsZXRlPC9NZW51SXRlbT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvTWVudT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEljb25CdXR0b24gY29sb3I9XCJwcmltYXJ5XCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8RmVhdGhlckljb24gaWNvbj1cIm1vcmUtdmVydGljYWxcIiBzaXplPVwiMjRcIiAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0ljb25CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgKSA6IChcclxuICAgICAgICAgICAgICAgIDxCb3ggY2xhc3NOYW1lPXtjbGFzc2VzLnJvb3RVcGxvYWR9PlxyXG4gICAgICAgICAgICAgICAgICAgIDxpbnB1dFxyXG4gICAgICAgICAgICAgICAgICAgICAgICBhY2NlcHQ9XCJpbWFnZS8qXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbGFzc2VzLmlucHV0fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBpZD1cImNvbnRhaW5lZC1idXR0b24tZmlsZVwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG11bHRpcGxlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHR5cGU9XCJmaWxlXCJcclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwiY29udGFpbmVkLWJ1dHRvbi1maWxlXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCdXR0b24gdmFyaWFudD1cImNvbnRhaW5lZFwiIGNvbXBvbmVudD1cInNwYW5cIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT1cImZsZXhcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcHg9ezJ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB5PXsxLjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbkhlaWdodD17OTZ9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Qm94PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPEluZGljYXRvclxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNpemU9ezM3fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YXR1cz17dmFyaWFudH1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uTmFtZT17aWNvbk5hbWV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyV2lkdGg9ezMuN31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpY29uU2l6ZT17MTh9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAge2NoaWxkcmVuICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmbGV4R3Jvdz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZmxleERpcmVjdGlvbj1cImNvbHVtblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBsPXsyfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvQ2FyZD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9CdXR0b24+XHJcbiAgICAgICAgICAgICAgICAgICAgPC9sYWJlbD5cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICApfVxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufTtcclxuXHJcbk9iamVjdENhcmQuZGVmYXVsdFByb3BzID0ge1xyXG4gICAgdmFyaWFudDogJ3N1Y2Nlc3MnLFxyXG4gICAgY2hpbGRyZW46ICcnLFxyXG4gICAgaWNvbk5hbWU6ICd1c2VyJyxcclxuICAgIGNhcmRUeXBlOiAnb2JqZWN0Q2FyZCcsXHJcbiAgICBvbkNsaWNrOiBub29wLFxyXG4gICAgaXNNZW1iZXI6IGZhbHNlLFxyXG4gICAgb25FZGl0Q2xpY2s6IG5vb3AsXHJcbiAgICBvbkRlbGV0ZTogbm9vcCxcclxuICAgIHNob3dPcHRpb25NZW51IDogdHJ1ZVxyXG59O1xyXG5cclxuT2JqZWN0Q2FyZC5wcm9wVHlwZXMgPSB7XHJcbiAgICB2YXJpYW50OiBQcm9wVHlwZXMub25lT2YoWydzdWNjZXNzJywgJ2ZhaWxlZCcsICdwZW5kaW5nJ10pLFxyXG4gICAgY2FyZFR5cGU6IFByb3BUeXBlcy5vbmVPZihbJ29iamVjdENhcmQnLCAnYWN0aW9uQ2FyZCddKSxcclxuICAgIGNoaWxkcmVuOiBQcm9wVHlwZXMubm9kZSxcclxuICAgIGljb25OYW1lOiBQcm9wVHlwZXMuc3RyaW5nLFxyXG4gICAgb25DbGljazogUHJvcFR5cGVzLmZ1bmMsXHJcbiAgICBpc01lbWJlcjogUHJvcFR5cGVzLmJvb2wsXHJcbiAgICBvbkVkaXRDbGljazogUHJvcFR5cGVzLmZ1bmMsXHJcbiAgICBvbkRlbGV0ZTogUHJvcFR5cGVzLmZ1bmMsXHJcbiAgICBzaG93T3B0aW9uTWVudSA6IFByb3BUeXBlcy5ib29sLFxyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgT2JqZWN0Q2FyZDtcclxuIiwiaW1wb3J0IHsgbWFrZVN0eWxlcyB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlL3N0eWxlcyc7XHJcblxyXG5jb25zdCB1c2VTdHlsZXMgPSBtYWtlU3R5bGVzKCgpID0+ICh7XHJcbiAgICByb290VXBsb2FkOiB7XHJcbiAgICAgICAgJyYgPiAqJzoge1xyXG4gICAgICAgICAgICBtYXJnaW46IDBcclxuICAgICAgICB9LFxyXG4gICAgICAgICcmIC5NdWlCdXR0b24tcm9vdCc6IHtcclxuICAgICAgICAgICAgd2lkdGg6ICcxMDAlJyxcclxuICAgICAgICAgICAgcGFkZGluZzogJzAnXHJcbiAgICAgICAgfSxcclxuICAgICAgICAnJiAuTXVpQ2FyZC1yb290Jzoge1xyXG4gICAgICAgICAgICB3aWR0aDogJzEwMCUnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIGlucHV0OiB7XHJcbiAgICAgICAgZGlzcGxheTogJ25vbmUnXHJcbiAgICB9LFxyXG4gICAgJy5NdWlCdXR0b25CYXNlLXJvb3QnOiB7XHJcbiAgICAgICAgcGFkZGluZzogMFxyXG4gICAgfVxyXG59KSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCB1c2VTdHlsZXM7XHJcbiIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL09iamVjdENhcmQnO1xyXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnO1xyXG5pbXBvcnQgeyBCb3gsIFR5cG9ncmFwaHkgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCBQcm9wVHlwZXMgZnJvbSAncHJvcC10eXBlcyc7XHJcblxyXG4vKiogXHJcbiAqIE5hbWUgOiBQYWdlSGVhZGluZ1xyXG4gKiBEZXNjIDogUmVuZGVyIFBhZ2VIZWFkaW5nXHJcbiAqIEBwYXJhbSB7c3RyaW5nfSB0aXRsZSBcclxuICoqL1xyXG5cclxuY29uc3QgUGFnZUhlYWRpbmcgPSAoeyB0aXRsZSB9KSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDw+XHJcbiAgICAgICAgICAgPEJveCBjb2xvcj0ncHJpbWFyeS5tYWluJyBmb250RmFtaWx5PSdmb250RmFtaWx5LmJvbGQnIGxldHRlclNwYWNpbmc9ezh9IHBiPXszfSBjbGFzc05hbWU9J3RleHRUcmFuc2Zvcm0nPlxyXG4gICAgICAgICAgICAgICAgPFR5cG9ncmFwaHkgdmFyaWFudD1cImgyXCI+XHJcbiAgICAgICAgICAgICAgICAgICB7dGl0bGV9XHJcbiAgICAgICAgICAgICAgICA8L1R5cG9ncmFwaHk+XHJcbiAgICAgICAgICAgIDwvQm94PiAgXHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59O1xyXG5QYWdlSGVhZGluZy5kZWZhdWx0UHJvcHMgPSB7fTtcclxuUGFnZUhlYWRpbmcucHJvcFR5cGVzID0ge1xyXG4gICAgdGl0bGU6IFByb3BUeXBlcy5zdHJpbmcsXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBQYWdlSGVhZGluZ1xyXG4iLCJleHBvcnQgeyBkZWZhdWx0IH0gZnJvbSAnLi9QYWdlSGVhZGluZyciLCJpbXBvcnQgeyBCb3gsIENhcmQsIEljb25CdXR0b24gfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZSc7XHJcbmltcG9ydCB3aXRoV2lkdGggZnJvbSAnQG1hdGVyaWFsLXVpL2NvcmUvd2l0aFdpZHRoJztcclxuaW1wb3J0IGNsc3ggZnJvbSAnY2xzeCc7XHJcbmltcG9ydCBJbWFnZSBmcm9tICduZXh0L2ltYWdlJztcclxuaW1wb3J0IFByb3BUeXBlcyBmcm9tICdwcm9wLXR5cGVzJztcclxuaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgQ2hldnJvblJpZ2h0LCBUcmFzaDIgfSBmcm9tICdyZWFjdC1mZWF0aGVyJztcclxuaW1wb3J0IHVzZVN0eWxlcyBmcm9tICcuL1Byb2dyYW1DYXJkc1N0eWxlJztcclxuXHJcbi8qKlxyXG4gKiBOYW1lIDogUHJvZ3JhbUNhcmRcclxuICogRGVzYyA6IFJlbmRlciBQcm9ncmFtQ2FyZFxyXG4gKiovXHJcblxyXG5jb25zdCBQcm9ncmFtQ2FyZCA9IChwcm9wcykgPT4ge1xyXG4gICAgY29uc3Qge1xyXG4gICAgICAgIGNoaWxkcmVuLFxyXG4gICAgICAgIHNob3dMZWZ0QXJyb3csXHJcbiAgICAgICAgdmFyaWFudCxcclxuICAgICAgICBzaG93RGVsZXRlQm94LFxyXG4gICAgICAgIHNob3dJbWFnZSxcclxuICAgICAgICBzaG93TGVmdEJvcmRlcixcclxuICAgICAgICBpbWdVcmwsXHJcbiAgICAgICAgd2lkdGhcclxuICAgIH0gPSBwcm9wcztcclxuICAgIGNvbnN0IGNsYXNzZXMgPSB1c2VTdHlsZXMoKTtcclxuICAgIHJldHVybiAoXHJcbiAgICAgICAgPEJveCBwb3NpdGlvbj1cInJlbGF0aXZlXCI+XHJcbiAgICAgICAgICAgIDxDYXJkPlxyXG4gICAgICAgICAgICAgICAgPEJveCBkaXNwbGF5PVwiZmxleFwiPlxyXG4gICAgICAgICAgICAgICAgICAgIHtzaG93TGVmdEJvcmRlciAmJiAoXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIDxCb3hcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbldpZHRoPXsxNn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbkhlaWdodD17OTZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBib3JkZXJSYWRpdXM9XCI1MHB4IDAgMCA1MHB4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBvc2l0aW9uPXt3aWR0aCA9PT0gJ3hzJyA/ICdzdGF0aWMnIDogJ2Fic29sdXRlJ31cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGxlZnQ9XCIwXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHpJbmRleD17MX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT17Y2xhc3Nlc1t2YXJpYW50XX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7c2hvd0ltYWdlICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtjbHN4KGNsYXNzZXMub3ZlcmxheSwgY2xhc3Nlc1t2YXJpYW50XSl9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtcj17Mi41fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGlzcGxheT17d2lkdGggPT09ICd4cycgPyAnbm9uZScgOiAnaW5oZXJpdCd9PlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz17aW1nVXJsfSB3aWR0aD17MTMzfSBoZWlnaHQ9ezk2fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG5cclxuICAgICAgICAgICAgICAgICAgICB7Y2hpbGRyZW4gJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmbGV4R3Jvdz17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHB4PXsxLjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBweT17Mn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGRpc3BsYXk9XCJmbGV4XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb249XCJjb2x1bW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAganVzdGlmeUNvbnRlbnQ9XCJjZW50ZXJcIj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHtjaGlsZHJlbn1cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuXHJcbiAgICAgICAgICAgICAgICAgICAge3Nob3dMZWZ0QXJyb3cgJiYgKFxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwPXswLjI1fVxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcHI9ezEuMjV9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8SWNvbkJ1dHRvbj5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q2hldnJvblJpZ2h0IHN0cm9rZS13aWR0aD1cIjNcIiBjb2xvcj1cIkluZGlnb1wiIHNpemU9ezI0fSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPC9JY29uQnV0dG9uPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICApfVxyXG4gICAgICAgICAgICAgICAgICAgIHtzaG93RGVsZXRlQm94ICYmIChcclxuICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29tcG9uZW50PVwiYnV0dG9uXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHA9ezEuNX1cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJnY29sb3I9XCJlcnJvci5kYXJrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbG9yPVwiY29tbW9uLndoaXRlXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIG1pbkhlaWdodD17OTZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtaW5XaWR0aD17OTZ9XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBkaXNwbGF5PVwiZmxleFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBqdXN0aWZ5Q29udGVudD1cImNlbnRlclwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhbGlnbkl0ZW1zPVwiY2VudGVyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZsZXhEaXJlY3Rpb249XCJjb2x1bW5cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYm9yZGVyPXswfT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxUcmFzaDIgc3Ryb2tlLXdpZHRoPVwiMS41XCIgY29sb3I9XCJ3aGl0ZVwiIHNpemU9ezIwfSAvPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgPEJveFxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbXBvbmVudD1cImJvZHkxXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250U2l6ZT1cImxnLmZvbnRTaXplXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb250RmFtaWx5PVwiZm9udEZhbWlseS5yZWd1bGFyXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwdD17MC43NX0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgREVMRVRFXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L0JveD5cclxuICAgICAgICAgICAgICAgICAgICAgICAgPC9Cb3g+XHJcbiAgICAgICAgICAgICAgICAgICAgKX1cclxuICAgICAgICAgICAgICAgIDwvQm94PlxyXG4gICAgICAgICAgICA8L0NhcmQ+XHJcbiAgICAgICAgPC9Cb3g+XHJcbiAgICApO1xyXG59O1xyXG5cclxuUHJvZ3JhbUNhcmQuZGVmYXVsdFByb3BzID0ge1xyXG4gICAgY2hpbGRyZW46ICcnLFxyXG4gICAgc2hvd0xlZnRBcnJvdzogZmFsc2UsXHJcbiAgICBzaG93RGVsZXRlQm94OiBmYWxzZSxcclxuICAgIHNob3dJbWFnZTogZmFsc2UsXHJcbiAgICBzaG93TGVmdEJvcmRlcjogdHJ1ZSxcclxuICAgIGltZ1VybDogJy92aWV3LmpwZydcclxufTtcclxuXHJcblByb2dyYW1DYXJkLnByb3BUeXBlcyA9IHtcclxuICAgIHZhcmlhbnQ6IFByb3BUeXBlcy5vbmVPZihbJ3N1Y2Nlc3MnLCAnZmFpbGVkJywgJ3dhaXRpbmcnXSksXHJcbiAgICBjaGlsZHJlbjogUHJvcFR5cGVzLm5vZGUsXHJcbiAgICBzaG93TGVmdEFycm93OiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIHNob3dEZWxldGVCb3g6IFByb3BUeXBlcy5ib29sLFxyXG4gICAgc2hvd0ltYWdlOiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIHNob3dMZWZ0Qm9yZGVyOiBQcm9wVHlwZXMuYm9vbCxcclxuICAgIGltZ1VybDogUHJvcFR5cGVzLnN0cmluZyxcclxuICAgIHdpZHRoOiBQcm9wVHlwZXMuc3RyaW5nXHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCB3aXRoV2lkdGgoKShQcm9ncmFtQ2FyZCk7XHJcbiIsImltcG9ydCB7IG1ha2VTdHlsZXMgfSBmcm9tICdAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXMnO1xyXG5cclxuY29uc3QgdXNlU3R5bGVzID0gbWFrZVN0eWxlcygodGhlbWUpID0+ICh7XHJcbiAgICBmYWlsZWQ6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUuZXJyb3IubWFpbixcclxuICAgICAgICAnJjpiZWZvcmUnOiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6ICdyZ2JhKDI0NSwgNjYsIDE1LCAwLjUpICFpbXBvcnRhbnQnXHJcbiAgICAgICAgfVxyXG4gICAgfSxcclxuICAgIHdhaXRpbmc6IHtcclxuICAgICAgICBiYWNrZ3JvdW5kQ29sb3I6IHRoZW1lLnBhbGV0dGUucGVuZGluZy5tYWluLFxyXG4gICAgICAgICcmOmJlZm9yZSc6IHtcclxuICAgICAgICAgICAgYmFja2dyb3VuZDogJ3JnYmEoMjQ5LCAxOTEsIDIsIDAuNSkgIWltcG9ydGFudCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgLy8gcGVuZGluZzoge1xyXG4gICAgLy8gICAgIGJhY2tncm91bmRDb2xvcjogdGhlbWUucGFsZXR0ZS5wZW5kaW5nLm1haW5cclxuICAgIC8vIH0sXHJcbiAgICBzdWNjZXNzOiB7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiB0aGVtZS5wYWxldHRlLnN1Y2Nlc3MubGlnaHQsXHJcbiAgICAgICAgJyY6YmVmb3JlJzoge1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAncmdiYSg3OSwgMjQwLCAxODgsIDAuNSkgIWltcG9ydGFudCdcclxuICAgICAgICB9XHJcbiAgICB9LFxyXG4gICAgaW5mbzp7XHJcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOnRoZW1lLnBhbGV0dGUuaW5mby5tYWluXHJcbiAgICB9LFxyXG4gICAgb3ZlcmxheToge1xyXG4gICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxyXG4gICAgICAgICcmOmJlZm9yZSc6IHtcclxuICAgICAgICAgICAgY29udGVudDogJ1wiXCInLFxyXG4gICAgICAgICAgICB3aWR0aDogJzEwMCUnLFxyXG4gICAgICAgICAgICBoZWlnaHQ6ICcxMDAlJyxcclxuICAgICAgICAgICAgcG9zaXRpb246ICdhYnNvbHV0ZScsXHJcbiAgICAgICAgICAgIHRvcDogJzAnLFxyXG4gICAgICAgICAgICBib3R0b206ICcwJyxcclxuICAgICAgICAgICAgbGVmdDogJzAnLFxyXG4gICAgICAgICAgICByaWdodDogJzAnLFxyXG4gICAgICAgICAgICB6SW5kZXg6ICcxJ1xyXG4gICAgICAgIH1cclxuICAgIH1cclxufSkpO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgdXNlU3R5bGVzOyIsImV4cG9ydCB7IGRlZmF1bHQgfSBmcm9tICcuL1Byb2dyYW1DYXJkJyIsImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XHJcbmltcG9ydCB7IFpvb20sIFRvb2x0aXAsIEJveCB9IGZyb20gJ0BtYXRlcmlhbC11aS9jb3JlJztcclxuaW1wb3J0IEhlbHBPdXRsaW5lT3V0bGluZWRJY29uIGZyb20gJ0BtYXRlcmlhbC11aS9pY29ucy9IZWxwT3V0bGluZU91dGxpbmVkJztcclxuXHJcbmNvbnN0IFRvb2x0aXBzID0gKCkgPT4ge1xyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8VG9vbHRpcCBUcmFuc2l0aW9uQ29tcG9uZW50PXtab29tfSB0aXRsZT1cIkFkZFwiPlxyXG4gICAgICAgICAgICA8Qm94XHJcbiAgICAgICAgICAgICBkaXNwbGF5PSdmbGV4J1xyXG4gICAgICAgICAgICAgYWxpZ25JdGVtcz0nY2VudGVyJ1xyXG4gICAgICAgICAgICAgZm9udFNpemU9J3N1YnRpdGxlMi5mb250U2l6ZSdcclxuICAgICAgICAgICAgIGZvbnRGYW1pbHk9J1BvcHBpbnMtTWVkaXVtJ1xyXG4gICAgICAgICAgICAgY29sb3I9JyMyRjBCN0MnXHJcbiAgICAgICAgICAgICA+XHJcbiAgICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICAgPEhlbHBPdXRsaW5lT3V0bGluZWRJY29uLz4gPEJveCBwbD17MX0+IFdoYXQgaXMgdGhpcyA/IDwvQm94PjwvQm94PlxyXG4gICAgICAgIDwvVG9vbHRpcD5cclxuICAgIClcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgVG9vbHRpcHNcclxuIiwiZXhwb3J0IHsgZGVmYXVsdCB9IGZyb20gJy4vVG9vbHRpcCciLCJleHBvcnQgY29uc3QgUk9VVEVTID0ge1xyXG4gICAgSE9NRToge1xyXG4gICAgICAgIFJPVVRFOiAnLycsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnSG9tZScsXHJcbiAgICAgICAgTkFNRTogJ0hvbWUnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBFWEFNUExFUzoge1xyXG4gICAgICAgIFJPVVRFOiAnL2V4YW1wbGVzJywgLy9Gb3IgbGVhcm5pbmcgcHVycG9zZVxyXG4gICAgICAgIFRJVExFOiAnRXhhbXBsZXMnLFxyXG4gICAgICAgIE5BTUU6ICdFeGFtcGxlcycsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIFVTRVJfTE9HSU46IHtcclxuICAgICAgICBST1VURTogJy9sb2dpbicsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnTG9naW4nLFxyXG4gICAgICAgIE5BTUU6ICdMb2dpbidcclxuICAgIH0sXHJcbiAgICBMT0dJTjoge1xyXG4gICAgICAgIFJPVVRFOiAnL2FkbWluJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdBZG1pbicsXHJcbiAgICAgICAgTkFNRTogJ0xvZ2luJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG5cclxuICAgIFBST0ZJTEU6IHtcclxuICAgICAgICAvL25lZWQgdG8gYWRkIHF1ZXJ5IHBhcmFtc1xyXG4gICAgICAgIFJPVVRFOiAnL3Byb2ZpbGUnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ1Byb2ZpbGUnLFxyXG4gICAgICAgIE5BTUU6ICdQcm9maWxlJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgVk9VQ0hFUjoge1xyXG4gICAgICAgIC8vbmVlZCB0byBhZGQgcXVlcnkgcGFyYW1zXHJcbiAgICAgICAgUk9VVEU6ICcvdm91Y2hlcicsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnVm91Y2hlcicsXHJcbiAgICAgICAgTkFNRTogJ1ZvdWNoZXInLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcblxyXG4gICAgQUNDT1VOVDoge1xyXG4gICAgICAgIC8vbmVlZCB0byBhZGQgcXVlcnkgcGFyYW1zXHJcbiAgICAgICAgUk9VVEU6ICcvYWNjb3VudCcsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnQWNjb3VudCcsXHJcbiAgICAgICAgTkFNRTogJ0FjY291bnQnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcblxyXG4gICAgQUNDT1VOVF9ERVRBSUw6IHtcclxuICAgICAgICAvL25lZWQgdG8gYWRkIHF1ZXJ5IHBhcmFtc1xyXG4gICAgICAgIFJPVVRFOiAnL2FjY291bnRkZXRhaWwnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0FjY291bnQgRGV0YWlsJyxcclxuICAgICAgICBOQU1FOiAnQWNjb3VudCBEZXRhaWwnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcblxyXG4gICAgR0VUX1NUQVJURUQ6IHtcclxuICAgICAgICAvL25lZWQgdG8gYWRkIHF1ZXJ5IHBhcmFtc1xyXG4gICAgICAgIFJPVVRFOiAnL2dldHN0YXJ0ZWQnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0dldCBTdGFydGVkJyxcclxuICAgICAgICBOQU1FOiAnR2V0IFN0YXJ0ZWQnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcblxyXG4gICAgSEVMUDoge1xyXG4gICAgICAgIC8vbmVlZCB0byBhZGQgcXVlcnkgcGFyYW1zXHJcbiAgICAgICAgUk9VVEU6ICcvaGVscCcsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnSGVscCcsXHJcbiAgICAgICAgTkFNRTogJ0hlbHAnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcblxyXG4gICAgSEVMUF9UT1BJQ1M6IHtcclxuICAgICAgICAvL25lZWQgdG8gYWRkIHF1ZXJ5IHBhcmFtc1xyXG4gICAgICAgIFJPVVRFOiAnL2hlbHB0b3BpY3MnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0hlbHAgVG9waWNzJyxcclxuICAgICAgICBOQU1FOiAnSGVscCBUb3BpY3MnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcblxyXG4gICAgQ0hBTkdFX1BBU1NXT1JEOiB7XHJcbiAgICAgICAgLy9uZWVkIHRvIGFkZCBxdWVyeSBwYXJhbXNcclxuICAgICAgICBST1VURTogJy9jaGFuZ2VwYXNzd29yZCcsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnQ2hhbmdlIFBhc3N3b3JkJyxcclxuICAgICAgICBOQU1FOiAnQ2hhbmdlIFBhc3N3b3JkJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG5cclxuICAgIEZPUkdPVF9QQVNTV09SRDoge1xyXG4gICAgICAgIFJPVVRFOiAnL2ZvcmdvdHBhc3N3b3JkJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdGb3Jnb3QgUGFzc3dvcmQnLFxyXG4gICAgICAgIE5BTUU6ICdGb3Jnb3QgUGFzc3dvcmQnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBDT01NT05fQ09NUE9ORU5UX1NUWUxFOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvY29tbW9uY29tcG9uZW50c3R5bGUnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0NvbW1vbiBDb21wb25lbnQgU3R5bGUnLFxyXG4gICAgICAgIE5BTUU6ICdDb21tb24gQ29tcG9uZW50IFN0eWxlJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgQ09NTU9OX0ZVTExGTE9XUEFHRV9TVFlMRToge1xyXG4gICAgICAgIFJPVVRFOiAnL2NvbW1vbmZ1bGxwYWdlZmxvd3N0eWxlJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdDb21tb24gZnVsbHBhZ2VmbG93IFN0eWxlJyxcclxuICAgICAgICBOQU1FOiAnQ29tbW9uIGZ1bGxwYWdlZmxvdyBTdHlsZScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIFZPVUNIRVJfUkVDRUlWRUQ6IHtcclxuICAgICAgICBST1VURTogJy92b3VjaGVycmVjZWl2ZWRmdWxscGFnZXN0eWxlJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdWb3VjaGVyIFJlY2VpdmVkIFN0eWxlJyxcclxuICAgICAgICBOQU1FOiAnVm91Y2hlciBSZWNlaXZlZCBTdHlsZScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIERBU0hCT0FSRF9QQUdFX1NUWUxFOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvZGFzaGJvYXJkcGFnZXN0eWxlJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdEYXNoYm9hcmQgUGFnZSBTdHlsZScsXHJcbiAgICAgICAgTkFNRTogJ0Rhc2hib2FyZCBQYWdlIFN0eWxlJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgTEFORExPUkRfUEFHRV9TVFlMRToge1xyXG4gICAgICAgIFJPVVRFOiAnL2xhbmRsb3JkcGFnZXN0eWxlJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdMYW5kbG9yZCBQYWdlIFN0eWxlJyxcclxuICAgICAgICBOQU1FOiAnTGFuZGxvcmQgUGFnZSBTdHlsZScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIFNVUEVSVklTT1JfTE9HSU46IHtcclxuICAgICAgICBST1VURTogJy9hZG1pbi9sb2dpbicsIC8vU2hvdWxkIGJlIHVuaXF1ZVxyXG4gICAgICAgIFRJVExFOiAnQWRtaW4gTE9HSU4nLFxyXG4gICAgICAgIE5BTUU6ICdBZG1pbiBMT0dJTidcclxuICAgIH0sXHJcbiAgICBDSEVDS19FTElHSUJJTElUWToge1xyXG4gICAgICAgIFJPVVRFOiAnL2NoZWNrLXlvdXItZWxpZ2liaWxpdHknLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0NoZWNrIFlvdXIgRWxpZ2liaWxpdHknLFxyXG4gICAgICAgIE5BTUU6ICdDaGVjayBZb3VyIEVsaWdpYmlsaXR5JyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgU1VQRVJWSVNPUl9EQVNIQk9BUkQ6IHtcclxuICAgICAgICBST1VURTogJy9hZG1pbi9kYXNoYm9hcmQnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0FkbWluIERhc2hib2FyZCcsXHJcbiAgICAgICAgTkFNRTogJ0FkbWluIERhc2hib2FyZCcsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIENSRUFURV9QUk9GSUxFOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvY3JlYXRlLXByb2ZpbGUnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ1Byb2ZpbGUnLFxyXG4gICAgICAgIE5BTUU6ICdQcm9maWxlJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgRUxJR0lCSUxJVFlfQ0FMQ1VMQVRPUjoge1xyXG4gICAgICAgIFJPVVRFOiAnL2FkbWluL2NhbGN1bGF0b3InLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0VsaWdpYmlsaXR5IENhbGN1bGF0b3InLFxyXG4gICAgICAgIE5BTUU6ICdFbGlnaWJpbGl0eSBDYWxjdWxhdG9yJyxcclxuICAgICAgICBQQVJFTlRfUk9VVEU6ICcnXHJcbiAgICB9LFxyXG4gICAgTUFOQUdFX1BST0dSQU1TOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvYWRtaW4vbWFuYWdlLXByb2dyYW1zJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdNYW5hZ2UgUHJvZ3JhbXMnLFxyXG4gICAgICAgIE5BTUU6ICdNYW5hZ2UgUHJvZ3JhbXMnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBNQU5BR0VfU01UUDoge1xyXG4gICAgICAgIFJPVVRFOiAnL2FkbWluL21hbmFnZS1zbXRwJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdNYW5hZ2UgU210cCcsXHJcbiAgICAgICAgTkFNRTogJ01hbmFnZSBTbXRwJyAsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIE1BTkFHRV9QUkVBUFBMSUNBVElPTjoge1xyXG4gICAgICAgIFJPVVRFOiAnL2FkbWluL21hbmFnZS1wcmVhcHBsaWNhdGlvbnMnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ01hbmFnZSBQcmVhcHBsaWNhdGlvbicsXHJcbiAgICAgICAgTkFNRTogJ01hbmFnZSBQcmVhcHBsaWNhdGlvbicsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIEhPVVNFX0hPTERfREVUQUlMOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvaG91c2UtaG9sZC1kZXRhaWwnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0hvdXNlIEhvbGQgRGV0YWlsJyxcclxuICAgICAgICBOQU1FOiAnSG91c2UgSG9sZCBEZXRhaWwnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBSRVZJRVdfQVBQTElDQVRJT046IHtcclxuICAgICAgICBST1VURTogJy9yZXZpZXctYXBwbGljYXRpb24nLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ1JldmlldyBBcHBsaWNhdGlvbicsXHJcbiAgICAgICAgTkFNRTogJ1JldmlldyBBcHBsaWNhdGlvbicsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIEhPVVNFSE9MRF9JTkNPTUU6IHtcclxuICAgICAgICBST1VURTogJy9ob3VzZWhvbGQtaW5jb21lJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdIb3VzZWhvbGQgSW5jb21lJyxcclxuICAgICAgICBOQU1FOiAnSG91c2Vob2xkIEluY29tZScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIEhPVVNFSE9MRF9BU1NFVFM6IHtcclxuICAgICAgICBST1VURTogJy9ob3VzZWhvbGQtYXNzZXRzJywgLy9TaG91bGQgYmUgdW5pcXVlXHJcbiAgICAgICAgVElUTEU6ICdIb3VzZWhvbGQgQXNzZXRzJyxcclxuICAgICAgICBOQU1FOiAnSG91c2Vob2xkIEFzc2V0cycsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIEhPVVNFSE9MRF9TUEVDSUFMX0VYUEVOU0VTOiB7XHJcbiAgICAgICAgUk9VVEU6ICcvaG91c2Vob2xkLXNwZWNpYWwtZXhwZW5zZXMnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ0hvdXNlaG9sZCBTcGVjaWFsIEV4cGVuc2VzJyxcclxuICAgICAgICBOQU1FOiAnSG91c2Vob2xkIFNwZWNpYWwgRXhwZW5zZXMnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBSRU5UX0FGRk9SREFCSUxJVFk6IHtcclxuICAgICAgICBST1VURTogJy9yZW50LWFmZm9yZGFiaWxpdHknLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ1JlbnQgQWZmb3JkYWJpbGl0eScsXHJcbiAgICAgICAgTkFNRTogJ1JlbnQgQWZmb3JkYWJpbGl0eScsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfSxcclxuICAgIFlPVVJfRE9DVU1FTlRTOiB7XHJcbiAgICAgICAgUk9VVEU6ICcveW91ci1kb2N1bWVudHMnLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ1JvdXIgRG9jdW1lbnRzJyxcclxuICAgICAgICBOQU1FOiAnUm91ciBEb2N1bWVudHMnLFxyXG4gICAgICAgIFBBUkVOVF9ST1VURTogJydcclxuICAgIH0sXHJcbiAgICBSRVZJRVdfQU5EX1NJR046IHtcclxuICAgICAgICBST1VURTogJy9yZXZpZXctYW5kLXNpZ24nLCAvL1Nob3VsZCBiZSB1bmlxdWVcclxuICAgICAgICBUSVRMRTogJ1JldmlldyBBbmQgU2lnbicsXHJcbiAgICAgICAgTkFNRTogJ1JldmlldyBBbmQgU2lnbicsXHJcbiAgICAgICAgUEFSRU5UX1JPVVRFOiAnJ1xyXG4gICAgfVxyXG59O1xyXG4iLCIvKipcclxuICogc2V0IExvY2FsU3RvcmFnZSBmb3IgZ2l2ZW4ga2V5IGFuZCB2YWx1ZVxyXG4gKiBAcGFyYW0geyp9IGtleVxyXG4gKiBAcGFyYW0geyp9IHZhbHVlXHJcbiAqL1xyXG5leHBvcnQgY29uc3Qgc2V0TG9jYWxTdG9yYWdlID0gKGtleSwgdmFsdWUpID0+IHtcclxuICAgIGxldCBzdG9yYWdlVmFsdWUgPSB2YWx1ZTtcclxuICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XHJcbiAgICAgICAgc3RvcmFnZVZhbHVlID0gSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xyXG4gICAgfVxyXG4gICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKGtleSwgc3RvcmFnZVZhbHVlKTtcclxufTtcclxuXHJcbi8qKlxyXG4gKiBSZXR1cm4gdGhlIExvY2FsU3RvcmFnZSBmb3IgZ2l2ZW4ga2V5XHJcbiAqIEBwYXJhbSB7Kn0ga2V5XHJcbiAqL1xyXG5leHBvcnQgY29uc3QgZ2V0TG9jYWxTdG9yYWdlID0gKGtleSkgPT4ge1xyXG4gICAgY29uc3QgdmFsdWUgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oa2V5KTtcclxuICAgIHJldHVybiB2YWx1ZSAmJiBKU09OLnBhcnNlKHZhbHVlKTtcclxufTtcclxuXHJcbi8qKlxyXG4gKiBSZXR1cm4gcmVtb3ZlZCBpdGVtXHJcbiAqL1xyXG5leHBvcnQgY29uc3QgcmVtb3ZlTG9jYWxTdG9yYWdlID0gKGtleSkgPT4ge1xyXG4gICAgY29uc3QgdmFsdWUgPSBnZXRMb2NhbFN0b3JhZ2Uoa2V5KTtcclxuICAgIHdpbmRvdy5sb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShrZXkpO1xyXG4gICAgcmV0dXJuIHZhbHVlO1xyXG59O1xyXG4iLCJpbXBvcnQgeyBnZXRMb2NhbFN0b3JhZ2UgfSBmcm9tICcuL3N0b3JlTWFuYWdlcic7XHJcblxyXG4vL3V0aWxpdHkgZnVuY3Rpb25zIGhlcmVcclxuZXhwb3J0IGNvbnN0IGdldEJhc2VVcmwgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gcHJvY2Vzcy5lbnYuTkVYVF9QVUJMSUNfQVBJX0JBU0VfVVJMO1xyXG59O1xyXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tZW1wdHktZnVuY3Rpb25cclxuZXhwb3J0IGNvbnN0IG5vb3AgPSAoKSA9PiB7fTtcclxuXHJcbmV4cG9ydCBjb25zdCBnZXRMb2NhbGl6ZUtleSA9ICgpID0+IHtcclxuICAgIHJldHVybiBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19MT0NBTElaRV9KU19LRVk7XHJcbn07XHJcblxyXG5leHBvcnQgY29uc3QgZ2V0VXNlcklkID0gKCkgPT4ge1xyXG4gICAgY29uc3QgdXNlckRldGFpbCA9IGdldExvY2FsU3RvcmFnZSgndXNlcl9kZXRhaWxzJykgfHwge307XHJcbiAgICByZXR1cm4gdXNlckRldGFpbD8udXNlcl9pZDtcclxufTtcclxuXHJcbmV4cG9ydCBjb25zdCBnZXRBY2Nlc3NUb2tlbiA9ICgpID0+IHtcclxuICAgIGNvbnN0IHVzZXJEZXRhaWwgPSBnZXRMb2NhbFN0b3JhZ2UoJ3VzZXJfZGV0YWlscycpIHx8IHt9O1xyXG4gICAgcmV0dXJuIHVzZXJEZXRhaWw/LmFjY2Vzc190b2tlbjtcclxufTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9CYWRnZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS9zdHlsZXNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2NvcmUvdXNlTWVkaWFRdWVyeVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJAbWF0ZXJpYWwtdWkvY29yZS93aXRoV2lkdGhcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL0Nsb3NlXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9DbG9zZU91dGxpbmVkXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIkBtYXRlcmlhbC11aS9pY29ucy9FeHBhbmRNb3JlT3V0bGluZWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2ljb25zL0hlbHBPdXRsaW5lT3V0bGluZWRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQG1hdGVyaWFsLXVpL2xhYlwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJjbHN4XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImZlYXRoZXItaWNvbnMtcmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9yb3V0ZXJcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicHJvcC10eXBlc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1mZWF0aGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiKTsiXSwic291cmNlUm9vdCI6IiJ9