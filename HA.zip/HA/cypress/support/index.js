import 'cypress-axe';
import './commands.js';
